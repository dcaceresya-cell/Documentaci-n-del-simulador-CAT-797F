# 3D Internal Combustion Engine Interactive Demo

> **Built for teaching** — an interactive, browser-based teaching aid for explaining how a four-stroke internal combustion engine works. Ideal for classroom projection, lab demos, and student self-study.

An interactive 3D simulation of a **four-stroke diesel engine**, built with Three.js in a single HTML file — no build step, no dependencies to install.

A fully articulated crank-slider mechanism (crankshaft, connecting rod, piston, flywheel, fuel injector, intake/exhaust valves) runs continuously through the complete **intake → compression → power → exhaust** cycle. Adjust the crankshaft speed with the RPM slider, run / pause / single-step the animation, pull the engine apart with the exploded-view slider, or toggle the translucent casing to watch the internals move. Every part is clickable and highlights with its name and function. Flame and fuel-spray particles visualize injection and combustion, animated arrows trace intake and exhaust airflow, and a real-time HUD labels the current stroke, crank angle, and valve states — all rendered in a dark, tech-styled 3D scene.

## Features

- **Accurate kinematics** — piston motion follows the exact slider-crank equation `y = r·cosθ + √(L² − r²sin²θ)`
- **Strict 4-stroke cycle** — 0–180° intake, 180–360° compression, 360–540° power, 540–720° exhaust, with live stroke indicator and crank-angle readout
- **Interactive controls** — RPM slider (0–1200), run/pause, +10° single-step, exploded view (0–100%), translucent shell, camera reset
- **Part annotation** — click any component for a pulsing highlight plus its name and function description
- **Effects** — combustion flame particles, fuel-spray mist, dynamic fire lighting, colored airflow arrows, starfield/grid background
- **Single file** — everything (UI, styles, logic) in one `index.html`; Three.js loads from CDN with automatic multi-source fallback

## For Teaching

Designed as an interactive teaching aid for engineering / physics classes:

- **Live stroke annotation** — the HUD continuously labels the current stroke, crank angle, and valve states, staying in sync with the animation while you explain
- **Single-step mode** — advance the crankshaft +10° per click (or `→` key) to walk through valve timing, injection, and ignition moment by moment
- **Slow motion** — drop the RPM slider to near zero to observe the mechanism at any pace
- **Exploded view + translucent casing** — disassemble the engine layer by layer, or make the block transparent to reveal the piston, rod, and crankshaft inside
- **Click-to-learn parts** — every component highlights and shows its name and function, like an interactive diagram
- **Zero setup** — one HTML file, opens in any modern browser; works offline if `three.module.js` is placed next to it

## Usage

Open `index.html` in any modern browser (internet required on first load to fetch Three.js).

Controls: drag to orbit · scroll to zoom · click a part for details · `Space` run/pause · `→` single-step.

---

## 中文简介

> **为教学而生** —— 可交互的四冲程内燃机浏览器教具，适合课堂投影演示、实验课讲解与学生自学。

一个基于 Three.js 的**四冲程柴油机 3D 交互仿真**，全部实现在单个 HTML 文件中，无需构建、即开即用。

完整的曲柄-连杆-活塞机构（曲轴、连杆、活塞、飞轮、喷油器、进排气门）严格按照**进气 → 压缩 → 做功 → 排气**四冲程循环运转，活塞运动遵循精确的滑块曲柄方程。支持转速调节（0–1200 RPM）、运行/暂停/单步、爆炸视图、半透明外壳；点击任意零件可高亮并查看名称与功能说明。做功冲程显示火焰与喷油粒子，进排气以箭头气流表示，顶部 HUD 实时标注当前冲程、曲轴转角与气门状态，整体为深色科技风 3D 场景。

**教学亮点**：

- 冲程名称、曲轴转角、气门开闭状态实时同步标注，讲课时画面与讲解一致
- 单步模式（每次 +10°）逐帧观察气门正时、喷油与着火时机；转速调低即可慢放
- 爆炸视图逐层拆解发动机，半透明外壳直接透视内部活塞、连杆、曲轴
- 点击零件即显示名称与功能说明，相当于可交互的教学挂图
- 单文件零安装，浏览器打开即用，课堂投影和学生课后自学都方便

**使用方法**：用现代浏览器直接打开 `index.html`（首次需联网加载 Three.js，内置多源自动切换）。拖拽旋转视角，滚轮缩放，空格运行/暂停，→ 键单步。
