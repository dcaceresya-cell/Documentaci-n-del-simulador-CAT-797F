#!/usr/bin/env python3
import os
import json
import yaml
import hashlib
import time
from collections import deque
from dataclasses import dataclass
from typing import List, Dict, Any, Iterator
from dotenv import load_dotenv
import requests

load_dotenv()

API_KEY = os.getenv("ANYTHING_LLM_API_KEY")
BASE_URL = os.getenv("ANYTHING_LLM_URL", "http://localhost:3001/v1")

@dataclass
class Rule:
    id: str
    parameter: str
    operator: str
    threshold: float
    unit: str
    duration_sec: float
    sample_interval: float
    severity: str

class DebouncedRuleEvaluator:
    def __init__(self, rule: Rule):
        self.rule = rule
        required_samples = int(rule.duration_sec / rule.sample_interval) if rule.sample_interval > 0 else 1
        self.buffer = deque(maxlen=required_samples)

    def update(self, value: float) -> bool:
        condition = value > self.rule.threshold if self.rule.operator == ">" else value < self.rule.threshold
        self.buffer.append(condition)
        return all(self.buffer) and len(self.buffer) == self.buffer.maxlen

def load_rules_from_yaml(path: str = "config/rules.yaml") -> List[Rule]:
    with open(path) as f:
        data = yaml.safe_load(f)
    return [Rule(**r) for r in data["rules"]]

def create_evidence_snapshot(rule: Rule, value: float, engine_rpm: float, frame_timestamp: float) -> Dict[str, Any]:
    snapshot = {
        "schema_version": "1.0",
        "rule_id": rule.id,
        "parameter": rule.parameter,
        "value": value,
        "unit": rule.unit,
        "threshold": rule.threshold,
        "duration_sec": rule.duration_sec,
        "engine_rpm": engine_rpm,
        "timestamp": frame_timestamp,
    }
    content = json.dumps(snapshot, sort_keys=True).encode()
    snapshot["content_hash"] = hashlib.sha256(content).hexdigest()
    return snapshot

def save_snapshot(snapshot: Dict):
    os.makedirs("evidence", exist_ok=True)
    with open("evidence/latest_snapshot.json", "w") as f:
        json.dump(snapshot, f, indent=2)
    with open("evidence/latest_snapshot.sha256", "w") as f:
        f.write(snapshot["content_hash"])

def query_anythingllm(evidence: Dict, workspace_slug: str, timeout_sec: int = 30) -> Dict:
    if not API_KEY or API_KEY == "your_key_here":
        return {"fallback": True, "message": "Tier 2 not configured – evidence only."}

    query_text = (
        f"Exhaust gas temperature alarm. Parameter: {evidence['parameter']}, "
        f"observed value: {evidence['value']} °C, threshold: {evidence['threshold']} °C. "
        f"Engine RPM: {evidence['engine_rpm']}. "
        f"What are the typical causes for elevated exhaust temperature in a marine diesel? "
        f"Provide diagnostic steps from the service manual."
    )

    payload = {"message": query_text, "mode": "query"}
    headers = {"Authorization": f"Bearer {API_KEY}", "Content-Type": "application/json"}
    endpoint = f"{BASE_URL}/workspace/{workspace_slug}/chat"

    try:
        resp = requests.post(endpoint, headers=headers, json=payload, timeout=timeout_sec)
        resp.raise_for_status()
        return resp.json()
    except (requests.exceptions.RequestException, json.JSONDecodeError) as e:
        return {"fallback": True, "error": str(e), "message": "Tier 2 unavailable – evidence only."}

def iter_telemetry_from_log(log_path: str) -> Iterator[Dict[str, Any]]:
    with open(log_path) as f:
        data = json.load(f)
    for frame in data:
        yield {
            "timestamp": frame.get("timestamp", time.time()),
            "exhaust_temp": frame.get("exhaust_temp"),
            "oil_pressure": frame.get("oil_pressure"),
            "engine_rpm": frame.get("rpm", 0),
        }

def main():
    print("[*] Marine Engine Condition Monitoring Demo")
    print("[*] Deterministic Core (Mode A) + Optional AI (Mode B)\n")

    try:
        rules = load_rules_from_yaml()
        print(f"[✓] Loaded {len(rules)} rules from configuration.")
    except Exception as e:
        print(f"[!] Could not load rules: {e}")
        return

    evaluators = {r.id: DebouncedRuleEvaluator(r) for r in rules}
    log_path = "data/sample_engine_log.json"

    print("[*] Replaying telemetry log...")
    triggered = False
    for frame in iter_telemetry_from_log(log_path):
        for rule in rules:
            evaluator = evaluators[rule.id]
            value = frame.get(rule.parameter)
            if value is None:
                continue
            if evaluator.update(value):
                snapshot = create_evidence_snapshot(rule, value, frame["engine_rpm"], frame["timestamp"])
                save_snapshot(snapshot)
                print(f"\n[!] ALARM TRIGGERED")
                print(f"    Rule:        {rule.id}")
                print(f"    Parameter:   {rule.parameter}")
                print(f"    Value:       {value} {rule.unit}")
                print(f"    Threshold:   {rule.threshold} {rule.unit}")
                print(f"    Severity:    {rule.severity}")
                print(f"\n[✓] Evidence snapshot saved & hashed")
                print(f"    SHA-256:     {snapshot['content_hash']}")

                result = query_anythingllm(snapshot, workspace_slug="yanmar-gm-series")
                if result.get("fallback"):
                    print(f"\n[*] Tier 2 Fallback Status: {result.get('message')}")
                else:
                    print("\n=== ADVISORY DIAGNOSIS ===")
                    print(result.get("textResponse", "No response."))
                triggered = True
                break
        if triggered:
            break

    if not triggered:
        print("[*] Replay finished. No rules triggered.")

if __name__ == "__main__":
    main()
