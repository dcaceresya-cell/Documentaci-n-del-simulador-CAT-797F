import pytest
from main import Rule, DebouncedRuleEvaluator, create_evidence_snapshot

def test_rule_evaluation_threshold():
    rule = Rule(
        id="test_exhaust",
        parameter="exhaust_temp",
        operator=">",
        threshold=500.0,
        unit="°C",
        duration_sec=1.0,
        sample_interval=0.5,
        severity="warning"
    )
    evaluator = DebouncedRuleEvaluator(rule)
    
    # First sample above threshold (needs 2 samples total for 1s duration at 0.5s interval)
    assert evaluator.update(510.0) is False
    # Second sample above threshold -> should trigger
    assert evaluator.update(520.0) is True

def test_evidence_snapshot_hash():
    rule = Rule(
        id="test_exhaust",
        parameter="exhaust_temp",
        operator=">",
        threshold=500.0,
        unit="°C",
        duration_sec=1.0,
        sample_interval=0.5,
        severity="warning"
    )
    snapshot = create_evidence_snapshot(rule, 520.0, 2000.0, 1700000000.0)
    assert "content_hash" in snapshot
    assert len(snapshot["content_hash"]) == 64
