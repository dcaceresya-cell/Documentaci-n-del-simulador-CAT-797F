# Marine Engine Condition Monitoring & Diagnostic Assistant

> **Deterministic detection first. AI assistance second.**  
> *A local-first prototype for marine diesel engine condition monitoring, alarm detection, and maintenance-oriented diagnostic assistance.*

[![Python 3.10+](https://img.shields.io/badge/python-3.10+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

---

## Engineering Objective

Demonstrate how marine engine telemetry (such as exhaust temperature, lubricating-oil pressure, and coolant temperature) can be monitored against configurable engineering rules, converted into persistent evidence with cryptographic integrity, and optionally analyzed using local AI/RAG tools.

---

## Architecture Overview

[200~ENGINE TELEMETRY
                    │
                    ▼
         ┌────────────────────┐
         │ Telemetry Replay   │
         └─────────┬──────────┘
                   │
                   ▼
         ┌────────────────────┐
         │ Deterministic Rule │
         │ Engine (Debounced) │
         └─────────┬──────────┘
                   │
         ┌─────────┴─────────┐
         │                   │
      NORMAL              ALARM
         │                   │
         │                   ▼
         │        ┌──────────────────┐
         │        │ Evidence Snapshot│
         │        └────────┬─────────┘
         │                 │
         │                 ▼
         │        ┌──────────────────┐
         │        │ SHA-256 Integrity│
         │        │ Hash             │
         │        └────────┬─────────┘
         │                 │
         │                 ▼
         │        Optional AI/RAG
         │        Diagnostic Layer
         │                 │
         └─────────────────┴──────►
                  Engineer Review

---

## Getting Started (Zero-AI Demo Mode)

You can run the deterministic core immediately without installing Docker, Ollama, or API keys.

```bash
# Clone and enter repository
cd marine-engine-condition-monitoring

# Create and activate virtual environment
python3 -m venv .venv
source .venv/bin/activate

# Install dependencies
pip install -r requirements.txt

# Run deterministic demo
python main.py~

Limitations
The thresholds included in the configuration are sample values for software testing and must not be interpreted as universal OEM operating limits.

The system is an offline advisory prototype and does not replace class-approved safety systems or professional watchkeeping judgment.

License
Licensed under the MIT License. See LICENSE for details.
