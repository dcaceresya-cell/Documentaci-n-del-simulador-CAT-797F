"""
data_loader.py — Data loading and preprocessing for NASA C-MAPSS dataset.

The C-MAPSS (Commercial Modular Aero-Propulsion System Simulation) dataset
contains run-to-failure simulations of turbofan engines under different
operating conditions and fault modes. Each engine starts healthy and develops
a fault at some unknown point, eventually reaching failure.

Dataset columns:
    - unit_id:        Engine unit number
    - cycle:          Current operational cycle
    - op_setting_1-3: Operational settings (altitude, Mach number, TRA)
    - sensor_1-21:    Sensor measurements (temperatures, pressures, speeds, etc.)

We compute the Remaining Useful Life (RUL) as the target variable:
    RUL = max_cycle_for_engine - current_cycle

Author: Tomás Nascimento
"""

import os
import urllib.request
import numpy as np
import pandas as pd
from sklearn.preprocessing import MinMaxScaler


# ─── Column names for the C-MAPSS dataset ───────────────────────────────────
# The raw .txt files have no headers, so we define them explicitly
COLUMN_NAMES = [
    "unit_id", "cycle",
    "op_setting_1", "op_setting_2", "op_setting_3",
    "sensor_1", "sensor_2", "sensor_3", "sensor_4", "sensor_5",
    "sensor_6", "sensor_7", "sensor_8", "sensor_9", "sensor_10",
    "sensor_11", "sensor_12", "sensor_13", "sensor_14", "sensor_15",
    "sensor_16", "sensor_17", "sensor_18", "sensor_19", "sensor_20",
    "sensor_21",
]

# Sensors that are constant or near-constant across all engines — these carry
# no useful degradation signal, so we drop them to reduce noise
DROP_SENSORS = ["sensor_1", "sensor_5", "sensor_6", "sensor_10",
                "sensor_16", "sensor_18", "sensor_19"]

# Also drop operational settings — they describe the *environment*, not the
# health state, and can confuse the model in a baseline setup
DROP_SETTINGS = ["op_setting_3"]

# GitHub mirror hosting the raw C-MAPSS data files
_BASE_URL = (
    "https://raw.githubusercontent.com/"
    "LahiruJayasinghe/RUL-Net/master/CMAPSSData"
)


def download_dataset(data_dir: str = "data", subset: str = "FD001") -> str:
    """
    Download the NASA C-MAPSS dataset files from a public GitHub mirror.
    
    FD001 is the simplest subset: single operating condition, single fault mode.
    Perfect for a baseline LSTM model before scaling to harder subsets.
    
    Returns the path to the data directory.
    """
    os.makedirs(data_dir, exist_ok=True)
    
    # Files we need for a given subset
    files = [f"train_{subset}.txt", f"test_{subset}.txt", f"RUL_{subset}.txt"]
    
    # Check if data already exists
    if all(os.path.exists(os.path.join(data_dir, f)) for f in files):
        print("Dataset already downloaded.")
        return data_dir

    print(f"Downloading C-MAPSS {subset} dataset...")
    for fname in files:
        url = f"{_BASE_URL}/{fname}"
        dest = os.path.join(data_dir, fname)
        print(f"  {fname}...", end=" ")
        urllib.request.urlretrieve(url, dest)
        # Verify the file has actual data (not an error page)
        size = os.path.getsize(dest)
        if size < 100:
            raise RuntimeError(
                f"Downloaded file {fname} is too small ({size} bytes). "
                f"The mirror may be down. Please download manually from Kaggle:\n"
                f"  https://www.kaggle.com/datasets/behrad3d/"
                f"nasa-cmapss1-turbofan-engine-degradation-dataset"
            )
        print(f"Done ({size:,} bytes)")
    
    print("Dataset ready.\n")
    return data_dir


def load_raw_data(data_dir: str = "data", subset: str = "FD001"):
    """
    Load raw train/test/RUL files for a given C-MAPSS subset.
    
    Args:
        data_dir: Path to the directory containing the .txt files
        subset:   Which subset to load (FD001, FD002, FD003, or FD004)
    
    Returns:
        train_df:  Training DataFrame (full run-to-failure trajectories)
        test_df:   Test DataFrame (truncated trajectories)
        rul_true:  Ground-truth RUL values for the test set
    """
    train_path = os.path.join(data_dir, f"train_{subset}.txt")
    test_path  = os.path.join(data_dir, f"test_{subset}.txt")
    rul_path   = os.path.join(data_dir, f"RUL_{subset}.txt")

    # The files are space-separated with trailing spaces → use sep=r"\s+"
    train_df = pd.read_csv(train_path, sep=r"\s+", header=None, names=COLUMN_NAMES)
    test_df  = pd.read_csv(test_path,  sep=r"\s+", header=None, names=COLUMN_NAMES)
    rul_true = pd.read_csv(rul_path,   sep=r"\s+", header=None, names=["RUL"])

    print(f"Loaded {subset}:")
    print(f"  Train: {train_df.shape[0]:,} rows, {train_df['unit_id'].nunique()} engines")
    print(f"  Test:  {test_df.shape[0]:,} rows,  {test_df['unit_id'].nunique()} engines")
    
    return train_df, test_df, rul_true


def compute_rul(df: pd.DataFrame, max_rul: int = 125) -> pd.DataFrame:
    """
    Compute the Remaining Useful Life for each row in the training set.
    
    We also apply a piecewise-linear RUL cap: engines typically don't degrade
    linearly from the start. A cap of 125 cycles is standard in the literature
    — it means the model only needs to distinguish "healthy" from "degradation
    approaching failure", which is what we actually care about in practice.
    
    Args:
        df:      Training DataFrame with 'unit_id' and 'cycle' columns
        max_rul: Maximum RUL cap (default: 125, following Heimes 2008)
    
    Returns:
        DataFrame with an additional 'RUL' column
    """
    df = df.copy()
    
    # For each engine, RUL = last_cycle - current_cycle
    max_cycles = df.groupby("unit_id")["cycle"].max().reset_index()
    max_cycles.columns = ["unit_id", "max_cycle"]
    df = df.merge(max_cycles, on="unit_id", how="left")
    df["RUL"] = df["max_cycle"] - df["cycle"]
    df.drop("max_cycle", axis=1, inplace=True)
    
    # Cap the RUL — constant at max_rul, then linearly decreasing
    df["RUL"] = df["RUL"].clip(upper=max_rul)
    
    return df


def preprocess(train_df: pd.DataFrame, test_df: pd.DataFrame, max_rul: int = 125):
    """
    Full preprocessing pipeline:
    1. Compute RUL targets (with piecewise-linear cap)
    2. Drop uninformative sensors and settings
    3. Normalize features to [0, 1] using MinMaxScaler
    
    The scaler is fit on training data only — no data leakage.
    
    Returns:
        train_df:      Preprocessed training data with RUL column
        test_df:       Preprocessed test data (no RUL column)
        feature_cols:  List of feature column names used for modeling
    """
    # Step 1: Compute RUL for training data
    train_df = compute_rul(train_df, max_rul=max_rul)
    
    # Step 2: Identify feature columns (drop uninformative ones)
    drop_cols = DROP_SENSORS + DROP_SETTINGS + ["unit_id", "cycle"]
    feature_cols = [c for c in COLUMN_NAMES if c not in drop_cols]
    
    print(f"\nFeatures used ({len(feature_cols)}): {feature_cols}")
    
    # Step 3: Normalize using MinMaxScaler fit on TRAINING data only
    scaler = MinMaxScaler()
    train_df[feature_cols] = scaler.fit_transform(train_df[feature_cols])
    test_df[feature_cols]  = scaler.transform(test_df[feature_cols])
    
    return train_df, test_df, feature_cols


def create_sequences(df: pd.DataFrame, feature_cols: list,
                     sequence_length: int = 30, target_col: str = "RUL"):
    """
    Create sliding-window sequences for the LSTM.
    
    For each engine, we slide a window of `sequence_length` cycles across the
    time series. The target is the RUL at the *last* timestep in the window.
    
    Why sliding windows? LSTMs need fixed-length input sequences. By choosing
    a window size (e.g., 30 cycles), we assume that the last 30 cycles of
    sensor data contain enough information to predict the current RUL.
    
    Args:
        df:              DataFrame with features and RUL
        feature_cols:    Columns to use as input features
        sequence_length: Number of timesteps per sequence (default: 30)
        target_col:      Name of the target column
    
    Returns:
        X: np.array of shape (num_sequences, sequence_length, num_features)
        y: np.array of shape (num_sequences,) — RUL at the last timestep
    """
    sequences = []
    targets = []
    
    for unit_id in df["unit_id"].unique():
        unit_data = df[df["unit_id"] == unit_id]
        features = unit_data[feature_cols].values
        rul = unit_data[target_col].values
        
        # Only create sequences where we have enough history
        for i in range(len(features) - sequence_length + 1):
            sequences.append(features[i : i + sequence_length])
            targets.append(rul[i + sequence_length - 1])  # RUL at end of window
    
    X = np.array(sequences, dtype=np.float32)
    y = np.array(targets, dtype=np.float32)
    
    print(f"\nCreated {len(X):,} sequences of length {sequence_length}")
    print(f"  Feature shape: {X.shape}")
    print(f"  Target shape:  {y.shape}")
    
    return X, y


def create_test_sequences(df: pd.DataFrame, feature_cols: list,
                          sequence_length: int = 30):
    """
    Create test sequences — one per engine, using the LAST `sequence_length`
    cycles. This mirrors the evaluation protocol: given the most recent sensor
    readings, predict how many cycles until failure.
    
    If an engine has fewer cycles than `sequence_length`, we pad with zeros
    on the left (pre-padding).
    
    Returns:
        X_test: np.array of shape (num_engines, sequence_length, num_features)
    """
    sequences = []
    
    for unit_id in df["unit_id"].unique():
        unit_data = df[df["unit_id"] == unit_id]
        features = unit_data[feature_cols].values
        
        if len(features) >= sequence_length:
            # Take the last `sequence_length` cycles
            sequences.append(features[-sequence_length:])
        else:
            # Pad with zeros on the left if not enough cycles
            padding = np.zeros((sequence_length - len(features), len(feature_cols)))
            padded = np.vstack([padding, features])
            sequences.append(padded)
    
    X_test = np.array(sequences, dtype=np.float32)
    print(f"\nTest sequences: {X_test.shape}")
    
    return X_test
