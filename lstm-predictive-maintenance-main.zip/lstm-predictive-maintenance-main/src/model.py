"""
model.py — LSTM model architecture for Remaining Useful Life prediction.

We use a relatively simple LSTM architecture as a baseline:
    Input → LSTM (2 layers, dropout) → Fully Connected → RUL prediction

The idea is straightforward: the LSTM processes the sequence of sensor readings
over time and learns temporal patterns associated with engine degradation. The
hidden state at the final timestep captures the "summary" of the degradation
trajectory, which we then map to a RUL estimate through a small feedforward head.

Why LSTM over vanilla RNN?
    LSTMs handle the vanishing gradient problem through their gating mechanism,
    making them much better at capturing long-range dependencies in sequences.
    For predictive maintenance, degradation patterns can span dozens of cycles,
    so this is critical.

Author: Tomás Nascimento
"""

import torch
import torch.nn as nn


class LSTMModel(nn.Module):
    """
    LSTM-based model for predicting Remaining Useful Life (RUL).
    
    Architecture:
        LSTM (multi-layer, bidirectional=False) → Dropout → FC layers → Output
    
    We keep it unidirectional because in a real predictive maintenance scenario,
    we only have access to past sensor data, not future readings. Bidirectional
    LSTMs would leak future information and wouldn't be deployable in production.
    
    Args:
        input_dim:   Number of input features (sensor channels)
        hidden_dim:  LSTM hidden state dimensionality
        num_layers:  Number of stacked LSTM layers
        dropout:     Dropout rate between LSTM layers (regularization)
        fc_dim:      Dimensionality of the intermediate fully connected layer
    """
    
    def __init__(self, input_dim: int, hidden_dim: int = 64,
                 num_layers: int = 2, dropout: float = 0.3,
                 fc_dim: int = 32):
        super(LSTMModel, self).__init__()
        
        self.hidden_dim = hidden_dim
        self.num_layers = num_layers
        
        # ─── LSTM backbone ──────────────────────────────────────────────
        # batch_first=True means input/output tensors are (batch, seq, feature)
        # which is more intuitive than the default (seq, batch, feature)
        self.lstm = nn.LSTM(
            input_size=input_dim,
            hidden_size=hidden_dim,
            num_layers=num_layers,
            batch_first=True,
            dropout=dropout if num_layers > 1 else 0.0,  # Only applies between layers
        )
        
        # ─── Prediction head ────────────────────────────────────────────
        # We take the LSTM output at the last timestep and pass it through
        # a small feedforward network to get the RUL prediction
        self.dropout = nn.Dropout(p=dropout)
        
        self.fc_block = nn.Sequential(
            nn.Linear(hidden_dim, fc_dim),
            nn.ReLU(),
            nn.Dropout(p=dropout),
            nn.Linear(fc_dim, 1),  # Single output: predicted RUL
        )
    
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Forward pass.
        
        Args:
            x: Input tensor of shape (batch_size, sequence_length, input_dim)
        
        Returns:
            Predicted RUL of shape (batch_size, 1)
        """
        # Pass through LSTM — we only care about the output at the LAST timestep
        # lstm_out shape: (batch, seq_len, hidden_dim)
        # h_n shape:      (num_layers, batch, hidden_dim)
        lstm_out, (h_n, c_n) = self.lstm(x)
        
        # Take the hidden state from the last LSTM layer at the final timestep
        # This is equivalent to lstm_out[:, -1, :] but using h_n is cleaner
        last_hidden = h_n[-1]  # shape: (batch, hidden_dim)
        
        # Apply dropout + feedforward head
        out = self.dropout(last_hidden)
        out = self.fc_block(out)  # shape: (batch, 1)
        
        return out
    
    def count_parameters(self) -> int:
        """Count trainable parameters — useful for model comparison."""
        return sum(p.numel() for p in self.parameters() if p.requires_grad)


def build_model(input_dim: int, device: torch.device,
                hidden_dim: int = 64, num_layers: int = 2,
                dropout: float = 0.3, fc_dim: int = 32) -> LSTMModel:
    """
    Factory function to build and initialize the model.
    
    Prints a summary of the architecture for logging purposes.
    """
    model = LSTMModel(
        input_dim=input_dim,
        hidden_dim=hidden_dim,
        num_layers=num_layers,
        dropout=dropout,
        fc_dim=fc_dim,
    ).to(device)
    
    print(f"\n{'='*60}")
    print(f"LSTM Model Summary")
    print(f"{'='*60}")
    print(f"  Input dim:       {input_dim}")
    print(f"  Hidden dim:      {hidden_dim}")
    print(f"  LSTM layers:     {num_layers}")
    print(f"  Dropout:         {dropout}")
    print(f"  FC hidden dim:   {fc_dim}")
    print(f"  Total params:    {model.count_parameters():,}")
    print(f"  Device:          {device}")
    print(f"{'='*60}\n")
    
    return model
