"""
visualize.py — Publication-quality visualization for the LSTM RUL model.

Generates a set of figures that tell the complete story of the model:
    1. Training curves (loss convergence)
    2. Predicted vs. actual RUL scatter plot
    3. Error distribution histogram
    4. Per-engine RUL prediction comparison
    5. Sensor degradation heatmap

These figures are designed to look polished on GitHub — dark theme, clean
typography, and thoughtful color palettes.

Author: Tomás Nascimento
"""

import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib as mpl
import seaborn as sns
from matplotlib.gridspec import GridSpec


# ─── Global style configuration ─────────────────────────────────────────────
# We use a custom dark theme for a modern, professional look on GitHub
COLORS = {
    "bg":          "#0d1117",      # GitHub dark background
    "card":        "#161b22",      # Slightly lighter card background
    "text":        "#e6edf3",      # Light text
    "text_dim":    "#8b949e",      # Dimmed text for secondary info
    "accent":      "#58a6ff",      # Blue accent (GitHub blue)
    "accent_2":    "#3fb950",      # Green accent
    "accent_3":    "#f78166",      # Orange accent
    "accent_4":    "#d2a8ff",      # Purple accent
    "grid":        "#21262d",      # Subtle grid lines
    "gradient_1":  "#1f6feb",      # Gradient start
    "gradient_2":  "#238636",      # Gradient end
}

def setup_plot_style():
    """Configure matplotlib for dark-themed, publication-quality figures."""
    plt.rcParams.update({
        "figure.facecolor":    COLORS["bg"],
        "axes.facecolor":      COLORS["card"],
        "axes.edgecolor":      COLORS["grid"],
        "axes.labelcolor":     COLORS["text"],
        "axes.titlesize":      14,
        "axes.labelsize":      11,
        "text.color":          COLORS["text"],
        "xtick.color":         COLORS["text_dim"],
        "ytick.color":         COLORS["text_dim"],
        "xtick.labelsize":     9,
        "ytick.labelsize":     9,
        "legend.facecolor":    COLORS["card"],
        "legend.edgecolor":    COLORS["grid"],
        "legend.fontsize":     9,
        "grid.color":          COLORS["grid"],
        "grid.alpha":          0.5,
        "font.family":         "sans-serif",
        "font.sans-serif":     ["Helvetica", "Arial", "DejaVu Sans"],
        "figure.dpi":          150,
        "savefig.dpi":         200,
        "savefig.bbox":        "tight",
        "savefig.facecolor":   COLORS["bg"],
        "savefig.edgecolor":   "none",
    })


def plot_training_curves(history: dict, save_dir: str = "results/figures"):
    """
    Plot training and validation loss curves side by side with learning rate.
    
    This is the first thing people look at to verify the model trained properly.
    We want to see: train loss going down, val loss following (no overfitting),
    and the learning rate dropping when the loss plateaus.
    """
    setup_plot_style()
    os.makedirs(save_dir, exist_ok=True)
    
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 5))
    
    epochs = range(1, len(history["train_loss"]) + 1)
    
    # ─── Loss curves ─────────────────────────────────────────────────────
    ax1.plot(epochs, history["train_loss"], color=COLORS["accent"],
             linewidth=2, label="Train Loss", alpha=0.9)
    ax1.plot(epochs, history["val_loss"], color=COLORS["accent_3"],
             linewidth=2, label="Val Loss", alpha=0.9)
    
    # Fill the area between to highlight the gap (overfitting indicator)
    ax1.fill_between(epochs, history["train_loss"], history["val_loss"],
                     alpha=0.1, color=COLORS["accent"])
    
    ax1.set_xlabel("Epoch")
    ax1.set_ylabel("MSE Loss")
    ax1.set_title("Training & Validation Loss", fontweight="bold", pad=12)
    ax1.legend(framealpha=0.8)
    ax1.grid(True, alpha=0.3)
    
    # ─── RMSE + MAE curves ───────────────────────────────────────────────
    ax2.plot(epochs, history["val_rmse"], color=COLORS["accent_4"],
             linewidth=2, label="Val RMSE", alpha=0.9)
    ax2.plot(epochs, history["val_mae"], color=COLORS["accent_2"],
             linewidth=2, label="Val MAE", alpha=0.9)
    
    ax2.set_xlabel("Epoch")
    ax2.set_ylabel("Error (cycles)")
    ax2.set_title("Validation Metrics", fontweight="bold", pad=12)
    ax2.legend(framealpha=0.8)
    ax2.grid(True, alpha=0.3)
    
    plt.tight_layout(pad=2)
    path = os.path.join(save_dir, "training_curves.png")
    fig.savefig(path)
    plt.close(fig)
    print(f"  Saved: {path}")


def plot_predictions_scatter(predictions: np.ndarray, targets: np.ndarray,
                             save_dir: str = "results/figures"):
    """
    Scatter plot of predicted vs. actual RUL values.
    
    The diagonal line represents perfect predictions. Points above the line
    mean the model is overestimating RUL (dangerous — could miss a failure),
    and points below mean underestimation (conservative — triggers early
    maintenance, which is safer but costly).
    """
    setup_plot_style()
    os.makedirs(save_dir, exist_ok=True)
    
    fig, ax = plt.subplots(figsize=(8, 8))
    
    # Compute error for color-coding
    errors = np.abs(predictions - targets)
    
    # Scatter with color mapped to absolute error
    scatter = ax.scatter(
        targets, predictions,
        c=errors, cmap="coolwarm", s=20, alpha=0.6,
        edgecolors="none", vmin=0, vmax=np.percentile(errors, 95),
    )
    
    # Perfect prediction line
    max_val = max(targets.max(), predictions.max()) * 1.05
    ax.plot([0, max_val], [0, max_val], "--", color=COLORS["accent_2"],
            linewidth=1.5, alpha=0.8, label="Perfect prediction")
    
    # ±10 cycle tolerance band
    ax.fill_between([0, max_val], [0 - 10, max_val - 10], [0 + 10, max_val + 10],
                    alpha=0.08, color=COLORS["accent_2"], label="±10 cycle tolerance")
    
    # Colorbar
    cbar = plt.colorbar(scatter, ax=ax, shrink=0.8, pad=0.02)
    cbar.set_label("Absolute Error (cycles)", color=COLORS["text_dim"], fontsize=9)
    cbar.ax.yaxis.set_tick_params(color=COLORS["text_dim"])
    plt.setp(plt.getp(cbar.ax.axes, "yticklabels"), color=COLORS["text_dim"])
    
    # Metrics annotation
    rmse = np.sqrt(np.mean((predictions - targets) ** 2))
    mae = np.mean(np.abs(predictions - targets))
    ax.text(0.05, 0.95, f"RMSE: {rmse:.2f}\nMAE:  {mae:.2f}",
            transform=ax.transAxes, fontsize=11,
            verticalalignment="top", fontfamily="monospace",
            bbox=dict(boxstyle="round,pad=0.5", facecolor=COLORS["bg"],
                      edgecolor=COLORS["grid"], alpha=0.9))
    
    ax.set_xlabel("Actual RUL (cycles)")
    ax.set_ylabel("Predicted RUL (cycles)")
    ax.set_title("Predicted vs. Actual Remaining Useful Life",
                 fontweight="bold", pad=12)
    ax.legend(loc="lower right", framealpha=0.8)
    ax.set_xlim(0, max_val)
    ax.set_ylim(0, max_val)
    ax.set_aspect("equal")
    ax.grid(True, alpha=0.3)
    
    path = os.path.join(save_dir, "predictions_scatter.png")
    fig.savefig(path)
    plt.close(fig)
    print(f"  Saved: {path}")


def plot_error_distribution(predictions: np.ndarray, targets: np.ndarray,
                            save_dir: str = "results/figures"):
    """
    Histogram of prediction errors with a KDE overlay.
    
    Ideally, we want a narrow distribution centered at zero. Positive errors
    (overestimating RUL) are highlighted in red because they're dangerous.
    """
    setup_plot_style()
    os.makedirs(save_dir, exist_ok=True)
    
    fig, ax = plt.subplots(figsize=(10, 5))
    
    errors = predictions - targets
    
    # Create histogram with custom coloring
    n, bins, patches = ax.hist(errors, bins=50, edgecolor="none", alpha=0.85)
    
    # Color bars based on sign: blue for early predictions, orange for late
    for i, (patch, b) in enumerate(zip(patches, bins)):
        if b < 0:
            patch.set_facecolor(COLORS["accent"])    # Early (safe)
        else:
            patch.set_facecolor(COLORS["accent_3"])  # Late (dangerous)
    
    # KDE overlay
    from scipy.stats import gaussian_kde
    kde = gaussian_kde(errors)
    x_kde = np.linspace(errors.min() - 5, errors.max() + 5, 300)
    y_kde = kde(x_kde) * len(errors) * (bins[1] - bins[0])  # Scale to histogram
    ax.plot(x_kde, y_kde, color=COLORS["accent_4"], linewidth=2, alpha=0.9)
    
    # Zero line
    ax.axvline(x=0, color=COLORS["text_dim"], linestyle="--", linewidth=1, alpha=0.7)
    
    # Annotation
    mean_err = np.mean(errors)
    std_err = np.std(errors)
    ax.text(0.02, 0.95,
            f"Mean: {mean_err:+.2f}\nStd:  {std_err:.2f}",
            transform=ax.transAxes, fontsize=10,
            verticalalignment="top", fontfamily="monospace",
            bbox=dict(boxstyle="round,pad=0.5", facecolor=COLORS["bg"],
                      edgecolor=COLORS["grid"], alpha=0.9))
    
    # Legend for colors
    from matplotlib.patches import Patch
    legend_elements = [
        Patch(facecolor=COLORS["accent"], label="Early prediction (safe)"),
        Patch(facecolor=COLORS["accent_3"], label="Late prediction (risky)"),
    ]
    ax.legend(handles=legend_elements, loc="upper right", framealpha=0.8)
    
    ax.set_xlabel("Prediction Error (Predicted − Actual)")
    ax.set_ylabel("Count")
    ax.set_title("Distribution of RUL Prediction Errors", fontweight="bold", pad=12)
    ax.grid(True, alpha=0.3, axis="y")
    
    path = os.path.join(save_dir, "error_distribution.png")
    fig.savefig(path)
    plt.close(fig)
    print(f"  Saved: {path}")


def plot_engine_predictions(predictions: np.ndarray, targets: np.ndarray,
                            n_engines: int = 20,
                            save_dir: str = "results/figures"):
    """
    Bar chart comparing predicted vs. actual RUL for individual test engines.
    
    This is one of the most intuitive visualizations — it shows at a glance
    how well the model performs on each engine. Good for presentations.
    """
    setup_plot_style()
    os.makedirs(save_dir, exist_ok=True)
    
    fig, ax = plt.subplots(figsize=(14, 6))
    
    # Take first n_engines
    n = min(n_engines, len(predictions))
    indices = np.arange(n)
    bar_width = 0.35
    
    # Bars
    bars1 = ax.bar(indices - bar_width/2, targets[:n], bar_width,
                   label="Actual RUL", color=COLORS["accent"], alpha=0.85,
                   edgecolor="none")
    bars2 = ax.bar(indices + bar_width/2, predictions[:n], bar_width,
                   label="Predicted RUL", color=COLORS["accent_3"], alpha=0.85,
                   edgecolor="none")
    
    ax.set_xlabel("Engine Unit")
    ax.set_ylabel("RUL (cycles)")
    ax.set_title("Predicted vs. Actual RUL per Engine",
                 fontweight="bold", pad=12)
    ax.set_xticks(indices)
    ax.set_xticklabels([f"E{i+1}" for i in range(n)], rotation=45)
    ax.legend(framealpha=0.8)
    ax.grid(True, alpha=0.3, axis="y")
    
    plt.tight_layout(pad=2)
    path = os.path.join(save_dir, "engine_predictions.png")
    fig.savefig(path)
    plt.close(fig)
    print(f"  Saved: {path}")


def plot_sensor_degradation(train_df: pd.DataFrame, feature_cols: list,
                            engine_id: int = 1,
                            save_dir: str = "results/figures"):
    """
    Heatmap showing sensor degradation over the lifecycle of a single engine.
    
    This helps visualize what the model is "seeing" — gradual changes in
    sensor readings as the engine degrades toward failure. Some sensors
    show clear trends (useful features), while others are noisy.
    """
    setup_plot_style()
    os.makedirs(save_dir, exist_ok=True)
    
    fig, ax = plt.subplots(figsize=(14, 6))
    
    # Get data for the specified engine
    engine_data = train_df[train_df["unit_id"] == engine_id]
    sensor_data = engine_data[feature_cols].values.T  # (features, timesteps)
    
    # Create heatmap
    im = ax.imshow(sensor_data, aspect="auto", cmap="inferno",
                   interpolation="bilinear")
    
    # Colorbar
    cbar = plt.colorbar(im, ax=ax, shrink=0.8, pad=0.02)
    cbar.set_label("Normalized Sensor Value", color=COLORS["text_dim"], fontsize=9)
    cbar.ax.yaxis.set_tick_params(color=COLORS["text_dim"])
    plt.setp(plt.getp(cbar.ax.axes, "yticklabels"), color=COLORS["text_dim"])
    
    # Labels
    ax.set_yticks(range(len(feature_cols)))
    ax.set_yticklabels(feature_cols, fontsize=8)
    ax.set_xlabel("Cycle")
    ax.set_title(f"Sensor Degradation Over Time — Engine {engine_id}",
                 fontweight="bold", pad=12)
    
    # Add a vertical line and annotation near the end
    n_cycles = sensor_data.shape[1]
    ax.axvline(x=n_cycles - 1, color=COLORS["accent_3"], linestyle="--",
               linewidth=1.5, alpha=0.8)
    ax.text(n_cycles - 2, -0.8, "FAILURE →", color=COLORS["accent_3"],
            fontsize=8, ha="right", fontweight="bold")
    
    plt.tight_layout(pad=2)
    path = os.path.join(save_dir, "sensor_degradation.png")
    fig.savefig(path)
    plt.close(fig)
    print(f"  Saved: {path}")


def plot_rul_timeline(train_df: pd.DataFrame, engine_ids: list = None,
                      save_dir: str = "results/figures"):
    """
    Plot the RUL degradation timeline for multiple engines.
    
    This shows the piecewise-linear RUL pattern: constant at the cap (125 cycles),
    then linearly decreasing toward failure. Helps explain the target variable.
    """
    setup_plot_style()
    os.makedirs(save_dir, exist_ok=True)
    
    fig, ax = plt.subplots(figsize=(12, 5))
    
    if engine_ids is None:
        # Pick 5 engines with different lifecycle lengths for variety
        engine_ids = sorted(train_df["unit_id"].unique()[:5])
    
    cmap = plt.get_cmap("cool")
    n = len(engine_ids)
    
    for i, eid in enumerate(engine_ids):
        engine = train_df[train_df["unit_id"] == eid]
        color = cmap(i / max(n - 1, 1))
        ax.plot(engine["cycle"], engine["RUL"], linewidth=2, alpha=0.85,
                color=color, label=f"Engine {eid}")
    
    ax.set_xlabel("Cycle")
    ax.set_ylabel("Remaining Useful Life (RUL)")
    ax.set_title("RUL Degradation Timeline — Sample Engines",
                 fontweight="bold", pad=12)
    ax.legend(framealpha=0.8, ncol=2)
    ax.grid(True, alpha=0.3)
    
    # Annotate the RUL cap
    ax.axhline(y=125, color=COLORS["text_dim"], linestyle=":", linewidth=1, alpha=0.5)
    ax.text(5, 127, "RUL cap = 125", fontsize=8, color=COLORS["text_dim"])
    
    plt.tight_layout(pad=2)
    path = os.path.join(save_dir, "rul_timeline.png")
    fig.savefig(path)
    plt.close(fig)
    print(f"  Saved: {path}")


def plot_model_summary(predictions: np.ndarray, targets: np.ndarray,
                       history: dict, save_dir: str = "results/figures"):
    """
    Combined dashboard figure — the hero image for the README.
    
    Puts the 4 key visualizations into a single figure with a cohesive layout.
    """
    setup_plot_style()
    os.makedirs(save_dir, exist_ok=True)
    
    fig = plt.figure(figsize=(16, 10))
    gs = GridSpec(2, 2, figure=fig, hspace=0.35, wspace=0.3)
    
    # ─── Panel 1: Training curves ────────────────────────────────────────
    ax1 = fig.add_subplot(gs[0, 0])
    epochs = range(1, len(history["train_loss"]) + 1)
    ax1.plot(epochs, history["train_loss"], color=COLORS["accent"],
             linewidth=2, label="Train", alpha=0.9)
    ax1.plot(epochs, history["val_loss"], color=COLORS["accent_3"],
             linewidth=2, label="Validation", alpha=0.9)
    ax1.fill_between(epochs, history["train_loss"], history["val_loss"],
                     alpha=0.1, color=COLORS["accent"])
    ax1.set_xlabel("Epoch")
    ax1.set_ylabel("MSE Loss")
    ax1.set_title("Training Convergence", fontweight="bold", fontsize=12)
    ax1.legend(framealpha=0.8)
    ax1.grid(True, alpha=0.3)
    
    # ─── Panel 2: Scatter plot ───────────────────────────────────────────
    ax2 = fig.add_subplot(gs[0, 1])
    errors = np.abs(predictions - targets)
    ax2.scatter(targets, predictions, c=errors, cmap="coolwarm",
                s=15, alpha=0.5, edgecolors="none",
                vmin=0, vmax=np.percentile(errors, 95))
    max_val = max(targets.max(), predictions.max()) * 1.05
    ax2.plot([0, max_val], [0, max_val], "--", color=COLORS["accent_2"],
             linewidth=1.5, alpha=0.7)
    ax2.set_xlabel("Actual RUL")
    ax2.set_ylabel("Predicted RUL")
    ax2.set_title("Predicted vs. Actual", fontweight="bold", fontsize=12)
    ax2.set_xlim(0, max_val)
    ax2.set_ylim(0, max_val)
    ax2.set_aspect("equal")
    ax2.grid(True, alpha=0.3)
    
    # ─── Panel 3: Error distribution ─────────────────────────────────────
    ax3 = fig.add_subplot(gs[1, 0])
    errs = predictions - targets
    n, bins, patches = ax3.hist(errs, bins=40, edgecolor="none", alpha=0.85)
    for patch, b in zip(patches, bins):
        patch.set_facecolor(COLORS["accent"] if b < 0 else COLORS["accent_3"])
    ax3.axvline(x=0, color=COLORS["text_dim"], linestyle="--", linewidth=1)
    ax3.set_xlabel("Error (Predicted − Actual)")
    ax3.set_ylabel("Count")
    ax3.set_title("Error Distribution", fontweight="bold", fontsize=12)
    ax3.grid(True, alpha=0.3, axis="y")
    
    # ─── Panel 4: Engine-level comparison ────────────────────────────────
    ax4 = fig.add_subplot(gs[1, 1])
    n_engines = min(15, len(predictions))
    idx = np.arange(n_engines)
    bw = 0.35
    ax4.bar(idx - bw/2, targets[:n_engines], bw, label="Actual",
            color=COLORS["accent"], alpha=0.85, edgecolor="none")
    ax4.bar(idx + bw/2, predictions[:n_engines], bw, label="Predicted",
            color=COLORS["accent_3"], alpha=0.85, edgecolor="none")
    ax4.set_xlabel("Engine")
    ax4.set_ylabel("RUL (cycles)")
    ax4.set_title("Per-Engine RUL", fontweight="bold", fontsize=12)
    ax4.set_xticks(idx)
    ax4.set_xticklabels([f"E{i+1}" for i in range(n_engines)], fontsize=7)
    ax4.legend(framealpha=0.8)
    ax4.grid(True, alpha=0.3, axis="y")
    
    # ─── Main title ──────────────────────────────────────────────────────
    fig.suptitle("LSTM Predictive Maintenance — NASA C-MAPSS FD001 Results",
                 fontsize=16, fontweight="bold", color=COLORS["text"], y=0.98)
    
    path = os.path.join(save_dir, "model_summary.png")
    fig.savefig(path)
    plt.close(fig)
    print(f"  Saved: {path}")
