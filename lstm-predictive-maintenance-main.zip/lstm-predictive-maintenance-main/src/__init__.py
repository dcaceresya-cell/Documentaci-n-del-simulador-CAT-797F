# LSTM Predictive Maintenance - NASA C-MAPSS Dataset
# Author: Tomás Nascimento
