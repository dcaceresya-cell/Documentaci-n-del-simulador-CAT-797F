"""
train.py — Training loop and evaluation for the LSTM RUL model.

Implements a standard PyTorch training pipeline with:
    - Asymmetric MSE loss that penalizes late predictions more heavily.
      Late predictions (predicting RUL too high) are dangerous because
      they can cause missed failures. Early predictions (RUL too low)
      just trigger extra maintenance — costly but safe.
    - Adam optimizer with learning rate scheduling
    - Training/validation split for monitoring overfitting
    - Early stopping (optional) to prevent overtraining
    - RMSE and MAE metrics for evaluation

We also compute a "scoring function" used in the PHM08 challenge:
    - Penalizes late predictions (predicting RUL too high) more heavily
      than early predictions, because in practice it's much worse to miss
      a failure than to perform unnecessary maintenance.

Author: Tomás Nascimento
"""

import time
import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import DataLoader, TensorDataset
from tqdm import tqdm


class AsymmetricMSELoss(nn.Module):
    """
    Asymmetric MSE loss that penalizes late predictions more heavily.
    
    In predictive maintenance, the cost of errors is NOT symmetric:
        - Late prediction (predicted > actual): The model says the engine
          has more life than it actually does → could miss a failure.
          This is DANGEROUS and must be heavily penalized.
        - Early prediction (predicted < actual): The model says the engine
          will fail sooner than it will → triggers unnecessary maintenance.
          This is COSTLY but SAFE.
    
    The loss is:
        L = mean(w_i * (pred_i - target_i)^2)
    where:
        w_i = late_penalty_weight  if pred_i > target_i  (late/overestimate)
        w_i = 1.0                  if pred_i <= target_i (early/conservative)
    
    Args:
        late_penalty_weight: Multiplier for late prediction errors (default: 3.0).
            Higher values push the model toward conservative predictions.
            A value of 1.0 recovers standard MSE.
    """
    
    def __init__(self, late_penalty_weight: float = 3.0):
        super(AsymmetricMSELoss, self).__init__()
        self.late_penalty_weight = late_penalty_weight
    
    def forward(self, predictions: torch.Tensor, targets: torch.Tensor) -> torch.Tensor:
        errors = predictions - targets
        squared_errors = errors ** 2
        
        # Weight matrix: 1.0 for early predictions, late_penalty_weight for late
        weights = torch.where(
            errors > 0,
            torch.tensor(self.late_penalty_weight, device=errors.device, dtype=errors.dtype),
            torch.tensor(1.0, device=errors.device, dtype=errors.dtype),
        )
        
        return torch.mean(weights * squared_errors)
    
    def __repr__(self):
        return f"AsymmetricMSELoss(late_penalty_weight={self.late_penalty_weight})"


def train_one_epoch(model, dataloader, criterion, optimizer, device):
    """
    Train the model for one epoch.
    
    Returns the average loss over all batches.
    """
    model.train()
    total_loss = 0.0
    num_batches = 0
    
    for X_batch, y_batch in dataloader:
        X_batch = X_batch.to(device)
        y_batch = y_batch.to(device)
        
        # Forward pass
        predictions = model(X_batch).squeeze()
        loss = criterion(predictions, y_batch)
        
        # Backward pass
        optimizer.zero_grad()
        loss.backward()
        
        # Gradient clipping — LSTMs can have exploding gradients, especially
        # during early training. Clipping at 1.0 is a safe default.
        torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
        
        optimizer.step()
        
        total_loss += loss.item()
        num_batches += 1
    
    return total_loss / num_batches


def evaluate(model, dataloader, criterion, device):
    """
    Evaluate the model on a validation/test set.
    
    Returns:
        avg_loss:    Average MSE loss
        predictions: All predictions as a numpy array
        targets:     All ground-truth values as a numpy array
    """
    model.eval()
    total_loss = 0.0
    num_batches = 0
    all_preds = []
    all_targets = []
    
    with torch.no_grad():
        for X_batch, y_batch in dataloader:
            X_batch = X_batch.to(device)
            y_batch = y_batch.to(device)
            
            predictions = model(X_batch).squeeze()
            loss = criterion(predictions, y_batch)
            
            total_loss += loss.item()
            num_batches += 1
            all_preds.append(predictions.cpu().numpy())
            all_targets.append(y_batch.cpu().numpy())
    
    avg_loss = total_loss / num_batches
    all_preds = np.concatenate(all_preds)
    all_targets = np.concatenate(all_targets)
    
    return avg_loss, all_preds, all_targets


def compute_metrics(predictions: np.ndarray, targets: np.ndarray):
    """
    Compute evaluation metrics for RUL prediction.
    
    Returns:
        rmse: Root Mean Squared Error
        mae:  Mean Absolute Error
        score: PHM08 scoring function (asymmetric penalty)
    """
    errors = predictions - targets
    
    # Standard regression metrics
    rmse = np.sqrt(np.mean(errors ** 2))
    mae = np.mean(np.abs(errors))
    
    # PHM08 scoring function — asymmetric penalty
    # Late predictions (RUL overestimated → missing a failure) are penalized
    # more heavily than early predictions (RUL underestimated → extra maintenance)
    score = 0.0
    for e in errors:
        if e < 0:
            # Early prediction: exponential penalty with alpha=1/13
            score += np.exp(-e / 13.0) - 1.0
        else:
            # Late prediction: exponential penalty with alpha=1/10 (steeper!)
            score += np.exp(e / 10.0) - 1.0
    
    return rmse, mae, score


def train_model(model, X_train, y_train, X_val, y_val, device,
                epochs: int = 50, batch_size: int = 256,
                learning_rate: float = 0.001, patience: int = 10,
                late_penalty_weight: float = 3.0):
    """
    Full training loop with validation monitoring.
    
    Args:
        model:         The LSTM model
        X_train/y_train: Training sequences and targets
        X_val/y_val:     Validation sequences and targets 
        device:              torch.device (cpu/cuda/mps)
        epochs:              Maximum number of training epochs
        batch_size:          Mini-batch size
        learning_rate:       Initial learning rate for Adam
        patience:            Early stopping patience (epochs without improvement)
        late_penalty_weight: How much more to penalize late predictions vs early.
                             1.0 = standard MSE, >1.0 = penalize overestimation.
                             Default 3.0 means late errors cost 3x more.
    
    Returns:
        history: Dict with training/validation metrics per epoch
    """
    # ─── Prepare data loaders ─────────────────────────────────────────────
    train_dataset = TensorDataset(
        torch.tensor(X_train, dtype=torch.float32),
        torch.tensor(y_train, dtype=torch.float32),
    )
    val_dataset = TensorDataset(
        torch.tensor(X_val, dtype=torch.float32),
        torch.tensor(y_val, dtype=torch.float32),
    )
    
    train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
    val_loader   = DataLoader(val_dataset,   batch_size=batch_size, shuffle=False)
    
    # ─── Loss, optimizer, scheduler ───────────────────────────────────────
    criterion = AsymmetricMSELoss(late_penalty_weight=late_penalty_weight)
    print(f"  Loss function: {criterion}")
    optimizer = torch.optim.Adam(model.parameters(), lr=learning_rate)
    
    # Reduce learning rate when validation loss plateaus
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
        optimizer, mode="min", factor=0.5, patience=5,
    )
    
    # ─── Training history ─────────────────────────────────────────────────
    history = {
        "train_loss": [],
        "val_loss": [],
        "val_rmse": [],
        "val_mae": [],
        "lr": [],
    }
    
    best_val_loss = float("inf")
    epochs_no_improve = 0
    best_model_state = None
    
    print(f"\n{'─'*60}")
    print(f"Training started — {epochs} epochs, batch size {batch_size}")
    print(f"{'─'*60}")
    
    start_time = time.time()
    
    for epoch in range(1, epochs + 1):
        # Train
        train_loss = train_one_epoch(model, train_loader, criterion, optimizer, device)
        
        # Validate
        val_loss, val_preds, val_targets = evaluate(model, val_loader, criterion, device)
        val_rmse, val_mae, _ = compute_metrics(val_preds, val_targets)
        
        # Step the scheduler
        scheduler.step(val_loss)
        current_lr = optimizer.param_groups[0]["lr"]
        
        # Log metrics
        history["train_loss"].append(train_loss)
        history["val_loss"].append(val_loss)
        history["val_rmse"].append(val_rmse)
        history["val_mae"].append(val_mae)
        history["lr"].append(current_lr)
        
        # Print progress every 5 epochs (or first/last)
        if epoch % 5 == 0 or epoch == 1 or epoch == epochs:
            print(
                f"  Epoch {epoch:3d}/{epochs} │ "
                f"Train Loss: {train_loss:.4f} │ "
                f"Val Loss: {val_loss:.4f} │ "
                f"RMSE: {val_rmse:.2f} │ "
                f"MAE: {val_mae:.2f} │ "
                f"LR: {current_lr:.6f}"
            )
        
        # ─── Early stopping ──────────────────────────────────────────────
        if val_loss < best_val_loss:
            best_val_loss = val_loss
            epochs_no_improve = 0
            best_model_state = model.state_dict().copy()
        else:
            epochs_no_improve += 1
            if epochs_no_improve >= patience:
                print(f"\n  ! Early stopping at epoch {epoch} (no improvement for {patience} epochs)")
                break
    
    elapsed = time.time() - start_time
    print(f"\n{'─'*60}")
    print(f"Training complete in {elapsed:.1f}s")
    print(f"Best validation loss: {best_val_loss:.4f}")
    print(f"{'─'*60}\n")
    
    # Restore best model weights
    if best_model_state is not None:
        model.load_state_dict(best_model_state)
    
    return history
