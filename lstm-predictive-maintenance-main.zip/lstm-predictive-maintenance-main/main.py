"""
main.py — Entry point for the LSTM Predictive Maintenance pipeline.

This script orchestrates the full workflow:
    1. Download and load the NASA C-MAPSS FD001 dataset
    2. Preprocess data (normalize, compute RUL, create sequences)
    3. Build and train an LSTM model for RUL prediction
    4. Evaluate on the held-out test set
    5. Generate publication-quality visualizations

Usage:
    python main.py

The FD001 subset is used as a baseline because it has a single operating
condition and a single fault mode, making it the simplest starting point.
Once this baseline works well, the approach can be extended to FD002-FD004
which introduce multiple operating conditions and fault modes.

Author: Tomás Nascimento
"""

import os
import sys
import torch
import numpy as np
from sklearn.model_selection import train_test_split

# Add project root to path so we can import from src/
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from src.data_loader import (
    download_dataset,
    load_raw_data,
    preprocess,
    create_sequences,
    create_test_sequences,
)
from src.model import build_model
from src.train import train_model, evaluate, compute_metrics
from src.visualize import (
    plot_training_curves,
    plot_predictions_scatter,
    plot_error_distribution,
    plot_engine_predictions,
    plot_sensor_degradation,
    plot_rul_timeline,
    plot_model_summary,
)


# ─────────────────────────────────────────────────────────────────────────────
# Configuration
# ─────────────────────────────────────────────────────────────────────────────

# Data
DATA_DIR        = "data"
SUBSET          = "FD001"       # Start with the simplest subset
MAX_RUL         = 125           # Piecewise-linear RUL cap (standard in literature)
SEQUENCE_LENGTH = 30            # Input window size (how many cycles the LSTM sees)

# Model architecture
HIDDEN_DIM      = 64            # LSTM hidden state size
NUM_LAYERS      = 2             # Number of stacked LSTM layers
DROPOUT         = 0.3           # Dropout for regularization
FC_DIM          = 32            # Fully connected layer dim

# Training
EPOCHS          = 50            # Maximum training epochs
BATCH_SIZE      = 256           # Mini-batch size
LEARNING_RATE   = 0.001         # Initial learning rate (Adam)
PATIENCE        = 15            # Early stopping patience
VAL_SPLIT       = 0.2           # Fraction of training data used for validation
RANDOM_SEED     = 42            # For reproducibility
LATE_PENALTY_WT = 3.0           # Asymmetric loss: penalize late predictions 3x more
                                # (1.0 = standard MSE, higher = more conservative)

# Output
RESULTS_DIR     = "results"
FIGURES_DIR     = "results/figures"
MODEL_SAVE_PATH = "results/lstm_rul_model.pth"


def get_device():
    """Automatically select the best available device."""
    if torch.cuda.is_available():
        device = torch.device("cuda")
        print(f"Using GPU: {torch.cuda.get_device_name(0)}")
    elif torch.backends.mps.is_available():
        device = torch.device("mps")
        print("Using Apple Silicon (MPS)")
    else:
        device = torch.device("cpu")
        print("Using CPU")
    return device


def main():
    # ─── Setup ────────────────────────────────────────────────────────────
    print("=" * 60)
    print("  LSTM Predictive Maintenance — NASA C-MAPSS")
    print("=" * 60)
    print()
    
    # Reproducibility
    torch.manual_seed(RANDOM_SEED)
    np.random.seed(RANDOM_SEED)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(RANDOM_SEED)
    
    device = get_device()
    os.makedirs(RESULTS_DIR, exist_ok=True)
    os.makedirs(FIGURES_DIR, exist_ok=True)
    
    # ─── Step 1: Download and load data ───────────────────────────────────
    print("\nStep 1: Loading dataset...")
    download_dataset(DATA_DIR)
    train_df, test_df, rul_true = load_raw_data(DATA_DIR, SUBSET)
    
    # ─── Step 2: Preprocess ───────────────────────────────────────────────
    print("\nStep 2: Preprocessing...")
    train_df, test_df, feature_cols = preprocess(train_df, test_df, max_rul=MAX_RUL)
    
    # Plot the RUL timeline and sensor degradation BEFORE creating sequences
    # (these use the full DataFrame, not the windowed sequences)
    print("\nGenerating data exploration plots...")
    plot_rul_timeline(train_df, save_dir=FIGURES_DIR)
    plot_sensor_degradation(train_df, feature_cols, engine_id=1, save_dir=FIGURES_DIR)
    
    # ─── Step 3: Create sequences ─────────────────────────────────────────
    print("\nStep 3: Creating sequences...")
    X, y = create_sequences(train_df, feature_cols, sequence_length=SEQUENCE_LENGTH)
    
    # Split into train/val sets — stratifying by engine isn't necessary here
    # since the sequences are essentially IID after windowing
    X_train, X_val, y_train, y_val = train_test_split(
        X, y, test_size=VAL_SPLIT, random_state=RANDOM_SEED,
    )
    print(f"  Train: {X_train.shape[0]:,} sequences")
    print(f"  Val:   {X_val.shape[0]:,} sequences")
    
    # Test sequences — one per engine, using the last `sequence_length` cycles
    X_test = create_test_sequences(test_df, feature_cols, sequence_length=SEQUENCE_LENGTH)
    y_test = rul_true["RUL"].values.astype(np.float32)
    
    # ─── Step 4: Build model ──────────────────────────────────────────────
    print("\nStep 4: Building model...")
    num_features = len(feature_cols)
    model = build_model(
        input_dim=num_features,
        device=device,
        hidden_dim=HIDDEN_DIM,
        num_layers=NUM_LAYERS,
        dropout=DROPOUT,
        fc_dim=FC_DIM,
    )
    
    # ─── Step 5: Train ────────────────────────────────────────────────────
    print("\nStep 5: Training...")
    history = train_model(
        model, X_train, y_train, X_val, y_val,
        device=device,
        epochs=EPOCHS,
        batch_size=BATCH_SIZE,
        learning_rate=LEARNING_RATE,
        patience=PATIENCE,
        late_penalty_weight=LATE_PENALTY_WT,
    )
    
    # Save the trained model
    torch.save({
        "model_state_dict": model.state_dict(),
        "config": {
            "input_dim": num_features,
            "hidden_dim": HIDDEN_DIM,
            "num_layers": NUM_LAYERS,
            "dropout": DROPOUT,
            "fc_dim": FC_DIM,
            "sequence_length": SEQUENCE_LENGTH,
            "max_rul": MAX_RUL,
            "feature_cols": feature_cols,
        },
        "history": history,
    }, MODEL_SAVE_PATH)
    print(f"  Model saved to: {MODEL_SAVE_PATH}")
    
    # ─── Step 6: Evaluate on test set ─────────────────────────────────────
    print("\nStep 6: Evaluating on test set...")
    
    # Get predictions for each test engine
    model.eval()
    with torch.no_grad():
        X_test_tensor = torch.tensor(X_test, dtype=torch.float32).to(device)
        test_predictions = model(X_test_tensor).squeeze().cpu().numpy()
    
    # Compute metrics
    rmse, mae, score = compute_metrics(test_predictions, y_test)
    
    print(f"\n{'='*60}")
    print(f"  TEST SET RESULTS (FD001)")
    print(f"{'='*60}")
    print(f"  RMSE:           {rmse:.2f} cycles")
    print(f"  MAE:            {mae:.2f} cycles")
    print(f"  PHM08 Score:    {score:.2f}")
    print(f"{'='*60}")
    
    # ─── Step 7: Generate all visualizations ──────────────────────────────
    print("\nStep 7: Generating visualizations...")
    plot_training_curves(history, save_dir=FIGURES_DIR)
    plot_predictions_scatter(test_predictions, y_test, save_dir=FIGURES_DIR)
    plot_error_distribution(test_predictions, y_test, save_dir=FIGURES_DIR)
    plot_engine_predictions(test_predictions, y_test, save_dir=FIGURES_DIR)
    plot_model_summary(test_predictions, y_test, history, save_dir=FIGURES_DIR)
    
    # ─── Summary ──────────────────────────────────────────────────────────
    print(f"\n{'='*60}")
    print(f"  Pipeline complete!")
    print(f"{'='*60}")
    print(f"  Model checkpoint: {MODEL_SAVE_PATH}")
    print(f"  Figures saved to: {FIGURES_DIR}/")
    print(f"  Generated figures:")
    for fname in sorted(os.listdir(FIGURES_DIR)):
        if fname.endswith(".png"):
            print(f"    • {fname}")
    print()
    
    return test_predictions, y_test, history


if __name__ == "__main__":
    main()
