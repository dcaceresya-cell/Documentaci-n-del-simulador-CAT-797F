Glossary
==============

.. glossary::
    :sorted:

    controller
      A closed loop future loading method. Calculates future loading as a function of state, like the :py:class:`progpy.loading.controllers.LQR` controller used by the :py:class:`progpy.models.aircraft_model.SmallRotorcraft` model.

    trajectory
      Path a vehicle takes through space, represented by a set of 4-dimensional points (position + time), represented by the :py:class:`progpy.utils.traj_gen.Trajectory` class.

    event
      Something that can be predicted (e.g., system failure). An event has either occurred or not. See also: :term:`threshold`

    event state
      Progress towards :term:`event` occurring. Defined as a number where an event state of 0 indicates the :term:`event` has occurred and 1 indicates no progress towards the :term:`event` (i.e., fully healthy operation for a failure event). For a gradually occurring :term:`event` (e.g., discharge) the number will progress from 1 to 0 as the :term:`event` nears. In prognostics, event state is frequently called "State of Health".

    input
      Control or loading applied to the system being modeled (e.g., current drawn from a battery). Input is frequently denoted by u.

    output
      Measured sensor values from a system (e.g., voltage and temperature of a battery). Output is frequently denoted by z.

    future load
      :term:`input` (i.e., loading) expected to be applied to a system at future times. In ProgPy, future load is typically provided as a function of time and state, f(time, state) -> load

    performance metric
      Performance characteristics of a system that are a function of system state, but are not directly measured.

    state
      Internal variables (typically hidden states) used to represent the state of the system- can be same as inputs/outputs but do not have to be.  State is frequently denoted as x

    hidden state
      :term:`state` that is not directly measurable

    state estimator
      An algorithm that is used to estimate the :term:`state` of the system, given measurements and a model, defined in the :py:mod:`progpy.state_estimators` subpackage (e.g., :py:class:`progpy.state_estimators.UnscentedKalmanFilter`).

    predictor
      An algorithm that is used to predict future states, given the initial state, a model, and an estimate of :term:`future load`. E.g., :py:class:`progpy.predictors.MonteCarlo`.

    prediction
      A prediction of something (e.g., :term:`input`, :term:`state`, :term:`output`, :term:`event state`, etc.), with uncertainty, at one or more future times, as a result of a :term:`predictor` prediction step (:py:func:`progpy.predictors.Predictor.predict`). For example- a prediction of the future :term:`state` of a system at certain specified savepoints, returned from prediction using a :py:class:`progpy.predictors.MonteCarlo` predictor. 

    surrogate
      A model that approximates the behavior of another model. Often used to generate a faster version of a model (e.g., for resource-constrained applications or to be used in optimization) or to test a data model. Generated using :py:func:`progpy.PrognosticsModel.generate_surrogate` method.

    model
      A subclass of :py:class:`progpy.PrognosticsModel` the describes the behavior of a system. Models are typically physics-based, data-driven (i.e., subclasses of :py:class:`progpy.data_models.DataModel`), or some hybrid approach (e.g., physics informed machine learning).

    threshold
      The conditions under which an :term:`event` is considered to have occurred.

    prognostics
      Prediction of (a) future performance and/or (b) the time at which one or more events of interest occur, for a system or a system of systems

    data-driven model
      A model where the behavior is learned from data. In ProgPy, data-driven models derive from the parent class :py:class:`progpy.data_models.DataModel`. A common example of data-driven models is models using neural networks (e.g., :py:class:`progpy.data_models.LSTMStateTransitionModel`).

    physics-based model
      A model where behavior is described by the physics of the system. Physics-based models are typically :term:`parameterized<parameters>`, so that exact behavior of the system can be configured or learned (through parameter estimation).

    parameters
      Parameters describe a system. They are used to specialize a generic model to the specific system of interest.

    process noise
      Noise applied in the state transition method. Process noise is used to represent uncertainty in the state transition process (e.g., uncertainty in the quality of your model or your model configuration :term:`parameters`, environmental effects)

    measurement noise
      Noise applied in the output method. Measurement noise is used to represent uncertainty in your measurements. This can represent such things as uncertainty in the logic of the model's output method or sensor noise. 

    future loading noise
      Noise applied in the user provided :term:`future load` function. This is used to represent uncertainty in how the system is loaded in the future. 
      
    state estimation
      State estimation is the process from which the internal model :term:`state` (x) is estimated using :term:`input` (i.e., loading) and :term:`output` (i.e., sensor data). State estimation is necessary for cases where model state isn't directly measurable (i.e., `hidden state`) or where there is sensor noise. Most state estimators estimate the state with some representation of uncertainty. An algorithm that performs state estimation is called a :term:`state estimator` and is included in the progpy.state_estimators package

    time of event
      The time at which an :term:`event` is predicted to occur (i.e., when :term:`threshold` is reached). Sometimes abbreviated as ToE. When the event of interest is failure, this is frequently referred to as End of Life (EOL).

    time to event
      The time remaining until :term:`time of event`. Sometimes abbreviated as TtE. When the :term:`event` of interest is failure, this is frequently referred to as Remaining Useful Life (RUL). :math:`TtE = ToE - t` where :math:`t` is the current time. Sometimes abbreviated as TtE.

    time of prediction
      The time at which a prediction is performed. Sometimes abbreviated as ToP or :math:`t_p`.

    time of measurement
      The time at which the last measurement was performed that was used for state estimation. Sometimes abbreviated as ToM or :math:`t_m`.

    direct-prediction model
      A model where the :term:`time of event` is directly estimated from the current state and/or :term:`future load`, instead of predicted through simulation to threshold. These are implemented using the :py:meth:`progpy.PrognosticsModel.time_to_event` method.

    state-transition model
      A model where the :term:`time of event` is predicted through simulation to threshold. Most prognostic models are state-transition models.

    composite model
      A model consisting of multiple inter-related Prognostics Models, where the :term:`input` of one :term:`model` is a function of the :term:`output` or :term:`state` of another. This is a tool for representing system-of-systems. Composite models are implemented using the :py:class:`progpy.CompositeModel` class.

    system-of-systems
      A system consisting of multiple inter-related systems, where one system affects the others. In ProgPy, system-of-systems are reporsented using :term:`composite models <composite model>`. Composite models are implemented using the :py:class:`progpy.CompositeModel` class.

    discrete state
      A system state representation that can only occupy one of a finite set of predefined values. Transitions between discrete states occur based on defined logic or triggering events. Discrete states are initialized using the function :py:func:`progpy.create_discrete_state`.

    continuous state
      A system state representation that can vary smoothly over a continuous range of values. Discrete states are initialized using a floating point number.

    discrete model
      A model where state transition is discrete. Discrete models define the `next_state` equation for state transition.

    continuous model
      A model where state transition is continuous. Discrete models define the `dx` equation for state transition.
