Prognostics Model
====================