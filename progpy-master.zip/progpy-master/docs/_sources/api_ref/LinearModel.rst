Linear Model
=================