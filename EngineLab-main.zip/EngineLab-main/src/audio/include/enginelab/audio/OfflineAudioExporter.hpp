#pragma once

#include <enginelab/calibration/CalibrationStore.hpp>
#include <enginelab/foundation/EngineTypes.hpp>

#include <cstdint>
#include <filesystem>
#include <functional>
#include <memory>
#include <optional>
#include <string>
#include <string_view>
#include <vector>

namespace enginelab {

/** File encodings supported by the deterministic offline renderer. */
enum class OfflineWaveFormat {
    pcm24,
    float32
};

/** One control segment in an offline render scenario.
 *
 * Throttle, load and target speed are linearly interpolated over the segment.
 * When `governed` is true, the load fields are ignored and a deterministic
 * absorber controller follows targetRpmStart/targetRpmEnd.
 */
struct OfflineAudioStage final {
    std::string name { "stage" };
    double durationSeconds { 1.0 };
    bool ignitionEnabled { true };
    bool starterEngaged { false };
    bool governed { true };
    double throttleStart { 0.2 };
    double throttleEnd { 0.2 };
    double loadStart { 0.0 };
    double loadEnd { 0.0 };
    double targetRpmStart { 1'200.0 };
    double targetRpmEnd { 1'200.0 };
};

/** Ordered, machine-readable drive cycle for repeatable sound exports. */
struct OfflineAudioScenario final {
    std::string name { "showcase" };
    std::vector<OfflineAudioStage> stages;
};

/** The same listening-chain controls as the realtime application. */
using OfflineAudioMix = AudioVoicingConfig;

struct OfflineAudioExportRequest final {
    EngineConfig engine;
    /** The ECU tables the render runs, as a running engine's store holds
     *  them; absent, the tables the configuration implies. An Audio workshop
     *  export ran the default tables and lost the live tuning (audit UA-01). */
    std::shared_ptr<const calibration::CalibrationSnapshot> calibration;
    OfflineAudioScenario scenario;
    OfflineAudioMix mix;
    std::filesystem::path outputDirectory;
    /** Root used to resolve engine-authored relative impulse-response paths. */
    std::filesystem::path assetRoot;
    std::uint32_t sampleRateHz { 96'000 };
    OfflineWaveFormat format { OfflineWaveFormat::pcm24 };
    bool writeStems { true };
    bool loadAuthoredImpulseResponses { true };
    bool overwriteExistingFiles { false };
    /** Exhaust finite-volume cell length (m) for a measurement against a
     *  published pipe; absent keeps the production mesh the application runs
     *  (EngineSimulator::productionExhaustCellLengthM). */
    std::optional<double> exhaustCellLengthM;
    /** Diagnostic: the audio exhaust network's own pressure, Pa, at
     *  `axialFraction` of authored component `componentId`, written every
     *  synthesis sample to exhaust_tap_pa.f32 (raw little-endian float32 at
     *  the render rate). Nothing else in the render changes. */
    struct ExhaustPressureTap final {
        std::uint32_t componentId {};
        double axialFraction {};
    };
    std::optional<ExhaustPressureTap> exhaustPressureTap;
    /** Diagnostic: the outlets' mean-flow reflection factor on or off
     *  (RealtimeEngineAudio::setOutletConvectiveLoss); absent keeps the
     *  renderer's default. */
    std::optional<bool> outletConvectiveLoss;
    /** The far field's low band from the gas solver's mouth flow below this
     *  crossover, Hz, 0 off (RealtimeEngineAudio::setOutletSolverLowBand);
     *  absent keeps the renderer's default. */
    std::optional<double> outletSolverLowBandHz;
};

/** Speed actually reached inside one scenario stage.
 *
 * A scenario declares a *requested* trajectory; the engine answers it. Nothing
 * used to publish the answer, so an "idle" stage could hold twice the engine's
 * real idle and the render still looked correct. Judging the speed from the
 * rendered audio does not substitute for this: the firing fundamental of a big
 * twin at idle is near 13 Hz, and a harmonic-product estimate picks the wrong
 * octave there. These are simulator telemetry, not an audio estimate.
 */
struct OfflineAudioStageSpeed final {
    std::string name;
    double requestedRpmStart { 0.0 };
    double requestedRpmEnd { 0.0 };
    double meanRpm { 0.0 };
    double minimumRpm { 0.0 };
    double maximumRpm { 0.0 };
    /** Mean over the last quarter of the stage: what the stage settled to. */
    double settledRpm { 0.0 };
    bool governed { false };
};

/** Auditable result returned by the shared CLI/application export path. */
struct OfflineAudioExportResult final {
    bool success { false };
    bool cancelled { false };
    std::string error;
    std::vector<std::string> warnings;
    std::vector<std::filesystem::path> files;
    std::uint64_t renderedFrames { 0 };
    double durationSeconds { 0.0 };
    double masterPeak { 0.0 };
    double masterRms { 0.0 };
    /** Float-domain algebraic checks, before WAV quantisation. */
    double stemPremasterMaxError { 0.0 };
    double masterReconstructionMaxError { 0.0 };
    /** pressure-wave + outlet-jet diagnostic stems versus exhaust_dry. */
    double exhaustDiagnosticDecompositionMaxError { 0.0 };
    std::size_t loadedImpulseResponses { 0 };
    std::size_t authoredImpulseResponses { 0 };
    bool physicalExhaustActive { false };
    bool compiledExhaustTopologyActive { false };
    bool compiledIntakeTopologyActive { false };
    bool forcedInductionAcousticsActive { false };
    std::uint64_t delayTruncationCount { 0 };
    std::uint64_t invalidBoundarySampleCount { 0 };
    std::uint64_t legacyPathSampleCount { 0 };
    std::uint64_t saturationProcessedSampleCount { 0 };
    std::uint64_t automaticGainControlledSampleCount { 0 };
    std::uint64_t softLimitedSampleCount { 0 };
    std::uint64_t hardClampedSampleCount { 0 };
    std::uint64_t droppedReactionEvents { 0 };
    /** Maximum host-rate sample magnitude after limiter/downsampling. */
    double maximumPostLimiterSampleMagnitude { 0.0 };
    std::uint64_t droppedFiringEvents { 0 };
    std::uint64_t droppedPressureSamples { 0 };
    std::uint64_t droppedExhaustAcousticSamples { 0 };
    /** Measured physical-audio activity over the complete rendered scenario. */
    double afterfirePeakHeatReleaseKw { 0.0 };
    double afterfireFuelBurnedMg { 0.0 };
    std::uint64_t overrunAfterfireActiveFrames { 0 };
    double cycleMultiplierMinimum { 1.0 };
    double cycleMultiplierMaximum { 1.0 };
    std::uint64_t cycleVariationSamples { 0 };
    std::size_t porousMufflerCount { 0 };
    std::vector<OfflineAudioStageSpeed> stageSpeeds;
};

/** Return the engine-relative crank/idle/rev/limiter/overrun showcase. */
[[nodiscard]] OfflineAudioScenario makeDefaultOfflineAudioScenario(
    const EngineConfig& engine);

/** Parse and strictly validate a schema-version 1 scenario JSON file. */
[[nodiscard]] bool loadOfflineAudioScenario(
    const std::filesystem::path& file,
    OfflineAudioScenario& destination,
    std::string& error);

/** Serialize a scenario in the public schema used by the CLI and manifest. */
[[nodiscard]] bool saveOfflineAudioScenario(
    const std::filesystem::path& file,
    const OfflineAudioScenario& scenario,
    std::string& error);

/** Run the shipping simulation/audio path faster than wall clock and stream WAVs.
 *
 * The callback is invoked outside the audio render loop at a bounded cadence.
 * Returning false cancels the job and removes only the partial files created by
 * that invocation.
 */
using OfflineAudioProgress =
    std::function<bool(double fraction, std::string_view stageName)>;

[[nodiscard]] OfflineAudioExportResult exportOfflineAudio(
    const OfflineAudioExportRequest& request,
    const OfflineAudioProgress& progress = {});

[[nodiscard]] const char* offlineWaveFormatName(
    OfflineWaveFormat format) noexcept;

} // namespace enginelab
