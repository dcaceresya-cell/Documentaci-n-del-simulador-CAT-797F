#pragma once
#include <enginelab/audio/AcousticExhaustNetwork.hpp>
#include <enginelab/audio/AcousticIntakeNetwork.hpp>
#include <enginelab/audio/ForcedInductionAcoustics.hpp>
#include <enginelab/audio/IAudioRenderer.hpp>
#include <enginelab/audio/IntegerUpsampler.hpp>
#include <enginelab/audio/PassByMicrophone.hpp>
#include <enginelab/audio/PipeRadiationModel.hpp>
#include <enginelab/audio/BoundaryReconstructionFilter.hpp>
#include <enginelab/audio/DuctWallLoss.hpp>
#include <enginelab/audio/ExpansionChamberMuffler.hpp>
#include <enginelab/audio/RealtimeConvolutionBank.hpp>
#include <enginelab/audio/StructuralModalRadiator.hpp>
#include <enginelab/audio/ReactionCrackSynthesiser.hpp>
#include <enginelab/audio/ThermoacousticHeatReleaseSource.hpp>
#include <enginelab/audio/ValveFlowAcousticSource.hpp>
#include <enginelab/audio/ValveTurbulenceNoise.hpp>
#include <enginelab/audio/ValvePortTermination.hpp>
#include <enginelab/foundation/AcousticSourcePlacement.hpp>
#include <enginelab/runtime/EngineRuntime.hpp>
#include <algorithm>
#include <array>
#include <atomic>
#include <cstdint>
#include <memory>
#include <optional>
#include <span>
#include <vector>
namespace enginelab {
/** Optional pre-master source buses for offline diagnosis.
 *
 * Every non-null buffer must be distinct from the master output and provide
 * the requested sample range. The renderer clears and fills channels 0/1 only.
 * These taps sit before the shared monitor tone/DC/reconstruction filters,
 * volume, safety leveler and limiter. `exhaustDry` is the source-side tailpipe
 * bus; `exhaustIr` is the downstream measured-IR return, kept separate so the
 * source and listening environment are never confused.
 *
 * Enabling taps observes the existing render; it does not route the master
 * through the stem buffers or alter any source state.
 *
 * `exhaustPressureWave` and `exhaustJet` are diagnostic sub-stems: together
 * they reconstruct `exhaustDry`, but they are not additional mix buses and
 * must not be added to the premaster a second time.
 */
struct RealtimeAudioStemBuffers final {
    juce::AudioBuffer<float>* combustion { nullptr };
    juce::AudioBuffer<float>* exhaustDry { nullptr };
    juce::AudioBuffer<float>* exhaustIr { nullptr };
    juce::AudioBuffer<float>* intake { nullptr };
    juce::AudioBuffer<float>* forcedInduction { nullptr };
    juce::AudioBuffer<float>* mechanical { nullptr };
    juce::AudioBuffer<float>* exhaustPressureWave { nullptr };
    juce::AudioBuffer<float>* exhaustJet { nullptr };
};

/** Allocation-free engine renderer with an SI-unit thermoacoustic exhaust path.
 *
 * When CylinderPressureSample publishes a valid thermoacoustic boundary, the
 * exhaust is a passive characteristic network terminated by a radiation load.
 * The historical procedural exhaust remains available only for old producers
 * that never publish that boundary; the two paths are never mixed.
 */
class RealtimeEngineAudio final : public IAudioRenderer {
public:
    /** Every telemetry source is explicit so a production-equivalent harness
     *  cannot silently omit the sparse thermoacoustic stream. Pass nullptr
     *  deliberately only for a unit test of a reduced path. */
    RealtimeEngineAudio(FiringEventQueue& queue, RealtimeAudioState& state,
                        CylinderPressureQueue* pressureQueue,
                        const ExhaustGraph* exhaustGraph,
                        const EngineConfig* engineConfig,
                        ExhaustAcousticQueue* exhaustAcousticQueue);
    ~RealtimeEngineAudio() override;
    void prepare(double sampleRate, int maximumBlockSize) noexcept override;
    void release() noexcept override;
    /**
     * Synthesise at the lowest whole fraction of the device rate that is still
     * at least `hz`, and upsample to the device (IntegerUpsampler): a 192 kHz
     * device then costs a 48 kHz one, not four times as much, and sounds as the
     * engines were voiced. 0 (the default) synthesises at the device rate.
     * Read by the next prepare(). Above that fraction, renderWithStems()
     * observes no stems.
     */
    void setReferenceSynthesisRate(double hz) noexcept { referenceSynthesisRateHz_ = hz; }
    /** The rate the engines are voiced and checked at. */
    static constexpr double voicedSampleRateHz = 48'000.0;
    [[nodiscard]] double synthesisSampleRate() const noexcept { return sampleRate_; }
    [[nodiscard]] int upsamplingFactor() const noexcept { return upsamplingFactor_; }
    /**
     * Change the compiled exhaust to one built from `graph` while the engine
     * plays: the same components resized (a live exhaust change). The new
     * network is fed the same sources as the playing one for
     * `exhaustSwapWarmupSeconds` so its pipes fill, then the output fades
     * linearly to it over `exhaustSwapFadeSeconds`; both are measured in
     * RealtimeRegressionTests. A change sent while another is in progress
     * waits for it, and a newer one replaces a change still waiting.
     *
     * Message thread, after prepare(). Returns false, changing nothing, when
     * no compiled exhaust plays or `graph` does not compile. Call
     * collectRetiredExhaustNetworks() now and then from the same thread: it
     * frees the networks the audio thread has finished with.
     */
    bool replaceExhaustGraph(const ExhaustGraph& graph);
    /** Frees what the audio thread has finished with: exhaust networks and
     * forced-induction settings. */
    void collectRetiredExhaustNetworks() noexcept;
    /**
     * Give the playing turbocharger or supercharger new sizes, areas and
     * efficiencies (a live settings change): the audio thread takes them at
     * its next block. Message thread. True when the sound now follows
     * `config`, or when neither the old nor the new settings make a sound.
     * False, changing nothing, when `config` is another machine
     * (ForcedInductionAcoustics::sameMachine) or would start or stop the
     * sound: that needs a new renderer.
     */
    bool replaceForcedInduction(const ForcedInductionConfig& config);
    /**
     * Swap the playing intake network for one compiled from `config`'s intake
     * (a live intake change), the way replaceExhaustGraph() swaps the
     * exhaust: the incoming network hears the same sources silently for
     * `exhaustSwapWarmupSeconds`, then the output fades to it over
     * `exhaustSwapFadeSeconds`. Message thread, after prepare(). True, with
     * nothing to swap, when neither the playing engine nor `config` has a
     * compiled intake. False, changing nothing, when only one of them has, or
     * the network does not compile: that needs a new renderer.
     */
    bool replaceIntake(const EngineConfig& config);
    /** Live intake changes the audio thread has completed. */
    [[nodiscard]] std::uint64_t intakeSwapCount() const noexcept {
        return intakeSwaps_.load(std::memory_order_acquire);
    }
    /** Forced-induction settings the audio thread has taken. */
    [[nodiscard]] std::uint64_t forcedInductionUpdateCount() const noexcept {
        return forcedInductionUpdates_.load(std::memory_order_acquire);
    }
    /** Live exhaust changes the audio thread has completed. */
    [[nodiscard]] std::uint64_t exhaustSwapCount() const noexcept {
        return exhaustSwaps_.load(std::memory_order_acquire);
    }
    // Measured on the CP2 swapping in its own exhaust: 60 ms leaves the
    // difference 33 dB below the engine, 150 ms 74 dB.
    static constexpr double exhaustSwapWarmupSeconds = 0.150;
    static constexpr double exhaustSwapFadeSeconds = 0.030;
    /**
     * Puts the listener's two microphones at `positions` (metres, in the
     * acoustic frame of AcousticObserverConfig, used as given: no
     * listening-distance scale), or back where the engine's observer put them
     * when empty. Every spatialised layer glides there
     * (FreeFieldObserver::moveMicrophones): each exhaust outlet and intake
     * inlet from its own position, the turbo and the structure by the
     * microphones' mean distance from the engine. Other layers do not move.
     * One thread at a time; lock-free; the audio thread takes the newest
     * positions at its next block.
     */
    void setMicrophones(const std::optional<std::array<AcousticPoint3M, 2>>& positions) noexcept;
    /**
     * The trackside microphone (PassByMicrophone, off by default): the
     * master, as the engine's own observer hears it, is heard 7.5 m off a
     * lane the car drives along at its speed (RealtimeAudioState::
     * vehicleSpeedMps), from 150 m before the microphone to 150 m past it,
     * again and again, starting in front of it. It cross-fades in and out;
     * off, the master is untouched. Any thread; the audio thread takes it at
     * its next block. The camera's microphones should be off meanwhile
     * (setMicrophones with none): the pass-by places its own.
     */
    void setPassByEnabled(bool enabled) noexcept { passByRequested_.store(enabled, std::memory_order_relaxed); }
    [[nodiscard]] bool passByEnabled() const noexcept { return passByRequested_.load(std::memory_order_relaxed); }
    /** The trackside microphone's place and ground, and whether its level is
     *  the real one or held at the lane's distance (PassByMicrophone::
     *  setGeometry). While a pass-by run is published (RealtimeAudioState::
     *  passByPhase) the microphone is on and follows the run's car. Any
     *  thread; the audio thread takes it at its next block. */
    void setPassByGeometry(double laneDistanceM, double microphoneHeightM, PassByGround ground,
                           bool normalisedLevel) noexcept {
        passByLaneM_.store(laneDistanceM, std::memory_order_relaxed);
        passByMicrophoneHeightM_.store(microphoneHeightM, std::memory_order_relaxed);
        passByGround_.store(static_cast<int>(ground), std::memory_order_relaxed);
        passByNormalised_.store(normalisedLevel, std::memory_order_relaxed);
    }
    /** Where the car is along the lane (m, 0 in front of the microphone). */
    [[nodiscard]] double passByPositionM() const noexcept { return passByPositionM_.load(std::memory_order_relaxed); }
    /**
     * Where the drawn engine puts its openings and its turbo
     * (render::ListenerFrame::sources). While the microphones are moved
     * (setMicrophones), each exhaust outlet and intake mouth radiates from its
     * placement (AcousticExhaustNetwork::placeOutlets,
     * AcousticIntakeNetwork::placeMouths) and the turbo is heard at the
     * microphones' mean distance from its own; switched off, every source is
     * back where the engine authored it. Message thread, the same one as
     * collectRetiredExhaustNetworks(), which frees the replaced placements.
     */
    void setSoundSources(const AcousticSourcePlacements& sources);
    void render(juce::AudioBuffer<float>& output, int startSample, int sampleCount) noexcept override;
    /** Render the identical master while observing optional pre-master stems. */
    void renderWithStems(juce::AudioBuffer<float>& output, int startSample,
                         int sampleCount, const RealtimeAudioStemBuffers& stems) noexcept;
    void setImpulseResponse(std::span<const float> samples,
                            double sourceSampleRate = 48'000.0,
                            std::size_t pathIndex = 0);
    void setImpulseResponse(juce::AudioBuffer<float>&& samples,
                            double sourceSampleRate,
                            std::size_t pathIndex);
    [[nodiscard]] std::uint64_t lateEventCount() const noexcept { return lateEvents_.load(std::memory_order_relaxed); }
    [[nodiscard]] std::uint64_t stolenVoiceCount() const noexcept { return stolenVoices_.load(std::memory_order_relaxed); }
    [[nodiscard]] std::uint64_t droppedPendingEventCount() const noexcept { return droppedPendingEvents_.load(std::memory_order_relaxed); }
    /** Times a requested delay exceeded its allocated line and was clamped.
     *
     * Lines are sized in prepare() from the delays the runtime published, so a
     * non-zero count means a delay grew afterwards and the acoustic geometry is
     * silently shorter than configured. Non-zero is a defect, not a warning.
     */
    [[nodiscard]] std::uint64_t delayTruncationCount() const noexcept { return delayTruncations_.load(std::memory_order_relaxed); }
    [[nodiscard]] double eventLatencySeconds() const noexcept { return eventLatencySeconds_; }
    [[nodiscard]] std::uint64_t largeForwardClockDriftCount() const noexcept {
        return largeForwardClockDrifts_.load(std::memory_order_relaxed);
    }
    [[nodiscard]] double maximumForwardClockDriftSeconds() const noexcept {
        return maximumForwardClockDriftSeconds_.load(std::memory_order_relaxed);
    }
    // Read-only output-chain observers. The counters deliberately keep authored
    // voicing saturation, slow safety AGC, oversampled soft limiting and the
    // last-resort sample clamp separate. These loads do not affect the audio path.
    [[nodiscard]] std::uint64_t levelLimitedSampleCount() const noexcept { return levelLimitedSamples_.load(std::memory_order_relaxed); }
    [[nodiscard]] std::uint64_t saturationProcessedSampleCount() const noexcept {
        return saturationProcessedSamples_.load(std::memory_order_relaxed);
    }
    [[nodiscard]] std::uint64_t softLimitedSampleCount() const noexcept {
        return softLimitedSamples_.load(std::memory_order_relaxed);
    }
    [[nodiscard]] std::uint64_t hardClampedSampleCount() const noexcept {
        return hardClampedSamples_.load(std::memory_order_relaxed);
    }
    [[nodiscard]] std::uint64_t droppedReactionEventCount() const noexcept {
        return droppedReactionEvents_.load(std::memory_order_relaxed);
    }
    [[nodiscard]] std::uint64_t reactionPressureLimitedSampleCount() const noexcept {
        return reactionPressureLimitedSamples_.load(std::memory_order_relaxed);
    }
    /** Maximum post-limiter sample magnitude at the host rate.
     *
     * This is deliberately not called a true peak: no standards-grade
     * inter-sample reconstruction meter is run in the realtime callback. */
    [[nodiscard]] float maximumPostLimiterSampleMagnitude() const noexcept {
        return maximumPostLimiterSampleMagnitude_.load(std::memory_order_relaxed);
    }
    [[nodiscard]] float minObservedLevelGain() const noexcept { return minObservedLevelGain_.load(std::memory_order_relaxed); }
    /** Whether the physical thermoacoustic path has taken ownership of the voice.
     *
     * False means every rendered sample is coming from the legacy procedural
     * exhaust instead. That is a silent downgrade in audible quality, so it must
     * be observable rather than inferred: a caller that cannot distinguish the
     * two paths cannot tell a physical-path improvement from a physical path
     * that never activated. */
    [[nodiscard]] bool physicalExhaustActive() const noexcept {
        return physicalExhaustActive_.load(std::memory_order_relaxed);
    }
    /** True only when the complete ExhaustGraph, rather than the compatibility
     * runner/path reduction, was compiled successfully. */
    [[nodiscard]] bool compiledExhaustTopologyActive() const noexcept {
        return acousticExhaustNetwork_ != nullptr;
    }
    /** Diagnostic A/B switch for the semi-empirical outlet turbulence layer. */
    void setOutletJetNoiseEnabled(bool enabled) noexcept {
        outletJetNoiseEnabled_ = enabled;
        if (acousticExhaustNetwork_)
            acousticExhaustNetwork_->setOutletJetNoiseEnabled(enabled);
    }
    /** Silencer flow noise (AcousticExhaustNetwork::setMufflerFlowNoiseEnabled),
     * off by default. */
    void setMufflerFlowNoiseEnabled(bool enabled) noexcept {
        mufflerFlowNoiseEnabled_ = enabled;
        if (acousticExhaustNetwork_)
            acousticExhaustNetwork_->setMufflerFlowNoiseEnabled(enabled);
    }
    /** Density of the air the exhaust outlets radiate into. Negative (the
     * default, production): ambient air, from the live ambient pressure and
     * temperature, refreshed every block. Zero: the duct medium, the model
     * before 2026-10-13. Positive: that density. A diagnostic override; not
     * thread-safe against a running audio callback, so set it before
     * prepare(), as the harnesses do. */
    void setOutletFarFieldDensity(double densityKgPerM3) noexcept {
        outletFarFieldDensityOverrideKgPerM3_ = densityKgPerM3;
    }
    /** Ambient air density from the realtime ambient conditions (ideal gas,
     * dry air). */
    [[nodiscard]] double ambientAirDensityKgPerM3() const noexcept;
    /** Diagnostic: ideal pressure-release outlets instead of the
     * Levine-Schwinger load. Same threading rule as above. */
    void setOutletPressureRelease(bool enabled) noexcept {
        outletPressureRelease_ = enabled;
        if (acousticExhaustNetwork_)
            acousticExhaustNetwork_->setOutletPressureRelease(enabled);
    }
    /** Diagnostic: true restores the outlets' refuted mean-flow reflection
     * factor (AcousticExhaustNetwork::setOutletConvectiveLoss). Same
     * threading rule. */
    void setOutletConvectiveLoss(bool enabled) noexcept {
        outletConvectiveLoss_ = enabled;
        if (acousticExhaustNetwork_)
            acousticExhaustNetwork_->setOutletConvectiveLoss(enabled);
    }
    /** The low band of every outlet's far field from the gas solver's mouth
     * flow below `crossoverHz`, 0 off (AcousticExhaustNetwork::
     * setOutletSolverLowBand). Same threading rule. */
    void setOutletSolverLowBand(double crossoverHz) noexcept {
        outletSolverLowBandHz_ = crossoverHz;
        if (acousticExhaustNetwork_)
            acousticExhaustNetwork_->setOutletSolverLowBand(crossoverHz);
    }
    /** Diagnostic: every sample the compiled exhaust network runs, append its
     * pressure at `axialFraction` of graph node `nodeId` to a recording of
     * at most `capacitySamples` (AcousticExhaustNetwork::setPressureTap).
     * Allocates: call after prepare(), never against a running callback.
     * False without a compiled network or a duct for that node. */
    bool setExhaustPressureTap(std::uint32_t nodeId, float axialFraction,
                               std::size_t capacitySamples) {
        exhaustTapRecording_.clear();
        exhaustTapRecording_.reserve(capacitySamples);
        exhaustTapCapacity_ = capacitySamples;
        return acousticExhaustNetwork_
            && acousticExhaustNetwork_->setPressureTap(nodeId, axialFraction);
    }
    [[nodiscard]] const std::vector<float>& exhaustTapRecording() const noexcept {
        return exhaustTapRecording_;
    }
    /** Turbulent fluctuation of each exhaust valve's effective area
     * (ValveTurbulenceNoise), off by default. Same threading rule as above. */
    void setValveTurbulenceNoiseEnabled(bool enabled) noexcept {
        valveTurbulenceNoiseEnabled_ = enabled;
    }
    [[nodiscard]] bool outletJetNoiseEnabled() const noexcept {
        return acousticExhaustNetwork_
            && acousticExhaustNetwork_->outletJetNoiseEnabled();
    }
    [[nodiscard]] bool structuralRadiationActive() const noexcept {
        return structuralModalRadiator_ != nullptr;
    }
    /** Diagnostic A/B switch for the corrected structural bank coordinate. */
    void setStructuralBankTopologyParticipationEnabled(bool enabled) noexcept {
        if (structuralModalRadiator_)
            structuralModalRadiator_
                ->setBankTopologyParticipationEnabled(enabled);
    }
    [[nodiscard]] bool structuralBankTopologyParticipationEnabled()
        const noexcept {
        return structuralModalRadiator_
            && structuralModalRadiator_
                ->bankTopologyParticipationEnabled();
    }
    /** Diagnostic A/B switch for the generic reaction crack band
     *  (ReactionCrackSynthesiser). The physical low band is unaffected. */
    void setReactionCrackEnabled(bool enabled) noexcept {
        reactionCrackEnabled_.store(enabled, std::memory_order_relaxed);
    }
    [[nodiscard]] bool reactionCrackEnabled() const noexcept {
        return reactionCrackEnabled_.load(std::memory_order_relaxed);
    }
    [[nodiscard]] bool compiledIntakeTopologyActive() const noexcept {
        return acousticIntakeNetwork_ != nullptr;
    }
    [[nodiscard]] bool forcedInductionAcousticsActive() const noexcept {
        return forcedInductionAcoustics_ != nullptr;
    }
    /** Diagnostic A/B switch for broadband FI power conservation. */
    void setForcedInductionBroadbandPowerNormalisationEnabled(
        bool enabled) noexcept {
        if (forcedInductionAcoustics_)
            forcedInductionAcoustics_
                ->setBroadbandPowerNormalisationEnabled(enabled);
    }
    [[nodiscard]] bool forcedInductionBroadbandPowerNormalisationEnabled()
        const noexcept {
        return forcedInductionAcoustics_
            && forcedInductionAcoustics_
                ->broadbandPowerNormalisationEnabled();
    }
    /** Samples rendered on the legacy procedural path.
     *
     * Non-zero after start-up means the physical boundary was unavailable or
     * rejected and the renderer fell back. Start-up itself contributes a bounded
     * number before the first valid telemetry arrives. */
    [[nodiscard]] std::uint64_t legacyPathSampleCount() const noexcept {
        return legacyPathSamples_.load(std::memory_order_relaxed);
    }
    /** Telemetry samples whose thermoacoustic boundary was published invalid. */
    [[nodiscard]] std::uint64_t invalidBoundarySampleCount() const noexcept {
        return invalidBoundarySamples_.load(std::memory_order_relaxed);
    }
    /** Peak SI pressure delivered by the free-field exhaust observer. */
    [[nodiscard]] float maxObservedExhaustPressurePa() const noexcept {
        return maxObservedExhaustPressurePa_.load(std::memory_order_relaxed);
    }
    [[nodiscard]] float maxObservedExhaustJetNoisePressurePa() const noexcept {
        return maxObservedExhaustJetNoisePressurePa_.load(
            std::memory_order_relaxed);
    }
    /** Peak outgoing characteristic injected at any exhaust valve. */
    [[nodiscard]] float maxThermoacousticValveSourcePressurePa() const noexcept {
        return maxThermoacousticValveSourcePressurePa_.load(
            std::memory_order_relaxed);
    }
    /** Peak observer pressure with the semi-empirical outlet jet removed. */
    [[nodiscard]] float maxObservedExhaustPressureWavePa() const noexcept {
        return maxObservedExhaustPressureWavePa_.load(
            std::memory_order_relaxed);
    }
    [[nodiscard]] float maxObservedIntakePressurePa() const noexcept {
        return maxObservedIntakePressurePa_.load(std::memory_order_relaxed);
    }
    [[nodiscard]] AcousticIntakeNetwork::Diagnostics
    intakeNetworkDiagnostics() const noexcept {
        return {
            maxIntakeSourcePressurePa_.load(std::memory_order_relaxed),
            maxIntakeRunnerPressurePa_.load(std::memory_order_relaxed),
            maxIntakePlenumPressurePa_.load(std::memory_order_relaxed),
            maxIntakeAirboxPressurePa_.load(std::memory_order_relaxed),
            maxIntakeMouthPressurePa_.load(std::memory_order_relaxed),
            maxIntakeRadiatedPressurePa_.load(std::memory_order_relaxed)
        };
    }
    [[nodiscard]] float maxObservedStructuralPressurePa() const noexcept {
        return maxObservedStructuralPressurePa_.load(std::memory_order_relaxed);
    }
    [[nodiscard]] float maxObservedForcedInductionPressurePa() const noexcept {
        return maxObservedForcedInductionPressurePa_.load(
            std::memory_order_relaxed);
    }
    [[nodiscard]] float maxPreLimiterMagnitude() const noexcept {
        return maxPreLimiterMagnitude_.load(std::memory_order_relaxed);
    }
    /** Sample-rate invariant quantisation used by the physical runner lines. */
    [[nodiscard]] static std::size_t runnerDelaySamples(double delaySeconds,
                                                        double sampleRate) noexcept;
    /** Resolve physical source cadence without confusing a wall-clock producer
     * stall for a change in solver bandwidth. */
    [[nodiscard]] static double pressureSourceSamplingFrequencyHz(
        const CylinderPressureSample&, double timestampIntervalSeconds) noexcept;
private:
    struct Voice {
        double bodyPhase {}, crackPhase {}, pipePhase {}, knockPhase {};
        float amplitude {}, decay {}, ageSeconds {}, attackSeconds {}, blowdownSeconds {};
        float bodyFrequency {}, crackFrequency {}, pipeFrequency {}, knockFrequency {};
        float leftGain {}, rightGain {}, filterState {}, turbulence {}, knock {};
        float combustionSharpness {};
        float massFlow {}, runnerPressure {}, jetBandState {}, jetLowState {}, jetHighState {};
        std::uint32_t exhaustPathIndex {};
        bool exhaust {};
        bool compressionIgnition {};
        bool active {};
    };
    struct PendingEvent { FiringEvent event {}; double scheduledTimeSeconds {}; bool exhaust {}; };
    // Compile-time upper bounds. These size only small per-block scratch arrays
    // and the published-telemetry views; the delay lines below are sized at
    // prepare() from the engine actually loaded.
    static constexpr std::size_t maximumPaths = RealtimeConvolutionBank::maximumPaths;
    static constexpr std::size_t maxRunners = 32;

    // Every physical delay is stretched at render time by
    //   acousticDelayScale = referenceSoundSpeed / exhaustSoundSpeed / timeScale
    // whose render-time clamps bound it at 900 / 289.8 / 0.25 = 12.42: a cold
    // exhaust auditioned at quarter speed. Lines are sized for this worst case,
    // so temperature and time-scale changes never reach the clamp.
    static constexpr double maximumAcousticDelayScale = 12.5;
    // Ceiling EngineRuntime applies to every published physical delay. It is a
    // safety clamp, not a physical bound: 80 ms of primary would be a 41 m pipe.
    // Sizing lines from it would waste ~87x, so prepare() sizes from the delays
    // actually published and render() reports any residual truncation.
    static constexpr double maximumPublishedDelaySeconds = 0.080;
    static constexpr std::size_t minimumLineLength = 64;
    // Reference delays of the muffler FDN's four lines, in samples at 48 kHz
    // before the acoustic scale is applied. Mutually prime so their modes do
    // not coincide.
    static constexpr std::array<double, 4> referenceFdnSamples {
        1'493.0, 2'111.0, 2'791.0, 3'557.0 };

    /** A bank of `count` power-of-two delay lines held contiguously.
     *
     * One allocation per bank keeps a runner's read and write cursors on the
     * same pages, and the power-of-two stride turns the per-sample wrap into a
     * mask instead of an integer division.
     */
    struct DelayLineBank final {
        std::vector<float> data;
        std::size_t stride { 0 };
        std::size_t mask { 0 };
        void allocate(std::size_t lines, std::size_t lengthPowerOfTwo) {
            stride = lengthPowerOfTwo;
            mask = lengthPowerOfTwo - 1;
            data.assign(lines * lengthPowerOfTwo, 0.0F);
        }
        void clear() noexcept { std::fill(data.begin(), data.end(), 0.0F); }
        [[nodiscard]] float* line(std::size_t index) noexcept {
            return data.data() + index * stride;
        }
    };

    struct ExhaustPathState final {
        UnflangedPipeRadiation radiation;
        /** Characteristic admittance A/(rho*c), in m^3/(Pa*s). */
        float outletAcousticAdmittance {};
        float collectorReturn {};
        std::vector<float> forwardWave;
        std::vector<float> reverseWave;
        /** Free-field propagation from the mouth to the calibrated observer. */
        std::vector<float> observerPressure;
        std::array<std::vector<float>, 4> fdn {};
        std::array<float, 64> jitterHistory {};
        std::size_t waveWrite {};
        std::size_t waveMask {};
        std::size_t observerWrite {};
        std::size_t observerMask {};
        float observerDelaySamples { 1.0F };
        std::array<std::size_t, 4> fdnWrite {};
        std::size_t jitterWrite {};
        float reflectionDelaySamples { 1.0F };
        /** Block-rate target reflectionDelaySamples ramps toward per sample. */
        float reflectionDelayTargetSamples { 1.0F };
        float reflectedLowPass {};
        float collectorState {};
        float previousCollectorInput {};
        float jitterDelaySamples {};
        float exhaustBodyLeft {};
        float exhaustBodyRight {};
        float exhaustAirLeft {};
        float exhaustAirRight {};
        /** Thermoviscous attenuation over one collector-to-outlet traversal,
         *  applied independently in each direction. Refitted per block from the
         *  path's own gas state; see DuctWallLoss. */
        DuctWallLoss::Coefficients wallLoss {};
        DuctWallLoss::State wallLossOutbound {};
        DuctWallLoss::State wallLossReturn {};
        /** Path-average gas state, cached from the last physical sample so the
         *  per-block wall-loss fit does not need per-sample transcendentals. */
        float mediumDensityKgPerM3 { 1.2F };
        float mediumSoundSpeedMps { 343.0F };
        /** Total mean exhaust mass flow leaving this path, cached from the last
         *  physical sample. Drives the outlet mean-flow convective loss so the
         *  wave network is not a quiescent (near-lossless) pipe. */
        float meanExhaustMassFlowKgPerSecond { 0.0F };
        /** Expansion-chamber silencer at the collector end of the duct.
         *  Disabled until the engine publishes a chamber, in which state it is
         *  an exact through-connection. See ExpansionChamberMuffler. */
        ExpansionChamberMuffler::State muffler {};
        ExpansionChamberMuffler::Coefficients mufflerCoefficients {};
        /** Block-rate target the chamber traversal ramps toward per sample.
         *
         * The chamber delay is stretched by the published exhaust sound speed
         * exactly like every other physical delay, so it inherits the same
         * frame-rate step; see RunnerWaveguides::delayTargetSamples. Applying
         * it directly was measured as broadband hash reaching 28 % of the
         * signal energy in the top octave -- block-boundary discontinuities,
         * not silencing. */
        float mufflerDelayTargetSamples { 0.0F };
    };
    struct RunnerWaveguides final {
        DelayLineBank forward;
        DelayLineBank backward;
        std::array<std::size_t, maxRunners> write {};
        std::array<float, maxRunners> delaySamples {};
        /** Block-rate targets delaySamples ramps toward per sample.
         *
         * Every delay in the network scales with the published exhaust sound
         * speed, which is frame-rate telemetry: it aliases the engine cycle's
         * temperature swing into a step at every frame. Applying such a step
         * directly phase-jumps all delay lines at once, which was measured as
         * an engine-independent comb at exact multiples of the frame rate with
         * firing sidebands. The physical quantity is continuous; the step is
         * a telemetry artefact, so control-rate values are ramped at audio
         * rate instead of applied instantaneously.
         */
        std::array<float, maxRunners> delayTargetSamples {};
    };
    /** One-pole coefficient for control-rate parameter ramps (about 10 Hz). */
    float controlRampCoefficient_ { 0.0F };
    /** Size and zero every delay line for the engine currently published.
     *  Allocates, so it is called only from prepare(). */
    void allocateDelayLines();
    /** Latch the physical path and retire already-scheduled procedural exhaust. */
    void activatePhysicalExhaust() noexcept;
    void trigger(const FiringEvent&, bool exhaust) noexcept;
    void updateExhaustPreset(int preset) noexcept;
    /** Instantaneous physical state of one exhaust port's valve.
     *
     * Carried per runner so the port's orifice termination can be recomputed
     * every sample: its resistance depends on the acoustic velocity through the
     * opening, which is only known inside the waveguide.
     */
    using PortBoundary = AcousticExhaustNetwork::CylinderBoundary;
    [[nodiscard]] std::array<float, maximumPaths> processExhaustWaveguides(
        const std::array<float, maxRunners>& pulse,
        const std::array<std::uint8_t, maxRunners>& pathIndex,
        const std::array<float, maxRunners>& runnerAdmittance,
        const std::array<float, maxRunners>& portReflection,
        const std::array<PortBoundary, maxRunners>& portBoundary,
        const std::array<float, maximumPaths>& outletAdmittance,
        std::size_t count, std::size_t pathCount) noexcept;
    [[nodiscard]] float processMufflerFdn(ExhaustPathState&, float sample) noexcept;
    [[nodiscard]] float saturateCollector(float sample, float drive) const noexcept;
    [[nodiscard]] static float softLimit(float sample) noexcept;
    [[nodiscard]] float noise() noexcept;
    FiringEventQueue& queue_;
    RealtimeAudioState& realtimeState_;
    CylinderPressureQueue* pressureQueue_ { nullptr };
    ExhaustAcousticQueue* exhaustAcousticQueue_ { nullptr };
    CylinderPressureSample currentPressureSample_ {};
    CylinderPressureSample nextPressureSample_ {};
    bool hasCurrentPressureSample_ { false };
    bool hasNextPressureSample_ { false };
    ExhaustAcousticSample currentExhaustAcousticSample_ {};
    ExhaustAcousticSample nextExhaustAcousticSample_ {};
    bool hasCurrentExhaustAcousticSample_ { false };
    bool hasNextExhaustAcousticSample_ { false };
    struct ThermoacousticReactionVoice final {
        bool active { false };
        std::uint32_t nodeId { 0 };
        std::uint32_t sourceComponentId { 0 };
        float axialPosition { 0.5F };
        float flowAreaM2 { 0.0F };
        float speedOfSoundMps { 0.0F };
        double targetPowerW { 0.0 };
        double lastUpdateTimeSeconds { 0.0 };
        double holdSeconds { 0.001 };
        ThermoacousticHeatReleaseSource::State source {};
        ReactionCrackSynthesiser::State crack {};
    };
    std::array<ThermoacousticReactionVoice, 64> reactionVoices_ {};
    double lastReactionEventSampleTime_ { -1.0 };
    ThermoacousticHeatReleaseSource::Coefficients reactionSourceCoefficients_ {};
    ReactionCrackSynthesiser::Coefficients reactionCrackCoefficients_ {};
    std::uint32_t reactionCrackSeedCounter_ { 0 };
    std::atomic<bool> reactionCrackEnabled_ { true };
    double reactionSourceCouplingHz_ { 0.0 };
    std::array<Voice, 96> voices_ {};
    std::array<PendingEvent, 512> pendingEvents_ {};
    std::size_t pendingEventCount_ { 0 };
    std::size_t observedExhaustPathCount_ { 1 };
    double sampleRate_ { 48'000.0 };
    double referenceSynthesisRateHz_ { 0.0 };
    int upsamplingFactor_ { 1 };
    /** Synthesis at sampleRate_, then upsampled to the device's rate. */
    static constexpr int maximumUpsamplingFactor = 16;
    juce::AudioBuffer<float> synthesisScratch_;
    std::array<IntegerUpsampler, 2> upsamplers_ {};
    std::array<std::vector<float>, 2> upsampledScratch_ {};
    /** Upsampled samples a device block did not take, for the next one. */
    std::array<std::array<float, maximumUpsamplingFactor>, 2> pendingUpsampled_ {};
    int pendingUpsampledCount_ { 0 };
    int pendingUpsampledRead_ { 0 };
    void prepareSynthesis(double sampleRate, int maximumBlockSize) noexcept;
    void renderSynthesis(juce::AudioBuffer<float>& output, int startSample,
                         int sampleCount, const RealtimeAudioStemBuffers& stems) noexcept;
    void renderUpsampled(juce::AudioBuffer<float>& output, int startSample,
                         int sampleCount) noexcept;
    double audioTimeSeconds_ { -0.020 };
    double producerClock_ { 0.0 };
    double eventLatencySeconds_ { 0.020 };
    std::uint32_t noiseState_ { 0x92d68ca2U };
    // Per-runner bidirectional digital waveguide (port <-> collector) with an
    // N-port scattering junction that couples cylinders sharing a collector.
    std::unique_ptr<RunnerWaveguides> runners_;
    /** Complete compiled DAG used by production engines. Null only for legacy
     * producers/tests that did not supply topology. */
    std::unique_ptr<AcousticExhaustNetwork> acousticExhaustNetwork_;
    /** Whether acousticExhaustNetwork_ is set, for the message thread: the
     *  audio thread swaps the pointer itself. */
    std::atomic<bool> exhaustNetworkPresent_ { false };
    std::atomic<bool> intakeNetworkPresent_ { false };
    /** Diagnostic recording (setExhaustPressureTap); empty in production. */
    std::vector<float> exhaustTapRecording_;
    std::size_t exhaustTapCapacity_ { 0 };
    /** A compiled exhaust on its way in, with the rate it was prepared at. */
    struct ExhaustNetworkHandoff final {
        std::unique_ptr<AcousticExhaustNetwork> network;
        double sampleRate { 0.0 };
    };
    /** Message thread -> audio thread: the next network, prepared. */
    std::atomic<ExhaustNetworkHandoff*> incomingExhaustNetwork_ { nullptr };
    /** Audio thread -> message thread: a network to free. */
    std::atomic<ExhaustNetworkHandoff*> retiredExhaustNetwork_ { nullptr };
    /** Audio thread: the network warming up then fading in, and how far. */
    ExhaustNetworkHandoff* swappingExhaustNetwork_ { nullptr };
    std::int64_t exhaustSwapSamples_ { 0 };
    std::int64_t exhaustSwapWarmupSamples_ { 0 };
    std::int64_t exhaustSwapFadeSamples_ { 1 };
    std::atomic<std::uint64_t> exhaustSwaps_ { 0 };
    std::atomic<double> preparedSampleRate_ { 0.0 };
    bool outletJetNoiseEnabled_ { true };
    bool mufflerFlowNoiseEnabled_ { false };
    double outletFarFieldDensityOverrideKgPerM3_ { -1.0 };
    /** The far-field density the outlets use this block (see above). */
    [[nodiscard]] double resolvedOutletFarFieldDensityKgPerM3() const noexcept {
        return outletFarFieldDensityOverrideKgPerM3_ < 0.0
            ? ambientAirDensityKgPerM3() : outletFarFieldDensityOverrideKgPerM3_;
    }
    bool outletPressureRelease_ { false };
    bool outletConvectiveLoss_ { false };
    /** 200 Hz: kept by the owner after an A/B (2026-11-17, K01). */
    double outletSolverLowBandHz_ { 200.0 };
    /** setMicrophones() -> audio thread, a sequence lock: odd while written. */
    std::atomic<std::uint64_t> microphoneSequence_ { 0 };
    std::array<std::atomic<double>, 6> publishedMicrophones_ {};
    std::atomic<bool> publishedMicrophonesMoved_ { false };
    /** Audio thread: the positions the layers are going to. */
    std::uint64_t appliedMicrophoneSequence_ { 0 };
    bool microphonesMoved_ { false };
    bool jumpMicrophones_ { false };
    std::array<AcousticPoint3M, 2> currentMicrophones_ {};
    /** Where the engine's observer puts the microphones, and their mean
     * distance (effectiveMicrophonePosition, effectiveObserverDistanceM). */
    std::array<AcousticPoint3M, 2> authoredMicrophones_ {};
    PassByMicrophone passBy_;
    std::atomic<bool> passByRequested_ { false };
    std::atomic<double> passByLaneM_ { 7.5 };
    std::atomic<double> passByMicrophoneHeightM_ { 1.2 };
    std::atomic<int> passByGround_ { static_cast<int>(PassByGround::asphalt) };
    std::atomic<bool> passByNormalised_ { false };
    std::atomic<double> passByPositionM_ { 0.0 };
    /** The tailpipe's distance behind the engine for the trackside
     *  microphone: the wheelbase, a front-engined car's estimate. */
    double passByExhaustBehindM_ { 2.65 };
    /** The exhaust's share of the dry mix, per channel, for one block, and
     *  the copies of the output low-pass and tone shelf it goes through. */
    std::array<std::vector<float>, 2> passByExhaust_ {};
    float passByLowPassLeft_ { 0.0F };
    float passByLowPassRight_ { 0.0F };
    float passByToneLowLeft_ { 0.0F };
    float passByToneLowRight_ { 0.0F };
    double authoredObserverDistanceM_ { 1.0 };
    /** setSoundSources() -> audio thread, and back to be freed. */
    std::atomic<AcousticSourcePlacements*> incomingSoundSources_ { nullptr };
    std::atomic<AcousticSourcePlacements*> retiredSoundSources_ { nullptr };
    /** Audio thread: the placements in use; null for none. */
    AcousticSourcePlacements* soundSources_ { nullptr };
    /** Audio thread, at the start of a block: newly published positions and
     * placements. */
    void takeMicrophones() noexcept;
    /** The outlet and mouth placements the networks use now: none while the
     * microphones are where the engine authored them. */
    [[nodiscard]] std::span<const AcousticSourcePlacement> placedOutlets() const noexcept;
    [[nodiscard]] std::span<const AcousticSourcePlacement> placedMouths() const noexcept;
    /** The same handoff for the intake network. */
    struct IntakeNetworkHandoff final {
        std::unique_ptr<AcousticIntakeNetwork> network;
        double sampleRate { 0.0 };
    };
    std::atomic<IntakeNetworkHandoff*> incomingIntakeNetwork_ { nullptr };
    std::atomic<IntakeNetworkHandoff*> retiredIntakeNetwork_ { nullptr };
    IntakeNetworkHandoff* swappingIntakeNetwork_ { nullptr };
    std::int64_t intakeSwapSamples_ { 0 };
    std::atomic<std::uint64_t> intakeSwaps_ { 0 };
    void beginIntakeSwapIfWaiting() noexcept;
    void completeIntakeSwap() noexcept;
    /** Message thread: the forced-induction settings the sound follows. */
    ForcedInductionConfig forcedInductionConfig_ {};
    /** Message thread -> audio thread: forced-induction settings to take;
     * the audio thread hands them back through the retired slot. */
    std::atomic<ForcedInductionConfig*> incomingForcedInduction_ { nullptr };
    std::atomic<ForcedInductionConfig*> retiredForcedInduction_ { nullptr };
    std::atomic<std::uint64_t> forcedInductionUpdates_ { 0 };
    void takeForcedInductionUpdate() noexcept;
    /** Audio thread: take a waiting network, or finish the one in progress. */
    void beginExhaustSwapIfWaiting() noexcept;
    void completeExhaustSwap() noexcept;
    /** Says, for the replace calls, whether there is an exhaust and an
     *  intake network: set where they are made or dropped, never by a swap. */
    void publishNetworksPresent() noexcept;
    /** Block/head modes compiled from immutable engine geometry. */
    std::unique_ptr<StructuralModalRadiator> structuralModalRadiator_;
    /** Runners/plenums/throttles/inlets compiled from EngineConfig. */
    std::unique_ptr<AcousticIntakeNetwork> acousticIntakeNetwork_;
    /** Rotor-order tones and jet radiation, parameterised by physical geometry. */
    std::unique_ptr<ForcedInductionAcoustics> forcedInductionAcoustics_;
    // Sized in prepare() to the cylinders and paths the loaded engine actually
    // has. Allocation stays off the callback; only the capacity is no longer a
    // worst-case guess paid for by every engine.
    std::vector<ExhaustPathState> exhaustPaths_;
    std::size_t allocatedRunners_ { 0 };
    std::size_t allocatedPaths_ { 0 };
    std::array<std::size_t, 4> fdnDelaySamples_ { 1, 1, 1, 1 };
    RealtimeConvolutionBank convolutionBank_;
    std::unique_ptr<juce::dsp::Oversampling<float>> oversampler_;
    int maximumBlockSize_ { 1 };
    int activeExhaustPreset_ { -1 };
    float presetDrive_ { 1.0F };
    float presetDamping_ { 0.985F };
    float presetWet_ { 0.42F };
    float presetToneHz_ { 1'500.0F };
    float presetReflection_ { 0.34F };
    float presetFdngain_ { 0.58F };
    float lowPassCoefficient_ { 0.18F };
    float voiceFilterCoefficient_ { 0.24F };
    float intakeFilterCoefficient_ { 0.08F };
    float rpmFilterCoefficient_ { 0.00037F };
    float reflectionFilterCoefficient_ { 0.12F };
    float lowPassLeft_ { 0.0F };
    float lowPassRight_ { 0.0F };
    float pressureTailDecay_ { 0.992F };
    float pressureTailInputCoefficient_ { 0.010F };
    float jitterCoefficient_ { 0.015F };
    float collectorCoefficient_ { 0.18F };
    float levelAttackCoefficient_ { 0.0025F };
    float levelReleaseCoefficient_ { 0.00012F };
    float gainAttackCoefficient_ { 0.0020F };
    float gainReleaseCoefficient_ { 0.00012F };
    float bodyExcitationScale_ { 1.0F };
    float levelEnvelope_ { 0.0F };
    float levelGain_ { 1.0F };
    float antiAliasLeftA_ { 0.0F };
    float antiAliasLeftB_ { 0.0F };
    float antiAliasRightA_ { 0.0F };
    float antiAliasRightB_ { 0.0F };
    float antiAliasCoefficient_ { 0.5F };
    float dcBlockPole_ { 0.998F };
    float toneCoefficient_ { 0.1F };
    float radiationLowCoefficient_ { 0.03F };
    float dcInputLeft_ { 0.0F };
    float dcInputRight_ { 0.0F };
    float dcOutputLeft_ { 0.0F };
    float dcOutputRight_ { 0.0F };
    float toneLowLeft_ { 0.0F };
    float toneLowRight_ { 0.0F };
    float exhaustRadiationLowLeft_ { 0.0F };
    float exhaustRadiationLowRight_ { 0.0F };
    float wetExhaustRadiationLowLeft_ { 0.0F };
    float wetExhaustRadiationLowRight_ { 0.0F };
    float pressureTailLeft_ { 0.0F };
    float pressureTailRight_ { 0.0F };
    std::array<float, 32> cylinderPressureRawPrevious_ {};
    std::array<float, 32> cylinderPressureHighPass_ {};
    std::array<float, 32> cylinderPressureHighPassPrevious_ {};
    std::array<float, 32> cylinderPressureBandLimited_ {};
    std::array<float, 32> exhaustPressureRawPrevious_ {};
    std::array<float, 32> exhaustPressureHighPass_ {};
    std::array<float, 32> exhaustPressureHighPassPrevious_ {};
    std::array<float, 32> exhaustPressureBandLimited_ {};
    std::array<float, 32> exhaustMeanPressurePa_ {};
    std::array<float, 32> exhaustMeanMassFlowKgPerSecond_ {};
    std::array<float, 32> thermoacousticRunnerAdmittance_ {};
    std::array<float, 32> thermoacousticPortReflection_ {};
    /** rho*c^2 of each runner's gas, for the finite-amplitude (steepening)
     *  propagation correction. Zero until physical telemetry arrives, which
     *  NonlinearDuctAcoustics::delayScale treats as exactly linear. */
    std::array<float, 32> runnerStiffnessRhoC2_ {};
    /** Latest published valve state per runner, and the two filter memories the
     *  orifice termination needs: one for the wave reflecting inside the runner,
     *  one for separating the measured boundary into source and reflection. */
    std::array<PortBoundary, maxRunners> portBoundary_ {};
    std::array<ValvePortTermination::State, maxRunners> portReflectionState_ {};
    std::array<ValvePortTermination::State, maxRunners> portSourceState_ {};
    /** Thermoviscous attenuation over one runner traversal, per direction. */
    std::array<DuctWallLoss::Coefficients, maxRunners> runnerWallLoss_ {};
    std::array<DuctWallLoss::State, maxRunners> runnerWallLossToJunction_ {};
    std::array<DuctWallLoss::State, maxRunners> runnerWallLossToPort_ {};
    /** Anti-imaging reconstruction of the sampled boundary. One shared
     *  coefficient set (the coupling rate is global), per-cylinder state for
     *  each of the two characteristic partners. See
     *  BoundaryReconstructionFilter. */
    BoundaryReconstructionFilter::Coefficients boundaryReconstruction_ {};
    double boundaryReconstructionCouplingHz_ { 0.0 };
    ValveFlowAcousticSource::SourceRateTracker valveFlowSourceRate_ {};
    double valveFlowSourceRateRise_ { 1.0 };
    std::array<BoundaryReconstructionFilter::State, 32> boundaryReconstructionPressure_ {};
    std::array<BoundaryReconstructionFilter::State, 32> boundaryReconstructionFlow_ {};
    ValveFlowAcousticSource::Coefficients valveFlowAcousticSource_ {};
    std::array<ValveFlowAcousticSource::State, 32> valveFlowAcousticSourceState_ {};
    bool valveTurbulenceNoiseEnabled_ { false };
    std::array<ValveTurbulenceNoise, 32> valveTurbulenceNoise_ {};
    std::array<bool, 32> thermoacousticMeanInitialised_ {};
    float thermoacousticMeanCoefficient_ { 0.0F };
    // Atomic so a monitoring thread can observe which path is producing audio
    // without racing the renderer.
    std::atomic<bool> physicalExhaustActive_ { false };
    float pressureHighPassPole_ { 0.997F };
    float pressureBandCoefficient_ { 0.5F };
    double pressureSampleIntervalSeconds_ { 0.0 };
    double mechanicalPhase_ { 0.0 };
    double valvetrainPhase_ { 0.0 };
    double starterPhase_ { 0.0 };
    float smoothedRpm_ { 0.0F };
    float intakeFilter_ { 0.0F };
    float intakeSvfLow_ { 0.0F };
    float intakeSvfBand_ { 0.0F };
    std::atomic<std::uint64_t> lateEvents_ { 0 };
    std::atomic<std::uint64_t> stolenVoices_ { 0 };
    std::atomic<std::uint64_t> droppedPendingEvents_ { 0 };
    std::atomic<std::uint64_t> delayTruncations_ { 0 };
    std::atomic<std::uint64_t> largeForwardClockDrifts_ { 0 };
    std::atomic<double> maximumForwardClockDriftSeconds_ { 0.0 };
    bool largeForwardClockDriftActive_ { false };
    // Safety-leveler observers (measurement only; updated once per block).
    std::atomic<std::uint64_t> levelLimitedSamples_ { 0 };
    std::atomic<std::uint64_t> saturationProcessedSamples_ { 0 };
    std::atomic<std::uint64_t> softLimitedSamples_ { 0 };
    std::atomic<std::uint64_t> hardClampedSamples_ { 0 };
    std::atomic<std::uint64_t> droppedReactionEvents_ { 0 };
    std::atomic<std::uint64_t> reactionPressureLimitedSamples_ { 0 };
    std::atomic<float> maximumPostLimiterSampleMagnitude_ { 0.0F };
    std::atomic<float> minObservedLevelGain_ { 1.0F };
    std::atomic<float> maxObservedExhaustPressurePa_ { 0.0F };
    std::atomic<float> maxObservedExhaustJetNoisePressurePa_ { 0.0F };
    std::atomic<float> maxThermoacousticValveSourcePressurePa_ { 0.0F };
    std::atomic<float> maxObservedExhaustPressureWavePa_ { 0.0F };
    std::atomic<float> maxObservedIntakePressurePa_ { 0.0F };
    std::atomic<float> maxIntakeSourcePressurePa_ { 0.0F };
    std::atomic<float> maxIntakeRunnerPressurePa_ { 0.0F };
    std::atomic<float> maxIntakePlenumPressurePa_ { 0.0F };
    std::atomic<float> maxIntakeAirboxPressurePa_ { 0.0F };
    std::atomic<float> maxIntakeMouthPressurePa_ { 0.0F };
    std::atomic<float> maxIntakeRadiatedPressurePa_ { 0.0F };
    std::atomic<float> maxObservedStructuralPressurePa_ { 0.0F };
    std::atomic<float> maxObservedForcedInductionPressurePa_ { 0.0F };
    std::atomic<float> maxPreLimiterMagnitude_ { 0.0F };
    std::atomic<std::uint64_t> legacyPathSamples_ { 0 };
    std::atomic<std::uint64_t> invalidBoundarySamples_ { 0 };
};
} // namespace enginelab
