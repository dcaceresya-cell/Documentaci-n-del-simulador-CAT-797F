#pragma once

#include <enginelab/audio/ExhaustJetNoise.hpp>
#include <enginelab/audio/ValvePortTermination.hpp>
#include <enginelab/audio/FreeFieldObserver.hpp>
#include <enginelab/exhaust/ExhaustGraph.hpp>
#include <enginelab/foundation/AcousticSourcePlacement.hpp>

#include <array>
#include <cstddef>
#include <cstdint>
#include <memory>
#include <span>

namespace enginelab {

/** Allocation-free audio-band wave network compiled from the complete exhaust DAG.
 *
 * Every constant-section component becomes a bidirectional delay line; a
 * finite taper is resolved by up to four bounded sections under a graph-wide
 * complexity budget. Direct interfaces, merges and splitters are lossless
 * admittance-scattering junctions, compact junction volumes and homogenised
 * perforated-core annuli are passive compliances, and every authored outlet
 * owns an independent radiation load. The
 * finite-volume solver remains authoritative for mean flow and low-frequency
 * feedback, while this network transports the complementary audible band.
 */
class AcousticExhaustNetwork final {
public:
    static constexpr std::size_t maximumCylinders = 32;
    static constexpr std::size_t maximumPaths = 8;
    /** Last-resort stability bound for a compact source in the linear network.
     * Any use must be reported by RealtimeEngineAudio; it is not a voicing
     * limiter and must never be silent instrumentation. Above the ~0.8 MPa
     * rise of an isochoric stoichiometric explosion from ambient, so no
     * physical burn reaches it: a slug lit by the fired exhaust gives a
     * 320 kPa jump, and the old 100 kPa bound cost a pop 3 dB (journal
     * 2026-10-25). A pulse that strong always arms the linear read. */
    static constexpr float maximumReactionSourcePressurePa = 1'000'000.0F;
    /** A reaction half-wave above this Mach number (beta * p' / (rho c^2))
     *  makes every line read linearly for reactionLinearHoldSeconds. On a
     *  0.5 m primary the amplitude warp then moves a read by about a sample. */
    static constexpr float reactionLinearMachThreshold = 0.03F;
    static constexpr double reactionLinearHoldSeconds = 0.020;

    struct CylinderBoundary final {
        float conductanceAreaM2 {};
        float meanMassFlowKgPerSecond {};
        float densityKgPerM3 {};
        float characteristicImpedancePaSPerM3 {};
        bool physical { false };
    };

    struct Medium final {
        float densityKgPerM3 { 1.2F };
        float soundSpeedMps { 343.0F };
    };

    struct OutletBoundary final {
        std::uint32_t nodeId { 0 };
        float signedMassFlowKgPerSecond { 0.0F };
        float densityKgPerM3 { 0.0F };
        float soundSpeedMps { 0.0F };
        float openingAreaM2 { 0.0F };
    };

    AcousticExhaustNetwork(const ExhaustGraph& graph,
                           std::span<const std::uint32_t> cylinderIds);
    ~AcousticExhaustNetwork();
    AcousticExhaustNetwork(const AcousticExhaustNetwork&) = delete;
    AcousticExhaustNetwork& operator=(const AcousticExhaustNetwork&) = delete;

    /** Allocate delay/radiation storage outside the audio callback. */
    [[nodiscard]] bool prepare(double sampleRateHz,
                               double maximumDelayScale = 12.5,
                               double observerDistanceM = 1.0);
    void reset() noexcept;

    /** Refit delays and wall losses once per callback block.
     *
     *  The optional per-path mean exhaust mass flow drives the outlet mean-flow
     *  convective loss; an empty span leaves every outlet quiescent.
     *
     *  `ductMedia` carries the gas state of each compiled duct, indexed as
     *  ExhaustNetworkLayout::ducts(). Where it is supplied every duct resolves
     *  its own delay and wall loss from the gas actually in it, which differs
     *  by hundreds of kelvin between a header primary and a tailpipe. Where it
     *  is absent, or an entry is not usable, the duct falls back to its path
     *  medium. */
    void beginBlock(std::span<const Medium> pathMedia,
                    double acousticTimeScale,
                    std::span<const float> pathMeanMassFlowKgPerSecond = {},
                    std::span<const Medium> ductMedia = {},
                    std::span<const OutletBoundary> outletBoundaries = {}) noexcept;

    /** Propagate one sample and return each path at the two microphones, Pa. */
    [[nodiscard]] std::array<StereoPressure, maximumPaths> process(
        std::span<const float> cylinderSourcePressurePa,
        std::span<const CylinderBoundary> cylinderBoundaries,
        float delayRampCoefficient) noexcept;

    /** Add a symmetric high-band pressure source at the finite-volume node
     * that released the energy. No outlet or cylinder fallback is used when a
     * node cannot be resolved. */
    [[nodiscard]] bool injectReactionPressure(
        std::uint32_t nodeId, float axialPosition,
        float sourcePressurePa) noexcept;

    /** The open share, 0-1, the active exhaust valves glide toward
     *  (ExhaustComponentConfig::inletValve). Each valve is a series
     *  resistance between its pipe and the junction it meets: at 1 the plain
     *  junction, bit for bit; at 0 a rigid end. */
    void setExhaustValveOpening(float openFraction) noexcept;
    [[nodiscard]] std::size_t exhaustValveCount() const noexcept;
    /** Diagnostic A/B switch. Production leaves the source enabled. */
    void setOutletJetNoiseEnabled(bool enabled) noexcept;
    /** Each silencer's broadband flow noise (MufflerFlowNoise), radiated by
     * the outlets it feeds. Off by default: as built it masked the engine
     * under 10-35 dB of hiss at 4-8 kHz on silenced engines (journal
     * 2026-11-19). It also needs setOutletJetNoiseEnabled. */
    void setMufflerFlowNoiseEnabled(bool enabled) noexcept;
    [[nodiscard]] bool mufflerFlowNoiseEnabled() const noexcept;
    /** Diagnostic: density of the air each outlet radiates into. Zero (the
     * default) keeps the duct medium (UnflangedPipeRadiation::setFarFieldDensity). */
    void setOutletFarFieldDensity(double densityKgPerM3) noexcept;
    /** Diagnostic: every outlet becomes an ideal pressure release
     * (UnflangedPipeRadiation::setPressureRelease). Production keeps the
     * Levine-Schwinger load. */
    void setOutletPressureRelease(bool enabled) noexcept;
    /** Diagnostic: true restores the outlet's mean-flow factor (1-M)/(1+M)
     * on the reflected wave, the no-Kutta limit that measured open pipes
     * refute (journal 2026-11-16). Production leaves it off: the pressure
     * reflection is Levine-Schwinger's. */
    void setOutletConvectiveLoss(bool enabled) noexcept;
    /** Below `crossoverHz` each outlet's far field follows the gas solver's
     * own mouth volume flow (setOutletSolverVolumeFlow) instead of the
     * network's: the radiated Q becomes Q_network + LP(Q_solver - Q_network),
     * a second-order Butterworth low-pass, so the two bands are complementary
     * and the sound is unchanged wherever the two flows agree. The linear
     * network fed at the port misses the finite-amplitude low band the solver
     * carries (K01, journal 2026-11-17). Zero (the default) is off; only the
     * far field changes, never the waves in the pipes. */
    void setOutletSolverLowBand(double crossoverHz) noexcept;
    [[nodiscard]] double outletSolverLowBandHz() const noexcept;
    /** The gas solver's outlet volume flows for this sample, m3/s positive
     * leaving, named by graph node and path; an outlet the list does not name
     * keeps its own far field. Audio thread, before process(). */
    void setOutletSolverVolumeFlow(std::span<const float> volumeFlowM3PerS,
                                   std::span<const std::uint32_t> nodeIds,
                                   std::span<const std::uint8_t> pathIndices) noexcept;
    /** Every outlet's microphones glide to `left` and `right`
     * (FreeFieldObserver::moveMicrophones). Audio thread. */
    void moveMicrophones(const AcousticPoint3M& left, const AcousticPoint3M& right,
                         bool immediately = false) noexcept;
    /** Each outlet radiates from its placement in `outlets` (matched by path
     * index and component id), or from where its graph authored it when none
     * matches (FreeFieldObserver::moveSource). Audio thread. */
    void placeOutlets(std::span<const AcousticSourcePlacement> outlets,
                      bool immediately = false) noexcept;
    [[nodiscard]] bool outletJetNoiseEnabled() const noexcept;
    /** Last sample contributed by outlet turbulence, after both microphones. */
    [[nodiscard]] std::array<StereoPressure, maximumPaths>
    lastOutletJetNoisePressure() const noexcept;

    /** Diagnostic: after each process() the plane-wave pressure, Pa, at
     * `axialFraction` (0 inlet, 1 outlet) along graph node `nodeId`: the
     * audio sections a tapered node compiles to share it by length. The
     * forward and reverse lines are read at their
     * partial delays. It never feeds the output. False when no duct
     * carries that node. At 0 or 1 it is exact, the end's incident plus
     * scattered wave. Inside a duct it is approximate: the line's wall loss
     * acts at its far end only, and where the two waves nearly cancel (low
     * frequencies near an open end) that read was 9 dB off. */
    [[nodiscard]] bool setPressureTap(std::uint32_t nodeId,
                                      float axialFraction) noexcept;
    [[nodiscard]] float lastTapPressurePa() const noexcept;

    [[nodiscard]] bool valid() const noexcept;
    [[nodiscard]] std::size_t ductCount() const noexcept;
    [[nodiscard]] std::size_t junctionCount() const noexcept;
    [[nodiscard]] std::size_t outletCount() const noexcept;
    /** Graph node and path of outlet `index` (setOutletSolverVolumeFlow's
     *  names); 0 past the end. */
    [[nodiscard]] std::uint32_t outletNodeId(std::size_t index) const noexcept;
    [[nodiscard]] std::uint32_t outletPathIndex(std::size_t index) const noexcept;

private:
    struct Impl;
    std::unique_ptr<Impl> impl_;
};

} // namespace enginelab
