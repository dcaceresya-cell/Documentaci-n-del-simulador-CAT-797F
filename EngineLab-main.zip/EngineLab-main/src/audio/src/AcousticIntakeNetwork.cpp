#include <enginelab/audio/AcousticIntakeNetwork.hpp>

#include <enginelab/audio/DuctWallLoss.hpp>
#include <enginelab/audio/PipeRadiationModel.hpp>
#include <enginelab/audio/ValvePortTermination.hpp>

#include <algorithm>
#include <cmath>
#include <limits>
#include <numbers>
#include <vector>

namespace enginelab {
namespace {

[[nodiscard]] std::size_t nextPowerOfTwo(std::size_t value) noexcept {
    auto result = std::size_t { 1 };
    while (result < value && result <= std::numeric_limits<std::size_t>::max() / 2U)
        result <<= 1U;
    return result;
}

[[nodiscard]] std::size_t intakePathIndexFor(
    const EngineConfig& config, const CylinderConfig& cylinder) noexcept {
    const auto found = std::find_if(config.intakePaths.begin(), config.intakePaths.end(),
        [&cylinder](const IntakePathConfig& path) {
            return std::find(path.cylinderIds.begin(), path.cylinderIds.end(), cylinder.id)
                != path.cylinderIds.end();
        });
    return found != config.intakePaths.end()
        ? static_cast<std::size_t>(std::distance(config.intakePaths.begin(), found)) : 0U;
}

[[nodiscard]] const IntakeConfig& intakeGeometryAt(
    const EngineConfig& config, std::size_t path) noexcept {
    return path < config.intakePaths.size()
        ? config.intakePaths[path].geometry : config.intake;
}

[[nodiscard]] double circularAreaM2(double diameterMm) noexcept {
    const auto radiusM = std::max(1.0, diameterMm) * 0.0005;
    return std::numbers::pi * radiusM * radiusM;
}

/** What the intake breathes through when no inlet duct or bellmouth is
 *  authored: the throttle bores, all of them, as one mouth of their combined
 *  area. One bore's diameter made four 34 mm throttles breathe through one
 *  34 mm hole, a quarter of the area that carries their air, and the intake of
 *  every multi-throttle engine radiated through that (an R6-like 600 at WOT:
 *  -69 dB against -57 dB with the combined mouth). */
[[nodiscard]] double boresMouthDiameterMm(const IntakeConfig& geometry) noexcept {
    return geometry.throttleDiameterMm
        * std::sqrt(static_cast<double>(std::max(1U, geometry.throttleCount)));
}

/** The length of a square-section volume `elongation` times as long as it is
 *  wide, m. As point compliances, the K20's 2.6 L plenum and 4.5 L airbox each
 *  shunted the intake above 92-202 Hz at 6 dB an octave: its stem sat 47-59 dB
 *  under the exhaust's at 1-2 kHz against 5-11 dB at 125-250 Hz (journal
 *  2026-10-30). A real volume is a cavity with modes: as plane-wave ducts
 *  of the same volume they stay compliances below their first mode. The
 *  shapes are estimates: a log plenum three times as long as it is wide
 *  along its runners, an airbox one and a half times along its flow. */
[[nodiscard]] double distributedVolumeLengthM(double volumeM3, double elongation) noexcept {
    return std::cbrt(elongation * elongation * std::max(0.0, volumeM3));
}
inline constexpr double plenumElongation = 3.0;
inline constexpr double airboxElongation = 1.5;

} // namespace

struct AcousticIntakeNetwork::Impl final {
    struct Duct final {
        double lengthM {};
        double radiusM {};
        double areaM2 {};
        double inletAreaM2 {};
        double outletAreaM2 {};
        std::vector<float> forward;
        std::vector<float> reverse;
        std::size_t write {};
        std::size_t mask {};
        float delaySamples { 1.0F };
        float delayControlSamples { 1.0F };
        float delayTargetSamples { 1.0F };
        DuctWallLoss::Coefficients wallLoss {};
        DuctWallLoss::Coefficients wallLossControl {};
        DuctWallLoss::Coefficients wallLossTarget {};
        DuctWallLoss::State forwardLoss {};
        DuctWallLoss::State reverseLoss {};
    };

    struct Runner final {
        std::size_t cylinderIndex {};
        std::size_t pathIndex {};
        Duct duct;
        float incidentAtValve {};
        float incidentAtPlenum {};
        float outgoingAtValve {};
        float outgoingAtPlenum {};
        float meanMassFlowKgPerSecond {};
        bool meanInitialised { false };
        ValvePortTermination::State reflectionState {};
    };

    struct Compliance final {
        double volumeM3 {};
        float admittanceM3PerPaSecond {};
        float incident {};
    };

    struct Path final {
        IntakeConfig geometry;
        std::vector<std::size_t> runners;
        Compliance plenum;
        Compliance airbox;
        // A volume long against the wavelength is no point compliance: the
        // plenum is a closed side branch of its volume at the runners' node,
        // the airbox a wide duct between the throttle and the inlet (see
        // distributedVolumeLengthM). Each stays a compliance when it is
        // shorter than two samples of travel.
        bool plenumBranched { false };
        Duct plenumBranch;
        float plenumBranchIncidentAtNode {};
        float plenumBranchIncidentAtEnd {};
        float plenumBranchOutgoingAtNode {};
        bool airboxDucted { false };
        Duct airboxDuct;
        float airboxIncidentAtThrottle {};
        float airboxIncidentAtInlet {};
        float airboxOutgoingAtThrottle {};
        float airboxOutgoingAtInlet {};
        float throttleIncidentAtPlenum {};
        float throttleIncidentAtAirbox {};
        float throttleAdmittanceM3PerPaSecond {};
        bool hasInletDuct { false };
        Duct inletDuct;
        float inletIncidentAtMouth {};
        float inletIncidentAtAirbox {};
        float inletOutgoingAtMouth {};
        float inletOutgoingAtAirbox {};
        float radiationIncidentAtAirbox {};
        // Air-filter element state, one per travel direction. The element is a
        // reciprocal two-port, so both directions carry the same coefficients
        // and independent state.
        bool hasAirFilter { false };
        float filterTowardMouthState {};
        float filterTowardAirboxState {};
        UnflangedPipeRadiation radiation;
        FreeFieldObserver observer;
        PathBoundary medium;
        PathBoundary mediumControl;
        PathBoundary mediumTarget;
        float throttleConductanceAreaM2 {};
        float throttleControlConductanceAreaM2 {};
        float throttleTargetConductanceAreaM2 {};
    };

    // --- air-filter element -------------------------------------------------
    //
    // Every catalogue engine breathes through a filter, and nothing modelled
    // it: the intake mouth radiated essentially bare. Measured on the delivered
    // render before this element existed, the intake layer supplied 97.7% (K20),
    // 99.9% (LS3) and 94.8% (Big Twin) of ALL master energy above 5 kHz, and the
    // first listening pass called every engine "trop aigu", with a whine "comme
    // un supercharger" on engines that have no supercharger.
    //
    // The element is a porous resistive sheet. For a plane wave crossing a sheet
    // of specific flow resistance R, transmission is 1/(1 + R/(2*rho*c)), which
    // is frequency independent; the rising insertion loss that a real element
    // shows above a few hundred hertz comes from the packing depth and the
    // element's own inertance. Both parts are represented here: a broadband
    // resistive transmission and a first-order low pass.
    //
    // These constants are SEMI-EMPIRICAL, chosen from the published range for
    // automotive paper panel elements (specific flow resistance of order
    // 10^2-10^3 Rayl against rho*c = 415). They are an `estimatedFamily`-grade
    // authoring choice, NOT a measurement of any catalogue engine, and they are
    // deliberately the same for every engine until per-engine survey data
    // exists. Do not present them as measured.
    //
    // The loss is frequency dependent on purpose. A flat broadband loss inside
    // this junction would sit in a resonant loop and collapse the low-order
    // induction character the same way an absorption term once cost the EJ25
    // 11 dB at its rev-range fundamental (see .claude/CLAUDE.md on the expansion
    // chamber). Damping the top while leaving the firing orders is the whole
    // point: a real filter lowers the Q of intake resonances, it does not mute
    // the intake.
    static constexpr double airFilterFlowResistanceRayl = 420.0;
    static constexpr double airFilterCutoffHz = 480.0;
    float airFilterBroadbandGain { 1.0F };
    float airFilterLowPassCoefficient { 1.0F };

    /** One direction through the element. Reciprocal: same coefficients.
     * A path with no filter housing is an exact through-connection. */
    [[nodiscard]] float applyAirFilter(
        const Path& path, float& state, float incident) const noexcept {
        if (!path.hasAirFilter) return incident;
        state += airFilterLowPassCoefficient * (incident - state);
        return airFilterBroadbandGain * state;
    }

    std::vector<Runner> runners;
    std::vector<Path> paths;
    double sampleRateHz { 48'000.0 };
    double acousticTimeScale { 1.0 };
    double observerDistanceM { 1.0 };
    AcousticObserverConfig observerConfig;
    float meanFlowCoefficient { 0.0F };
    Diagnostics diagnostics;
    bool mediaInitialised { false };
    bool configured { false };
    bool prepared { false };

    explicit Impl(const EngineConfig& config)
        : observerConfig(config.acousticObserver) {
        if (config.cylinders.empty()) return;
        const auto count = std::clamp<std::size_t>(
            config.intakePaths.empty() ? 1U : config.intakePaths.size(), 1U,
            maximumPaths);
        paths.resize(count);
        for (std::size_t path = 0; path < count; ++path) {
            auto& compiled = paths[path];
            compiled.geometry = intakeGeometryAt(config, path);
            compiled.plenum.volumeM3 = std::max(1.0e-6,
                compiled.geometry.plenumVolumeLitres * 0.001);
            compiled.airbox.volumeM3 = std::max(0.0,
                compiled.geometry.airboxVolumeLitres * 0.001);
            const auto distribute = [](Duct& duct, double volumeM3, double elongation) {
                duct.lengthM = distributedVolumeLengthM(volumeM3, elongation);
                duct.areaM2 = volumeM3 / std::max(1.0e-9, duct.lengthM);
                duct.inletAreaM2 = duct.areaM2;
                duct.outletAreaM2 = duct.areaM2;
                duct.radiusM = std::sqrt(duct.areaM2 / std::numbers::pi);
            };
            distribute(compiled.plenumBranch, compiled.plenum.volumeM3, plenumElongation);
            distribute(compiled.airboxDuct, compiled.airbox.volumeM3, airboxElongation);
            const auto inletDiameterMm = compiled.geometry.inletDuctDiameterMm > 1.0
                ? compiled.geometry.inletDuctDiameterMm
                : boresMouthDiameterMm(compiled.geometry);
            // The filter element belongs to the filter HOUSING. An engine that
            // authors no airbox has no housing, so it gets no element: a
            // carburetted radial breathing through a scoop, or an open-trumpet
            // ITB stack, is legitimately bright. Inventing an element for those
            // would be inventing hardware, and it measurably over-darkened the
            // Radial R5 past `EngineLab.AudioRender`'s low-band gate. A pod
            // filter is the element without the housing.
            compiled.hasAirFilter = compiled.geometry.airboxVolumeLitres > 0.0
                || compiled.geometry.podFilter;
            compiled.hasInletDuct = compiled.geometry.inletDuctLengthMm > 1.0;
            if (compiled.hasInletDuct) {
                compiled.inletDuct.lengthM = compiled.geometry.inletDuctLengthMm * 0.001;
                compiled.inletDuct.areaM2 = circularAreaM2(inletDiameterMm);
                compiled.inletDuct.radiusM = std::sqrt(
                    compiled.inletDuct.areaM2 / std::numbers::pi);
            }
        }
        runners.reserve(config.cylinders.size());
        for (std::size_t cylinder = 0; cylinder < config.cylinders.size(); ++cylinder) {
            const auto path = std::min(intakePathIndexFor(
                config, config.cylinders[cylinder]), count - 1U);
            const auto& geometry = paths[path].geometry;
            const auto lengthMm = config.cylinders[cylinder].intakeRunnerLengthMm > 1.0
                ? config.cylinders[cylinder].intakeRunnerLengthMm
                : geometry.runnerLengthMm;
            const auto diameterMm = config.cylinders[cylinder].intakeRunnerDiameterMm > 1.0
                ? config.cylinders[cylinder].intakeRunnerDiameterMm
                : geometry.runnerDiameterMm;
            const auto plenumDiameterMm = geometry.runnerPlenumDiameterMm > 1.0
                ? geometry.runnerPlenumDiameterMm : diameterMm;
            Runner runner;
            runner.cylinderIndex = cylinder;
            runner.pathIndex = path;
            runner.duct.lengthM = std::max(0.001, lengthMm * 0.001);
            const auto valveEndAreaM2 = circularAreaM2(diameterMm);
            const auto plenumEndAreaM2 = circularAreaM2(plenumDiameterMm);
            runner.duct.areaM2 = (valveEndAreaM2
                + std::sqrt(valveEndAreaM2 * plenumEndAreaM2)
                + plenumEndAreaM2) / 3.0;
            // One delay line carries its pressure unchanged, so both ends
            // present one admittance: the cylinder of the frustum's volume,
            // as each exhaust taper section is (AcousticExhaustNetwork). The
            // valve's impedance at the inlet area and the plenum's scattering
            // at the outlet area made a forward wave gain A_out/A_in in power
            // and a returning one lose it, x4 for a 2:1 diameter (audit
            // A2-05). A straight runner is untouched to the bit.
            runner.duct.inletAreaM2 = diameterMm == plenumDiameterMm
                ? valveEndAreaM2 : runner.duct.areaM2;
            runner.duct.outletAreaM2 = runner.duct.inletAreaM2;
            runner.duct.radiusM = std::sqrt(runner.duct.areaM2 / std::numbers::pi);
            paths[path].runners.push_back(runners.size());
            runners.push_back(std::move(runner));
        }
        configured = !runners.empty() && std::all_of(paths.begin(), paths.end(),
            [](const auto& path) { return !path.runners.empty(); });
    }

    [[nodiscard]] float readDelayed(const Duct& duct,
                                    const std::vector<float>& line) const noexcept {
        const auto delay0 = static_cast<std::size_t>(duct.delaySamples);
        const auto fraction = duct.delaySamples - static_cast<float>(delay0);
        const auto read0 = (duct.write + line.size() - delay0) & duct.mask;
        const auto read1 = (duct.write + line.size() - delay0 - 1U) & duct.mask;
        return std::lerp(line[read0], line[read1], fraction);
    }

    void prepareDuct(Duct& duct) {
        constexpr double minimumSoundSpeedMps = 300.0;
        constexpr double maximumTimeScaleStretch = 4.0;
        const auto maximumSamples = static_cast<std::size_t>(std::ceil(
            duct.lengthM / minimumSoundSpeedMps * sampleRateHz
                * maximumTimeScaleStretch)) + 4U;
        const auto size = std::max<std::size_t>(64U,
            nextPowerOfTwo(maximumSamples));
        duct.forward.assign(size, 0.0F);
        duct.reverse.assign(size, 0.0F);
        duct.mask = size - 1U;
    }

};

AcousticIntakeNetwork::AcousticIntakeNetwork(const EngineConfig& config)
    : impl_(std::make_unique<Impl>(config)) {}

AcousticIntakeNetwork::~AcousticIntakeNetwork() = default;

bool AcousticIntakeNetwork::prepare(double sampleRateHz,
                                    double observerDistanceM) {
    if (!impl_->configured || !(sampleRateHz > 1'000.0)
        || !std::isfinite(sampleRateHz) || !(observerDistanceM > 0.0)
        || !std::isfinite(observerDistanceM))
        return false;
    impl_->sampleRateHz = sampleRateHz;
    impl_->observerDistanceM = observerDistanceM;
    // Five hertz separates the conserved mean flow from the acoustic
    // perturbation while retaining every audible engine order.
    impl_->meanFlowCoefficient = static_cast<float>(1.0 - std::exp(
        -2.0 * std::numbers::pi * 5.0 / sampleRateHz));
    // Filter element coefficients. The characteristic impedance used here is
    // ambient air on the cold side of the element, not the per-path medium:
    // the element sits upstream of the throttle, where the charge has not yet
    // been heated by the engine.
    constexpr double ambientCharacteristicImpedanceRayl = 415.0;
    impl_->airFilterBroadbandGain = static_cast<float>(
        1.0 / (1.0 + Impl::airFilterFlowResistanceRayl
            / (2.0 * ambientCharacteristicImpedanceRayl)));
    impl_->airFilterLowPassCoefficient = static_cast<float>(
        1.0 - std::exp(-2.0 * std::numbers::pi
            * Impl::airFilterCutoffHz / sampleRateHz));
    for (auto& runner : impl_->runners) impl_->prepareDuct(runner.duct);
    for (auto& path : impl_->paths) {
        if (path.hasInletDuct) impl_->prepareDuct(path.inletDuct);
        constexpr double referenceSoundSpeedMps = 343.0;
        const auto spansTwoSamples = [&](const Impl::Duct& duct) {
            return duct.lengthM / referenceSoundSpeedMps * sampleRateHz >= 2.0;
        };
        path.plenumBranched = spansTwoSamples(path.plenumBranch);
        path.airboxDucted = path.airbox.volumeM3 > 0.0 && spansTwoSamples(path.airboxDuct);
        if (path.plenumBranched) impl_->prepareDuct(path.plenumBranch);
        if (path.airboxDucted) impl_->prepareDuct(path.airboxDuct);
        const auto inletDiameterMm = path.geometry.bellmouthDiameterMm > 1.0
            ? path.geometry.bellmouthDiameterMm
            : path.geometry.inletDuctDiameterMm > 1.0
                ? path.geometry.inletDuctDiameterMm
                : boresMouthDiameterMm(path.geometry);
        const auto radiusM = inletDiameterMm * 0.0005;
        if (!path.radiation.prepare(sampleRateHz, radiusM, 1.0)
            || !path.observer.prepare(sampleRateHz, radiusM, {},
                { 0.0, 1.0, 0.0 }, AcousticTerminationType::unflanged,
                impl_->observerConfig))
            return false;
        // A sharp unflanged mouth sheds vortices once acoustic particle
        // velocity is no longer infinitesimal. The quasi-steady termination
        // resistance is Znl/Zc = 2*Cd/(3*pi) * |u|/c with Cd=2 for a
        // thin-wall edge (Peters et al.; Atig et al.). Without this passive
        // loss, a linear Helmholtz mode can grow beyond its own validity range.
        constexpr double unflangedVortexLoss = 4.0
            / (3.0 * std::numbers::pi);
        if (!path.radiation.setNonlinearLossCoefficient(
                unflangedVortexLoss))
            return false;
    }
    impl_->prepared = true;
    reset();
    std::array<PathBoundary, maximumPaths> defaults {};
    beginBlock(std::span<const PathBoundary>(
        defaults.data(), impl_->paths.size()), 1.0);
    // The default block seeds finite delay/loss targets. The first real block
    // must snap to its true gas state rather than sweep up from ambient.
    impl_->mediaInitialised = false;
    return true;
}

void AcousticIntakeNetwork::moveMicrophones(const AcousticPoint3M& left,
                                            const AcousticPoint3M& right, bool immediately) noexcept {
    if (!impl_) return;
    for (auto& path : impl_->paths) path.observer.moveMicrophones(left, right, immediately);
}

void AcousticIntakeNetwork::placeMouths(std::span<const AcousticSourcePlacement> mouths,
                                        bool immediately) noexcept {
    if (!impl_) return;
    for (std::size_t index = 0; index < impl_->paths.size(); ++index) {
        // Where prepare() put every mouth.
        AcousticPoint3M position {};
        AcousticPoint3M axis { 0.0, 1.0, 0.0 };
        for (const auto& placement : mouths)
            if (placement.pathIndex == index) {
                position = placement.positionM;
                axis = placement.axis;
                break;
            }
        impl_->paths[index].observer.moveSource(position, axis, immediately);
    }
}

void AcousticIntakeNetwork::reset() noexcept {
    if (!impl_) return;
    impl_->diagnostics = {};
    impl_->mediaInitialised = false;
    const auto resetDuct = [](Impl::Duct& duct) {
        std::fill(duct.forward.begin(), duct.forward.end(), 0.0F);
        std::fill(duct.reverse.begin(), duct.reverse.end(), 0.0F);
        duct.write = 0;
        duct.delaySamples = 1.0F;
        duct.delayTargetSamples = 1.0F;
        duct.forwardLoss.reset();
        duct.reverseLoss.reset();
    };
    for (auto& runner : impl_->runners) {
        resetDuct(runner.duct);
        runner.incidentAtValve = 0.0F;
        runner.incidentAtPlenum = 0.0F;
        runner.outgoingAtValve = 0.0F;
        runner.outgoingAtPlenum = 0.0F;
        runner.meanMassFlowKgPerSecond = 0.0F;
        runner.meanInitialised = false;
        runner.reflectionState.reset();
    }
    for (auto& path : impl_->paths) {
        if (path.hasInletDuct) resetDuct(path.inletDuct);
        if (path.plenumBranched) resetDuct(path.plenumBranch);
        if (path.airboxDucted) resetDuct(path.airboxDuct);
        path.plenumBranchIncidentAtNode = 0.0F;
        path.plenumBranchIncidentAtEnd = 0.0F;
        path.plenumBranchOutgoingAtNode = 0.0F;
        path.airboxIncidentAtThrottle = 0.0F;
        path.airboxIncidentAtInlet = 0.0F;
        path.airboxOutgoingAtThrottle = 0.0F;
        path.airboxOutgoingAtInlet = 0.0F;
        path.plenum.incident = 0.0F;
        path.airbox.incident = 0.0F;
        path.throttleIncidentAtPlenum = 0.0F;
        path.throttleIncidentAtAirbox = 0.0F;
        path.inletIncidentAtMouth = 0.0F;
        path.inletIncidentAtAirbox = 0.0F;
        path.inletOutgoingAtMouth = 0.0F;
        path.inletOutgoingAtAirbox = 0.0F;
        path.radiationIncidentAtAirbox = 0.0F;
        path.filterTowardMouthState = 0.0F;
        path.filterTowardAirboxState = 0.0F;
        path.radiation.reset();
        path.observer.reset();
    }
}

void AcousticIntakeNetwork::beginBlock(
    std::span<const PathBoundary> boundaries,
    double acousticTimeScale) noexcept {
    if (!impl_->prepared) return;
    impl_->acousticTimeScale = std::clamp(
        std::isfinite(acousticTimeScale) ? acousticTimeScale : 1.0, 0.25, 4.0);
    updateBoundaryTargets(boundaries);
    for (std::size_t pathIndex = 0; pathIndex < impl_->paths.size(); ++pathIndex) {
        auto& path = impl_->paths[pathIndex];
        const auto rho = static_cast<double>(path.mediumTarget.densityKgPerM3);
        const auto c = static_cast<double>(path.mediumTarget.soundSpeedMps);

        const auto fitDuct = [&](Impl::Duct& duct) {
            const auto traversalSeconds = duct.lengthM / c
                / impl_->acousticTimeScale;
            duct.wallLossTarget = DuctWallLoss::fit(
                traversalSeconds, duct.radiusM, rho, c, impl_->sampleRateHz);
        };
        for (const auto runnerIndex : path.runners)
            fitDuct(impl_->runners[runnerIndex].duct);
        if (path.hasInletDuct) fitDuct(path.inletDuct);
        if (path.plenumBranched) fitDuct(path.plenumBranch);
        if (path.airboxDucted) fitDuct(path.airboxDuct);
    }
    if (!impl_->mediaInitialised) {
        for (auto& path : impl_->paths) {
            path.medium = path.mediumTarget;
            path.mediumControl = path.mediumTarget;
            path.throttleConductanceAreaM2 =
                path.throttleTargetConductanceAreaM2;
            path.throttleControlConductanceAreaM2 =
                path.throttleTargetConductanceAreaM2;
            for (const auto runnerIndex : path.runners) {
                auto& duct = impl_->runners[runnerIndex].duct;
                duct.wallLoss = duct.wallLossTarget;
                duct.wallLossControl = duct.wallLossTarget;
                duct.delayControlSamples = duct.delayTargetSamples;
                duct.delaySamples = duct.delayTargetSamples;
            }
            const auto snap = [](Impl::Duct& duct) {
                duct.wallLoss = duct.wallLossTarget;
                duct.wallLossControl = duct.wallLossTarget;
                duct.delayControlSamples = duct.delayTargetSamples;
                duct.delaySamples = duct.delayTargetSamples;
            };
            if (path.plenumBranched) snap(path.plenumBranch);
            if (path.airboxDucted) snap(path.airboxDuct);
            if (path.hasInletDuct) {
                path.inletDuct.wallLoss = path.inletDuct.wallLossTarget;
                path.inletDuct.wallLossControl =
                    path.inletDuct.wallLossTarget;
                path.inletDuct.delayControlSamples =
                    path.inletDuct.delayTargetSamples;
                path.inletDuct.delaySamples =
                    path.inletDuct.delayTargetSamples;
            }
            (void) path.radiation.setMedium(
                path.medium.densityKgPerM3,
                path.medium.soundSpeedMps);
        }
        impl_->mediaInitialised = true;
    }
}

void AcousticIntakeNetwork::updateBoundaryTargets(
    std::span<const PathBoundary> boundaries) noexcept {
    if (!impl_->prepared) return;
    for (std::size_t pathIndex = 0; pathIndex < impl_->paths.size(); ++pathIndex) {
        auto& path = impl_->paths[pathIndex];
        if (pathIndex < boundaries.size()
            && std::isfinite(boundaries[pathIndex].densityKgPerM3)
            && boundaries[pathIndex].densityKgPerM3 > 0.0F
            && std::isfinite(boundaries[pathIndex].soundSpeedMps)
            && boundaries[pathIndex].soundSpeedMps > 0.0F)
            path.mediumTarget = boundaries[pathIndex];
        path.throttleTargetConductanceAreaM2 =
            std::isfinite(path.mediumTarget.throttleConductanceAreaM2)
            ? std::max(0.0F,
                path.mediumTarget.throttleConductanceAreaM2) : 0.0F;
        const auto c = static_cast<double>(path.mediumTarget.soundSpeedMps);
        const auto updateDelayTarget = [&](Impl::Duct& duct) {
            const auto traversalSeconds = duct.lengthM / c
                / impl_->acousticTimeScale;
            const auto limit = static_cast<float>(duct.forward.size() - 2U);
            duct.delayTargetSamples = std::clamp(static_cast<float>(
                traversalSeconds * impl_->sampleRateHz), 1.0F, limit);
            if (duct.delaySamples <= 1.0F)
                duct.delaySamples = duct.delayTargetSamples;
        };
        for (const auto runnerIndex : path.runners)
            updateDelayTarget(impl_->runners[runnerIndex].duct);
        if (path.hasInletDuct) updateDelayTarget(path.inletDuct);
        if (path.plenumBranched) updateDelayTarget(path.plenumBranch);
        if (path.airboxDucted) updateDelayTarget(path.airboxDuct);
    }
}

std::array<StereoPressure, AcousticIntakeNetwork::maximumPaths>
AcousticIntakeNetwork::process(
    std::span<const CylinderBoundary> cylinders,
    float delayRampCoefficient) noexcept {
    std::array<StereoPressure, maximumPaths> result {};
    if (!impl_->prepared) return result;
    const auto ramp = std::clamp(delayRampCoefficient, 0.0F, 1.0F);
    // Two matched poles preserve a continuous first derivative when a host
    // callback supplies a new block-held target. A single pole kept the value
    // continuous but changed its slope instantaneously; the radiation model
    // differentiates volume velocity, turning that corner into a delayed
    // two-sample click whose cadence followed the host block size. Each stage
    // is 1.55x the requested cutoff so the cascade retains the original -3 dB
    // control bandwidth.
    constexpr auto matchedPoleFrequencyRatio = 1.553773974F;
    const auto stageRamp = 1.0F - std::pow(
        std::max(0.0F, 1.0F - ramp), matchedPoleFrequencyRatio);
    // Every medium-derived scattering parameter must move continuously at the
    // sample rate. Stepping these values in beginBlock produced a deterministic
    // impulse at fs/blockSize in the intake stem.
    for (auto& path : impl_->paths) {
        path.mediumControl.densityKgPerM3 += stageRamp
            * (path.mediumTarget.densityKgPerM3
                - path.mediumControl.densityKgPerM3);
        path.mediumControl.soundSpeedMps += stageRamp
            * (path.mediumTarget.soundSpeedMps
                - path.mediumControl.soundSpeedMps);
        path.medium.densityKgPerM3 += stageRamp
            * (path.mediumControl.densityKgPerM3
                - path.medium.densityKgPerM3);
        path.medium.soundSpeedMps += stageRamp
            * (path.mediumControl.soundSpeedMps
                - path.medium.soundSpeedMps);
        path.throttleControlConductanceAreaM2 += stageRamp
            * (path.throttleTargetConductanceAreaM2
                - path.throttleControlConductanceAreaM2);
        path.throttleConductanceAreaM2 += stageRamp
            * (path.throttleControlConductanceAreaM2
                - path.throttleConductanceAreaM2);
        const auto rho = static_cast<double>(path.medium.densityKgPerM3);
        const auto c = static_cast<double>(path.medium.soundSpeedMps);
        path.plenum.admittanceM3PerPaSecond = static_cast<float>(
            2.0 * path.plenum.volumeM3 / (rho * c * c)
                * impl_->sampleRateHz);
        path.airbox.admittanceM3PerPaSecond = path.airbox.volumeM3 > 0.0
            ? static_cast<float>(2.0 * path.airbox.volumeM3
                / (rho * c * c) * impl_->sampleRateHz) : 0.0F;
        path.throttleAdmittanceM3PerPaSecond =
            path.throttleConductanceAreaM2
            / (path.medium.densityKgPerM3
                * path.medium.soundSpeedMps);
        (void) path.radiation.setMedium(rho, c);
    }
    for (auto& runner : impl_->runners) {
        auto& duct = runner.duct;
        duct.delayControlSamples += stageRamp
            * (duct.delayTargetSamples - duct.delayControlSamples);
        duct.delaySamples += stageRamp
            * (duct.delayControlSamples - duct.delaySamples);
        duct.wallLossControl.pole += stageRamp
            * (duct.wallLossTarget.pole - duct.wallLossControl.pole);
        duct.wallLossControl.zero += stageRamp
            * (duct.wallLossTarget.zero - duct.wallLossControl.zero);
        duct.wallLossControl.renormalise();
        duct.wallLoss.pole += stageRamp
            * (duct.wallLossControl.pole - duct.wallLoss.pole);
        duct.wallLoss.zero += stageRamp
            * (duct.wallLossControl.zero - duct.wallLoss.zero);
        duct.wallLoss.renormalise();
        runner.incidentAtValve = DuctWallLoss::process(
            duct.wallLoss, duct.reverseLoss, impl_->readDelayed(duct, duct.reverse));
        runner.incidentAtPlenum = DuctWallLoss::process(
            duct.wallLoss, duct.forwardLoss, impl_->readDelayed(duct, duct.forward));
        impl_->diagnostics.runnerPressurePa = std::max(
            impl_->diagnostics.runnerPressurePa,
            std::max(std::abs(runner.incidentAtValve),
                std::abs(runner.incidentAtPlenum)));
    }
    for (auto& path : impl_->paths) {
        if (!path.hasInletDuct) continue;
        auto& duct = path.inletDuct;
        duct.delayControlSamples += stageRamp
            * (duct.delayTargetSamples - duct.delayControlSamples);
        duct.delaySamples += stageRamp
            * (duct.delayControlSamples - duct.delaySamples);
        duct.wallLossControl.pole += stageRamp
            * (duct.wallLossTarget.pole - duct.wallLossControl.pole);
        duct.wallLossControl.zero += stageRamp
            * (duct.wallLossTarget.zero - duct.wallLossControl.zero);
        duct.wallLossControl.renormalise();
        duct.wallLoss.pole += stageRamp
            * (duct.wallLossControl.pole - duct.wallLoss.pole);
        duct.wallLoss.zero += stageRamp
            * (duct.wallLossControl.zero - duct.wallLoss.zero);
        duct.wallLoss.renormalise();
        path.inletIncidentAtMouth = DuctWallLoss::process(
            duct.wallLoss, duct.reverseLoss, impl_->readDelayed(duct, duct.reverse));
        // Crossing the filter element on the way back into the airbox.
        path.inletIncidentAtAirbox = impl_->applyAirFilter(
            path, path.filterTowardAirboxState,
            DuctWallLoss::process(duct.wallLoss, duct.forwardLoss,
                impl_->readDelayed(duct, duct.forward)));
    }
    const auto rampDuct = [&](Impl::Duct& duct) {
        duct.delayControlSamples += stageRamp
            * (duct.delayTargetSamples - duct.delayControlSamples);
        duct.delaySamples += stageRamp
            * (duct.delayControlSamples - duct.delaySamples);
        duct.wallLossControl.pole += stageRamp
            * (duct.wallLossTarget.pole - duct.wallLossControl.pole);
        duct.wallLossControl.zero += stageRamp
            * (duct.wallLossTarget.zero - duct.wallLossControl.zero);
        duct.wallLossControl.renormalise();
        duct.wallLoss.pole += stageRamp
            * (duct.wallLossControl.pole - duct.wallLoss.pole);
        duct.wallLoss.zero += stageRamp
            * (duct.wallLossControl.zero - duct.wallLoss.zero);
        duct.wallLoss.renormalise();
    };
    for (auto& path : impl_->paths) {
        // Forward runs from the node (or the throttle) to the far end.
        if (path.plenumBranched) {
            auto& duct = path.plenumBranch;
            rampDuct(duct);
            path.plenumBranchIncidentAtNode = DuctWallLoss::process(
                duct.wallLoss, duct.reverseLoss, impl_->readDelayed(duct, duct.reverse));
            path.plenumBranchIncidentAtEnd = DuctWallLoss::process(
                duct.wallLoss, duct.forwardLoss, impl_->readDelayed(duct, duct.forward));
        }
        if (path.airboxDucted) {
            auto& duct = path.airboxDuct;
            rampDuct(duct);
            path.airboxIncidentAtThrottle = DuctWallLoss::process(
                duct.wallLoss, duct.reverseLoss, impl_->readDelayed(duct, duct.reverse));
            path.airboxIncidentAtInlet = DuctWallLoss::process(
                duct.wallLoss, duct.forwardLoss, impl_->readDelayed(duct, duct.forward));
        }
    }

    for (std::size_t pathIndex = 0; pathIndex < impl_->paths.size(); ++pathIndex) {
        auto& path = impl_->paths[pathIndex];
        const auto rho = path.medium.densityKgPerM3;
        const auto c = path.medium.soundSpeedMps;
        const auto plenumBranchAdmittance = path.plenumBranched
            ? path.plenumBranch.areaM2 / (static_cast<double>(rho) * c) : 0.0;
        auto weighted = static_cast<double>(path.throttleAdmittanceM3PerPaSecond)
            * path.throttleIncidentAtPlenum
            + (path.plenumBranched
                ? plenumBranchAdmittance * path.plenumBranchIncidentAtNode
                : static_cast<double>(path.plenum.admittanceM3PerPaSecond)
                    * path.plenum.incident);
        auto admittance = static_cast<double>(path.throttleAdmittanceM3PerPaSecond)
            + (path.plenumBranched ? plenumBranchAdmittance
                : static_cast<double>(path.plenum.admittanceM3PerPaSecond));
        for (const auto runnerIndex : path.runners) {
            const auto& runner = impl_->runners[runnerIndex];
            const auto runnerAdmittance = static_cast<float>(
                runner.duct.outletAreaM2 / (rho * c));
            weighted += runnerAdmittance * runner.incidentAtPlenum;
            admittance += runnerAdmittance;
        }
        const auto plenumPressure = admittance > 1.0e-15
            ? static_cast<float>(2.0 * weighted / admittance) : 0.0F;
        impl_->diagnostics.plenumPressurePa = std::max(
            impl_->diagnostics.plenumPressurePa, std::abs(plenumPressure));
        for (const auto runnerIndex : path.runners) {
            auto& runner = impl_->runners[runnerIndex];
            runner.outgoingAtPlenum = plenumPressure - runner.incidentAtPlenum;
        }
        const auto throttleOutgoingFromPlenum = plenumPressure
            - path.throttleIncidentAtPlenum;
        if (path.plenumBranched)
            path.plenumBranchOutgoingAtNode = plenumPressure - path.plenumBranchIncidentAtNode;
        else
            path.plenum.incident = plenumPressure - path.plenum.incident;

        const auto inletAreaM2 = path.hasInletDuct
            ? path.inletDuct.areaM2
            : circularAreaM2(path.geometry.bellmouthDiameterMm > 1.0
                ? path.geometry.bellmouthDiameterMm
                : boresMouthDiameterMm(path.geometry));
        const auto inletAdmittance = static_cast<float>(inletAreaM2 / (rho * c));
        const auto inletIncident = path.hasInletDuct
            ? path.inletIncidentAtAirbox : path.radiationIncidentAtAirbox;
        auto airboxPressure = 0.0F;
        auto throttleOutgoingFromAirbox = 0.0F;
        if (path.airboxDucted) {
            // The throttle's end of the box, then its inlet's end, where the
            // rest of the path meets it as it met the point airbox.
            const auto boxAdmittance = path.airboxDuct.areaM2 / (static_cast<double>(rho) * c);
            weighted = static_cast<double>(path.throttleAdmittanceM3PerPaSecond)
                    * path.throttleIncidentAtAirbox
                + boxAdmittance * path.airboxIncidentAtThrottle;
            admittance = path.throttleAdmittanceM3PerPaSecond + boxAdmittance;
            const auto throttleEndPressure = admittance > 1.0e-15
                ? static_cast<float>(2.0 * weighted / admittance) : 0.0F;
            throttleOutgoingFromAirbox = throttleEndPressure - path.throttleIncidentAtAirbox;
            path.airboxOutgoingAtThrottle = throttleEndPressure - path.airboxIncidentAtThrottle;
            weighted = boxAdmittance * path.airboxIncidentAtInlet
                + static_cast<double>(inletAdmittance) * inletIncident;
            admittance = boxAdmittance + inletAdmittance;
            airboxPressure = admittance > 1.0e-15
                ? static_cast<float>(2.0 * weighted / admittance) : 0.0F;
            path.airboxOutgoingAtInlet = airboxPressure - path.airboxIncidentAtInlet;
        } else {
            weighted = static_cast<double>(path.throttleAdmittanceM3PerPaSecond)
                    * path.throttleIncidentAtAirbox
                + static_cast<double>(inletAdmittance) * inletIncident
                + static_cast<double>(path.airbox.admittanceM3PerPaSecond)
                    * path.airbox.incident;
            admittance = path.throttleAdmittanceM3PerPaSecond + inletAdmittance
                + path.airbox.admittanceM3PerPaSecond;
            airboxPressure = admittance > 1.0e-15
                ? static_cast<float>(2.0 * weighted / admittance) : 0.0F;
            throttleOutgoingFromAirbox = airboxPressure - path.throttleIncidentAtAirbox;
        }
        impl_->diagnostics.airboxPressurePa = std::max(
            impl_->diagnostics.airboxPressurePa, std::abs(airboxPressure));
        if (path.hasInletDuct)
            // Crossing the filter element on the way out toward the mouth.
            path.inletOutgoingAtAirbox = impl_->applyAirFilter(
                path, path.filterTowardMouthState,
                airboxPressure - path.inletIncidentAtAirbox);
        else {
            const auto towardMouth = impl_->applyAirFilter(
                path, path.filterTowardMouthState,
                airboxPressure - path.radiationIncidentAtAirbox);
            const auto radiation = path.radiation.process(towardMouth);
            impl_->diagnostics.mouthPressurePa = std::max(
                impl_->diagnostics.mouthPressurePa, std::abs(towardMouth));
            impl_->diagnostics.radiatedPressurePa = std::max(
                impl_->diagnostics.radiatedPressurePa,
                static_cast<float>(std::abs(radiation.farFieldPressurePa)));
            // ... and back through it on the reflection from the mouth.
            path.radiationIncidentAtAirbox = impl_->applyAirFilter(
                path, path.filterTowardAirboxState,
                static_cast<float>(radiation.reflectedPressurePa));
            const auto observed = path.observer.process(
                static_cast<float>(radiation.farFieldPressurePa));
            result[pathIndex].leftPa += observed.leftPa;
            result[pathIndex].rightPa += observed.rightPa;
        }
        if (path.airbox.admittanceM3PerPaSecond > 0.0F && !path.airboxDucted)
            path.airbox.incident = airboxPressure - path.airbox.incident;
        else
            path.airbox.incident = 0.0F;
        // Cross the two zero-length throttle characteristics. This is the
        // causal one-sample storage of the variable-admittance two-port.
        path.throttleIncidentAtAirbox = throttleOutgoingFromPlenum;
        path.throttleIncidentAtPlenum = throttleOutgoingFromAirbox;
    }

    for (auto& runner : impl_->runners) {
        const auto cylinderIndex = runner.cylinderIndex;
        const auto boundary = cylinderIndex < cylinders.size()
            ? cylinders[cylinderIndex] : CylinderBoundary {};
        auto sourcePressurePa = 0.0F;
        if (boundary.physical && std::isfinite(boundary.massFlowKgPerSecond)
            && boundary.densityKgPerM3 > 0.0F && boundary.soundSpeedMps > 0.0F) {
            // Positive solver intake flow leaves the runner. From the acoustic
            // line's outward convention it is therefore a negative source.
            const auto signedFlow = -boundary.massFlowKgPerSecond;
            if (!runner.meanInitialised) {
                runner.meanMassFlowKgPerSecond = signedFlow;
                runner.meanInitialised = true;
            } else {
                runner.meanMassFlowKgPerSecond += impl_->meanFlowCoefficient
                    * (signedFlow - runner.meanMassFlowKgPerSecond);
            }
            const auto perturbationKgPerSecond = signedFlow
                - runner.meanMassFlowKgPerSecond;
            const auto impedance = boundary.densityKgPerM3
                * boundary.soundSpeedMps
                / static_cast<float>(runner.duct.inletAreaM2);
            // The valve-flow telemetry is a Norton source located between the
            // cylinder control volume and the acoustic runner.  Its volume
            // velocity launches two characteristic partners; only the runner-
            // travelling half belongs in this one-way acoustic network.  Using
            // Zc*U here injected the complete two-sided source into the runner
            // and then reflected it at the valve a second time.  Besides being
            // non-passive, that doubled every intake pulse before the plenum
            // could distribute its energy and drove the monitor limiter on the
            // catalogue engines.  This is the same characteristic split used
            // by ValveFlowAcousticSource on the exhaust boundary.
            sourcePressurePa = 0.5F * impedance * perturbationKgPerSecond
                / boundary.densityKgPerM3;
            impl_->diagnostics.sourcePressurePa = std::max(
                impl_->diagnostics.sourcePressurePa, std::abs(sourcePressurePa));
            const auto acousticVolumeVelocity = impedance > 0.0F
                ? (runner.incidentAtValve - runner.reflectionState.previousOutput)
                    / impedance : 0.0F;
            const auto coefficients = ValvePortTermination::compute(
                boundary.conductanceAreaM2, signedFlow,
                acousticVolumeVelocity, boundary.densityKgPerM3,
                impedance, impl_->sampleRateHz);
            runner.outgoingAtValve = sourcePressurePa
                + ValvePortTermination::process(coefficients,
                    runner.reflectionState, runner.incidentAtValve);
        } else {
            runner.outgoingAtValve = runner.incidentAtValve;
        }
    }

    for (std::size_t pathIndex = 0; pathIndex < impl_->paths.size(); ++pathIndex) {
        auto& path = impl_->paths[pathIndex];
        if (path.hasInletDuct) {
            const auto radiation = path.radiation.process(path.inletIncidentAtMouth);
            impl_->diagnostics.mouthPressurePa = std::max(
                impl_->diagnostics.mouthPressurePa,
                std::abs(path.inletIncidentAtMouth));
            impl_->diagnostics.radiatedPressurePa = std::max(
                impl_->diagnostics.radiatedPressurePa,
                static_cast<float>(std::abs(radiation.farFieldPressurePa)));
            path.inletOutgoingAtMouth = static_cast<float>(
                radiation.reflectedPressurePa);
            const auto observed = path.observer.process(
                static_cast<float>(radiation.farFieldPressurePa));
            result[pathIndex].leftPa += observed.leftPa;
            result[pathIndex].rightPa += observed.rightPa;
            auto& duct = path.inletDuct;
            duct.forward[duct.write] = std::isfinite(path.inletOutgoingAtMouth)
                ? path.inletOutgoingAtMouth : 0.0F;
            duct.reverse[duct.write] = std::isfinite(path.inletOutgoingAtAirbox)
                ? path.inletOutgoingAtAirbox : 0.0F;
            duct.write = (duct.write + 1U) & duct.mask;
        }
        if (path.plenumBranched) {
            // A closed end returns the wave unchanged.
            auto& duct = path.plenumBranch;
            duct.forward[duct.write] = std::isfinite(path.plenumBranchOutgoingAtNode)
                ? path.plenumBranchOutgoingAtNode : 0.0F;
            duct.reverse[duct.write] = std::isfinite(path.plenumBranchIncidentAtEnd)
                ? path.plenumBranchIncidentAtEnd : 0.0F;
            duct.write = (duct.write + 1U) & duct.mask;
        }
        if (path.airboxDucted) {
            auto& duct = path.airboxDuct;
            duct.forward[duct.write] = std::isfinite(path.airboxOutgoingAtThrottle)
                ? path.airboxOutgoingAtThrottle : 0.0F;
            duct.reverse[duct.write] = std::isfinite(path.airboxOutgoingAtInlet)
                ? path.airboxOutgoingAtInlet : 0.0F;
            duct.write = (duct.write + 1U) & duct.mask;
        }
    }
    for (auto& runner : impl_->runners) {
        auto& duct = runner.duct;
        duct.forward[duct.write] = std::isfinite(runner.outgoingAtValve)
            ? runner.outgoingAtValve : 0.0F;
        duct.reverse[duct.write] = std::isfinite(runner.outgoingAtPlenum)
            ? runner.outgoingAtPlenum : 0.0F;
        duct.write = (duct.write + 1U) & duct.mask;
    }
    return result;
}

bool AcousticIntakeNetwork::valid() const noexcept {
    return impl_ && impl_->configured;
}

std::size_t AcousticIntakeNetwork::runnerCount() const noexcept {
    return impl_ ? impl_->runners.size() : 0U;
}

std::size_t AcousticIntakeNetwork::pathCount() const noexcept {
    return impl_ ? impl_->paths.size() : 0U;
}

AcousticIntakeNetwork::Diagnostics
AcousticIntakeNetwork::diagnostics() const noexcept {
    return impl_ ? impl_->diagnostics : Diagnostics {};
}

} // namespace enginelab
