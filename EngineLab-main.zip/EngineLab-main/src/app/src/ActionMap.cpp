#include <enginelab/app/ActionMap.hpp>

#include <juce_core/juce_core.h>
#include <algorithm>

namespace enginelab {
namespace {
[[nodiscard]] juce::KeyPress letter(juce::juce_wchar value) {
    return { static_cast<int>(value), {}, value };
}
[[nodiscard]] juce::KeyPress command(juce::juce_wchar value) {
    return { static_cast<int>(value), juce::ModifierKeys::commandModifier, 0 };
}
[[nodiscard]] int upper(int keyCode) noexcept {
    return keyCode >= 'a' && keyCode <= 'z' ? keyCode - 'a' + 'A' : keyCode;
}
}

ActionMap::ActionMap() : ActionMap(DefaultsOnly {}) {
    load();
}

ActionMap::ActionMap(DefaultsOnly)
    : entries_ {{
        { "ignition", letter('A') }, { "starter", letter('S') }, { "dyno", letter('D') },
        { "dyno_hold", letter('H') }, { "fullscreen", letter('F') }, { "dyno_stats", letter('I') },
        { "pause", letter('P') }, { "next_screen", juce::KeyPress(juce::KeyPress::tabKey) },
        { "shift_up", juce::KeyPress(juce::KeyPress::upKey) },
        { "shift_down", juce::KeyPress(juce::KeyPress::downKey) },
        { "brake", juce::KeyPress(juce::KeyPress::leftKey) },
        { "throttle_idle", letter('Q') }, { "throttle_quarter", letter('W') },
        { "throttle_half", letter('E') }, { "throttle_full", letter('R') },
        { "time_quarter", letter('1') }, { "time_half", letter('2') },
        { "time_normal", letter('3') }, { "time_double", letter('4') },
        { "time_quadruple", letter('5') }, { "layer_up", letter('M') },
        { "layer_down", letter(',') }, { "exhaust_preset", letter(';') },
        { "clutch_hold", letter('Y') }, { "clutch_decrease", letter('T') }, { "clutch_increase", letter('U') },
        { "wheel_dyno_rpm", letter('G') }, { "wheel_volume", letter('Z') },
        { "wheel_convolution", letter('X') }, { "wheel_high_gain", letter('C') },
        { "wheel_low_noise", letter('V') }, { "wheel_high_noise", letter('B') },
        { "wheel_combustion", letter('J') }, { "wheel_exhaust", letter('K') },
        { "wheel_intake", letter('L') }, { "wheel_mechanical", letter('O') },
        { "wheel_simulation_rate", letter('N') },
        { "wheel_fine_throttle", juce::KeyPress(juce::KeyPress::spaceKey) },
        // Every letter A-Z is already bound, hence a digit.
        { "dyno_ramp", letter('6') },
        { "ab_switch", letter('7') },
        // Next to the brake: the cruise control sets or cancels.
        { "cruise", juce::KeyPress(juce::KeyPress::rightKey) },
        { "automatic_gearbox", letter('8') },
        { "datalog", letter('9') },
        // A truck's engine brake: each press takes the switch a stage up,
        // and off after the last.
        { "engine_brake", letter('0') },
        // The active exhaust valve: automatic, shut, open, automatic...
        { "exhaust_valve", letter('-') },
        // Held: the nitrous kit's push button (with the kit armed).
        { "nitrous", letter('=') },
        // Chords on keys no held control reads (M is the layer step, P the
        // pause), so holding them drives nothing.
        { "more_menu", command('M') },
        { "engine_menu", command('P') }
    }} {}

bool ActionMap::sameEvent(const juce::KeyPress& left, const juce::KeyPress& right) noexcept {
    if (upper(left.getKeyCode()) != upper(right.getKeyCode())) return false;
    const auto strip = [](const juce::KeyPress& key) {
        return key.getModifiers().withoutMouseButtons().withoutFlags(juce::ModifierKeys::shiftModifier);
    };
    return strip(left) == strip(right);
}

bool ActionMap::reserved(const juce::KeyPress& key) noexcept {
    const auto code = key.getKeyCode();
    if (code == juce::KeyPress::escapeKey || code == juce::KeyPress::returnKey
        || (code >= juce::KeyPress::F1Key && code <= juce::KeyPress::F12Key))
        return true;
    const auto mods = key.getModifiers();
    return upper(code) == 'S' && mods.isCommandDown() && !mods.isAltDown();
}

bool ActionMap::matches(AppAction action, const juce::KeyPress& key) const noexcept {
    const auto& binding = entries_[static_cast<std::size_t>(action)].key;
    if (key.getKeyCode() != binding.getKeyCode()) return false;
    auto keyModifiers = key.getModifiers().withoutMouseButtons();
    const auto bindingModifiers = binding.getModifiers().withoutMouseButtons();
    // Shift doubles as the momentary clutch (see MainComponent), and JUCE stamps
    // the Shift flag onto every key event generated while it is held. With an
    // exact modifier comparison that made holding the clutch suppress every
    // unmodified control -- including the gear-shift keys, so "hold the clutch
    // and you cannot change gear". Unless a binding deliberately uses Shift,
    // ignore the Shift flag here, matching the subset semantics isDown() already
    // uses for held controls. Ctrl/Alt/Cmd stay exact so distinct modified
    // bindings and OS shortcuts are unaffected.
    if (!bindingModifiers.isShiftDown())
        keyModifiers = keyModifiers.withoutFlags(juce::ModifierKeys::shiftModifier);
    return keyModifiers == bindingModifiers;
}

bool ActionMap::isDown(AppAction action) const noexcept {
    const auto& binding = entries_[static_cast<std::size_t>(action)].key;
    const auto required = binding.getModifiers();
    const auto current = juce::ModifierKeys::getCurrentModifiersRealtime();
    return juce::KeyPress::isKeyCurrentlyDown(binding.getKeyCode())
        && (!required.isShiftDown() || current.isShiftDown())
        && (!required.isCtrlDown() || current.isCtrlDown())
        && (!required.isAltDown() || current.isAltDown())
        && (!required.isCommandDown() || current.isCommandDown());
}

juce::String ActionMap::toJson() const {
    auto* root = new juce::DynamicObject;
    for (const auto& entry : entries_) root->setProperty(entry.id, entry.key.getTextDescription());
    return juce::JSON::toString(juce::var(root), true);
}

bool ActionMap::fromJson(const juce::String& json, juce::String& error) {
    const auto parsed = juce::JSON::parse(json);
    const auto* object = parsed.getDynamicObject();
    if (object == nullptr) { error = "The document must be a JSON object."; return false; }
    const auto& properties = object->getProperties();
    for (int propertyIndex = 0; propertyIndex < properties.size(); ++propertyIndex) {
        const auto propertyName = properties.getName(propertyIndex).toString();
        const auto known = std::any_of(entries_.begin(), entries_.end(), [&propertyName](const Entry& entry) {
            return propertyName == entry.id;
        });
        if (!known) { error = "Unknown action: " + propertyName; return false; }
    }
    auto candidate = entries_;
    for (auto& entry : candidate) {
        const auto value = object->getProperty(entry.id);
        if (value.isVoid()) continue;
        if (!value.isString()) { error = juce::String(entry.id) + " must be a string."; return false; }
        const auto key = juce::KeyPress::createFromDescription(value.toString());
        if (!key.isValid()) { error = "Invalid key binding for " + juce::String(entry.id); return false; }
        if (reserved(key)) {
            error = "Reserved key binding for " + juce::String(entry.id);
            return false;
        }
        entry.key = key;
    }
    for (std::size_t left = 0; left < candidate.size(); ++left) {
        for (std::size_t right = left + 1; right < candidate.size(); ++right) {
            if (sameEvent(candidate[left].key, candidate[right].key)) {
                error = "Conflict between " + juce::String(candidate[left].id) + " and " + juce::String(candidate[right].id);
                return false;
            }
        }
    }
    entries_ = std::move(candidate);
    error.clear();
    return true;
}

juce::File ActionMap::settingsFile() {
    return juce::File::getSpecialLocation(juce::File::userApplicationDataDirectory)
        .getChildFile("EngineLab").getChildFile("keybindings.json");
}

void ActionMap::load() {
    const auto file = settingsFile();
    if (!file.existsAsFile()) { save(); return; }
    juce::String error;
    (void)fromJson(file.loadFileAsString(), error);
}

void ActionMap::save() const {
    const auto file = settingsFile();
    (void)file.getParentDirectory().createDirectory();
    (void)file.replaceWithText(toJson());
}

juce::String ActionMap::shortcut(AppAction action) const {
    return entries_[static_cast<std::size_t>(action)].key.getTextDescription();
}

} // namespace enginelab
