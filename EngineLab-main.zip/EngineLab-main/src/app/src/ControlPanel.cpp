#include <enginelab/app/ControlPanel.hpp>

#include <enginelab/app/Theme.hpp>
#include <algorithm>
#include <array>
#include <cmath>
#include <utility>

namespace enginelab::ui {
namespace {
[[nodiscard]] juce::String signedValue(double value, int decimals, const juce::String& suffix) {
    if (std::abs(value) < 0.5 * std::pow(10.0, -decimals))
        return utf8("\xc2\xb1") + juce::String(0.0, decimals) + suffix;
    return (value > 0.0 ? "+" : utf8("\xe2\x88\x92")) + juce::String(std::abs(value), decimals) + suffix;
}
} // namespace

juce::String ControlPanel::percentLabel(int percent) { return juce::String(percent) + " %"; }

ControlPanel::ControlPanel() {
    ignition.setClickingTogglesState(true);
    ignition.setTooltip(utf8("Ignition and injection on or off"));
    starter.setTooltip(utf8("Hold to crank the engine"));
    dyno.setTooltip(utf8("Automatic dyno run (H holds the engine speed, 6 arms the continuous ramp)"));
    for (auto* button : { &ignition, &starter, &dyno }) addAndMakeVisible(*button);

    throttle.setSliderStyle(juce::Slider::LinearVertical);
    throttle.setTextBoxStyle(juce::Slider::NoTextBox, true, 0, 0);
    throttle.setRange(0.0, 100.0, 1.0);
    throttle.setWantsKeyboardFocus(false);
    throttle.setMouseClickGrabsKeyboardFocus(false);
    throttle.setScrollWheelEnabled(false);
    throttle.setSliderSnapsToMousePosition(true);
    throttle.setMouseCursor(juce::MouseCursor::UpDownResizeCursor);
    throttle.setTooltip(utf8("Throttle. Drag, or hold Q / W / E / R for a momentary opening"));
    throttle.addListener(this);
    addAndMakeVisible(throttle);

    const std::array<std::pair<ActionButton*, double>, 4> presets {{
        { &throttleIdle, 0.01 }, { &throttleLow, 0.10 }, { &throttleMid, 0.20 }, { &throttleFull, 1.0 } }};
    for (const auto& [button, fraction] : presets) {
        button->onClick = [this, value = fraction] { if (onThrottlePreset) onThrottlePreset(value); };
        button->setTooltip(utf8("Click to set the throttle; hold the key for a momentary opening"));
        addAndMakeVisible(*button);
    }

    gearDown.setTooltip(utf8("Shift down a gear"));
    gearUp.setTooltip(utf8("Shift up a gear"));
    brake.setTooltip(utf8("Hold to brake: the pressure builds up while held (slower with Space held), "
                          "and lets go at once. Cancels the cruise control"));
    clutch.setTooltip(utf8("Hold to press the clutch pedal (Shift does the same). A dual-clutch gearbox has no "
                           "pedal and ignores it"));
    cruise.setTooltip(utf8("Cruise control: holds the road speed you have when you set it (from 30 km/h). "
                           "The pedal overtakes it; the brake, the clutch or neutral cancel it"));
    resetTrip.setTooltip(utf8("Starts the trip computer again: distance, fuel and average consumption"));
    automatic.setTooltip(utf8("Automatic gearbox: it changes gear from your pedal, early with a light foot, "
                              "near the limiter flat out, and kicks down. A gear key takes it back to manual"));
    for (auto* button : { &gearDown, &gearUp, &brake, &clutch, &cruise, &resetTrip, &automatic })
        addAndMakeVisible(*button);
    engineBrake.setTooltip(utf8("Engine brake (compression release): pick how many cylinders brake (its key "
                                "steps through them). It holds in gear with your foot off the pedal and the "
                                "clutch in, cuts their fuel, and lets go near idle and in neutral"));
    engineBrake.onClick = [this] { openEngineBrakeMenu(); };
    addChildComponent(engineBrake);
    exhaustValve.setTooltip(utf8("Active exhaust valve: automatic opens it above the engine speed or the throttle "
                                 "set in the exhaust designer; shut and open hold it (its key steps through "
                                 "them). Lit while it is open"));
    exhaustValve.onClick = [this] { openExhaustValveMenu(); };
    addChildComponent(exhaustValve);
    nitrous.setTooltip(utf8("Nitrous kit: a click arms or disarms it. Armed, it sprays at the throttle and "
                            "engine speeds set in the Equipment window (and, with a push button, while its key "
                            "is held). Lit while it sprays"));
    nitrous.onClick = [this] { if (onNitrousArm) onNitrousArm(); };
    addChildComponent(nitrous);
    antiLag.setTooltip(utf8("Anti-lag: a click switches it on or off. On, it keeps the turbo spinning when you "
                            "lift off, keeping the share of the engine braking set in the Equipment window. Lit "
                            "while it works"));
    antiLag.onClick = [this] { if (onAntiLagToggle) onAntiLagToggle(); };
    addChildComponent(antiLag);

    prepareSlider(afrTrim.slider, -3.0, 3.0, 0.1, 0.0);
    afrTrim.slider.setDoubleClickReturnValue(true, 0.0);
    afrTrim.format = [](double value) { return signedValue(value, 1, {}); };
    prepareSlider(sparkTrim.slider, -15.0, 15.0, 0.1, 0.0);
    sparkTrim.slider.setDoubleClickReturnValue(true, 0.0);
    sparkTrim.format = [](double value) { return signedValue(value, 1, utf8("\xc2\xb0")); };
    addChildComponent(afrTrim);
    addChildComponent(sparkTrim);
}

ControlPanel::~ControlPanel() { throttle.removeListener(this); }

void ControlPanel::setKeyCaps(const ActionMap& actions) {
    const auto cap = [&actions](AppAction action) { return keyCapText(actions.shortcut(action)); };
    ignition.setKeyCap(cap(AppAction::ignition));
    starter.setKeyCap(cap(AppAction::starter));
    dyno.setKeyCap(cap(AppAction::dyno));
    throttleIdle.setKeyCap(cap(AppAction::throttleIdle));
    throttleLow.setKeyCap(cap(AppAction::throttleQuarter));
    throttleMid.setKeyCap(cap(AppAction::throttleHalf));
    throttleFull.setKeyCap(cap(AppAction::throttleFull));
    gearDown.setKeyCap(cap(AppAction::shiftDown));
    gearUp.setKeyCap(cap(AppAction::shiftUp));
    brake.setKeyCap(cap(AppAction::brake));
    clutch.setKeyCap(cap(AppAction::clutchHold));
    cruise.setKeyCap(cap(AppAction::cruise));
    automatic.setKeyCap(cap(AppAction::automaticGearbox));
    engineBrake.setKeyCap(cap(AppAction::engineBrake));
    exhaustValve.setKeyCap(cap(AppAction::exhaustValve));
    nitrous.setKeyCap(cap(AppAction::nitrous));
}

void ControlPanel::openEngineBrakeMenu() {
    if (engineBrakeStages_ == 0) return;
    juce::PopupMenu menu;
    menu.addItem(1, "Off", true, engineBrakeStage_ == 0);
    for (std::uint32_t stage = 1; stage <= engineBrakeStages_; ++stage) {
        // As the simulator rounds it (EngineSimulator, the brake's stage).
        const auto braking = std::lround(static_cast<double>(engineBrakeCylinders_) * stage / engineBrakeStages_);
        menu.addItem(static_cast<int>(stage) + 1,
                     "Stage " + juce::String(stage) + " of " + juce::String(engineBrakeStages_)
                         + (engineBrakeCylinders_ > 0 ? ": " + juce::String(braking) + " of "
                                                            + juce::String(engineBrakeCylinders_) + " cylinders"
                                                      : juce::String()),
                     true, engineBrakeStage_ == stage);
    }
    menu.showMenuAsync(juce::PopupMenu::Options {}.withTargetComponent(&engineBrake)
                           .withMinimumWidth(engineBrake.getWidth()),
        [safe = juce::Component::SafePointer<ControlPanel>(this)](int result) {
            if (safe == nullptr || result <= 0) return;
            const auto stage = static_cast<std::uint32_t>(result - 1);
            if (safe->onEngineBrakeStage) safe->onEngineBrakeStage(stage);
        });
}

void ControlPanel::setEngineBrake(std::uint32_t stages, std::uint32_t cylinders) {
    engineBrakeStages_ = stages;
    engineBrakeCylinders_ = cylinders;
    engineBrake.setVisible(stages > 0);
    setEngineBrakeStage(0);
    relayout();
}

std::uint32_t ControlPanel::nextEngineBrakeStage() const noexcept {
    return engineBrakeStages_ == 0 || engineBrakeStage_ >= engineBrakeStages_ ? 0U : engineBrakeStage_ + 1U;
}

void ControlPanel::setEngineBrakeStage(std::uint32_t stage) {
    engineBrakeStage_ = std::min(stage, engineBrakeStages_);
    const auto text = engineBrakeStage_ == 0 ? juce::String("Engine brake off")
        : "Engine brake " + juce::String(engineBrakeStage_) + "/" + juce::String(engineBrakeStages_);
    if (engineBrake.getButtonText() != text) engineBrake.setButtonText(text);
}

void ControlPanel::openExhaustValveMenu() {
    juce::PopupMenu menu;
    menu.addItem(1, "Automatic", true, exhaustValveMode_ == ExhaustValveMode::automatic);
    menu.addItem(2, "Shut", true, exhaustValveMode_ == ExhaustValveMode::closed);
    menu.addItem(3, "Open", true, exhaustValveMode_ == ExhaustValveMode::open);
    menu.showMenuAsync(juce::PopupMenu::Options {}.withTargetComponent(&exhaustValve)
                           .withMinimumWidth(exhaustValve.getWidth()),
        [safe = juce::Component::SafePointer<ControlPanel>(this)](int result) {
            if (safe == nullptr || result <= 0) return;
            const auto mode = result == 2 ? ExhaustValveMode::closed
                : result == 3 ? ExhaustValveMode::open : ExhaustValveMode::automatic;
            if (safe->onExhaustValveMode) safe->onExhaustValveMode(mode);
        });
}

void ControlPanel::setExhaustValveFitted(bool fitted) {
    if (exhaustValve.isVisible() == fitted) return;
    exhaustValve.setVisible(fitted);
    relayout();
}

ExhaustValveMode ControlPanel::nextExhaustValveMode() const noexcept {
    return exhaustValveMode_ == ExhaustValveMode::automatic ? ExhaustValveMode::closed
        : exhaustValveMode_ == ExhaustValveMode::closed ? ExhaustValveMode::open
        : ExhaustValveMode::automatic;
}

void ControlPanel::setExhaustValveMode(ExhaustValveMode mode) {
    exhaustValveMode_ = mode;
    const auto text = juce::String("Exhaust valve ")
        + (mode == ExhaustValveMode::closed ? "shut" : mode == ExhaustValveMode::open ? "open" : "auto");
    if (exhaustValve.getButtonText() != text) exhaustValve.setButtonText(text);
}

void ControlPanel::setNitrousFitted(bool fitted) {
    if (nitrous.isVisible() == fitted) return;
    nitrous.setVisible(fitted);
    relayout();
}

void ControlPanel::setNitrousArmed(bool armed) {
    nitrousArmed_ = armed;
    const auto text = juce::String(armed ? "Nitrous armed" : "Nitrous off");
    if (nitrous.getButtonText() != text) nitrous.setButtonText(text);
}

void ControlPanel::setAntiLag(bool carried, bool on) {
    const auto text = juce::String(on ? "Anti-lag on" : "Anti-lag off");
    if (antiLag.getButtonText() != text) antiLag.setButtonText(text);
    if (antiLag.isVisible() == carried) return;
    antiLag.setVisible(carried);
    relayout();
}

void ControlPanel::setDiesel(bool diesel) {
    afrTrim.setName(diesel ? utf8("Smoke limit trim (+ = less fuel)") : utf8("AFR trim"));
    afrTrim.slider.setTooltip(diesel ? utf8("Offset of the smoke-limit AFR table")
                                     : utf8("Offset added to the target AFR table"));
}

void ControlPanel::refresh(const DashboardModel& model) {
    const auto running = model.dynoRunning;
    dyno.setButtonText(running
        ? (model.state.dynoPreparing ? utf8("Cancel prep")
            : (model.state.dynoMode == DynoMode::hold ? utf8("End hold") : utf8("Cancel dyno")))
        : utf8("Start dyno"));
    dyno.setToggleState(running, juce::dontSendNotification);
    for (juce::Component* control : { static_cast<juce::Component*>(&ignition),
                                       static_cast<juce::Component*>(&starter),
                                       static_cast<juce::Component*>(&throttle),
                                       static_cast<juce::Component*>(&throttleIdle),
                                       static_cast<juce::Component*>(&throttleLow),
                                       static_cast<juce::Component*>(&throttleMid),
                                       static_cast<juce::Component*>(&throttleFull),
                                       static_cast<juce::Component*>(&afrTrim),
                                       static_cast<juce::Component*>(&sparkTrim) })
        control->setEnabled(!running);
    for (auto* button : { &gearDown, &gearUp, &brake, &clutch, &cruise, &automatic, &engineBrake })
        button->setEnabled(!running);

    // The speedometer and trip computer. Nothing here repaints unless a
    // figure as shown changed.
    using units::Quantity;
    const auto& state = model.state;
    const auto& unit = model.units;
    const auto speed = unit.value(Quantity::speed, std::abs(state.vehicleSpeedMps), 0);
    const auto speedUnit = unit.symbol(Quantity::speed);
    const auto gear = juce::String("gear ") + gearName(state.gear, state.continuouslyVariable);
    // Standing still, L/100 km has no meaning: the flow is shown instead.
    const auto consumption = std::abs(state.vehicleSpeedMps) >= 1.0
        ? unit.text(Quantity::fuelConsumption, state.instantFuelEconomyLitresPer100Km)
        : unit.value(Quantity::fuelVolume, state.fuelFlowLitresPerHour, 2) + " "
            + unit.symbol(Quantity::fuelVolume) + "/h";
    const auto detail = gear + utf8("  \xc2\xb7  ") + consumption;
    const auto trip = "trip " + unit.text(Quantity::distance, state.tripDistanceM,
                                          unit.preferences.of(Quantity::distance).id == "m" ? 0 : 1)
        + utf8("  \xc2\xb7  ")
        + (state.tripFuelEconomyLitresPer100Km > 0.0
            ? unit.text(Quantity::fuelConsumption, state.tripFuelEconomyLitresPer100Km)
            : utf8("\xe2\x80\x94"));
    if (speed != speedText_ || speedUnit != speedUnit_ || detail != driveDetail_ || trip != tripDetail_) {
        speedText_ = speed;
        speedUnit_ = speedUnit;
        driveDetail_ = detail;
        tripDetail_ = trip;
        repaint(speedValue_.getUnion(tripText_).getSmallestIntegerContainer().expanded(2));
    }
    brake.setEngaged(state.brakePressure > 0.01);
    clutch.setEngaged(state.clutchPressure < 0.5 && state.gear != -1);
    cruise.setEngaged(state.cruiseEngaged);
    automatic.setEngaged(state.automaticShifting);
    // Lit while it holds; its stage stays shown while it waits for the
    // pedal to lift or the speed to rise.
    engineBrake.setEngaged(state.engineBrakeCylinders > 0);
    exhaustValve.setEngaged(state.exhaustValveCount > 0 && state.exhaustValveOpening > 0.5);
    nitrous.setEngaged(state.nitrousSpraying);
    antiLag.setEngaged(state.antiLagActive);
    const auto cruiseText = state.cruiseEngaged
        ? "Cruise " + unit.value(Quantity::speed, state.cruiseSetSpeedMps, 0)
        : juce::String("Cruise");
    if (cruise.getButtonText() != cruiseText) cruise.setButtonText(cruiseText);
}

void ControlPanel::sliderValueChanged(juce::Slider*) {
    repaint(throttleValue_.getSmallestIntegerContainer());
}

void ControlPanel::paint(juce::Graphics& g) {
    g.fillAll(colours::panel);
    g.setColour(colours::line);
    g.fillRect(getLocalBounds().removeFromRight(1));
    for (const auto rule : groupRules_)
        g.fillRect(0.0F, rule, static_cast<float>(getWidth() - 1), 1.0F);
    drawSectionLabel(g, engineLabel_, "Engine");
    drawSectionLabel(g, throttleLabel_, "Throttle");
    drawSectionLabel(g, driveLabel_, "Drive");

    // The speed in big figures, its unit beside it.
    const auto bigFont = monoFont(30.0F);
    const auto speedWidth = juce::GlyphArrangement::getStringWidth(bigFont, speedText_);
    g.setColour(colours::text);
    g.setFont(bigFont);
    g.drawText(speedText_, speedValue_, juce::Justification::centredLeft, false);
    g.setColour(colours::label);
    g.setFont(uiFont(14.0F));
    g.drawText(speedUnit_, speedValue_.withTrimmedLeft(speedWidth + 5.0F).withTrimmedTop(8.0F),
               juce::Justification::centredLeft, true);
    auto lines = tripText_;
    g.setColour(colours::muted);
    g.setFont(uiFont(14.5F));
    g.drawFittedText(driveDetail_, lines.removeFromTop(lines.getHeight() * 0.5F).toNearestInt(),
                     juce::Justification::centredLeft, 1, 0.8F);
    g.setColour(colours::label);
    g.drawFittedText(tripDetail_, lines.toNearestInt(), juce::Justification::centredLeft, 1, 0.8F);

    // The throttle's opening, and the fader's scale on its left.
    const auto opening = fixed(throttle.getValue(), 0);
    g.setColour(throttle.isEnabled() ? colours::text : colours::muted);
    g.setFont(bigFont);
    g.drawText(opening, throttleValue_, juce::Justification::centredLeft, false);
    g.setColour(colours::label);
    g.setFont(uiFont(14.0F));
    g.drawText("%", throttleValue_.withTrimmedLeft(juce::GlyphArrangement::getStringWidth(bigFont, opening) + 5.0F)
                        .withTrimmedTop(8.0F),
               juce::Justification::centredLeft, false);
    g.setFont(monoFont(11.0F, false));
    // As the slider places its thumb: its travel is inset by the thumb's radius.
    const auto travel = throttle.getBounds().toFloat().reduced(0.0F, 6.0F);
    for (const auto mark : { 0, 20, 50, 100 }) {
        const auto level = std::round(travel.getBottom() - travel.getHeight() * static_cast<float>(mark) * 0.01F);
        const auto box = juce::Rectangle<float>(travel.getX() - 32.0F, level - 7.0F, 24.0F, 14.0F);
        g.drawText(juce::String(mark), box, juce::Justification::centredRight, false);
        g.fillRect(box.getRight() + 3.0F, level, 4.0F, 1.0F);
    }
    drawSectionLabel(g, trimsHeader_, juce::String("Calibration trims  ") + (trimsOpen_ ? utf8("\xe2\x80\x93") : "+"));
}

void ControlPanel::mouseUp(const juce::MouseEvent& event) {
    if (!trimsHeader_.contains(event.position)) return;
    trimsOpen_ = !trimsOpen_;
    afrTrim.setVisible(trimsOpen_);
    sparkTrim.setVisible(trimsOpen_);
    relayout();
}

int ControlPanel::arrange(bool apply) {
    const auto place = [apply](juce::Component& component, juce::Rectangle<int> bounds) {
        if (apply) component.setBounds(bounds);
    };
    const auto mark = [apply](juce::Rectangle<float>& member, juce::Rectangle<int> bounds) {
        if (apply) member = bounds.toFloat();
    };
    if (apply) groupRules_.clear();
    auto area = getLocalBounds().withHeight(100000).reduced(14, 0);
    // A group: a hairline above it (but the first), its heading, its controls.
    const auto startGroup = [&area, &mark, apply, this](juce::Rectangle<float>& label) {
        if (area.getY() > 0 && apply) groupRules_.push_back(static_cast<float>(area.getY()));
        area.removeFromTop(12);
        mark(label, area.removeFromTop(18));
        area.removeFromTop(6);
    };

    startGroup(engineLabel_);
    place(ignition, area.removeFromTop(36));
    area.removeFromTop(6);
    place(starter, area.removeFromTop(36));
    area.removeFromTop(6);
    place(dyno, area.removeFromTop(36));
    area.removeFromTop(14);

    startGroup(throttleLabel_);
    auto throttleRow = area.removeFromTop(156);
    throttleRow.removeFromLeft(34); // the fader's scale
    place(throttle, throttleRow.removeFromLeft(38));
    throttleRow.removeFromLeft(12);
    mark(throttleValue_, throttleRow.removeFromTop(36));
    auto presets = throttleRow.removeFromBottom(64);
    auto topPresets = presets.removeFromTop(29);
    auto bottomPresets = presets.removeFromBottom(29);
    const auto half = (topPresets.getWidth() - 6) / 2;
    place(throttleIdle, topPresets.removeFromLeft(half));
    place(throttleLow, topPresets.removeFromRight(half));
    place(throttleMid, bottomPresets.removeFromLeft(half));
    place(throttleFull, bottomPresets.removeFromRight(half));
    area.removeFromTop(14);

    startGroup(driveLabel_);
    {
        // The speed, and the trip's reset on its right.
        auto row = area.removeFromTop(34);
        const auto resetWidth = resetTrip.idealWidth();
        place(resetTrip, row.removeFromRight(resetWidth).withSizeKeepingCentre(resetWidth, 26));
        mark(speedValue_, row);
    }
    mark(tripText_, area.removeFromTop(36));
    area.removeFromTop(6);
    const auto pair = [&area, &place](ActionButton& left, ActionButton& right) {
        auto row = area.removeFromTop(30);
        const auto halfWidth = (row.getWidth() - 6) / 2;
        place(left, row.removeFromLeft(halfWidth));
        place(right, row.removeFromRight(halfWidth));
        area.removeFromTop(6);
    };
    pair(gearDown, gearUp);
    pair(automatic, cruise);
    pair(brake, clutch);
    for (auto* fitted : { &engineBrake, &exhaustValve, &nitrous, &antiLag }) {
        if (!fitted->isVisible()) continue;
        place(*fitted, area.removeFromTop(30));
        area.removeFromTop(6);
    }
    area.removeFromTop(8);

    if (apply) groupRules_.push_back(static_cast<float>(area.getY()));
    area.removeFromTop(8);
    mark(trimsHeader_, area.removeFromTop(22));
    area.removeFromTop(4);
    if (trimsOpen_) {
        place(afrTrim, area.removeFromTop(SliderRow::preferredHeight));
        area.removeFromTop(10);
        place(sparkTrim, area.removeFromTop(SliderRow::preferredHeight));
    }
    return area.getY() + 12;
}

void ControlPanel::resized() { (void)arrange(true); }

int ControlPanel::preferredHeight() const { return const_cast<ControlPanel*>(this)->arrange(false); }

void ControlPanel::relayout() {
    resized();
    repaint();
    if (onLayoutChanged) onLayoutChanged();
}

} // namespace enginelab::ui
