#include <enginelab/app/AudioWorkshopWindow.hpp>
#include <enginelab/app/Theme.hpp>
#include <enginelab/audio/LoopPackExporter.hpp>

#include <algorithm>
#include <array>
#include <atomic>
#include <cctype>
#include <cmath>
#include <memory>
#include <string>
#include <string_view>
#include <thread>
#include <utility>

namespace enginelab {
namespace {

[[nodiscard]] juce::String utf8(std::string_view value) {
    return juce::String::fromUTF8(
        value.data(), static_cast<int>(value.size()));
}

[[nodiscard]] std::string fileSlug(std::string_view source) {
    std::string result;
    result.reserve(source.size());
    bool lastWasSeparator = false;
    for (const auto character : source) {
        const auto byte = static_cast<unsigned char>(character);
        if (std::isalnum(byte) != 0) {
            result.push_back(static_cast<char>(std::tolower(byte)));
            lastWasSeparator = false;
        } else if (!result.empty() && !lastWasSeparator) {
            result.push_back('-');
            lastWasSeparator = true;
        }
    }
    while (!result.empty() && result.back() == '-')
        result.pop_back();
    return result.empty() ? "engine" : result;
}

[[nodiscard]] std::filesystem::path fileSystemPath(
    const juce::File& file) {
    const auto text = file.getFullPathName();
    const auto* encoded = text.toRawUTF8();
    return std::filesystem::path(std::u8string(
        reinterpret_cast<const char8_t*>(encoded)));
}

[[nodiscard]] juce::String displayPath(
    const std::filesystem::path& path) {
    const auto encoded = path.u8string();
    return juce::String::fromUTF8(
        reinterpret_cast<const char*>(encoded.data()),
        static_cast<int>(encoded.size()));
}

} // namespace

OfflineAudioMix effectiveAudioWorkshopMix(
    const OfflineAudioMix& baseMix,
    const AudioWorkshopAvailability& availability,
    const AudioWorkshopLayerSwitches& switches) noexcept {
    auto mix = baseMix;
    if (!availability.measuredImpulseResponseAvailable)
        mix.convolution = 0.0;
    if (availability.compiledIntakeTopology)
        mix.lowFrequencyNoise = 0.0;
    if (availability.compiledExhaustTopology) {
        mix.highFrequencyNoise = 0.0;
        mix.combustionGain = 0.0;
    }

    auto anySolo = false;
    for (std::size_t layer = 0;
         layer < switches.solo.size(); ++layer) {
        const auto available =
            layer != 0
            || !availability.compiledExhaustTopology;
        anySolo = anySolo
            || (available && switches.solo[layer]);
    }
    const auto audible = [&](std::size_t layer) {
        const auto available =
            layer != 0
            || !availability.compiledExhaustTopology;
        return available
            && !switches.muted[layer]
            && (!anySolo || switches.solo[layer]);
    };
    if (!audible(0)) mix.combustionGain = 0.0;
    if (!audible(1)) mix.exhaustGain = 0.0;
    if (!audible(2)) mix.intakeGain = 0.0;
    if (!audible(3)) mix.mechanicalGain = 0.0;
    return mix;
}

AudioPhysicsSettings audioPhysicsSettingsFor(
    const EngineConfig& engine) noexcept {
    return {
        engine.combustionCalibration.cycleVariationCoefficientOfVariation,
        engine.combustionCalibration.cycleVariationCorrelation,
        engine.exhaustAfterfire.enabled,
        engine.ignition.limiterKeepsFuel,
        engine.exhaustAfterfire.ignitionTemperatureK,
        engine.exhaustAfterfire.reactionTimeConstantSeconds,
        engine.exhaustAfterfire.reactionEfficiency,
        engine.exhaustAfterfire.overrunSparkAdvanceDegrees,
        engine.exhaustAfterfire.pocketMixingTimeSeconds,
        engine.exhaustAfterfire.overrunSparkCutFraction,
    };
}

void applyAudioPhysicsSettings(
    EngineConfig& engine, const AudioPhysicsSettings& settings) noexcept {
    const auto enablingFlatInduction = settings.afterfireEnabled
        && engine.exhaustAfterfire.inductionActivationTemperatureK == 0.0
        && engine.exhaustAfterfire.inductionPressureExponent == 0.0
        && engine.exhaustAfterfire.inductionEquivalenceRatioExponent == 0.0;
    engine.combustionCalibration.cycleVariationCoefficientOfVariation =
        settings.cycleVariationCoefficientOfVariation;
    engine.combustionCalibration.cycleVariationCorrelation =
        settings.cycleVariationCorrelation;
    engine.exhaustAfterfire.strategy = settings.afterfireEnabled
        ? ExhaustAfterfireStrategy::lateSparkOverrun
        : ExhaustAfterfireStrategy::cleanDfco;
    engine.exhaustAfterfire.enabled = afterfireRetainsFuel(
        engine.exhaustAfterfire.strategy);
    engine.ignition.limiterKeepsFuel = settings.limiterKeepsFuel;
    engine.exhaustAfterfire.ignitionTemperatureK =
        settings.afterfireIgnitionTemperatureK;
    engine.exhaustAfterfire.reactionTimeConstantSeconds =
        settings.afterfireReactionTimeSeconds;
    engine.exhaustAfterfire.reactionEfficiency =
        settings.afterfireEfficiency;
    engine.exhaustAfterfire.overrunSparkAdvanceDegrees =
        settings.overrunSparkAdvanceDegrees;
    engine.exhaustAfterfire.pocketMixingTimeSeconds =
        settings.pocketMixingTimeSeconds;
    engine.exhaustAfterfire.overrunSparkCutFraction =
        settings.overrunSparkCutFraction;
    if (enablingFlatInduction) {
        // A flat legacy induction timer is not what the late-spark profile
        // was measured with: enabling it installs the schema-8
        // thermochemical correlation, so ignition depends on the local
        // temperature, pressure and mixture.
        engine.exhaustAfterfire.inductionActivationTemperatureK = 13'340.0;
        engine.exhaustAfterfire.inductionPressureExponent = 0.989;
        engine.exhaustAfterfire.inductionEquivalenceRatioExponent = -0.577;
        engine.exhaustAfterfire.inductionDecayTimeSeconds = 0.008;
    }
}

AudioPhysicsTelemetry audioPhysicsTelemetryFor(
    const EngineConfig& engine, const EngineState& state) noexcept {
    AudioPhysicsTelemetry telemetry;
    const auto cylinderCount = std::min(
        engine.cylinders.size(), state.cylinderStates.size());
    if (cylinderCount != 0) {
        telemetry.minimumCycleMultiplier =
            state.cylinderStates[0].combustionCycleMultiplier;
        telemetry.maximumCycleMultiplier =
            telemetry.minimumCycleMultiplier;
        for (std::size_t cylinder = 1; cylinder < cylinderCount; ++cylinder) {
            const auto multiplier =
                state.cylinderStates[cylinder].combustionCycleMultiplier;
            telemetry.minimumCycleMultiplier = std::min(
                telemetry.minimumCycleMultiplier, multiplier);
            telemetry.maximumCycleMultiplier = std::max(
                telemetry.maximumCycleMultiplier, multiplier);
        }
    }
    telemetry.afterfireHeatReleaseKw =
        state.exhaustAfterfireHeatReleaseKw;
    telemetry.afterfireFuelBurnMgPerSecond =
        state.exhaustAfterfireFuelBurnMgPerSecond;
    telemetry.overrunAfterfireActive =
        state.exhaustAfterfireOverrunActive;
    for (const auto& path : engine.exhaustPaths) {
        if (path.network) {
            for (const auto& component : path.network->components) {
                if (component.type == ExhaustComponentType::muffler
                        && component.packingFlowResistivityPaSPerM2 > 0.0
                        && component.packingThicknessMm > 0.0
                        && component.perforatedOpenAreaRatio > 0.0)
                    ++telemetry.porousMufflerCount;
            }
        } else if (path.geometry.mufflerPackingFlowResistivityPaSPerM2 > 0.0
                && path.geometry.mufflerPackingThicknessMm > 0.0
                && path.geometry.mufflerPerforatedOpenAreaRatio > 0.0) {
            ++telemetry.porousMufflerCount;
        }
    }
    return telemetry;
}

class AudioWorkshopWindow::WorkshopContent final
    : public juce::Component,
      private juce::Timer {
public:
    WorkshopContent(
        const EngineConfig& engine,
        std::filesystem::path assetRoot,
        const OfflineAudioMix& mix,
        bool compiledExhaustTopology,
        bool compiledIntakeTopology,
        bool measuredImpulseResponseAvailable,
        MixChangedCallback mixChanged,
        PhysicsApplyCallback physicsApply,
        TelemetryProvider telemetryProvider,
        RunningEngineProvider runningEngine)
        : engine_(engine),
          assetRoot_(std::move(assetRoot)),
          catalogueMix_(mix),
          authoredMix_(mix),
          compiledExhaustTopology_(compiledExhaustTopology),
          compiledIntakeTopology_(compiledIntakeTopology),
          measuredImpulseResponseAvailable_(
              measuredImpulseResponseAvailable),
          mixChanged_(std::move(mixChanged)),
          physicsApply_(std::move(physicsApply)),
          telemetryProvider_(std::move(telemetryProvider)),
          runningEngine_(std::move(runningEngine)),
          progressBar_(progressValue_) {
        setOpaque(true);

        mixGroup_.setText("Real-time mix");
        exportGroup_.setText("Offline HQ render");
        physicsGroup_.setText("Audio physics: pressure to exhaust");
        for (auto* group : { &mixGroup_, &exportGroup_, &physicsGroup_ }) {
            group->setColour(
                juce::GroupComponent::outlineColourId,
                ui::colours::line);
            group->setColour(
                juce::GroupComponent::textColourId,
                ui::colours::label);
            addAndMakeVisible(*group);
        }

        engineLabel_.setFont(
            juce::FontOptions(18.0F, juce::Font::bold));
        engineLabel_.setColour(
            juce::Label::textColourId,
            ui::colours::text);
        statusLabel_.setColour(
            juce::Label::textColourId,
            ui::colours::label);
        statusLabel_.setFont(juce::FontOptions(12.0F));
        statusLabel_.setJustificationType(
            juce::Justification::centredRight);
        addAndMakeVisible(engineLabel_);
        addAndMakeVisible(statusLabel_);

        const std::array<std::string_view, 9> names {
            "Master",
            "Measured IR send (max +50 %)",
            "Master treble",
            "Legacy intake noise",
            "Legacy exhaust noise",
            "Direct combustion",
            "Exhaust",
            "Intake + forced induction",
            "Structure / mechanical",
        };
        for (std::size_t index = 0;
             index < controlLabels_.size(); ++index) {
            controlLabels_[index].setText(
                utf8(names[index]), juce::dontSendNotification);
            controlLabels_[index].setColour(
                juce::Label::textColourId,
                ui::colours::muted);
            controlLabels_[index].setFont(
                juce::FontOptions(12.0F));
            addAndMakeVisible(controlLabels_[index]);
        }

        configureSlider(volumeSlider_, 0.0, 2.0, 0.01);
        configureSlider(irSlider_, 0.0, 1.0, 0.01);
        configureSlider(highShelfSlider_, 0.2, 2.5, 0.01);
        configureSlider(lowNoiseSlider_, 0.0, 1.5, 0.01);
        configureSlider(highNoiseSlider_, 0.0, 1.5, 0.01);
        configureSlider(combustionSlider_, 0.0, 2.0, 0.01);
        configureSlider(exhaustSlider_, 0.0, 2.0, 0.01);
        exhaustSlider_.setComponentID("mix-exhaust");
        configureSlider(intakeSlider_, 0.0, maximumIntakeGain, 0.01);
        configureSlider(mechanicalSlider_, 0.0, 2.0, 0.01);

        for (std::size_t index = 0;
             index < muteButtons_.size(); ++index) {
            muteButtons_[index] =
                std::make_unique<juce::TextButton>("Mute");
            soloButtons_[index] =
                std::make_unique<juce::TextButton>("Solo");
            muteButtons_[index]->setClickingTogglesState(true);
            soloButtons_[index]->setClickingTogglesState(true);
            muteButtons_[index]->setColour(
                juce::TextButton::buttonOnColourId,
                ui::colours::critical);
            soloButtons_[index]->setColour(
                juce::TextButton::buttonOnColourId,
                ui::colours::okBorder);
            muteButtons_[index]->onClick =
                [this] { publishMix(); };
            soloButtons_[index]->onClick =
                [this] { publishMix(); };
            addAndMakeVisible(*muteButtons_[index]);
            addAndMakeVisible(*soloButtons_[index]);
        }

        catalogueMixButton_.onClick = [this] {
            setMixInternal(catalogueMix_);
            publishMix();
        };
        resetButton_.onClick = [this] {
            setMixInternal(OfflineAudioMix {});
            for (auto& button : muteButtons_)
                button->setToggleState(
                    false, juce::dontSendNotification);
            for (auto& button : soloButtons_)
                button->setToggleState(
                    false, juce::dontSendNotification);
            publishMix();
        };
        captureVoicingToggle_.setColour(
            juce::ToggleButton::textColourId,
            ui::colours::muted);
        captureVoicingToggle_.setComponentID("monitor-capture");
        captureVoicingToggle_.onClick = [this] { publishMix(); };
        addAndMakeVisible(catalogueMixButton_);
        addAndMakeVisible(resetButton_);
        addAndMakeVisible(captureVoicingToggle_);

        sampleRateSelector_.addItem("48 kHz", 1);
        sampleRateSelector_.addItem("96 kHz", 2);
        sampleRateSelector_.addItem("192 kHz", 3);
        sampleRateSelector_.setSelectedId(
            2, juce::dontSendNotification);
        formatSelector_.addItem("PCM 24 bits", 1);
        formatSelector_.addItem("Float 32 bits", 2);
        formatSelector_.setSelectedId(
            1, juce::dontSendNotification);
        stemsToggle_.setToggleState(
            true, juce::dontSendNotification);
        stemsToggle_.setColour(
            juce::ToggleButton::textColourId,
            ui::colours::muted);
        addAndMakeVisible(sampleRateSelector_);
        addAndMakeVisible(formatSelector_);
        addAndMakeVisible(stemsToggle_);

        loopStepSelector_.addItem("Every 250 rpm", 250);
        loopStepSelector_.addItem("Every 500 rpm", 500);
        loopStepSelector_.addItem("Every 1000 rpm", 1'000);
        loopStepSelector_.setSelectedId(500, juce::dontSendNotification);
        loopStepSelector_.setTooltip(
            "The loop pack holds the idle, then a point every step up to just "
            "under the redline, on load and off load.");
        loopOggToggle_.setColour(
            juce::ToggleButton::textColourId, ui::colours::muted);
        loopOggToggle_.setTooltip(
            "Also write an Ogg Vorbis copy of every loop (the WAV is the exact one).");
        loopPackButton_.setTooltip(
            "Seamless loops for a game's engine sound (BeamNG soundConfig and "
            "soundConfigExhaust): each point held on the dyno, whole engine "
            "cycles, an engine and an exhaust layer, one gain for the pack. "
            "48 kHz mono 24-bit WAV and loop-pack.json.");
        loopPackButton_.onClick = [this] { chooseLoopPackDirectory(); };
        addAndMakeVisible(loopStepSelector_);
        addAndMakeVisible(loopOggToggle_);
        addAndMakeVisible(loopPackButton_);

        scenarioButton_.onClick =
            [this] { chooseScenario(); };
        defaultScenarioButton_.onClick = [this] {
            scenarioPath_.clear();
            updateScenarioLabel();
        };
        exportButton_.onClick =
            [this] { chooseExportDirectory(); };
        cancelButton_.onClick = [this] {
            if (exportThread_.joinable()) {
                exportThread_.request_stop();
                statusLabel_.setText(
                    "Cancelling...",
                    juce::dontSendNotification);
            }
        };
        revealButton_.onClick = [this] {
            if (!lastOutputDirectory_.empty())
                juce::File(displayPath(
                    lastOutputDirectory_))
                    .revealToUser();
        };
        cancelButton_.setEnabled(false);
        revealButton_.setEnabled(false);
        for (auto* button : {
                 &scenarioButton_, &defaultScenarioButton_,
                 &exportButton_, &cancelButton_,
                 &revealButton_ }) {
            addAndMakeVisible(*button);
        }

        scenarioLabel_.setColour(
            juce::Label::textColourId,
            ui::colours::label);
        scenarioLabel_.setFont(juce::FontOptions(12.0F));
        scenarioLabel_.setJustificationType(
            juce::Justification::topLeft);
        scenarioLabel_.setMinimumHorizontalScale(0.7F);
        addAndMakeVisible(scenarioLabel_);

        proofLabel_.setColour(
            juce::Label::textColourId,
            ui::colours::ok);
        proofLabel_.setFont(juce::FontOptions(12.0F));
        proofLabel_.setJustificationType(
            juce::Justification::topLeft);
        proofLabel_.setText(
            "The render runs EngineSimulator -> publishAudioFrame -> "
            "RealtimeEngineAudio. The manifest records the physical-graph "
            "counters and the actual WAV format.",
            juce::dontSendNotification);
        addAndMakeVisible(proofLabel_);
        addAndMakeVisible(progressBar_);

        const std::array<std::string_view, 8> physicsNames {
            "Cycle variation (COV)", "Cycle correlation",
            "Afterfire ignition (K)", "Afterfire reaction (ms)",
            "Afterfire efficiency", "Overrun spark (deg BTDC)",
            "Pocket mixing (ms)", "Overrun spark cut",
        };
        for (std::size_t index = 0; index < physicsLabels_.size(); ++index) {
            physicsLabels_[index].setText(
                utf8(physicsNames[index]), juce::dontSendNotification);
            physicsLabels_[index].setColour(
                juce::Label::textColourId, ui::colours::muted);
            physicsLabels_[index].setFont(juce::FontOptions(12.0F));
            addAndMakeVisible(physicsLabels_[index]);
        }
        configureSlider(cycleVariationSlider_, 0.0, 0.20, 0.005);
        configureSlider(cycleCorrelationSlider_, 0.0, 0.98, 0.01);
        configureSlider(afterfireTemperatureSlider_, 500.0, 1'800.0, 10.0);
        configureSlider(afterfireReactionSlider_, 0.5, 50.0, 0.5);
        configureSlider(afterfireEfficiencySlider_, 0.0, 1.0, 0.01);
        configureSlider(overrunSparkSlider_, -45.0, 10.0, 1.0);
        configureSlider(pocketMixingSlider_, 0.0, 50.0, 1.0);
        configureSlider(sparkCutSlider_, 0.0, 0.9, 0.05);
        cycleVariationSlider_.setTextValueSuffix(" ratio");
        cycleCorrelationSlider_.setTextValueSuffix(" ratio");
        afterfireTemperatureSlider_.setTextValueSuffix(" K");
        afterfireReactionSlider_.setTextValueSuffix(" ms");
        afterfireEfficiencySlider_.setTextValueSuffix(" ratio");
        overrunSparkSlider_.setTextValueSuffix(" deg");
        pocketMixingSlider_.setTextValueSuffix(" ms");
        sparkCutSlider_.setTextValueSuffix(" ratio");

        afterfireToggle_.setColour(
            juce::ToggleButton::textColourId, ui::colours::muted);
        afterfireToggle_.setComponentID("afterfire-enabled");
        afterfireToggle_.onClick = [this] {
            if (afterfireToggle_.getToggleState())
                prepareCleanAfterfireProfile();
        };
        // The owner's switch: afterfire is an option of every engine, turned
        // on and off from the mixer and applied at once. The physics group
        // below keeps the detailed calibration and its explicit APPLY; this
        // switch shows the live state, never the pending one.
        mixAfterfireToggle_.setColour(
            juce::ToggleButton::textColourId, ui::colours::warn);
        mixAfterfireToggle_.setComponentID("mix-afterfire");
        mixAfterfireToggle_.setTooltip(
            "Pops and bangs on overrun: a late spark, whose unburnt charge "
            "goes on burning in the pipe. Off whenever an engine is loaded. "
            "Applied immediately; fine tuning in AUDIO PHYSICS.");
        mixAfterfireToggle_.onClick = [this] {
            const auto enabled = mixAfterfireToggle_.getToggleState();
            afterfireToggle_.setToggleState(enabled, juce::dontSendNotification);
            if (enabled) prepareCleanAfterfireProfile();
            if (!applyPhysics()) {
                // Refused (dyno running or invalid): show the state that is
                // actually live rather than the one the user asked for.
                const auto live = engine_.exhaustAfterfire.enabled;
                mixAfterfireToggle_.setToggleState(
                    live, juce::dontSendNotification);
                afterfireToggle_.setToggleState(
                    live, juce::dontSendNotification);
            }
        };
        addAndMakeVisible(mixAfterfireToggle_);
        wetLimiterToggle_.setColour(
            juce::ToggleButton::textColourId, ui::colours::muted);
        addAndMakeVisible(afterfireToggle_);
        addAndMakeVisible(wetLimiterToggle_);
        demoPhysicsButton_.onClick = [this] {
            setPhysicsInternal({ 0.06, 0.55, true, true,
                MeasuredBackfireProfile::ignitionTemperatureK,
                MeasuredBackfireProfile::reactionTimeConstantSeconds, 0.95,
                MeasuredBackfireProfile::overrunSparkAdvanceDegrees,
                MeasuredBackfireProfile::pocketMixingTimeSeconds,
                MeasuredBackfireProfile::overrunSparkCutFraction });
            applyPhysics();
        };
        bypassPhysicsButton_.onClick = [this] {
            auto settings = physicsSettings();
            settings.cycleVariationCoefficientOfVariation = 0.0;
            settings.afterfireEnabled = false;
            settings.limiterKeepsFuel = false;
            setPhysicsInternal(settings);
            applyPhysics();
        };
        applyPhysicsButton_.onClick = [this] { applyPhysics(); };
        for (auto* button : { &demoPhysicsButton_, &bypassPhysicsButton_,
                              &applyPhysicsButton_ })
            addAndMakeVisible(*button);
        physicsTelemetryLabel_.setColour(
            juce::Label::textColourId, ui::colours::ok);
        physicsTelemetryLabel_.setFont(juce::FontOptions(12.0F));
        physicsTelemetryLabel_.setJustificationType(juce::Justification::topLeft);
        addAndMakeVisible(physicsTelemetryLabel_);
        physicsStatusLabel_.setColour(
            juce::Label::textColourId, ui::colours::warn);
        physicsStatusLabel_.setFont(juce::FontOptions(11.5F));
        addAndMakeVisible(physicsStatusLabel_);

        setMixInternal(mix);
        setPhysicsInternal(audioPhysicsSettingsFor(engine_));
        updateEnginePresentation();
        setPhysicsInternal(audioPhysicsSettingsFor(engine_));
        updateScenarioLabel();
        installSliderCallbacks();
        updateAvailability();
        startTimerHz(20);
    }

    ~WorkshopContent() override {
        stopTimer();
        if (exportThread_.joinable()) {
            exportThread_.request_stop();
            exportThread_.join();
        }
        for (auto* slider : sliders())
            slider->onValueChange = nullptr;
        for (auto& button : muteButtons_)
            button->onClick = nullptr;
        for (auto& button : soloButtons_)
            button->onClick = nullptr;
    }

    void setEngine(
        const EngineConfig& engine,
        std::filesystem::path assetRoot,
        bool compiledExhaustTopology,
        bool compiledIntakeTopology,
        bool measuredImpulseResponseAvailable) {
        engine_ = engine;
        assetRoot_ = std::move(assetRoot);
        compiledExhaustTopology_ =
            compiledExhaustTopology;
        compiledIntakeTopology_ =
            compiledIntakeTopology;
        measuredImpulseResponseAvailable_ =
            measuredImpulseResponseAvailable;
        // The physics fields are the new engine's: APPLY LIVE sent the
        // last engine's to it (audit APP-04).
        setPhysicsInternal(audioPhysicsSettingsFor(engine_));
        updateEnginePresentation();
        updateAvailability();
        publishMix();
    }

    /** The calibration an export runs: the running engine's, read with
     *  its configuration (see RunningEngineProvider). */
    [[nodiscard]] std::shared_ptr<const calibration::CalibrationSnapshot> refreshRunningEngine() {
        if (!runningEngine_) return {};
        auto running = runningEngine_();
        engine_ = std::move(running.config);
        return std::move(running.calibration);
    }

    void setMix(const OfflineAudioMix& mix) {
        catalogueMix_ = mix;
        setMixInternal(mix);
        publishMix();
    }

    void paint(juce::Graphics& graphics) override {
        graphics.fillAll(ui::colours::background);
        juce::ColourGradient gradient(
            ui::colours::panelRaised, 0.0F, 0.0F,
            ui::colours::background, 0.0F,
            static_cast<float>(getHeight()), false);
        graphics.setGradientFill(gradient);
        graphics.fillRect(getLocalBounds());
    }

    void resized() override {
        auto area = getLocalBounds().reduced(18);
        auto header = area.removeFromTop(44);
        engineLabel_.setBounds(
            header.removeFromLeft(
                static_cast<int>(header.getWidth() * 0.62)));
        statusLabel_.setBounds(header);
        area.removeFromTop(8);

        auto physicsArea = area.removeFromBottom(276);
        area.removeFromBottom(12);
        const auto leftWidth = std::max(
            500, static_cast<int>(
                     static_cast<double>(area.getWidth())
                     * 0.58));
        auto mixArea = area.removeFromLeft(leftWidth);
        area.removeFromLeft(12);
        auto exportArea = area;
        mixGroup_.setBounds(mixArea);
        exportGroup_.setBounds(exportArea);
        physicsGroup_.setBounds(physicsArea);

        auto mixBody = mixArea.reduced(16, 28);
        // Bottom rows first, at fixed height; the fader rows share the rest.
        // Fixed 34/38 px rows used to leave the voicing buttons 12 px at an
        // 800 px window.
        auto voicingButtons = mixBody.removeFromBottom(32);
        mixBody.removeFromBottom(4);
        mixAfterfireToggle_.setBounds(mixBody.removeFromBottom(28));
        mixBody.removeFromBottom(4);
        const auto rowScale = std::min(1.0,
            static_cast<double>(mixBody.getHeight()) / (5 * 34 + 8 + 4 * 38));
        const auto generalRowHeight = static_cast<int>(34 * rowScale);
        for (std::size_t index = 0; index < 5; ++index) {
            auto row = mixBody.removeFromTop(
                generalRowHeight);
            controlLabels_[index].setBounds(
                row.removeFromLeft(190));
            sliders()[index]->setBounds(row);
        }
        mixBody.removeFromTop(8);
        const auto layerRowHeight = static_cast<int>(38 * rowScale);
        for (std::size_t layer = 0; layer < 4; ++layer) {
            auto row = mixBody.removeFromTop(layerRowHeight);
            controlLabels_[layer + 5].setBounds(
                row.removeFromLeft(155));
            muteButtons_[layer]->setBounds(
                row.removeFromRight(58).reduced(2, 7));
            soloButtons_[layer]->setBounds(
                row.removeFromRight(58).reduced(2, 7));
            layerSliders()[layer]->setBounds(row);
        }
        catalogueMixButton_.setBounds(
            voicingButtons.removeFromLeft(190));
        resetButton_.setBounds(
            voicingButtons.removeFromRight(150));
        captureVoicingToggle_.setBounds(voicingButtons.reduced(6, 0));

        auto exportBody = exportArea.reduced(16, 30);
        auto selectors = exportBody.removeFromTop(34);
        sampleRateSelector_.setBounds(
            selectors.removeFromLeft(
                selectors.getWidth() / 2 - 4));
        selectors.removeFromLeft(8);
        formatSelector_.setBounds(selectors);
        exportBody.removeFromTop(8);
        stemsToggle_.setBounds(
            exportBody.removeFromTop(30));
        exportBody.removeFromTop(8);
        auto scenarioButtons =
            exportBody.removeFromTop(34);
        scenarioButton_.setBounds(
            scenarioButtons.removeFromLeft(
                scenarioButtons.getWidth() * 2 / 3 - 4));
        scenarioButtons.removeFromLeft(8);
        defaultScenarioButton_.setBounds(
            scenarioButtons);
        scenarioLabel_.setBounds(
            exportBody.removeFromTop(56));
        exportBody.removeFromTop(8);
        exportButton_.setBounds(
            exportBody.removeFromTop(42));
        exportBody.removeFromTop(6);
        auto jobButtons =
            exportBody.removeFromTop(34);
        cancelButton_.setBounds(
            jobButtons.removeFromLeft(
                jobButtons.getWidth() / 2 - 4));
        jobButtons.removeFromLeft(8);
        revealButton_.setBounds(jobButtons);
        exportBody.removeFromTop(8);
        auto loopRow = exportBody.removeFromTop(34);
        loopStepSelector_.setBounds(loopRow.removeFromLeft(
            std::min(150, loopRow.getWidth() / 3)));
        loopRow.removeFromLeft(6);
        loopOggToggle_.setBounds(loopRow.removeFromLeft(78));
        loopRow.removeFromLeft(4);
        loopPackButton_.setBounds(loopRow);
        exportBody.removeFromTop(12);
        progressBar_.setBounds(
            exportBody.removeFromTop(24));
        exportBody.removeFromTop(12);
        proofLabel_.setBounds(exportBody);

        auto physicsBody = physicsArea.reduced(16, 28);
        const auto firstWidth = physicsBody.getWidth() * 31 / 100;
        const auto secondWidth = physicsBody.getWidth() * 34 / 100;
        auto firstColumn = physicsBody.removeFromLeft(firstWidth);
        physicsBody.removeFromLeft(12);
        auto secondColumn = physicsBody.removeFromLeft(secondWidth);
        physicsBody.removeFromLeft(12);
        auto thirdColumn = physicsBody;
        // The afterfire column is the tallest at six rows; seven keeps the
        // rows at their former height. Size the row from it
        // so shrinking the window narrows the rows instead of clipping them.
        const auto physicsRowHeight =
            std::clamp(physicsBody.getHeight() / 7, 24, 35);
        const auto physicsRow = [physicsRowHeight](
                                    juce::Rectangle<int>& column,
                                    juce::Label& label, juce::Slider& slider) {
            auto row = column.removeFromTop(physicsRowHeight);
            label.setBounds(row.removeFromLeft(145));
            slider.setBounds(row);
        };
        physicsRow(firstColumn, physicsLabels_[0], cycleVariationSlider_);
        physicsRow(firstColumn, physicsLabels_[1], cycleCorrelationSlider_);
        physicsStatusLabel_.setBounds(firstColumn.reduced(0, 5));
        physicsRow(secondColumn, physicsLabels_[2], afterfireTemperatureSlider_);
        physicsRow(secondColumn, physicsLabels_[3], afterfireReactionSlider_);
        physicsRow(secondColumn, physicsLabels_[4], afterfireEfficiencySlider_);
        physicsRow(secondColumn, physicsLabels_[5], overrunSparkSlider_);
        physicsRow(secondColumn, physicsLabels_[6], pocketMixingSlider_);
        physicsRow(secondColumn, physicsLabels_[7], sparkCutSlider_);
        afterfireToggle_.setBounds(thirdColumn.removeFromTop(27));
        wetLimiterToggle_.setBounds(thirdColumn.removeFromTop(27));
        auto presets = thirdColumn.removeFromTop(32);
        demoPhysicsButton_.setBounds(
            presets.removeFromLeft(presets.getWidth() / 2 - 4));
        presets.removeFromLeft(8);
        bypassPhysicsButton_.setBounds(presets);
        thirdColumn.removeFromTop(5);
        applyPhysicsButton_.setBounds(thirdColumn.removeFromTop(34));
        thirdColumn.removeFromTop(5);
        physicsTelemetryLabel_.setBounds(thirdColumn);
    }

private:
    [[nodiscard]] std::array<juce::Slider*, 9> sliders() {
        return {
            &volumeSlider_, &irSlider_,
            &highShelfSlider_, &lowNoiseSlider_,
            &highNoiseSlider_, &combustionSlider_,
            &exhaustSlider_, &intakeSlider_,
            &mechanicalSlider_,
        };
    }

    [[nodiscard]] std::array<const juce::Slider*, 9>
    sliders() const {
        return {
            &volumeSlider_, &irSlider_,
            &highShelfSlider_, &lowNoiseSlider_,
            &highNoiseSlider_, &combustionSlider_,
            &exhaustSlider_, &intakeSlider_,
            &mechanicalSlider_,
        };
    }

    [[nodiscard]] std::array<juce::Slider*, 4>
    layerSliders() {
        return {
            &combustionSlider_, &exhaustSlider_,
            &intakeSlider_, &mechanicalSlider_,
        };
    }

    void configureSlider(
        juce::Slider& slider, double minimum,
        double maximum, double interval) {
        slider.setRange(minimum, maximum, interval);
        slider.setSliderStyle(
            juce::Slider::LinearHorizontal);
        slider.setTextBoxStyle(
            juce::Slider::TextBoxRight, false, 58, 22);
        slider.setColour(
            juce::Slider::thumbColourId,
            ui::colours::accent);
        slider.setColour(
            juce::Slider::trackColourId,
            ui::colours::accentDeep);
        addAndMakeVisible(slider);
    }

    void installSliderCallbacks() {
        volumeSlider_.onValueChange = [this] { publishMix(); };
        irSlider_.onValueChange = [this] { publishMix(); };

        // These controls are intentionally neutral in the SI reference mode.
        // Moving one must not appear to work while its value is silently
        // ignored: a user edit explicitly opts into capture voicing and the
        // visible MODE CAPTURE switch follows the actual audio state.
        for (auto* slider : {
                 &highShelfSlider_, &lowNoiseSlider_, &highNoiseSlider_,
                 &combustionSlider_, &exhaustSlider_, &intakeSlider_,
                 &mechanicalSlider_ }) {
            slider->onValueChange = [this] {
                if (!updatingControls_)
                    captureVoicingToggle_.setToggleState(
                        true, juce::dontSendNotification);
                publishMix();
            };
        }
    }

    void setMixInternal(const OfflineAudioMix& mix) {
        authoredMix_ = mix;
        updatingControls_ = true;
        volumeSlider_.setValue(
            mix.volume, juce::dontSendNotification);
        irSlider_.setValue(
            mix.convolution, juce::dontSendNotification);
        highShelfSlider_.setValue(
            mix.highFrequencyGain,
            juce::dontSendNotification);
        lowNoiseSlider_.setValue(
            mix.lowFrequencyNoise,
            juce::dontSendNotification);
        highNoiseSlider_.setValue(
            mix.highFrequencyNoise,
            juce::dontSendNotification);
        combustionSlider_.setValue(
            mix.combustionGain,
            juce::dontSendNotification);
        exhaustSlider_.setValue(
            mix.exhaustGain,
            juce::dontSendNotification);
        intakeSlider_.setValue(
            mix.intakeGain,
            juce::dontSendNotification);
        mechanicalSlider_.setValue(
            mix.mechanicalGain,
            juce::dontSendNotification);
        captureVoicingToggle_.setToggleState(
            mix.monitorMode == AudioMonitorMode::captureVoiced,
            juce::dontSendNotification);
        updatingControls_ = false;
    }

    [[nodiscard]] AudioPhysicsSettings physicsSettings() const noexcept {
        return {
            cycleVariationSlider_.getValue(),
            cycleCorrelationSlider_.getValue(),
            afterfireToggle_.getToggleState(),
            wetLimiterToggle_.getToggleState(),
            afterfireTemperatureSlider_.getValue(),
            afterfireReactionSlider_.getValue() * 0.001,
            afterfireEfficiencySlider_.getValue(),
            overrunSparkSlider_.getValue(),
            pocketMixingSlider_.getValue() * 0.001,
            sparkCutSlider_.getValue(),
        };
    }

    void setPhysicsInternal(const AudioPhysicsSettings& settings) {
        cycleVariationSlider_.setValue(
            settings.cycleVariationCoefficientOfVariation,
            juce::dontSendNotification);
        cycleCorrelationSlider_.setValue(
            settings.cycleVariationCorrelation, juce::dontSendNotification);
        afterfireToggle_.setToggleState(
            settings.afterfireEnabled, juce::dontSendNotification);
        mixAfterfireToggle_.setToggleState(
            settings.afterfireEnabled, juce::dontSendNotification);
        wetLimiterToggle_.setToggleState(
            settings.limiterKeepsFuel, juce::dontSendNotification);
        afterfireTemperatureSlider_.setValue(
            settings.afterfireIgnitionTemperatureK,
            juce::dontSendNotification);
        afterfireReactionSlider_.setValue(
            settings.afterfireReactionTimeSeconds * 1'000.0,
            juce::dontSendNotification);
        afterfireEfficiencySlider_.setValue(
            settings.afterfireEfficiency, juce::dontSendNotification);
        overrunSparkSlider_.setValue(
            settings.overrunSparkAdvanceDegrees, juce::dontSendNotification);
        pocketMixingSlider_.setValue(
            settings.pocketMixingTimeSeconds * 1'000.0,
            juce::dontSendNotification);
        sparkCutSlider_.setValue(
            settings.overrunSparkCutFraction, juce::dontSendNotification);
    }

    /** An engine that never authored an afterfire calibration carries the
     *  clean defaults (900 K, 10 ms, no pockets), which were never measured
     *  as a backfire. Turning backfires on installs the measured profile
     *  instead (`MeasuredBackfireProfile`); an authored calibration is
     *  kept. */
    void prepareCleanAfterfireProfile() {
        const auto cleanProfile =
            std::abs(afterfireTemperatureSlider_.getValue() - 900.0) < 0.5
            && std::abs(afterfireReactionSlider_.getValue() - 10.0) < 0.5
            && pocketMixingSlider_.getValue() <= 0.0;
        if (!cleanProfile) return;

        afterfireTemperatureSlider_.setValue(
            MeasuredBackfireProfile::ignitionTemperatureK,
            juce::dontSendNotification);
        afterfireReactionSlider_.setValue(
            MeasuredBackfireProfile::reactionTimeConstantSeconds * 1'000.0,
            juce::dontSendNotification);
        overrunSparkSlider_.setValue(
            MeasuredBackfireProfile::overrunSparkAdvanceDegrees,
            juce::dontSendNotification);
        pocketMixingSlider_.setValue(
            MeasuredBackfireProfile::pocketMixingTimeSeconds * 1'000.0,
            juce::dontSendNotification);
        sparkCutSlider_.setValue(
            MeasuredBackfireProfile::overrunSparkCutFraction,
            juce::dontSendNotification);
    }

    bool applyPhysics() {
        if (!physicsApply_) {
            physicsStatusLabel_.setText(
                "Read-only: no host engine.", juce::dontSendNotification);
            return false;
        }
        const auto settings = physicsSettings();
        if (!physicsApply_(settings)) {
            physicsStatusLabel_.setText(
                "Rejected (dyno running or invalid configuration).",
                juce::dontSendNotification);
            mixAfterfireToggle_.setToggleState(
                engine_.exhaustAfterfire.enabled, juce::dontSendNotification);
            return false;
        }
        applyAudioPhysicsSettings(engine_, settings);
        mixAfterfireToggle_.setToggleState(
            engine_.exhaustAfterfire.enabled, juce::dontSendNotification);
        physicsStatusLabel_.setText(
            "Applied live. Thermal state and engine speed kept.",
            juce::dontSendNotification);
        return true;
    }

    [[nodiscard]] OfflineAudioMix baseMix() const {
        // Only nine authoring controls are visible. Preserve the remaining
        // catalogue fields (low shelf, stereo width, outlet jet and saturation)
        // instead of silently resetting them when any visible fader moves.
        auto mix = authoredMix_;
        mix.volume = volumeSlider_.getValue();
        mix.convolution = irSlider_.getValue();
        mix.highFrequencyGain =
            highShelfSlider_.getValue();
        mix.lowFrequencyNoise =
            lowNoiseSlider_.getValue();
        mix.highFrequencyNoise =
            highNoiseSlider_.getValue();
        mix.combustionGain =
            combustionSlider_.getValue();
        mix.exhaustGain = exhaustSlider_.getValue();
        mix.intakeGain = intakeSlider_.getValue();
        mix.mechanicalGain =
            mechanicalSlider_.getValue();
        mix.monitorMode = captureVoicingToggle_.getToggleState()
            ? AudioMonitorMode::captureVoiced
            : AudioMonitorMode::physicalReference;
        return mix;
    }

    [[nodiscard]] OfflineAudioMix effectiveMix() const {
        AudioWorkshopLayerSwitches switches;
        for (std::size_t layer = 0;
             layer < switches.muted.size(); ++layer) {
            switches.muted[layer] =
                muteButtons_[layer]->getToggleState();
            switches.solo[layer] =
                soloButtons_[layer]->getToggleState();
        }
        return effectiveAudioWorkshopMix(
            baseMix(),
            {
                compiledExhaustTopology_,
                compiledIntakeTopology_,
                measuredImpulseResponseAvailable_,
            },
            switches);
    }

    void publishMix() {
        if (updatingControls_ || !mixChanged_) return;
        mixChanged_(baseMix(), effectiveMix());
    }

    void updateEnginePresentation() {
        engineLabel_.setText(
            "Audio workshop  /  "
                + utf8(engine_.name),
            juce::dontSendNotification);
        if (!exportRunning_)
            statusLabel_.setText(
                compiledExhaustTopology_
                    ? "Physical graph active"
                    : "Compatibility mode",
                juce::dontSendNotification);
    }

    void updateAvailability() {
        irSlider_.setEnabled(
            measuredImpulseResponseAvailable_);
        controlLabels_[1].setText(
            measuredImpulseResponseAvailable_
                ? "Measured IR send (max +50 %)"
                : "IR send (no measurement loaded)",
            juce::dontSendNotification);
        irSlider_.setTooltip(
            measuredImpulseResponseAvailable_
                ? "Adds the measured impulse response as a send; "
                  "the dry signal stays intact."
                : "No measured impulse response is loaded.");

        lowNoiseSlider_.setEnabled(
            !compiledIntakeTopology_);
        controlLabels_[3].setText(
            compiledIntakeTopology_
                ? "Legacy intake noise (N/A)"
                : "Legacy intake noise",
            juce::dontSendNotification);
        highNoiseSlider_.setEnabled(
            !compiledExhaustTopology_);
        controlLabels_[4].setText(
            compiledExhaustTopology_
                ? "Legacy exhaust noise (N/A)"
                : "Legacy exhaust noise",
            juce::dontSendNotification);

        combustionSlider_.setEnabled(
            !compiledExhaustTopology_);
        muteButtons_[0]->setEnabled(
            !compiledExhaustTopology_);
        soloButtons_[0]->setEnabled(
            !compiledExhaustTopology_);
        if (compiledExhaustTopology_) {
            muteButtons_[0]->setToggleState(
                false, juce::dontSendNotification);
            soloButtons_[0]->setToggleState(
                false, juce::dontSendNotification);
            controlLabels_[5].setText(
                "Direct combustion (N/A: pressure -> exhaust)",
                juce::dontSendNotification);
            combustionSlider_.setTooltip(
                "The thermoacoustic graph owns the cylinder pressure. "
                "The direct synthetic voice is deliberately removed.");
        } else {
            controlLabels_[5].setText(
                "Direct combustion",
                juce::dontSendNotification);
            combustionSlider_.setTooltip({});
        }
    }

    void chooseScenario() {
        if (exportRunning_) return;
        fileChooser_ = std::make_unique<juce::FileChooser>(
            "Choose a JSON audio scenario",
            juce::File::getSpecialLocation(
                juce::File::userDocumentsDirectory),
            "*.json");
        auto safe =
            juce::Component::SafePointer<WorkshopContent>(
                this);
        fileChooser_->launchAsync(
            juce::FileBrowserComponent::openMode
                | juce::FileBrowserComponent::canSelectFiles,
            [safe](const juce::FileChooser& chooser) {
                if (!safe) return;
                const auto file = chooser.getResult();
                if (file.existsAsFile()) {
                    OfflineAudioScenario scenario;
                    std::string error;
                    if (loadOfflineAudioScenario(
                            fileSystemPath(file),
                            scenario, error)) {
                        safe->scenarioPath_ =
                            fileSystemPath(file);
                        safe->updateScenarioLabel();
                    } else {
                        ui::showMessage(
                                safe.getComponent(),
                                juce::MessageBoxIconType::
                                    WarningIcon,
                                "Invalid scenario",
                                utf8(error));
                    }
                }
                safe->fileChooser_.reset();
            });
    }

    void updateScenarioLabel() {
        scenarioLabel_.setText(
            scenarioPath_.empty()
                ? "Scenario: built-in showcase\n"
                  "start -> idle -> rev-up -> "
                  "limiter -> overrun"
                : "Scenario JSON:\n"
                    + displayPath(scenarioPath_),
            juce::dontSendNotification);
    }

    void setExportControlsEnabled(bool enabled) {
        for (juce::Component* control : std::initializer_list<juce::Component*> {
                 &exportButton_, &scenarioButton_, &defaultScenarioButton_,
                 &sampleRateSelector_, &formatSelector_, &stemsToggle_,
                 &loopStepSelector_, &loopOggToggle_, &loopPackButton_ })
            control->setEnabled(enabled);
        cancelButton_.setEnabled(!enabled);
    }

    void chooseExportDirectory() {
        if (exportRunning_) return;
        fileChooser_ = std::make_unique<juce::FileChooser>(
            "Choose the parent folder for the HQ export",
            juce::File::getSpecialLocation(
                juce::File::userMusicDirectory),
            juce::String {});
        auto safe =
            juce::Component::SafePointer<WorkshopContent>(
                this);
        fileChooser_->launchAsync(
            juce::FileBrowserComponent::openMode
                | juce::FileBrowserComponent::
                    canSelectDirectories,
            [safe](const juce::FileChooser& chooser) {
                if (!safe) return;
                const auto directory = chooser.getResult();
                if (directory.isDirectory())
                    safe->startExport(
                        fileSystemPath(directory));
                safe->fileChooser_.reset();
            });
    }

    void startExport(
        const std::filesystem::path& parentDirectory) {
        auto runningCalibration = refreshRunningEngine();
        OfflineAudioScenario scenario =
            makeDefaultOfflineAudioScenario(engine_);
        if (!scenarioPath_.empty()) {
            std::string error;
            if (!loadOfflineAudioScenario(
                    scenarioPath_, scenario, error)) {
                ui::showMessage(this,
                    juce::MessageBoxIconType::WarningIcon,
                    "Invalid scenario", utf8(error));
                return;
            }
        }

        const auto rate = sampleRateSelector_.getSelectedId()
                == 1
            ? 48'000U
            : (sampleRateSelector_.getSelectedId() == 3
                   ? 192'000U
                   : 96'000U);
        const auto format =
            formatSelector_.getSelectedId() == 2
            ? OfflineWaveFormat::float32
            : OfflineWaveFormat::pcm24;
        const auto stamp =
            juce::Time::getCurrentTime().formatted(
                "%Y%m%d-%H%M%S")
                .toStdString();
        const auto baseName =
            fileSlug(engine_.name) + "-" + stamp
            + "-" + std::to_string(rate / 1'000U)
            + "k-" + offlineWaveFormatName(format);
        auto outputDirectory =
            parentDirectory / baseName;
        for (int suffix = 2;
             std::filesystem::exists(outputDirectory);
             ++suffix) {
            outputDirectory = parentDirectory
                / (baseName + "-"
                   + std::to_string(suffix));
        }

        OfflineAudioExportRequest request;
        request.engine = engine_;
        request.calibration = std::move(runningCalibration);
        request.scenario = std::move(scenario);
        request.mix = effectiveMix();
        request.outputDirectory = outputDirectory;
        request.assetRoot = assetRoot_;
        request.sampleRateHz = rate;
        request.format = format;
        request.writeStems =
            stemsToggle_.getToggleState();

        if (exportThread_.joinable())
            exportThread_.join();
        exportRunning_ = true;
        threadProgress_.store(
            0.0, std::memory_order_relaxed);
        progressValue_ = 0.0;
        setExportControlsEnabled(false);
        revealButton_.setEnabled(false);
        statusLabel_.setText(
            "Preparing render...",
            juce::dontSendNotification);

        auto safe =
            juce::Component::SafePointer<WorkshopContent>(
                this);
        exportThread_ = std::jthread(
            [safe, request = std::move(request),
             outputDirectory](
                std::stop_token stopToken) mutable {
                std::string lastStage;
                auto result = exportOfflineAudio(
                    request,
                    [safe, stopToken, &lastStage](
                        double fraction,
                        std::string_view stage) {
                        if (stopToken.stop_requested())
                            return false;
                        if (safe)
                            safe->threadProgress_.store(
                                fraction,
                                std::memory_order_relaxed);
                        if (stage != lastStage) {
                            lastStage = stage;
                            const auto stageCopy =
                                std::string(stage);
                            juce::MessageManager::callAsync(
                                [safe, stageCopy] {
                                    if (safe)
                                        safe->statusLabel_.setText(
                                            "Rendering  "
                                                + utf8(stageCopy),
                                            juce::
                                                dontSendNotification);
                                });
                        }
                        return !stopToken.stop_requested();
                    });
                juce::MessageManager::callAsync(
                    [safe, result = std::move(result),
                     outputDirectory]() mutable {
                        if (safe)
                            safe->finishExport(
                                std::move(result),
                                outputDirectory);
                    });
            });
    }

    void finishExport(
        OfflineAudioExportResult result,
        const std::filesystem::path& outputDirectory) {
        exportRunning_ = false;
        setExportControlsEnabled(true);
        if (result.success) {
            threadProgress_.store(
                1.0, std::memory_order_relaxed);
            lastOutputDirectory_ = outputDirectory;
            revealButton_.setEnabled(true);
            statusLabel_.setText(
                "Export complete  /  "
                    + juce::String(
                        static_cast<juce::int64>(
                            result.renderedFrames))
                    + " FRAMES",
                juce::dontSendNotification);
            juce::String message;
            message << "Export complete.\n\n"
                    << displayPath(outputDirectory)
                    << "\n\nPhysical exhaust graph: "
                    << (result.physicalExhaustActive
                            ? "active" : "inactive")
                    << "\nDelay truncations: "
                    << static_cast<juce::int64>(
                           result.delayTruncationCount)
                    << "\nInvalid boundary samples: "
                    << static_cast<juce::int64>(
                           result.invalidBoundarySampleCount)
                    << "\nLost telemetry: "
                    << static_cast<juce::int64>(
                           result.droppedFiringEvents
                           + result.droppedPressureSamples)
                    << "\nCycle variation: "
                    << juce::String(result.cycleMultiplierMinimum, 3)
                    << " .. " << juce::String(result.cycleMultiplierMaximum, 3)
                    << "\nAfterfire: "
                    << juce::String(result.afterfirePeakHeatReleaseKw, 2)
                    << " kW peak / "
                    << juce::String(result.afterfireFuelBurnedMg, 1)
                    << " mg burned"
                    << "\nPorous mufflers: "
                    << static_cast<int>(result.porousMufflerCount);
            if (!result.warnings.empty())
                message << "\n\nWarnings: "
                        << static_cast<int>(
                               result.warnings.size());
            ui::showMessage(this,
                juce::MessageBoxIconType::InfoIcon,
                "HQ audio render", message);
        } else if (result.cancelled) {
            threadProgress_.store(
                0.0, std::memory_order_relaxed);
            statusLabel_.setText(
                "Export cancelled  /  no partial WAV",
                juce::dontSendNotification);
        } else {
            statusLabel_.setText(
                "Export failed",
                juce::dontSendNotification);
            ui::showMessage(this,
                juce::MessageBoxIconType::WarningIcon,
                "HQ audio render failed",
                utf8(result.error));
        }
    }

    void chooseLoopPackDirectory() {
        if (exportRunning_) return;
        fileChooser_ = std::make_unique<juce::FileChooser>(
            "Choose the parent folder for the loop pack",
            juce::File::getSpecialLocation(juce::File::userMusicDirectory),
            juce::String {});
        auto safe = juce::Component::SafePointer<WorkshopContent>(this);
        fileChooser_->launchAsync(
            juce::FileBrowserComponent::openMode
                | juce::FileBrowserComponent::canSelectDirectories,
            [safe](const juce::FileChooser& chooser) {
                if (!safe) return;
                const auto directory = chooser.getResult();
                if (directory.isDirectory())
                    safe->startLoopPack(fileSystemPath(directory));
                safe->fileChooser_.reset();
            });
    }

    void startLoopPack(const std::filesystem::path& parentDirectory) {
        auto runningCalibration = refreshRunningEngine();
        const auto stamp = juce::Time::getCurrentTime()
            .formatted("%Y%m%d-%H%M%S").toStdString();
        const auto baseName = fileSlug(engine_.name) + "-" + stamp + "-loops";
        auto outputDirectory = parentDirectory / baseName;
        for (int suffix = 2; std::filesystem::exists(outputDirectory); ++suffix)
            outputDirectory = parentDirectory
                / (baseName + "-" + std::to_string(suffix));

        LoopPackRequest request;
        request.engine = engine_;
        request.calibration = std::move(runningCalibration);
        request.mix = effectiveMix();
        request.outputDirectory = outputDirectory;
        request.assetRoot = assetRoot_;
        request.stepRpm = static_cast<double>(
            std::max(50, loopStepSelector_.getSelectedId()));
        request.writeOgg = loopOggToggle_.getToggleState();

        if (exportThread_.joinable()) exportThread_.join();
        exportRunning_ = true;
        threadProgress_.store(0.0, std::memory_order_relaxed);
        progressValue_ = 0.0;
        setExportControlsEnabled(false);
        revealButton_.setEnabled(false);
        statusLabel_.setText("Preparing loop pack...", juce::dontSendNotification);

        auto safe = juce::Component::SafePointer<WorkshopContent>(this);
        exportThread_ = std::jthread(
            [safe, request = std::move(request), outputDirectory](
                std::stop_token stopToken) mutable {
                std::string lastStage;
                auto result = exportLoopPack(request,
                    [safe, stopToken, &lastStage](
                        double fraction, std::string_view stage) {
                        if (stopToken.stop_requested()) return false;
                        if (safe)
                            safe->threadProgress_.store(
                                fraction, std::memory_order_relaxed);
                        if (stage != lastStage) {
                            lastStage = stage;
                            const auto stageCopy = std::string(stage);
                            juce::MessageManager::callAsync([safe, stageCopy] {
                                if (safe)
                                    safe->statusLabel_.setText(
                                        "Loop pack  " + utf8(stageCopy),
                                        juce::dontSendNotification);
                            });
                        }
                        return !stopToken.stop_requested();
                    });
                juce::MessageManager::callAsync(
                    [safe, result = std::move(result), outputDirectory]() mutable {
                        if (safe)
                            safe->finishLoopPack(std::move(result), outputDirectory);
                    });
            });
    }

    void finishLoopPack(
        LoopPackResult result, const std::filesystem::path& outputDirectory) {
        exportRunning_ = false;
        setExportControlsEnabled(true);
        if (result.success) {
            threadProgress_.store(1.0, std::memory_order_relaxed);
            lastOutputDirectory_ = outputDirectory;
            revealButton_.setEnabled(true);
            statusLabel_.setText(
                "Loop pack complete  /  "
                    + juce::String(static_cast<int>(result.loops.size())) + " LOOPS",
                juce::dontSendNotification);
            juce::String message;
            message << "Loop pack complete.\n\n" << displayPath(outputDirectory)
                    << "\n\n" << static_cast<int>(result.loops.size())
                    << " points, each an engine and an exhaust loop"
                    << (result.oggWritten ? " (WAV and OGG)" : " (WAV)")
                    << ".\nOne gain for the pack: "
                    << juce::String(result.packGainDb, 1) << " dB."
                    << "\nCylinders to declare: "
                    << static_cast<int>(result.equivalentFourStrokeCylinders)
                    << " (firing frequency = rpm / 120 x cylinders)."
                    << "\nloop-pack.json gives each loop's measured speed.";
            if (!result.warnings.empty()) {
                message << "\n\nWarnings:";
                for (const auto& warning : result.warnings)
                    message << "\n- " << utf8(warning);
            }
            ui::showMessage(this, juce::MessageBoxIconType::InfoIcon,
                "Loop pack", message);
        } else if (result.cancelled) {
            threadProgress_.store(0.0, std::memory_order_relaxed);
            statusLabel_.setText("Loop pack cancelled  /  no file kept",
                juce::dontSendNotification);
        } else {
            statusLabel_.setText("Loop pack failed", juce::dontSendNotification);
            ui::showMessage(this, juce::MessageBoxIconType::WarningIcon,
                "Loop pack failed", utf8(result.error));
        }
    }

    void timerCallback() override {
        progressValue_ = threadProgress_.load(
            std::memory_order_relaxed);
        progressBar_.repaint();
        const auto telemetry = telemetryProvider_
            ? telemetryProvider_()
            : audioPhysicsTelemetryFor(engine_, EngineState {});
        physicsTelemetryLabel_.setText(
            "Live  cycles " + juce::String(telemetry.minimumCycleMultiplier, 3)
                + " .. " + juce::String(telemetry.maximumCycleMultiplier, 3)
                + "  |  afterfire " + juce::String(telemetry.afterfireHeatReleaseKw, 2)
                + " kW / " + juce::String(telemetry.afterfireFuelBurnMgPerSecond, 1)
                + " mg/s  |  decel "
                + (telemetry.overrunAfterfireActive ? "active" : "off")
                + "  |  porous mufflers "
                + juce::String(static_cast<int>(telemetry.porousMufflerCount)),
            juce::dontSendNotification);
    }

    EngineConfig engine_;
    std::filesystem::path assetRoot_;
    std::filesystem::path scenarioPath_;
    std::filesystem::path lastOutputDirectory_;
    OfflineAudioMix catalogueMix_;
    OfflineAudioMix authoredMix_;
    bool compiledExhaustTopology_ { false };
    bool compiledIntakeTopology_ { false };
    bool measuredImpulseResponseAvailable_ { false };
    bool updatingControls_ { false };
    bool exportRunning_ { false };
    MixChangedCallback mixChanged_;
    PhysicsApplyCallback physicsApply_;
    TelemetryProvider telemetryProvider_;
    RunningEngineProvider runningEngine_;

    juce::GroupComponent mixGroup_;
    juce::GroupComponent exportGroup_;
    juce::GroupComponent physicsGroup_;
    juce::Label engineLabel_;
    juce::Label statusLabel_;
    std::array<juce::Label, 9> controlLabels_;
    juce::Slider volumeSlider_;
    juce::Slider irSlider_;
    juce::Slider highShelfSlider_;
    juce::Slider lowNoiseSlider_;
    juce::Slider highNoiseSlider_;
    juce::Slider combustionSlider_;
    juce::Slider exhaustSlider_;
    juce::Slider intakeSlider_;
    juce::Slider mechanicalSlider_;
    std::array<std::unique_ptr<juce::TextButton>, 4>
        muteButtons_;
    std::array<std::unique_ptr<juce::TextButton>, 4>
        soloButtons_;
    juce::TextButton catalogueMixButton_ { "Voicing catalogue" };
    juce::TextButton resetButton_ { "Neutral" };
    juce::ToggleButton captureVoicingToggle_ { "Capture mode" };
    juce::ToggleButton mixAfterfireToggle_ {
        "Afterfire  (pops and bangs on overrun)"
    };

    juce::ComboBox sampleRateSelector_;
    juce::ComboBox formatSelector_;
    juce::ToggleButton stemsToggle_ {
        "Master + exact stems + order map"
    };
    juce::TextButton scenarioButton_ {
        "Scenario JSON..."
    };
    juce::TextButton defaultScenarioButton_ {
        "Default"
    };
    juce::Label scenarioLabel_;
    juce::TextButton exportButton_ {
        "Choose folder and export"
    };
    juce::TextButton cancelButton_ { "Cancel" };
    juce::TextButton revealButton_ {
        "Open folder"
    };
    juce::ComboBox loopStepSelector_;
    juce::ToggleButton loopOggToggle_ { "+ OGG" };
    juce::TextButton loopPackButton_ { "Loop pack for games..." };
    juce::Label proofLabel_;
    double progressValue_ { 0.0 };
    std::atomic<double> threadProgress_ { 0.0 };
    juce::ProgressBar progressBar_;
    std::jthread exportThread_;
    std::unique_ptr<juce::FileChooser> fileChooser_;
    std::array<juce::Label, 8> physicsLabels_;
    juce::Slider cycleVariationSlider_;
    juce::Slider cycleCorrelationSlider_;
    juce::Slider afterfireTemperatureSlider_;
    juce::Slider afterfireReactionSlider_;
    juce::Slider afterfireEfficiencySlider_;
    juce::Slider overrunSparkSlider_;
    juce::Slider pocketMixingSlider_;
    juce::Slider sparkCutSlider_;
    juce::ToggleButton afterfireToggle_ { "Physical afterfire on" };
    juce::ToggleButton wetLimiterToggle_ {
        "Spark-cut limiter / fuel kept"
    };
    juce::TextButton demoPhysicsButton_ { "Audible demo" };
    juce::TextButton bypassPhysicsButton_ { "Bypass" };
    juce::TextButton applyPhysicsButton_ { "Apply live" };
    juce::Label physicsTelemetryLabel_;
    juce::Label physicsStatusLabel_;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(WorkshopContent)
};

AudioWorkshopWindow::AudioWorkshopWindow(
    const EngineConfig& engine,
    std::filesystem::path assetRoot,
    const OfflineAudioMix& mix,
    bool compiledExhaustTopology,
    bool compiledIntakeTopology,
    bool measuredImpulseResponseAvailable,
    MixChangedCallback mixChanged,
    PhysicsApplyCallback physicsApply,
    TelemetryProvider telemetryProvider,
    RunningEngineProvider runningEngine)
    : juce::DocumentWindow(
        "EngineLab - Audio workshop",
        ui::colours::background,
        juce::DocumentWindow::closeButton,
        true) {
    content_ = new WorkshopContent(
        engine, std::move(assetRoot), mix,
        compiledExhaustTopology,
        compiledIntakeTopology,
        measuredImpulseResponseAvailable,
        std::move(mixChanged), std::move(physicsApply),
        std::move(telemetryProvider), std::move(runningEngine));
    setContentOwned(content_, true);
    setUsingNativeTitleBar(true);
    setResizable(true, true);
    setResizeLimits(1'100, 800, 1'700, 1'080);
    centreWithSize(1'280, 860);
}

AudioWorkshopWindow::~AudioWorkshopWindow() = default;

void AudioWorkshopWindow::closeButtonPressed() {
    setVisible(false);
}

void AudioWorkshopWindow::setEngine(
    const EngineConfig& engine,
    std::filesystem::path assetRoot,
    bool compiledExhaustTopology,
    bool compiledIntakeTopology,
    bool measuredImpulseResponseAvailable) {
    if (content_ != nullptr)
        content_->setEngine(
            engine, std::move(assetRoot),
            compiledExhaustTopology,
            compiledIntakeTopology,
            measuredImpulseResponseAvailable);
}

void AudioWorkshopWindow::setMix(
    const OfflineAudioMix& mix) {
    if (content_ != nullptr) content_->setMix(mix);
}

} // namespace enginelab
