#pragma once

#include <enginelab/audio/OfflineAudioExporter.hpp>

#include <juce_gui_extra/juce_gui_extra.h>

#include <filesystem>
#include <functional>
#include <memory>
#include <array>

namespace enginelab {

struct AudioWorkshopAvailability final {
    bool compiledExhaustTopology { false };
    bool compiledIntakeTopology { false };
    bool measuredImpulseResponseAvailable { false };
};

struct AudioWorkshopLayerSwitches final {
    /** combustion, exhaust, intake+FI, structure/mechanical */
    std::array<bool, 4> muted {};
    std::array<bool, 4> solo {};
};

/** Authored controls that make the pressure/exhaust audio physics audible.
 *  The two switches are the only way to turn backfires on: an engine is
 *  always loaded with them off (`disableBackfires`). */
struct AudioPhysicsSettings final {
    double cycleVariationCoefficientOfVariation { 0.0 };
    double cycleVariationCorrelation { 0.45 };
    /** Overrun backfires: a late-spark map whose late-burning charge goes on
     *  burning in the pipe (`ExhaustAfterfireStrategy::lateSparkOverrun`). */
    bool afterfireEnabled { false };
    bool limiterKeepsFuel { false };
    double afterfireIgnitionTemperatureK { 900.0 };
    double afterfireReactionTimeSeconds { 0.010 };
    double afterfireEfficiency { 0.95 };
    /** Append new members below this comment: the aggregate is initialised
     *  by position. */
    double overrunSparkAdvanceDegrees { -30.0 };
    double pocketMixingTimeSeconds { 0.0 };
    double overrunSparkCutFraction { 0.0 };
};

/** Live proof that the authored controls are active in the simulator. */
struct AudioPhysicsTelemetry final {
    double minimumCycleMultiplier { 1.0 };
    double maximumCycleMultiplier { 1.0 };
    double afterfireHeatReleaseKw { 0.0 };
    double afterfireFuelBurnMgPerSecond { 0.0 };
    bool overrunAfterfireActive { false };
    std::size_t porousMufflerCount { 0 };
};

[[nodiscard]] AudioPhysicsSettings audioPhysicsSettingsFor(
    const EngineConfig& engine) noexcept;
void applyAudioPhysicsSettings(
    EngineConfig& engine, const AudioPhysicsSettings& settings) noexcept;
[[nodiscard]] AudioPhysicsTelemetry audioPhysicsTelemetryFor(
    const EngineConfig& engine, const EngineState& state) noexcept;

/** Apply availability plus source mute/solo without modifying visible faders. */
[[nodiscard]] OfflineAudioMix effectiveAudioWorkshopMix(
    const OfflineAudioMix& baseMix,
    const AudioWorkshopAvailability& availability,
    const AudioWorkshopLayerSwitches& switches) noexcept;

/** Standalone source mixer and deterministic HQ-export front end.
 *
 * `baseMix` retains the visible fader values. `effectiveMix` additionally
 * applies mute/solo and physical-path availability, so MainComponent can keep
 * user intent separate from the values currently published to the audio thread.
 */
class AudioWorkshopWindow final : public juce::DocumentWindow {
public:
    using MixChangedCallback = std::function<void(
        const OfflineAudioMix& baseMix,
        const OfflineAudioMix& effectiveMix)>;
    using PhysicsApplyCallback = std::function<bool(
        const AudioPhysicsSettings& settings)>;
    using TelemetryProvider = std::function<AudioPhysicsTelemetry()>;
    /** The engine as it runs now: its configuration after every live edit,
     *  and its ECU tables. */
    struct RunningEngine final {
        EngineConfig config;
        std::shared_ptr<const calibration::CalibrationSnapshot> calibration;
    };
    /** Read when an export starts, so it renders the running engine: the
     *  copy the window holds missed live edits and the ECU tuning (audit
     *  APP-03, UA-01). */
    using RunningEngineProvider = std::function<RunningEngine()>;

    AudioWorkshopWindow(
        const EngineConfig& engine,
        std::filesystem::path assetRoot,
        const OfflineAudioMix& mix,
        bool compiledExhaustTopology,
        bool compiledIntakeTopology,
        bool measuredImpulseResponseAvailable,
        MixChangedCallback mixChanged,
        PhysicsApplyCallback physicsApply = {},
        TelemetryProvider telemetryProvider = {},
        RunningEngineProvider runningEngine = {});
    ~AudioWorkshopWindow() override;

    void closeButtonPressed() override;
    void setEngine(
        const EngineConfig& engine,
        std::filesystem::path assetRoot,
        bool compiledExhaustTopology,
        bool compiledIntakeTopology,
        bool measuredImpulseResponseAvailable);
    /** Synchronise external fader changes without discarding mute/solo state. */
    void setMix(const OfflineAudioMix& mix);

private:
    class WorkshopContent;
    WorkshopContent* content_ {};
    /** Its own tooltips: a tooltip window parented to another window shows
        none over this one. */
    juce::TooltipWindow tooltips_ { this, 650 };

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(AudioWorkshopWindow)
};

} // namespace enginelab
