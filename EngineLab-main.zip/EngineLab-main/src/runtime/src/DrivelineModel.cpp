#include <enginelab/runtime/DrivelineModel.hpp>
#include <enginelab/runtime/ShiftSchedule.hpp>
#include <enginelab/runtime/VariatorControl.hpp>
#include <array>
#include <algorithm>
#include <cmath>
#include <numbers>

namespace enginelab {

namespace {
double synchronisationTorqueRelease(double speedMatchedFraction) noexcept {
    const auto matched = std::clamp(speedMatchedFraction, 0.0, 1.0);
    const auto smoothMatched = matched * matched * (3.0 - 2.0 * matched);
    // The clutch is still dissipating kinetic-slip power until it enters the
    // lock band. Restoring engine torque linearly with the matched-speed
    // fraction makes combustion torque fight that dissipation through most of
    // the hand-over. A second smooth stage keeps the intervention dominant
    // while slip power is material, yet retains zero slope at both endpoints
    // and returns exactly to the driver's torque at synchronism.
    return smoothMatched * smoothMatched;
}
} // namespace

DrivelineModel::DrivelineModel(const EngineConfig& config) : config_(config) {
    clutchTemperatureC_ = config_.ambientTemperatureC;
    engineInertiaKgM2_ = std::max(0.001, effectiveRotatingInertiaKgM2(config_));
    variatorRatio_ = variatorLowestRatio();
    scheduleRatios_.assign(config_.transmission.gearRatios.size(), 0.0);
}

bool DrivelineModel::replaceVehicle(const TransmissionConfig& transmission, const VehicleConfig& vehicle) {
    if (transmission.gearRatios.size() != config_.transmission.gearRatios.size()) return false;
    // Automatic or manual is a driving mode, switched while driving like the
    // gear: an edit of the gearbox keeps it.
    const auto automatic = config_.transmission.automaticShifting;
    const auto wasVariable = continuouslyVariable();
    const auto gearboxRatio = engagedGear_ >= 0 && !wasVariable
        ? config_.transmission.gearRatios[static_cast<std::size_t>(engagedGear_)] : variatorRatio_;
    config_.transmission = transmission;
    config_.transmission.automaticShifting = automatic;
    config_.vehicle = vehicle;
    // Becoming a CVT, the variator takes the ratio of the gear it was in;
    // ceasing to be one, the selector goes to first.
    if (continuouslyVariable()) {
        variatorRatio_ = std::clamp(gearboxRatio, variatorTallestRatio(), variatorLowestRatio());
        if (requestedGear_ > 0) requestedGear_ = 0;
        if (engagedGear_ > 0) engagedGear_ = 0;
    } else if (wasVariable) {
        variatorRatio_ = variatorLowestRatio();
    }
    return true;
}

void DrivelineModel::setAtmosphere(double pressureKpa, double temperatureC) noexcept {
    config_.ambientPressureKpa = pressureKpa;
    config_.ambientTemperatureC = temperatureC;
}

void DrivelineModel::requestGear(int gear) noexcept {
    // A CVT has one forward position.
    const auto maximum = continuouslyVariable() ? 0 : static_cast<int>(config_.transmission.gearRatios.size()) - 1;
    const auto selected = std::clamp(gear, -2, maximum);
    // A real selector cannot engage a ratio that would instantly reverse a
    // moving driveline. Neutral remains available so the vehicle can coast to
    // the low-speed interlock before reverse/forward is requested again.
    constexpr double directionInterlockMps = 0.5;
    if ((selected == -2 && vehicleSpeedMps_ > directionInterlockMps)
        || (selected >= 0 && vehicleSpeedMps_ < -directionInterlockMps))
        return;
    requestedGear_ = selected;
}

void DrivelineModel::shiftUp() noexcept { requestGear(requestedGear_ + 1); }
void DrivelineModel::shiftDown() noexcept { requestGear(requestedGear_ - 1); }

double DrivelineModel::ratioForGear(int gear) const noexcept {
    if (gear == -2) return -config_.transmission.reverseRatio * config_.transmission.finalDriveRatio;
    if (gear < 0 || gear >= static_cast<int>(config_.transmission.gearRatios.size())) return 0.0;
    if (continuouslyVariable()) return variatorRatio_ * config_.transmission.finalDriveRatio;
    return config_.transmission.gearRatios[static_cast<std::size_t>(gear)]
        * config_.transmission.finalDriveRatio;
}

double DrivelineModel::variatorLowestRatio() const noexcept {
    const auto& ratios = config_.transmission.gearRatios;
    return ratios.empty() ? 1.0 : std::max(ratios.front(), ratios.back());
}

double DrivelineModel::variatorTallestRatio() const noexcept {
    const auto& ratios = config_.transmission.gearRatios;
    return ratios.empty() ? 1.0 : std::min(ratios.front(), ratios.back());
}

void DrivelineModel::advanceVariator(const EngineState& engineState, double clutchPressure,
                                     double dtSeconds) noexcept {
    const auto& transmission = config_.transmission;
    VariatorInput input;
    input.driverThrottle = driverThrottle_ >= 0.0 ? driverThrottle_ : engineState.throttle;
    input.outputRadPerSecond = wheelAngularVelocityRadPerSecond_ * transmission.finalDriveRatio;
    input.lowestRatio = variatorLowestRatio();
    input.tallestRatio = variatorTallestRatio();
    input.currentRatio = variatorRatio_;
    input.idleRpm = config_.idleRpm;
    input.revLimitRpm = engineState.activeRevLimitRpm > 0.0
        ? engineState.activeRevLimitRpm : config_.ignition.revLimitRpm;
    const auto lockBandRpm = std::max(1.0, transmission.clutchLockSpeedRpm);
    if (transmission.centrifugalClutch) {
        input.centrifugalLockRpm = VariatorControl::centrifugalLockRpm(
            transmission.centrifugalClutchEngageRpm, config_.idleRpm);
        input.coupled = clutchPressure > 0.999 && std::abs(lastClutchSlipRpm_) < lockBandRpm;
    } else {
        input.coupled = launchClutchLocked_;
    }
    variatorRatio_ = VariatorControl::nextRatio(input, dtSeconds);
}

double DrivelineModel::selectedRatio() const noexcept {
    return dogsFree_ ? 0.0 : ratioForGear(engagedGear_);
}

int DrivelineModel::protectedDownshiftTarget(const EngineState& engineState) const noexcept {
    const auto limitRpm = engineState.activeRevLimitRpm > 0.0
        ? engineState.activeRevLimitRpm : config_.ignition.revLimitRpm;
    for (int gear = requestedGear_; gear < engagedGear_; ++gear) {
        const auto landingRpm = std::abs(wheelAngularVelocityRadPerSecond_ * ratioForGear(gear))
            * 60.0 / (2.0 * std::numbers::pi);
        if (landingRpm <= limitRpm) return gear;
    }
    return engagedGear_;
}

double DrivelineModel::dualClutchLaunchPressure(const EngineState& engineState,
                                                double brakePressure, double dtSeconds) noexcept {
    const auto& transmission = config_.transmission;
    const auto idleRpm = std::max(300.0, config_.idleRpm);
    const auto lockBandRpm = std::max(1.0, transmission.clutchLockSpeedRpm);
    const auto smoothStep = [](double x) noexcept {
        const auto t = std::clamp(x, 0.0, 1.0);
        return t * t * (3.0 - 2.0 * t);
    };
    // Shut once the engine turns with the gearbox above idle; open again only
    // when the engine nears idle, as a dual clutch does coming to a stop.
    if (launchClutchLocked_ && engineState.rpm < 1.1 * idleRpm)
        launchClutchLocked_ = false;
    else if (!launchClutchLocked_ && engagedGear_ >= 0 && launchClutchPressure_ > 0.9
             && engineState.rpm > 1.2 * idleRpm && std::abs(lastClutchSlipRpm_) < lockBandRpm)
        launchClutchLocked_ = true;
    auto target = 1.0;
    if (!launchClutchLocked_) {
        // The launch speed rises with the throttle, to about 38 % of the
        // redline at full throttle; the clutch is fully shut there.
        const auto throttle = std::clamp(engineState.throttle, 0.0, 1.0);
        const auto launchRpm = idleRpm
            + throttle * std::max(200.0, 0.38 * config_.redlineRpm - idleRpm);
        // Foot off, only the creep: the idle controller's few rpm above idle
        // must not close the clutch.
        const auto rise = smoothStep(throttle / 0.05)
            * smoothStep((engineState.rpm - idleRpm) / std::max(100.0, launchRpm - idleRpm));
        // Creep: a small fixed clutch torque at idle, released on the brake.
        constexpr double creepClutchTorqueNm = 25.0;
        constexpr double creepCapacityShare = 0.05;
        const auto maximumTorque = std::max(1.0, transmission.maxClutchTorqueNm);
        const auto creep = brakePressure > 0.2 ? 0.0
            : std::min(creepClutchTorqueNm, creepCapacityShare * maximumTorque) / maximumTorque;
        // Opens before the engine stalls.
        const auto stallGuard = smoothStep((engineState.rpm - 0.75 * idleRpm) / (0.2 * idleRpm));
        target = stallGuard * (creep + (1.0 - creep) * rise);
    }
    // A hydraulic clutch fills in about a tenth of a second and dumps faster
    // (neither measured).
    constexpr double fillSeconds = 0.10;
    constexpr double dumpSeconds = 0.03;
    const auto timeConstant = target > launchClutchPressure_ ? fillSeconds : dumpSeconds;
    launchClutchPressure_ += (target - launchClutchPressure_)
        * std::clamp(dtSeconds / timeConstant, 0.0, 1.0);
    return launchClutchPressure_;
}

DrivelineModel::ShiftAction DrivelineModel::chooseShiftAction(double clutchPedal) const noexcept {
    const auto& transmission = config_.transmission;
    // With the clutch held out the driver makes the shift: no device acts.
    constexpr double declutchedPedal = 0.5;
    if (driverClutchConnected() && clutchPedal < declutchedPedal)
        return ShiftAction::driverClutch;
    // Only a change between two forward gears; neutral and reverse are
    // always selected the manual way.
    if (shiftFromGear_ < 0 || shiftTargetGear_ < 0 || shiftFromGear_ == shiftTargetGear_)
        return ShiftAction::timed;
    if (shiftTargetGear_ > shiftFromGear_) {
        if (transmission.shiftStyle == ShiftStyle::sequential && transmission.quickshifter)
            return ShiftAction::quickshift;
        if (transmission.shiftStyle == ShiftStyle::dualClutch)
            return ShiftAction::handOver;
        return ShiftAction::timed;
    }
    // An automated manual's controller blips down too: it opens its clutch,
    // frees the dogs and brings the engine to the lower gear's speed.
    if ((transmission.shiftStyle == ShiftStyle::sequential && transmission.autoBlipper)
            || transmission.shiftStyle == ShiftStyle::dualClutch
            || transmission.shiftStyle == ShiftStyle::automatedManual)
        return ShiftAction::blip;
    return ShiftAction::timed;
}

DrivelineOutput DrivelineModel::advance(double dt, const EngineState& engineState,
                                        double requestedLoad, double clutchPedal,
                                        double brakePressure) noexcept {
    DrivelineOutput output;
    dt = std::isfinite(dt) ? std::clamp(dt, 0.0, 0.05) : 0.0;
    requestedLoad = std::isfinite(requestedLoad) ? std::clamp(requestedLoad, 0.0, 1.0) : 0.0;
    clutchPedal = std::isfinite(clutchPedal) ? std::clamp(clutchPedal, 0.0, 1.0) : 0.0;
    brakePressure = std::isfinite(brakePressure) ? std::clamp(brakePressure, 0.0, 1.0) : 0.0;
    const auto& transmission = config_.transmission;
    const auto& vehicle = config_.vehicle;
    const auto maximumGear = static_cast<int>(transmission.gearRatios.size()) - 1;

    const auto engineOmega = engineState.angularVelocityRadPerSecond;
    // The crank's own torque this tick (combustion brake torque plus any starter),
    // used by the locked-clutch constraint. It is a one-tick estimate of a quantity
    // that changes slowly next to the tick, and the friction capacity bounds it.
    // The driveline advances once per public 240 Hz frame while chamber torque
    // is resolved at many crank-angle substeps. Feeding the last instantaneous
    // pressure torque into a one-frame-ahead rigid-clutch constraint aliases a
    // firing pulse into an equal-and-opposite reaction on the next frame. Use
    // the completed-cycle work for the mean constraint load; torsional ripple
    // remains in EngineSimulator, but cannot be phase-inverted by the slower
    // vehicle coupling.
    // A crank at rest makes no resistive torque of its own: its friction is a
    // reaction that only opposes motion. Passed through a locked clutch as a
    // drive torque, a stalled engine's friction rolled the car backwards at a
    // steady 0.3 km/h, the crank being held at zero against it.
    const auto crankTorque = engineState.simulationTimeSeconds > 0.0 && engineState.rpm > 220.0
        ? engineState.cycleAveragedTorqueNm
        : engineState.torqueNm;
    const auto engineDriveTorque = (engineOmega > 0.0 ? crankTorque : std::max(0.0, crankTorque))
        + engineState.starterTorqueNm;
    secondsSinceShift_ += dt;
    // The engine's rate of climb over about 0.1 s.
    if (dt > 0.0 && previousEngineRpm_ >= 0.0 && std::isfinite(engineState.rpm)) {
        const auto rate = (engineState.rpm - previousEngineRpm_) / dt;
        engineRpmRate_ += (rate - engineRpmRate_) * std::clamp(dt / 0.1, 0.0, 1.0);
    }
    previousEngineRpm_ = std::isfinite(engineState.rpm) ? engineState.rpm : previousEngineRpm_;
    // An automatic gearbox picks its gear from the driver's pedal, never
    // right after a shift, and never while the driver holds the clutch.
    constexpr double scheduleHoldSeconds = 0.8;
    if (transmission.automaticShifting && !continuouslyVariable() && !shiftInProgress_ && engagedGear_ >= 0
        && requestedGear_ == engagedGear_ && secondsSinceShift_ >= scheduleHoldSeconds
        && (!driverClutchConnected() || clutchPedal >= 0.5)) {
        // Sized with the gearbox (any count): no allocation in a frame.
        auto& overall = scheduleRatios_;
        const auto count = std::min(overall.size(), transmission.gearRatios.size());
        for (std::size_t gear = 0; gear < count; ++gear) overall[gear] = ratioForGear(static_cast<int>(gear));
        ShiftScheduleInput schedule;
        schedule.engineRpm = engineState.rpm;
        // An automated manual changes up at the point itself: its fuel and
        // spark go at the start of the shift, so the engine no longer climbs
        // while the clutch opens. (On a throttle lift alone it did, 1,000
        // rpm/s in a loaded truck's first, and the controller had to start a
        // third of the shift early.)
        schedule.driverThrottle = driverThrottle_ >= 0.0 ? driverThrottle_ : engineState.throttle;
        schedule.engagedGear = engagedGear_;
        schedule.overallRatios = std::span<const double>(overall.data(), count);
        schedule.wheelRadPerSecond = wheelAngularVelocityRadPerSecond_;
        schedule.idleRpm = config_.idleRpm;
        schedule.revLimitRpm = engineState.activeRevLimitRpm > 0.0
            ? engineState.activeRevLimitRpm : config_.ignition.revLimitRpm;
        schedule.fullThrottleUpshiftRpm = transmission.automaticUpshiftRpm;
        schedule.coastDownshiftRpm = transmission.automaticDownshiftRpm;
        schedule.brake = brakePressure;
        if (const auto gear = ShiftSchedule::chooseGear(schedule); gear != engagedGear_)
            requestGear(std::min(gear, maximumGear));
    }
    // A dual clutch has no pedal: its own launch clutch takes its place, and
    // it refuses the part of a downshift that would over-rev the engine.
    if (continuouslyVariable() && transmission.centrifugalClutch) {
        clutchPedal = VariatorControl::centrifugalClutchPressure(
            engineState.rpm, transmission.centrifugalClutchEngageRpm, config_.idleRpm);
    } else if (!driverClutchConnected()) {
        clutchPedal = dualClutchLaunchPressure(engineState, brakePressure, dt);
        if (!shiftInProgress_ && requestedGear_ >= 0 && engagedGear_ > requestedGear_)
            requestedGear_ = protectedDownshiftTarget(engineState);
    }
    if (!shiftInProgress_ && requestedGear_ != engagedGear_) {
        shiftInProgress_ = true;
        shiftTargetGear_ = requestedGear_;
        shiftFromGear_ = engagedGear_;
        shiftElapsedSeconds_ = 0.0;
        secondsSinceShift_ = 0.0;
        resyncReferenceSlipRpm_ = 0.0;
        shiftAction_ = chooseShiftAction(clutchPedal);
        handOverReferenceSlipRadPerSecond_ = 0.0;
        automatedTorqueGone_ = !(transmission.shiftStyle == ShiftStyle::automatedManual
            && shiftAction_ == ShiftAction::timed && shiftFromGear_ >= 0
            && shiftTargetGear_ > shiftFromGear_);
        automatedTorqueOffSeconds_ = 0.0;
    }
    double shiftProgress = 0.0;
    double effectiveClutch = clutchPedal;
    const auto finishShift = [&]() noexcept {
        engagedGear_ = shiftTargetGear_;
        dogsFree_ = false;
        shiftInProgress_ = false;
        shiftProgress = 0.0;
    };
    if (shiftInProgress_ && shiftAction_ == ShiftAction::driverClutch) {
        finishShift();
    } else if (shiftInProgress_ && shiftAction_ == ShiftAction::quickshift) {
        // The shift sensor trips, the ignition is cut and the unloaded dogs
        // slide over to the next gear with the clutch left in; the clutch
        // then pulls the engine down to the new gear's speed while it makes
        // no torque. A cut too short for that leaves the engine firing into
        // the slip. The drum and dog travel is not measured; a sequential
        // drum turns in about 10-20 ms.
        constexpr double dogChangeSeconds = 0.015;
        const auto cutSeconds = std::max(0.01, transmission.quickshifterCutSeconds);
        shiftElapsedSeconds_ += dt;
        shiftProgress = std::clamp(shiftElapsedSeconds_ / cutSeconds, 0.0, 1.0);
        output.ignitionCut = shiftElapsedSeconds_ <= cutSeconds;
        if (shiftElapsedSeconds_ >= std::min(dogChangeSeconds, 0.5 * cutSeconds))
            engagedGear_ = shiftTargetGear_;
        if (shiftElapsedSeconds_ >= cutSeconds) finishShift();
    } else if (shiftInProgress_ && shiftAction_ == ShiftAction::blip) {
        // The blip unloads the dogs, which come free; the throttle stays open
        // until the engine reaches the speed the new gear will turn it at,
        // and the dogs engage there. A blipper that cannot get there in time
        // engages anyway and the clutch takes the rest.
        constexpr double maximumBlipSeconds = 0.30;
        constexpr double matchedFraction = 0.98;
        shiftElapsedSeconds_ += dt;
        dogsFree_ = true;
        const auto targetOmega = std::abs(
            wheelAngularVelocityRadPerSecond_ * ratioForGear(shiftTargetGear_));
        const auto missing = targetOmega - engineOmega;
        // Wide open until the last 15 % of the climb, then closing with it.
        output.blipThrottle = targetOmega > 0.0
            ? std::clamp(missing / (0.15 * targetOmega), 0.0, 1.0) : 0.0;
        shiftProgress = std::clamp(shiftElapsedSeconds_ / maximumBlipSeconds, 0.0, 1.0);
        // The driver pulling the clutch mid-blip takes the shift over.
        const auto driverDeclutched = driverClutchConnected() && clutchPedal < 0.5;
        if (engineOmega >= targetOmega * matchedFraction
                || shiftElapsedSeconds_ >= maximumBlipSeconds || driverDeclutched) {
            output.blipThrottle = 0.0;
            finishShift();
        }
    } else if (shiftInProgress_ && shiftAction_ == ShiftAction::handOver) {
        // The oncoming clutch takes the drive at once: no torque gap. Its
        // pressure is held to carry the engine's torque plus what pulls the
        // engine down to the new gear's speed over shiftDurationSeconds; the
        // engine's torque is not reduced meanwhile, so the wheel feels that
        // released inertia as a push.
        shiftElapsedSeconds_ += dt;
        engagedGear_ = shiftTargetGear_;
        const auto slipOmega = engineOmega
            - wheelAngularVelocityRadPerSecond_ * ratioForGear(shiftTargetGear_);
        if (!(handOverReferenceSlipRadPerSecond_ > 0.0))
            handOverReferenceSlipRadPerSecond_ = std::max(1.0, std::abs(slipOmega));
        const auto lockBandOmega = std::max(1.0, transmission.clutchLockSpeedRpm)
            * 2.0 * std::numbers::pi / 60.0;
        const auto syncTorque = engineInertiaKgM2_ * handOverReferenceSlipRadPerSecond_
            / std::max(0.02, transmission.shiftDurationSeconds);
        const auto neededCapacity = std::abs(engineDriveTorque) + syncTorque;
        effectiveClutch = clutchPedal * std::clamp(
            neededCapacity / std::max(1.0, transmission.maxClutchTorqueNm), 0.0, 1.0);
        shiftProgress = std::clamp(
            1.0 - std::abs(slipOmega) / handOverReferenceSlipRadPerSecond_, 0.0, 1.0);
        // A loaded upshift: the ECU retards the spark while the clutch pulls
        // the engine down, and gives it back as the speeds meet, as a dual
        // clutch's torque intervention does.
        // Past the retard's floor the ECU meets the rest of the request by
        // cutting injection on a share of the firings.
        if (shiftTargetGear_ > shiftFromGear_ && engineDriveTorque > 0.0) {
            const auto release = synchronisationTorqueRelease(1.0 - shiftProgress);
            output.sparkRetardDegrees = std::max(0.0, transmission.dualClutchUpshiftRetardDegrees)
                * release;
            output.cylinderCutFraction = std::clamp(
                transmission.dualClutchUpshiftCylinderCutFraction, 0.0, 1.0) * release;
        }
        if (std::abs(slipOmega) <= lockBandOmega
                || shiftElapsedSeconds_ >= 4.0 * transmission.shiftDurationSeconds) {
            effectiveClutch = clutchPedal;
            finishShift();
        }
    } else if (shiftInProgress_ && !automatedTorqueGone_) {
        // An automated manual's upshift: its controller cuts fuel and spark
        // with the clutch still shut, so the engine's torque leaves the
        // driveline while the car still holds the engine's speed; the clutch
        // opens only once that torque has gone. Opened first on a throttle
        // lift alone, the manifold's charge kept firing into an open clutch
        // and the engine flared (owner 2026-11-14). The completed-cycle
        // torque lags a cycle; a cut that has not taken it away in
        // automatedTorqueOffLimitSeconds opens the clutch anyway.
        constexpr double automatedTorqueOffLimitSeconds = 0.15;
        automatedTorqueOffSeconds_ += dt;
        output.ignitionCut = true;
        output.torqueCutMultiplier = 0.0;
        shiftProgress = 0.0;
        if (engineDriveTorque <= 0.0 || automatedTorqueOffSeconds_ >= automatedTorqueOffLimitSeconds)
            automatedTorqueGone_ = true;
    } else if (shiftInProgress_) {
        shiftElapsedSeconds_ += dt;
        shiftProgress = std::clamp(shiftElapsedSeconds_ / transmission.shiftDurationSeconds, 0.0, 1.0);
        if (shiftProgress < 0.35) effectiveClutch *= 1.0 - shiftProgress / 0.35;
        else if (shiftProgress < 0.60) effectiveClutch = 0.0;
        else effectiveClutch *= (shiftProgress - 0.60) / 0.40;
        if (shiftProgress >= 0.48) engagedGear_ = shiftTargetGear_;
        const auto forwardUpshift = shiftFromGear_ >= 0
            && shiftTargetGear_ > shiftFromGear_;
        const auto lockBandRpm = std::max(
            1.0, transmission.clutchLockSpeedRpm);
        // The new ratio becomes active just before halfway through the timer.
        // On the following frame lastClutchSlipRpm_ is therefore the first
        // measured slip in that ratio and is a stable reference for the
        // synchronisation phase.
        if (forwardUpshift && shiftProgress >= 0.52
            && resyncReferenceSlipRpm_ <= lockBandRpm
            && std::abs(lastClutchSlipRpm_) > lockBandRpm) {
            resyncReferenceSlipRpm_ =
                std::abs(lastClutchSlipRpm_);
        }

        // An automated manual's controller takes the engine's torque away
        // whole before its clutch is half open, and gives it back only as the
        // clutch locks in the new gear: a driver's foot left flat on the pedal
        // flared the engine onto its limiter while the clutch was open (owner
        // 2026-11-09, a designed truck: +400 rpm, 0.28 s on the limiter).
        const auto automated = transmission.shiftStyle == ShiftStyle::automatedManual;
        const auto cutDepth = automated ? 1.0 : std::clamp(
            transmission.shiftTorqueCutFraction, 0.0, 1.0);
        const auto cutFloor = 1.0 - cutDepth;
        // Its fuel and spark stay cut while the clutch is open (the torque
        // went before it opened, above) and come back as it closes, the
        // throttle then following the clutch's slip.
        if (automated && forwardUpshift && shiftProgress < 0.60) output.ignitionCut = true;
        if (automated && forwardUpshift && !(shiftProgress > 0.50 && resyncReferenceSlipRpm_ > lockBandRpm)) {
            output.torqueCutMultiplier = cutFloor;
        } else if (forwardUpshift && shiftProgress > 0.50
            && resyncReferenceSlipRpm_ > lockBandRpm) {
            // Do not restore engine torque merely because a wall-clock shift
            // timer is ending. Release it with the actual clutch slip instead:
            // this prevents rising combustion torque and clutch synchronising
            // torque from fighting across the same few frames, the physical
            // source of the boosted-engine "gear crack".
            const auto remainingSlip = std::clamp(
                (std::abs(lastClutchSlipRpm_) - lockBandRpm)
                    / std::max(1.0,
                        resyncReferenceSlipRpm_ - lockBandRpm),
                0.0, 1.0);
            const auto release = 1.0 - remainingSlip;
            output.torqueCutMultiplier =
                cutFloor + cutDepth * synchronisationTorqueRelease(release);
        } else {
            output.torqueCutMultiplier = 1.0 - cutDepth
                * std::sin(std::numbers::pi
                    * std::clamp(shiftProgress, 0.0, 1.0));
        }
        if (shiftProgress >= 1.0) {
            engagedGear_ = shiftTargetGear_;
            shiftInProgress_ = false;
            shiftProgress = 0.0;
        }
    } else if (resyncReferenceSlipRpm_
        > std::max(1.0, transmission.clutchLockSpeedRpm)) {
        // A high-power upshift can still be synchronising after the selector
        // timer has completed. Keep the same slip-following torque envelope
        // until the dry clutch enters its lock band, then return exactly to
        // the driver's requested torque.
        const auto lockBandRpm = std::max(
            1.0, transmission.clutchLockSpeedRpm);
        const auto currentSlip = std::abs(lastClutchSlipRpm_);
        if (currentSlip <= lockBandRpm) {
            resyncReferenceSlipRpm_ = 0.0;
            output.torqueCutMultiplier = 1.0;
        } else {
            const auto remainingSlip = std::clamp(
                (currentSlip - lockBandRpm)
                    / std::max(1.0,
                        resyncReferenceSlipRpm_ - lockBandRpm),
                0.0, 1.0);
            const auto release = 1.0 - remainingSlip;
            const auto cutDepth = transmission.shiftStyle == ShiftStyle::automatedManual ? 1.0 : std::clamp(
                transmission.shiftTorqueCutFraction, 0.0, 1.0);
            output.torqueCutMultiplier =
                1.0 - cutDepth
                    + cutDepth * synchronisationTorqueRelease(release);
        }
    }

    // A CVT's ratio moves through the frame, from where it was to where the
    // variator takes it; other gearboxes hold one ratio (start == end).
    const auto frameStartRatio = selectedRatio();
    if (continuouslyVariable() && engagedGear_ >= 0 && !dogsFree_)
        advanceVariator(engineState, effectiveClutch, dt);
    const auto frameEndRatio = selectedRatio();
    const auto ratioRate = dt > 0.0 ? (frameEndRatio - frameStartRatio) / dt : 0.0;
    const auto inertiaAtRatio = [&](double ratio) noexcept {
        return std::max(0.01, transmission.drivenWheelInertiaKgM2
            + transmission.differentialInertiaKgM2
            + transmission.gearboxInputInertiaKgM2 * ratio * ratio);
    };
    const auto wheelInertia = inertiaAtRatio(frameEndRatio);
    constexpr double gravityMps2 = 9.80665;
    const auto totalNormalForce = vehicle.massKg * gravityMps2;
    const auto drivenAxleNormalForce = [&](double accelerationMps2) noexcept {
        if (vehicle.drivenAxleLayout == DrivenAxleLayout::all)
            return totalNormalForce;
        const auto staticNormalForce =
            totalNormalForce * vehicle.drivenAxleWeightFraction;
        // Quasi-static pitch equilibrium: m*a*h/L moves load rearward under
        // positive acceleration. It therefore helps a rear driven axle and
        // unloads a front driven axle; reverse acceleration swaps the effect.
        const auto longitudinalTransfer = vehicle.massKg * accelerationMps2
            * vehicle.centerOfGravityHeightM / vehicle.wheelbaseM;
        const auto dynamicNormalForce =
            vehicle.drivenAxleLayout == DrivenAxleLayout::rear
            ? staticNormalForce + longitudinalTransfer
            : staticNormalForce - longitudinalTransfer;
        return std::clamp(dynamicNormalForce, 0.0, totalNormalForce);
    };
    const auto brakeForceCapacity = vehicle.maximumBrakeForceN * brakePressure;
    // The tire relaxation time is much shorter than the public simulation step.
    // Integrating that stiff coupling at 1 ms keeps the result stable at every time scale
    // without weakening the physical tire stiffness or hiding instability behind clamps.
    const auto mechanicalStepCount = std::max(1, static_cast<int>(std::ceil(dt / 0.001)));
    const auto mechanicalDt = mechanicalStepCount > 0 ? dt / mechanicalStepCount : 0.0;
    double clutchTorqueIntegral = 0.0;
    double engineCouplingTorqueIntegral = 0.0;
    double reflectedInertiaTimeIntegral = 0.0;
    double wheelTorqueIntegral = 0.0;
    double clutchLossEnergy = 0.0;
    double wheelInputWork = 0.0;
    double roadWork = 0.0;
    double brakeWork = 0.0;
    double roadLoadWork = 0.0;
    double tireSlipWork = 0.0;
    double drivenAxleNormalImpulse = 0.0;
    double longitudinalAccelerationImpulse = 0.0;
    std::size_t clutchStickingSteps = 0;
    double lastSlipRpm = 0.0;
    double lastTireForce = 0.0;
    double lastRoadLoadForce = 0.0;
    // The engine itself is integrated by EngineSimulator after this call, from
    // the frame-mean clutch reaction returned below. The mechanical loop still
    // needs a local prediction of that same response: keeping engineOmega
    // frozen while the wheel advances through four or five 1 ms substeps makes
    // a locked clutch overshoot synchronism, reverse its full kinetic-friction
    // torque on the next substep, and repeat. At high ratio this appeared as
    // +/- clutch capacity and 200-300 rpm crank jumps every public 240 Hz tick.
    //
    // This predictor does not become a second crank state and is never
    // published. It integrates the same estimated drive torque and clutch
    // reaction solely for the next local slip evaluation; EngineSimulator
    // remains authoritative and receives the time-averaged reaction exactly as
    // before.
    auto predictedEngineOmega = engineOmega;
    // Counted, not latched. This used to be a sticky OR across the mechanical
    // sub-steps, so a single clipped sub-step out of five lit the indicator for
    // the whole frame -- and with a slip-velocity spring this stiff, one clipped
    // sub-step happens on every gearshift and every kerb-strength transient. The
    // panel then showed a permanent "tyre limited" on an engine cruising far
    // below the limit. Report saturation only when the tyre actually spent most
    // of the frame on its friction limit. Display-only: no physics reads this.
    std::size_t tractionLimitedSteps = 0;
    for (int step = 0; step < mechanicalStepCount; ++step) {
        const auto totalRatio = frameStartRatio + (frameEndRatio - frameStartRatio)
            * static_cast<double>(step + 1) / static_cast<double>(mechanicalStepCount);
        const auto previousWheelOmega = wheelAngularVelocityRadPerSecond_;
        const auto previousVehicleSpeed = vehicleSpeedMps_;
        const auto gearboxOmega = previousWheelOmega * totalRatio;
        const auto slipOmega = predictedEngineOmega - gearboxOmega;
        lastSlipRpm = slipOmega * 60.0 / (2.0 * std::numbers::pi);
        const auto fade = std::clamp((transmission.clutchFailureTemperatureC - clutchTemperatureC_)
            / (transmission.clutchFailureTemperatureC - transmission.clutchFadeStartTemperatureC), 0.0, 1.0);
        const auto capacity = transmission.maxClutchTorqueNm * effectiveClutch * fade;

        const auto speedSquared = previousVehicleSpeed * previousVehicleSpeed;
        const auto speedSign = std::abs(previousVehicleSpeed) > 0.01
            ? std::copysign(1.0, previousVehicleSpeed) : 0.0;
        // The air the engine breathes: 1.225 kg/m3 was ISA's 15 degC sea
        // level whatever the atmosphere (audit PH-04); the default 22 degC
        // and 101.325 kPa give 1.196.
        constexpr double airGasConstantJPerKgK = 287.05;
        const auto airDensityKgPerM3 = config_.ambientPressureKpa * 1'000.0
            / (airGasConstantJPerKgK * (config_.ambientTemperatureC + 273.15));
        const auto aeroForce = 0.5 * airDensityKgPerM3 * vehicle.dragCoefficient
            * vehicle.frontalAreaM2 * speedSquared * speedSign;
        // Below 1 cm/s a car slowing down keeps a rolling resistance that
        // fades with its speed: switched off there, it left a car creeping on
        // at the speed it had when it crossed that line, for ever. A car
        // pulling away keeps none there, as before (a launch is unchanged).
        constexpr double rollingStictionSpeedMps = 0.01;
        const auto slowing = previousVehicleSpeed * longitudinalAccelerationMps2_ <= 0.0;
        const auto rollingDirection = std::abs(previousVehicleSpeed) > rollingStictionSpeedMps ? speedSign
            : (slowing ? previousVehicleSpeed / rollingStictionSpeedMps : 0.0);
        const auto rollingForce = vehicle.massKg * 9.80665
            * vehicle.rollingResistanceCoefficient * rollingDirection;
        const auto motionSign = std::abs(previousWheelOmega) > 0.01
            ? std::copysign(1.0, previousWheelOmega)
            : (std::abs(previousVehicleSpeed) > 0.01
                ? std::copysign(1.0, previousVehicleSpeed) : 0.0);
        const auto brakeTorque = brakeForceCapacity
            * vehicle.tireRadiusM * motionSign;

        // Driven-tyre longitudinal force and wheel-brake torque are resolved
        // before the clutch, because the lock solver needs the road load it
        // must react. With the optional grip model OFF, rolling contact is a
        // rigid no-wheelspin constraint: vehicle translation is reflected as
        // m*r^2 at the wheel instead of approximated by an unbounded stiff
        // slip spring. This is both the documented rolling-road behaviour and
        // the stable interpretation of "no adhesion constraint".
        const auto tireSurfaceSpeed = previousWheelOmega * vehicle.tireRadiusM;
        const auto slipVelocity = tireSurfaceSpeed - previousVehicleSpeed;
        // The preceding 1 ms mechanical sub-step supplies acceleration to the
        // quasi-static pitch equilibrium. This is the same causal update used
        // by the tyre relaxation state and avoids an algebraic traction loop.
        const auto normalForce =
            drivenAxleNormalForce(longitudinalAccelerationMps2_);
        auto wheelInertiaForConstraint = inertiaAtRatio(totalRatio);
        auto wheelLoadTorque = 0.0;
        auto roadLoadForce = 0.0;
        if (vehicle.tyreGripLimitEnabled) {
            const auto tractionLimit =
                vehicle.tireFrictionCoefficient * normalForce;
            const auto tireStiffnessNPerMps = normalForce * 7.5;
            const auto unconstrainedTireForce =
                slipVelocity * tireStiffnessNPerMps;
            lastTireForce = std::clamp(
                unconstrainedTireForce, -tractionLimit, tractionLimit);
            if (std::abs(unconstrainedTireForce) > tractionLimit + 1.0e-6)
                ++tractionLimitedSteps;
            wheelLoadTorque = lastTireForce * vehicle.tireRadiusM
                + brakeTorque;
        } else {
            constexpr double roadLoadDirectionThresholdMps = 1.0e-6;
            const auto vehicleIsMoving = std::abs(previousVehicleSpeed)
                > roadLoadDirectionThresholdMps;
            const auto loadDirection = vehicleIsMoving
                ? std::copysign(1.0, previousVehicleSpeed)
                : (std::abs(totalRatio) > 1.0e-9
                    ? std::copysign(1.0, totalRatio) : 0.0);
            roadLoadForce = requestedLoad * vehicle.maximumBrakeForceN
                * loadDirection;
            lastRoadLoadForce = roadLoadForce;
            wheelInertiaForConstraint += vehicle.massKg
                * vehicle.tireRadiusM * vehicle.tireRadiusM;
            wheelLoadTorque = (aeroForce + rollingForce + roadLoadForce)
                * vehicle.tireRadiusM + brakeTorque;
        }

        // Dry-friction clutch with a Karnopp stick/slip law.
        //  * |slip| outside the lock window -> kinetic friction: it transmits its full
        //    capacity opposing the slip, independent of slip magnitude. This launches
        //    the car and is what dissipates energy and heats the disc.
        //  * inside the lock window -> stick: crank and gearbox input are one rigid
        //    body. We solve their shared acceleration from both inertias, the engine's
        //    own torque and the reflected road load, then read off the coupling torque
        //    that holds synchronism. Being the constraint solution rather than a stiff
        //    slope, this reaction cannot overshoot within a tick, so an engaged clutch
        //    holds the engine's torque at a few rpm of residual slip instead of
        //    slipping without end. The friction capacity still bounds it: when the
        //    demanded stick torque exceeds capacity the clutch breaks away into slip.
        double clutchTorque = 0.0;
        auto clutchSticking = false;
        // A moving ratio: held together, the crank must also follow the
        // change of ratio (its rate times the wheel speed), and any slip left
        // is taken out over a short time rather than left to drift into the
        // kinetic band.
        constexpr double variatorSlipRecoverySeconds = 0.02;
        const auto ratioAcceleration = continuouslyVariable()
            ? ratioRate * previousWheelOmega - slipOmega / variatorSlipRecoverySeconds : 0.0;
        // The gearbox loses its share of the power that crosses it, in either
        // direction: driving, the wheel gets the clutch's torque times the
        // efficiency; back-driven (engine braking), the wheel must give the
        // clutch's torque over it. One law both ways made the crank receive
        // more power than the wheel gave (audit PH-01).
        auto gearboxEfficiency = transmission.drivelineEfficiency;
        if (totalRatio != 0.0 && effectiveClutch > 0.0) {
            const auto lockBandRpm = std::max(1.0, transmission.clutchLockSpeedRpm);
            if (std::abs(lastSlipRpm) > lockBandRpm) {
                clutchTorque = std::copysign(capacity, slipOmega);
                if (clutchTorque * totalRatio * previousWheelOmega < 0.0)
                    gearboxEfficiency = 1.0 / transmission.drivelineEfficiency;
            } else {
                // The coupling torque's sign is its numerator's (the shared
                // inertia is positive), so it says which way the power goes.
                const auto stickNumerator = wheelInertiaForConstraint * engineDriveTorque
                    + engineInertiaKgM2_ * totalRatio * wheelLoadTorque
                    - engineInertiaKgM2_ * wheelInertiaForConstraint * ratioAcceleration;
                if (stickNumerator < 0.0) gearboxEfficiency = 1.0 / transmission.drivelineEfficiency;
                const auto coupledInertia = wheelInertiaForConstraint
                    + engineInertiaKgM2_ * totalRatio * totalRatio * gearboxEfficiency;
                const auto stickTorque = coupledInertia > 0.0 ? stickNumerator / coupledInertia : 0.0;
                clutchTorque = std::clamp(stickTorque, -capacity, capacity);
                clutchSticking = std::abs(stickTorque) <= capacity + 1.0e-9;
            }
        }
        auto engineCouplingTorque = -clutchTorque;
        auto reflectedInertiaKgM2 = 0.0;
        if (clutchSticking && std::abs(totalRatio) > 1.0e-9) {
            ++clutchStickingSteps;
            // Rigid-shaft equivalent referred to the crank. The clutch torque
            // itself contains the torque needed to accelerate wheel/gearbox
            // inertia; applying it as an external load one 240 Hz frame later
            // phase-inverts combustion ripple. Carry that inertia explicitly
            // and reflect only the road-side load torque instead.
            const auto ratioEfficiency = totalRatio * gearboxEfficiency;
            reflectedInertiaKgM2 = wheelInertiaForConstraint
                / (totalRatio * ratioEfficiency);
            engineCouplingTorque = -wheelLoadTorque / ratioEfficiency
                + reflectedInertiaKgM2 * ratioAcceleration;
        }
        const auto wheelTorque = clutchTorque * totalRatio * gearboxEfficiency;
        const auto wheelAcceleration = (wheelTorque - wheelLoadTorque)
            / wheelInertiaForConstraint;
        wheelAngularVelocityRadPerSecond_ += wheelAcceleration * mechanicalDt;
        if (totalRatio != 0.0 && effectiveClutch > 0.0) {
            predictedEngineOmega = std::max(0.0,
                predictedEngineOmega
                    + (engineDriveTorque + engineCouplingTorque)
                        / (engineInertiaKgM2_ + reflectedInertiaKgM2)
                        * mechanicalDt);
        }
        if (brakePressure > 0.0 && previousWheelOmega * wheelAngularVelocityRadPerSecond_ < 0.0)
            wheelAngularVelocityRadPerSecond_ = 0.0;

        if (vehicle.tyreGripLimitEnabled) {
            // The manual vehicle load is an external longitudinal retarder. Its
            // reaction reaches the crank only through tyre, gearbox and clutch.
            const auto unretardedForce =
                lastTireForce - aeroForce - rollingForce;
            constexpr double roadLoadDirectionThresholdMps = 1.0e-6;
            const auto vehicleIsMoving = std::abs(previousVehicleSpeed)
                > roadLoadDirectionThresholdMps;
            const auto loadDirection = vehicleIsMoving
                ? std::copysign(1.0, previousVehicleSpeed)
                : (std::abs(unretardedForce) > 1.0e-6
                    ? std::copysign(1.0, unretardedForce) : 0.0);
            const auto roadLoadCapacity =
                requestedLoad * vehicle.maximumBrakeForceN;
            const auto roadLoadMagnitude = vehicleIsMoving
                ? roadLoadCapacity
                : std::min(roadLoadCapacity, std::abs(unretardedForce));
            roadLoadForce = roadLoadMagnitude * loadDirection;
            lastRoadLoadForce = roadLoadForce;
            longitudinalAccelerationMps2_ =
                (lastTireForce - aeroForce - rollingForce - roadLoadForce)
                / vehicle.massKg;
            vehicleSpeedMps_ +=
                longitudinalAccelerationMps2_ * mechanicalDt;
            if (loadDirection != 0.0
                    && vehicleSpeedMps_ * loadDirection < 0.0)
                vehicleSpeedMps_ = 0.0;
        } else {
            vehicleSpeedMps_ = wheelAngularVelocityRadPerSecond_
                * vehicle.tireRadiusM;
            longitudinalAccelerationMps2_ =
                (vehicleSpeedMps_ - previousVehicleSpeed) / mechanicalDt;
            // Contact force telemetry includes the force accelerating vehicle
            // mass plus the external longitudinal resistances.
            lastTireForce = vehicle.massKg * longitudinalAccelerationMps2_
                + aeroForce + rollingForce + roadLoadForce;
        }
        if (brakePressure > 0.0 && previousVehicleSpeed * vehicleSpeedMps_ < 0.0) vehicleSpeedMps_ = 0.0;
        // The fading rolling resistance brings a free car to rest
        // exponentially: end it before the speed reaches denormal numbers.
        constexpr double restSpeedMps = 1.0e-9;
        if (std::abs(vehicleSpeedMps_) < restSpeedMps
                && std::abs(wheelAngularVelocityRadPerSecond_ * vehicle.tireRadiusM) < restSpeedMps) {
            vehicleSpeedMps_ = 0.0;
            wheelAngularVelocityRadPerSecond_ = 0.0;
        }
        vehicleDistanceM_ += std::abs(0.5 * (previousVehicleSpeed + vehicleSpeedMps_)) * mechanicalDt;

        const auto meanWheelOmega = 0.5 * (previousWheelOmega + wheelAngularVelocityRadPerSecond_);
        const auto meanVehicleSpeed = 0.5 * (previousVehicleSpeed + vehicleSpeedMps_);
        const auto clutchLossW = std::abs(clutchTorque * slipOmega);
        const auto coolingW = std::max(0.0, clutchTemperatureC_ - config_.ambientTemperatureC)
            * transmission.clutchCoolingWPerC;
        clutchTemperatureC_ += (clutchLossW - coolingW)
            / transmission.clutchThermalCapacityJPerC * mechanicalDt;
        clutchTemperatureC_ = std::max(config_.ambientTemperatureC, clutchTemperatureC_);
        clutchTorqueIntegral += clutchTorque * mechanicalDt;
        engineCouplingTorqueIntegral +=
            engineCouplingTorque * mechanicalDt;
        reflectedInertiaTimeIntegral +=
            reflectedInertiaKgM2 * mechanicalDt;
        wheelTorqueIntegral += wheelTorque * mechanicalDt;
        clutchLossEnergy += clutchLossW * mechanicalDt;
        wheelInputWork += wheelTorque * meanWheelOmega * mechanicalDt;
        roadWork += (std::abs(aeroForce) + std::abs(rollingForce)) * std::abs(meanVehicleSpeed) * mechanicalDt;
        roadLoadWork += std::abs(roadLoadForce * meanVehicleSpeed) * mechanicalDt;
        brakeWork += brakeForceCapacity * vehicle.tireRadiusM * std::abs(meanWheelOmega) * mechanicalDt;
        if (vehicle.tyreGripLimitEnabled)
            tireSlipWork += std::abs(lastTireForce * slipVelocity)
                * mechanicalDt;
        drivenAxleNormalImpulse += normalForce * mechanicalDt;
        longitudinalAccelerationImpulse +=
            longitudinalAccelerationMps2_ * mechanicalDt;
    }
    clutchDissipatedEnergyJoules_ += clutchLossEnergy;
    const auto inverseDt = dt > 0.0 ? 1.0 / dt : 0.0;
    output.clutchTorqueNm = clutchTorqueIntegral * inverseDt;
    output.engineReactionTorqueNm = -output.clutchTorqueNm;
    output.engineCouplingTorqueNm =
        engineCouplingTorqueIntegral * inverseDt;
    output.reflectedRotatingInertiaKgM2 =
        reflectedInertiaTimeIntegral * inverseDt;
    output.wheelTorqueNm = wheelTorqueIntegral * inverseDt;
    output.clutchSlipRpm = lastSlipRpm;
    output.clutchStickFraction = mechanicalStepCount > 0
        ? static_cast<double>(clutchStickingSteps)
            / static_cast<double>(mechanicalStepCount)
        : 0.0;
    output.tireForceN = lastTireForce;
    output.drivenAxleNormalForceN =
        drivenAxleNormalImpulse * inverseDt;
    output.longitudinalAccelerationMps2 =
        longitudinalAccelerationImpulse * inverseDt;
    output.tractionLimited = mechanicalStepCount > 0
        && tractionLimitedSteps * 2 > static_cast<std::size_t>(mechanicalStepCount);
    const auto storedEnergy = 0.5 * wheelInertia * wheelAngularVelocityRadPerSecond_
        * wheelAngularVelocityRadPerSecond_ + 0.5 * vehicle.massKg * vehicleSpeedMps_ * vehicleSpeedMps_;
    const auto energyResidual = energyInitialised_
        ? storedEnergy - previousStoredEnergyJoules_ - wheelInputWork + roadWork + roadLoadWork
            + brakeWork + tireSlipWork : 0.0;
    previousStoredEnergyJoules_ = storedEnergy;
    energyInitialised_ = true;

    output.requestedLoad = requestedLoad;
    output.engagedGear = engagedGear_;
    output.gearboxRatio = engagedGear_ == -2 ? transmission.reverseRatio
        : engagedGear_ >= 0 && !dogsFree_ ? selectedRatio() / std::max(1.0e-9, transmission.finalDriveRatio)
        : 0.0;
    output.clutchPressure = effectiveClutch;
    output.vehicleSpeedMps = vehicleSpeedMps_;
    output.vehicleDistanceM = vehicleDistanceM_;
    output.shiftProgress = shiftProgress;
    output.shiftInProgress = shiftInProgress_;
    output.brakePressure = brakePressure;
    output.brakeForceN = brakeForceCapacity;
    output.roadLoadForceN = std::abs(lastRoadLoadForce);
    output.clutchTemperatureC = clutchTemperatureC_;
    output.clutchDissipatedEnergyJoules = clutchDissipatedEnergyJoules_;
    output.clutchPowerLossKw = clutchLossEnergy * inverseDt * 0.001;
    output.storedEnergyJoules = storedEnergy;
    output.energyResidualJoules = energyResidual;
    lastClutchSlipRpm_ = lastSlipRpm;
    return output;
}

} // namespace enginelab
