add_library(EngineLabRuntime STATIC
    src/EngineRuntime.cpp
    src/DriverCommandArbiter.cpp
    src/CruiseControl.cpp
    src/PassByRun.cpp
    src/DrivelineModel.cpp
    src/ShiftSchedule.cpp
    src/VariatorControl.cpp
    src/DynoEstimator.cpp
    src/DynoQualityGate.cpp
    src/DynoRunArchive.cpp
    src/DataLogger.cpp
    src/RealtimeCapacityProbe.cpp
    src/KnockLimitCalibration.cpp)
add_library(EngineLab::Runtime ALIAS EngineLabRuntime)
target_include_directories(EngineLabRuntime PUBLIC include)
target_link_libraries(EngineLabRuntime PUBLIC EngineLab::Simulation EngineLab::Ecu EngineLab::Physics EngineLab::Events EngineLab::Exhaust)
enginelab_set_warnings(EngineLabRuntime)
