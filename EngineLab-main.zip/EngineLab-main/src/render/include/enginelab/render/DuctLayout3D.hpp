#pragma once

#include <enginelab/foundation/EngineTypes.hpp>
#include <enginelab/render/Mesh.hpp>
#include <enginelab/render/RouteSolver.hpp>

#include <cstdint>
#include <vector>

namespace enginelab::render {

/** Where a cylinder's port leaves the head, for routing intake and exhaust ducts. */
struct PortAnchor final {
    std::uint32_t cylinderId {};
    Vec3 position;
    Vec3 direction;
    float diameterMm {};
    /** Inside the head, where the port starts behind the valves. */
    Vec3 inner;
    /** A two-stroke's: `position` is the reed's mouth on the barrel and
        `direction` the way its carburettor points; this is the transfer duct,
        from the crankcase up to the transfer window, in gas-flow order. */
    std::vector<Vec3> transferDuct;
    /** The way a carburettor's slide rises (a two-stroke's). */
    Vec3 carburettorUp { 0.0F, 1.0F, 0.0F };
    /** A two-stroke's transfers come in a pair, one on each flank: the
        other is the transfer duct mirrored in the plane through this point
        with this normal (zero: no pair). */
    Vec3 transferMirrorPoint;
    Vec3 transferMirrorNormal;
};

/** What a laid-out duct stands for, so it can later be coloured from the solver. */
enum class DuctKind : std::uint8_t {
    /** One component of an exhaust path's graph. */
    exhaustComponent,
    /** A port joined straight to a junction: no authored length. */
    exhaustFeeder,
    intakeRunner,
    intakePlenum,
    intakeThrottle,
    intakeAirbox,
    intakeInletDuct,
};

/** One throttle bore as drawn: the plate (or a slide carburettor's slide)
    the view turns or lifts with the throttle. */
struct ThrottleBore final {
    /** The bore's downstream face, and the unit direction it runs from there
        towards the air (upstream). */
    Vec3 face;
    Vec3 direction { 0.0F, 1.0F, 0.0F };
    float diameterMm {};
    /** A slide carburettor (not a fixed venturi): a slide and its needle in
        place of a plate, rising towards `up`. */
    bool slide {};
    Vec3 up { 0.0F, 1.0F, 0.0F };
};

struct DuctPiece final {
    DuctKind kind { DuctKind::exhaustComponent };
    /** Exhaust or intake path id. */
    std::uint32_t pathId {};
    /** Exhaust component id (for a feeder, the junction it joins); cylinder
        id for a runner. */
    std::uint32_t elementId {};
    ExhaustComponentType componentType { ExhaustComponentType::pipe };
    Mesh mesh;
    /** Centreline as drawn, from inlet to outlet (gas-flow order). Empty for
        boxes (plenum, airbox). */
    std::vector<Vec3> centreline;
    /** Outer radius at each centreline point; empty for boxes. */
    std::vector<float> radii;
    /** Authored length; 0 when the configuration gives none. */
    float authoredLengthMm {};
    /** Framed by the engine camera views (ports, runners, plenum, primaries). */
    bool nearEngine {};
    /** Where the gas meets the atmosphere: an exhaust outlet's tip, or the
        mouth of an intake path's outermost piece (bellmouth, airbox inlet,
        throttle mouths or supercharger eye). The sound of that opening
        radiates from `openEnd` along the unit `openAxis`, pointing out. */
    bool opensToAtmosphere {};
    Vec3 openEnd;
    Vec3 openAxis { 0.0F, 1.0F, 0.0F };
    /** How much shorter than its authored length the pipe is drawn: a length
        no vehicle has room for (a primary longer than the run back to the
        gearbox, a tailpipe far past the engine) is drawn as a broken view,
        the cut marked by two bands. The simulator keeps the whole length. */
    float foldedMm {};
    /** For throttle bodies: each bore, its plate or slide. */
    std::vector<ThrottleBore> bores {};
};

/**
 * Where a turbocharger sits on the exhaust: bolted to the collector of the
 * first path it serves, the trunk resuming at its turbine outlet. The
 * simulator puts its turbine on the same collector's outgoing face.
 *
 * The shaft runs along the crankshaft (+Z). Gas leaves the collector, bends
 * outwards and enters the turbine volute tangentially; it leaves through the
 * exducer along +Z. The compressor sits on the shaft on the other side.
 */
struct TurboPlacement final {
    bool placed {};
    /** The turbocharger unit (ForcedInductionConfig::turbochargerCount). */
    std::uint32_t unit {};
    std::uint32_t pathId {};
    /** The collector it is bolted to. */
    std::uint32_t collectorId {};
    /** Gas path from the collector's outlet round the volute: centreline and
        outer radius, in gas-flow order. */
    std::vector<Vec3> scroll;
    std::vector<float> scrollRadii;
    /** Unit shaft axis (+Z), and the unit radial pointing from the shaft to
        where the gas enters the volute. */
    Vec3 axis { 0.0F, 0.0F, 1.0F };
    Vec3 radial { 1.0F, 0.0F, 0.0F };
    Vec3 turbineCentre;
    Vec3 compressorCentre;
    float turbineWheelRadius {};
    float compressorWheelRadius {};
    /** Axial widths of the turbine housing's centre and of the compressor's. */
    float turbineWidth {};
    float compressorWidth {};
    /** Outer radius of the compressor volute. */
    float compressorOuterRadius {};
    /** Where the exhaust resumes, past the exducer, and its radius there. */
    Vec3 outlet;
    float outletRadius {};
};

/**
 * Where a geared supercharger sits on the intake. The simulator applies it as
 * a pressure ratio on the intake, with no compressor in its gas network, so
 * the picture puts a centrifugal one where the air passes it: the charge
 * leaves the back of its volute through a straight pipe to the throttle, and
 * the airbox or inlet duct feeds its eye.
 *
 * The impeller turns about `axis`, the direction the air comes from at the
 * throttle, offset away from the engine by the volute's radius so that the
 * charge pipe runs straight along the throttle's axis.
 */
struct SuperchargerPlacement final {
    bool placed {};
    std::uint32_t pathId {};
    /** Unit axis, from the impeller's back plate towards its eye. */
    Vec3 axis { 0.0F, 0.0F, -1.0F };
    /** Unit radial from the impeller's axis towards the charge outlet. */
    Vec3 radial { 1.0F, 0.0F, 0.0F };
    Vec3 centre;
    float wheelRadius {};
    /** Axial width of the impeller's housing, and its outer radius. */
    float width {};
    float outerRadius {};
    /** The charge pipe, from the back of the volute to the throttle. */
    Vec3 chargeOutlet;
    Vec3 throttleInlet;
    float chargeRadius {};
    /** The inducer's mouth, where the airbox or inlet duct joins. */
    Vec3 eye;
    float eyeRadius {};
};

/** The solid a placed supercharger occupies, for the router and the route
    check. */
[[nodiscard]] std::vector<EngineSolid> superchargerSolids(const SuperchargerPlacement& supercharger);

/** The supercharger housing (volute, back plate, inducer) and its charge
    pipe, in world coordinates. */
void appendSuperchargerHousing(Mesh& mesh, const SuperchargerPlacement& supercharger);

/**
 * The vehicle round the engine, for the exhaust: which way is rearwards (a
 * car's flywheel end, +Z; a motorcycle's gearbox side, across its crank), and
 * how many of the solids given are the engine and its gearbox (the rest are
 * bolted on: a supercharger, turbos).
 *
 * With `engineSolids` set, the exhaust is kept in the room a vehicle gives it
 * (owner 2026-11-18: pipes coiled out to the side, turbos a metre off the
 * block): a corridor as wide as the engine and 150 mm more each side, from
 * 250 mm under it up to two port diameters over its highest port, and from
 * just ahead of it back. Collectors sit in it, low and back along the
 * gearbox, as far as their primaries reach; a pipe longer than the room
 * there is drawn as a broken view (DuctPiece::foldedMm). A radial is left
 * as it is: its pipes stand round it.
 */
struct ExhaustFrame final {
    Vec3 rear { 0.0F, 0.0F, 1.0F };
    std::size_t engineSolids {};
    bool radial {};
};

/**
 * Lays out every exhaust path of `config` from its component graph (or from
 * the scalar geometry when the path has none), with the authored lengths and
 * diameters: junctions and bodies sit on a trunk running along +Z (towards
 * the flywheel), bodies get the diameter of their authored volume, and a
 * collector's mouth is wide enough for all its inputs side by side.
 *
 * Pipes between ports and junctions are then bent together by relaxRoutes:
 * each keeps its length, enters its junction along the trunk, and stays clear
 * of the other pipes, of `avoid` (the intake) and of `solids` (the engine).
 * A pipe that must span more than its authored length is drawn straight and
 * therefore longer; tests measure how often that happens.
 *
 * With `turbos` given and turbochargers configured, each unit an exhaust path
 * feeds is placed after the collector of the first path it serves, the path
 * each unit's turbine face sits on in the simulator (see TurboPlacement), and
 * the pipes are routed clear of them. A unit no path feeds gets no gas in the
 * simulator and is not drawn.
 */
[[nodiscard]] std::vector<DuctPiece> layoutExhaust(const EngineConfig& config,
                                                   const std::vector<PortAnchor>& ports,
                                                   float boreMm,
                                                   const std::vector<RouteTube>& avoid = {},
                                                   const std::vector<EngineSolid>& solids = {},
                                                   std::vector<TurboPlacement>* turbos = nullptr,
                                                   const ExhaustFrame& frame = {});

/** The solids a placed turbo occupies (turbine housing centre, bearing
    housing, compressor), for the router and the route check. */
[[nodiscard]] std::vector<EngineSolid> turboSolids(const TurboPlacement& turbo);

/** The turbine housing (inlet bend, volute, exducer and bearing housing) and
    the compressor housing (volute, open inducer, outlet stub), in world
    coordinates. */
void appendTurboHousings(Mesh& turbine, Mesh& compressor, const TurboPlacement& turbo);

/** A bladed wheel round local +Y, centred on the origin: full radius at the
    back, its nose (the turbine's exducer, the compressor's inducer) towards
    `noseSign` × Y. */
void appendTurboWheel(Mesh& mesh, float radius, float width, int blades, float noseSign);

/**
 * Lays out every intake path: runners of their real length and taper from
 * each port to a plenum of the authored volume, then the throttle bores, the
 * airbox volume, the inlet duct and its bellmouth, in the order the gas
 * crosses them. `radial` gathers the runners on a drum around the crank axis.
 * The runners are bent together by relaxRoutes, clear of one another, of the
 * plenums and of `solids`.
 *
 * With `supercharger` given and a supercharger configured, the first path
 * with a single throttle gets it between its throttle and its airbox (see
 * SuperchargerPlacement).
 *
 * A two-stroke's paths are its crankcases, so its intake is drawn as a real
 * one is built instead: each cylinder's transfer duct (the runner) inside the
 * barrel, then out of the barrel a reed block, a short manifold, the
 * carburettor (the throttle) a few centimetres from the reeds and a rubber
 * boot into one airbox all the carburettors share. The crankcase itself is
 * the block's, and is not drawn again as a plenum.
 */
[[nodiscard]] std::vector<DuctPiece> layoutIntake(const EngineConfig& config,
                                                  const std::vector<PortAnchor>& ports,
                                                  float boreMm, bool radial,
                                                  const std::vector<EngineSolid>& solids = {},
                                                  SuperchargerPlacement* supercharger = nullptr);

} // namespace enginelab::render
