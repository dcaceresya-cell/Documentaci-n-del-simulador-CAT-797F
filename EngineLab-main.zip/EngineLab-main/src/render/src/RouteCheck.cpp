#include <enginelab/render/RouteCheck.hpp>

#include <enginelab/render/FreeSpace.hpp>

#include <algorithm>
#include <cmath>
#include <limits>
#include <numbers>

namespace enginelab::render {
namespace {

struct Box final {
    Vec3 minimum { std::numeric_limits<float>::max(), std::numeric_limits<float>::max(),
                   std::numeric_limits<float>::max() };
    Vec3 maximum { -std::numeric_limits<float>::max(), -std::numeric_limits<float>::max(),
                   -std::numeric_limits<float>::max() };

    void add(Vec3 p, float margin) noexcept {
        minimum = { std::min(minimum.x, p.x - margin), std::min(minimum.y, p.y - margin), std::min(minimum.z, p.z - margin) };
        maximum = { std::max(maximum.x, p.x + margin), std::max(maximum.y, p.y + margin), std::max(maximum.z, p.z + margin) };
    }
    [[nodiscard]] bool overlaps(const Box& other) const noexcept {
        return minimum.x <= other.maximum.x && other.minimum.x <= maximum.x && minimum.y <= other.maximum.y
            && other.minimum.y <= maximum.y && minimum.z <= other.maximum.z && other.minimum.z <= maximum.z;
    }
    [[nodiscard]] bool contains(Vec3 p, float margin) const noexcept {
        return p.x >= minimum.x - margin && p.x <= maximum.x + margin && p.y >= minimum.y - margin
            && p.y <= maximum.y + margin && p.z >= minimum.z - margin && p.z <= maximum.z + margin;
    }
};

struct Tube final {
    int duct {};
    const std::vector<Vec3>* points {};
    const std::vector<float>* radii {};
    std::vector<float> arc;
    Box bounds;
    /** Ends that plug into something: overlap within two radii is a joint. */
    bool attached[2] {};
};

/** Overlap of a sphere (centre `q`, radius `rq`) with tube `t`: positive
    when they overlap. Segments [skipFrom, skipTo) are left out. */
[[nodiscard]] float overlap(Vec3 q, float rq, const Tube& t, std::size_t skipFrom = 0, std::size_t skipTo = 0) {
    return tubeContact(q, rq, *t.points, t.radii, 0.0F, skipFrom, skipTo).depth;
}

/** Arc index range of `t` within `distance` of arc position `s`. */
void arcWindow(const Tube& t, float s, float distance, std::size_t& from, std::size_t& to) {
    from = 0;
    while (from < t.arc.size() && t.arc[from] < s - distance) ++from;
    to = from;
    while (to < t.arc.size() && t.arc[to] <= s + distance) ++to;
}

[[nodiscard]] bool nearAttachedEnd(const Tube& t, std::size_t i) {
    const auto& p = *t.points;
    const auto& r = *t.radii;
    if (t.attached[0] && length(p[i] - p.front()) < 2.0F * r.front()) return true;
    if (t.attached[1] && length(p[i] - p.back()) < 2.0F * r.back()) return true;
    return false;
}

[[nodiscard]] Vec3 meanPoint(const Vec3& a, const Vec3& b) noexcept { return (a + b) * 0.5F; }

} // namespace

std::size_t RouteReport::count(RouteIssueKind kind) const noexcept {
    return static_cast<std::size_t>(
        std::count_if(issues.begin(), issues.end(), [kind](const RouteIssue& issue) { return issue.kind == kind; }));
}

RouteReport checkRoutes(const EngineModel3D& model) {
    RouteReport report;
    const auto& ducts = model.ducts();

    // Boxes (plenum, airbox, throttle bodies) and ports take joints too.
    std::vector<Box> boxes;
    std::vector<Tube> tubes;
    for (std::size_t d = 0; d < ducts.size(); ++d) {
        const auto& duct = ducts[d];
        if (duct.centreline.size() >= 2U && duct.radii.size() == duct.centreline.size()) {
            Tube tube;
            tube.duct = static_cast<int>(d);
            tube.points = &duct.centreline;
            tube.radii = &duct.radii;
            tube.arc.assign(duct.centreline.size(), 0.0F);
            for (std::size_t i = 0; i < duct.centreline.size(); ++i) {
                if (i > 0) tube.arc[i] = tube.arc[i - 1U] + length(duct.centreline[i] - duct.centreline[i - 1U]);
                tube.bounds.add(duct.centreline[i], duct.radii[i]);
            }
            tubes.push_back(std::move(tube));
        } else {
            Box box;
            for (const auto& vertex : model.parts()[duct.part].mesh.vertices) box.add(vertex.position, 0.0F);
            boxes.push_back(box);
        }
    }
    std::vector<Vec3> ports;
    for (const auto& port : model.exhaustPorts()) ports.push_back(port.position);
    for (const auto& port : model.intakePorts()) ports.push_back(port.position);

    for (auto& tube : tubes) {
        for (int end = 0; end < 2; ++end) {
            const auto e = end == 0 ? tube.points->front() : tube.points->back();
            const auto re = end == 0 ? tube.radii->front() : tube.radii->back();
            bool attached = std::any_of(ports.begin(), ports.end(), [&](Vec3 port) { return length(port - e) < 2.0F * re; })
                || std::any_of(boxes.begin(), boxes.end(), [&](const Box& box) { return box.contains(e, re); });
            for (const auto& other : tubes) {
                if (attached) break;
                if (other.duct == tube.duct || !other.bounds.contains(e, re)) continue;
                attached = overlap(e, re, other) > -0.25F * re;
            }
            tube.attached[end] = attached;
        }
    }

    // Duct against duct, both ways, deepest overlap per pair.
    for (std::size_t a = 0; a < tubes.size(); ++a) {
        for (std::size_t b = a + 1U; b < tubes.size(); ++b) {
            const auto& ta = tubes[a];
            const auto& tb = tubes[b];
            if (!ta.bounds.overlaps(tb.bounds)) continue;
            RouteIssue worst { RouteIssueKind::ductClash, ta.duct, tb.duct, {}, 0.0F };
            const auto test = [&](const Tube& from, const Tube& against) {
                for (std::size_t i = 0; i < from.points->size(); ++i) {
                    if (nearAttachedEnd(from, i)) continue;
                    const auto q = (*from.points)[i];
                    const auto rq = (*from.radii)[i];
                    if (!against.bounds.contains(q, rq)) continue;
                    const auto depth = overlap(q, rq, against);
                    // A graze is not a clash.
                    if (depth > 0.5F + 0.15F * rq && depth > worst.value) {
                        worst.value = depth;
                        worst.where = q;
                    }
                }
            };
            test(ta, tb);
            test(tb, ta);
            if (worst.value > 0.0F) report.issues.push_back(worst);
        }
    }

    // A duct against itself, beyond four radii of arc.
    for (const auto& tube : tubes) {
        RouteIssue worst { RouteIssueKind::selfClash, tube.duct, -1, {}, 0.0F };
        for (std::size_t i = 0; i < tube.points->size(); ++i) {
            const auto rq = (*tube.radii)[i];
            std::size_t from = 0, to = 0;
            arcWindow(tube, tube.arc[i], 4.0F * rq, from, to);
            // Segments touching the points of the window.
            const auto depth = overlap((*tube.points)[i], rq, tube, from > 0 ? from - 1U : 0U, to);
            if (depth > 0.5F + 0.15F * rq && depth > worst.value) {
                worst.value = depth;
                worst.where = (*tube.points)[i];
            }
        }
        if (worst.value > 0.0F) report.issues.push_back(worst);
    }

    // Ducts against the engine's solids.
    const auto& solids = model.solids();
    for (const auto& tube : tubes) {
        // A two-stroke's transfer duct is cast in its barrel's wall.
        if (ducts[static_cast<std::size_t>(tube.duct)].kind == DuctKind::intakeRunner
            && model.config().cycle == EngineCycle::twoStroke)
            continue;
        for (std::size_t s = 0; s < solids.size(); ++s) {
            RouteIssue worst { RouteIssueKind::engineClash, tube.duct, static_cast<int>(s), {}, 0.0F };
            for (std::size_t i = 0; i < tube.points->size(); ++i) {
                if (nearAttachedEnd(tube, i)) continue;
                const auto rq = (*tube.radii)[i];
                const auto depth = rq - signedDistance(solids[s], (*tube.points)[i]);
                if (depth > 0.5F + 0.15F * rq && depth > worst.value) {
                    worst.value = depth;
                    worst.where = (*tube.points)[i];
                }
            }
            if (worst.value > 0.0F) report.issues.push_back(worst);
        }
    }

    // Bodies against the engine and its gearbox: a plenum or an airbox (its
    // drawn box), a turbocharger or a supercharger (its solids). Owner
    // 2026-11-18: an X12's collector and turbo sat inside the gearbox, which
    // nothing here looked at.
    const auto engineSolids = std::min(model.engineSolidCount(), solids.size());
    const auto bodyIssue = [&](int duct, const std::vector<Vec3>& points) {
        for (std::size_t s = 0; s < engineSolids; ++s) {
            RouteIssue worst { RouteIssueKind::engineClash, duct, static_cast<int>(s), {}, 0.0F };
            for (const auto& point : points) {
                const auto depth = -signedDistance(solids[s], point);
                if (depth > 2.0F && depth > worst.value) {
                    worst.value = depth;
                    worst.where = point;
                }
            }
            if (worst.value > 0.0F) report.issues.push_back(worst);
        }
    };
    // Points spread through a body: its corners pulled a little towards its
    // centre (a face resting on the engine is not inside it), and the centre.
    const auto inside = [](const std::vector<Vec3>& corners) {
        Vec3 centre {};
        for (const auto& corner : corners) centre += corner;
        centre = centre * (1.0F / static_cast<float>(std::max<std::size_t>(1U, corners.size())));
        std::vector<Vec3> points { centre };
        for (const auto& corner : corners)
            for (const auto t : { 0.5F, 0.9F }) points.push_back(lerp(centre, corner, t));
        return points;
    };
    for (std::size_t d = 0; d < ducts.size(); ++d) {
        const auto& duct = ducts[d];
        if (duct.centreline.size() >= 2U && duct.radii.size() == duct.centreline.size()) continue;
        // A rotor's port passage is in its housing, and a two-stroke's reed
        // block bolts onto its crankcase, by construction.
        const auto intakeBody = duct.kind == DuctKind::intakePlenum || duct.kind == DuctKind::intakeThrottle
            || duct.kind == DuctKind::intakeAirbox;
        if (!intakeBody || (duct.kind == DuctKind::intakePlenum && model.config().cycle == EngineCycle::twoStroke))
            continue;
        std::vector<Vec3> corners;
        for (const auto& vertex : model.parts()[duct.part].mesh.vertices) corners.push_back(vertex.position);
        if (!corners.empty()) bodyIssue(static_cast<int>(d), inside(corners));
    }
    const auto solidCorners = [](const EngineSolid& solid) {
        std::vector<Vec3> corners;
        const auto& h = solid.half;
        for (int k = 0; k < 8; ++k) {
            const auto sx = (k & 1) != 0 ? 1.0F : -1.0F, sy = (k & 2) != 0 ? 1.0F : -1.0F, sz = (k & 4) != 0 ? 1.0F : -1.0F;
            if (solid.shape == EngineSolid::Shape::box)
                corners.push_back(solid.centre + solid.axes[0] * (sx * h.x) + solid.axes[1] * (sy * h.y)
                                  + solid.axes[2] * (sz * h.z));
            else {
                // The axis is axes[1]; the other two are not kept square to it.
                const auto axis = solid.axes[1];
                const auto u = normalise(std::abs(axis.x) < 0.9F ? cross(axis, Vec3 { 1.0F, 0.0F, 0.0F })
                                                                  : cross(axis, Vec3 { 0.0F, 1.0F, 0.0F }));
                const auto v = cross(axis, u);
                const auto a = 0.25F * 3.14159265F * static_cast<float>(k);
                corners.push_back(solid.centre + (u * std::cos(a) + v * std::sin(a)) * h.x + axis * (sz * h.y));
            }
        }
        return corners;
    };
    for (std::size_t s = engineSolids; s < solids.size(); ++s) bodyIssue(-1, inside(solidCorners(solids[s])));

    // Bends: the circle through three points half a diameter apart along the
    // centreline must have a radius of at least one diameter.
    for (const auto& tube : tubes) {
        const auto& p = *tube.points;
        RouteIssue run { RouteIssueKind::tightBend, tube.duct, -1, {}, std::numeric_limits<float>::max() };
        bool open = false;
        for (std::size_t i = 1; i + 1U < p.size(); ++i) {
            const auto diameter = 2.0F * (*tube.radii)[i];
            std::size_t before = i, after = i;
            while (before > 0 && tube.arc[i] - tube.arc[before] < 0.5F * diameter) --before;
            while (after + 1U < p.size() && tube.arc[after] - tube.arc[i] < 0.5F * diameter) ++after;
            const auto ab = p[i] - p[before], bc = p[after] - p[i], ca = p[before] - p[after];
            const auto area2 = length(cross(ab, bc));
            const auto ratio = area2 < 1.0e-6F ? std::numeric_limits<float>::max()
                : length(ab) * length(bc) * length(ca) / (2.0F * area2) / diameter;
            const auto tight = ratio < 1.0F && tube.arc[i] - tube.arc[before] >= 0.45F * diameter
                && tube.arc[after] - tube.arc[i] >= 0.45F * diameter;
            if (tight) {
                open = true;
                if (ratio < run.value) {
                    run.value = ratio;
                    run.where = p[i];
                }
            } else if (open) {
                report.issues.push_back(run);
                run.value = std::numeric_limits<float>::max();
                open = false;
            }
        }
        if (open) report.issues.push_back(run);
    }

    // Pipes drawn longer than authored.
    for (std::size_t d = 0; d < ducts.size(); ++d) {
        const auto& duct = ducts[d];
        const auto pipe = (duct.kind == DuctKind::exhaustComponent && duct.componentType == ExhaustComponentType::pipe)
            || duct.kind == DuctKind::intakeRunner;
        if (!pipe || duct.authoredLengthMm <= 1.0F) continue;
        const auto drawn = polylineLength(duct.centreline);
        if (drawn > 1.03F * duct.authoredLengthMm)
            report.issues.push_back({ RouteIssueKind::stretched, static_cast<int>(d), -1,
                                      meanPoint(duct.centreline.front(), duct.centreline.back()),
                                      drawn / duct.authoredLengthMm });
    }
    return report;
}

PlausibilityReport checkPlausibility(const EngineModel3D& model) {
    PlausibilityReport report;
    const auto rear = model.rear();
    const Vec3 up { 0.0F, 1.0F, 0.0F };
    const auto across = normalise(cross(up, rear));
    // The vehicle's frame: across, up, rearwards.
    const auto local = [&](Vec3 p) { return Vec3 { dot(p, across), p.y, dot(p, rear) }; };
    Vec3 low { std::numeric_limits<float>::max(), std::numeric_limits<float>::max(), std::numeric_limits<float>::max() };
    Vec3 high = low * -1.0F;
    const auto& solids = model.solids();
    for (std::size_t s = 0; s < model.engineSolidCount() && s < solids.size(); ++s) {
        const auto half = solidHalfExtent(solids[s]);
        for (int corner = 0; corner < 8; ++corner) {
            const Vec3 offset { (corner & 1) != 0 ? half.x : -half.x, (corner & 2) != 0 ? half.y : -half.y,
                                (corner & 4) != 0 ? half.z : -half.z };
            const auto p = local(solids[s].centre + offset);
            low = { std::min(low.x, p.x), std::min(low.y, p.y), std::min(low.z, p.z) };
            high = { std::max(high.x, p.x), std::max(high.y, p.y), std::max(high.z, p.z) };
        }
    }
    const auto& ports = model.exhaustPorts();
    if (ports.empty() || high.x < low.x) return report;
    float topPort = -std::numeric_limits<float>::max(), frontPort = std::numeric_limits<float>::max();
    for (const auto& port : ports) {
        const auto p = local(port.position);
        topPort = std::max(topPort, p.y + 2.0F * port.diameterMm);
        frontPort = std::min(frontPort, p.z - 3.0F * port.diameterMm);
    }
    const auto front = std::min(low.z, frontPort) - 100.0F;
    // A tail runs on out of the picture past one and a half engine (and
    // gearbox) lengths behind it: drawn broken there.
    const auto back = high.z + 1.5F * (high.z - low.z) + 50.0F;

    const auto& ducts = model.ducts();
    for (std::size_t d = 0; d < ducts.size(); ++d) {
        const auto& duct = ducts[d];
        if ((duct.kind != DuctKind::exhaustComponent && duct.kind != DuctKind::exhaustFeeder) || duct.centreline.size() < 2U)
            continue;
        bool offends = false;
        const auto mark = [&](float& worst, float excess) {
            if (excess <= 0.0F) return;
            worst = std::max(worst, excess);
            offends = true;
        };
        for (const auto& point : duct.centreline) {
            const auto p = local(point);
            mark(report.besideMm, std::max(low.x - p.x, p.x - high.x) - 150.0F);
            mark(report.belowMm, low.y - 250.0F - p.y);
            mark(report.aboveMm, p.y - topPort);
            mark(report.aheadMm, front - p.z);
        }
        // A straight, even pipe still running on past the plane: one a
        // broken view could have shortened (a muffler, a chamber's cone or
        // a radial's collector keeps its size).
        if (duct.kind == DuctKind::exhaustComponent && duct.componentType == ExhaustComponentType::pipe
            && !duct.radii.empty()) {
            const auto [thinnest, widest] = std::minmax_element(duct.radii.begin(), duct.radii.end());
            float arc = 0.0F;
            Vec3 first {}, last {};
            bool any = false;
            for (std::size_t i = 1; i < duct.centreline.size(); ++i) {
                const auto a = local(duct.centreline[i - 1U]), b = local(duct.centreline[i]);
                if (b.z <= back) continue;
                if (!any) first = a.z > back ? a : b;
                any = true;
                arc += length(b - a);
                last = b;
            }
            const auto diameter = 2.0F * *widest;
            if (any && *widest - *thinnest < 0.5F && length(last - first) > 0.98F * arc)
                mark(report.behindMm, arc - 3.0F * diameter - 1.0F);
        }
        // Total turning, a direction every diameter or so along the line.
        const auto step = std::max(10.0F, 2.0F * (duct.radii.empty() ? 10.0F : duct.radii.front()));
        float turning = 0.0F, carried = 0.0F;
        Vec3 anchor = duct.centreline.front();
        Vec3 last {};
        bool haveLast = false;
        for (std::size_t i = 1; i < duct.centreline.size(); ++i) {
            carried += length(duct.centreline[i] - duct.centreline[i - 1U]);
            if (carried < step && i + 1U < duct.centreline.size()) continue;
            const auto chord = duct.centreline[i] - anchor;
            if (length(chord) > 1.0e-3F) {
                const auto direction = normalise(chord);
                if (haveLast) turning += std::acos(std::clamp(dot(last, direction), -1.0F, 1.0F));
                last = direction;
                haveLast = true;
            }
            anchor = duct.centreline[i];
            carried = 0.0F;
        }
        if (duct.kind == DuctKind::exhaustComponent && turning > 2.5F * std::numbers::pi_v<float>) {
            ++report.coiled;
            offends = true;
        }
        // A stack (an aircraft's, a radial's) opens straight off its port:
        // it points where the port does.
        const auto stack = std::any_of(ports.begin(), ports.end(), [&](const PortAnchor& port) {
            return length(port.position - duct.centreline.front()) < std::max(5.0F, 0.5F * port.diameterMm);
        });
        if (duct.kind == DuctKind::exhaustComponent && duct.componentType == ExhaustComponentType::outlet && !stack) {
            const auto axis = duct.centreline.back() - duct.centreline[duct.centreline.size() - 2U];
            if (length(axis) > 1.0e-3F && dot(normalise(axis), rear) < 0.7071F) {
                ++report.astray;
                offends = true;
            }
        }
        if (duct.foldedMm > 0.0F) ++report.folded;
        if (offends) report.offenders.push_back(static_cast<int>(d));
    }

    // Mirror images across the crank's vertical plane (world x = 0), a bank
    // staggered along the crank by its rod's width: measured only where every
    // port has its image, and only in a car's frame (a motorcycle's banks
    // stand front and rear).
    // A radial's pipes stand round it, the same for every cylinder: its
    // symmetry is a turn about the crank, not a mirror.
    if (std::abs(rear.z) < 0.99F || model.config().layout == EngineLayout::radial) return report;
    float leftZ = 0.0F, rightZ = 0.0F;
    std::size_t left = 0, right = 0;
    for (const auto& port : ports) {
        if (port.position.x > 1.0F) {
            rightZ += port.position.z;
            ++right;
        } else if (port.position.x < -1.0F) {
            leftZ += port.position.z;
            ++left;
        }
    }
    if (left == 0U || left != right) return report;
    const auto stagger = leftZ / static_cast<float>(left) - rightZ / static_cast<float>(right);
    const auto image = [stagger](Vec3 p) { return Vec3 { -p.x, p.y, p.z + (p.x > 0.0F ? stagger : -stagger) }; };
    for (const auto& port : ports) {
        const auto mirrored = image(port.position);
        const auto matched = std::any_of(ports.begin(), ports.end(), [&](const PortAnchor& other) {
            return length(other.position - mirrored) < 5.0F;
        });
        if (!matched) return report;
    }
    report.mirrored = true;
    // Measured on twins: two pipes of one type and length that start at each
    // other's images (the primaries of mirror ports, and whatever follows
    // two mirrored collectors). A design one side of which differs from the
    // other -- a single turbo, a collector fed by both banks -- is measured
    // only on its primaries, which carry where that collector sits.
    const auto sampled = [](const std::vector<Vec3>& line) {
        std::vector<Vec3> points { line.front() };
        float run = 0.0F;
        for (std::size_t i = 1; i < line.size(); ++i) {
            run += length(line[i] - line[i - 1U]);
            if (run >= 20.0F || i + 1U == line.size()) {
                points.push_back(line[i]);
                run = 0.0F;
            }
        }
        return points;
    };
    std::vector<float> gaps;
    for (const auto& duct : ducts) {
        if (duct.kind != DuctKind::exhaustComponent || duct.centreline.size() < 2U) continue;
        const auto start = image(duct.centreline.front());
        const auto twin = std::find_if(ducts.begin(), ducts.end(), [&](const SceneDuct& other) {
            return &other != &duct && other.kind == DuctKind::exhaustComponent && other.centreline.size() >= 2U
                && other.componentType == duct.componentType
                && std::abs(other.authoredLengthMm - duct.authoredLengthMm) < 1.0F
                && length(other.centreline.front() - start) < 5.0F;
        });
        if (twin == ducts.end()) continue;
        const auto theirs = sampled(twin->centreline);
        for (const auto& point : sampled(duct.centreline)) {
            const auto mirrored = image(point);
            float nearest = std::numeric_limits<float>::max();
            for (const auto& other : theirs) nearest = std::min(nearest, length(other - mirrored));
            gaps.push_back(nearest);
        }
    }
    if (!gaps.empty()) {
        const auto k = static_cast<std::size_t>(0.9 * static_cast<double>(gaps.size() - 1U));
        std::nth_element(gaps.begin(), gaps.begin() + static_cast<std::ptrdiff_t>(k), gaps.end());
        report.asymmetryMm = gaps[k];
    }
    return report;
}

} // namespace enginelab::render
