#pragma once

#include <enginelab/foundation/EngineTypes.hpp>

namespace enginelab {

struct CarburettorState final {
    /** Fuel wetting the bore and the crankcase walls, waiting to evaporate. */
    double wallFilmMoles { 0.0 };
    /** The throttle at the last step, whose rise strokes the pump. */
    double previousThrottle { 0.0 };
    /** Fuel the pump has displaced that its nozzle has not yet delivered. */
    double pumpShotMoles { 0.0 };
};

struct CarburettorMetering final {
    /** Fuel that left the jets this step. */
    double meteredMoles { 0.0 };
    /** Fuel that reached the charge this step: what the jets passed less what
     * the walls took, plus what the film gave back. */
    double deliveredMoles { 0.0 };
    double mainMoles { 0.0 };
    double pilotMoles { 0.0 };
    double pumpMoles { 0.0 };
    double starterMoles { 0.0 };
    double venturiDepressionKpa { 0.0 };
    double venturiVelocityMps { 0.0 };
};

/** Fuel metered by the air itself, the way a slide carburettor does it.
 *
 * Nothing here is commanded. The jets are orifices into a float bowl held at
 * the pressure outside the engine, and the mixture is whatever depression the
 * air happens to draw through them. That is the whole point of modelling it:
 * an injector asked for the right fuel and got it, so a carburetted engine's
 * real mixture excursions -- lean off idle, rich as the slide comes up, and a
 * stumble on a fast tip-in while the bore is still wet -- cannot come out of
 * an injector model no matter how it is calibrated.
 *
 * The two circuits never need blending, because each is driven by a
 * depression the other does not see. The main circuit is driven by the
 * throat's depression -- the slide's gap part-way open, the venturi wide
 * open -- and its needle follows the slide, so with the slide down it passes
 * nothing at all. The pilot circuit is driven by the
 * drop from the bowl to the crankcase, which is largest with the slide shut
 * and collapses at full throttle, where a two-stroke's crankcase pumps at
 * about ambient. Each fades where the other takes over, with no crossover
 * term written anywhere.
 *
 * Two things a real carburettor has are deliberately absent, and both would
 * show up at the top of the range rather than at idle:
 *
 * - **No emulsion tube or air corrector.** A real main circuit bleeds air
 *   into the fuel passage once the depression uncovers the tube's holes, which
 *   is what keeps the mixture flat at high flow; a plain jet richens instead.
 *   The flattening is a two-phase effect in the passage, and no single
 *   algebraic factor stands in for it honestly, so the model has the
 *   plain-jet characteristic and this is a measured gap, not a calibration.
 * - **No throat density drop.** The air density used is the one handed in, so
 *   the compressible fall across the venturi (a few per cent at full throttle)
 *   is not there. It is the other half of why a plain jet richens.
 */
class CarburettorModel final {
public:
    /** Throat area in square metres; zero configured diameter takes its
     *  fraction of the throttle bore. */
    [[nodiscard]] static double venturiAreaM2(const CarburettorConfig& carburettor,
                                              double throttleDiameterMm) noexcept;

    /** Orifice area of a jet stamped with a flow number.
     *
     * A jet's number is cubic centimetres per minute of test fluid under one
     * metre of head. The velocity that head produces is sqrt(2 g h), which is
     * 4.43 m/s and carries no fluid density at all, so the area a number
     * implies is independent of what the jet was calibrated with.
     */
    [[nodiscard]] static double jetAreaM2(double flowNumber,
                                          double dischargeCoefficient) noexcept;

    /** How far the needle has withdrawn from the needle jet, 0 to 1, given
     *  the slide's open area over the venturi's.
     *
     * The needle rides with the slide, and its taper is cut so the needle
     * jet's annulus follows the slide's gap: with the gap as the throat, the
     * main circuit's mixture then holds what full throttle gives from where
     * the slide lifts to where the venturi takes over. The clip moves it
     * richer (a lower clip) or leaner below full throttle; wide open the
     * needle is clear and the main jet alone meters.
     */
    [[nodiscard]] static double needleOpenFraction(const CarburettorConfig& carburettor,
                                                   double slideToThroatAreaRatio) noexcept;

    /** Meter the fuel for one solver sub-step.
     *
     * `airMassFlowKgPerSecond` is the air actually crossing the bore, and the
     * fuel follows from the depression that moved it, so this is an amount per
     * step and never a gain on a flow it goes on to change.
     *
     * `throttleOpenAreaM2` is every effective area the air crosses the bore
     * by (slide gap, idle passages, leak) and `slideOpenAreaM2` the slide's
     * own share: on a slide carburettor the smaller of the first and the
     * venturi is the throat the main circuit reads, and the needle follows
     * the second. A fixed venturi ignores both.
     *
     * `idleCircuitOpening` is the idle air path's opening against its
     * neutral one. Opening a slide's idle stop uncovers progression holes
     * as it lets air by, so the pilot's fuel follows the idle air; 1 is the
     * opening the pilot jet was sized at.
     */
    [[nodiscard]] static CarburettorMetering meter(const CarburettorConfig& carburettor,
                                                   const FuelConfig& fuel,
                                                   CarburettorState& state,
                                                   double airMassFlowKgPerSecond,
                                                   double airDensityKgPerM3,
                                                   double bowlPressureKpa,
                                                   double crankcasePressureKpa,
                                                   double throttleDiameterMm,
                                                   double throttleFraction,
                                                   double throttleOpenAreaM2,
                                                   double slideOpenAreaM2,
                                                   double dtSeconds,
                                                   double idleCircuitOpening = 1.0,
                                                   double starterCircuitOpening = 0.0) noexcept;
};

} // namespace enginelab
