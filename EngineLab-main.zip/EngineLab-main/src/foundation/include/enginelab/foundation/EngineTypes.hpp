﻿#pragma once

#include <cstddef>
#include <cmath>
#include <cstdint>
#include <string>
#include <vector>
#include <optional>
#include <array>

namespace enginelab {
inline constexpr std::uint32_t minimumSupportedEngineSchemaVersion { 1 };
inline constexpr std::uint32_t currentEngineSchemaVersion { 9 };


enum class EngineCycle : std::uint8_t { fourStroke, twoStroke, rotary };
enum class FuelType : std::uint8_t { gasoline, diesel };
enum class InjectionMode : std::uint8_t { port, direct };
enum class EngineLayout : std::uint8_t { inlineLayout, vLayout, flat, radial, custom };
enum class ConnectingRodType : std::uint8_t { conventional, master, articulated };
enum class ForcedInductionType : std::uint8_t { turbocharger, supercharger };
enum class DrivenAxleLayout : std::uint8_t { front, rear, all };
enum class ShiftStyle : std::uint8_t { manual, sequential, dualClutch, cvt, automatedManual };
enum class StructuralNvhProvenance : std::uint8_t {
    estimatedFamily, calculatedGeometry, measured
};
enum class StructuralModeDrive : std::uint8_t {
    headGas, bearingAxial, bearingLateral, torsion
};
enum class ExhaustComponentType : std::uint8_t {
    pipe, merge, splitter, resonator, muffler, catalyst, outlet, crossover
};
/** Port metadata is meaningful only on the corresponding side of a crossover
 * connection. All historical two-field connection initialisers retain this
 * sentinel and therefore preserve their exact topology semantics. */
inline constexpr std::uint8_t unspecifiedExhaustComponentPort { 0xffU };
/** On a merge or a splitter, the port of a duct that meets it at right angles,
 * as an H-pipe's balance pipe meets each side's pipe. A junction carries
 * momentum along its graph axis, from its inputs toward its outputs; a side
 * branch exchanges mass and energy with it but none of that momentum, and
 * sees it at rest. Without it the balance pipe was a jet pump: the splitter
 * rammed its side's flow into it and the merge drew it out, holding the
 * splitter 0-24 kPa under the merge at every crank angle (journal
 * 2026-10-29). */
inline constexpr std::uint8_t exhaustSideBranchPort { 2U };
/** Global CPU bound for acoustic-only delay lines authored as sealed branches. */
inline constexpr std::size_t maximumExhaustAcousticSideBranches { 8 };
/** Turbochargers one engine can carry (ForcedInductionConfig::turbochargerCount). */
inline constexpr std::size_t maximumTurbochargers { 4 };
enum class AcousticTerminationType : std::uint8_t { unflanged, flanged };
enum class RunningState : std::uint8_t {
    stopped, cranking, idling, running, unstable, knocking, overheating, damaged, destroyed
};

/** Calibrated thermochemical properties of the fuel surrogate. */
struct FuelConfig final {
    std::string name { "Pump gasoline" };
    double lowerHeatingValueMjPerKg { 43.0 };
    double densityKgPerL { 0.745 };
    double stoichiometricAirFuelRatio { 14.7 };
    double molarMassGramsPerMole { 114.23 };
    double oxygenMolesPerFuelMole { 12.5 };
    double productMolesPerFuelMole { 17.0 };
    double laminarFlameSpeedMps { 0.38 };
    double turbulenceFlameSpeedGain { 1.55 };
    /** Ignition quality for compression-ignition fuel. Zero explicitly means
     *  "not a compression-ignition fuel"; diesel configurations use 30-80.
     */
    double cetaneNumber { 0.0 };
};

struct CylinderConfig final {
    std::uint32_t id { 1 };
    double boreMm { 86.0 };
    double strokeMm { 86.0 };
    double connectingRodMm { 143.0 };
    double pistonMassGrams { 420.0 };
    double compressionRatio { 10.5 };
    double ignitionOffsetDegrees { 0.0 };
    double efficiencyOffset { 0.0 };
    double crankOffsetDegrees { 0.0 };
    std::uint32_t crankJournalId { 0 };
    double bankOffsetDegrees { 0.0 };
    std::uint32_t bankId { 0 };
    // Zero delegates to the selected intake path.  A non-zero value is a
    // genuine per-cylinder override rather than an accidental global default.
    double intakeRunnerLengthMm { 0.0 };
    double intakeRunnerDiameterMm { 0.0 };
    double exhaustPrimaryLengthMm { 0.0 };
    double soundAttenuation { 1.0 };
    double blowByCoefficient { 0.00002 };
    double connectingRodMassGrams { 600.0 };
    double pistonFrictionCoefficient { 0.025 };
    double pistonBreakawayForceN { 45.0 };
    double pistonBreakawayVelocityMps { 0.10 };
    double pistonViscousFrictionNsPerM { 4.5 };
    ConnectingRodType connectingRodType { ConnectingRodType::conventional };
    std::uint32_t masterCylinderId { 0 };
    double articulatedJournalRadiusMm { 0.0 };
    double articulatedJournalAngleDegrees { 0.0 };
    double deckHeightMm { 0.0 };
    double compressionHeightMm { 0.0 };
    double wristPinOffsetMm { 0.0 };
    double pistonCrownVolumeCc { 0.0 };
    double headChamberVolumeCc { 0.0 };
    double headGasketThicknessMm { 0.0 };
    double connectingRodMomentOfInertiaKgM2 { 0.0 };
    std::uint32_t intakeValveCount { 2 };
    std::uint32_t exhaustValveCount { 2 };
    // Zero selects a physically proportioned diameter from bore and count.
    double intakeValveDiameterMm { 0.0 };
    double exhaustValveDiameterMm { 0.0 };
};

struct CrankJournalConfig final {
    std::uint32_t id { 0 };
    double angleDegrees { 0.0 };
    double throwMm { 0.0 };
    std::uint32_t crankshaftId { 1 };
};

struct CrankshaftConfig final {
    std::uint32_t id { 1 };
    double positionXMm { 0.0 };
    double positionYMm { 0.0 };
    double phaseOffsetDegrees { 0.0 };
    double rotationRatio { 1.0 };
    double massKg { 18.0 };
    double flywheelMassKg { 8.0 };
    double momentOfInertiaKgM2 { 0.0 };
    double frictionTorqueNm { 0.0 };
    // Runtime migration provenance; deliberately not part of schema v1.
    // Explicitly decoded crankshafts keep the default false value.
    bool inheritsLegacyInertia { false };
};

struct ValveLiftSample final {
    double angleDegrees { 0.0 };
    double liftMm { 0.0 };
};

struct ValveFlowSample final {
    double liftMm { 0.0 };
    double dischargeCoefficient { 0.0 };
};

struct ValveControlSample final {
    double rpm { 0.0 };
    double load { 0.0 };
    double intakeAdvanceDegrees { 0.0 };
    double exhaustAdvanceDegrees { 0.0 };
    double liftMultiplier { 1.0 };
};

struct ValveControlConfig final {
    bool enabled { false };
    double responseFrequencyHz { 8.0 };
    std::vector<ValveControlSample> samples;
};

struct CamshaftConfig final {
    double intakeDurationDegrees { 248.0 };
    double exhaustDurationDegrees { 244.0 };
    double intakeLiftMm { 10.2 };
    double exhaustLiftMm { 9.8 };
    double intakeCenterlineDegrees { 110.0 };
    double exhaustCenterlineDegrees { 112.0 };
    double intakeFlowCoefficient { 0.62 };
    double exhaustFlowCoefficient { 0.62 };
    std::vector<ValveLiftSample> intakeLiftProfile {};
    std::vector<ValveLiftSample> exhaustLiftProfile {};
    bool variableProfileEnabled { false };
    double switchRpm { 5'800.0 };
    double switchThrottle { 0.55 };
    double highIntakeDurationDegrees { 282.0 };
    double highExhaustDurationDegrees { 276.0 };
    double highIntakeLiftMm { 12.5 };
    double highExhaustLiftMm { 11.8 };
    std::vector<ValveLiftSample> highIntakeLiftProfile {};
    std::vector<ValveLiftSample> highExhaustLiftProfile {};
    std::vector<ValveFlowSample> intakeFlowCurve {};
    std::vector<ValveFlowSample> exhaustFlowCurve {};
    ValveControlConfig continuousControl {};
    /** The fraction of exhaust valve head area the port's effective area
     *  saturates at, read off a flow bench; 0 keeps the literature's
     *  production figure (0.51). */
    double exhaustPortHeadAreaFraction { 0.0 };
};

/** Length of the common trunk the scalar exhaust geometry gives its
 *  collector, mm. */
inline constexpr double legacyCollectorTrunkLengthMm = 120.0;
/** The tailpipe the scalar exhaust compiler meshes after its body. */
inline constexpr double legacyTailpipeLengthMm = 180.0;

struct ExhaustConfig final {
    double primaryLengthMm { 480.0 };
    double primaryDiameterMm { 42.0 };
    double collectorDiameterMm { 58.0 };
    double mufflerRestriction { 0.28 };
    double outletDiameterMm { 65.0 };
    /** Gas volume of the collector body. Zero: no body, the collector holds
     *  what its own trunk sweeps, as a cone of merging primaries does. It was
     *  2.0 L by default: a pre-chamber behind every catalogue collector, which
     *  muffled 0.5-5 kHz by up to 19 dB (journal 2026-10-15). */
    double collectorVolumeLitres { 0.0 };
    double outletDischargeCoefficient { 0.72 };
    /** Single expansion chamber on the collector-to-outlet duct. Zero on either
     *  field means "no silencer": the audio element becomes an exact
     *  through-connection, which is the correct model for an open stack and
     *  keeps every engine that predates these fields rendering unchanged. See
     *  `enginelab/audio/ExpansionChamberMuffler.hpp`. */
    double mufflerChamberDiameterMm { 0.0 };
    double mufflerChamberLengthMm { 0.0 };
    /** Optional straight-through absorptive packing around the perforated core.
     * All three values are zero for an exact dry bypass, or positive together. */
    double mufflerPackingFlowResistivityPaSPerM2 { 0.0 };
    double mufflerPackingThicknessMm { 0.0 };
    double mufflerPerforatedOpenAreaRatio { 0.0 };
    /** Straight pipe from the collector to the silencer: the downpipe and mid
     * pipe that carry a car's exhaust to its rear box. Zero length means none,
     * as every engine that predates this field had. Zero diameter keeps the
     * collector's (the primary's on a single-cylinder path). */
    double midpipeLengthMm { 0.0 };
    double midpipeDiameterMm { 0.0 };
};

/** The idle-air opening a carburettor's pilot jet is sized at: the idle
 *  governor's neutral command (its feed-forward), where a warm engine idles. */
inline constexpr double carburettorPilotSizingIdleOpening = 0.42;
/** The idle stop screw's turns at which it holds the slide on that sizing
 *  opening, and the most it turns in. */
inline constexpr double carburettorNominalIdleScrewTurns = 1.5;
inline constexpr double carburettorMaximumIdleScrewTurns = 8.0;
/** The idle-air opening the idle stop screw holds at `turns` in: each turn
 *  lifts the slide alike, so the idle path opens in proportion. */
[[nodiscard]] constexpr double carburettorIdleScrewOpening(double turns) noexcept {
    const auto held = turns < 0.0 ? 0.0
        : turns > carburettorMaximumIdleScrewTurns ? carburettorMaximumIdleScrewTurns : turns;
    return held * (carburettorPilotSizingIdleOpening / carburettorNominalIdleScrewTurns);
}

/** A slide carburettor: the fuel system that meters from the air itself.
 *
 * An injector is told how much fuel to deliver. A carburettor is not told
 * anything: its jets are orifices into a float bowl at ambient pressure, and
 * whatever depression the air draws through them is the mixture. Everything a
 * rider feels about a carburetted two-stroke follows from that, so the model
 * reproduces the mechanism rather than a mixture curve.
 *
 * Two circuits run in parallel and hand over without any blend between them,
 * because each is driven by a depression the other does not have. The main
 * circuit is driven by the venturi's own depression, which goes as the square
 * of the air velocity through the throat, so it is worth nothing at idle. The
 * pilot circuit is driven by the drop from the float bowl to the crankcase,
 * which is largest with the slide shut and collapses to nothing at full
 * throttle, where the crankcase pumps at about ambient. Neither needs to know
 * about the other.
 *
 * Jet sizes are diameters here. Real jets are stamped with a flow number
 * (a "260 main"), which is a calibrated flow at a reference head and not a
 * diameter; a 260 is about 0.90 mm.
 */
struct CarburettorConfig final {
    /** False keeps the intake path on its injector, as every engine that
     * predates this field does. */
    bool enabled { false };
    /** Throat diameter. Zero takes 0.80 of the throttle bore, which is about
     * the venturi a slide carburettor of a given nominal size carries. */
    double venturiDiameterMm { 0.0 };
    /** Main jet, metering from about a quarter throttle upwards, as the number
     * stamped on a Mikuni jet: cubic centimetres per minute of test fluid
     * under one metre of head. A 280 is what an RD350 runs, and the arithmetic
     * agrees: at full throttle each of its cylinders burns about 155 cc/min,
     * the venturi depression there is about 2.2 kPa, which is 0.3 m of petrol,
     * and a jet passes sqrt(0.3) of its rating at 0.3 m, so the rating wanted
     * is 155/0.55 = 282. */
    double mainJetFlowNumber { 280.0 };
    /** Pilot (slow) jet, metering at and just off idle, same convention. */
    double pilotJetFlowNumber { 35.0 };
    /** How much of the pilot circuit's restriction is the jet.
     *
     * The main jet is very nearly the only restriction in its circuit, so its
     * stamped number can be used directly. The pilot's is not: its fuel then
     * travels an emulsion passage, meets the air screw's bleed and leaves
     * through a small outlet at the slide's edge, and all of that throttles it
     * further. Driving a bare 35 jet with the whole crankcase depression gives
     * AFR 1.5 at idle, so the lumping is not optional; this factor is the
     * series restriction of everything after the jet. 0.026 is what an
     * RD350's 35 pilot and its ~20 kPa idle depression need to feed the air
     * its idle path passes at AFR 13.5, which is the one real pair the value
     * is fitted to (0.14 belonged to an idle delivery ratio of 0.35, about
     * three times a real one). A circuit resolved passage by passage would
     * replace it. */
    double pilotCircuitFactor { 0.026 };
    /** Needle clip position, 1 (needle highest, richest) to 5. The taper in
     * the needle jet is what meters between the pilot and the main. */
    double needleClipPosition { 3.0 };
    /** A fixed-venturi carburettor, a car's Weber, Solex or Holley: no slide
     * and no needle, the throttle a butterfly downstream of the venturi.
     * Its main jet meters at its whole area at any opening, and the
     * venturi's depression alone sets the flow, so the needle clip is
     * ignored. */
    bool fixedVenturi { false };
    /** Turns out on the pilot air screw. More turns bleed more air into the
     * pilot circuit and lean it; 1.5 is the usual nominal setting. */
    double airScrewTurns { 1.5 };
    /** Turns in on the idle stop screw, from the slide resting on its seat.
     * A carburettor has no idle governor: the screw holds the slide open and
     * the engine idles wherever that air takes it, so turning it in raises
     * the idle. The nominal 1.5 holds the opening the pilot is sized at. */
    double idleScrewTurns { carburettorNominalIdleScrewTurns };
    /** Height of the jet outlet above the float-bowl level. It is what stops a
     * carburettor dribbling fuel at rest, and what makes the main circuit go
     * lean before it goes rich. */
    double jetLiftMm { 5.0 };
    double jetDischargeCoefficient { 0.80 };
    /** Share of metered fuel that wets the bore and crankcase walls instead of
     * reaching the charge, and how fast that film gives it back. This is a
     * carburetted engine's tip-in stumble, and the reason an accelerator pump
     * exists. Zero is a dry bore. */
    double wallFilmFraction { 0.25 };
    double wallFilmTimeConstantSeconds { 0.12 };
    /** Accelerator pump: fuel squirted into the bore as the throttle opens,
     * in cubic centimetres for a stroke from shut to wide open. A car's
     * carburettor has one because its main circuit cannot answer a sudden
     * opening: the air arrives at once, the venturi's depression and the
     * jet's fuel only as the engine speeds up, and the film takes its share
     * first. A motorcycle's slide carburettor usually has none. Zero is no
     * pump. */
    double acceleratorPumpStrokeCc { 0.0 };
    /** How long the pump's nozzle takes to deliver a shot (its first-order
     * time constant). */
    double acceleratorPumpTimeConstantSeconds { 0.15 };
    /** Starter circuit (the enrichener a bike's choke lever works, or a
     * car's choke): its own jet, fed by the manifold's depression, opening
     * with the start aid's extra air and closing as that air does. Without
     * one the start aid's air only cracks the slide, which feeds the pilot
     * in proportion and so enriches nothing. Flow number in cc/min under
     * one metre of fuel, as the other jets; zero is no circuit. */
    double starterJetFlowNumber { 0.0 };
};

struct IntakeConfig final {
    double plenumVolumeLitres { 3.0 };
    double throttleDiameterMm { 60.0 };
    /** Number of equal throttle bores feeding this intake path. */
    std::uint32_t throttleCount { 1 };
    double throttleDischargeCoefficient { 0.72 };
    /** Fuel metering in this path's throttle bore. Disabled by default,
     * leaving the path on `InjectionConfig`. */
    CarburettorConfig carburettor {};
    double runnerLengthMm { 300.0 };
    /** Runner diameter at the cylinder-head/valve end. */
    double runnerDiameterMm { 38.0 };
    /** Optional diameter at the plenum end. Zero keeps a constant runner. */
    double runnerPlenumDiameterMm { 0.0 };
    /** Optional upstream acoustic hardware. Zero volume/length means the
     * throttle mouth is directly exposed rather than inventing an airbox. */
    double airboxVolumeLitres { 0.0 };
    /** A filter element on the mouth with no housing around it (a pod or
     * cone filter). An airbox always carries its element; without one the
     * mouth is bare unless this is set. */
    bool podFilter { false };
    double inletDuctLengthMm { 0.0 };
    /** Zero inherits the throttle diameter. */
    double inletDuctDiameterMm { 0.0 };
    /** Zero inherits the inlet-duct diameter; used by inlet radiation. */
    double bellmouthDiameterMm { 0.0 };
    double idleBypassAreaMm2 { 12.0 };
    double throttleGamma { 1.7 };
    /**
     * Flow area still open with the throttle plate fully closed, per bore.
     *
     * A throttle plate is a disc in a bore and cannot seal against it: it runs
     * with a working clearance, and production throttle bodies additionally
     * carry a deliberate minimum air path (a stop screw or a machined notch) so
     * the engine can breathe with the pedal released and the idle actuator shut.
     * The closed-plate leakage of a typical 60 mm body is a few square
     * millimetres, which is the order of this default.
     *
     * Without it the intake has literally zero flow area whenever the driver
     * throttle and the idle bypass command are both zero, and the engine pumps
     * against a sealed manifold. Measured on the catalogue before this existed,
     * manifold pressure fell to about 10 kPa during the post-start speed flare
     * -- a vacuum no throttled engine can produce -- torque went to about
     * -75 Nm, and every larger engine stalled within a second of the starter
     * releasing.
     *
     * This is intake hardware, not a control command. It deliberately does not
     * live in the ECU: the driver's throttle and the idle actuator must both
     * still be able to close completely, which is why a minimum *commanded*
     * throttle opening was previously removed. The floor belongs to the bore.
     *
     * The default is a genuine leak and not an idle air supply. It is small
     * enough that the idle actuator still governs idle: at 3 mm2 per bore a
     * four-throttle 1.3 litre engine idled at 1945 rpm against a 1250 rpm
     * target, because leakage alone exceeded its idle air demand. What keeps an
     * engine alive through the post-start flare is the ECU's post-start air
     * schedule, not this.
     */
    double closedThrottleLeakageAreaMm2 { 0.6 };
    /**
     * One throttle plate in each runner instead of one ahead of the plenum
     * (individual throttle bodies). The plenum is then the airbox the runner
     * mouths draw from, fed through the bores fully open, and each runner is
     * two 1-D ducts meeting at a restriction face: the plate, with its share
     * of the bores, leakage and idle bypass. The manifold pressure the ECU
     * reads is the mean behind the plates, through a 30 ms tapping manifold.
     */
    bool individualThrottles { false };
    /** Plate position along the runner, from the valve. Zero places it at
     *  55 % of the runner length (not measured on any engine). */
    double throttleDistanceFromValveMm { 0.0 };
};

struct IntakePathConfig final {
    std::uint32_t id { 1 };
    std::vector<std::uint32_t> cylinderIds;
    IntakeConfig geometry;
    // True only for a path synthesized from the legacy/global intake fields.
    // Explicit paths are authoritative and retain the default false value.
    bool inheritsGlobalGeometry { false };
};

struct CylinderBankConfig final {
    std::uint32_t id { 0 };
    double angleDegrees { 0.0 };
    std::vector<std::uint32_t> cylinderIds;
    CamshaftConfig camshafts;
    std::uint32_t intakeId { 0 };
    std::uint32_t exhaustPathId { 0 };
};

/** Engine-fixed free-field acoustic coordinates, in metres.
 *
 * +X is the engine's right side, +Y points out of the nominal tailpipe and +Z
 * points upward. These are geometry and measurement-chain data, never pan or
 * gain controls.
 */
struct AcousticPoint3M final {
    double x { 0.0 };
    double y { 0.0 };
    double z { 0.0 };
};

struct AcousticObserverConfig final {
    AcousticPoint3M leftMicrophoneM { -0.18, 4.0, 0.8 };
    AcousticPoint3M rightMicrophoneM { 0.18, 4.0, 0.8 };
    /** Zero derives local sound speed from the acoustic medium. */
    double soundSpeedMps { 0.0 };
    /**
     * Distance from the engine origin at which the listener is placed, metres.
     *
     * How far away the listener stands is a property of the SCENE, not of the
     * engine, and the catalogue had drifted into treating it as both: fourteen
     * engines were authored between 3.5 and 5 m while the V12 sat at 24 m and
     * the radial at 6. With a `1/r` law that is about -16 dB on the V12 against
     * the twins for no reason a listener can act on, and it is most of why the
     * biggest engine in the catalogue was reported as making no sound at all.
     *
     * The microphone pair is therefore rescaled about the origin to this
     * distance before propagation. It is a UNIFORM scale, so every angle is
     * preserved -- directivity, the interaural delay ratio, the relative
     * geometry of multiple outlets -- and only `r` changes. Radiated source
     * strength is untouched, so engines still differ in level by how much sound
     * they actually make, which is the comparison that means something.
     *
     * Zero keeps the authored positions exactly, for a scene that is genuinely
     * about distance. The SPL guard already back-extrapolates to one metre by
     * this same law, so it does not confuse a distant observer with a weak
     * source and is unaffected either way.
     */
    double listeningDistanceM { 4.0 };
};

/** Uniform scale that places the authored microphone pair at the scene's
 *  listening distance. Returns 1 when the scene keeps its authored positions.
 *
 *  Every consumer that derives a distance from `leftMicrophoneM` /
 *  `rightMicrophoneM` must apply this. Three of them computed their own mean
 *  distance independently, and leaving any one of them on the authored value
 *  makes it disagree with the propagation the listener actually hears -- the
 *  SPL guard in particular back-extrapolates by `1/r` and would be
 *  extrapolating from a radius the render no longer uses. */
[[nodiscard]] inline double observerMicrophoneScale(
    const AcousticObserverConfig& observer) noexcept {
    const auto magnitude = [](const AcousticPoint3M& point) noexcept {
        return std::sqrt(point.x * point.x + point.y * point.y
            + point.z * point.z);
    };
    if (!(observer.listeningDistanceM > 0.0)) return 1.0;
    const auto authored = 0.5 * (magnitude(observer.leftMicrophoneM)
        + magnitude(observer.rightMicrophoneM));
    if (!(authored > 1.0e-6)) return 1.0;
    const auto scale = observer.listeningDistanceM / authored;
    return std::isfinite(scale) && scale > 0.0 ? scale : 1.0;
}

/** Microphone positions after the listening-distance scale. */
[[nodiscard]] inline AcousticPoint3M effectiveMicrophonePosition(
    const AcousticObserverConfig& observer, bool right) noexcept {
    const auto scale = observerMicrophoneScale(observer);
    const auto& point = right ? observer.rightMicrophoneM
                              : observer.leftMicrophoneM;
    return { point.x * scale, point.y * scale, point.z * scale };
}

/** Mean listener distance from the engine origin, after the scale. */
[[nodiscard]] inline double effectiveObserverDistanceM(
    const AcousticObserverConfig& observer) noexcept {
    const auto magnitude = [](const AcousticPoint3M& point) noexcept {
        return std::sqrt(point.x * point.x + point.y * point.y
            + point.z * point.z);
    };
    return 0.5 * (magnitude(effectiveMicrophonePosition(observer, false))
        + magnitude(effectiveMicrophonePosition(observer, true)));
}

/** A user-authored component in one exhaust path's directed acyclic graph. */
struct ExhaustComponentConfig final {
    // Component IDs are local to the containing exhaust path.
    std::uint32_t id { 0 };
    ExhaustComponentType type { ExhaustComponentType::pipe };
    double lengthMm { 300.0 };
    /** Diameter at the component inlet. On a packed muffler this is the
     * perforated mean-flow core diameter; on a dry muffler it is the chamber
     * inlet and volumeLitres may expand the internal gas section. */
    double diameterMm { 42.0 };
    /** Optional outlet diameter. Zero keeps a constant section. A non-zero
     * value forms a linear-area taper in the quasi-1D gas solver.
     */
    double outletDiameterMm { 0.0 };
    /** Optional component volume. For a packed muffler this is the gross outer
     * can volume and must exceed the swept core volume; the difference is a
     * sealed acoustic annulus and never becomes mean-flow area. */
    double volumeLitres { 0.0 };
    // Dimensionless pressure-loss coefficient added to the geometric loss.
    double restriction { 0.0 };
    // On a terminal resonator, zero uses lengthMm and a positive value requests
    // a c/(4f) acoustic length at the graph's reference temperature. Kept as
    // legacy route metadata on inline components, but not imposed on the
    // physical waveguide.
    double resonanceHz { 0.0 };
    // Compatibility gain for the reconstructed audio fallback. The physical
    // SI waveguide remains passive and does not consume this arbitrary gain.
    double acousticGain { 1.0 };
    double dischargeCoefficient { 0.72 };
    /** Radiation geometry, used only when type==outlet. */
    AcousticPoint3M acousticPositionM {};
    AcousticPoint3M acousticAxis { 0.0, 1.0, 0.0 };
    AcousticTerminationType acousticTermination {
        AcousticTerminationType::unflanged };
    /** Optional perforated-core porous packing. All three must be positive;
     * zero leaves the acoustic network exactly unlined. The resistivity and
     * thickness drive material loss, while the open-area ratio couples the
     * gross-can annulus to the core as a passive compliance. */
    double packingFlowResistivityPaSPerM2 { 0.0 };
    double packingThicknessMm { 0.0 };
    double perforatedOpenAreaRatio { 0.0 };
    /** Optional homogenised catalyst substrate. All three fields are zero for
     * an exact backward-compatible bypass and positive together when authored. */
    double catalystCellDensityCpsi { 0.0 };
    double catalystOpenAreaRatio { 0.0 };
    /** Effective heat capacity of the solid substrate per occupied solid
     * volume. Required with the two cellular-geometry fields. */
    double catalystSubstrateVolumetricHeatCapacityJPerM3K { 0.0 };
    /** Power-wave cross-coupling amplitude of an ideal matched four-port X.
     * Zero transmits each bank only to its paired outlet; one swaps the two
     * outlets. The complementary straight coefficient is sqrt(1-k^2), so the
     * acoustic scattering matrix is passive for every value in [0, 1]. */
    double crossoverCoupling { 0.0 };
    /** On a pipe fed by another part: an active exhaust valve at its inlet,
     * a butterfly in the face between the two parts (never a short pipe of
     * its own). Shut, the face is a wall: a bypass with its valve shut is a
     * closed branch that still resonates. Every valve of the engine follows
     * one actuator (ExhaustValveConfig, EngineControls::exhaustValveMode). */
    bool inletValve { false };
};

/** The actuator of the engine's active exhaust valves (inletValve parts).
 * Nothing on an engine without one. */
struct ExhaustValveConfig final {
    /** Automatic mode opens the valves at or above this speed... */
    double openAboveRpm { 3'500.0 };
    /** ...or at or above this throttle, 0-1 (the plate never reads more than
     * 0.999, which is what 1 means here). It shuts them again 250 rpm and
     * 5 % of throttle under both. */
    double openAboveThrottle { 0.5 };
    /** A full stroke, closed to open, s: about 0.3 s on a production
     * actuator. Zero moves it within a frame. */
    double travelSeconds { 0.3 };
};

enum class NitrousKitType : std::uint8_t {
    /** Nitrous only: the ECU's injectors add the kit's fuel. */
    dry,
    /** The kit's nozzle sprays its own fuel with the nitrous. */
    wet
};

/** A nitrous oxide kit: one nozzle (a plate behind the throttle) feeding the
 * plenum, a bottle, an arming switch and a push button. Nothing on an engine
 * without one (`fitted`); no limit on any figure (owner, 2026-11-11). */
struct NitrousConfig final {
    bool fitted { false };
    NitrousKitType type { NitrousKitType::wet };
    /** The kit's rating, kW at the crank (a "100 hp shot": 74.57 kW). It
     *  sizes the jet: nitrousMassFlowPerShotKw at the reference bottle
     *  pressure. */
    double shotKw { 74.57 };
    /** Liquid nitrous a full bottle holds, kg (a 10 lb bottle: 4.54). */
    double bottleCapacityKg { 4.54 };
    /** The bottle never empties and holds its temperature (and so its
     *  pressure): unlimited nitrous for testing. */
    bool unlimitedBottle { false };
    /** A heater holds the bottle at `bottleTemperatureC`; without one it
     *  starts at the ambient temperature and cools as it empties. */
    bool bottleHeater { true };
    double bottleTemperatureC { 30.0 };
    /** It sprays only at or above this throttle, 0-1 (the WOT switch)... */
    double minimumThrottle { 0.95 };
    /** ...and inside this window of engine speed, rpm (0: no ceiling). */
    double minimumRpm { 3'000.0 };
    double maximumRpm { 0.0 };
    /** Only while the push button is held (Drive's key); off (the default),
     *  arming and the full-throttle switch are enough, as on most kits. */
    bool pushButton { false };
    /** Progressive controller: the flow rises from 0 to the full jet over
     *  this, s (0: at once). */
    double rampSeconds { 0.0 };
    /** Spark taken off the map while it sprays, degrees per 50 hp of shot. */
    double sparkRetardDegreesPer50Hp { 2.0 };
    /** The kit's own fuel for its oxygen, as a lambda: the wet nozzle's fuel
     *  jet, or the ECU's extra pulse for a dry kit. */
    double kitLambda { 0.80 };

    [[nodiscard]] bool operator==(const NitrousConfig&) const = default;
};

/** Liquid nitrous a kit's jet passes per kW of its rating, kg/s, at the
 *  reference bottle pressure: 2.27 kg/min per 100 hp, from the energy
 *  balance (oxygen 36.4 % by mass, the stoichiometric fuel it burns and
 *  82 kJ/mol of decomposition, 6.6 MJ per kg of nitrous, at a 30 % brake
 *  efficiency); install sheets and tuners give 4-6 lb/min per 100 hp
 *  (1.8-2.7 kg/min). */
inline constexpr double nitrousMassFlowPerShotKw = 2.27 / 60.0 / 74.57;
/** The pressure a kit's rating is quoted at, kPa (900 psi). */
inline constexpr double nitrousReferenceBottlePressureKpa = 6'205.0;

enum class ExhaustValveMode : std::uint8_t {
    /** The actuator follows ExhaustValveConfig's speed and throttle. */
    automatic,
    closed,
    open
};

/** The ECU's overrun map. Clean deceleration fuel cut is every engine's; the
 * late spark is the one backfire strategy, switched on in the Audio workshop
 * (`disableBackfires`). The anti-lag and chopped-fuel strategies are gone
 * (2026-10-24): files that still name them read as `cleanDfco`. */
enum class ExhaustAfterfireStrategy : std::uint8_t {
    cleanDfco,
    /** No fuel cut on overrun, as a "pops and bangs" map does: its own spark
     * angle (`overrunSparkAdvanceDegrees`) and an ignition cut on a share of
     * the cycles (`overrunSparkCutFraction`). A late spark's flame is still
     * burning when the exhaust valve opens; a cut cycle's whole charge leaves
     * unburnt, and the next fired cycle's exhaust lights it in the primary.
     * Only the cut makes a pop (journal 2026-10-25): with a late spark alone
     * every cycle burns its own charge, continuously. */
    lateSparkOverrun,
};

/** Optional oxidation of unburned charge inside the physical exhaust network.
 * Disabled by default: enabling it never creates fuel or oxygen, it only lets
 * inventories already present react when hot enough. */
struct ExhaustAfterfireConfig final {
    bool enabled { false };
    double ignitionTemperatureK { 900.0 };
    double reactionTimeConstantSeconds { 0.010 };
    double reactionEfficiency { 0.95 };
    double overrunMinimumRpm { 2'500.0 };
    double overrunMaximumThrottle { 0.02 };
    /** Spark advance on overrun for `lateSparkOverrun`, degrees before top
     * dead centre: negative is after it. Only that strategy reads it. */
    double overrunSparkAdvanceDegrees { -20.0 };
    ExhaustAfterfireStrategy strategy {
        ExhaustAfterfireStrategy::cleanDfco
    };
    /** Reference ignition delay at ignitionTemperatureK, stoichiometry and
     * inductionReferencePressureKpa. Schema-7 files migrate to the former flat
     * timer by keeping all three correlation exponents at zero. */
    double inductionTimeSeconds { 0.004 };
    /** Reference pressure of the induction-delay correlation. */
    double inductionReferencePressureKpa { 101.325 };
    /** Arrhenius activation energy divided by R, expressed as kelvin. Zero
     * preserves the schema-7 temperature-independent timer. */
    double inductionActivationTemperatureK { 0.0 };
    /** Positive exponent n in tau proportional to pressure^-n. */
    double inductionPressureExponent { 0.0 };
    /** Exponent m in tau proportional to equivalenceRatio^m. */
    double inductionEquivalenceRatioExponent { 0.0 };
    /** Time for a fully accumulated, unlit induction integral to decay back to
     * zero when the hot-source condition disappears but the mixture remains
     * flammable. A non-flammable inventory resets immediately. */
    double inductionDecayTimeSeconds { 0.008 };
    /** Lean/rich flammability bounds expressed as equivalence ratio. */
    double minimumEquivalenceRatio { 0.45 };
    double maximumEquivalenceRatio { 1.80 };
    /** Below this bulk-gas temperature an established kernel is quenched unless
     * a sufficiently hot wall continues to supply ignition energy. */
    double quenchTemperatureK { 520.0 };
    /** Time for the unburnt charge a cylinder exhausts to mix into the gas
     * around it, s. Until then it is a pocket of its own composition and
     * temperature carried by the flow; zero mixes it into the cells at once. */
    double pocketMixingTimeSeconds { 0.0 };
    /** Share of overrun cycles whose spark a `lateSparkOverrun` map cuts,
     * fuel kept. Each is drawn on its own, so the cuts come irregularly, as
     * the pops of a real overrun do. Zero: every overrun cycle fires. */
    double overrunSparkCutFraction { 0.0 };
};

/** The backfire calibration the Audio workshop installs on an engine that
 * never authored one, measured on the Lab Twin and the MT-07 (journal
 * 2026-10-25): an ignition cut on 70 % of the overrun cycles, the others
 * fired at +10 deg so that their exhaust is hot enough to light the slugs,
 * which stay pockets of their own for 40 ms and burn in 0.5 ms. */
struct MeasuredBackfireProfile final {
    static constexpr double ignitionTemperatureK = 800.0;
    static constexpr double reactionTimeConstantSeconds = 0.0005;
    static constexpr double overrunSparkAdvanceDegrees = 10.0;
    static constexpr double pocketMixingTimeSeconds = 0.040;
    static constexpr double overrunSparkCutFraction = 0.70;
};

[[nodiscard]] constexpr bool afterfireRetainsFuel(
    ExhaustAfterfireStrategy strategy) noexcept {
    return strategy != ExhaustAfterfireStrategy::cleanDfco;
}

/** Coherent, allocation-free calibration copied into the simulation thread.
 * It deliberately contains no state and no geometry: applying it must not
 * rebuild a network or reset gas/wall/ECU history. */
struct AudioPhysicsCalibration final {
    double cycleVariationCoefficientOfVariation { 0.0 };
    double cycleVariationCorrelation { 0.45 };
    bool limiterKeepsFuel { false };
    ExhaustAfterfireConfig exhaustAfterfire;
};

/**
 * Why the overrun afterfire is not metering fuel right now.
 *
 * The afterfire has eight independent preconditions and a user who hears no pop
 * has no way to tell which one is missing -- the reported symptom is identical
 * whether the feature is unauthored, the throttle never closed far enough, or
 * the engine is still in its after-start flare. Every one of those was proposed
 * and none could be confirmed from a render, so the state is published instead
 * of guessed at.
 *
 * A bitmask rather than a single reason: several conditions genuinely fail at
 * once during a normal lift-off, and reporting only the first would make the
 * readout flicker between them as the engine coasts down.
 */
enum class AfterfireBlocker : std::uint32_t {
    none = 0,
    /** Not authored: backfires off, or a non-gasoline engine. */
    notAuthored = 1U << 0,
    ignitionOff = 1U << 1,
    cranking = 1U << 2,
    /** Commanded throttle above `overrunMaximumThrottle` (default 2 %). */
    throttleOpen = 1U << 3,
    belowMinimumRpm = 1U << 4,
    /** Deceleration fuel cut is not latched, so the engine is not in overrun. */
    fuelCutInactive = 1U << 5,
    revLimiterActive = 1U << 6,
    /** The engine has not been taken above the rpm gate under throttle since
     * the last start, so the lift-off is still an after-start flare. */
    notArmed = 1U << 8,
    /** The overboost cut holds the fuel: the overrun map must not refuel it
     *  (audit PG-06). */
    overboostCut = 1U << 9,
};

[[nodiscard]] constexpr bool afterfireBlocked(std::uint32_t mask,
                                              AfterfireBlocker bit) noexcept {
    return (mask & static_cast<std::uint32_t>(bit)) != 0U;
}
/** Shortest human-readable summary of a blocker mask, most informative first.
 *  Empty when nothing blocks. Declared here so the app and the harnesses print
 *  the same words for the same state. */
[[nodiscard]] const char* afterfireBlockerName(std::uint32_t mask) noexcept;

/** What holds anti-lag back, one bit each (`EngineState::antiLagBlockers`):
 *  zero while it works, or while it is off (`antiLagArmed` false). */
enum class AntiLagBlocker : std::uint32_t {
    ignition = 1U << 0,
    /** Rally: the driver's foot is on the throttle. */
    throttle = 1U << 1,
    /** Launch: launch control is not holding the engine. */
    notLaunching = 1U << 2,
    belowMinimumRpm = 1U << 3,
    aboveMaximumRpm = 1U << 4,
    /** Rally: neutral or the clutch out longer than a gear change. */
    decoupled = 1U << 5,
    /** Its maximum time on this lift: the throttle re-arms it. */
    timeUp = 1U << 6,
    exhaustTooHot = 1U << 7,
    /** The rev limiter, the overboost cut or a broken engine. */
    protection = 1U << 8,
};

/** Why a fitted nitrous kit is not spraying: bits of
 *  `EngineState::nitrousBlockers`, every one that holds. Telemetry only. */
enum class NitrousBlocker : std::uint32_t {
    notArmed = 1U << 0,
    /** Its push button is not held. */
    pushButton = 1U << 1,
    ignitionOff = 1U << 2,
    /** The throttle is under the kit's minimum. */
    throttle = 1U << 3,
    belowMinimumRpm = 1U << 4,
    aboveMaximumRpm = 1U << 5,
    bottleEmpty = 1U << 6,
};

/** Why the engine is not giving more right now: bits of
 *  `EngineState::activeLimits`. Telemetry only; nothing reads it back. */
enum class ActiveLimit : std::uint32_t {
    none = 0,
    /** The ECU's rev limiter is cutting (soft or hard stage). */
    revLimiter = 1U << 0,
    /** Knock control is pulling spark. */
    knockRetard = 1U << 1,
    /** A hot coolant is pulling spark and richening the mixture. */
    coolantProtection = 1U << 2,
    /** A diesel's fuel is capped by the air: the smoke limit. */
    dieselSmokeLimit = 1U << 3,
    /** A diesel's fuel is capped by its quantity map. */
    dieselQuantityLimit = 1U << 4,
    /** The wastegate is open: boost is held at its target, not by the turbo. */
    boostAtTarget = 1U << 5,
    /** The injectors are open for the whole of their window. */
    injectorSaturated = 1U << 6,
    /** Launch control holds the engine at its launch speed. */
    launchControl = 1U << 7,
    /** The boost ran past its target by the overboost margin: the ECU cuts
     *  the fuel until it falls back. */
    overboostCut = 1U << 8,
    /** A turbocharger runs past its top speed line (or its wheel burst). */
    turboOverspeed = 1U << 9
};
[[nodiscard]] constexpr bool hasActiveLimit(std::uint32_t mask, ActiveLimit bit) noexcept {
    return (mask & static_cast<std::uint32_t>(bit)) != 0U;
}

struct ExhaustCylinderConnectionConfig final {
    std::uint32_t cylinderId { 0 };
    std::uint32_t componentId { 0 };
};

struct ExhaustComponentConnectionConfig final {
    std::uint32_t fromComponentId { 0 };
    std::uint32_t toComponentId { 0 };
    /** Port 0 or 1 when the source is a crossover; unspecified otherwise. */
    std::uint8_t fromPort { unspecifiedExhaustComponentPort };
    /** Port 0 or 1 when the destination is a crossover; unspecified otherwise. */
    std::uint8_t toPort { unspecifiedExhaustComponentPort };
};

/**
 * Optional custom topology for an exhaust path. When absent, the legacy
 * geometry fields are compiled to a primary/collector/muffler/outlet graph.
 */
struct ExhaustNetworkConfig final {
    std::vector<ExhaustComponentConfig> components;
    std::vector<ExhaustCylinderConnectionConfig> cylinderConnections;
    std::vector<ExhaustComponentConnectionConfig> connections;
};

struct ExhaustPathConfig final {
    std::uint32_t id { 0 };
    std::vector<std::uint32_t> cylinderIds;
    ExhaustConfig geometry;
    std::string impulseResponsePath;
    double audioVolume { 1.0 };
    std::optional<ExhaustNetworkConfig> network {};
    // Runtime migration provenance; deliberately not part of schema v1.
    bool inheritsGlobalGeometry { false };
    /** Radiation geometry for the outlet synthesized from scalar path data. */
    AcousticPoint3M acousticPositionM {};
    AcousticPoint3M acousticAxis { 0.0, 1.0, 0.0 };
    AcousticTerminationType acousticTermination {
        AcousticTerminationType::unflanged };
    /** The turbocharger this path's turbine face drives. Negative: the path's
     * index modulo ForcedInductionConfig::turbochargerCount. */
    std::int32_t turbocharger { -1 };
};

struct IgnitionMapSample final {
    double rpm { 0.0 };
    double advanceDegrees { 10.0 };
};

struct KnockLimitSample final {
    double rpm { 0.0 };
    double advanceDegrees { 0.0 };
    double manifoldPressureKpa { 0.0 };
};

struct IgnitionConfig final {
    std::vector<IgnitionMapSample> timingCurve {
        { 0.0, 10.0 }, { 1'000.0, 14.0 }, { 2'000.0, 22.0 },
        { 3'500.0, 30.0 }, { 5'500.0, 34.0 }, { 8'000.0, 32.0 }
    };
    double revLimitRpm { 7'200.0 };
    double limiterDurationSeconds { 0.08 };
    /**
     * Keep injecting while the hard limiter suppresses spark.  The default
     * remains a fuel-and-spark cut for backwards-compatible, clean operation;
     * audio-oriented calibrations may opt into a physical wet limiter so the
     * exhaust afterfire model receives actual unburned fuel.
     */
    bool limiterKeepsFuel { false };
    /**
     * The knock-limited spark at full load, measured on the dyno with the
     * knock control on (`calibrateKnockLimit`), and the manifold pressure it
     * was measured at. The ECU holds the map under it in proportion to how
     * far the manifold pressure has climbed towards that pressure, so part
     * load keeps its map. Empty: the map alone, the knock control's retard on
     * top as before.
     */
    std::vector<KnockLimitSample> knockLimitCurve {};
};

struct InjectionConfig final {
    InjectionMode mode { InjectionMode::direct };
    double startAngleDegrees { 570.0 };
    double endAngleDegrees { 690.0 };
    // Per-injector mass flow. At 0.745 kg/L, 400 cc/min is about 4,970 mg/s;
    // the larger DI default reflects its high pressure and short open window.
    double injectorFlowMgPerSecond { 20'000.0 };
    double fuelTemperatureC { 25.0 };
    // Port injection: regulated differential pressure relative to the intake
    // manifold. Direct injection: absolute rail pressure.
    double railPressureBar { 200.0 };
    // Differential pressure at which injectorFlowMgPerSecond is specified.
    double referencePressureBar { 200.0 };
    // Fraction of a port-injection pulse that wets the port wall as liquid
    // film instead of vaporising in flight (the X of the X-tau wall-film
    // model; Aquino, SAE 810494). The catalogue loader applies 0.22 and
    // 0.26 s to port-injected engines: with an effective tau of ~0.6 s that
    // matches the warmest tip-in of Curtis et al. (SAE 961186, x1.05 at a
    // 349 K port). Note, measured: the film does NOT by itself prevent the
    // flooded-misfire lock-in a big-cylinder engine can enter at idle catch
    // with a resolved 1-D runner (the V12 flooded identically at 0.22), so
    // do not reach for this knob to fix an idle. DI ignores this field.
    double wallFilmFraction { 0.35 };
    double vaporisationTimeConstantSeconds { 0.035 };
    double latentHeatKjPerKg { 350.0 };
    double directChargeCoolingEfficiency { 0.82 };
    double portChargeCoolingEfficiency { 0.28 };
    /** Direct-injection liquid-droplet vaporisation time at the reference
     *  chamber temperature. Zero preserves the legacy, fully-vaporised pulse.
     */
    double directSprayVaporisationTimeConstantSeconds { 0.0 };
    /** Time for vaporised spray parcels to entrain sufficient chamber gas to
     *  become part of the locally combustible mixture. Zero is instantaneous.
     */
    double directSprayEntrainmentTimeConstantSeconds { 0.0 };
    struct FuelQuantityLimitSample final {
        double rpm { 0.0 };
        /** Per-cylinder maximum metered fuel at full driver demand. */
        double milligramsPerCycle { 0.0 };
    };
    /** Compression-ignition full-load smoke/torque limiter. Empty means the
     *  oxygen-based target alone governs quantity. The driver-demand fraction
     *  scales this limit before it is applied.
     */
    std::vector<FuelQuantityLimitSample> fullLoadFuelLimit;
};

struct SolverConfig final {
    double mechanicalFrequencyHz { 2'000.0 };
    double maximumMechanicalFrequencyHz { 60'000.0 };
    double maximumCrankDegreesPerStep { 2.0 };
    std::uint32_t gasSubsteps { 1 };
};

struct TransmissionConfig final {
    std::vector<double> gearRatios { 2.97, 2.07, 1.43, 1.00, 0.84, 0.56 };
    double finalDriveRatio { 3.42 };
    double maxClutchTorqueNm { 1'356.0 };
    double drivelineEfficiency { 0.88 };
    double drivenWheelInertiaKgM2 { 3.6 };
    // Half-width of the clutch lock window in slip rpm: inside it the disc sticks
    // and carries torque up to capacity, outside it slips at capacity (kinetic).
    double clutchLockSpeedRpm { 35.0 };
    double shiftDurationSeconds { 0.18 };
    /** An automatic gearbox chooses the gear from the driver's pedal
     * (ShiftSchedule); the driver can switch it on and off while driving. */
    bool automaticShifting { false };
    /** Full-throttle upshift speed; 0 places it just under the active rev
     * limit. Part throttle shifts earlier. */
    double automaticUpshiftRpm { 0.0 };
    /** Lugging speed: under it the gearbox changes down whatever the pedal;
     * 0 places it at 1.3 x idle. Above it, the pedal and the brake place the
     * downshift (ShiftSchedule). */
    double automaticDownshiftRpm { 0.0 };
    double reverseRatio { 3.20 };
    double gearboxInputInertiaKgM2 { 0.08 };
    double differentialInertiaKgM2 { 0.16 };
    double clutchThermalCapacityJPerC { 18'000.0 };
    double clutchCoolingWPerC { 8.0 };
    double clutchFadeStartTemperatureC { 220.0 };
    double clutchFailureTemperatureC { 420.0 };
    double shiftTorqueCutFraction { 0.85 };
    /** How a gear change is made.
     *  - manual: the driver lifts and dips the clutch, over
     *    shiftDurationSeconds with shiftTorqueCutFraction of throttle lift.
     *  - sequential: a dog box, clutch left in. An upshift with the
     *    quickshifter cuts the ignition for quickshifterCutSeconds while the
     *    dogs change over; a downshift with the auto-blipper frees the dogs
     *    and opens the throttle until the engine reaches the new gear's speed.
     *    Without them, a shift is made as a manual one.
     *  - dualClutch: one clutch hands the drive over to the other with no
     *    torque gap; the oncoming clutch pulls the engine to the new speed
     *    over shiftDurationSeconds. Downshifts are blipped.
     *  - cvt: a belt variator, its ratio anywhere between the first gear
     *    ratio (lowest) and the last (tallest), held where it keeps the
     *    engine at a speed scheduled from the pedal (VariatorControl). One
     *    forward position. It starts on its own clutch: a wet one that
     *    creeps, as a dual clutch's, or a scooter's centrifugal one.
     *  - automatedManual: a manual gearbox and its one dry clutch worked by
     *    actuators (a single-clutch "robotised" box, a truck's AMT). No
     *    pedal: it starts on its own clutch, as a dual clutch does, and an
     *    upshift is a manual's, clutch out and torque cut over
     *    shiftDurationSeconds, so the drive has a gap. Downshifts are
     *    blipped. */
    ShiftStyle shiftStyle { ShiftStyle::manual };
    bool quickshifter { true };
    double quickshifterCutSeconds { 0.065 };
    bool autoBlipper { true };
    /** A dual clutch's torque intervention on a loaded upshift: the ECU
     * retards the spark by up to this much while the oncoming clutch pulls
     * the engine down, released as the speeds meet (0 = none). Production
     * calibrations are not published; the default is a choice. */
    double dualClutchUpshiftRetardDegrees { 20.0 };
    /** The rest of that intervention: the share of the engine's torque the
     * gearbox asks to remove, which the ECU meets past its retard floor by
     * suppressing injection on that share of the firings, spread in firing
     * order (Bosch ME7: a dual clutch asks for ~24 % of the torque during
     * an upshift, and the cut, not the retard, makes the "fart"; NefMoto
     * forum, "Launch control and DSG farts", 2021). Released with the
     * retard as the speeds meet. 0 = retard only. */
    double dualClutchUpshiftCylinderCutFraction { 0.76 };
    /** A CVT's start clutch: centrifugal (a scooter's: open at idle, no
     * creep) rather than wet. It bites at centrifugalClutchEngageRpm (0:
     * 1.7 x idle) and is shut at 1.35 x that. */
    bool centrifugalClutch { false };
    double centrifugalClutchEngageRpm { 0.0 };
};

struct VehicleConfig final {
    double massKg { 1'420.0 };
    double dragCoefficient { 0.32 };
    double frontalAreaM2 { 2.20 };
    double tireRadiusM { 0.315 };
    double rollingResistanceCoefficient { 0.014 };
    double tireFrictionCoefficient { 1.0 };
    DrivenAxleLayout drivenAxleLayout { DrivenAxleLayout::rear };
    /** Static fraction of vehicle weight carried by the driven axle. Ignored
     * for all-wheel drive, where every tyre contributes its normal load. */
    double drivenAxleWeightFraction { 0.55 };
    double wheelbaseM { 2.65 };
    double centerOfGravityHeightM { 0.52 };
    double maximumBrakeForceN { 14'000.0 };
    /** Whether the driven tyre may break traction and spin.
     *
     * Off by default, and deliberately so: the grip limit is a VEHICLE feature
     * layered on top of the engine, and until the engine side is trustworthy it
     * only adds a second explanation for every "it will not rev" observation --
     * which is exactly what happened, with a part-load fuelling defect being
     * read from the application as a traction limit because the panel was
     * announcing one. With this off the tyre transmits whatever the driveline
     * asks, the model behaves like a rolling road, and `tractionLimited` is
     * always false so the diagnostic cannot fire. Turning it on restores the
     * friction-circle clamp and the longitudinal load transfer that
     * `EngineLab.VehicleDynamics` exercises; that test sets it explicitly and
     * therefore still covers the model. */
    bool tyreGripLimitEnabled { false };
};

struct ForcedInductionConfig final {
    bool enabled { false };
    ForcedInductionType type { ForcedInductionType::turbocharger };
    double pressureRatio { 1.0 };
    double fullBoostRpm { 3'500.0 };
    double compressorEfficiency { 0.68 };
    double chargeTemperatureRiseC { 35.0 };
    double turbineEfficiency { 0.68 };
    double shaftInertiaKgM2 { 0.00012 };
    double wastegatePressureRatio { 1.05 };
    double designShaftSpeedRpm { 130'000.0 };
    double bearingFrictionPowerWatts { 280.0 };
    double turbineFlowAreaMm2 { 700.0 };
    double wastegateFlowAreaMm2 { 520.0 };
    /** Rotor geometry used by aeroacoustics. Zero count disables the
     * corresponding blade/lobe-passing tone rather than inventing one. */
    std::uint32_t compressorBladeCount { 0 };
    std::uint32_t turbineBladeCount { 0 };
    std::uint32_t superchargerLobeCount { 0 };
    double superchargerDriveRatio { 1.0 };
    /** A Roots supercharger's (lobes > 0) air displaced per rotor turn, in
     *  litres. 0: sized to hold `pressureRatio` at the redline
     *  (`rootsDisplacementLitres`). */
    double superchargerDisplacementLitres { 0.0 };
    /** A Roots supercharger's bypass valve, opened by manifold vacuum, in
     *  mm2. 0: the throttle bores' combined area. */
    double superchargerBypassAreaMm2 { 0.0 };
    double compressorInducerDiameterMm { 0.0 };
    double turbineExducerDiameterMm { 0.0 };
    /** Vent-to-ambient compressor bypass. Zero area means absent. The valve
     * opens from upstream/downstream pressure ratio, never throttle gestures. */
    double blowOffValveFlowAreaMm2 { 0.0 };
    double blowOffValveOpeningPressureRatio { 1.12 };
    double blowOffValveDischargeCoefficient { 0.72 };
    /** Resolve a turbocharger's compressor duct and charge volume in time
     *  (Greitzer's surge model), so a throttle shut on boost with no blow-off
     *  valve surges: the charge blows back through the wheel in bursts, the
     *  "flutter". Off (the default): the boost follows the map at the flow
     *  the engine draws. */
    bool compressorSurge { false };
    /** The charge's volume between the compressor and the throttle (pipes,
     *  intercooler), in litres. 0: 1.5 x the engine's displacement. */
    double chargeVolumeLitres { 0.0 };
    /** Measurable/semi-empirical conversion parameters, not mix gains. */
    double tonalAcousticEfficiency { 1.0e-6 };
    double turbulentJetNoiseCoefficient { 1.0e-5 };
    /** Identical turbochargers, each one this unit: the design flow, areas,
     * inertia and bearing loss above are one turbocharger's. The exhaust
     * paths share them out (ExhaustPathConfig::turbocharger); their
     * compressors feed one charge. 1 to maximumTurbochargers. */
    std::uint32_t turbochargerCount { 1 };
    /** Corrected mass flow at the centre of the compressor map (peak
     * efficiency), one unit. Zero: 100 m/s through the inducer when its
     * diameter is authored, else the engine's air flow at 70 % of the redline
     * at the wastegate boost, shared by the units. */
    double compressorDesignMassFlowKgPerSecond { 0.0 };
    /** Charge-air cooler effectiveness: the share of the compressor's
     * temperature rise it removes (0 = none, 0.6-0.8 a road intercooler).
     * The catalogue engines have none authored: with a real one their
     * torque rises 19-29 % above their makers' figures (journal 2026-10-15). */
    double intercoolerEffectiveness { 0.0 };
    /** A turbocharger's top speed line, one unit, rpm: past it the wheel
     * loses its efficiency fast and is damaged, until it bursts. 0: 1.3 x
     * the design speed (turboMaximumShaftSpeedRpm). */
    double maximumShaftSpeedRpm { 0.0 };
};

/** A compressor map's top speed line over the centre of its map: a map's
 *  peak-efficiency island sits at 75-80 % of its highest speed line. The
 *  catalogue's turbochargers run at most 1.07 x their design speed at full
 *  load (journal 2026-11-11). */
inline constexpr double turboDefaultMaximumSpeedOverDesign = 1.3;

/** One turbocharger's top speed line, rpm: the authored one, else 1.3 x its
 *  design speed. */
[[nodiscard]] inline double turboMaximumShaftSpeedRpm(const ForcedInductionConfig& turbo) noexcept {
    return turbo.maximumShaftSpeedRpm > 0.0 ? turbo.maximumShaftSpeedRpm
        : turboDefaultMaximumSpeedOverDesign * turbo.designShaftSpeedRpm;
}

/** Engine temperatures; the realistic (unregulated) model is
 * EngineThermalModel. A zero capacity or conductance is sized from the
 * displacement and the estimated rated power. The heat shares are of the heat
 * released by combustion (Heywood: 17-26 % to the coolant at full load). */
struct ThermalConfig final {
    double coolantMassKjPerC { 0.0 };
    double oilMassKjPerC { 0.0 };
    double coolantHeatShare { 0.24 };
    double oilHeatShare { 0.05 };
    double coolingPowerKwPerC { 0.0 };
    double oilCoolingPowerKwPerC { 0.0 };
    // Filled positionally (makeDefaultRadialFive): add members below this line only.
    /** Regulated: coolant and oil are held at their operating temperatures
     * from the start, as a dyno cell's conditioning unit holds them, so runs
     * and A/B comparisons are made at one temperature. Otherwise they start
     * at the ambient temperature, warm up and cool by the model above. */
    bool regulated { true };
    double regulatedCoolantTemperatureC { 90.0 };
    double regulatedOilTemperatureC { 100.0 };
    /** A radiator behind a thermostat, with an electric fan; otherwise fins
     * in the air, the "coolant" temperature standing for the oil's, as an
     * air-cooled engine's gauge reads it. */
    bool liquidCooled { true };
    /** An air-cooled engine's blower, driven by the crank. */
    bool engineDrivenFan { false };
};

struct CombustionCalibrationConfig final {
    double baseIgnitionDelaySeconds { 0.00035 };
    double ignitionDelayTemperatureExponent { 1.10 };
    double ignitionDelayPressureExponent { 0.35 };
    double wallHeatTransferCoefficientWPerK { 0.42 };
    double residualDilutionSensitivity { 0.78 };
    /** Chamber-generated tumble/squish intensity relative to the legacy
     * mean-piston-speed closure. This belongs to the cylinder head, not to the
     * fuel chemistry: pent-roof/tumble ports and low-speed aircraft chambers
     * do not create the same u' at equal piston speed.
     */
    double chamberTurbulenceIntensityRatio { 1.0 };
    /** Independent flame kernels (normally spark plugs) per cylinder.
     *
     * Multiple kernels grow through disjoint chamber volume until their fronts
     * meet. This is physically distinct from increasing flame speed and is
     * important for large-bore dual-ignition aircraft engines.
     */
    std::uint32_t ignitionSiteCount { 1 };
    /** Multiplier on the pressure/temperature/cetane ignition-delay
     *  correlation used by the compression-ignition model.
     */
    double compressionIgnitionDelayScale { 1.0 };
    /** Mixing-controlled diffusion-burn time constant after autoignition. */
    double compressionIgnitionMixingTimeSeconds { 0.0014 };
    /** Fraction of fuel accumulated during ignition delay which burns in the
     *  initial premixed phase; the remainder is mixing controlled. Used only
     *  when `compressionIgnitionMixedPremix` is off.
     */
    double compressionIgnitionPremixedFraction { 0.20 };
    /** The premixed share is the fuel that has mixed by autoignition: from
     *  the start of injection the delay's fuel mixes at the diffusion burn's
     *  own rate, so a long delay (idle, cold, low cetane) premixes more and a
     *  long injection less, as Watson's correlation reads. Off, the fixed
     *  fraction above applies to the fuel present at ignition. */
    bool compressionIgnitionMixedPremix { true };
    /** Standard deviation of the physical burn-rate multiplier from one
     * cylinder cycle to the next. Zero is an exact deterministic bypass. */
    double cycleVariationCoefficientOfVariation { 0.0 };
    /** AR(1) correlation between consecutive combustion cycles. */
    double cycleVariationCorrelation { 0.45 };
};

/**
 * Intake-runner acoustics (see HelmholtzRunnerModel).
 *
 * `couplingGain` scales a forcing term -- `(plenum - runner)` -- that the 0-D
 * intake topology has already flattened to a few kPa, so it is an amplitude knob
 * and NOT a tuning parameter: raising it lifts the whole VE curve without moving
 * its peak, and on an engine whose low-speed torque is already at or above the
 * real one (the LS3: 596 Nm at 2000 rpm, real peak 575 at 4600) that is a
 * regression dressed as a calibration. Measured numbers in
 * HelmholtzRunnerModel's header and physics-audit.md (archive/docs-2026-09 tag). Leave it at 0.45
 * until the runner has a real inertance to force against.
 */
struct RunnerAcousticsConfig final {
    bool enabled { true };
    double dampingRatio { 0.16 };
    double couplingGain { 0.45 };
    double maximumPressureAmplitudeKpa { 35.0 };
};

/** One authored structural mode. Every amplitude-bearing field is an SI
 * physical/modal parameter; there is deliberately no arbitrary mix gain. */
struct StructuralModeConfig final {
    std::string name;
    StructuralModeDrive drive { StructuralModeDrive::headGas };
    double frequencyHz { 1'000.0 };
    double dampingRatio { 0.04 };
    double modalMassKg { 5.0 };
    double radiatingAreaM2 { 0.10 };
    double radiationEfficiency { 0.50 };
    double surfaceVelocityRmsScale { 0.50 };
    double torqueRadiusM { 0.05 };
    /** Signed, antinode-normalised modal participation, one value per
     * cylinder in EngineConfig::cylinders order. */
    std::vector<double> cylinderParticipation;
};

/** Optional measured or geometry-calculated replacement for the family
 * estimate used by StructuralModalRadiator. Empty modes select the documented
 * estimated-family fallback and may not claim measured provenance. */
struct StructuralNvhConfig final {
    StructuralNvhProvenance provenance {
        StructuralNvhProvenance::estimatedFamily
    };
    /** Measurement report, dataset, model revision or other auditable source. */
    std::string source;
    std::vector<StructuralModeConfig> modes;
};

enum class AudioSaturationPlacement : std::uint8_t {
    preShelf,
    postShelf
};

enum class AudioMonitorMode : std::uint8_t {
    /** SI source buses with neutral gains and no artistic saturation/EQ. */
    physicalReference,
    /** Optional listening/capture voicing authored in the voicing catalogue. */
    captureVoiced,
};

/** The intake layer's ceiling, above the other layers' 2: a stock airbox sits
 * 3-16 dB under the exhaust at part load (journal 2026-10-30), so a listener
 * who wants the induction roar needs up to ~13 dB over the default 0.85.
 */
inline constexpr double maximumIntakeGain = 4.0;

/** Non-physical monitor voicing, kept separate from engine and exhaust physics.
 *
 * These values shape only the listening chain. Defaults exactly match the
 * historical hard-coded realtime mix, so introducing a voicing catalogue does
 * not silently retune existing engines.
 */
struct AudioVoicingConfig final {
    double volume { 1.0 };
    double convolution { 0.45 };
    double highFrequencyGain { 1.0 };
    double lowFrequencyGain { 1.0 };
    double lowFrequencyNoise { 0.35 };
    double highFrequencyNoise { 0.35 };
    double combustionGain { 1.0 };
    double exhaustGain { 1.0 };
    double intakeGain { 0.85 };
    double mechanicalGain { 0.0 };
    double stereoWidth { 1.0 };
    double outletJetGain { 1.0 };
    double saturationDrive { 0.0 };
    AudioSaturationPlacement saturationPlacement {
        AudioSaturationPlacement::postShelf
    };
    AudioMonitorMode monitorMode { AudioMonitorMode::physicalReference };
};

/**
 * The piston-controlled ports and crankcase of a two-stroke cylinder
 * (EngineCycle::twoStroke). Port timings are crank degrees after top dead
 * centre at which the piston crown uncovers the port's top edge; each port
 * stays open for 360 - 2 x that, symmetric about bottom dead centre. A port's
 * open area is its total width (every window and bridge-free width summed)
 * times the height the piston has uncovered, times the discharge
 * coefficient.
 *
 * Each cylinder has its own crankcase. The engine's intake path for that
 * cylinder is the crankcase circuit: its plenum is the crankcase, pumped by
 * the underside of the piston (largest at top dead centre); its throttle
 * feeds it through a reed valve that only lets air in; its runner is the
 * transfer duct and its "intake valve" the transfer ports. The exhaust port
 * takes the exhaust valve's place on the exhaust network.
 */
/** Where a two-stroke's carburettor delivers. */
enum class TwoStrokeIntake : std::uint8_t {
    /** A reed block on the crankcase (Rotax, Aprilia, most scooters): the
     *  charge enters whenever the crankcase is below the carburettor,
     *  whatever the piston is doing. */
    crankcaseReed,
    /** A port in the cylinder wall that the piston skirt uncovers on its way
     *  up and covers again on its way down (piston port), with or without a
     *  reed in it (Yamaha's torque induction): the charge still reaches the
     *  crankcase, but only while the skirt leaves the port open. */
    cylinderPort,
};

struct TwoStrokeConfig final {
    TwoStrokeIntake intake { TwoStrokeIntake::crankcaseReed };
    /** A cylinder port's timing: crank degrees before top dead centre at
     *  which the skirt starts to uncover it. It is fully open at top dead
     *  centre and shut the same angle after it. */
    double intakePortOpenDegreesBtdc { 75.0 };
    /** A cylinder port's width; zero: 0.70 x bore. */
    double intakePortWidthMm { 0.0 };
    /** A reed in the cylinder port. Without one the port blows the charge
     *  back through the carburettor whenever the crankcase is above it. */
    bool intakePortReed { true };
    double exhaustPortOpenDegrees { 92.0 };
    double transferPortOpenDegrees { 118.0 };
    /** Zero: 0.65 x bore (one wide window). */
    double exhaustPortWidthMm { 0.0 };
    /** Zero: 1.30 x bore (the transfer windows together). */
    double transferPortWidthMm { 0.0 };
    double portDischargeCoefficient { 0.72 };
    /** Crankcase volume at top dead centre over that at bottom dead centre:
     *  1.25-1.5 on a road or race engine. */
    double crankcaseCompressionRatio { 1.35 };
    /** Length of the scavenging loop -- up the far wall, over the head and
     *  back down to the exhaust port -- as a multiple of the bore. A
     *  loop-scavenged cylinder runs about 1.8; a cross-scavenged one with a
     *  deflector piston is shorter, a long-stroke one longer.
     *
     *  Zero disables the displacement phase, leaving the perfectly mixed
     *  cylinder the simulator had before the model existed. See
     *  `TwoStrokeScavenging.hpp` for what the length buys. */
    double scavengeLoopLengthRatio { 1.8 };
    /** An exhaust power valve (Yamaha's YPVS and its kind): a blade or drum
     *  in the port's roof that lowers it at low speed, so the port opens later
     *  and the exhaust keeps more of the stroke, and lifts out of the way as
     *  the speed rises. The opening angle with the valve shut, later than
     *  `exhaustPortOpenDegrees`; zero is no valve. */
    double powerValveClosedExhaustPortOpenDegrees { 0.0 };
    /** The speeds where the servo starts to lift the valve and where it is
     *  fully open. */
    double powerValveOpeningStartRpm { 0.0 };
    double powerValveFullyOpenRpm { 0.0 };
};

/** A Wankel rotary's rotors. Each rotor's three faces are three chambers,
 *  which the simulator runs as three cylinders (faces 1-3 on the first rotor,
 *  4-6 on the second...), each crossing its own four strokes over three turns
 *  of the eccentric shaft. A face's volume is exactly
 *  V = Vmin + Vd/2 (1 - cos(2a/3)), a the shaft angle from the face's firing
 *  top dead centre and Vd = 3 sqrt(3) R e b; its ports are the faces'
 *  intake and exhaust "valves" (`camshafts`, in shaft degrees), shared by the
 *  rotor's three faces. */
struct RotaryConfig final {
    /** R: the rotor's centre to an apex. */
    double generatingRadiusMm { 105.0 };
    /** e: the eccentric shaft's throw. */
    double eccentricityMm { 15.0 };
    /** b: the rotor's width between the side housings. */
    double rotorWidthMm { 80.0 };
    std::uint32_t rotorCount { 2 };
};

/** Crank degrees of one thermodynamic cycle: 720 for a four-stroke, 360 for
 *  a two-stroke, 1,080 of the eccentric shaft for a rotary's face. */
[[nodiscard]] inline double cycleDegreesOf(EngineCycle cycle) noexcept {
    return cycle == EngineCycle::twoStroke ? 360.0 : cycle == EngineCycle::rotary ? 1'080.0 : 720.0;
}
/** One stroke: a quarter of a four-stroke's or a rotary's cycle, half a
 *  two-stroke's. */
[[nodiscard]] inline double strokeDegreesOf(EngineCycle cycle) noexcept {
    return cycle == EngineCycle::twoStroke ? 180.0 : cycleDegreesOf(cycle) * 0.25;
}
/** The stroke a phase over the cycle (from firing top dead centre) falls in:
 *  0 power, 1 exhaust, 2 intake, 3 compression; a two-stroke has power, then
 *  compression. A rotary's face takes 270 deg a stroke: counted in 180s, its
 *  1,080 deg ran to a sixth stroke and the cycle panel read past its names. */
[[nodiscard]] inline std::size_t strokeIndexOf(EngineCycle cycle, double phaseDegrees) noexcept {
    const auto stroke = phaseDegrees > 0.0
        ? static_cast<std::size_t>(std::fmin(phaseDegrees / strokeDegreesOf(cycle), 3.0)) : std::size_t { 0 };
    if (cycle == EngineCycle::twoStroke) return stroke == 0U ? 0U : 3U;
    return stroke;
}
/** The crank angle's domain: the cycle, or 720 for a two-stroke (whose
 *  cylinders run two cycles inside it). */
[[nodiscard]] inline double crankDomainDegreesOf(EngineCycle cycle) noexcept {
    return cycle == EngineCycle::rotary ? 1'080.0 : 720.0;
}
/** A rotary face's swept volume, 3 sqrt(3) R e b, litres. */
[[nodiscard]] double rotaryFaceDisplacementLitres(const RotaryConfig&) noexcept;
struct EngineConfig;
/** Gives every face of a rotary its rotor's equivalent bore and stroke
 *  (rotaryEquivalentBoreMm, rotaryEquivalentStrokeMm), the values
 *  validateEngineConfig asks of it. */
void applyRotaryFaceGeometry(EngineConfig& config) noexcept;
/** The bore a face runs with: twice the path each of its two flames covers,
 *  a third of the chamber's sqrt(3) R length (2 R / sqrt(3)). The stroke
 *  follows from the face's displacement over that bore's area. */
[[nodiscard]] double rotaryEquivalentBoreMm(const RotaryConfig&) noexcept;
[[nodiscard]] double rotaryEquivalentStrokeMm(const RotaryConfig&) noexcept;
/** The chamber's wetted surface at `volumeLitres`: the rotor's flank and the
 *  housing's arc (each about sqrt(3) R long, b wide) and the two side
 *  housings (V / b each): 0.031 m2 for a 13B face at top dead centre, where
 *  a piston of its equivalent bore wets 0.023 m2. */
[[nodiscard]] double rotaryChamberSurfaceM2(const RotaryConfig&, double volumeLitres) noexcept;
/** The mean speed of an apex along the housing, omega R / 3: the gas speed
 *  scale of Woschni's law in a rotary (the rotor tip speed). */
[[nodiscard]] double rotaryApexSpeedMps(const RotaryConfig&, double shaftRadPerSecond) noexcept;

/** A compression-release engine brake (a "jake brake"): with the driver's
 *  switch on, the pedal released and the clutch in, each braking cylinder's
 *  fuel is cut and a small extra lift opens one exhaust valve near the top of
 *  its compression stroke. The air the piston compressed blows down into the
 *  exhaust instead of pushing the piston back down, so the compression work
 *  is not returned: the shaft is braked. Four-strokes only; the designer fits
 *  it to a truck. */
struct EngineBrakeConfig final {
    bool fitted { false };
    /** The brake event's peak lift on the one valve it opens, mm: about
     *  1-2 mm on production brakes. */
    double valveLiftMm { 2.0 };
    /** Where the event peaks, crank degrees after firing top dead centre
     *  (negative: before), and its whole duration. */
    double peakAfterTdcDegrees { 0.0 };
    double durationDegrees { 80.0 };
    /** Below this speed the brake lets go: a brake cutting fuel near idle
     *  would stall the engine. */
    double minimumRpm { 1'000.0 };
    /** The driver's switch has this many stages; stage k of N brakes
     *  round(k x cylinders / N) cylinders. */
    std::uint32_t stageCount { 3 };
};

/** The extra exhaust-valve lift the engine brake adds at `phaseDegrees` of a
 *  cylinder's 720 deg cycle (0 at firing top dead centre): a cosine-squared
 *  bump. It is taken over the valve count so that the curtain area equals one
 *  valve's at the brake's lift. */
[[nodiscard]] double engineBrakeLiftMm(const EngineBrakeConfig&, double phaseDegrees,
                                       std::uint32_t exhaustValveCount) noexcept;

struct EngineConfig final {
    std::uint32_t schemaVersion { currentEngineSchemaVersion };
    std::string name { "Untitled engine" };
    EngineCycle cycle { EngineCycle::fourStroke };
    FuelType fuel { FuelType::gasoline };
    FuelConfig fuelProperties;
    EngineLayout layout { EngineLayout::inlineLayout };
    std::vector<CylinderConfig> cylinders;
    std::vector<std::uint32_t> firingOrder;
    std::vector<CrankJournalConfig> crankJournals;
    std::vector<CrankshaftConfig> crankshafts;
    double idleRpm { 850.0 };
    double redlineRpm { 7'200.0 };
    double rotatingInertiaKgM2 { 0.24 };
    double frictionCoefficient { 0.12 };
    double octaneRating { 98.0 };
    double ambientPressureKpa { 101.325 };
    double ambientTemperatureC { 22.0 };
    double coolingEfficiency { 1.0 };
    double plenumVolumeLitres { 3.0 };
    double throttleDiameterMm { 60.0 };
    double bankAngleDegrees { 0.0 };
    /** Structural limit of the peak firing pressure, bar absolute: above it
     * the head gasket, ring lands and bearings are overloaded and the engine
     * accumulates damage. Zero: a typical limit for the fuel and induction
     * (see peakCylinderPressureLimitBar()). */
    double peakFiringPressureLimitBar { 0.0 };
    IntakeConfig intake;
    std::vector<IntakePathConfig> intakePaths;
    std::vector<CylinderBankConfig> banks;
    std::vector<ExhaustPathConfig> exhaustPaths;
    AcousticObserverConfig acousticObserver;
    IgnitionConfig ignition;
    InjectionConfig injection;
    SolverConfig solver;
    ForcedInductionConfig forcedInduction;
    ThermalConfig thermal;
    CombustionCalibrationConfig combustionCalibration;
    RunnerAcousticsConfig runnerAcoustics;
    StructuralNvhConfig structuralNvh;
    CamshaftConfig camshafts;
    ExhaustConfig exhaust;
    ExhaustAfterfireConfig exhaustAfterfire;
    ExhaustValveConfig exhaustValve;
    /** A nitrous kit; not fitted by default. */
    NitrousConfig nitrous;
    TransmissionConfig transmission;
    VehicleConfig vehicle;
    EngineBrakeConfig engineBrake;
    /** Resolved default -> family -> engine voicing. Runtime-only: the engine
     * serializers remain physics/configuration documents, while the catalogue
     * YAML files in voicing/ own listening-chain choices. */
    AudioVoicingConfig audioVoicing;
    std::string audioVoicingFamily;
    std::string audioVoicingKey;
    /** Read only when `cycle` is EngineCycle::twoStroke. */
    TwoStrokeConfig twoStroke;
    /** Read only when `cycle` is EngineCycle::rotary. */
    RotaryConfig rotary;
};

struct EngineControls final {
    bool ignitionEnabled { false };
    bool starterEngaged { false };
    double throttle { 0.0 };
    // Legacy normalized absorber command retained for existing integrations.
    // New dynamometer code should command a calibrated reaction torque below.
    double load { 0.0 };
    double externalTorqueNm { 0.0 };
    double brake { 0.0 };
    double dynamometerTorqueNm { 0.0 };
    /** Rotating inertia reflected through a sticking clutch. The driveline
     * supplies this with its equivalent external torque so chamber ripple is
     * integrated against the coupled shaft instead of a one-frame-delayed
     * clutch reaction. Zero preserves standalone/dyno behaviour. */
    double externalRotatingInertiaKgM2 { 0.0 };
    /** Air speed at the radiator or the fins, from the vehicle's speed or a
     * dyno cell fan; it cools an engine whose temperatures are not
     * regulated. */
    double coolingAirSpeedMps { 0.0 };
    /** A quickshifter's ignition cut: the ECU cuts as its rev limiter does
     * (spark, and fuel too unless `ignition.limiter_keeps_fuel`). */
    bool shiftIgnitionCut { false };
    /** A dual clutch's upshift torque intervention: spark retard, degrees,
     * taken off the mapped advance (within the ECU's advance limits). */
    double shiftSparkRetardDegrees { 0.0 };
    /** Its injection cut: the share of firings, 0-1, whose fuel the ECU
     * suppresses (the spark still fires, on air). */
    double shiftCylinderCutFraction { 0.0 };
    /** The gear the driveline has engaged (-1: none, as on the dyno) and the
     * road speed, m/s, as the ECU's wheel-speed and gear inputs: its launch
     * control reads them. The simulator's own state had neither, so launch
     * control never armed in the application (owner report 2026-10-30). */
    int engagedGear { -1 };
    double vehicleSpeedMps { 0.0 };
    /** Neutral, or the clutch out (a vehicle only; false on the dyno). */
    bool drivelineDecoupled { false };
    /** The engine brake's switch: 0 off, up to `engineBrake.stageCount`.
     * The runtime passes 0 while the clutch is out or a shift is under way. */
    std::uint32_t engineBrakeStage { 0 };
    /** The active exhaust valves' switch; nothing without one. */
    ExhaustValveMode exhaustValveMode { ExhaustValveMode::automatic };
    /** The nitrous kit's arming switch and push button; nothing without a
     *  kit. */
    bool nitrousArmed { false };
    bool nitrousButton { false };
    /** Counts bottle refills: each new value fills the bottle. */
    std::uint32_t nitrousRefills { 0 };
};

struct CylinderState final {
    std::uint32_t id { 0 };
    double cyclePhaseDegrees { 0.0 };
    double pressureEstimateBar { 0.0 };
    double combustionPulse { 0.0 };
    double misfireProbability { 0.0 };
    double intakeValveLiftMm { 0.0 };
    double exhaustValveLiftMm { 0.0 };
    double intakeFlowMgPerCycle { 0.0 };
    double exhaustFlowMgPerCycle { 0.0 };
    double runnerPressureKpa { 101.325 };
    double exhaustTemperatureC { 22.0 };
    double gasTemperatureC { 22.0 };
    double trappedMassMg { 0.0 };
    double oxygenMoles { 0.0 };
    double fuelMoles { 0.0 };
    double burnedMoles { 0.0 };
    double intakeVelocityMps { 0.0 };
    double exhaustVelocityMps { 0.0 };
    double fuelDeliveryRatio { 0.0 };
    /** Fraction of the authored injection window still unused (1 = closed,
     *  0 = open for the entire window). This is actuator headroom, independent
     *  of closed-loop trim and runner fuel transport. */
    double injectorCapacityRatio { 1.0 };
    double flameSpeedMps { 0.0 };
    double burnedFraction { 0.0 };
    double combustionEfficiency { 0.0 };
    double endGasKnockLevel { 0.0 };
    bool combustionActive { false };
    bool misfiring { false };
    // NOTE: `misfiring` is the last member reached by the positional aggregate
    // initialiser in EngineSimulator::publishCylinderStates. Add new members
    // BELOW this line and assign them by name, or every field after the
    // insertion point silently receives the wrong value.
    /** Instantaneous compact-valve conductance Cd*A used by the gas solver. */
    double exhaustValveConductanceAreaM2 { 0.0 };
    /** Signed instantaneous flow; positive from chamber into exhaust runner. */
    double exhaustMassFlowKgPerSecond { 0.0 };
    /** Oxygen-equivalent fresh air latched when this cylinder's intake valve
     * closed, on the same basis as EngineState::airMassMgPerCycle.
     */
    double trappedFreshAirMassMg { 0.0 };
    /** Net oxygen-equivalent fresh air delivered through this intake valve
     * during the most recently completed 720-degree cycle.
     */
    double deliveredFreshAirMassMgPerCycle { 0.0 };
    /**
     * Burned mole fraction in the chamber at the instant of ignition -- i.e. the
     * residual the gas exchange failed to expel, since nothing has burned yet.
     *
     * The flame model has always consumed this (it sets both the ignition-delay
     * residual penalty and the dilution factor of `combustionEfficiency`), but
     * it was only ever passed positionally into `FlameConditions` and never
     * published, so a residual failure could only be seen through its downstream
     * symptom: efficiency collapsing with no visible cause.
     *
     * Literature (Heywood ch. 6.4): 3-7 % at wide-open throttle, rising towards
     * 20 % at idle where the pressure ratio across the overlap is adverse. A WOT
     * figure above ~0.15 is a gas-exchange failure, not a calibration choice.
     *
     * Declared further down, next to the other named-assignment members.
     */
    double pistonTravelMm { 0.0 };
    double pistonPositionMm { 0.0 };
    double pistonVelocityMps { 0.0 };
    double pistonAccelerationMps2 { 0.0 };
    double connectingRodAngleDegrees { 0.0 };
    double crankPinXMm { 0.0 };
    double crankPinYMm { 0.0 };
    double wristPinXMm { 0.0 };
    double wristPinYMm { 0.0 };
    double mechanicalReactionTorqueNm { 0.0 };
    std::uint32_t crankshaftId { 1 };
    std::uint32_t crankJournalId { 0 };
    double indicatedWorkJoulesPerCycle { 0.0 };
    /**
     * INSTANTANEOUS burned mole fraction, despite the name. Immediately after
     * combustion it is ~1.0, so a cycle average of it is not a residual figure
     * and cannot show a gas-exchange failure. Kept with this meaning because the
     * comparison harness's stall diagnostic and the perf harness CSV both read
     * it that way. For the residual, use `residualGasFractionAtSpark` below.
     */
    double residualGasFraction { 0.0 };
    /**
     * Burned mole fraction sampled at the instant of ignition -- i.e. the
     * residual the gas exchange failed to expel, since nothing has burned yet.
     *
     * The flame model has always consumed this quantity: it sets the
     * ignition-delay residual penalty and the dilution factor of
     * `combustionEfficiency`. But it was only ever passed positionally into
     * `FlameConditions` and never published, so a residual failure could only be
     * seen through its downstream symptom -- efficiency collapsing with no
     * visible cause -- while the field named `residualGasFraction` reported
     * something else entirely.
     *
     * IT IS NOT A RESIDUAL GAS FRACTION, and must not be compared with one
     * directly. The mixture model carries four species -- oxygen, inert, fuel,
     * burned -- and the nitrogen that arrives with the air stays in `inert`
     * forever. So `burned / total` counts the combustion PRODUCTS alone, while
     * Heywood's residual gas fraction counts the whole trapped exhaust,
     * nitrogen included.
     *
     * The conversion is fixed by the fuel chemistry. With the default pump
     * gasoline (`oxygenMolesPerFuelMole` 12.5, `productMolesPerFuelMole` 17.0,
     * i.e. C8H18 + 12.5 O2 -> 8 CO2 + 9 H2O), stoichiometric exhaust is 17
     * product moles against 17 + 12.5 * 3.7619 = 64.0 total, so
     *
     *     residualGasFractionAtSpark ~= 0.266 * (residual gas fraction)
     *
     * Literature (Heywood ch. 6.4) puts the residual gas fraction at 3-7 % at
     * wide-open throttle and near 20 % at idle, where the pressure ratio across
     * the overlap is adverse. Expressed in THIS quantity that is **0.008-0.019
     * at WOT and about 0.053 at idle**, and the gas-exchange failure threshold
     * that used to read 0.15 here is about **0.04**.
     *
     * Reading the raw number against Heywood's percentages is a factor of 3.8,
     * and it produced a false alarm that reached three documents: 0.004-0.026
     * was reported as "an order of magnitude below what a production SI engine
     * traps". Measured on the shipped catalogue after both errors were
     * corrected -- the other being that the low figures came from a speed-held
     * 10 % throttle point rather than a free idle -- a `--trace 1 --idle` run
     * reads 0.063-0.142 (24-53 % residual) and a WOT hold reads 0.014-0.016 on
     * the naturally aspirated engines, i.e. 5.3-6.0 %, inside Heywood's band.
     */
    double residualGasFractionAtSpark { 0.0 };
    /**
     * Heywood's burned-gas fraction when the spark was commanded, misfire or
     * not: the share of the charge that is neither fresh air (oxygen with its
     * nitrogen) nor fuel, so a combustion product's nitrogen counts as
     * diluent. About 3.8 x `residualGasFractionAtSpark` for a stoichiometric
     * residual, read directly here. Zero before the first spark.
     */
    double diluentFractionAtSpark { 0.0 };
    /**
     * Equivalence ratio in the chamber at the instant of ignition -- the mixture
     * the flame model actually evaluated, which is what sets the mixture factor
     * of `combustionEfficiency`. Distinct from `airFuelRatio`, a completed-cycle
     * figure: a fixed crank-angle injection window occupies more crank degrees
     * as speed rises, so at high rpm the charge can still be arriving when the
     * spark fires and the flame sees a leaner mixture than the cycle reports.
     */
    double equivalenceRatioAtSpark { 0.0 };
    double airFuelRatio { 14.7 };
    double requestedFuelMgPerCycle { 0.0 };
    double deliveredFuelMgPerCycle { 0.0 };
    double closedLoopFuelTrim { 1.0 };
    double intakeValveAdvanceDegrees { 0.0 };
    double exhaustValveAdvanceDegrees { 0.0 };
    double valveLiftMultiplier { 1.0 };
    double intakeResonancePressureKpa { 0.0 };
    double intakeResonanceFrequencyHz { 0.0 };
    /** Stagnation head of the arriving intake runner column, rho*u^2/2, in kPa.
     *
     * The charging pressure a column moving at `intakePortColumnVelocityMps` would
     * present at the valve, over and above the port's static pressure. DIAGNOSTIC
     * ONLY -- nothing reads it for flow. It peaks at full lift and is ~3 % of peak
     * by the time the valve seats, which is why biasing the fill with it loses
     * charge instead of trapping it; see the intake-valve comment in
     * EngineSimulator.cpp and physics-audit.md (archive/docs-2026-09 tag). Published because it is the
     * quantity to watch when evaluating any future ram mechanism. */
    double intakePortRamPressureKpa { 0.0 };
    /** Runner column velocity at the valve plane, u = mdot_valve/(rho*A_runner).
     *
     * Referred to the runner cross-section, so it is the speed of the gas column
     * whose momentum `intakePortRamPressureKpa` differentiates. Distinct from
     * `intakeVelocityMps` (the valve-throat speed) and from the runner cell's own
     * bulk velocity, which does not collapse at IVC. */
    double intakePortColumnVelocityMps { 0.0 };
    /** Charge state in this cylinder's own intake runner, at the valve.
     *
     * What an IAT sensor in the port would read, and the direct determinant of
     * charge density and therefore of volumetric efficiency. Reported per
     * cylinder rather than per plenum because reversion through the intake
     * valve heats one runner at a time. */
    double intakeRunnerTemperatureC { 22.0 };
    double intakeRunnerChargePressureKpa { 101.325 };
    /** True when heat release is governed by compression ignition instead of
     *  a spark-initiated flame front.
     */
    bool compressionIgnition { false };
    /** Resolved start of combustion in cylinder-cycle coordinates, where
     *  firing TDC is zero. Negative means before firing TDC.
     */
    double combustionStartPhaseDegrees { 0.0 };
    double combustionDurationMs { 0.0 };
    /** Normalised initial pressure-rise propensity, used by diagnostics and
     *  the physically distinct diesel combustion-noise renderer.
     */
    double combustionSharpness { 0.0 };
    double directLiquidSprayFuelMg { 0.0 };
    double directDispersingFuelMg { 0.0 };
    /** Current per-cylinder physical burn-rate multiplier. Unlike the legacy
     * event-generator jitter, this acts before pressure and heat release. */
    double combustionCycleMultiplier { 1.0 };
    /** Diagnostic event accounting for the most recently completed cylinder
     * cycle. A commanded spark which never becomes an ignition distinguishes
     * phasing/delay failures from fuelling and probabilistic misfire. */
    std::uint32_t commandedSparkEventsLastCycle { 0 };
    std::uint32_t completedIgnitionEventsLastCycle { 0 };
    double commandedSparkPhaseLastCycle { -1.0 };
    double completedIgnitionPhaseLastCycle { -1.0 };
    /** True only after this cylinder has produced a fuelled charge observation
     * in the current observation epoch. Fuel cut and spark cut invalidate the
     * epoch; the numeric AFR is then retained only as last-known telemetry. */
    bool airFuelRatioValid { false };
    /** Injector open time divided by the complete 720-degree cycle. */
    double injectorDutyCycle { 0.0 };
    /** Liquid fuel metered by this injector during its most recently completed
     *  cycle, before port-film or spray transport. */
    double meteredFuelMgPerCycle { 0.0 };
    /** Fuel vapour currently resident in this cylinder's resolved intake
     *  runner. Useful for distinguishing metering from transport starvation. */
    double portFuelVapourInventoryMg { 0.0 };
    /** Liquid fuel currently resident in this cylinder's port wall film. */
    double portLiquidFilmFuelMg { 0.0 };
    /** Vapour inventory inside the finite-volume cells actually touched by the
     *  port injector source. This is the locally reachable subset of the whole
     *  runner inventory above. */
    double portInjectorFootprintFuelMg { 0.0 };
    /** Oxygen-derived vapour inventory which would put that numerical injector
     *  footprint at the current commanded AFR. */
    double portInjectorFootprintTargetFuelMg { 0.0 };
    /** False when an otherwise enabled spark is intentionally not a combustion
     *  command, for example while DFCO resume waits for a complete port-injector
     *  window. Event/audio consumers must not label that clean cut a misfire. */
    bool combustionCommandAvailable { true };
    /** The end gas: the hottest the unburned charge got in the last completed
     *  cycle, compressed from the moment the cylinder sealed (EndGasKnockModel),
     *  and the pressure the last knock event's end gas released. Spark ignition
     *  only; zero on a diesel. */
    double endGasPeakTemperatureK { 0.0 };
    double knockPressureRiseBar { 0.0 };
};

enum class DynoMode : std::uint8_t {
    steppedCalibration,
    continuousRamp,
    hold
};

enum class DynoRunStatus : std::uint8_t {
    idle,
    running,
    completed,
    cancelled,
    timedOut,
    invalid
};

enum class DynoPhase : std::uint8_t {
    idle,
    preparing,
    acquiring,
    recovery,
    terminal
};

enum class DynoStopReason : std::uint8_t {
    none,
    sweepCeilingReached,
    operatorFinished,
    operatorCancelled,
    startupTimeout,
    acquisitionTimeout,
    runtimeStopped,
    engineReconfigured,
    insufficientValidData,
    controllerFailure
};

struct DynoSessionConfig final {
    DynoMode mode { DynoMode::continuousRamp };
    /** Zero means derive the safe endpoint from the engine configuration. */
    double sweepEntryRpm { 0.0 };
    double sweepCeilingRpm { 0.0 };
    double holdRpm { 2'500.0 };
    double rampRateRpmPerSecond { 500.0 };
    double binWidthRpm { 50.0 };
    double rollingWindowSeconds { 0.25 };
    double maximumDurationSeconds { 60.0 };
};

struct EngineState final {
    double simulationTimeSeconds { 0.0 };
    double rpm { 0.0 };
    double crankAngleDegrees { 719.9 };
    double throttle { 0.0 };
    double load { 0.0 };
    double angularVelocityRadPerSecond { 0.0 };
    double indicatedTorqueNm { 0.0 };
    double meanWorkTorqueNm { 0.0 };
    double cylinderPressureTorqueNm { 0.0 };
    double cylinderPressureTorqueBlend { 0.0 };
    double frictionTorqueNm { 0.0 };
    double frictionMeanEffectivePressureBar { 0.0 };
    double reciprocatingTorqueNm { 0.0 };
    double meanPistonSpeedMps { 0.0 };
    double loadTorqueNm { 0.0 };
    double starterTorqueNm { 0.0 };
    double netTorqueNm { 0.0 };
    double torqueNm { 0.0 };
    double cycleAveragedTorqueNm { 0.0 };
    double coolantTemperatureC { 22.0 };
    double oilTemperatureC { 22.0 };
    /** The cylinders' mean exhaust temperature (5.6 s time constant). */
    double exhaustTemperatureC { 22.0 };
    /** An EGT probe at the turbine inlet: the gas in the element before each
     *  turbine face, by its cylinders' share, read with a 3 mm probe's
     *  ~0.5 s lag. What anti-lag's exhaust limit reads: with its sparks cut,
     *  the cylinders send cool unlit charges that burn in the manifold. The
     *  cylinders' mean without a turbine face in the gas network. */
    double turbineInletTemperatureC { 22.0 };
    double knockLevel { 0.0 };
    double misfireRate { 0.0 };
    /** Monotonic physical event counters. `misfireRate` is deliberately
     * smoothed for display and can retain history across a control edge; these
     * counters let validation distinguish that decay from a new failed spark. */
    std::uint64_t commandedSparkEventCount { 0 };
    std::uint64_t misfireEventCount { 0 };
    double lastMisfireAirFuelRatio { 0.0 };
    double lastMisfireTimeSeconds { 0.0 };
    double airFuelRatio { 14.7 };
    double targetAirFuelRatio { 14.7 };
    double ignitionAdvanceDegrees { 0.0 };
    double manifoldPressureKpa { 28.0 };
    double boostPressureRatio { 1.0 };
    /**
     * NOT back pressure. This is the `max` over cylinder ports of the
     * INSTANTANEOUS exhaust-runner pressure -- a blowdown peak envelope. It
     * reads like a mean and is not one: on a healthy V8 at 5,940 rpm it sits at
     * 172 kPa while the gas is discharging freely. Audio and telemetry want the
     * peak, so it stays; any back-pressure, pumping or restriction argument
     * built on it is void. Use `exhaustBackPressureKpa` for that.
     */
    double exhaustPressureKpa { 101.325 };
    /**
     * Cycle-mean exhaust back pressure: the port pressures averaged over the
     * cylinders and then damped over several firing periods, which is what a
     * real back-pressure gauge on a manifold boss reads. This is the quantity a
     * restriction warning must be built on.
     */
    double exhaustBackPressureKpa { 101.325 };
    double intakeRunnerPressureKpa { 101.325 };
    double exhaustRunnerPressureKpa { 101.325 };
    /** Static pressure the turbine expands INTO, absolute. Ambient plus the
     *  quasi-steady loss the downstream system needs to pass the current flow.
     *  A turbo's shaft power is set by inlet/outlet, so this is the channel
     *  through which downpipe and silencer geometry reach the boost. */
    double turbineOutletPressureKpa { 101.325 };
    double exhaustFlowGramsPerSecond { 0.0 };
    /** Real chemical heat release occurring in the physical exhaust network. */
    double exhaustAfterfireHeatReleaseKw { 0.0 };
    double exhaustAfterfireFuelBurnMgPerSecond { 0.0 };
    /** The exhaust's fuel balance, mg/s, smoothed as the line above: the
     *  unburnt fuel the cylinders send into it, the part of the burn above
     *  that happens before a turbine, and the unburnt fuel leaving the
     *  tailpipe. Bookkeeping only. */
    double exhaustFuelInMgPerSecond { 0.0 };
    double exhaustFuelBurnBeforeTurbineMgPerSecond { 0.0 };
    double tailpipeFuelMgPerSecond { 0.0 };
    /** Cylinders the engine brake holds this step (fuel cut, brake valve
     * event on): zero when it is off or released. */
    std::uint32_t engineBrakeCylinders { 0 };
    /** ECU currently meters the authored partial fuel charge with spark cut. */
    bool exhaustAfterfireOverrunActive { false };
    /** Bitmask of `AfterfireBlocker` explaining the line above when it is
     * false. Zero while the overrun afterfire is metering. */
    std::uint32_t exhaustAfterfireBlockers {
        static_cast<std::uint32_t>(AfterfireBlocker::notAuthored) };
    /** Share of reacting exhaust control volumes whose bulk gas was BELOW the
     * ignition threshold and which lit on the pipe wall instead. It exists to
     * keep the hot-surface path non-vacuous: a fully heat-soaked exhaust warms
     * its own gas past the threshold, so this reads near zero there and the
     * reading only rises in the partly-warm regime the path was added for. */
    double exhaustAfterfireWallIgnitedFraction { 0.0 };
    /** Largest local Livengood-Wu induction integral in the active exhaust
     * chemistry pass. One establishes a flame kernel. */
    double exhaustAfterfireInductionProgress { 0.0 };
    /** Smallest finite local induction delay evaluated in the active chemistry
     * pass, milliseconds. Zero means that no site was induction-eligible. */
    double exhaustAfterfireMinimumInductionDelayMs { 0.0 };
    /** Largest finite local induction delay evaluated in the active chemistry
     * pass, milliseconds. Zero means that no site was induction-eligible. */
    double exhaustAfterfireMaximumInductionDelayMs { 0.0 };
    /** Hottest exhaust pipe wall, which is what ignites an overrun mixture --
     * the gas is cold during overrun by construction. It lags the gas by tens
     * of seconds (1.5 mm steel), so a just-started engine cannot pop and this
     * is the reading that says whether it is warm enough yet. */
    double exhaustWallTemperatureC { 22.0 };
    double manifoldGasMassGrams { 0.0 };
    double cylinderGasMassGrams { 0.0 };
    double gasInternalEnergyJoules { 0.0 };
    /** Actual accepted mechanical steps / caller-frame duration. Adaptive
     * durations can differ within that frame; each pressure sample carries its
     * own reciprocal duration. This is not a requested nominal frequency. */
    double solverFrequencyHz { 0.0 };
    double crankDegreesPerSolverStep { 0.0 };
    std::uint32_t solverSubsteps { 0 };
    bool solverResolutionLimited { false };
    /** CFL substeps the exhaust network accepted internally over the last frame.
     *
     * The network resolves the acoustic field at this cadence, which is far
     * above the multirate coupling cadence that the audio boundary is sampled
     * at. Published so the ratio between the two is observable: bandwidth the
     * solver has already paid for but that nothing downstream reads is invisible
     * from any other measurement.
     */
    std::uint64_t exhaustNetworkAcceptedSubsteps { 0 };
    /** Rate over advanced simulation time, Hz. Compare against the coupling
     * cadence to see how much resolved bandwidth reaches the audio path.
     */
    double exhaustNetworkSubstepFrequencyHz { 0.0 };
    /** Cadence at which the audio boundary is actually sampled, Hz. Content
     * above half this frequency cannot be physical.
     */
    double exhaustCouplingFrequencyHz { 0.0 };
    /** Actual intake advances in the last frame, summed across runner networks.
     * Rates use advanced simulation time, rather than the requested cadence. */
    std::uint64_t intakeNetworkAcceptedSubsteps { 0 };
    std::uint64_t intakeNetworkRejectedSubsteps { 0 };
    double intakeNetworkAdvancedSeconds { 0.0 };
    std::uint32_t intakeCouplingFlushCount { 0 };
    /** Scheduled coupling duration, including the sealed-valve rest path.
     * Actual FV integration time is intakeNetworkAdvancedSeconds. */
    double intakeCouplingAdvancedSeconds { 0.0 };
    double intakeCouplingMinimumIntervalSeconds { 0.0 };
    double intakeCouplingMaximumIntervalSeconds { 0.0 };
    std::uint32_t intakeCylinderTransferFailures { 0 };
    std::uint32_t intakePlenumTransferFailures { 0 };
    /** Last-frame maxima over accepted gas steps. Stable-step ratio includes
     * every coded source/boundary cap; duct Courant uses actual cell length
     * and cached signal speeds, separately at current and predictor states. */
    double intakeNetworkMaximumAcceptedStepRatio { 0.0 };
    double intakeNetworkMaximumCourantCurrent { 0.0 };
    double intakeNetworkMaximumCourantPredictor { 0.0 };
    double exhaustNetworkMaximumAcceptedStepRatio { 0.0 };
    double exhaustNetworkMaximumCourantCurrent { 0.0 };
    double exhaustNetworkMaximumCourantPredictor { 0.0 };
    double volumetricEfficiency { 0.0 };
    double airMassMgPerCycle { 0.0 };
    /**
     * Charge mass that actually crossed the intake valves last cycle.
     *
     * Distinct from `airMassMgPerCycle`, which is the oxygen-equivalent air
     * TRAPPED in the chambers -- the right quantity to meter fuel against,
     * because it is what can burn, but not a measure of breathing: a chamber
     * holding unburned oxygen (a misfire, a motored cylinder, or a cam with no
     * lift at all) reports a full charge it never inducted. Measured on a
     * zero-lift engine that the starter can now turn: `volumetricEfficiency`
     * reads 1.031 while nothing whatsoever passes the valve. Induction is the
     * quantity that is genuinely zero there.
     *
     * Note this is total charge mass, not air alone -- with port injection it
     * carries the fuel vapour picked up in the runner -- so it is NOT a drop-in
     * numerator for volumetric efficiency. See physics-audit.md (archive/docs-2026-09 tag).
     */
    double inductedChargeMassMgPerCycle { 0.0 };
    /**
     * Fresh air DELIVERED past the intake valves last cycle, and the volumetric
     * efficiency built on it.
     *
     * `volumetricEfficiency` above is a *trapping* figure: oxygen-equivalent air
     * still in the chamber at IVC. Heywood's definition (ch. 2.10) is the mass
     * of fresh air *inducted* per cycle over the ambient-density displacement --
     * a delivery figure, and the one a dyno's air meter reads. The two differ by
     * exactly the fresh charge that entered and was then pushed back out before
     * the valve shut, so
     *
     *     trapping efficiency = volumetricEfficiency / deliveredVolumetricEfficiency
     *
     * and a ratio below 1 is charge the engine paid to accelerate and did not
     * keep. That is not a bookkeeping curiosity: it is the direct per-cylinder
     * read-out of the overlap backflow that the pumping loop
     * (`pumpingMeanEffectivePressureBar`) shows in aggregate.
     *
     * Both are oxygen-derived, so both are fresh air on the same basis and their
     * ratio is meaningful. Do NOT use `inductedChargeMassMgPerCycle` as the
     * numerator instead -- it is total charge and carries port fuel vapour.
     *
     * A reverting cylinder can drive the net delivery negative over a cycle; the
     * figure is published signed for that reason, and only the VE built on it is
     * clamped non-negative.
     */
    double deliveredAirMassMgPerCycle { 0.0 };
    double deliveredVolumetricEfficiency { 0.0 };
    double injectedFuelMgPerCycle { 0.0 };
    double deliveredFuelMgPerCycle { 0.0 };
    double fuelFlowGramsPerSecond { 0.0 };
    double fuelConsumedGrams { 0.0 };
    double fuelConsumedLitres { 0.0 };
    /** Average since the engine was built (fuel burnt standing still included). */
    double fuelEconomyLitresPer100Km { 0.0 };
    /** Fuel flow now, by volume; what a standing car shows instead of L/100 km. */
    double fuelFlowLitresPerHour { 0.0 };
    /** Fuel flow over road speed now; 0 below 1 m/s, where it has no meaning. */
    double instantFuelEconomyLitresPer100Km { 0.0 };
    /** The trip computer: distance, fuel and average since the last trip reset. */
    double tripDistanceM { 0.0 };
    double tripFuelLitres { 0.0 };
    /** 0 until the trip has covered 100 m. */
    double tripFuelEconomyLitresPer100Km { 0.0 };
    /** The gearbox chooses its gears (TransmissionConfig::automaticShifting,
     * switched live from the UI). */
    bool automaticShifting { false };
    /** Cruise control: engaged, and the speed it holds. */
    bool cruiseEngaged { false };
    double cruiseSetSpeedMps { 0.0 };
    /** A pass-by run (EngineRuntime::startPassByRun): its phase
     *  (PassByPhase, 0 off), the car's place along the lane (m, 0 in front of
     *  the microphone, negative before it), the seconds since it began at the
     *  start and the sound's share (1, fading to 0 past the end). */
    std::uint8_t passByPhase { 0 };
    double passByPositionM { 0.0 };
    double passBySeconds { 0.0 };
    double passBySoundGain { 1.0 };
    double airFlowGramsPerSecond { 0.0 };
    double lambda { 1.0 };
    double brakeSpecificFuelConsumptionGPerKwh { 0.0 };
    double mechanicalEfficiency { 0.0 };
    double oilPressureKpa { 0.0 };
    double peakPistonAccelerationG { 0.0 };
    /** Highest firing pressure of the last completed cycle over all
     * cylinders, bar absolute, tracked at every physics sub-step (a per-frame
     * sample of the chamber pressure misses the peak). */
    double peakCylinderPressureBar { 0.0 };
    double resolvedHeatReleaseKw { 0.0 };
    double compressorPowerKw { 0.0 };
    double turbinePowerKw { 0.0 };
    /** Bearing/friction work removed from the turbo shaft energy balance. */
    double turboBearingPowerKw { 0.0 };
    /** Turbine minus compressor minus bearing power. Near zero at equilibrium. */
    double turboShaftNetPowerKw { 0.0 };
    double forcedInductionShaftSpeedRpm { 0.0 };
    /** Shaft speed divided by the authored compressor design speed. */
    double forcedInductionShaftSpeedRatio { 0.0 };
    double wastegateOpening { 0.0 };
    /** The active exhaust valves (ExhaustComponentConfig::inletValve): how
     * many the exhaust carries, the butterfly's stroke (0 shut, 1 open) and
     * the open share of the face, 1 - cos of its angle; 1 without a valve. */
    std::uint32_t exhaustValveCount { 0 };
    double exhaustValveStroke { 1.0 };
    double exhaustValveOpening { 1.0 };
    double blowOffMassFlowKgPerSecond { 0.0 };
    /** With `compressorSurge`: the flow through the compressors' duct, kg/s,
     *  negative while the charge blows back through them. */
    double compressorDuctFlowKgPerSecond { 0.0 };
    bool compressorDuctResolved { false };
    /** Each turbocharger. The scalar fields above are their mean shaft speed,
     * summed powers and the common wastegate. */
    struct Turbocharger final {
        double shaftSpeedRpm { 0.0 };
        double turbinePowerKw { 0.0 };
        double compressorPowerKw { 0.0 };
        double compressorMassFlowKgPerSecond { 0.0 };
        /** Flow coefficient over the map's design one; below 0.4 it surges,
         * from 1.5 it chokes. */
        double compressorFlowCoefficientRatio { 0.0 };
        double compressorEfficiency { 0.0 };
        /** Damage from running past the top speed line, 0-1; at 1 the
         * wheel has burst: the shaft stops and the compressor makes no
         * boost until the engine is reset. */
        double wheelDamage { 0.0 };
    };
    std::uint32_t turbochargerCount { 0 };
    std::array<Turbocharger, maximumTurbochargers> turbochargers {};
    /** Last resolved ECU command. These are diagnostic telemetry, not a
     * second control path: EngineSimulator publishes the exact command that
     * already drove injection and combustion in the current sub-step. */
    double ecuFuelCorrection { 1.0 };
    /** Per-cylinder compression-ignition quantity command. Zero means that the
     *  active ECU did not publish one and the simulator must use the authored
     *  engine-config fallback. */
    double ecuDieselFuelQuantityLimitMgPerCycle { 0.0 };
    bool ecuFuelEnabled { false };
    bool ecuSparkEnabled { false };
    bool ecuSoftRevLimiterActive { false };
    bool ecuHardRevLimiterActive { false };
    bool ecuAlternatingSparkCutActive { false };
    bool ecuDecelerationFuelCutActive { false };
    /** The rev limit the ECU applies now: its calibration's, else the
     *  authored `ignition.revLimitRpm`. */
    double activeRevLimitRpm { 0.0 };
    /** Bitmask of `ActiveLimit`: what holds the engine back this frame. */
    std::uint32_t activeLimits { 0U };
    double indicatedWorkJoulesPerCycle { 0.0 };
    double indicatedMeanEffectivePressureBar { 0.0 };
    /**
     * The two loops of the indicated diagram, published separately.
     *
     * `indicatedMeanEffectivePressureBar` above is the NET figure and already
     * contains the gas-exchange loop; these two split it, and
     * gross + pumping == net up to the difference between the engine-level
     * torque accumulation and the per-cylinder p-dV integrals they come from.
     *
     * `pumpingMeanEffectivePressureBar` is SIGNED, not a loss magnitude:
     * negative is the normal case (the piston spends work moving gas), and a
     * supercharged engine whose intake stroke is pressurised can legitimately
     * read positive. At wide-open throttle a healthy naturally aspirated engine
     * sits around -0.2 to -0.6 bar, the loss growing with speed; a throttled
     * one reaches -0.8 bar or worse, which is where the throttling loss lives.
     *
     * This is the number that exposes a gas-exchange failure. A cycle-averaged
     * IMEP cannot: an engine that cannot evacuate its cylinder reports a
     * perfectly healthy IMEP while paying twice, once in pumping work and once
     * in the residual it re-inducts on the next intake stroke.
     */
    double pumpingMeanEffectivePressureBar { 0.0 };
    /**
     * The exhaust-stroke half of `pumpingMeanEffectivePressureBar`; the intake
     * half is the remainder (`pumping - exhaustStroke`). Same sign convention.
     *
     * A single PMEP figure says an engine pumps too hard but not which side is
     * at fault, and the two have unrelated causes: the exhaust half is back
     * pressure (a duct, a collector, an exhaust-valve area, a terminal boundary
     * condition), the intake half is depression (a plate, a runner, an
     * intake-valve area). They are also of opposite physical sign at the pump --
     * the exhaust stroke pushes against a positive gauge pressure while the
     * intake stroke pulls against a negative one -- so a pair of errors on the
     * two sides can partly cancel in the total and hide from a PMEP gate.
     */
    double exhaustStrokeMeanEffectivePressureBar { 0.0 };
    double grossIndicatedMeanEffectivePressureBar { 0.0 };
    double indicatedPowerKw { 0.0 };
    double pdvTorqueNm { 0.0 };
    double powerKw { 0.0 };
    double cycleAveragedPowerKw { 0.0 };
    double wear { 0.0 };
    double damage { 0.0 };
    int gear { -1 };
    int gearCount { 0 };
    /** A CVT: one forward position (drive), the ratio below varies. */
    bool continuouslyVariable { false };
    /** The gearbox's ratio now (without the final drive); 0 in neutral. */
    double gearboxRatio { 0.0 };
    double clutchPressure { 1.0 };
    double vehicleSpeedMps { 0.0 };
    double vehicleDistanceM { 0.0 };
    double wheelTorqueNm { 0.0 };
    double drivelineLoadTorqueNm { 0.0 };
    double clutchTorqueNm { 0.0 };
    double clutchSlipRpm { 0.0 };
    double drivelineReflectedInertiaKgM2 { 0.0 };
    double shiftProgress { 0.0 };
    bool shiftInProgress { false };
    double brakePressure { 0.0 };
    double brakeForceN { 0.0 };
    double requestedRoadLoad { 0.0 };
    double roadLoadForceN { 0.0 };
    double tireLongitudinalForceN { 0.0 };
    double drivenAxleNormalForceN { 0.0 };
    double longitudinalAccelerationMps2 { 0.0 };
    bool tractionLimited { false };
    double clutchTemperatureC { 22.0 };
    double clutchDissipatedEnergyJoules { 0.0 };
    double clutchPowerLossKw { 0.0 };
    double drivelineStoredEnergyJoules { 0.0 };
    double drivelineEnergyResidualJoules { 0.0 };
    double dynoHoldRpm { 0.0 };
    bool dynoHoldEnabled { false };
    /** Which bench is armed: the continuous ramp or the 250 rpm stepped ladder.
     * Published because the toggle is otherwise invisible -- the two modes only
     * differ in how the setpoint moves, which a user cannot read off a torque
     * curve while it is being drawn. */
    bool dynoRampEnabled { false };
    DynoMode dynoMode { DynoMode::steppedCalibration };
    DynoRunStatus dynoRunStatus { DynoRunStatus::idle };
    DynoPhase dynoPhase { DynoPhase::idle };
    double dynoRampRpmPerSecond { 500.0 };
    /** User-facing brake-dyno session state. The preparation phase brings an
     * already-running engine to the first measurement speed without applying
     * a discontinuous absorber step. */
    bool dynoActive { false };
    bool dynoPreparing { false };
    double dynoTargetRpm { 0.0 };
    double dynoControllerTargetRpm { 0.0 };
    double dynoFilteredAccelerationRpmPerSecond { 0.0 };
    double dynoBrakeTorqueNm { 0.0 };
    double dynoBrakeContactFraction { 0.0 };
    bool dynoAbsorberSaturatedLow { false };
    bool dynoAbsorberSaturatedHigh { false };
    std::uint32_t dynoQualityReasons { 0U };
    bool dynoMeasurementReady { false };
    std::uint32_t dynoAcceptedCycleCount { 0U };
    double dynoWindowDurationSeconds { 0.0 };
    double dynoWindowMeanRpm { 0.0 };
    double dynoWindowMinimumRpm { 0.0 };
    double dynoWindowMaximumRpm { 0.0 };
    double dynoProgress { 0.0 };
    std::uint32_t dynoRecoveryCount { 0 };
    RunningState runningState { RunningState::stopped };
    std::array<CylinderState, 32> cylinderStates {};
    std::size_t cylinderStateCount { 0 };
    /** False during fuel/spark cut and until every cylinder has supplied one
     * fresh fuelled observation. Consumers must not interpret the retained
     * numeric AFR as a live mixture measurement while this is false. */
    bool airFuelRatioValid { false };
    /** The electric radiator fan, realistic temperatures only. */
    bool coolingFanOn { false };
    /** Crankshaft speed averaged over the last step: `rpm` is the speed at
     *  its end, which carries the firing ripple. Sampled once per 240 Hz
     *  frame, a ripple near that rate aliases into a slow wander; a
     *  two-stroke twin fires at 233 Hz at 7,000 rpm. Zero before a step. */
    double frameAveragedRpm { 0.0 };
    /** A two-stroke's exhaust power valve, 0 shut to 1 open; 1 without one. */
    double powerValveOpening { 1.0 };
    /** VTEC: bit i is set while configuration cylinder i runs its high cam
     *  (the valves' actual profile, switched on a base circle). */
    std::uint32_t vtecHighCylinderMask { 0U };
    /** VTEC: the ECU's switch, on an engine with VTEC cams fitted. */
    bool vtecEnabled { false };
    /** VTEC: the speed the ECU engages the high cam above, rpm (the first
     *  VTEC camshaft's own when its tables have no setting); 0 without. */
    double vtecEngageRpm { 0.0 };
    /** The nitrous kit: spraying, its flow (kg/s of liquid nitrous), the
     *  liquid left (kg), the bottle's pressure (kPa) and temperature (C),
     *  and the share of the charge's oxygen that came from it. */
    bool nitrousSpraying { false };
    double nitrousMassFlowKgPerSecond { 0.0 };
    double nitrousBottleMassKg { 0.0 };
    double nitrousBottlePressureKpa { 0.0 };
    double nitrousBottleTemperatureC { 0.0 };
    double nitrousOxygenShare { 0.0 };
    /** A fitted kit that does not spray: why (NitrousBlocker bits). */
    std::uint32_t nitrousBlockers { 0U };
    /** Anti-lag: armed in the ECU's tables, and working this frame. */
    bool antiLagArmed { false };
    bool antiLagActive { false };
    /** Armed and not working: why (AntiLagBlocker bits). Working: the share
     *  of its air it opens, 0-1, and the torque it holds the engine to. */
    std::uint32_t antiLagBlockers { 0U };
    double antiLagAuthority { 0.0 };
    double antiLagTargetTorqueNm { 0.0 };
};

struct EcuCommand final {
    double targetAirFuelRatio { 14.2 };
    double ignitionAdvanceDegrees { 18.0 };
    double effectiveThrottle { 0.0 };
    /** Normalised command for the configured idle-air bypass actuator. */
    double idleAirOpening { 0.0 };
    double fuelCorrection { 1.0 };
    /** Per-cylinder diesel injected-quantity ceiling. Zero preserves custom
     *  ECU compatibility by selecting the EngineConfig fallback curve. */
    double dieselFuelQuantityLimitMgPerCycle { 0.0 };
    bool fuelEnabled { true };
    bool sparkEnabled { true };
    bool overrunAfterfireActive { false };
    /** Explicit authored limiter state that keeps fuel while cutting spark. */
    bool wetSparkCutActive { false };
    /** Diagnostic attribution for torque discontinuities. */
    bool softRevLimiterActive { false };
    bool hardRevLimiterActive { false };
    bool alternatingSparkCutActive { false };
    bool decelerationFuelCutActive { false };
    /** Bitmask of `AfterfireBlocker`. Append new members BELOW this one: the
     *  aggregate is initialised by position in SimpleEcuModel. */
    std::uint32_t overrunAfterfireBlockers { 0U };
    /** Whether a lambda observation may update long-term trim. Tip-in, DFCO,
     * fuel-resume and deliberate spark cuts are open-loop transients. */
    bool lambdaLearningAllowed { true };
    /** One-substep edge emitted when driver demand ends an active DFCO period.
     *  The simulator uses it to start a bounded port-transport observation
     *  epoch before accepting a new lambda sample. */
    bool decelerationFuelResumeEvent { false };
    /** The rev limit applied to this command (see `activeRevLimitRpm`). */
    double revLimitRpm { 0.0 };
    /** `ActiveLimit` bits the ECU itself decides: rev limiter, knock retard,
     *  coolant protection. */
    std::uint32_t activeLimits { 0U };
    /** Gauge boost the wastegate controller holds (calibration
     *  `boost.target_gauge_kpa`); negative: the configuration's wastegate
     *  pressure ratio. */
    double boostTargetGaugeKpa { -1.0 };
    /** Share of firings, 0-1, whose injection is suppressed (a dual
     *  clutch's upshift intervention). The simulator spreads it over the
     *  cylinders in firing order. */
    double cylinderCutFraction { 0.0 };
    /** VTEC (calibration `vtec.*`): whether the ECU lets the high cam run.
     *  Off, a high cam drops back at its next base circle. */
    bool vtecEnabled { true };
    /** The speed the high cam engages above, rpm; negative: each camshaft's
     *  own `switchRpm`. */
    double vtecEngageRpm { -1.0 };
    /** The high cam drops back below the engagement speed less this, rpm. */
    double vtecHysteresisRpm { 0.0 };
    /** The throttle, 0-1, under which the high cam never runs; negative:
     *  each camshaft's own `switchThrottle`. */
    double vtecMinimumThrottle { -1.0 };
    /** Anti-lag (calibration `antilag.*`): armed, the exhaust's reaction
     *  model runs; active, the ECU holds the throttle open, fires late and
     *  cuts the spark of `sparkCutFraction` of the firings, fuel kept. */
    bool antiLagArmed { false };
    bool antiLagActive { false };
    /** Share of firings, 0-1, whose spark is cut with the fuel kept; the
     *  simulator spreads it over the cylinders in firing order. */
    double sparkCutFraction { 0.0 };
    /** Anti-lag's `AntiLagBlocker` bits, the share of its air it opens
     *  (0-1, its feedback's output) and the torque it holds the engine to,
     *  N.m (negative: braking). */
    std::uint32_t antiLagBlockers { 0U };
    double antiLagAuthority { 0.0 };
    double antiLagTargetTorqueNm { 0.0 };
};

// Output of the mean-value model SimplifiedGasolinePhysics::evaluateCombustion.
// It is telemetry, NOT the crank-driving model: the crankshaft is integrated
// from the 0-D solver's chamber pressure (see that model's header and
// physics-audit.md (archive/docs-2026-09 tag)). This is the *measured* consumption map (Phase 6): the
// only production readers are EngineSimulator and FourStrokeEventGenerator, plus
// the EngineLab.Core characterization test. Field order is load-bearing (used by
// designated/positional init in the model); do not reorder to "tidy" the groups.
//
//   Drives live behaviour:
//     combustionEnabled   gates injection/combustion/event generation
//     combustionQuality   exhaust-audio firing amplitude (read unconditionally)
//     heatOutput          cylinder wall temperature -> wall heat transfer
//     pressureEstimateBar firing pressure, event-gen fallback when no resolved
//                         per-cylinder state exists
//     misfireProbability  misfire draw, event-gen fallback (same condition)
//     airMassMgPerCycle   breathingQuality display
//   Telemetry / test-only (no production reader):
//     indicatedTorqueNm   copied to state.meanWorkTorqueNm for display only
//     actualAirFuelRatio  read only by EngineLab.Core (characterization)
//     heatPowerKw         read only by EngineLab.Core (characterization)
//   Unread anywhere (kept as struct-stable telemetry; the value is still a
//   necessary local intermediate inside the model, so the field is cheap):
//     knockLevel (forced 0.0), volumetricEfficiency, fuelMassMgPerCycle,
//     thermalEfficiency
struct CombustionResult final {
    double indicatedTorqueNm { 0.0 };     // telemetry -> state.meanWorkTorqueNm (display)
    double pressureEstimateBar { 0.0 };   // event-gen firing-pressure fallback
    double combustionQuality { 0.0 };     // exhaust-audio amplitude (live, unconditional)
    double heatOutput { 0.0 };            // cylinder wall temperature (live)
    double knockLevel { 0.0 };            // unread; knock resolved per-cylinder in EngineSimulator
    double misfireProbability { 0.0 };    // event-gen misfire fallback
    double volumetricEfficiency { 0.0 };  // unread (intermediate exposed as telemetry)
    double airMassMgPerCycle { 0.0 };     // breathingQuality display (live)
    double fuelMassMgPerCycle { 0.0 };    // unread (intermediate exposed as telemetry)
    double thermalEfficiency { 0.0 };     // unread (intermediate exposed as telemetry)
    double actualAirFuelRatio { 14.7 };   // read only by EngineLab.Core characterization
    double heatPowerKw { 0.0 };           // read only by EngineLab.Core characterization
    bool combustionEnabled { false };     // gates injection/combustion/event-gen (live)
};

struct DynoPoint final {
    /** Display/recorder abscissa. For a continuous pull this is an exact bin;
     * windowMeanRpm below remains the speed actually represented. */
    double rpm { 0.0 };
    double torqueNm { 0.0 };
    double powerKw { 0.0 };
    double airFuelRatio { 14.7 };
    double coolantTemperatureC { 22.0 };
    double exhaustTemperatureC { 22.0 };
    double ignitionAdvanceDegrees { 0.0 };
    double atmosphericCorrectionFactor { 1.0 };
    double correctedTorqueNm { 0.0 };
    double correctedPowerKw { 0.0 };
    double targetAirFuelRatio { 14.7 };
    double volumetricEfficiency { 0.0 };
    double fuelFlowGramsPerSecond { 0.0 };
    double manifoldPressureKpa { 0.0 };
    double exhaustPressureKpa { 0.0 };
    double oilTemperatureC { 22.0 };
    double oilPressureKpa { 0.0 };
    double airFlowGramsPerSecond { 0.0 };
    double lambda { 1.0 };
    double brakeSpecificFuelConsumptionGPerKwh { 0.0 };
    double binRpm { 0.0 };
    double windowMeanRpm { 0.0 };
    double windowMinimumRpm { 0.0 };
    double windowMaximumRpm { 0.0 };
    double windowDurationSeconds { 0.0 };
    double torqueVarianceNm2 { 0.0 };
    std::uint64_t firstCycleId { 0 };
    std::uint64_t lastCycleId { 0 };
    std::uint32_t acceptedCycleCount { 0 };
    /** Bit representation of DynoQualityReason; zero means accepted. */
    std::uint32_t qualityReasons { 0 };
    bool valid { true };
    bool airFuelRatioValid { false };
};

struct DynoRun final {
    std::uint64_t id { 0 };
    std::string engineName;
    DynoSessionConfig sessionConfig {};
    DynoRunStatus status { DynoRunStatus::idle };
    DynoStopReason stopReason { DynoStopReason::none };
    std::uint64_t calibrationRevision { 0 };
    double startedAtSimulationSeconds { 0.0 };
    double endedAtSimulationSeconds { 0.0 };
    std::vector<DynoPoint> points;
    double peakTorqueNm { 0.0 };
    double peakPowerKw { 0.0 };
    double peakCorrectedTorqueNm { 0.0 };
    double peakCorrectedPowerKw { 0.0 };
};

/** "manual", "sequential" or "dual_clutch", as in the engine files. */
[[nodiscard]] const char* shiftStyleName(ShiftStyle) noexcept;
/** `count` forward gears from `ratios`: the first and the top keep their
 *  ratios and the gears between are spread with an equal step from one to
 *  the next, as a gearbox's steps are; one gear is the first. Empty if
 *  `ratios` is empty or `count` is 0. */
[[nodiscard]] std::vector<double> spreadGearRatios(const std::vector<double>& ratios, std::size_t count);
[[nodiscard]] std::optional<ShiftStyle> parseShiftStyle(const std::string&) noexcept;

[[nodiscard]] EngineConfig makeDefaultInlineFour();
[[nodiscard]] EngineConfig makeDefaultInlineTwo();
[[nodiscard]] EngineConfig makeDefaultInlineFive();
[[nodiscard]] EngineConfig makeDefaultV6();
[[nodiscard]] EngineConfig makeDefaultV8();
[[nodiscard]] EngineConfig makeDefaultFlatSix();
[[nodiscard]] EngineConfig makeDefaultRadialFive();
[[nodiscard]] std::vector<EngineConfig> makeBaseEnginePresets();
[[nodiscard]] double engineDisplacementLitres(const EngineConfig&) noexcept;
/** The volume the air-sizing rules take in 720 deg of the shaft: the
 *  displacement, and a rotary's faces' share of it, each face filling once in
 *  1,080 deg (a 13B's six faces sweep 3.9 L, 2.6 L in 720 deg). A two-stroke
 *  keeps its displacement, as those rules were fitted on it. */
[[nodiscard]] double breathingDisplacementLitres(const EngineConfig&) noexcept;
[[nodiscard]] double effectiveRotatingInertiaKgM2(const EngineConfig&) noexcept;
/** The authored peak firing pressure limit, or a typical one for the fuel and
 * induction when none is authored. */
[[nodiscard]] double peakCylinderPressureLimitBar(const EngineConfig&) noexcept;
/** The carburettor that sets the engine's idle: its first intake path's
 *  (the engine-wide intake on an engine without paths), or nothing when the
 *  engine meters with injectors and its ECU governs the idle. */
[[nodiscard]] const CarburettorConfig* idleCarburettor(const EngineConfig&) noexcept;
[[nodiscard]] double intakeRunnerVolumeLitres(const CylinderConfig&, const IntakeConfig&) noexcept;
void normaliseEngineConfig(EngineConfig&);
/** The camshaft a cylinder runs: its bank's when a bank names it, else the
 *  engine-wide one. */
[[nodiscard]] const CamshaftConfig& camshaftOfCylinder(const EngineConfig&, const CylinderConfig&) noexcept;
/** Whether a cylinder's camshaft carries a high cam (VTEC; a rotary's staged
 *  intake ports). A two-stroke has none. */
[[nodiscard]] bool vtecCamsFitted(const EngineConfig&) noexcept;
/** Whether any exhaust part carries an active valve (inletValve). */
[[nodiscard]] bool exhaustValveFitted(const EngineConfig&) noexcept;
/** The first VTEC camshaft a cylinder runs, or null. */
[[nodiscard]] const CamshaftConfig* firstVtecCamshaft(const EngineConfig&) noexcept;
/** Fits VTEC cams to every camshaft that has none, laid out as the
 *  catalogue K20A's over its own cam (intake +24 deg and +1.0 mm, exhaust
 *  +22 deg and +0.6 mm; a rotary's exhaust port keeps its timing), engaging
 *  at two thirds of the rev limit above 55 % throttle. A camshaft that has
 *  them keeps its high cam. False on a two-stroke, which has no cam to
 *  switch, or when every camshaft has them already. */
bool fitVtecCams(EngineConfig&);
/** Takes the VTEC cams off every camshaft (the high cam's figures stay in
 *  the file, unused). */
void removeVtecCams(EngineConfig&) noexcept;
/** Backfires (overrun afterfire and the wet limiter) are a listening option
 *  the Audio workshop turns on for the running engine, never part of an
 *  engine: every engine is loaded, compared and saved with them off. The
 *  calibration under the switch is kept. */
void disableBackfires(EngineConfig&) noexcept;
/** An edit of the running engine (a bigger bore, a script reload, the JSON
 *  editor) takes the running engine's backfires, switch and calibration: only
 *  the Audio workshop changes them, and only another engine resets them. */
void keepBackfires(const EngineConfig& running, EngineConfig& edited) noexcept;
[[nodiscard]] double valveFlowCoefficient(double liftMm, double fallback,
                                          const std::vector<ValveFlowSample>&) noexcept;
[[nodiscard]] ValveControlSample interpolateValveControl(const ValveControlConfig&, double rpm,
                                                         double load) noexcept;
/** `cycleDegrees`: the cylinder's cycle the angles wrap in (1,080 on a
 *  rotary's face). */
[[nodiscard]] double valveLiftMm(double crankAngleDegrees, double centerlineDegrees,
                                 double durationDegrees, double maximumLiftMm,
                                 double cycleDegrees = 720.0) noexcept;
[[nodiscard]] double profiledValveLiftMm(double crankAngleDegrees, double centerlineDegrees,
                                         double durationDegrees, double maximumLiftMm,
                                         const std::vector<ValveLiftSample>& samples,
                                         double cycleDegrees = 720.0) noexcept;
[[nodiscard]] double combustionPulse(double cylinderPhaseDegrees, double ignitionAdvanceDegrees,
                                     double ignitionOffsetDegrees) noexcept;
/** validateEngineConfig()'s limits that the engine designer clamps to. */
inline constexpr double minimumRotatingInertiaKgM2 { 0.01 };
inline constexpr double minimumPlenumVolumeLitres { 0.1 };
inline constexpr double minimumThrottleDiameterMm { 15.0 };
/** The floors above are a 50 cc engine's; validateEngineConfig() takes a
 *  model engine's, and the designer scales the floors down below 50 cc. */
inline constexpr double smallestPlenumVolumeLitres { 0.001 };
inline constexpr double smallestThrottleDiameterMm { 2.0 };
inline constexpr double minimumPistonMassGrams { 50.0 };
/** A model engine's bore to a ship's: sizes are not refused for being large. */
inline constexpr double minimumBoreStrokeMm { 5.0 };
inline constexpr double maximumBoreStrokeMm { 1'000.0 };
/** Everything outside the gearbox, a motorcycle's primary drive included: a
 *  125 cc bike runs about 10 (primary ~3 x chain ~3.3), a scooter 9.4. */
inline constexpr double maximumFinalDriveRatio { 15.0 };
[[nodiscard]] std::optional<std::string> validateEngineConfig(const EngineConfig&);
/** Clamps every finite engine or part scalar that validateEngineConfig()
 *  would refuse for its range into that range, and says what it changed
 *  ("octaneRating = 150, outside 70 to 130: loaded as 130"). A hand-edited
 *  file then loads with a warning instead of vanishing from the engine menu.
 *  Values in lists (cylinders, curves) and refusals of another kind are left
 *  to validateEngineConfig(). */
[[nodiscard]] std::vector<std::string> repairEngineConfigRanges(EngineConfig&);

} // namespace enginelab




