#pragma once

#include <enginelab/foundation/EngineTypes.hpp>

#include <algorithm>
#include <array>
#include <cmath>
#include <cstddef>
#include <numbers>

namespace enginelab {

struct TurboExhaustFlowSplit final {
    double turbineKgPerSecond {};
    double wastegateKgPerSecond {};
};

/** One explicit energy step of the reduced turbocharger shaft model.
 *
 * `compressorPressureRatio` is the head available at the END of the step from
 * the centrifugal similarity law. `compressorPowerWatts` is the work actually
 * removed during the step at the measured compressor outlet pressure. Keeping
 * those two quantities separate preserves causality without hiding a block of
 * shaft energy in a pressure clamp.
 */
struct TurboShaftAdvance final {
    double angularSpeedRadPerSecond {};
    double compressorPressureRatio { 1.0 };
    double compressorPowerWatts {};
    double bearingPowerWatts {};
    double netPowerWatts {};
    double energyBeforeJoules {};
    double energyAfterJoules {};
};

inline constexpr double turboAirCpJPerKgK = 1'005.0;
inline constexpr double turboIsentropicExponent = 0.285714285714;

/** Centrifugal-compressor head from the affinity law.
 *
 * This is deliberately an extrapolatable reduced-order law, not a hidden
 * compressor map. At the authored design shaft speed it returns the authored
 * design pressure ratio; shaft-speed ratio remains separately observable so a
 * caller can identify operation beyond that design point.
 */
[[nodiscard]] inline double compressorPressureRatioFromSpeed(
    const ForcedInductionConfig& config,
    double angularSpeedRadPerSecond) noexcept {
    const auto designOmega = config.designShaftSpeedRpm
        * 2.0 * std::numbers::pi / 60.0;
    const auto speedRatio = std::max(0.0, angularSpeedRadPerSecond)
        / std::max(1.0, designOmega);
    return 1.0 + std::max(0.0, config.pressureRatio - 1.0)
        * speedRatio * speedRatio;
}

/** Where a centrifugal compressor runs on its map. */
struct CompressorOperatingPoint final {
    double pressureRatio { 1.0 };
    /** Corrected shaft speed over the design speed. */
    double speedRatio { 0.0 };
    /** Flow coefficient over the design one: corrected flow over speed. */
    double flowCoefficientRatio { 0.0 };
    /** Left of the surge line: the real flow would reverse in bursts. */
    bool surge { false };
    /** Past the choke line: the wheel passes no more flow and adds no head. */
    bool choke { false };
};

inline constexpr double compressorReferenceTemperatureK = 298.15;
inline constexpr double compressorReferencePressureKpa = 101.325;
/** Choke and surge, as flow coefficients over the design one. */
inline constexpr double compressorChokeFlowCoefficientRatio = 1.5;
inline constexpr double compressorSurgeFlowCoefficientRatio = 0.4;

/** A generic compressor map scaled to the authored design point.
 *
 * A compressor family's speed lines collapse onto one curve of the head
 * coefficient against the flow coefficient (Moraal and Kolmanovsky, SAE
 * 1999-01-0908). Both are taken relative to the design point here: the head
 * ratio is (PR^k - 1) / ((PR_d^k - 1) N^2) and the flow ratio is the corrected
 * flow over the design flow, divided by the corrected speed ratio N. The curve
 * is psi = psi0 (1 - (phi / phi_c)^4): flat towards surge, falling steeply to
 * zero head at choke (phi_c = 1.5), through psi = 1 at the design point. At
 * the design flow and speed the map returns the design pressure ratio, as the
 * affinity law did; it now also falls with flow, as a real wheel's does.
 *
 * The efficiency stays the authored one: an efficiency island around the
 * design point cost 9-19 % of the torque at 2,000 rpm, further from the
 * makers' figures (journal 2026-10-15).
 */
[[nodiscard]] inline CompressorOperatingPoint compressorOperatingPoint(
    const ForcedInductionConfig& config, double designMassFlowKgPerSecond,
    double angularSpeedRadPerSecond, double massFlowKgPerSecond,
    double inletTemperatureK, double inletPressureKpa) noexcept {
    CompressorOperatingPoint point;
    const auto designOmega = std::max(1.0, config.designShaftSpeedRpm * 2.0 * std::numbers::pi / 60.0);
    const auto temperatureK = std::max(150.0, inletTemperatureK);
    const auto pressureKpa = std::max(1.0, inletPressureKpa);
    point.speedRatio = std::max(0.0, angularSpeedRadPerSecond) / designOmega
        * std::sqrt(compressorReferenceTemperatureK / temperatureK);
    const auto correctedFlowRatio = std::max(0.0, massFlowKgPerSecond)
        * std::sqrt(temperatureK / compressorReferenceTemperatureK)
        / (pressureKpa / compressorReferencePressureKpa)
        / std::max(1.0e-6, designMassFlowKgPerSecond);
    if (point.speedRatio < 1.0e-6) {
        point.flowCoefficientRatio = correctedFlowRatio > 0.0 ? compressorChokeFlowCoefficientRatio : 0.0;
        point.choke = correctedFlowRatio > 0.0;
        return point;
    }
    const auto phi = correctedFlowRatio / point.speedRatio;
    point.flowCoefficientRatio = phi;
    constexpr auto chokeFourth = compressorChokeFlowCoefficientRatio * compressorChokeFlowCoefficientRatio
        * compressorChokeFlowCoefficientRatio * compressorChokeFlowCoefficientRatio;
    const auto psi0 = 1.0 / (1.0 - 1.0 / chokeFourth);
    const auto psi = std::max(0.0, psi0 * (1.0 - phi * phi * phi * phi / chokeFourth));
    const auto designHead = std::pow(std::max(1.0, config.pressureRatio), turboIsentropicExponent) - 1.0;
    point.pressureRatio = std::pow(1.0 + psi * designHead * point.speedRatio * point.speedRatio,
        1.0 / turboIsentropicExponent);
    point.choke = phi >= compressorChokeFlowCoefficientRatio;
    point.surge = phi < compressorSurgeFlowCoefficientRatio;
    return point;
}

/** A wheel's head down to no flow and reversed (Greitzer, ASME J. Eng.
 *  Power 98, 1976; Moore and Greitzer, 1986): the map to the surge line,
 *  then a cubic through the surge line's head with zero slope there, falling
 *  to a shut-off head of 70 % of it at no flow and rising again for reversed
 *  flow, where the wheel only resists the charge blowing back. Left of its
 *  peak the head rises with flow: a dip in flow lowers the head, and the
 *  charge behind pushes the flow down further. That branch is what surges. */
inline constexpr double compressorShutOffHeadShare = 0.7;
/** Greitzer's duct: the inducer's area over an equivalent length of 0.4 m
 *  (the inlet pipe and the wheel's passages of a car's turbocharger). */
inline constexpr double compressorDuctLengthM = 0.4;

[[nodiscard]] inline double compressorSurgeHeadPressureRatio(
    const ForcedInductionConfig& config, double designMassFlowKgPerSecond,
    double angularSpeedRadPerSecond, double massFlowKgPerSecond,
    double inletTemperatureK, double inletPressureKpa) noexcept {
    const auto designOmega = std::max(1.0, config.designShaftSpeedRpm * 2.0 * std::numbers::pi / 60.0);
    const auto temperatureK = std::max(150.0, inletTemperatureK);
    const auto speedRatio = std::max(0.0, angularSpeedRadPerSecond) / designOmega
        * std::sqrt(compressorReferenceTemperatureK / temperatureK);
    if (speedRatio < 1.0e-6) return 1.0;
    const auto phi = massFlowKgPerSecond * std::sqrt(temperatureK / compressorReferenceTemperatureK)
        / (std::max(1.0, inletPressureKpa) / compressorReferencePressureKpa)
        / std::max(1.0e-6, designMassFlowKgPerSecond) / speedRatio;
    constexpr auto chokeFourth = compressorChokeFlowCoefficientRatio * compressorChokeFlowCoefficientRatio
        * compressorChokeFlowCoefficientRatio * compressorChokeFlowCoefficientRatio;
    const auto psi0 = 1.0 / (1.0 - 1.0 / chokeFourth);
    auto psi = 0.0;
    if (phi >= compressorSurgeFlowCoefficientRatio) {
        psi = std::max(0.0, psi0 * (1.0 - phi * phi * phi * phi / chokeFourth));
    } else {
        constexpr auto surgeFourth = compressorSurgeFlowCoefficientRatio * compressorSurgeFlowCoefficientRatio
            * compressorSurgeFlowCoefficientRatio * compressorSurgeFlowCoefficientRatio;
        const auto surgeHead = psi0 * (1.0 - surgeFourth / chokeFourth);
        const auto semiHeight = 0.5 * (1.0 - compressorShutOffHeadShare) * surgeHead;
        const auto x = phi / (0.5 * compressorSurgeFlowCoefficientRatio) - 1.0;
        psi = compressorShutOffHeadShare * surgeHead + semiHeight * (1.0 + 1.5 * x - 0.5 * x * x * x);
    }
    const auto designHead = std::pow(std::max(1.0, config.pressureRatio), turboIsentropicExponent) - 1.0;
    return std::pow(1.0 + psi * designHead * speedRatio * speedRatio, 1.0 / turboIsentropicExponent);
}

/** Axial speed through the inducer at the centre of a typical compressor map. */
inline constexpr double compressorInducerDesignVelocityMps = 100.0;

/** One unit's corrected flow at the centre of its map: the authored one, else
 *  100 m/s through an authored inducer, else the engine's air flow at 70 % of
 *  the redline at the wastegate boost (volumetric efficiency 0.9), shared by
 *  the units. */
[[nodiscard]] inline double compressorDesignMassFlowKgPerSecond(const EngineConfig& config) noexcept {
    const auto& turbo = config.forcedInduction;
    if (turbo.compressorDesignMassFlowKgPerSecond > 0.0) return turbo.compressorDesignMassFlowKgPerSecond;
    constexpr double referenceDensityKgPerM3 = compressorReferencePressureKpa * 1'000.0
        / (287.05 * compressorReferenceTemperatureK);
    if (turbo.compressorInducerDiameterMm > 0.0) {
        const auto radiusM = turbo.compressorInducerDiameterMm * 0.0005;
        return referenceDensityKgPerM3 * std::numbers::pi * radiusM * radiusM
            * compressorInducerDesignVelocityMps;
    }
    const auto ratio = std::max(1.0, turbo.wastegatePressureRatio);
    const auto chargeTemperatureRatio = 1.0 + (std::pow(ratio, turboIsentropicExponent) - 1.0)
        / std::clamp(turbo.compressorEfficiency, 0.35, 0.90);
    const auto flow = referenceDensityKgPerM3 * breathingDisplacementLitres(config) * 0.001
        * 0.7 * config.redlineRpm / 120.0 * 0.9 * ratio / chargeTemperatureRatio;
    return std::max(0.005, flow / static_cast<double>(std::max(1U, turbo.turbochargerCount)));
}

/** One compressor's duct: its authored inducer, else the area passing its
 *  design flow at 100 m/s. */
[[nodiscard]] inline double compressorDuctAreaM2(const EngineConfig& config) noexcept {
    const auto& turbo = config.forcedInduction;
    if (turbo.compressorInducerDiameterMm > 0.0) {
        const auto radiusM = turbo.compressorInducerDiameterMm * 0.0005;
        return std::numbers::pi * radiusM * radiusM;
    }
    constexpr double referenceDensityKgPerM3 = compressorReferencePressureKpa * 1'000.0
        / (287.05 * compressorReferenceTemperatureK);
    return compressorDesignMassFlowKgPerSecond(config)
        / (referenceDensityKgPerM3 * compressorInducerDesignVelocityMps);
}

/** The charge between the compressors and the throttle: the authored
 *  volume, else 1.5 x the displacement (a car's pipes and intercooler). */
[[nodiscard]] inline double chargeVolumeM3(const EngineConfig& config) noexcept {
    return (config.forcedInduction.chargeVolumeLitres > 0.0 ? config.forcedInduction.chargeVolumeLitres
        : 1.5 * breathingDisplacementLitres(config)) * 0.001;
}

/** A centrifugal supercharger's wheel at the centre of its map: the authored
 *  flow, else the engine's air at full-boost speed and the authored ratio
 *  (volumetric efficiency 0.9, the turbocharger's sizing). Its design speed
 *  is the full-boost speed
 *  through the drive. An inducer is not read: a supercharger's authored
 *  "inducer" is often the wheel's tip (the Merlin's 250 mm). */
[[nodiscard]] inline double centrifugalSuperchargerDesignMassFlowKgPerSecond(const EngineConfig& config) noexcept {
    const auto& charger = config.forcedInduction;
    if (charger.compressorDesignMassFlowKgPerSecond > 0.0) return charger.compressorDesignMassFlowKgPerSecond;
    constexpr double referenceDensityKgPerM3 = compressorReferencePressureKpa * 1'000.0
        / (287.05 * compressorReferenceTemperatureK);
    const auto ratio = std::max(1.0, charger.pressureRatio);
    const auto chargeTemperatureRatio = 1.0 + (std::pow(ratio, turboIsentropicExponent) - 1.0)
        / std::clamp(charger.compressorEfficiency, 0.35, 0.90);
    const auto cyclesPerRevolution = 360.0 / cycleDegreesOf(config.cycle);
    return std::max(0.005, referenceDensityKgPerM3 * engineDisplacementLitres(config) * 0.001
        * std::max(1.0, charger.fullBoostRpm) / 60.0 * cyclesPerRevolution * 0.9 * ratio
        / chargeTemperatureRatio);
}

/** A Roots supercharger's clearances return to its inlet the air its rotors
 *  displace at 2,000 rotor rpm at a 50 kPa rise: a volumetric efficiency of
 *  0.80 at 10,000 rotor rpm and 0.50 at 4,000, about an Eaton M-series map.
 *  The clearances are orifices of fixed area, so the leak grows with the
 *  root of the rise and not with the speed. */
inline constexpr double rootsLeakageRotorRpm = 2'000.0;
inline constexpr double rootsLeakageReferenceRiseKpa = 50.0;
/** Its bypass valve opens with manifold vacuum: shut at none, fully open at
 *  34 kPa (10 inHg, about the actuator of a GM 3800's M90). */
inline constexpr double rootsBypassFullOpenVacuumKpa = 34.0;
inline constexpr double rootsBypassDischargeCoefficient = 0.7;

[[nodiscard]] inline double rootsLeakageM3PerSecond(double displacementLitres, double riseKpa) noexcept {
    return displacementLitres * 0.001 * rootsLeakageRotorRpm / 60.0
        * std::sqrt(std::max(0.0, riseKpa) / rootsLeakageReferenceRiseKpa);
}

/** The authored displacement, else the one that holds the authored ratio at
 *  the redline, the engine at a volumetric efficiency of 0.9. The boost an
 *  engine then reaches is its own breathing's: a designed 1.6 four at 1.75
 *  reaches 1.75 at 6,000 rpm, a designed 3.8 V6 at 1.5 reaches 1.34 (it
 *  draws 1.02 of its swept volume at the outlet's pressure), as a real
 *  blower's pulley is chosen on the car. */
[[nodiscard]] inline double rootsDisplacementLitres(const EngineConfig& config) noexcept {
    const auto& charger = config.forcedInduction;
    if (charger.superchargerDisplacementLitres > 0.0) return charger.superchargerDisplacementLitres;
    const auto ratio = std::max(1.0, charger.pressureRatio);
    const auto engineRevolutionsPerSecond = std::max(1.0, config.redlineRpm) / 60.0;
    const auto cyclesPerRevolution = 360.0 / cycleDegreesOf(config.cycle);
    // The engine draws its volume at the outlet's density, the rotors fill
    // at the inlet's: the net displacement carries the ratio.
    const auto drawnM3PerSecond = engineDisplacementLitres(config) * 0.001
        * engineRevolutionsPerSecond * cyclesPerRevolution * 0.9 * ratio;
    const auto rotorRevolutionsPerSecond = engineRevolutionsPerSecond
        * std::max(0.1, charger.superchargerDriveRatio);
    const auto netM3PerSecondPerLitre = std::max(0.2 * rotorRevolutionsPerSecond * 0.001,
        rotorRevolutionsPerSecond * 0.001
            - rootsLeakageM3PerSecond(1.0, (ratio - 1.0) * config.ambientPressureKpa));
    return drawnM3PerSecond / netM3PerSecondPerLitre;
}

/** The authored bypass, else the throttle bores' combined area. */
[[nodiscard]] inline double rootsBypassAreaM2(const EngineConfig& config) noexcept {
    if (config.forcedInduction.superchargerBypassAreaMm2 > 0.0)
        return config.forcedInduction.superchargerBypassAreaMm2 * 1.0e-6;
    const auto radiusM = config.intake.throttleDiameterMm * 0.0005;
    return static_cast<double>(std::max(1U, config.intake.throttleCount)) * std::numbers::pi * radiusM * radiusM;
}

struct RootsOperatingPoint final {
    double pressureRatio { 1.0 };
    double powerWatts {};
    double bypassKgPerSecond {};
};

/** Where a Roots supercharger runs: the outlet pressure at which the air its
 *  rotors carry, less what its clearances leak back and its bypass returns,
 *  is the air the engine draws there. The engine's draw is the one measured
 *  at `currentPressureRatio`, in proportion to the outlet pressure (a throttle
 *  and the cylinders both pass mass in proportion to the pressure upstream).
 *  A Roots has no internal compression: each pocket arrives at the inlet's
 *  pressure and the outlet's gas flows back into it, so the work is the
 *  displaced volume times the rise. Where the engine draws more than the
 *  rotors carry it would be a restriction; the ratio is held at 1 there. */
[[nodiscard]] inline RootsOperatingPoint rootsOperatingPoint(
    double displacementLitres, double rotorRpm, double engineMassFlowKgPerSecond,
    double currentPressureRatio, double bypassAreaM2, double inletPressureKpa,
    double inletTemperatureK) noexcept {
    RootsOperatingPoint point;
    const auto inletKpa = std::max(1.0, inletPressureKpa);
    const auto density = inletKpa * 1'000.0 / (287.05 * std::max(150.0, inletTemperatureK));
    const auto displacedM3PerSecond = std::max(0.0, displacementLitres) * 0.001
        * std::max(0.0, rotorRpm) / 60.0;
    const auto drawPerRatio = std::max(0.0, engineMassFlowKgPerSecond)
        / std::max(1.0, currentPressureRatio);
    const auto bypassAt = [&](double riseKpa) {
        return rootsBypassDischargeCoefficient * std::max(0.0, bypassAreaM2)
            * std::sqrt(2.0 * density * std::max(0.0, riseKpa) * 1'000.0);
    };
    const auto surplusAt = [&](double ratio) {
        const auto riseKpa = (ratio - 1.0) * inletKpa;
        return density * (displacedM3PerSecond - rootsLeakageM3PerSecond(displacementLitres, riseKpa))
            - bypassAt(riseKpa) - drawPerRatio * ratio;
    };
    auto low = 1.0;
    auto high = 1.0;
    if (surplusAt(1.0) > 0.0) {
        high = 2.0;
        while (high < 8.0 && surplusAt(high) > 0.0) high *= 2.0;
        for (int iteration = 0; iteration < 40; ++iteration) {
            const auto middle = 0.5 * (low + high);
            (surplusAt(middle) > 0.0 ? low : high) = middle;
        }
    }
    point.pressureRatio = 0.5 * (low + high);
    const auto riseKpa = (point.pressureRatio - 1.0) * inletKpa;
    point.bypassKgPerSecond = bypassAt(riseKpa);
    point.powerWatts = displacedM3PerSecond * riseKpa * 1'000.0;
    return point;
}

/** The pressure ratio parallel compressors hold together, and each one's
 *  share of the flow.
 *
 * Compressors feeding one charge sit at one outlet pressure; each passes the
 * flow its own map gives at that pressure and its own speed. The ratio is
 * the one at which those flows add up to the flow drawn, found by bisection
 * (the total falls with the ratio). A compressor that cannot reach the ratio
 * at its speed passes nothing (it would surge). One compressor needs no
 * search: the map gives the ratio from the flow directly.
 */
template <std::size_t N>
[[nodiscard]] inline double parallelCompressorPressureRatio(
    const ForcedInductionConfig& config, double designMassFlowKgPerSecond,
    const std::array<double, N>& angularSpeedRadPerSecond, std::size_t count,
    double totalMassFlowKgPerSecond, double inletTemperatureK, double inletPressureKpa,
    std::array<double, N>& massFlowKgPerSecond) noexcept {
    count = std::clamp<std::size_t>(count, 1, N);
    massFlowKgPerSecond.fill(0.0);
    const auto total = std::max(0.0, totalMassFlowKgPerSecond);
    if (count == 1) {
        massFlowKgPerSecond[0] = total;
        return compressorOperatingPoint(config, designMassFlowKgPerSecond, angularSpeedRadPerSecond[0],
            total, inletTemperatureK, inletPressureKpa).pressureRatio;
    }
    const auto designOmega = std::max(1.0, config.designShaftSpeedRpm * 2.0 * std::numbers::pi / 60.0);
    const auto temperatureK = std::max(150.0, inletTemperatureK);
    const auto flowScale = designMassFlowKgPerSecond * (std::max(1.0, inletPressureKpa)
        / compressorReferencePressureKpa) / std::sqrt(temperatureK / compressorReferenceTemperatureK);
    const auto designHead = std::pow(std::max(1.0, config.pressureRatio), turboIsentropicExponent) - 1.0;
    constexpr auto chokeFourth = compressorChokeFlowCoefficientRatio * compressorChokeFlowCoefficientRatio
        * compressorChokeFlowCoefficientRatio * compressorChokeFlowCoefficientRatio;
    const auto psi0 = 1.0 / (1.0 - 1.0 / chokeFourth);
    // Each compressor's flow at a ratio: the map read backwards.
    const auto flowAt = [&](std::size_t index, double ratio) {
        const auto speed = std::max(0.0, angularSpeedRadPerSecond[index]) / designOmega
            * std::sqrt(compressorReferenceTemperatureK / temperatureK);
        if (speed < 1.0e-6) return ratio <= 1.0 ? total / static_cast<double>(count) : 0.0;
        const auto psi = (std::pow(std::max(1.0, ratio), turboIsentropicExponent) - 1.0)
            / (designHead * speed * speed);
        if (psi >= psi0) return 0.0;
        const auto phi = compressorChokeFlowCoefficientRatio * std::pow(1.0 - psi / psi0, 0.25);
        return phi * speed * flowScale;
    };
    auto highest = 1.0;
    for (std::size_t index = 0; index < count; ++index)
        highest = std::max(highest, compressorOperatingPoint(config, designMassFlowKgPerSecond,
            angularSpeedRadPerSecond[index], 0.0, inletTemperatureK, inletPressureKpa).pressureRatio);
    auto low = 1.0;
    auto high = highest;
    const auto sumAt = [&](double ratio) {
        auto sum = 0.0;
        for (std::size_t index = 0; index < count; ++index) sum += flowAt(index, ratio);
        return sum;
    };
    if (sumAt(low) <= total) {
        // Even at no pressure rise they cannot pass the flow: choked.
        high = low;
    } else {
        for (int iteration = 0; iteration < 40; ++iteration) {
            const auto middle = 0.5 * (low + high);
            (sumAt(middle) > total ? low : high) = middle;
        }
    }
    const auto ratio = 0.5 * (low + high);
    auto sum = 0.0;
    for (std::size_t index = 0; index < count; ++index) {
        massFlowKgPerSecond[index] = flowAt(index, ratio);
        sum += massFlowKgPerSecond[index];
    }
    // Share the drawn flow in the proportions the maps give.
    for (std::size_t index = 0; index < count; ++index)
        massFlowKgPerSecond[index] = sum > 0.0 ? total * massFlowKgPerSecond[index] / sum
                                               : total / static_cast<double>(count);
    return ratio;
}

/** Isentropic compressor work at the measured through-flow and pressure. */
[[nodiscard]] inline double compressorPowerForPressureRatioWatts(
    const ForcedInductionConfig& config,
    double massFlowKgPerSecond,
    double inletTemperatureK,
    double pressureRatio) noexcept {
    return std::max(0.0, massFlowKgPerSecond) * turboAirCpJPerKgK
        * std::max(1.0, inletTemperatureK)
        * (std::pow(std::max(1.0, pressureRatio),
             turboIsentropicExponent) - 1.0)
        / std::max(0.35, config.compressorEfficiency);
}

/** Past its top speed line a compressor's efficiency falls as
 *  (line / speed)^8: the inducer runs supersonic, its shock losses grow fast,
 *  and maps stop there (a modelling choice; no published curve goes past a
 *  map's last line). Half the efficiency 9 % over the line, a quarter 19 %
 *  over: the wheel absorbs that much more shaft power for the same head and
 *  heats its charge as much, so a turbine fed without limit (a wastegate too
 *  small, a fuel with more energy per kilogram of oxygen than any real one)
 *  holds the shaft a little past its line instead of spinning it to three
 *  times its design speed and ten bar (journal 2026-11-11). Exactly 1 up to
 *  the line. */
inline constexpr double turboOverspeedEfficiencyExponent = 8.0;
/** Wheel damage per second past the line: 2 x (overspeed share)^2, so 10 %
 *  over bursts the wheel in about 50 s, 20 % in 13 s, 30 % in 6 s. */
inline constexpr double turboOverspeedDamagePerSecond = 2.0;

[[nodiscard]] inline double compressorOverspeedEfficiencyScale(
    const ForcedInductionConfig& config, double angularSpeedRadPerSecond) noexcept {
    const auto topOmega = turboMaximumShaftSpeedRpm(config) * 2.0 * std::numbers::pi / 60.0;
    if (!(topOmega > 0.0) || !(angularSpeedRadPerSecond > topOmega)) return 1.0;
    return std::pow(angularSpeedRadPerSecond / topOmega, -turboOverspeedEfficiencyExponent);
}

/** Advance kinetic shaft energy without an undocumented speed sink.
 *
 * The update is exact in energy for zero-order-held powers:
 *
 *   E[n+1] = max(0, E[n] + (P_t - P_c - P_b) dt)
 *
 * A previous implementation clamped speed after this equation and silently
 * discarded the excess energy. Here every watt is either compressor work,
 * authored bearing loss, or retained shaft kinetic energy. Wastegate control
 * remains the physical means of reducing turbine input power.
 */
[[nodiscard]] inline TurboShaftAdvance advanceTurboShaft(
    const ForcedInductionConfig& config,
    double angularSpeedRadPerSecond,
    double turbinePowerWatts,
    double compressorMassFlowKgPerSecond,
    double inletTemperatureK,
    double measuredPressureRatio,
    double dtSeconds) noexcept {
    TurboShaftAdvance result;
    const auto omega = std::max(0.0, angularSpeedRadPerSecond);
    const auto inertia = std::max(1.0e-12, config.shaftInertiaKgM2);
    const auto designOmega = config.designShaftSpeedRpm
        * 2.0 * std::numbers::pi / 60.0;
    const auto speedRatio = omega / std::max(1.0, designOmega);
    // Past the top speed line the same head costs more work.
    const auto requestedCompressorPowerWatts =
        compressorPowerForPressureRatioWatts(
            config, compressorMassFlowKgPerSecond, inletTemperatureK,
            measuredPressureRatio)
        / compressorOverspeedEfficiencyScale(config, omega);
    const auto requestedBearingPowerWatts = std::max(0.0,
        config.bearingFrictionPowerWatts) * speedRatio * speedRatio;
    result.energyBeforeJoules = 0.5 * inertia * omega * omega;
    const auto turbinePower = std::max(0.0, turbinePowerWatts);
    const auto dt = std::max(0.0, dtSeconds);
    auto deliveredLossScale = 1.0;
    const auto requestedLossPower = requestedCompressorPowerWatts
        + requestedBearingPowerWatts;
    if (dt > 0.0 && requestedLossPower > 0.0) {
        // A stopped shaft cannot deliver more work than the turbine supplies
        // plus the kinetic energy available during this step. Scale both
        // zero-order-held loss channels together if the requested work would
        // otherwise drive kinetic energy negative.
        const auto availableLossPower = turbinePower
            + result.energyBeforeJoules / dt;
        deliveredLossScale = std::min(
            1.0, availableLossPower / requestedLossPower);
    }
    result.compressorPowerWatts = requestedCompressorPowerWatts
        * deliveredLossScale;
    result.bearingPowerWatts = requestedBearingPowerWatts
        * deliveredLossScale;
    result.netPowerWatts = turbinePower - result.compressorPowerWatts
        - result.bearingPowerWatts;
    result.energyAfterJoules = result.energyBeforeJoules
        + result.netPowerWatts * dt;
    // Only floating-point roundoff may put a conservative stopped shaft a few
    // ulps below zero; there is no positive-energy ceiling here.
    result.energyAfterJoules = std::max(0.0, result.energyAfterJoules);
    result.angularSpeedRadPerSecond = std::sqrt(
        2.0 * result.energyAfterJoules / inertia);
    result.compressorPressureRatio = compressorPressureRatioFromSpeed(
        config, result.angularSpeedRadPerSecond);
    return result;
}

/** Conservatively partitions the measured exhaust flow through the parallel
 *  effective turbine and wastegate throats. The same split drives shaft power
 *  and aeroacoustics so neither subsystem can create or discard bypass flow. */
[[nodiscard]] inline TurboExhaustFlowSplit partitionTurboExhaustFlow(
    const ForcedInductionConfig& config, double totalKgPerSecond,
    double wastegateOpening) noexcept {
    const auto total = std::max(0.0, totalKgPerSecond);
    const auto turbineArea = std::max(0.0, config.turbineFlowAreaMm2);
    const auto wastegateArea = std::max(0.0, config.wastegateFlowAreaMm2)
        * std::clamp(wastegateOpening, 0.0, 1.0);
    const auto effectiveArea = turbineArea + wastegateArea;
    if (!(effectiveArea > 0.0)) return { total, 0.0 };
    const auto bypass = total * wastegateArea / effectiveArea;
    return { total - bypass, bypass };
}

} // namespace enginelab
