#include <enginelab/foundation/EngineTypes.hpp>
#include <enginelab/foundation/CatalystMonolithGeometry.hpp>
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <numbers>
#include <functional>
#include <unordered_map>
#include <unordered_set>
#include <limits>

namespace enginelab {

namespace {
[[nodiscard]] bool validMufflerPacking(const ExhaustConfig& exhaust) noexcept {
    const auto none = exhaust.mufflerPackingFlowResistivityPaSPerM2 == 0.0
        && exhaust.mufflerPackingThicknessMm == 0.0
        && exhaust.mufflerPerforatedOpenAreaRatio == 0.0;
    const auto complete = exhaust.mufflerPackingFlowResistivityPaSPerM2 > 0.0
        && exhaust.mufflerPackingThicknessMm > 0.0
        && exhaust.mufflerPerforatedOpenAreaRatio > 0.0
        && exhaust.mufflerChamberDiameterMm > 1.0
        && exhaust.mufflerChamberLengthMm > 1.0;
    return none || complete;
}

[[nodiscard]] bool validMidpipe(const ExhaustConfig& exhaust) noexcept {
    const auto length = exhaust.midpipeLengthMm;
    const auto diameter = exhaust.midpipeDiameterMm;
    return std::isfinite(length) && length >= 0.0 && length <= 30'000.0
        && std::isfinite(diameter)
        && (diameter == 0.0 || (diameter >= 4.0 && diameter <= 1'500.0));
}

[[nodiscard]] IntakePathConfig makeDefaultIntakePath(const EngineConfig& config) {
    IntakePathConfig path;
    path.id = 1;
    path.geometry = config.intake;
    path.inheritsGlobalGeometry = true;
    for (const auto& cylinder : config.cylinders) path.cylinderIds.push_back(cylinder.id);
    return path;
}

[[nodiscard]] ExhaustPathConfig makeDefaultExhaustPath(const EngineConfig& config) {
    ExhaustPathConfig path;
    path.id = 1;
    path.geometry = config.exhaust;
    path.inheritsGlobalGeometry = true;
    for (const auto& cylinder : config.cylinders) path.cylinderIds.push_back(cylinder.id);
    return path;
}

/** The six scalars that tell the built-in engines apart. The rest of
 *  `CamshaftConfig` keeps its defaults, and naming them here keeps the
 *  built-in engines out of the positional-initialisation trap. */
[[nodiscard]] CamshaftConfig cam(double intakeDuration, double exhaustDuration, double intakeLift,
                                 double exhaustLift, double intakeCentre, double exhaustCentre) {
    CamshaftConfig cams;
    cams.intakeDurationDegrees = intakeDuration;
    cams.exhaustDurationDegrees = exhaustDuration;
    cams.intakeLiftMm = intakeLift;
    cams.exhaustLiftMm = exhaustLift;
    cams.intakeCenterlineDegrees = intakeCentre;
    cams.exhaustCenterlineDegrees = exhaustCentre;
    return cams;
}

EngineConfig makeEngine(std::string name, EngineLayout layout, std::uint32_t count,
                        std::vector<std::uint32_t> order, double bore, double stroke,
                        double idle, double redline, double inertia, CamshaftConfig cams) {
    EngineConfig config;
    config.name = std::move(name);
    config.layout = layout;
    config.idleRpm = idle;
    config.redlineRpm = redline;
    config.rotatingInertiaKgM2 = inertia;
    config.plenumVolumeLitres = std::max(0.6, static_cast<double>(count) * 0.70);
    config.throttleDiameterMm = std::clamp(36.0 + static_cast<double>(count) * 4.5, 42.0, 82.0);
    config.bankAngleDegrees = layout == EngineLayout::vLayout ? 60.0
        : (layout == EngineLayout::flat ? 180.0 : 0.0);
    config.camshafts = cams;
    config.intake.plenumVolumeLitres = config.plenumVolumeLitres;
    config.intake.throttleDiameterMm = config.throttleDiameterMm;
    config.ignition.revLimitRpm = redline;
    config.cylinders.reserve(count);
    const auto spacing = 720.0 / static_cast<double>(count);
    for (std::uint32_t id = 1; id <= count; ++id) {
        CylinderConfig cylinder;
        cylinder.id = id;
        cylinder.boreMm = bore;
        cylinder.strokeMm = stroke;
        cylinder.efficiencyOffset = (static_cast<double>(id) - (static_cast<double>(count) + 1.0) * 0.5) * 0.003;
        const auto it = std::find(order.begin(), order.end(), id);
        if (it != order.end()) {
            const auto orderIndex = static_cast<double>(std::distance(order.begin(), it));
            cylinder.crankOffsetDegrees = orderIndex * spacing;
        } else {
            cylinder.crankOffsetDegrees = 0.0;
        }
        cylinder.crankJournalId = id;
        if (layout == EngineLayout::vLayout) {
            cylinder.bankOffsetDegrees = id % 2U == 0U ? config.bankAngleDegrees * 0.5 : -config.bankAngleDegrees * 0.5;
        } else if (layout == EngineLayout::flat) {
            cylinder.bankOffsetDegrees = id % 2U == 0U ? 90.0 : -90.0;
        }
        config.crankJournals.push_back({ id,
            cylinder.crankOffsetDegrees - cylinder.bankOffsetDegrees, stroke * 0.5, 1 });
        config.cylinders.push_back(cylinder);
    }
    config.firingOrder = std::move(order);
    if (layout == EngineLayout::vLayout || layout == EngineLayout::flat) {
        CylinderBankConfig left { 1, -config.bankAngleDegrees * 0.5, {}, cams, 1, 1 };
        CylinderBankConfig right { 2, config.bankAngleDegrees * 0.5, {}, cams, 1, 1 };
        for (auto& cylinder : config.cylinders) {
            cylinder.bankId = cylinder.id % 2U == 0U ? right.id : left.id;
            (cylinder.id % 2U == 0U ? right.cylinderIds : left.cylinderIds).push_back(cylinder.id);
        }
        config.banks = { std::move(left), std::move(right) };
    } else {
        CylinderBankConfig bank { 1, 0.0, {}, cams, 1, 1 };
        for (auto& cylinder : config.cylinders) {
            cylinder.bankId = bank.id;
            bank.cylinderIds.push_back(cylinder.id);
        }
        config.banks.push_back(std::move(bank));
    }
    ExhaustPathConfig path;
    path.id = 1;
    path.geometry = config.exhaust;
    path.inheritsGlobalGeometry = true;
    for (const auto& cylinder : config.cylinders) path.cylinderIds.push_back(cylinder.id);
    config.exhaustPaths.push_back(std::move(path));
    normaliseEngineConfig(config);
    return config;
}
}

EngineConfig makeDefaultInlineFour() {
    return makeEngine("EL-20 I4", EngineLayout::inlineLayout, 4, { 1, 3, 4, 2 },
                      86.0, 86.0, 850.0, 7'200.0, 0.24, {});
}

EngineConfig makeDefaultInlineTwo() {
    return makeEngine("EL-09 I2", EngineLayout::inlineLayout, 2, { 1, 2 },
                      84.0, 81.0, 1'050.0, 8'200.0, 0.13, cam(262.0, 256.0, 10.8, 10.3, 108.0, 110.0));
}

EngineConfig makeDefaultInlineFive() {
    return makeEngine("EL-25 I5", EngineLayout::inlineLayout, 5, { 1, 2, 4, 5, 3 },
                      82.5, 92.8, 780.0, 6'800.0, 0.29, cam(252.0, 248.0, 10.5, 10.0, 110.0, 112.0));
}

EngineConfig makeDefaultV6() {
    return makeEngine("EL-30 V6", EngineLayout::vLayout, 6, { 1, 4, 2, 5, 3, 6 },
                      86.0, 86.0, 750.0, 7'000.0, 0.32, cam(256.0, 252.0, 11.0, 10.5, 109.0, 111.0));
}

EngineConfig makeDefaultV8() {
    auto config = makeEngine("EL-50 V8", EngineLayout::vLayout, 8, { 1, 5, 4, 8, 6, 3, 7, 2 },
                             94.0, 90.0, 720.0, 6'600.0, 0.46, cam(268.0, 264.0, 12.0, 11.5, 108.0, 110.0));
    config.frictionCoefficient = 0.15;
    config.bankAngleDegrees = 90.0;
    for (auto& cylinder : config.cylinders) {
        cylinder.bankOffsetDegrees = cylinder.id % 2U == 0U ? 45.0 : -45.0;
        cylinder.intakeValveCount = 1;
        cylinder.exhaustValveCount = 1;
    }
    for (auto& journal : config.crankJournals) {
        const auto cylinder = std::find_if(config.cylinders.begin(), config.cylinders.end(),
            [&journal](const CylinderConfig& item) { return item.crankJournalId == journal.id; });
        if (cylinder != config.cylinders.end())
            journal.angleDegrees = cylinder->crankOffsetDegrees - cylinder->bankOffsetDegrees;
    }
    if (config.banks.size() == 2) {
        config.banks[0].angleDegrees = -45.0;
        config.banks[1].angleDegrees = 45.0;
    }
    normaliseEngineConfig(config);
    return config;
}

EngineConfig makeDefaultFlatSix() {
    auto config = makeEngine("EL-36 F6", EngineLayout::flat, 6, { 1, 6, 2, 4, 3, 5 },
                             97.0, 81.5, 780.0, 7'600.0, 0.33,
                             cam(270.0, 266.0, 12.3, 11.9, 106.0, 109.0));
    config.frictionCoefficient = 0.13;
    config.intake.plenumVolumeLitres = 4.2;
    config.intake.throttleDiameterMm = 74.0;
    if (config.intakePaths.size() == 1) config.intakePaths.front().geometry = config.intake;
    config.exhaust = { 720.0, 42.0, 66.0, 0.22, 74.0 };
    if (config.exhaustPaths.size() == 1) config.exhaustPaths.front().geometry = config.exhaust;
    config.transmission = { { 3.82, 2.20, 1.52, 1.22, 1.02, 0.84 }, 3.44, 980.0 };
    config.vehicle = { 1'430.0, 0.30, 2.04, 0.325, 0.013 };
    normaliseEngineConfig(config);
    return config;
}

EngineConfig makeDefaultRadialFive() {
    EngineConfig config;
    config.name = "EL-R5 Radial";
    config.layout = EngineLayout::radial;
    config.firingOrder = { 1, 3, 5, 2, 4 };
    config.idleRpm = 640.0;
    config.redlineRpm = 3'200.0;
    config.ignition.revLimitRpm = 3'200.0;
    config.rotatingInertiaKgM2 = 0.86;
    config.frictionCoefficient = 0.19;
    config.octaneRating = 92.0;
    config.coolingEfficiency = 2.6;
    config.plenumVolumeLitres = 6.4;
    config.throttleDiameterMm = 82.0;
    config.bankAngleDegrees = 72.0;
    config.camshafts = { 246.0, 250.0, 11.6, 11.2, 106.0, 110.0 };
    config.exhaust = { 920.0, 54.0, 96.0, 0.08, 110.0 };
    config.transmission = { { 1.0 }, 1.0, 6'800.0 };
    config.vehicle = { 1'000.0, 0.30, 2.0, 0.320, 0.014 };
    config.thermal = { 820.0, 430.0, 0.24, 0.16, 0.92, 0.46 };
    config.crankJournals.push_back({ 1, 0.0, 63.5, 1 });
    constexpr std::uint32_t count = 5;
    for (std::uint32_t id = 1; id <= count; ++id) {
        CylinderConfig cylinder;
        cylinder.id = id;
        cylinder.boreMm = 114.0;
        cylinder.strokeMm = 127.0;
        cylinder.connectingRodMm = 228.0;
        cylinder.pistonMassGrams = 1'050.0;
        cylinder.compressionRatio = 7.0;
        cylinder.intakeValveCount = 1;
        cylinder.exhaustValveCount = 1;
        cylinder.intakeValveDiameterMm = 49.0;
        cylinder.exhaustValveDiameterMm = 42.0;
        cylinder.efficiencyOffset = (static_cast<double>(id) - 3.0) * 0.004;
        const auto order = std::find(config.firingOrder.begin(), config.firingOrder.end(), id);
        cylinder.crankOffsetDegrees = order == config.firingOrder.end() ? 0.0
            : static_cast<double>(std::distance(config.firingOrder.begin(), order)) * (720.0 / static_cast<double>(count));
        cylinder.crankJournalId = 1;
        cylinder.connectingRodType = id == 1 ? ConnectingRodType::master : ConnectingRodType::articulated;
        cylinder.masterCylinderId = id == 1 ? 0 : 1;
        cylinder.articulatedJournalRadiusMm = id == 1 ? 0.0 : 34.0;
        cylinder.articulatedJournalAngleDegrees = static_cast<double>(id - 1U) * 72.0;
        cylinder.bankOffsetDegrees = static_cast<double>(id - 1U) * (360.0 / static_cast<double>(count));
        config.cylinders.push_back(cylinder);
    }
    normaliseEngineConfig(config);
    return config;
}

std::vector<EngineConfig> makeBaseEnginePresets() {
    return { makeDefaultInlineTwo(), makeDefaultInlineFour(), makeDefaultInlineFive(), makeDefaultV6(),
             makeDefaultV8(), makeDefaultFlatSix(), makeDefaultRadialFive() };
}

double engineDisplacementLitres(const EngineConfig& config) noexcept {
    double cubicMillimetres = 0.0;
    for (const auto& cylinder : config.cylinders)
        cubicMillimetres += std::numbers::pi * cylinder.boreMm * cylinder.boreMm * 0.25 * cylinder.strokeMm;
    return cubicMillimetres / 1'000'000.0;
}

double breathingDisplacementLitres(const EngineConfig& config) noexcept {
    const auto litres = engineDisplacementLitres(config);
    return config.cycle == EngineCycle::rotary ? litres * 720.0 / cycleDegreesOf(config.cycle) : litres;
}

double intakeRunnerVolumeLitres(const CylinderConfig& cylinder, const IntakeConfig& fallback) noexcept {
    const auto inletDiameterMm = cylinder.intakeRunnerDiameterMm > 0.0
        ? cylinder.intakeRunnerDiameterMm : fallback.runnerDiameterMm;
    const auto outletDiameterMm = fallback.runnerPlenumDiameterMm > 0.0
        ? fallback.runnerPlenumDiameterMm : inletDiameterMm;
    const auto lengthMm = cylinder.intakeRunnerLengthMm > 0.0
        ? cylinder.intakeRunnerLengthMm : fallback.runnerLengthMm;
    const auto inletRadiusMm = std::max(0.0, inletDiameterMm * 0.5);
    const auto outletRadiusMm = std::max(0.0, outletDiameterMm * 0.5);
    // Exact circular-frustum volume with a radius-linear runner.
    const auto volumeMm3 = std::numbers::pi * std::max(0.0, lengthMm) / 3.0
        * (inletRadiusMm * inletRadiusMm
            + inletRadiusMm * outletRadiusMm
            + outletRadiusMm * outletRadiusMm);
    return std::max(0.001, volumeMm3 / 1'000'000.0);
}

double peakCylinderPressureLimitBar(const EngineConfig& config) noexcept {
    if (config.peakFiringPressureLimitBar > 0.0) return config.peakFiringPressureLimitBar;
    // The upper end of production design limits: a passenger-car diesel
    // 180-200 bar, a boosted spark-ignition engine 120-140, a naturally
    // aspirated one 100-120.
    if (config.fuel == FuelType::diesel) return 200.0;
    return config.forcedInduction.enabled ? 140.0 : 120.0;
}

const CarburettorConfig* idleCarburettor(const EngineConfig& config) noexcept {
    for (const auto& path : config.intakePaths)
        if (path.geometry.carburettor.enabled) return &path.geometry.carburettor;
    if (config.intakePaths.empty() && config.intake.carburettor.enabled) return &config.intake.carburettor;
    return nullptr;
}

double effectiveRotatingInertiaKgM2(const EngineConfig& config) noexcept {
    if (config.crankshafts.empty()) return std::max(0.001, config.rotatingInertiaKgM2);
    double inertia = 0.0;
    for (const auto& crankshaft : config.crankshafts)
        inertia += std::max(0.0, crankshaft.momentOfInertiaKgM2)
            * crankshaft.rotationRatio * crankshaft.rotationRatio;
    for (const auto& cylinder : config.cylinders) {
        if (cylinder.connectingRodMomentOfInertiaKgM2 > 0.0) {
            inertia += cylinder.connectingRodMomentOfInertiaKgM2;
        } else {
            const auto radiusM = cylinder.strokeMm * 0.0005;
            inertia += cylinder.connectingRodMassGrams * 0.001 * (2.0 / 3.0) * radiusM * radiusM;
        }
    }
    return inertia > 0.0 ? inertia : std::max(0.001, config.rotatingInertiaKgM2);
}

double valveFlowCoefficient(double liftMm, double fallback,
                            const std::vector<ValveFlowSample>& samples) noexcept {
    if (samples.empty()) return std::max(0.0, fallback);
    if (liftMm <= samples.front().liftMm) return std::max(0.0, samples.front().dischargeCoefficient);
    if (liftMm >= samples.back().liftMm) return std::max(0.0, samples.back().dischargeCoefficient);
    for (std::size_t index = 1; index < samples.size(); ++index) {
        if (liftMm <= samples[index].liftMm) {
            const auto span = std::max(1.0e-12, samples[index].liftMm - samples[index - 1].liftMm);
            const auto amount = std::clamp((liftMm - samples[index - 1].liftMm) / span, 0.0, 1.0);
            return std::max(0.0, std::lerp(samples[index - 1].dischargeCoefficient,
                                           samples[index].dischargeCoefficient, amount));
        }
    }
    return std::max(0.0, fallback);
}

ValveControlSample interpolateValveControl(const ValveControlConfig& control, double rpm,
                                           double load) noexcept {
    ValveControlSample result;
    result.rpm = rpm;
    result.load = load;
    if (!control.enabled || control.samples.empty()) return result;
    const auto [minimumRpm, maximumRpm] = std::minmax_element(control.samples.begin(), control.samples.end(),
        [](const auto& left, const auto& right) { return left.rpm < right.rpm; });
    const auto [minimumLoad, maximumLoad] = std::minmax_element(control.samples.begin(), control.samples.end(),
        [](const auto& left, const auto& right) { return left.load < right.load; });
    const auto clampedRpm = std::clamp(rpm, minimumRpm->rpm, maximumRpm->rpm);
    const auto clampedLoad = std::clamp(load, minimumLoad->load, maximumLoad->load);
    auto lowerRpm = minimumRpm->rpm;
    auto upperRpm = maximumRpm->rpm;
    auto lowerLoad = minimumLoad->load;
    auto upperLoad = maximumLoad->load;
    for (const auto& sample : control.samples) {
        if (sample.rpm <= clampedRpm) lowerRpm = std::max(lowerRpm, sample.rpm);
        if (sample.rpm >= clampedRpm) upperRpm = std::min(upperRpm, sample.rpm);
        if (sample.load <= clampedLoad) lowerLoad = std::max(lowerLoad, sample.load);
        if (sample.load >= clampedLoad) upperLoad = std::min(upperLoad, sample.load);
    }
    const auto sampleAt = [&control](double sampleRpm, double sampleLoad) noexcept
        -> const ValveControlSample* {
        const auto item = std::find_if(control.samples.begin(), control.samples.end(),
            [sampleRpm, sampleLoad](const ValveControlSample& sample) {
                return std::abs(sample.rpm - sampleRpm) <= 1.0e-9
                    && std::abs(sample.load - sampleLoad) <= 1.0e-12;
            });
        return item == control.samples.end() ? nullptr : &*item;
    };
    const auto* lowerLower = sampleAt(lowerRpm, lowerLoad);
    const auto* upperLower = sampleAt(upperRpm, lowerLoad);
    const auto* lowerUpper = sampleAt(lowerRpm, upperLoad);
    const auto* upperUpper = sampleAt(upperRpm, upperLoad);
    if (lowerLower != nullptr && upperLower != nullptr
            && lowerUpper != nullptr && upperUpper != nullptr) {
        const auto rpmAmount = upperRpm > lowerRpm
            ? (clampedRpm - lowerRpm) / (upperRpm - lowerRpm) : 0.0;
        const auto loadAmount = upperLoad > lowerLoad
            ? (clampedLoad - lowerLoad) / (upperLoad - lowerLoad) : 0.0;
        const auto bilinear = [rpmAmount, loadAmount](double ll, double ul,
                                                       double lu, double uu) noexcept {
            return std::lerp(std::lerp(ll, ul, rpmAmount),
                             std::lerp(lu, uu, rpmAmount), loadAmount);
        };
        result.intakeAdvanceDegrees = bilinear(lowerLower->intakeAdvanceDegrees,
            upperLower->intakeAdvanceDegrees, lowerUpper->intakeAdvanceDegrees,
            upperUpper->intakeAdvanceDegrees);
        result.exhaustAdvanceDegrees = bilinear(lowerLower->exhaustAdvanceDegrees,
            upperLower->exhaustAdvanceDegrees, lowerUpper->exhaustAdvanceDegrees,
            upperUpper->exhaustAdvanceDegrees);
        result.liftMultiplier = bilinear(lowerLower->liftMultiplier,
            upperLower->liftMultiplier, lowerUpper->liftMultiplier,
            upperUpper->liftMultiplier);
        return result;
    }

    // Schema-v1 accepted sparse point clouds. Retain a deterministic fallback
    // for those files, but clamp at the calibrated axes so extrapolation can
    // never drift beyond the edge cells of a tuning table.
    // A sparse table is a SCHEDULE, so interpolate along it in rpm rather than
    // averaging it isotropically.
    //
    // This used to be inverse-distance (Shepard) weighting over all samples in a
    // normalised rpm/load plane. That is wrong for a cam-phaser map in a way
    // that is invisible until it is measured: Shepard weighting is not monotone
    // between neighbours, so every sample pulls on every query, and a schedule
    // whose author wrote "advance hard in the midrange, then fall back at the
    // top" instead gets the midrange value smeared across the whole upper range.
    // Measured on the K20A, whose sport_na table asks for 28 deg of intake
    // advance at 6000 rpm and 12 deg at 8500: the old fallback still delivered
    // 26 deg at 5000 and never came back, holding intake valve closing ~30 deg
    // early through the entire power band. Disabling the phaser outright was
    // worth +16 % peak power, which is the size of the error being corrected
    // here. See physics-audit.md (archive/docs-2026-09 tag).
    //
    // Piecewise-linear in rpm is monotone between authored points, reproduces
    // the authored value exactly at each of them, and cannot extrapolate past
    // the ends (rpm is clamped above). Samples sharing an rpm are blended by
    // load first, so a table that does vary load at fixed rpm still works.
    auto lowerIndex = control.samples.size();
    auto upperIndex = control.samples.size();
    for (std::size_t index = 0; index < control.samples.size(); ++index) {
        const auto& sample = control.samples[index];
        if (sample.rpm <= clampedRpm
            && (lowerIndex == control.samples.size()
                || sample.rpm > control.samples[lowerIndex].rpm
                || (sample.rpm == control.samples[lowerIndex].rpm
                    && std::abs(sample.load - clampedLoad)
                        < std::abs(control.samples[lowerIndex].load - clampedLoad))))
            lowerIndex = index;
        if (sample.rpm >= clampedRpm
            && (upperIndex == control.samples.size()
                || sample.rpm < control.samples[upperIndex].rpm
                || (sample.rpm == control.samples[upperIndex].rpm
                    && std::abs(sample.load - clampedLoad)
                        < std::abs(control.samples[upperIndex].load - clampedLoad))))
            upperIndex = index;
    }
    if (lowerIndex == control.samples.size()) lowerIndex = upperIndex;
    if (upperIndex == control.samples.size()) upperIndex = lowerIndex;
    if (lowerIndex == control.samples.size()) return result;
    const auto& lower = control.samples[lowerIndex];
    const auto& upper = control.samples[upperIndex];
    const auto amount = upper.rpm > lower.rpm
        ? (clampedRpm - lower.rpm) / (upper.rpm - lower.rpm) : 0.0;
    result.intakeAdvanceDegrees = std::lerp(lower.intakeAdvanceDegrees,
        upper.intakeAdvanceDegrees, amount);
    result.exhaustAdvanceDegrees = std::lerp(lower.exhaustAdvanceDegrees,
        upper.exhaustAdvanceDegrees, amount);
    result.liftMultiplier = std::lerp(lower.liftMultiplier, upper.liftMultiplier, amount);
    return result;
}

void disableBackfires(EngineConfig& config) noexcept {
    config.exhaustAfterfire.strategy = ExhaustAfterfireStrategy::cleanDfco;
    config.exhaustAfterfire.enabled = false;
    config.ignition.limiterKeepsFuel = false;
}

void keepBackfires(const EngineConfig& running, EngineConfig& edited) noexcept {
    edited.exhaustAfterfire = running.exhaustAfterfire;
    edited.ignition.limiterKeepsFuel = running.ignition.limiterKeepsFuel;
}

const CamshaftConfig& camshaftOfCylinder(const EngineConfig& config, const CylinderConfig& cylinder) noexcept {
    for (const auto& bank : config.banks)
        if (bank.id == cylinder.bankId
            || std::find(bank.cylinderIds.begin(), bank.cylinderIds.end(), cylinder.id) != bank.cylinderIds.end())
            return bank.camshafts;
    return config.camshafts;
}

const CamshaftConfig* firstVtecCamshaft(const EngineConfig& config) noexcept {
    if (config.cycle == EngineCycle::twoStroke) return nullptr;
    for (const auto& cylinder : config.cylinders)
        if (const auto& cam = camshaftOfCylinder(config, cylinder); cam.variableProfileEnabled) return &cam;
    return nullptr;
}

bool exhaustValveFitted(const EngineConfig& config) noexcept {
    for (const auto& path : config.exhaustPaths)
        if (path.network)
            for (const auto& component : path.network->components)
                if (component.inletValve) return true;
    return false;
}

bool vtecCamsFitted(const EngineConfig& config) noexcept {
    return firstVtecCamshaft(config) != nullptr;
}

namespace {

/** A custom lift profile stretched to another duration and lift: the high
 *  cam keeps the low cam's shape. */
[[nodiscard]] std::vector<ValveLiftSample> stretchedLiftProfile(const std::vector<ValveLiftSample>& samples,
    double fromDuration, double toDuration, double fromLift, double toLift) {
    const auto angleScale = fromDuration > 0.0 ? toDuration / fromDuration : 1.0;
    const auto liftScale = fromLift > 0.0 ? toLift / fromLift : 1.0;
    auto stretched = samples;
    for (auto& sample : stretched) {
        sample.angleDegrees *= angleScale;
        sample.liftMm = std::clamp(sample.liftMm * liftScale, 0.0, toLift);
    }
    return stretched;
}

} // namespace

bool fitVtecCams(EngineConfig& config) {
    if (config.cycle == EngineCycle::twoStroke) return false;
    const auto rotary = config.cycle == EngineCycle::rotary;
    // The catalogue K20A (parts/camshafts.yaml sport_na): 268/264 deg and
    // 12.2/11.8 mm under a 292/286 deg, 13.2/12.4 mm high cam, engaging at
    // 5,800 rpm of its 8,700 rpm limit above 55 % throttle.
    const auto engage = std::clamp(std::round(config.ignition.revLimitRpm * (2.0 / 3.0) / 50.0) * 50.0,
                                   200.0, 25'000.0);
    auto fitted = false;
    const auto fit = [&](CamshaftConfig& cam) {
        if (cam.variableProfileEnabled) return;
        cam.variableProfileEnabled = true;
        cam.switchRpm = engage;
        cam.switchThrottle = 0.55;
        cam.highIntakeDurationDegrees = std::min(cam.intakeDurationDegrees + 24.0, 720.0);
        cam.highIntakeLiftMm = std::min(cam.intakeLiftMm + 1.0, 150.0);
        cam.highExhaustDurationDegrees = rotary ? cam.exhaustDurationDegrees
                                                : std::min(cam.exhaustDurationDegrees + 22.0, 720.0);
        cam.highExhaustLiftMm = rotary ? cam.exhaustLiftMm : std::min(cam.exhaustLiftMm + 0.6, 150.0);
        cam.highIntakeLiftProfile = cam.intakeLiftProfile.size() < 2 ? std::vector<ValveLiftSample> {}
            : stretchedLiftProfile(cam.intakeLiftProfile, cam.intakeDurationDegrees, cam.highIntakeDurationDegrees,
                                   cam.intakeLiftMm, cam.highIntakeLiftMm);
        cam.highExhaustLiftProfile = cam.exhaustLiftProfile.size() < 2 ? std::vector<ValveLiftSample> {}
            : stretchedLiftProfile(cam.exhaustLiftProfile, cam.exhaustDurationDegrees, cam.highExhaustDurationDegrees,
                                   cam.exhaustLiftMm, cam.highExhaustLiftMm);
        fitted = true;
    };
    fit(config.camshafts);
    for (auto& bank : config.banks) fit(bank.camshafts);
    return fitted;
}

void removeVtecCams(EngineConfig& config) noexcept {
    config.camshafts.variableProfileEnabled = false;
    for (auto& bank : config.banks) bank.camshafts.variableProfileEnabled = false;
}

void normaliseEngineConfig(EngineConfig& config) {
    // Schema 2 added authored exhaust DAGs/topology provenance; schema 3 adds
    // explicit valve geometry; schema 4 adds SI outlet/observer coordinates;
    // schema 5 adds authored vehicle layout and longitudinal load-transfer
    // geometry; schema 6 makes the overrun strategy explicit and adds local
    // induction/flammability/quench calibration; schema 7 adds explicit
    // cellular catalyst-substrate geometry; schema 8 replaces the afterfire's
    // flat induction clock with an explicitly parameterised Livengood-Wu
    // correlation; schema 9 adds explicit paired ports and passive coupling
    // for a four-port exhaust crossover. Older documents migrate to the
    // documented defaults below.
    const auto sourceSchemaVersion = config.schemaVersion;
    if (config.schemaVersion < currentEngineSchemaVersion)
        config.schemaVersion = currentEngineSchemaVersion;
    // The exhaust chemistry runs with the backfire strategy: schema <=5
    // files and the removed anti-lag and chopped strategies read as clean.
    config.exhaustAfterfire.enabled = afterfireRetainsFuel(
        config.exhaustAfterfire.strategy);
    if (sourceSchemaVersion < 8) {
        // Schema <=7 accumulated wall-clock seconds once the threshold was
        // crossed. Zero exponents reproduce that behaviour exactly, while the
        // old `-0.5 seconds per second` cooldown becomes a dimensionless full
        // decay time of 2*tau_ref.
        config.exhaustAfterfire.inductionReferencePressureKpa = 101.325;
        config.exhaustAfterfire.inductionActivationTemperatureK = 0.0;
        config.exhaustAfterfire.inductionPressureExponent = 0.0;
        config.exhaustAfterfire.inductionEquivalenceRatioExponent = 0.0;
        config.exhaustAfterfire.inductionDecayTimeSeconds =
            2.0 * config.exhaustAfterfire.inductionTimeSeconds;
    }
    // `intake` is the canonical representation. Legacy scalar fields remain
    // mirrored so schema-v1 files and old catalog overrides remain compatible.
    if (config.intake.plenumVolumeLitres == IntakeConfig {}.plenumVolumeLitres
        && config.plenumVolumeLitres != EngineConfig {}.plenumVolumeLitres)
        config.intake.plenumVolumeLitres = config.plenumVolumeLitres;
    if (config.intake.throttleDiameterMm == IntakeConfig {}.throttleDiameterMm
        && config.throttleDiameterMm != EngineConfig {}.throttleDiameterMm)
        config.intake.throttleDiameterMm = config.throttleDiameterMm;
    config.plenumVolumeLitres = config.intake.plenumVolumeLitres;
    config.throttleDiameterMm = config.intake.throttleDiameterMm;
    if (!(config.acousticObserver.soundSpeedMps > 0.0)
        || !std::isfinite(config.acousticObserver.soundSpeedMps)) {
        constexpr double dryAirGamma = 1.4;
        constexpr double dryAirGasConstantJPerKgK = 287.05;
        config.acousticObserver.soundSpeedMps = std::sqrt(dryAirGamma
            * dryAirGasConstantJPerKgK * (config.ambientTemperatureC + 273.15));
    }

    if (config.crankshafts.empty()) {
        CrankshaftConfig crankshaft;
        crankshaft.momentOfInertiaKgM2 = config.rotatingInertiaKgM2;
        crankshaft.inheritsLegacyInertia = true;
        config.crankshafts.push_back(crankshaft);
    } else {
        // Explicit topology is authoritative. The scalar is a schema-v1
        // migration field and must never erase a deliberately configured
        // crankshaft inertia.
        if (config.crankshafts.size() == 1
                && config.crankshafts.front().inheritsLegacyInertia)
            config.crankshafts.front().momentOfInertiaKgM2 = config.rotatingInertiaKgM2;
        double configuredInertia = 0.0;
        double missingRatioSquared = 0.0;
        for (const auto& crankshaft : config.crankshafts) {
            const auto ratioSquared = crankshaft.rotationRatio * crankshaft.rotationRatio;
            if (crankshaft.momentOfInertiaKgM2 > 0.0)
                configuredInertia += crankshaft.momentOfInertiaKgM2 * ratioSquared;
            else
                missingRatioSquared += ratioSquared;
        }
        const auto inertiaPerMissingRatio = missingRatioSquared > 0.0
            ? std::max(0.001, (config.rotatingInertiaKgM2 - configuredInertia)
                / missingRatioSquared)
            : 0.0;
        for (auto& crankshaft : config.crankshafts)
            if (!(crankshaft.momentOfInertiaKgM2 > 0.0))
                crankshaft.momentOfInertiaKgM2 = inertiaPerMissingRatio;
        config.rotatingInertiaKgM2 = 0.0;
        for (const auto& crankshaft : config.crankshafts)
            config.rotatingInertiaKgM2 += crankshaft.momentOfInertiaKgM2
                * crankshaft.rotationRatio * crankshaft.rotationRatio;
    }
    if (config.crankJournals.empty()) {
        for (auto& cylinder : config.cylinders) {
            cylinder.crankJournalId = cylinder.id;
            config.crankJournals.push_back({ cylinder.id,
                cylinder.crankOffsetDegrees - cylinder.bankOffsetDegrees,
                cylinder.strokeMm * 0.5, config.crankshafts.front().id });
        }
    }
    for (auto& journal : config.crankJournals) {
        if (journal.crankshaftId == 0) journal.crankshaftId = config.crankshafts.front().id;
    }
    if (config.intakePaths.empty()) {
        config.intakePaths.push_back(makeDefaultIntakePath(config));
    }
    // A two-stroke's intake path is its cylinder's crankcase circuit: a
    // shared default intake becomes one copy per cylinder.
    if (config.cycle == EngineCycle::twoStroke && config.intakePaths.size() == 1
        && config.intakePaths.front().inheritsGlobalGeometry && config.cylinders.size() > 1) {
        const auto shared = config.intakePaths.front();
        config.intakePaths.clear();
        for (const auto& cylinder : config.cylinders) {
            auto path = shared;
            path.id = cylinder.id;
            path.cylinderIds = { cylinder.id };
            path.inheritsGlobalGeometry = false;
            config.intakePaths.push_back(std::move(path));
        }
        for (auto& bank : config.banks) bank.intakeId = 0;
    }
    if (config.intakePaths.size() == 1) {
        // As with crankshafts, a serialised path is an explicit topology. Keep
        // the legacy/global view mirrored from it instead of silently
        // overwriting the path during every validation or hot reload.
        if (config.intakePaths.front().inheritsGlobalGeometry)
            config.intakePaths.front().geometry = config.intake;
        else
            config.intake = config.intakePaths.front().geometry;
        config.plenumVolumeLitres = config.intake.plenumVolumeLitres;
        config.throttleDiameterMm = config.intake.throttleDiameterMm;
    }
    for (auto& bank : config.banks) {
        if (bank.intakeId == 0 && !config.intakePaths.empty()) bank.intakeId = config.intakePaths.front().id;
    }
    // A zero bank ID is legacy/unspecified and can be inferred without
    // ambiguity from the authoritative membership lists. Non-zero IDs remain
    // untouched so validation can expose contradictory authored topology.
    for (auto& cylinder : config.cylinders) {
        if (cylinder.bankId != 0) continue;
        const auto bank = std::find_if(config.banks.begin(), config.banks.end(),
            [&cylinder](const auto& candidate) {
                return std::find(candidate.cylinderIds.begin(), candidate.cylinderIds.end(), cylinder.id)
                    != candidate.cylinderIds.end();
            });
        if (bank != config.banks.end()) cylinder.bankId = bank->id;
    }
    if (config.exhaustPaths.empty()) {
        config.exhaustPaths.push_back(makeDefaultExhaustPath(config));
    } else if (config.exhaustPaths.size() == 1) {
        // Generated preset paths continue to mirror the legacy/global
        // geometry. A decoded or authored path is explicit and authoritative.
        if (config.exhaustPaths.front().inheritsGlobalGeometry)
            config.exhaustPaths.front().geometry = config.exhaust;
        else
            config.exhaust = config.exhaustPaths.front().geometry;
    }
}

double rotaryFaceDisplacementLitres(const RotaryConfig& rotary) noexcept {
    return 3.0 * std::sqrt(3.0) * rotary.generatingRadiusMm * rotary.eccentricityMm
        * rotary.rotorWidthMm * 1.0e-6;
}

void applyRotaryFaceGeometry(EngineConfig& config) noexcept {
    const auto bore = rotaryEquivalentBoreMm(config.rotary);
    const auto stroke = rotaryEquivalentStrokeMm(config.rotary);
    for (auto& face : config.cylinders) {
        face.boreMm = bore;
        face.strokeMm = stroke;
        // No rod: the eccentric is the crank. The length only has to be one
        // a piston could have.
        face.connectingRodMm = std::max(face.connectingRodMm, stroke * 0.5 + 1.0);
    }
    // A face's journal throws half its stroke, as a piston's does.
    for (auto& journal : config.crankJournals) journal.throwMm = stroke * 0.5;
}

double rotaryEquivalentBoreMm(const RotaryConfig& rotary) noexcept {
    return 2.0 * rotary.generatingRadiusMm / std::sqrt(3.0);
}

double rotaryEquivalentStrokeMm(const RotaryConfig& rotary) noexcept {
    const auto bore = rotaryEquivalentBoreMm(rotary);
    return rotaryFaceDisplacementLitres(rotary) * 1.0e6 / (std::numbers::pi * 0.25 * bore * bore);
}

double rotaryChamberSurfaceM2(const RotaryConfig& rotary, double volumeLitres) noexcept {
    const auto widthM = rotary.rotorWidthMm * 0.001;
    return 2.0 * std::sqrt(3.0) * rotary.generatingRadiusMm * 0.001 * widthM
        + 2.0 * std::max(0.0, volumeLitres) * 0.001 / std::max(1.0e-6, widthM);
}

double rotaryApexSpeedMps(const RotaryConfig& rotary, double shaftRadPerSecond) noexcept {
    return std::abs(shaftRadPerSecond) * rotary.generatingRadiusMm * 0.001 / 3.0;
}

double valveLiftMm(double crankAngleDegrees, double centerlineDegrees,
                   double durationDegrees, double maximumLiftMm, double cycleDegrees) noexcept {
    const auto wrapped = std::remainder(crankAngleDegrees - centerlineDegrees, cycleDegrees);
    const auto halfDuration = std::max(1.0, durationDegrees * 0.5);
    if (std::abs(wrapped) >= halfDuration) return 0.0;
    const auto phase = (wrapped + halfDuration) / durationDegrees;
    return std::max(0.0, maximumLiftMm * 0.5 * (1.0 - std::cos(phase * 2.0 * std::numbers::pi)));
}

double profiledValveLiftMm(double crankAngleDegrees, double centerlineDegrees,
                           double durationDegrees, double maximumLiftMm,
                           const std::vector<ValveLiftSample>& samples, double cycleDegrees) noexcept {
    if (samples.size() < 2)
        return valveLiftMm(crankAngleDegrees, centerlineDegrees, durationDegrees, maximumLiftMm, cycleDegrees);
    const auto relativeAngle = std::remainder(crankAngleDegrees - centerlineDegrees, cycleDegrees);
    const auto halfDuration = std::max(1.0, durationDegrees * 0.5);
    if (std::abs(relativeAngle) >= halfDuration) return 0.0;
    const auto firstAngle = samples.front().angleDegrees;
    const auto lastAngle = samples.back().angleDegrees;
    if (relativeAngle <= firstAngle) return std::clamp(samples.front().liftMm, 0.0, maximumLiftMm);
    if (relativeAngle >= lastAngle) return std::clamp(samples.back().liftMm, 0.0, maximumLiftMm);
    for (std::size_t index = 1; index < samples.size(); ++index) {
        const auto& left = samples[index - 1];
        const auto& right = samples[index];
        if (relativeAngle <= right.angleDegrees) {
            const auto span = std::max(1.0e-9, right.angleDegrees - left.angleDegrees);
            const auto t = std::clamp((relativeAngle - left.angleDegrees) / span, 0.0, 1.0);
            return std::clamp(std::lerp(left.liftMm, right.liftMm, t), 0.0, maximumLiftMm);
        }
    }
    return 0.0;
}

double combustionPulse(double cylinderPhaseDegrees, double ignitionAdvanceDegrees,
                       double ignitionOffsetDegrees) noexcept {
    const auto pressurePhase = std::fmod(cylinderPhaseDegrees + ignitionAdvanceDegrees * 0.35
        - ignitionOffsetDegrees + 720.0, 720.0);
    return pressurePhase < 180.0
        ? std::pow(std::sin(pressurePhase * std::numbers::pi / 180.0), 2.0) : 0.0;
}

namespace {

/** `repairs` non-null: `config` is a mutable object, and a finite value
 *  outside its range that is one of its own members (a scalar of the engine
 *  or of a part it holds by value, not an element of a list) is clamped into
 *  its range and reported instead of refused. */
std::optional<std::string> validateOrRepair(const EngineConfig& config, std::vector<std::string>* repairs) {
    const auto inRange = [](double value, double minimum, double maximum) {
        return std::isfinite(value) && value >= minimum && value <= maximum;
    };
    const auto* const configBytes = reinterpret_cast<const unsigned char*>(&config);
    const auto ownMember = [configBytes](const double& value) {
        const auto* const at = reinterpret_cast<const unsigned char*>(&value);
        return at >= configBytes && at + sizeof(double) <= configBytes + sizeof(EngineConfig);
    };
    // The first value found outside its range, named in the message: a
    // designed engine is refused by what is wrong, not with a generic line.
    std::string rangeFailure;
    const auto outOfRange = [&inRange, &rangeFailure, &ownMember, repairs](const char* name, const double& value,
                                                                         double minimum, double maximum) {
        if (inRange(value, minimum, maximum)) return false;
        if (repairs != nullptr && std::isfinite(value) && minimum <= maximum && ownMember(value)) {
            const auto clamped = std::clamp(value, minimum, maximum);
            char text[224];
            std::snprintf(text, sizeof(text), "%s = %g, outside %g to %g: loaded as %g", name, value, minimum,
                          maximum, clamped);
            repairs->emplace_back(text);
            const_cast<double&>(value) = clamped;
            return false;
        }
        if (rangeFailure.empty()) {
            char text[192];
            std::snprintf(text, sizeof(text), "%s = %g, outside %g to %g", name, value, minimum, maximum);
            rangeFailure = text;
        }
        return true;
    };
    const auto validPoint = [&inRange](const AcousticPoint3M& point) {
        return inRange(point.x, -100.0, 100.0)
            && inRange(point.y, -100.0, 100.0)
            && inRange(point.z, -100.0, 100.0);
    };
    if (config.schemaVersion < minimumSupportedEngineSchemaVersion
            || config.schemaVersion > currentEngineSchemaVersion)
        return "Unsupported engine schema version";
    if (config.name.empty() || config.name.size() > 128) return "Engine name must contain between 1 and 128 bytes";
    if (config.cycle == EngineCycle::twoStroke) {
        const auto& ports = config.twoStroke;
        if (config.fuel != FuelType::gasoline) return "A two-stroke engine runs on petrol";
        if (config.forcedInduction.enabled) return "A two-stroke engine has no forced induction";
        if (!inRange(ports.exhaustPortOpenDegrees, 60.0, 120.0)
            || !inRange(ports.transferPortOpenDegrees, ports.exhaustPortOpenDegrees + 4.0, 150.0))
            return "Two-stroke ports open 60-120 deg after TDC (exhaust), the transfers at least 4 deg later "
                   "and by 150 deg";
        const auto widthOk = [&inRange](double width) { return width == 0.0 || inRange(width, 5.0, 500.0); };
        if (!widthOk(ports.exhaustPortWidthMm) || !widthOk(ports.transferPortWidthMm)
            || !inRange(ports.portDischargeCoefficient, 0.3, 1.0)
            || !inRange(ports.crankcaseCompressionRatio, 1.1, 2.5)
            || !(ports.scavengeLoopLengthRatio == 0.0
                 || inRange(ports.scavengeLoopLengthRatio, 0.5, 4.0)))
            return "Two-stroke port widths are 5-500 mm (0: from the bore), their discharge coefficient 0.3-1, "
                   "the crankcase compression ratio 1.1-2.5, the scavenging loop 0.5-4 x bore "
                   "(0: a perfectly mixed cylinder)";
        if (ports.powerValveClosedExhaustPortOpenDegrees != 0.0
                && (!inRange(ports.powerValveClosedExhaustPortOpenDegrees, ports.exhaustPortOpenDegrees + 1.0,
                        ports.transferPortOpenDegrees - 4.0)
                    || !inRange(ports.powerValveOpeningStartRpm, 0.0, 30'000.0)
                    || !inRange(ports.powerValveFullyOpenRpm, ports.powerValveOpeningStartRpm + 100.0, 30'000.0)))
            return "A two-stroke power valve opens the exhaust port later than the port itself and at least "
                   "4 deg before the transfers, and is fully open at least 100 rpm above where it starts";
        if (ports.intake == TwoStrokeIntake::cylinderPort
                && (!inRange(ports.intakePortOpenDegreesBtdc, 30.0, 110.0) || !widthOk(ports.intakePortWidthMm)))
            return "A two-stroke cylinder intake port opens 30-110 deg before TDC and is 5-500 mm wide "
                   "(0: from the bore)";
        for (const auto& path : config.intakePaths) {
            if (path.cylinderIds.size() != 1)
                return "Each two-stroke cylinder has its own crankcase: one intake path per cylinder";
            if (path.geometry.individualThrottles)
                return "A two-stroke crankcase is fed through one carburettor, not individual throttles";
        }
        if (config.injection.startAngleDegrees >= 360.0 || config.injection.endAngleDegrees >= 360.0)
            return "A two-stroke cycle is 360 degrees: injection angles are below 360";
    }
    if (config.cycle == EngineCycle::rotary) {
        const auto& rotary = config.rotary;
        if (config.fuel != FuelType::gasoline) return "A rotary engine runs on petrol";
        if (rotary.rotorCount < 1 || rotary.rotorCount > 10)
            return "A rotary engine has 1-10 rotors (three faces each, 32 chambers at most)";
        if (!inRange(rotary.generatingRadiusMm, 10.0, 2'000.0) || !inRange(rotary.rotorWidthMm, 5.0, 2'000.0)
            || !inRange(rotary.eccentricityMm, 1.0, 500.0)
            || !inRange(rotary.generatingRadiusMm / rotary.eccentricityMm, 4.0, 12.0))
            return "A rotor's generating radius is 10-2,000 mm, its width 5-2,000 mm, and 4-12 times "
                   "its eccentricity (a production Wankel runs 6-8)";
        if (config.cylinders.size() != 3U * rotary.rotorCount)
            return "A rotary engine runs each rotor's three faces as three cylinders";
        const auto bore = rotaryEquivalentBoreMm(rotary);
        const auto stroke = rotaryEquivalentStrokeMm(rotary);
        for (const auto& face : config.cylinders)
            if (std::abs(face.boreMm - bore) > 1.0e-6 * bore || std::abs(face.strokeMm - stroke) > 1.0e-6 * stroke)
                return "A rotary face's bore and stroke follow its rotor (rotaryEquivalentBoreMm, "
                       "rotaryEquivalentStrokeMm)";
        for (std::size_t rotor = 0; rotor < rotary.rotorCount; ++rotor) {
            const auto first = config.cylinders[3 * rotor].crankOffsetDegrees;
            for (std::size_t face = 1; face < 3; ++face) {
                const auto apart = std::fmod(config.cylinders[3 * rotor + face].crankOffsetDegrees - first
                    + 2'160.0, 1'080.0);
                if (std::abs(apart - 360.0 * static_cast<double>(face)) > 1.0e-6)
                    return "A rotor's faces fire 360 deg of the eccentric shaft apart, in face order";
            }
        }
        for (const auto& face : config.cylinders)
            if (face.headChamberVolumeCc > 0.0 || face.pistonCrownVolumeCc > 0.0)
                return "A rotary face's clearance comes from its compression ratio (no head chamber)";
        // A rotor's faces share its ports, so they share its paths.
        const auto splitsARotor = [&config](const std::vector<std::uint32_t>& ids) {
            for (std::size_t rotor = 0; rotor < config.rotary.rotorCount; ++rotor) {
                std::size_t inside = 0;
                for (std::size_t face = 0; face < 3; ++face)
                    inside += static_cast<std::size_t>(std::count(ids.begin(), ids.end(),
                        config.cylinders[3 * rotor + face].id));
                if (inside != 0 && inside != 3) return true;
            }
            return false;
        };
        for (const auto& path : config.intakePaths)
            if (splitsARotor(path.cylinderIds)) return "A rotor's three faces share one intake path";
        for (const auto& path : config.exhaustPaths)
            if (splitsARotor(path.cylinderIds)) return "A rotor's three faces share one exhaust path";
    }
    if (config.fuel == FuelType::diesel
            && config.injection.mode != InjectionMode::direct)
        return "Compression-ignition diesel engines require direct injection";
    if (config.fuelProperties.name.empty() || config.fuelProperties.name.size() > 128
        // Up to hydrogen's 120 MJ/kg and past it: the Fuel window's heating
        // value follows a raised stoichiometric ratio (25 from petrol: 73).
        || !inRange(config.fuelProperties.lowerHeatingValueMjPerKg, 10.0, 150.0)
        || !inRange(config.fuelProperties.densityKgPerL, 0.30, 1.50)
        || !inRange(config.fuelProperties.stoichiometricAirFuelRatio, 5.0, 25.0)
        || !inRange(config.fuelProperties.molarMassGramsPerMole, 20.0, 300.0)
        || !inRange(config.fuelProperties.oxygenMolesPerFuelMole, 1.0, 40.0)
        || !inRange(config.fuelProperties.productMolesPerFuelMole, 1.0, 60.0)
        || !inRange(config.fuelProperties.laminarFlameSpeedMps,
            config.fuel == FuelType::diesel ? 0.0 : 0.05, 2.0)
        || !inRange(config.fuelProperties.turbulenceFlameSpeedGain, 0.0, 10.0)
        || (config.fuel == FuelType::gasoline
            && config.fuelProperties.cetaneNumber != 0.0)
        || (config.fuel == FuelType::diesel
            && !inRange(config.fuelProperties.cetaneNumber, 30.0, 80.0)))
        return "Fuel properties must define finite chemistry, ignition quality and thermodynamic values";
    const auto chemistryStoichiometricAfr = config.fuelProperties.oxygenMolesPerFuelMole * 31.9988
        / config.fuelProperties.molarMassGramsPerMole / 0.232;
    if (std::abs(config.fuelProperties.stoichiometricAirFuelRatio / chemistryStoichiometricAfr - 1.0) > 0.25)
        return "Fuel stoichiometric AFR is inconsistent with its molar oxygen requirement";
    if (config.cylinders.empty() || config.cylinders.size() > 32 || config.firingOrder.size() != config.cylinders.size())
        return "Firing order must reference between 1 and 32 cylinders";
    if (outOfRange("idleRpm", config.idleRpm, 50.0, 3'000.0)
        || outOfRange("redlineRpm", config.redlineRpm, config.idleRpm + 100.0, 20'000.0)
        || outOfRange("rotatingInertiaKgM2", config.rotatingInertiaKgM2, minimumRotatingInertiaKgM2, 20'000.0)
        || outOfRange("frictionCoefficient", config.frictionCoefficient, 0.0, 1.0)
        || (config.fuel == FuelType::gasoline
            && outOfRange("octaneRating", config.octaneRating, 70.0, 130.0))
        || outOfRange("ambientPressureKpa", config.ambientPressureKpa, 50.0, 120.0)
        || outOfRange("ambientTemperatureC", config.ambientTemperatureC, -50.0, 60.0)
        || outOfRange("coolingEfficiency", config.coolingEfficiency, 0.1, 5.0)
        || outOfRange("plenumVolumeLitres", config.plenumVolumeLitres, smallestPlenumVolumeLitres, 6'000.0)
        || outOfRange("throttleDiameterMm", config.throttleDiameterMm, smallestThrottleDiameterMm, 750.0)
        || outOfRange("bankAngleDegrees", config.bankAngleDegrees, 0.0, 180.0)
        || !(config.peakFiringPressureLimitBar == 0.0
            || inRange(config.peakFiringPressureLimitBar, 20.0, 400.0))
        || !validPoint(config.acousticObserver.leftMicrophoneM)
        || !validPoint(config.acousticObserver.rightMicrophoneM)
        || !(config.acousticObserver.soundSpeedMps == 0.0
            || inRange(config.acousticObserver.soundSpeedMps, 250.0, 450.0))
        // Zero keeps the authored microphone positions; anything else places
        // the listener at a real, human distance from the engine.
        || !(config.acousticObserver.listeningDistanceM == 0.0
            || inRange(config.acousticObserver.listeningDistanceM, 0.5, 200.0))
        || outOfRange("forcedInduction.pressureRatio", config.forcedInduction.pressureRatio, 1.0, 6.0)
        || outOfRange("forcedInduction.fullBoostRpm", config.forcedInduction.fullBoostRpm, 200.0, 20'000.0)
        || outOfRange("forcedInduction.compressorEfficiency", config.forcedInduction.compressorEfficiency, 0.35, 0.95)
        || outOfRange("forcedInduction.chargeTemperatureRiseC", config.forcedInduction.chargeTemperatureRiseC, 0.0, 160.0)
        || outOfRange("forcedInduction.turbineEfficiency", config.forcedInduction.turbineEfficiency, 0.20, 0.95)
        || outOfRange("forcedInduction.shaftInertiaKgM2", config.forcedInduction.shaftInertiaKgM2, 1.0e-10, 300.0)
        || outOfRange("forcedInduction.wastegatePressureRatio", config.forcedInduction.wastegatePressureRatio, 1.0, 6.0)
        || outOfRange("forcedInduction.designShaftSpeedRpm", config.forcedInduction.designShaftSpeedRpm, 1'000.0, 2'000'000.0)
        || outOfRange("forcedInduction.bearingFrictionPowerWatts", config.forcedInduction.bearingFrictionPowerWatts, 0.0, 20'000.0)
        || outOfRange("forcedInduction.turbineFlowAreaMm2", config.forcedInduction.turbineFlowAreaMm2, 1.0, 500'000.0)
        || outOfRange("forcedInduction.wastegateFlowAreaMm2", config.forcedInduction.wastegateFlowAreaMm2, 0.0, 500'000.0)
        || config.forcedInduction.turbochargerCount < 1U
        || config.forcedInduction.turbochargerCount > maximumTurbochargers
        || !(config.forcedInduction.compressorDesignMassFlowKgPerSecond == 0.0
            || inRange(config.forcedInduction.compressorDesignMassFlowKgPerSecond, 0.0001, 500.0))
        || outOfRange("forcedInduction.intercoolerEffectiveness", config.forcedInduction.intercoolerEffectiveness, 0.0, 0.95)
        // Zero: 1.3 x the design speed. No ceiling: a user may build a wheel
        // that never meets its line.
        || !(config.forcedInduction.maximumShaftSpeedRpm == 0.0
            || inRange(config.forcedInduction.maximumShaftSpeedRpm, 1'000.0, 1.0e9))
        || outOfRange("thermal.regulatedCoolantTemperatureC", config.thermal.regulatedCoolantTemperatureC, 40.0, 130.0)
        || outOfRange("thermal.regulatedOilTemperatureC", config.thermal.regulatedOilTemperatureC, 40.0, 150.0)
        || !(config.thermal.coolantMassKjPerC == 0.0 || inRange(config.thermal.coolantMassKjPerC, 0.05, 500'000.0))
        || !(config.thermal.oilMassKjPerC == 0.0 || inRange(config.thermal.oilMassKjPerC, 0.02, 250'000.0))
        || outOfRange("thermal.coolantHeatShare", config.thermal.coolantHeatShare, 0.0, 1.0)
        || outOfRange("thermal.oilHeatShare", config.thermal.oilHeatShare, 0.0, 1.0)
        || !(config.thermal.coolingPowerKwPerC == 0.0 || inRange(config.thermal.coolingPowerKwPerC, 0.0002, 2'000.0))
        || !(config.thermal.oilCoolingPowerKwPerC == 0.0 || inRange(config.thermal.oilCoolingPowerKwPerC, 0.00002, 1'000.0))
        || outOfRange("camshafts.intakeDurationDegrees", config.camshafts.intakeDurationDegrees, 1.0, 720.0)
        || outOfRange("camshafts.exhaustDurationDegrees", config.camshafts.exhaustDurationDegrees, 1.0, 720.0)
        || outOfRange("camshafts.intakeLiftMm", config.camshafts.intakeLiftMm, 0.0, 150.0)
        || outOfRange("camshafts.exhaustLiftMm", config.camshafts.exhaustLiftMm, 0.0, 150.0)
        || outOfRange("camshafts.intakeCenterlineDegrees", config.camshafts.intakeCenterlineDegrees, 0.0, 720.0)
        || outOfRange("camshafts.exhaustCenterlineDegrees", config.camshafts.exhaustCenterlineDegrees, 0.0, 720.0)
        || outOfRange("camshafts.intakeFlowCoefficient", config.camshafts.intakeFlowCoefficient, 0.05, 1.50)
        || outOfRange("camshafts.exhaustFlowCoefficient", config.camshafts.exhaustFlowCoefficient, 0.05, 1.50)
        || outOfRange("exhaust.primaryLengthMm", config.exhaust.primaryLengthMm, 25.0, 15'000.0)
        || outOfRange("exhaust.primaryDiameterMm", config.exhaust.primaryDiameterMm, 4.0, 1'000.0)
        || outOfRange("exhaust.collectorDiameterMm", config.exhaust.collectorDiameterMm, 4.0, 1'500.0)
        || outOfRange("exhaust.outletDiameterMm", config.exhaust.outletDiameterMm, 4.0, 1'500.0)
        || outOfRange("exhaust.mufflerRestriction", config.exhaust.mufflerRestriction, 0.0, 1.0)
        || !(config.exhaust.collectorVolumeLitres == 0.0
             || inRange(config.exhaust.collectorVolumeLitres, 0.05, 25'000.0))
        || outOfRange("exhaust.outletDischargeCoefficient", config.exhaust.outletDischargeCoefficient, 0.02, 1.5)
        || outOfRange("exhaust.mufflerChamberDiameterMm", config.exhaust.mufflerChamberDiameterMm, 0.0, 3'000.0)
        || outOfRange("exhaust.mufflerChamberLengthMm", config.exhaust.mufflerChamberLengthMm, 0.0, 15'000.0)
        || outOfRange("exhaust.mufflerPackingFlowResistivityPaSPerM2", config.exhaust.mufflerPackingFlowResistivityPaSPerM2, 0.0, 200'000.0)
        || outOfRange("exhaust.mufflerPackingThicknessMm", config.exhaust.mufflerPackingThicknessMm, 0.0, 1'500.0)
        || outOfRange("exhaust.mufflerPerforatedOpenAreaRatio", config.exhaust.mufflerPerforatedOpenAreaRatio, 0.0, 1.0)
        || !validMufflerPacking(config.exhaust)
        || !validMidpipe(config.exhaust)
        || outOfRange("exhaustValve.openAboveRpm", config.exhaustValve.openAboveRpm, 0.0, 100'000.0)
        || outOfRange("exhaustValve.openAboveThrottle", config.exhaustValve.openAboveThrottle, 0.0, 1.0)
        || outOfRange("exhaustValve.travelSeconds", config.exhaustValve.travelSeconds, 0.0, 60.0)
        // A nitrous kit: any size, any bottle (owner, 2026-11-11); only what
        // has no meaning is refused.
        || outOfRange("nitrous.shotKw", config.nitrous.shotKw, 0.0, 1.0e9)
        || outOfRange("nitrous.bottleCapacityKg", config.nitrous.bottleCapacityKg, 0.0, 1.0e9)
        || outOfRange("nitrous.bottleTemperatureC", config.nitrous.bottleTemperatureC, -90.0, 1'000.0)
        || outOfRange("nitrous.minimumThrottle", config.nitrous.minimumThrottle, 0.0, 1.0)
        || outOfRange("nitrous.minimumRpm", config.nitrous.minimumRpm, 0.0, 1.0e6)
        || outOfRange("nitrous.maximumRpm", config.nitrous.maximumRpm, 0.0, 1.0e6)
        || outOfRange("nitrous.rampSeconds", config.nitrous.rampSeconds, 0.0, 1.0e4)
        || outOfRange("nitrous.sparkRetardDegreesPer50Hp", config.nitrous.sparkRetardDegreesPer50Hp, -90.0, 90.0)
        || outOfRange("nitrous.kitLambda", config.nitrous.kitLambda, 0.05, 20.0)
        || outOfRange("engineBrake.valveLiftMm", config.engineBrake.valveLiftMm, 0.0, 10.0)
        || outOfRange("engineBrake.peakAfterTdcDegrees", config.engineBrake.peakAfterTdcDegrees, -90.0, 90.0)
        || outOfRange("engineBrake.durationDegrees", config.engineBrake.durationDegrees, 5.0, 180.0)
        || outOfRange("engineBrake.minimumRpm", config.engineBrake.minimumRpm, 0.0, 50'000.0)
        || outOfRange("engineBrake.stageCount", static_cast<double>(config.engineBrake.stageCount), 1.0, 8.0)
        || outOfRange("transmission.finalDriveRatio", config.transmission.finalDriveRatio, 1.0, maximumFinalDriveRatio)
        || outOfRange("transmission.maxClutchTorqueNm", config.transmission.maxClutchTorqueNm, 0.1, 10'000'000.0)
        || outOfRange("transmission.drivelineEfficiency", config.transmission.drivelineEfficiency, 0.2, 1.0)
        || outOfRange("transmission.drivenWheelInertiaKgM2", config.transmission.drivenWheelInertiaKgM2, 0.0, 100'000.0)
        || outOfRange("transmission.clutchLockSpeedRpm", config.transmission.clutchLockSpeedRpm, 0.1, 500.0)
        || outOfRange("transmission.shiftDurationSeconds", config.transmission.shiftDurationSeconds, 0.01, 3.0)
        || outOfRange("transmission.automaticUpshiftRpm", config.transmission.automaticUpshiftRpm, 0.0, 50'000.0)
        || outOfRange("transmission.automaticDownshiftRpm", config.transmission.automaticDownshiftRpm, 0.0, 30'000.0)
        // A truck's reverse is 13-16, its first gear 16.7 (ZF TraXon).
        || outOfRange("transmission.reverseRatio", config.transmission.reverseRatio, 0.1, 25.0)
        || outOfRange("transmission.gearboxInputInertiaKgM2", config.transmission.gearboxInputInertiaKgM2, 0.0, 10'000.0)
        || outOfRange("transmission.differentialInertiaKgM2", config.transmission.differentialInertiaKgM2, 0.0, 10'000.0)
        || outOfRange("transmission.clutchThermalCapacityJPerC", config.transmission.clutchThermalCapacityJPerC, 1.0, 1.0e9)
        || outOfRange("transmission.clutchCoolingWPerC", config.transmission.clutchCoolingWPerC, 0.0, 1.0e6)
        || outOfRange("transmission.clutchFadeStartTemperatureC", config.transmission.clutchFadeStartTemperatureC, 50.0, 800.0)
        || outOfRange("transmission.clutchFailureTemperatureC", config.transmission.clutchFailureTemperatureC,
                    config.transmission.clutchFadeStartTemperatureC + 1.0, 1'200.0)
        || outOfRange("transmission.shiftTorqueCutFraction", config.transmission.shiftTorqueCutFraction, 0.0, 1.0)
        || outOfRange("transmission.quickshifterCutSeconds", config.transmission.quickshifterCutSeconds, 0.01, 0.5)
        || outOfRange("transmission.dualClutchUpshiftRetardDegrees", config.transmission.dualClutchUpshiftRetardDegrees, 0.0, 40.0)
        || outOfRange("transmission.dualClutchUpshiftCylinderCutFraction", config.transmission.dualClutchUpshiftCylinderCutFraction, 0.0, 1.0)
        || outOfRange("transmission.centrifugalClutchEngageRpm", config.transmission.centrifugalClutchEngageRpm, 0.0, 20'000.0)
        || outOfRange("vehicle.massKg", config.vehicle.massKg, 1.0, 1.0e6)
        || outOfRange("vehicle.dragCoefficient", config.vehicle.dragCoefficient, 0.05, 2.0)
        || outOfRange("vehicle.frontalAreaM2", config.vehicle.frontalAreaM2, 0.01, 200.0)
        || outOfRange("vehicle.tireRadiusM", config.vehicle.tireRadiusM, 0.01, 5.0)
        || outOfRange("vehicle.rollingResistanceCoefficient", config.vehicle.rollingResistanceCoefficient, 0.0, 0.20)
        || outOfRange("vehicle.tireFrictionCoefficient", config.vehicle.tireFrictionCoefficient, 0.05, 3.0)
        || outOfRange("vehicle.drivenAxleWeightFraction", config.vehicle.drivenAxleWeightFraction, 0.05, 1.0)
        || outOfRange("vehicle.wheelbaseM", config.vehicle.wheelbaseM, 0.1, 50.0)
        || outOfRange("vehicle.centerOfGravityHeightM", config.vehicle.centerOfGravityHeightM, 0.05, 3.0)
        || config.vehicle.centerOfGravityHeightM >= config.vehicle.wheelbaseM
        || outOfRange("vehicle.maximumBrakeForceN", config.vehicle.maximumBrakeForceN, 0.0, 1.0e8)
        || outOfRange("combustionCalibration.baseIgnitionDelaySeconds", config.combustionCalibration.baseIgnitionDelaySeconds, 0.0, 0.02)
        || outOfRange("combustionCalibration.ignitionDelayTemperatureExponent", config.combustionCalibration.ignitionDelayTemperatureExponent, 0.0, 5.0)
        || outOfRange("combustionCalibration.ignitionDelayPressureExponent", config.combustionCalibration.ignitionDelayPressureExponent, 0.0, 3.0)
        || outOfRange("combustionCalibration.wallHeatTransferCoefficientWPerK", config.combustionCalibration.wallHeatTransferCoefficientWPerK, 0.0, 500'000.0)
        || outOfRange("combustionCalibration.residualDilutionSensitivity", config.combustionCalibration.residualDilutionSensitivity, 0.0, 3.0)
        || outOfRange("combustionCalibration.chamberTurbulenceIntensityRatio", config.combustionCalibration.chamberTurbulenceIntensityRatio, 0.1, 4.0)
        || config.combustionCalibration.ignitionSiteCount < 1
        || config.combustionCalibration.ignitionSiteCount > 4
        || outOfRange("combustionCalibration.compressionIgnitionDelayScale", config.combustionCalibration.compressionIgnitionDelayScale, 0.2, 5.0)
        || outOfRange("combustionCalibration.compressionIgnitionMixingTimeSeconds", config.combustionCalibration.compressionIgnitionMixingTimeSeconds,
                    0.00005, 0.02)
        || outOfRange("combustionCalibration.compressionIgnitionPremixedFraction", config.combustionCalibration.compressionIgnitionPremixedFraction,
                    0.0, 0.8)
        || outOfRange("combustionCalibration.cycleVariationCoefficientOfVariation", config.combustionCalibration
                        .cycleVariationCoefficientOfVariation,
                    0.0, 0.20)
        || outOfRange("combustionCalibration.cycleVariationCorrelation", config.combustionCalibration.cycleVariationCorrelation,
                    0.0, 0.98)
        || outOfRange("exhaustAfterfire.ignitionTemperatureK", config.exhaustAfterfire.ignitionTemperatureK,
                    500.0, 2'000.0)
        || outOfRange("exhaustAfterfire.reactionTimeConstantSeconds", config.exhaustAfterfire.reactionTimeConstantSeconds,
                    0.0001, 1.0)
        || outOfRange("exhaustAfterfire.reactionEfficiency", config.exhaustAfterfire.reactionEfficiency, 0.0, 1.0)
        || outOfRange("exhaustAfterfire.overrunMinimumRpm", config.exhaustAfterfire.overrunMinimumRpm, 500.0, 20'000.0)
        || outOfRange("exhaustAfterfire.overrunMaximumThrottle", config.exhaustAfterfire.overrunMaximumThrottle, 0.0, 0.20)
        || outOfRange("exhaustAfterfire.inductionTimeSeconds", config.exhaustAfterfire.inductionTimeSeconds,
                    0.0001, 0.100)
        || outOfRange("exhaustAfterfire.inductionReferencePressureKpa", config.exhaustAfterfire.inductionReferencePressureKpa,
                    10.0, 10'000.0)
        || outOfRange("exhaustAfterfire.inductionActivationTemperatureK", config.exhaustAfterfire.inductionActivationTemperatureK,
                    0.0, 50'000.0)
        || outOfRange("exhaustAfterfire.inductionPressureExponent", config.exhaustAfterfire.inductionPressureExponent,
                    0.0, 3.0)
        || outOfRange("exhaustAfterfire.inductionEquivalenceRatioExponent", config.exhaustAfterfire.inductionEquivalenceRatioExponent,
            -3.0, 3.0)
        || outOfRange("exhaustAfterfire.inductionDecayTimeSeconds", config.exhaustAfterfire.inductionDecayTimeSeconds,
                    0.0001, 1.0)
        || outOfRange("exhaustAfterfire.minimumEquivalenceRatio", config.exhaustAfterfire.minimumEquivalenceRatio,
                    0.05, 1.0)
        || outOfRange("exhaustAfterfire.maximumEquivalenceRatio", config.exhaustAfterfire.maximumEquivalenceRatio,
                    1.0, 5.0)
        || config.exhaustAfterfire.minimumEquivalenceRatio
            >= config.exhaustAfterfire.maximumEquivalenceRatio
        || outOfRange("exhaustAfterfire.quenchTemperatureK", config.exhaustAfterfire.quenchTemperatureK,
                    250.0, 1'500.0)
        || outOfRange("exhaustAfterfire.pocketMixingTimeSeconds",
                    config.exhaustAfterfire.pocketMixingTimeSeconds, 0.0, 0.2)
        || outOfRange("exhaustAfterfire.overrunSparkAdvanceDegrees",
                    config.exhaustAfterfire.overrunSparkAdvanceDegrees, -45.0, 10.0)
        || outOfRange("exhaustAfterfire.overrunSparkCutFraction",
                    config.exhaustAfterfire.overrunSparkCutFraction, 0.0, 0.9)
        || outOfRange("runnerAcoustics.dampingRatio", config.runnerAcoustics.dampingRatio, 0.01, 2.0)
        || outOfRange("runnerAcoustics.couplingGain", config.runnerAcoustics.couplingGain, 0.0, 2.0)
        || outOfRange("runnerAcoustics.maximumPressureAmplitudeKpa", config.runnerAcoustics.maximumPressureAmplitudeKpa, 0.1, 200.0)
        || config.forcedInduction.compressorBladeCount > 100
        || config.forcedInduction.turbineBladeCount > 100
        || config.forcedInduction.superchargerLobeCount > 20
        || outOfRange("forcedInduction.superchargerDriveRatio", config.forcedInduction.superchargerDriveRatio, 0.1, 30.0)
        || outOfRange("forcedInduction.superchargerDisplacementLitres", config.forcedInduction.superchargerDisplacementLitres, 0.0, 1'000.0)
        || outOfRange("forcedInduction.superchargerBypassAreaMm2", config.forcedInduction.superchargerBypassAreaMm2, 0.0, 1.0e6)
        || outOfRange("forcedInduction.compressorInducerDiameterMm", config.forcedInduction.compressorInducerDiameterMm, 0.0, 2'500.0)
        || outOfRange("forcedInduction.turbineExducerDiameterMm", config.forcedInduction.turbineExducerDiameterMm, 0.0, 2'500.0)
        || outOfRange("forcedInduction.blowOffValveFlowAreaMm2", config.forcedInduction.blowOffValveFlowAreaMm2, 0.0, 500'000.0)
        || outOfRange("forcedInduction.blowOffValveOpeningPressureRatio", config.forcedInduction.blowOffValveOpeningPressureRatio, 1.001, 3.0)
        || outOfRange("forcedInduction.blowOffValveDischargeCoefficient", config.forcedInduction.blowOffValveDischargeCoefficient, 0.05, 1.5)
        || outOfRange("forcedInduction.chargeVolumeLitres", config.forcedInduction.chargeVolumeLitres, 0.0, 10'000.0)
        || outOfRange("forcedInduction.tonalAcousticEfficiency", config.forcedInduction.tonalAcousticEfficiency, 0.0, 0.01)
        || outOfRange("forcedInduction.turbulentJetNoiseCoefficient", config.forcedInduction.turbulentJetNoiseCoefficient, 0.0, 0.1)
        || outOfRange("intake.plenumVolumeLitres", config.intake.plenumVolumeLitres, smallestPlenumVolumeLitres, 6'000.0)
        || outOfRange("intake.throttleDiameterMm", config.intake.throttleDiameterMm, smallestThrottleDiameterMm, 750.0)
        || config.intake.throttleCount < 1 || config.intake.throttleCount > 16
        || outOfRange("intake.throttleDischargeCoefficient", config.intake.throttleDischargeCoefficient, 0.05, 1.5)
        || outOfRange("intake.carburettor.venturiDiameterMm", config.intake.carburettor.venturiDiameterMm, 0.0, 1'000.0)
        || outOfRange("intake.carburettor.mainJetFlowNumber", config.intake.carburettor.mainJetFlowNumber, 5.0, 5000.0)
        || outOfRange("intake.carburettor.pilotJetFlowNumber", config.intake.carburettor.pilotJetFlowNumber, 1.0, 2000.0)
        || outOfRange("intake.carburettor.pilotCircuitFactor", config.intake.carburettor.pilotCircuitFactor, 0.005, 1.0)
        || outOfRange("intake.carburettor.needleClipPosition", config.intake.carburettor.needleClipPosition, 1.0, 5.0)
        || outOfRange("intake.carburettor.airScrewTurns", config.intake.carburettor.airScrewTurns, 0.1, 6.0)
        || outOfRange("intake.carburettor.idleScrewTurns", config.intake.carburettor.idleScrewTurns, 0.0,
                      carburettorMaximumIdleScrewTurns)
        || outOfRange("intake.carburettor.jetLiftMm", config.intake.carburettor.jetLiftMm, 0.0, 100.0)
        || outOfRange("intake.carburettor.jetDischargeCoefficient", config.intake.carburettor.jetDischargeCoefficient, 0.05, 1.0)
        || outOfRange("intake.carburettor.wallFilmFraction", config.intake.carburettor.wallFilmFraction, 0.0, 0.98)
        || outOfRange("intake.carburettor.wallFilmTimeConstantSeconds", config.intake.carburettor.wallFilmTimeConstantSeconds, 1.0e-4, 5.0)
        || outOfRange("intake.carburettor.acceleratorPumpStrokeCc", config.intake.carburettor.acceleratorPumpStrokeCc, 0.0, 100.0)
        || outOfRange("intake.carburettor.acceleratorPumpTimeConstantSeconds", config.intake.carburettor.acceleratorPumpTimeConstantSeconds, 1.0e-3, 5.0)
        || outOfRange("intake.carburettor.starterJetFlowNumber", config.intake.carburettor.starterJetFlowNumber, 0.0, 20'000.0)
        || outOfRange("intake.runnerLengthMm", config.intake.runnerLengthMm, 5.0, 10'000.0)
        || outOfRange("intake.runnerDiameterMm", config.intake.runnerDiameterMm, 2.5, 750.0)
        || !(config.intake.runnerPlenumDiameterMm == 0.0
            || inRange(config.intake.runnerPlenumDiameterMm, 2.5, 750.0))
        || outOfRange("intake.airboxVolumeLitres", config.intake.airboxVolumeLitres, 0.0, 12'000.0)
        || !(config.intake.throttleDistanceFromValveMm >= 0.0
            && config.intake.throttleDistanceFromValveMm < config.intake.runnerLengthMm)
        || outOfRange("intake.inletDuctLengthMm", config.intake.inletDuctLengthMm, 0.0, 25'000.0)
        || outOfRange("intake.inletDuctDiameterMm", config.intake.inletDuctDiameterMm, 0.0, 2'500.0)
        || outOfRange("intake.bellmouthDiameterMm", config.intake.bellmouthDiameterMm, 0.0, 5'000.0)
        || outOfRange("intake.idleBypassAreaMm2", config.intake.idleBypassAreaMm2, 0.0, 25'000.0)
        || outOfRange("intake.throttleGamma", config.intake.throttleGamma, 0.2, 5.0)
        || outOfRange("ignition.revLimitRpm", config.ignition.revLimitRpm, config.idleRpm + 100.0, 25'000.0)
        || outOfRange("ignition.limiterDurationSeconds", config.ignition.limiterDurationSeconds, 0.005, 2.0)
        || outOfRange("injection.startAngleDegrees", config.injection.startAngleDegrees, 0.0,
            cycleDegreesOf(config.cycle) > 720.0 ? cycleDegreesOf(config.cycle) : 720.0)
        || outOfRange("injection.endAngleDegrees", config.injection.endAngleDegrees, 0.0,
            cycleDegreesOf(config.cycle) > 720.0 ? cycleDegreesOf(config.cycle) : 720.0)
        || std::abs(config.injection.startAngleDegrees - config.injection.endAngleDegrees) < 1.0
        || outOfRange("injection.injectorFlowMgPerSecond", config.injection.injectorFlowMgPerSecond, 10.0, 500'000.0)
        || outOfRange("injection.fuelTemperatureC", config.injection.fuelTemperatureC, -50.0, 180.0)
        || outOfRange("injection.railPressureBar", config.injection.railPressureBar, 1.2, 3'000.0)
        || outOfRange("injection.referencePressureBar", config.injection.referencePressureBar, 1.2, 3'000.0)
        || outOfRange("injection.wallFilmFraction", config.injection.wallFilmFraction, 0.0, 0.98)
        || outOfRange("injection.vaporisationTimeConstantSeconds", config.injection.vaporisationTimeConstantSeconds, 0.001, 2.0)
        || outOfRange("injection.latentHeatKjPerKg", config.injection.latentHeatKjPerKg, 10.0, 1'200.0)
        || outOfRange("injection.directChargeCoolingEfficiency", config.injection.directChargeCoolingEfficiency, 0.0, 1.0)
        || outOfRange("injection.portChargeCoolingEfficiency", config.injection.portChargeCoolingEfficiency, 0.0, 1.0)
        || outOfRange("injection.directSprayVaporisationTimeConstantSeconds", config.injection.directSprayVaporisationTimeConstantSeconds,
                    0.0, 0.02)
        || outOfRange("injection.directSprayEntrainmentTimeConstantSeconds", config.injection.directSprayEntrainmentTimeConstantSeconds,
                    0.0, 0.02)
        || outOfRange("solver.mechanicalFrequencyHz", config.solver.mechanicalFrequencyHz, 240.0, 50'000.0)
        || outOfRange("solver.maximumMechanicalFrequencyHz", config.solver.maximumMechanicalFrequencyHz, config.solver.mechanicalFrequencyHz, 100'000.0)
        || outOfRange("solver.maximumCrankDegreesPerStep", config.solver.maximumCrankDegreesPerStep, 0.1, 30.0)
        || config.solver.gasSubsteps < 1 || config.solver.gasSubsteps > 32)
        return rangeFailure.empty() ? std::string("Engine configuration contains non-finite or physically invalid values")
                                    : "Engine value out of range: " + rangeFailure;
    if (config.injection.fullLoadFuelLimit.size() > 64
            || (config.fuel != FuelType::diesel
                && !config.injection.fullLoadFuelLimit.empty()))
        return "Full-load fuel quantity limits are only valid for compression-ignition engines";
    if (config.structuralNvh.modes.empty()) {
        if (config.structuralNvh.provenance
                != StructuralNvhProvenance::estimatedFamily
            || !config.structuralNvh.source.empty())
            return "Empty structural NVH data must retain estimated-family provenance";
    } else {
        if ((config.structuralNvh.provenance
                != StructuralNvhProvenance::estimatedFamily
             && config.structuralNvh.provenance
                != StructuralNvhProvenance::calculatedGeometry
             && config.structuralNvh.provenance
                != StructuralNvhProvenance::measured)
            || config.structuralNvh.modes.size() > 64
            || config.structuralNvh.source.empty()
            || config.structuralNvh.source.size() > 1'024)
            return "Authored structural NVH modes require a bounded auditable source";
        for (const auto& mode : config.structuralNvh.modes) {
            if ((mode.drive != StructuralModeDrive::headGas
                    && mode.drive
                        != StructuralModeDrive::bearingAxial
                    && mode.drive
                        != StructuralModeDrive::bearingLateral
                    && mode.drive != StructuralModeDrive::torsion)
                || mode.name.empty() || mode.name.size() > 128
                || !inRange(mode.frequencyHz, 10.0, 20'000.0)
                || !inRange(mode.dampingRatio, 0.001, 0.50)
                || !inRange(mode.modalMassKg, 0.01, 10'000.0)
                || !inRange(mode.radiatingAreaM2, 0.0001, 100.0)
                || !inRange(mode.radiationEfficiency, 0.0, 1.0)
                || !inRange(mode.surfaceVelocityRmsScale, 0.001, 1.0)
                || !inRange(mode.torqueRadiusM, 0.001, 2.0)
                || mode.cylinderParticipation.size()
                    != config.cylinders.size())
                return "Structural NVH modes must define finite SI modal data and one participation per cylinder";
            auto maximumParticipation = 0.0;
            for (const auto participation :
                 mode.cylinderParticipation) {
                if (!inRange(participation, -1.0, 1.0))
                    return "Structural NVH participation must be finite and antinode-normalised";
                maximumParticipation = std::max(
                    maximumParticipation, std::abs(participation));
            }
            if (maximumParticipation < 1.0e-6)
                return "Structural NVH modes must couple to at least one cylinder";
        }
    }
    auto previousFuelLimitRpm = -1.0;
    for (const auto& sample : config.injection.fullLoadFuelLimit) {
        if (!inRange(sample.rpm, 0.0, 25'000.0)
                || !inRange(sample.milligramsPerCycle, 0.0, 125'000.0)
                || sample.rpm <= previousFuelLimitRpm)
            return "Full-load fuel quantity limits must be finite and ordered by RPM";
        previousFuelLimitRpm = sample.rpm;
    }
    const auto maximumCalibratedRpm = std::max(config.redlineRpm, config.ignition.revLimitRpm);
    const auto requiredAngleFrequency = maximumCalibratedRpm * 6.0
        / config.solver.maximumCrankDegreesPerStep;
    const auto requiredSolverFrequency = std::max(requiredAngleFrequency,
        config.solver.mechanicalFrequencyHz * static_cast<double>(config.solver.gasSubsteps));
    if (config.solver.maximumMechanicalFrequencyHz + 1.0e-9 < requiredSolverFrequency)
        return "Solver maximum frequency cannot satisfy the configured crank-angle resolution at the rev limit";
    // No cap on the count (owner, 2026-11-14): a user may build any gearbox.
    if (config.transmission.gearRatios.empty())
        return "Transmission must contain at least one forward gear";
    for (const auto gearRatio : config.transmission.gearRatios)
        if (!inRange(gearRatio, 0.05, 25.0)) return "Transmission gear ratios must be between 0.05 and 25";
    // Zero derives a shift speed from the engine (ShiftSchedule).
    if (config.transmission.automaticDownshiftRpm > 0.0 && config.transmission.automaticUpshiftRpm > 0.0
        && config.transmission.automaticDownshiftRpm >= config.transmission.automaticUpshiftRpm)
        return "Automatic transmission downshift RPM must be lower than upshift RPM";
    if (std::abs(config.plenumVolumeLitres - config.intake.plenumVolumeLitres) > 1.0e-9
        || std::abs(config.throttleDiameterMm - config.intake.throttleDiameterMm) > 1.0e-9)
        return "Legacy plenum and throttle fields must match the canonical intake configuration";
    if (config.crankshafts.empty() || config.crankshafts.size() > 8)
        return "Mechanical topology must define between 1 and 8 crankshafts";
    std::unordered_set<std::uint32_t> crankshaftIds;
    for (const auto& crankshaft : config.crankshafts) {
        if (crankshaft.id == 0 || !crankshaftIds.insert(crankshaft.id).second
            || !inRange(crankshaft.positionXMm, -10'000.0, 10'000.0)
            || !inRange(crankshaft.positionYMm, -10'000.0, 10'000.0)
            || !inRange(crankshaft.phaseOffsetDegrees, -720.0, 720.0)
            || !inRange(crankshaft.rotationRatio, -8.0, 8.0) || std::abs(crankshaft.rotationRatio) < 0.01
            || !inRange(crankshaft.massKg, 0.01, 250'000.0)
            || !inRange(crankshaft.flywheelMassKg, 0.0, 250'000.0)
            || !inRange(crankshaft.momentOfInertiaKgM2, 0.001, 150'000.0)
            || !inRange(crankshaft.frictionTorqueNm, 0.0, 1'250'000.0))
            return "Crankshaft IDs, ratios, positions, masses and inertia must be finite and valid";
    }
    if (config.crankJournals.empty() || config.crankJournals.size() > 64)
        return "Crank journal table must contain between 1 and 64 entries";
    std::unordered_set<std::uint32_t> journalIds;
    for (const auto& journal : config.crankJournals) {
        if (journal.id == 0 || !inRange(journal.angleDegrees, -360.0, crankDomainDegreesOf(config.cycle))
            || !inRange(journal.throwMm, 1.0, 0.5 * maximumBoreStrokeMm) || !crankshaftIds.contains(journal.crankshaftId))
            return "Crank journals must have finite IDs, angles and throws";
        journalIds.insert(journal.id);
    }
    if (journalIds.size() != config.crankJournals.size()) return "Crank journal IDs must be unique";
    const auto validateLiftProfile = [&inRange](const std::vector<ValveLiftSample>& profile, double maxLift) {
        if (profile.size() > 64) return false;
        double previous = -std::numeric_limits<double>::infinity();
        for (const auto& sample : profile) {
            if (!inRange(sample.angleDegrees, -360.0, 360.0) || !inRange(sample.liftMm, 0.0, maxLift)) return false;
            if (sample.angleDegrees <= previous) return false;
            previous = sample.angleDegrees;
        }
        return true;
    };
    const auto validateFlowCurve = [&inRange](const std::vector<ValveFlowSample>& curve) {
        if (curve.size() > 64) return false;
        double previousLift = -1.0;
        for (const auto& sample : curve) {
            if (!inRange(sample.liftMm, 0.0, 200.0)
                || !inRange(sample.dischargeCoefficient, 0.0, 1.5)
                || sample.liftMm <= previousLift) return false;
            previousLift = sample.liftMm;
        }
        return true;
    };
    const auto validateCamshaft = [&inRange, &validateLiftProfile, &validateFlowCurve](const CamshaftConfig& cam) {
        if (!inRange(cam.continuousControl.responseFrequencyHz, 0.1, 100.0)
            || (cam.continuousControl.enabled && cam.continuousControl.samples.empty())
            || cam.continuousControl.samples.size() > 128
            || !validateFlowCurve(cam.intakeFlowCurve) || !validateFlowCurve(cam.exhaustFlowCurve)
            || !(cam.exhaustPortHeadAreaFraction == 0.0 || inRange(cam.exhaustPortHeadAreaFraction, 0.2, 1.2)))
            return false;
        for (std::size_t index = 0; index < cam.continuousControl.samples.size(); ++index) {
            const auto& sample = cam.continuousControl.samples[index];
            if (!inRange(sample.rpm, 0.0, 30'000.0) || !inRange(sample.load, 0.0, 1.5)
                || !inRange(sample.intakeAdvanceDegrees, -90.0, 90.0)
                || !inRange(sample.exhaustAdvanceDegrees, -90.0, 90.0)
                || !inRange(sample.liftMultiplier, 0.1, 2.0)) return false;
            for (std::size_t other = index + 1; other < cam.continuousControl.samples.size(); ++other)
                if (std::abs(sample.rpm - cam.continuousControl.samples[other].rpm) <= 1.0e-9
                    && std::abs(sample.load - cam.continuousControl.samples[other].load) <= 1.0e-12)
                    return false;
        }
        return inRange(cam.intakeDurationDegrees, 1.0, 720.0)
            && inRange(cam.exhaustDurationDegrees, 1.0, 720.0)
            && inRange(cam.intakeLiftMm, 0.0, 150.0)
            && inRange(cam.exhaustLiftMm, 0.0, 150.0)
            && inRange(cam.intakeCenterlineDegrees, 0.0, 720.0)
            && inRange(cam.exhaustCenterlineDegrees, 0.0, 720.0)
            && inRange(cam.intakeFlowCoefficient, 0.05, 1.50)
            && inRange(cam.exhaustFlowCoefficient, 0.05, 1.50)
            && inRange(cam.switchRpm, 200.0, 25'000.0)
            && inRange(cam.switchThrottle, 0.0, 1.0)
            && inRange(cam.highIntakeDurationDegrees, 1.0, 720.0)
            && inRange(cam.highExhaustDurationDegrees, 1.0, 720.0)
            && inRange(cam.highIntakeLiftMm, 0.0, 150.0)
            && inRange(cam.highExhaustLiftMm, 0.0, 150.0)
            && validateLiftProfile(cam.intakeLiftProfile, cam.intakeLiftMm)
            && validateLiftProfile(cam.exhaustLiftProfile, cam.exhaustLiftMm)
            && validateLiftProfile(cam.highIntakeLiftProfile, cam.highIntakeLiftMm)
            && validateLiftProfile(cam.highExhaustLiftProfile, cam.highExhaustLiftMm);
    };
    if (!validateCamshaft(config.camshafts))
        return "Valve lift profiles must be sorted finite tables within configured max lift";
    if (config.ignition.timingCurve.empty() || config.ignition.timingCurve.size() > 128)
        return "Ignition timing curve must contain between 1 and 128 samples";
    double previousIgnitionRpm = -1.0;
    for (const auto& sample : config.ignition.timingCurve) {
        if (!inRange(sample.rpm, 0.0, 25'000.0) || !inRange(sample.advanceDegrees, -30.0, 80.0)
            || sample.rpm <= previousIgnitionRpm)
            return "Ignition timing curve must be finite and strictly ordered by RPM";
        previousIgnitionRpm = sample.rpm;
    }
    // Optional; read by the ECU every step. A non-finite point gave a NaN
    // advance, and the interpolation needs its points in RPM order (audit
    // PH-02). The designer's measurement gives equal RPMs on an engine whose
    // range is a single point, so equal is allowed.
    if (config.ignition.knockLimitCurve.size() > 128)
        return "Ignition knock-limit curve must contain at most 128 samples";
    double previousKnockRpm = 0.0;
    for (const auto& sample : config.ignition.knockLimitCurve) {
        if (!inRange(sample.rpm, 0.0, 25'000.0) || !inRange(sample.advanceDegrees, -30.0, 80.0)
            || !inRange(sample.manifoldPressureKpa, 1.0, 2'000.0) || sample.rpm < previousKnockRpm)
            return "Ignition knock-limit curve must be finite and ordered by RPM";
        previousKnockRpm = sample.rpm;
    }
    std::unordered_set<std::uint32_t> cylinderIds;
    constexpr std::uint32_t mergeId = std::numeric_limits<std::uint32_t>::max() - 2U;
    for (const auto& cylinder : config.cylinders) {
        if (cylinder.id == 0 || cylinder.id >= mergeId || outOfRange("boreMm", cylinder.boreMm, minimumBoreStrokeMm, maximumBoreStrokeMm)
            || outOfRange("strokeMm", cylinder.strokeMm, minimumBoreStrokeMm, maximumBoreStrokeMm)
            || outOfRange("connectingRodMm", cylinder.connectingRodMm, cylinder.strokeMm * 0.5 + 0.01, 5'000.0)
            || outOfRange("pistonMassGrams", cylinder.pistonMassGrams, minimumPistonMassGrams, 2'500'000.0)
            || outOfRange("compressionRatio", cylinder.compressionRatio, 5.0, 20.0)
            || outOfRange("ignitionOffsetDegrees", cylinder.ignitionOffsetDegrees, -30.0, 30.0)
            || outOfRange("efficiencyOffset", cylinder.efficiencyOffset, -0.5, 0.5)
            || outOfRange("crankOffsetDegrees", cylinder.crankOffsetDegrees, -360.0, crankDomainDegreesOf(config.cycle))
            || outOfRange("bankOffsetDegrees", cylinder.bankOffsetDegrees, -360.0, 360.0)
            || !(cylinder.intakeRunnerLengthMm == 0.0
                || inRange(cylinder.intakeRunnerLengthMm, 5.0, 10'000.0))
            || !(cylinder.intakeRunnerDiameterMm == 0.0
                || inRange(cylinder.intakeRunnerDiameterMm, 2.5, 750.0))
            || outOfRange("exhaustPrimaryLengthMm", cylinder.exhaustPrimaryLengthMm, 0.0, 15'000.0)
            || outOfRange("soundAttenuation", cylinder.soundAttenuation, 0.0, 4.0)
            || outOfRange("blowByCoefficient", cylinder.blowByCoefficient, 0.0, 0.1)
            || outOfRange("connectingRodMassGrams", cylinder.connectingRodMassGrams, 1.0, 5'000'000.0)
            || outOfRange("pistonFrictionCoefficient", cylinder.pistonFrictionCoefficient, 0.0, 0.5)
            || outOfRange("pistonBreakawayForceN", cylinder.pistonBreakawayForceN, 0.0, 125'000.0)
            || outOfRange("pistonBreakawayVelocityMps", cylinder.pistonBreakawayVelocityMps, 0.001, 5.0)
            || outOfRange("pistonViscousFrictionNsPerM", cylinder.pistonViscousFrictionNsPerM, 0.0, 50'000.0)
            || outOfRange("articulatedJournalRadiusMm", cylinder.articulatedJournalRadiusMm, 0.0, 1'250.0)
            || outOfRange("articulatedJournalAngleDegrees", cylinder.articulatedJournalAngleDegrees, -720.0, 720.0)
            || outOfRange("deckHeightMm", cylinder.deckHeightMm, 0.0, 5'000.0)
            || outOfRange("compressionHeightMm", cylinder.compressionHeightMm, 0.0, 1'250.0)
            || outOfRange("wristPinOffsetMm", cylinder.wristPinOffsetMm, -100.0, 100.0)
            || outOfRange("pistonCrownVolumeCc", cylinder.pistonCrownVolumeCc, -31'250.0, 31'250.0)
            || outOfRange("headChamberVolumeCc", cylinder.headChamberVolumeCc, 0.0, 62'500.0)
            || outOfRange("headGasketThicknessMm", cylinder.headGasketThicknessMm, 0.0, 50.0)
            || outOfRange("connectingRodMomentOfInertiaKgM2", cylinder.connectingRodMomentOfInertiaKgM2, 0.0, 3'125.0)
            || cylinder.intakeValveCount < 1 || cylinder.intakeValveCount > 4
            || cylinder.exhaustValveCount < 1 || cylinder.exhaustValveCount > 4
            || !(cylinder.intakeValveDiameterMm == 0.0
                || inRange(cylinder.intakeValveDiameterMm, 2.5, 400.0))
            || !(cylinder.exhaustValveDiameterMm == 0.0
                || inRange(cylinder.exhaustValveDiameterMm, 2.5, 400.0)))
            return rangeFailure.empty() ? std::string("Cylinder IDs and dimensions must be finite and physically valid")
                                        : "Cylinder " + std::to_string(cylinder.id) + " value out of range: "
                                            + rangeFailure;
        if (cylinder.crankJournalId == 0)
            return "Every cylinder must explicitly reference a configured crank journal";
        if (!journalIds.contains(cylinder.crankJournalId))
            return "Cylinder crankJournalId must reference a configured crank journal";
        const auto journal = std::find_if(config.crankJournals.begin(), config.crankJournals.end(),
            [&cylinder](const auto& candidate) { return candidate.id == cylinder.crankJournalId; });
        if (journal != config.crankJournals.end()
            && std::abs(journal->throwMm * 2.0 - cylinder.strokeMm) > 0.05)
            return "Crank journal throw must equal half of the referenced cylinder stroke";
        const auto explicitDeckGeometry = cylinder.deckHeightMm > 0.0 || cylinder.compressionHeightMm > 0.0
            || cylinder.headChamberVolumeCc > 0.0 || cylinder.headGasketThicknessMm > 0.0
            || cylinder.pistonCrownVolumeCc != 0.0;
        if (explicitDeckGeometry && (cylinder.deckHeightMm <= 0.0 || cylinder.compressionHeightMm <= 0.0
            || cylinder.headChamberVolumeCc <= 0.0))
            return "Explicit chamber geometry requires positive deck height, compression height and head chamber volume";
        if (explicitDeckGeometry) {
            const auto areaMm2 = std::numbers::pi * cylinder.boreMm * cylinder.boreMm * 0.25;
            const auto deckClearanceMm = cylinder.deckHeightMm - cylinder.strokeMm * 0.5
                - cylinder.connectingRodMm - cylinder.compressionHeightMm;
            const auto clearanceCc = cylinder.headChamberVolumeCc - cylinder.pistonCrownVolumeCc
                + areaMm2 * (cylinder.headGasketThicknessMm + deckClearanceMm) / 1'000.0;
            const auto sweptCc = areaMm2 * cylinder.strokeMm / 1'000.0;
            if (clearanceCc <= 0.1 || std::abs((1.0 + sweptCc / clearanceCc) - cylinder.compressionRatio) > 0.25)
                return "Explicit chamber geometry must yield positive clearance and match compressionRatio";
        }
        cylinderIds.insert(cylinder.id);
    }
    const std::unordered_set<std::uint32_t> firingIds(config.firingOrder.begin(), config.firingOrder.end());
    if (cylinderIds.size() != config.cylinders.size()) return "Cylinder IDs must be unique";
    if (firingIds != cylinderIds) return "Firing order must contain every cylinder ID exactly once";
    for (const auto& cylinder : config.cylinders) {
        if (cylinder.connectingRodType == ConnectingRodType::articulated) {
            if (cylinder.masterCylinderId == 0 || cylinder.masterCylinderId == cylinder.id
                || !cylinderIds.contains(cylinder.masterCylinderId) || cylinder.articulatedJournalRadiusMm <= 0.0)
                return "Articulated rods must reference a distinct master cylinder and a positive articulation radius";
            const auto master = std::find_if(config.cylinders.begin(), config.cylinders.end(),
                [&cylinder](const auto& candidate) { return candidate.id == cylinder.masterCylinderId; });
            if (master == config.cylinders.end() || master->connectingRodType == ConnectingRodType::articulated)
                return "An articulated rod master must be a conventional or master rod";
        } else if (cylinder.masterCylinderId != 0 || cylinder.articulatedJournalRadiusMm != 0.0) {
            return "Only articulated rods may define a master cylinder or articulation radius";
        }
    }
    if (config.intakePaths.empty() || config.intakePaths.size() > 32)
        return "Intake topology must contain between 1 and 32 paths";
    std::unordered_set<std::uint32_t> intakePathIds;
    std::unordered_set<std::uint32_t> assignedIntakeCylinders;
    for (const auto& path : config.intakePaths) {
        const auto& intake = path.geometry;
        if (path.id == 0 || path.cylinderIds.empty() || !intakePathIds.insert(path.id).second
            || !inRange(intake.plenumVolumeLitres, smallestPlenumVolumeLitres, 12'000.0)
            || !inRange(intake.throttleDiameterMm, 2.5, 1'250.0)
            || intake.throttleCount < 1 || intake.throttleCount > 16
            || !inRange(intake.throttleDischargeCoefficient, 0.05, 1.5)
            || !inRange(intake.carburettor.venturiDiameterMm, 0.0, 1'000.0)
            || !inRange(intake.carburettor.mainJetFlowNumber, 5.0, 5000.0)
            || !inRange(intake.carburettor.pilotJetFlowNumber, 1.0, 2000.0)
            || !inRange(intake.carburettor.pilotCircuitFactor, 0.005, 1.0)
            || !inRange(intake.carburettor.needleClipPosition, 1.0, 5.0)
            || !inRange(intake.carburettor.airScrewTurns, 0.1, 6.0)
            || !inRange(intake.carburettor.idleScrewTurns, 0.0, carburettorMaximumIdleScrewTurns)
            || !inRange(intake.carburettor.jetLiftMm, 0.0, 500.0)
            || !inRange(intake.carburettor.jetDischargeCoefficient, 0.05, 1.0)
            || !inRange(intake.carburettor.wallFilmFraction, 0.0, 0.98)
            || !inRange(intake.carburettor.wallFilmTimeConstantSeconds, 1.0e-4, 5.0)
            || !inRange(intake.carburettor.acceleratorPumpStrokeCc, 0.0, 100.0)
            || !inRange(intake.carburettor.acceleratorPumpTimeConstantSeconds, 1.0e-3, 5.0)
            || !inRange(intake.carburettor.starterJetFlowNumber, 0.0, 20'000.0)
            || !inRange(intake.runnerLengthMm, 5.0, 10'000.0)
            || !inRange(intake.runnerDiameterMm, 2.5, 750.0)
            || !(intake.runnerPlenumDiameterMm == 0.0
                || inRange(intake.runnerPlenumDiameterMm, 2.5, 750.0))
            || !inRange(intake.airboxVolumeLitres, 0.0, 12'000.0)
            || !(intake.throttleDistanceFromValveMm >= 0.0
                && intake.throttleDistanceFromValveMm < intake.runnerLengthMm)
            || !inRange(intake.inletDuctLengthMm, 0.0, 25'000.0)
            || !inRange(intake.inletDuctDiameterMm, 0.0, 2'500.0)
            || !inRange(intake.bellmouthDiameterMm, 0.0, 5'000.0)
            || !inRange(intake.idleBypassAreaMm2, 0.0, 25'000.0)
            || !inRange(intake.throttleGamma, 0.2, 5.0))
            return "Intake path IDs and geometry must be valid";
        for (const auto cylinderId : path.cylinderIds)
            if (!cylinderIds.contains(cylinderId) || !assignedIntakeCylinders.insert(cylinderId).second)
                return "Intake paths must reference every cylinder exactly once";
    }
    if (assignedIntakeCylinders != cylinderIds)
        return "Configured intake paths must assign every cylinder exactly once";
    if (config.banks.size() > 32) return "Bank topology may contain at most 32 banks";
    std::unordered_set<std::uint32_t> assignedBankCylinders;
    std::unordered_set<std::uint32_t> bankIds;
    for (const auto& bank : config.banks) {
        // Radial layouts conventionally enumerate cylinder axes over
        // [0, 360), whereas V/flat layouts commonly use signed angles.
        // Both describe the same physical circle and must remain valid.
        if (bank.id == 0 || bank.cylinderIds.empty() || !bankIds.insert(bank.id).second || !inRange(bank.angleDegrees, -360.0, 360.0)
            || !validateCamshaft(bank.camshafts)) return "Bank IDs, angles and camshafts must be valid";
        if (!intakePathIds.contains(bank.intakeId)) return "Bank intakeId must reference a configured intake path";
        for (const auto cylinderId : bank.cylinderIds) {
            if (!cylinderIds.contains(cylinderId) || !assignedBankCylinders.insert(cylinderId).second)
                return "Bank cylinder references must be unique and valid";
            const auto cylinder = std::find_if(config.cylinders.begin(), config.cylinders.end(),
                [cylinderId](const auto& candidate) { return candidate.id == cylinderId; });
            if (cylinder == config.cylinders.end() || cylinder->bankId != bank.id)
                return "Cylinder bankId must match the bank that contains the cylinder";
        }
    }
    if (!config.banks.empty() && assignedBankCylinders != cylinderIds)
        return "Configured banks must assign every cylinder exactly once";
    if (config.exhaustPaths.size() > 8) return "Exhaust topology may contain at most 8 paths supported by audio";
    std::unordered_set<std::uint32_t> exhaustPathIds;
    std::unordered_set<std::uint32_t> assignedExhaustCylinders;
    std::size_t exhaustAcousticSideBranchCount = 0;
    for (const auto& path : config.exhaustPaths) {
        const auto& exhaust = path.geometry;
        if (path.id == 0 || path.cylinderIds.empty() || !exhaustPathIds.insert(path.id).second || !inRange(path.audioVolume, 0.0, 8.0)
            || path.turbocharger >= static_cast<std::int32_t>(config.forcedInduction.turbochargerCount)
            || path.impulseResponsePath.size() > 1'024
            || !inRange(exhaust.primaryLengthMm, 25.0, 15'000.0)
            || !inRange(exhaust.primaryDiameterMm, 4.0, 1'000.0)
            || !inRange(exhaust.collectorDiameterMm, 4.0, 1'500.0)
            || !inRange(exhaust.outletDiameterMm, 4.0, 1'500.0)
            || !inRange(exhaust.mufflerRestriction, 0.0, 1.0)
            || !(exhaust.collectorVolumeLitres == 0.0
                 || inRange(exhaust.collectorVolumeLitres, 0.05, 25'000.0))
            || !inRange(exhaust.outletDischargeCoefficient, 0.02, 1.5)
            || !inRange(exhaust.mufflerChamberDiameterMm, 0.0, 3'000.0)
            || !inRange(exhaust.mufflerChamberLengthMm, 0.0, 15'000.0)
            || !inRange(exhaust.mufflerPackingFlowResistivityPaSPerM2, 0.0, 200'000.0)
            || !inRange(exhaust.mufflerPackingThicknessMm, 0.0, 1'500.0)
            || !inRange(exhaust.mufflerPerforatedOpenAreaRatio, 0.0, 1.0)
            || !validMufflerPacking(exhaust)
            || !validMidpipe(exhaust)
            || !validPoint(path.acousticPositionM)
            || !validPoint(path.acousticAxis)
            || path.acousticAxis.x * path.acousticAxis.x
                + path.acousticAxis.y * path.acousticAxis.y
                + path.acousticAxis.z * path.acousticAxis.z < 1.0e-12)
            return "Exhaust path IDs and audio volumes must be valid";
        for (const auto cylinderId : path.cylinderIds)
            if (!cylinderIds.contains(cylinderId) || !assignedExhaustCylinders.insert(cylinderId).second)
                return "Exhaust paths must reference every cylinder at most once";

        if (path.network) {
            const auto& network = *path.network;
            if (network.components.empty() || network.components.size() > 256)
                return "Custom exhaust graphs must contain between 1 and 256 components";
            if (network.connections.size() > 1'024)
                return "Custom exhaust graphs may contain at most 1024 component connections";

            std::unordered_map<std::uint32_t, const ExhaustComponentConfig*> components;
            std::unordered_map<std::uint32_t, std::vector<std::uint32_t>> outgoing;
            std::unordered_map<std::uint32_t, std::size_t> componentIncoming;
            std::unordered_map<std::uint32_t, std::size_t> cylinderIncoming;
            components.reserve(network.components.size());
            outgoing.reserve(network.components.size());
            componentIncoming.reserve(network.components.size());
            cylinderIncoming.reserve(network.components.size());
            for (const auto& component : network.components) {
                const auto requiresLength = component.type == ExhaustComponentType::pipe
                    || component.type == ExhaustComponentType::resonator
                    || component.type == ExhaustComponentType::muffler
                    || component.type == ExhaustComponentType::catalyst;
                if (static_cast<std::uint8_t>(component.type)
                        > static_cast<std::uint8_t>(ExhaustComponentType::crossover)
                    || component.id == 0 || !components.emplace(component.id, &component).second
                    || !inRange(component.lengthMm, requiresLength ? 1.0 : 0.0, 30'000.0)
                    || !inRange(component.diameterMm, 4.0, 3'000.0)
                    || !(component.outletDiameterMm == 0.0
                        || inRange(component.outletDiameterMm, 4.0, 3'000.0))
                    || !inRange(component.volumeLitres, 0.0, 25'000.0)
                    || !inRange(component.restriction, 0.0, 20.0)
                    || !inRange(component.resonanceHz, 0.0, 20'000.0)
                    || !inRange(component.acousticGain, 0.0, 8.0)
                    || !inRange(component.dischargeCoefficient, 0.02, 1.5)
                    || !inRange(component.packingFlowResistivityPaSPerM2, 0.0, 200'000.0)
                    || !inRange(component.packingThicknessMm, 0.0, 300.0)
                    || !inRange(component.perforatedOpenAreaRatio, 0.0, 1.0)
                    || !inRange(component.catalystCellDensityCpsi, 0.0, 5'000.0)
                    || !inRange(component.catalystOpenAreaRatio, 0.0, 0.99)
                    || !inRange(component.catalystSubstrateVolumetricHeatCapacityJPerM3K,
                        0.0, 10'000'000.0)
                    || !inRange(component.crossoverCoupling, 0.0, 1.0)
                    || !validPoint(component.acousticPositionM)
                    || !validPoint(component.acousticAxis)
                    || (component.type == ExhaustComponentType::outlet
                        && component.acousticAxis.x * component.acousticAxis.x
                            + component.acousticAxis.y * component.acousticAxis.y
                            + component.acousticAxis.z * component.acousticAxis.z
                            < 1.0e-12))
                    return "Custom exhaust component IDs and dimensions must be finite, unique and valid";
                if (component.type == ExhaustComponentType::crossover) {
                    if (component.lengthMm != 0.0
                        || component.volumeLitres != 0.0
                        || component.outletDiameterMm != 0.0
                        || component.resonanceHz != 0.0)
                        return "An exhaust crossover is a compact four-port and requires zero length, volume, outlet diameter and resonance; author real pipe lengths on its four neighbours";
                } else if (component.crossoverCoupling != 0.0) {
                    return "Crossover coupling may only be authored on an exhaust crossover";
                }
                const auto hasPacking = component.packingFlowResistivityPaSPerM2 > 0.0
                    || component.packingThicknessMm > 0.0
                    || component.perforatedOpenAreaRatio > 0.0;
                if (hasPacking
                    && (component.type != ExhaustComponentType::muffler
                        || component.packingFlowResistivityPaSPerM2 <= 0.0
                        || component.packingThicknessMm <= 0.0
                        || component.perforatedOpenAreaRatio <= 0.0))
                    return "Porous packing requires a muffler with resistivity, thickness and perforated open area";
                if (hasPacking) {
                    const auto inletRadiusM = component.diameterMm * 0.0005;
                    const auto outletDiameterMm = component.outletDiameterMm > 0.0
                        ? component.outletDiameterMm : component.diameterMm;
                    const auto outletRadiusM = outletDiameterMm * 0.0005;
                    const auto inletAreaM2 = std::numbers::pi
                        * inletRadiusM * inletRadiusM;
                    const auto outletAreaM2 = std::numbers::pi
                        * outletRadiusM * outletRadiusM;
                    const auto coreMeanAreaM2 = (inletAreaM2
                        + std::sqrt(inletAreaM2 * outletAreaM2)
                        + outletAreaM2) / 3.0;
                    // m2 * mm has the same numerical value as litres. A packed
                    // straight-through component needs volume outside that
                    // swept core; otherwise its material fields describe a can
                    // which has no physical annulus to occupy.
                    const auto coreVolumeLitres = coreMeanAreaM2
                        * component.lengthMm;
                    if (!(component.volumeLitres
                            > coreVolumeLitres * (1.0 + 1.0e-9)))
                        return "Porous packing requires outer-can volume greater than the perforated core volume";
                }
                const auto hasCatalystMonolith =
                    component.catalystCellDensityCpsi > 0.0
                    || component.catalystOpenAreaRatio > 0.0
                    || component.catalystSubstrateVolumetricHeatCapacityJPerM3K > 0.0;
                if (hasCatalystMonolith) {
                    const auto monolith = catalystMonolithGeometry(
                        component.catalystCellDensityCpsi,
                        component.catalystOpenAreaRatio);
                    if (component.type != ExhaustComponentType::catalyst
                        || component.catalystCellDensityCpsi < 25.0
                        || component.catalystOpenAreaRatio < 0.05
                        || component.catalystSubstrateVolumetricHeatCapacityJPerM3K
                            < 100'000.0
                        || !monolith.active
                        || monolith.cellPitchM > component.diameterMm * 0.001)
                        return "Catalyst monolith requires a catalyst, 25..5000 cpsi, 0.05..0.99 open area, 0.1..10 MJ/m3/K substrate capacity and at least one cell across its diameter";
                }
                outgoing.try_emplace(component.id);
                componentIncoming.try_emplace(component.id, 0U);
                cylinderIncoming.try_emplace(component.id, 0U);
            }

            std::unordered_set<std::uint64_t> uniqueConnections;
            std::unordered_map<std::uint32_t, std::array<bool, 2>>
                usedCrossoverInputs;
            std::unordered_map<std::uint32_t, std::array<bool, 2>>
                usedCrossoverOutputs;
            for (const auto& connection : network.connections) {
                if (!components.contains(connection.fromComponentId)
                    || !components.contains(connection.toComponentId)
                    || connection.fromComponentId == connection.toComponentId)
                    return "Custom exhaust connections must reference two distinct configured components";
                const auto key = (static_cast<std::uint64_t>(connection.fromComponentId) << 32U)
                    | connection.toComponentId;
                if (!uniqueConnections.insert(key).second)
                    return "Custom exhaust component connections must be unique";
                const auto fromType = components.at(
                    connection.fromComponentId)->type;
                const auto toType = components.at(
                    connection.toComponentId)->type;
                const auto validPort = [](std::uint8_t port) noexcept {
                    return port <= 1U;
                };
                if (fromType == ExhaustComponentType::crossover) {
                    if (!validPort(connection.fromPort))
                        return "Every exhaust crossover output connection requires from_port 0 or 1";
                    if (usedCrossoverOutputs[connection.fromComponentId]
                            [connection.fromPort])
                        return "Each exhaust crossover output port may be connected exactly once";
                    usedCrossoverOutputs[connection.fromComponentId]
                        [connection.fromPort] = true;
                } else if (connection.fromPort == exhaustSideBranchPort
                        && (fromType == ExhaustComponentType::merge
                            || fromType == ExhaustComponentType::splitter)) {
                    if (toType == ExhaustComponentType::merge || toType == ExhaustComponentType::splitter
                        || toType == ExhaustComponentType::crossover)
                        return "A side branch (port 2) joins a merge or a splitter to a duct";
                } else if (connection.fromPort
                        != unspecifiedExhaustComponentPort) {
                    return "from_port may only be set on an exhaust crossover, or 2 (a side branch) on a merge or a splitter";
                }
                if (toType == ExhaustComponentType::crossover) {
                    if (!validPort(connection.toPort))
                        return "Every exhaust crossover input connection requires to_port 0 or 1";
                    if (usedCrossoverInputs[connection.toComponentId]
                            [connection.toPort])
                        return "Each exhaust crossover input port may be connected exactly once";
                    usedCrossoverInputs[connection.toComponentId]
                        [connection.toPort] = true;
                } else if (connection.toPort == exhaustSideBranchPort
                        && (toType == ExhaustComponentType::merge
                            || toType == ExhaustComponentType::splitter)) {
                    if (fromType == ExhaustComponentType::merge || fromType == ExhaustComponentType::splitter
                        || fromType == ExhaustComponentType::crossover)
                        return "A side branch (port 2) joins a merge or a splitter to a duct";
                } else if (connection.toPort
                        != unspecifiedExhaustComponentPort) {
                    return "to_port may only be set on an exhaust crossover, or 2 (a side branch) on a merge or a splitter";
                }
                if (fromType == ExhaustComponentType::crossover
                    && toType == ExhaustComponentType::crossover)
                    return "Exhaust crossovers must be separated by a finite duct";
                const auto isBranchJunction = [](ExhaustComponentType type) {
                    return type == ExhaustComponentType::merge
                        || type == ExhaustComponentType::splitter;
                };
                if ((fromType == ExhaustComponentType::crossover
                        && isBranchJunction(toType))
                    || (toType == ExhaustComponentType::crossover
                        && isBranchJunction(fromType)))
                    return "Every exhaust crossover port must connect through a finite duct, not directly to a merge or splitter";
                outgoing[connection.fromComponentId].push_back(connection.toComponentId);
                ++componentIncoming[connection.toComponentId];
            }

            std::unordered_set<std::uint32_t> pathCylinderIds(path.cylinderIds.begin(), path.cylinderIds.end());
            std::unordered_set<std::uint32_t> connectedCylinderIds;
            for (const auto& connection : network.cylinderConnections) {
                if (!pathCylinderIds.contains(connection.cylinderId)
                    || !components.contains(connection.componentId)
                    || !connectedCylinderIds.insert(connection.cylinderId).second)
                    return "Custom exhaust graphs must map each path cylinder to one configured component";
                if (components.at(connection.componentId)->type
                        == ExhaustComponentType::crossover)
                    return "A cylinder cannot connect directly to an exhaust crossover; insert a finite inlet duct";
                ++cylinderIncoming[connection.componentId];
            }
            if (connectedCylinderIds != pathCylinderIds)
                return "Custom exhaust graphs must map every path cylinder exactly once";

            const auto isTerminalSideBranch = [&components, &outgoing](
                std::uint32_t componentId) {
                const auto component = components.find(componentId);
                const auto outputs = outgoing.find(componentId);
                return component != components.end()
                    && outputs != outgoing.end()
                    && component->second->type == ExhaustComponentType::resonator
                    && outputs->second.empty();
            };
            const auto pathAcousticSideBranchCount = static_cast<std::size_t>(
                std::count_if(network.components.begin(), network.components.end(),
                    [&isTerminalSideBranch](const auto& component) {
                        return isTerminalSideBranch(component.id);
                    }));
            if (pathAcousticSideBranchCount
                    > maximumExhaustAcousticSideBranches
                        - exhaustAcousticSideBranchCount)
                return "An engine may contain at most 8 terminal exhaust resonators";
            exhaustAcousticSideBranchCount += pathAcousticSideBranchCount;
            std::unordered_map<std::uint32_t, std::vector<std::uint32_t>>
                flowOutgoing;
            flowOutgoing.reserve(outgoing.size());
            for (const auto& [componentId, outputs] : outgoing) {
                auto& flowOutputs = flowOutgoing[componentId];
                for (const auto nextId : outputs)
                    if (!isTerminalSideBranch(nextId))
                        flowOutputs.push_back(nextId);
            }

            for (const auto& component : network.components) {
                const auto incoming = componentIncoming[component.id] + cylinderIncoming[component.id];
                if (component.inletValve
                    && (component.type != ExhaustComponentType::pipe
                        || isTerminalSideBranch(component.id)
                        || componentIncoming[component.id] != 1U
                        || cylinderIncoming[component.id] != 0U))
                    return "An active exhaust valve sits at the inlet of a pipe fed by exactly one other part, not by a cylinder";
                if (isTerminalSideBranch(component.id)) {
                    if (componentIncoming[component.id] != 1U
                        || cylinderIncoming[component.id] != 0U)
                        return "A terminal exhaust resonator requires exactly one component attachment and no cylinder mapping";
                    continue;
                }
                const auto outputCount = flowOutgoing[component.id].size();
                switch (component.type) {
                case ExhaustComponentType::merge:
                    if (incoming < 2 || outputCount != 1)
                        return "An exhaust merge requires at least two inputs and exactly one output";
                    break;
                case ExhaustComponentType::splitter:
                    if (incoming != 1 || outputCount < 2)
                        return "An exhaust splitter requires exactly one input and at least two outputs";
                    break;
                case ExhaustComponentType::crossover:
                    if (incoming != 2 || outputCount != 2
                        || usedCrossoverInputs[component.id]
                            != std::array<bool, 2> { true, true }
                        || usedCrossoverOutputs[component.id]
                            != std::array<bool, 2> { true, true })
                        return "An exhaust crossover requires exactly two explicitly paired input ports and two explicitly paired output ports";
                    for (const auto nextId : outgoing[component.id])
                        if (isTerminalSideBranch(nextId))
                            return "An exhaust crossover port cannot terminate in an acoustic-only resonator branch";
                    break;
                case ExhaustComponentType::outlet:
                    if (incoming < 1 || outputCount != 0
                        || !outgoing[component.id].empty())
                        return "An exhaust outlet requires at least one input and cannot have outputs";
                    break;
                default:
                    if (incoming != 1 || outputCount != 1)
                        return "Pipe, resonator, muffler and catalyst components require one input and one output";
                    break;
                }
            }

            // Kahn's algorithm rejects cycles independently of cylinder roots.
            auto remainingIncoming = componentIncoming;
            std::vector<std::uint32_t> ready;
            ready.reserve(network.components.size());
            for (const auto& component : network.components)
                if (remainingIncoming[component.id] == 0) ready.push_back(component.id);
            std::size_t visitedCount = 0;
            for (std::size_t index = 0; index < ready.size(); ++index) {
                const auto componentId = ready[index];
                ++visitedCount;
                for (const auto nextId : outgoing[componentId])
                    if (--remainingIncoming[nextId] == 0) ready.push_back(nextId);
            }
            if (visitedCount != network.components.size())
                return "Custom exhaust component connections must form an acyclic graph";

            std::unordered_set<std::uint32_t> reachable;
            std::vector<std::uint32_t> frontier;
            for (const auto& connection : network.cylinderConnections)
                if (reachable.insert(connection.componentId).second) frontier.push_back(connection.componentId);
            for (std::size_t index = 0; index < frontier.size(); ++index)
                for (const auto nextId : outgoing[frontier[index]])
                    if (reachable.insert(nextId).second) frontier.push_back(nextId);
            if (reachable.size() != network.components.size())
                return "Every custom exhaust component must be reachable from a mapped cylinder";

            std::unordered_map<std::uint32_t, bool> reachesOutletMemo;
            std::function<bool(std::uint32_t)> everyRouteReachesOutlet = [&](std::uint32_t componentId) {
                if (const auto found = reachesOutletMemo.find(componentId); found != reachesOutletMemo.end())
                    return found->second;
                const auto component = components.at(componentId);
                if (component->type == ExhaustComponentType::outlet)
                    return reachesOutletMemo.emplace(componentId, true).first->second;
                const auto& outputs = flowOutgoing[componentId];
                const auto valid = !outputs.empty() && std::all_of(outputs.begin(), outputs.end(),
                    [&everyRouteReachesOutlet](std::uint32_t nextId) { return everyRouteReachesOutlet(nextId); });
                reachesOutletMemo.emplace(componentId, valid);
                return valid;
            };
            for (const auto& connection : network.cylinderConnections)
                if (!everyRouteReachesOutlet(connection.componentId))
                    return "Every route from a cylinder in a custom exhaust graph must reach an outlet";

            // Bound path expansion so a valid-looking splitter DAG cannot
            // cause exponential work or memory use in the runtime compiler.
            constexpr std::size_t maximumRoutes = 4'096;
            std::unordered_map<std::uint32_t, std::size_t> routeCounts;
            routeCounts.reserve(network.components.size());
            for (auto iterator = ready.rbegin(); iterator != ready.rend(); ++iterator) {
                const auto componentId = *iterator;
                if (components.at(componentId)->type == ExhaustComponentType::outlet) {
                    routeCounts[componentId] = 1;
                    continue;
                }
                std::size_t count = 0;
                for (const auto nextId : flowOutgoing[componentId])
                    count = std::min(maximumRoutes + 1, count + routeCounts[nextId]);
                routeCounts[componentId] = count;
            }
            std::size_t totalRoutes = 0;
            for (const auto& connection : network.cylinderConnections)
                totalRoutes = std::min(maximumRoutes + 1,
                    totalRoutes + routeCounts[connection.componentId]);
            if (totalRoutes > maximumRoutes)
                return "Custom exhaust graph expands to more than 4096 cylinder-to-outlet routes";
        }
    }
    if (!config.exhaustPaths.empty() && assignedExhaustCylinders != cylinderIds)
        return "Configured exhaust paths must assign every cylinder exactly once";
    for (const auto& bank : config.banks)
        if (!config.exhaustPaths.empty() && bank.exhaustPathId != 0 && !exhaustPathIds.contains(bank.exhaustPathId))
            return "Bank exhaustPathId must reference a configured exhaust path";
    const auto displacement = engineDisplacementLitres(config);
    // The tolerance lets a 50 cc design through the round trip from litres
    // to bore and stroke and back.
    if (!inRange(displacement, 0.0005, 100'000.0)) return "Total displacement must be between 0.5 cc and 100,000 litres";
    return std::nullopt;
}

} // namespace

std::optional<std::string> validateEngineConfig(const EngineConfig& config) {
    return validateOrRepair(config, nullptr);
}

std::vector<std::string> repairEngineConfigRanges(EngineConfig& config) {
    std::vector<std::string> repairs;
    // Each pass clamps every value it reaches; a refusal of another kind
    // stops the pass early, so clamping can uncover nothing it did not see.
    (void)validateOrRepair(config, &repairs);
    return repairs;
}

const char* afterfireBlockerName(std::uint32_t mask) noexcept {
    // Ordered by how much the reading tells someone who hears no pop. An
    // unauthored feature explains everything else, so it leads.
    if (afterfireBlocked(mask, AfterfireBlocker::notAuthored)) return "not authored";
    if (afterfireBlocked(mask, AfterfireBlocker::ignitionOff)) return "ignition off";
    if (afterfireBlocked(mask, AfterfireBlocker::cranking)) return "cranking";
    if (afterfireBlocked(mask, AfterfireBlocker::notArmed)) return "never armed (rev it up at full throttle)";
    if (afterfireBlocked(mask, AfterfireBlocker::belowMinimumRpm)) return "engine speed too low";
    if (afterfireBlocked(mask, AfterfireBlocker::throttleOpen)) return "throttle open";
    if (afterfireBlocked(mask, AfterfireBlocker::revLimiterActive)) return "rev limiter active";
    if (afterfireBlocked(mask, AfterfireBlocker::overboostCut)) return "overboost cut";
    if (afterfireBlocked(mask, AfterfireBlocker::fuelCutInactive)) return "not in overrun fuel cut";
    return "";
}

std::vector<double> spreadGearRatios(const std::vector<double>& ratios, std::size_t count) {
    if (ratios.empty() || count == 0U) return {};
    const auto first = ratios.front();
    const auto top = ratios.size() > 1U ? ratios.back() : first;
    std::vector<double> spread(count);
    for (std::size_t step = 0; step < count; ++step)
        spread[step] = count == 1U ? first
            : first * std::pow(top / first, static_cast<double>(step) / static_cast<double>(count - 1U));
    return spread;
}

const char* shiftStyleName(ShiftStyle style) noexcept {
    switch (style) {
    case ShiftStyle::manual: return "manual";
    case ShiftStyle::sequential: return "sequential";
    case ShiftStyle::dualClutch: return "dual_clutch";
    case ShiftStyle::cvt: return "cvt";
    case ShiftStyle::automatedManual: return "automated_manual";
    }
    return "manual";
}

std::optional<ShiftStyle> parseShiftStyle(const std::string& name) noexcept {
    if (name == "manual") return ShiftStyle::manual;
    if (name == "sequential") return ShiftStyle::sequential;
    if (name == "dual_clutch") return ShiftStyle::dualClutch;
    if (name == "cvt") return ShiftStyle::cvt;
    if (name == "automated_manual") return ShiftStyle::automatedManual;
    return std::nullopt;
}

double engineBrakeLiftMm(const EngineBrakeConfig& brake, double phaseDegrees,
                         std::uint32_t exhaustValveCount) noexcept {
    if (!(brake.valveLiftMm > 0.0) || !(brake.durationDegrees > 0.0)) return 0.0;
    const auto distance = std::remainder(phaseDegrees - brake.peakAfterTdcDegrees, 720.0);
    const auto half = 0.5 * brake.durationDegrees;
    if (!(std::abs(distance) < half)) return 0.0;
    const auto shape = std::cos(0.5 * std::numbers::pi * distance / half);
    return brake.valveLiftMm * shape * shape / static_cast<double>(std::max<std::uint32_t>(1, exhaustValveCount));
}

} // namespace enginelab
