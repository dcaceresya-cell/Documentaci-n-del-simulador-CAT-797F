#include <enginelab/foundation/IntakeResize.hpp>

#include <algorithm>
#include <cmath>
#include <numbers>
#include <string>

namespace enginelab {
namespace {

template <typename Config>
[[nodiscard]] auto* pathOf(Config& config, std::uint32_t pathId) {
    const auto path = std::find_if(config.intakePaths.begin(), config.intakePaths.end(),
                                   [pathId](const IntakePathConfig& item) { return item.id == pathId; });
    return path != config.intakePaths.end() ? &*path : nullptr;
}

[[nodiscard]] bool within(double value, double low, double high) {
    return std::isfinite(value) && value >= low && value <= high;
}

/** One path mirrors the engine-wide intake (normaliseEngineConfig), from
    whichever side it inherits. */
void mirrorSinglePath(EngineConfig& config) {
    if (config.intakePaths.size() != 1) return;
    const auto& geometry = config.intakePaths.front().geometry;
    config.intake = geometry;
    config.plenumVolumeLitres = geometry.plenumVolumeLitres;
    config.throttleDiameterMm = geometry.throttleDiameterMm;
}

/** The velocity one metre of head gives, m/s, at which a flow number is
    measured (CarburettorModel::jetAreaM2). */
const double jetReferenceVelocityMps = std::sqrt(2.0 * 9.80665);

} // namespace

double jetHoleHundredthsMm(double flowNumber, double dischargeCoefficient) noexcept {
    if (!(flowNumber > 0.0)) return 0.0;
    const auto coefficient = std::clamp(dischargeCoefficient, 0.05, 1.0);
    const auto areaM2 = flowNumber * 1.0e-6 / 60.0 / (coefficient * jetReferenceVelocityMps);
    return std::sqrt(4.0 * areaM2 / std::numbers::pi) * 1.0e5;
}

double jetFlowNumberForHole(double holeHundredthsMm, double dischargeCoefficient) noexcept {
    if (!(holeHundredthsMm > 0.0)) return 0.0;
    const auto coefficient = std::clamp(dischargeCoefficient, 0.05, 1.0);
    const auto diameterM = holeHundredthsMm * 1.0e-5;
    return 0.25 * std::numbers::pi * diameterM * diameterM * coefficient * jetReferenceVelocityMps * 60.0e6;
}

std::optional<IntakePartSize> intakePartSize(const EngineConfig& config, std::uint32_t pathId,
                                             IntakePart part, std::size_t cylinderIndex) {
    const auto* path = pathOf(config, pathId);
    if (path == nullptr) return std::nullopt;
    const auto& geometry = path->geometry;
    IntakePartSize size;
    switch (part) {
    case IntakePart::runner: {
        const auto* cylinder = cylinderIndex < config.cylinders.size() ? &config.cylinders[cylinderIndex] : nullptr;
        const auto ownLength = cylinder != nullptr && cylinder->intakeRunnerLengthMm > 0.0;
        const auto ownDiameter = cylinder != nullptr && cylinder->intakeRunnerDiameterMm > 0.0;
        size.first = ownLength ? cylinder->intakeRunnerLengthMm : geometry.runnerLengthMm;
        size.second = ownDiameter ? cylinder->intakeRunnerDiameterMm : geometry.runnerDiameterMm;
        size.sharedByRunners = !ownLength && !ownDiameter && path->cylinderIds.size() > 1;
        break;
    }
    case IntakePart::plenum: size.first = geometry.plenumVolumeLitres; break;
    case IntakePart::throttle: size.first = geometry.throttleDiameterMm; break;
    }
    return size;
}

std::string resizeIntakePart(EngineConfig& config, std::uint32_t pathId, IntakePart part,
                             std::size_t cylinderIndex, double first, double second) {
    auto* path = pathOf(config, pathId);
    if (path == nullptr) return "The engine has no intake path " + std::to_string(pathId) + ".";
    auto& geometry = path->geometry;
    switch (part) {
    case IntakePart::runner: {
        if (!within(first, 30.0, 2'000.0)) return "A runner is 30 to 2,000 mm long.";
        if (!within(second, 10.0, 200.0)) return "A runner is 10 to 200 mm across.";
        auto* cylinder = cylinderIndex < config.cylinders.size() ? &config.cylinders[cylinderIndex] : nullptr;
        // The cylinder's own size where it has one; the path's, which every
        // runner without its own shares, otherwise.
        if (cylinder != nullptr && cylinder->intakeRunnerLengthMm > 0.0) cylinder->intakeRunnerLengthMm = first;
        else geometry.runnerLengthMm = first;
        if (cylinder != nullptr && cylinder->intakeRunnerDiameterMm > 0.0) cylinder->intakeRunnerDiameterMm = second;
        else geometry.runnerDiameterMm = second;
        break;
    }
    case IntakePart::plenum:
        if (!within(first, 0.05, 40.0)) return "A plenum holds 0.05 to 40 litres.";
        geometry.plenumVolumeLitres = first;
        break;
    case IntakePart::throttle: {
        if (!within(first, 10.0, 150.0)) return "A throttle bore is 10 to 150 mm.";
        auto& carburettor = geometry.carburettor;
        if (carburettor.enabled && !(carburettor.venturiDiameterMm > 0.0) && geometry.throttleDiameterMm > 0.0) {
            const auto ratio = first / geometry.throttleDiameterMm;
            carburettor.mainJetFlowNumber = std::clamp(carburettor.mainJetFlowNumber * ratio * ratio, 5.0, 5'000.0);
        }
        geometry.throttleDiameterMm = first;
        break;
    }
    }
    mirrorSinglePath(config);
    return {};
}

std::optional<CarburettorTune> carburettorTune(const EngineConfig& config, std::uint32_t pathId) {
    const auto* path = pathOf(config, pathId);
    if (path == nullptr || !path->geometry.carburettor.enabled) return std::nullopt;
    const auto& carburettor = path->geometry.carburettor;
    return CarburettorTune { carburettor.mainJetFlowNumber, carburettor.pilotJetFlowNumber,
                             carburettor.needleClipPosition, carburettor.airScrewTurns,
                             carburettor.idleScrewTurns };
}

std::string tuneCarburettor(EngineConfig& config, std::uint32_t pathId, const CarburettorTune& tune) {
    auto* path = pathOf(config, pathId);
    if (path == nullptr) return "The engine has no intake path " + std::to_string(pathId) + ".";
    auto& carburettor = path->geometry.carburettor;
    if (!carburettor.enabled) return "Intake path " + std::to_string(pathId) + " has no carburettor.";
    if (!within(tune.mainJetFlowNumber, 50.0, 1'000.0)) return "A main jet is a 50 to a 1,000.";
    if (!within(tune.pilotJetFlowNumber, 10.0, 150.0)) return "A pilot jet is a 10 to a 150.";
    if (!within(tune.needleClipPosition, 1.0, 5.0)) return "The needle clip is in position 1 to 5.";
    if (!within(tune.airScrewTurns, 0.0, 5.0)) return "The air screw is 0 to 5 turns out.";
    if (!within(tune.idleScrewTurns, 0.0, carburettorMaximumIdleScrewTurns))
        return "The idle screw is 0 to 8 turns in.";
    carburettor.mainJetFlowNumber = tune.mainJetFlowNumber;
    carburettor.pilotJetFlowNumber = tune.pilotJetFlowNumber;
    carburettor.needleClipPosition = tune.needleClipPosition;
    carburettor.airScrewTurns = tune.airScrewTurns;
    carburettor.idleScrewTurns = tune.idleScrewTurns;
    mirrorSinglePath(config);
    return {};
}

} // namespace enginelab
