#include <enginelab/serialization/YamlEngineSerializer.hpp>
#include <enginelab/foundation/TwoStrokePorts.hpp>
#include <yaml-cpp/yaml.h>
#include <stdexcept>

namespace enginelab {
namespace {
void readCarburettor(const YAML::Node& intake, CarburettorConfig& carburettor) {
    const auto node = intake["carburettor"];
    if (!node) return;
    carburettor.enabled = node["enabled"].as<bool>(carburettor.enabled);
    carburettor.venturiDiameterMm = node["venturi_diameter_mm"].as<double>(carburettor.venturiDiameterMm);
    carburettor.mainJetFlowNumber = node["main_jet_flow_number"].as<double>(carburettor.mainJetFlowNumber);
    carburettor.pilotJetFlowNumber = node["pilot_jet_flow_number"].as<double>(carburettor.pilotJetFlowNumber);
    carburettor.pilotCircuitFactor = node["pilot_circuit_factor"].as<double>(carburettor.pilotCircuitFactor);
    carburettor.needleClipPosition = node["needle_clip_position"].as<double>(carburettor.needleClipPosition);
    carburettor.fixedVenturi = node["fixed_venturi"].as<bool>(carburettor.fixedVenturi);
    carburettor.airScrewTurns = node["air_screw_turns"].as<double>(carburettor.airScrewTurns);
    carburettor.idleScrewTurns = node["idle_screw_turns"].as<double>(carburettor.idleScrewTurns);
    carburettor.jetLiftMm = node["jet_lift_mm"].as<double>(carburettor.jetLiftMm);
    carburettor.jetDischargeCoefficient = node["jet_discharge_coefficient"].as<double>(carburettor.jetDischargeCoefficient);
    carburettor.wallFilmFraction = node["wall_film_fraction"].as<double>(carburettor.wallFilmFraction);
    carburettor.wallFilmTimeConstantSeconds = node["wall_film_time_constant_s"].as<double>(carburettor.wallFilmTimeConstantSeconds);
    carburettor.acceleratorPumpStrokeCc = node["accelerator_pump_stroke_cc"].as<double>(carburettor.acceleratorPumpStrokeCc);
    carburettor.acceleratorPumpTimeConstantSeconds = node["accelerator_pump_time_constant_s"].as<double>(carburettor.acceleratorPumpTimeConstantSeconds);
    carburettor.starterJetFlowNumber = node["starter_jet_flow_number"].as<double>(carburettor.starterJetFlowNumber);
}

[[nodiscard]] std::uint8_t decodeOptionalCrossoverPort(
    const YAML::Node& object, const char* key) {
    const auto encoded = object[key];
    if (!encoded) return unspecifiedExhaustComponentPort;
    const auto value = encoded.as<unsigned>();
    // 0 and 1 are a crossover's ports, 2 a merge's or a splitter's side
    // branch (an H-pipe's balance pipe); validation says which fits where.
    if (value > exhaustSideBranchPort)
        throw std::invalid_argument(
            std::string("Exhaust port must be 0, 1 or 2 (a side branch): ") + key);
    return static_cast<std::uint8_t>(value);
}
[[nodiscard]] const char* afterfireStrategyName(
    ExhaustAfterfireStrategy value) noexcept {
    switch (value) {
    case ExhaustAfterfireStrategy::cleanDfco: return "clean_dfco";
    case ExhaustAfterfireStrategy::lateSparkOverrun:
        return "late_spark_overrun";
    }
    return "clean_dfco";
}
[[nodiscard]] ExhaustAfterfireStrategy decodeAfterfireStrategy(
    std::string_view value) {
    // The anti-lag and chopped-fuel strategies were removed: files that still
    // name them read as a clean fuel cut.
    if (value == "clean_dfco" || value == "continuous_anti_lag"
        || value == "discrete_afterfire")
        return ExhaustAfterfireStrategy::cleanDfco;
    if (value == "late_spark_overrun")
        return ExhaustAfterfireStrategy::lateSparkOverrun;
    throw std::invalid_argument(
        "Unknown exhaust afterfire strategy: " + std::string(value));
}
[[nodiscard]] const char* layoutName(EngineLayout value) noexcept {
    switch (value) {
    case EngineLayout::inlineLayout: return "inline";
    case EngineLayout::vLayout: return "v";
    case EngineLayout::flat: return "flat";
    case EngineLayout::radial: return "radial";
    case EngineLayout::custom: return "custom";
    }
    return "custom";
}
[[nodiscard]] const char* rodTypeName(ConnectingRodType value) noexcept {
    if (value == ConnectingRodType::master) return "master";
    if (value == ConnectingRodType::articulated) return "articulated";
    return "conventional";
}
[[nodiscard]] const char* drivenAxleLayoutName(
    DrivenAxleLayout value) noexcept {
    switch (value) {
    case DrivenAxleLayout::front: return "front";
    case DrivenAxleLayout::rear: return "rear";
    case DrivenAxleLayout::all: return "all";
    }
    return "rear";
}
[[nodiscard]] DrivenAxleLayout decodeDrivenAxleLayout(
    std::string_view value) {
    if (value == "front") return DrivenAxleLayout::front;
    if (value == "rear") return DrivenAxleLayout::rear;
    if (value == "all") return DrivenAxleLayout::all;
    throw std::invalid_argument(
        "Unknown driven axle layout: " + std::string(value));
}
[[nodiscard]] const char* structuralNvhProvenanceName(
    StructuralNvhProvenance value) noexcept {
    switch (value) {
    case StructuralNvhProvenance::estimatedFamily:
        return "estimated_family";
    case StructuralNvhProvenance::calculatedGeometry:
        return "calculated_geometry";
    case StructuralNvhProvenance::measured: return "measured";
    }
    return "estimated_family";
}
[[nodiscard]] StructuralNvhProvenance decodeStructuralNvhProvenance(
    std::string_view value) {
    if (value == "estimated_family")
        return StructuralNvhProvenance::estimatedFamily;
    if (value == "calculated_geometry")
        return StructuralNvhProvenance::calculatedGeometry;
    if (value == "measured")
        return StructuralNvhProvenance::measured;
    throw std::invalid_argument(
        "Unknown structural NVH provenance: " + std::string(value));
}
[[nodiscard]] const char* structuralModeDriveName(
    StructuralModeDrive value) noexcept {
    switch (value) {
    case StructuralModeDrive::headGas: return "head_gas";
    case StructuralModeDrive::bearingAxial: return "bearing_axial";
    case StructuralModeDrive::bearingLateral: return "bearing_lateral";
    case StructuralModeDrive::torsion: return "torsion";
    }
    return "head_gas";
}
[[nodiscard]] StructuralModeDrive decodeStructuralModeDrive(
    std::string_view value) {
    if (value == "head_gas") return StructuralModeDrive::headGas;
    if (value == "bearing_axial")
        return StructuralModeDrive::bearingAxial;
    if (value == "bearing_lateral")
        return StructuralModeDrive::bearingLateral;
    if (value == "torsion") return StructuralModeDrive::torsion;
    throw std::invalid_argument(
        "Unknown structural mode drive: " + std::string(value));
}
void emitStructuralNvh(YAML::Emitter& out,
                       const StructuralNvhConfig& config) {
    out << YAML::Key << "structural_nvh" << YAML::Value
        << YAML::BeginMap
        << YAML::Key << "provenance" << YAML::Value
        << structuralNvhProvenanceName(config.provenance)
        << YAML::Key << "source" << YAML::Value << config.source
        << YAML::Key << "modes" << YAML::Value << YAML::BeginSeq;
    for (const auto& mode : config.modes)
        out << YAML::BeginMap
            << YAML::Key << "name" << YAML::Value << mode.name
            << YAML::Key << "drive" << YAML::Value
            << structuralModeDriveName(mode.drive)
            << YAML::Key << "frequency_hz" << YAML::Value
            << mode.frequencyHz
            << YAML::Key << "damping_ratio" << YAML::Value
            << mode.dampingRatio
            << YAML::Key << "modal_mass_kg" << YAML::Value
            << mode.modalMassKg
            << YAML::Key << "radiating_area_m2" << YAML::Value
            << mode.radiatingAreaM2
            << YAML::Key << "radiation_efficiency" << YAML::Value
            << mode.radiationEfficiency
            << YAML::Key << "surface_velocity_rms_scale"
            << YAML::Value << mode.surfaceVelocityRmsScale
            << YAML::Key << "torque_radius_m" << YAML::Value
            << mode.torqueRadiusM
            << YAML::Key << "cylinder_participation" << YAML::Value
            << YAML::Flow << mode.cylinderParticipation
            << YAML::EndMap;
    out << YAML::EndSeq << YAML::EndMap;
}
[[nodiscard]] StructuralNvhConfig decodeStructuralNvh(
    const YAML::Node& encoded) {
    StructuralNvhConfig config;
    config.provenance = decodeStructuralNvhProvenance(
        encoded["provenance"].as<std::string>("estimated_family"));
    config.source = encoded["source"].as<std::string>("");
    if (const auto modes = encoded["modes"]) {
        config.modes.reserve(modes.size());
        for (const auto& item : modes) {
            StructuralModeConfig mode;
            mode.name = item["name"].as<std::string>();
            mode.drive = decodeStructuralModeDrive(
                item["drive"].as<std::string>());
            mode.frequencyHz = item["frequency_hz"].as<double>();
            mode.dampingRatio =
                item["damping_ratio"].as<double>();
            mode.modalMassKg =
                item["modal_mass_kg"].as<double>();
            mode.radiatingAreaM2 =
                item["radiating_area_m2"].as<double>();
            mode.radiationEfficiency =
                item["radiation_efficiency"].as<double>();
            mode.surfaceVelocityRmsScale =
                item["surface_velocity_rms_scale"].as<double>();
            mode.torqueRadiusM =
                item["torque_radius_m"].as<double>();
            mode.cylinderParticipation =
                item["cylinder_participation"]
                    .as<std::vector<double>>();
            config.modes.push_back(std::move(mode));
        }
    }
    return config;
}
[[nodiscard]] const char* exhaustComponentTypeName(ExhaustComponentType value) noexcept {
    switch (value) {
    case ExhaustComponentType::pipe: return "pipe";
    case ExhaustComponentType::merge: return "merge";
    case ExhaustComponentType::splitter: return "splitter";
    case ExhaustComponentType::resonator: return "resonator";
    case ExhaustComponentType::muffler: return "muffler";
    case ExhaustComponentType::catalyst: return "catalyst";
    case ExhaustComponentType::outlet: return "outlet";
    case ExhaustComponentType::crossover: return "crossover";
    }
    return "pipe";
}
[[nodiscard]] std::optional<ExhaustComponentType> decodeExhaustComponentType(std::string_view value) noexcept {
    if (value == "pipe") return ExhaustComponentType::pipe;
    if (value == "merge") return ExhaustComponentType::merge;
    if (value == "splitter") return ExhaustComponentType::splitter;
    if (value == "resonator") return ExhaustComponentType::resonator;
    if (value == "muffler") return ExhaustComponentType::muffler;
    if (value == "catalyst") return ExhaustComponentType::catalyst;
    if (value == "outlet") return ExhaustComponentType::outlet;
    if (value == "crossover") return ExhaustComponentType::crossover;
    return std::nullopt;
}
[[nodiscard]] const char* terminationName(AcousticTerminationType value) noexcept {
    return value == AcousticTerminationType::flanged ? "flanged" : "unflanged";
}
void emitPoint(YAML::Emitter& out, const AcousticPoint3M& point) {
    out << YAML::Flow << YAML::BeginMap
        << YAML::Key << "x" << YAML::Value << point.x
        << YAML::Key << "y" << YAML::Value << point.y
        << YAML::Key << "z" << YAML::Value << point.z << YAML::EndMap;
}
[[nodiscard]] AcousticPoint3M decodePoint(
    const YAML::Node& node, AcousticPoint3M fallback = {}) {
    return { node["x"].as<double>(fallback.x), node["y"].as<double>(fallback.y),
        node["z"].as<double>(fallback.z) };
}

void emitLiftProfile(YAML::Emitter& out, const char* key, const std::vector<ValveLiftSample>& profile) {
    out << YAML::Key << key << YAML::Value << YAML::BeginSeq;
    for (const auto& sample : profile)
        out << YAML::BeginMap << YAML::Key << "angle_deg" << YAML::Value << sample.angleDegrees
            << YAML::Key << "lift_mm" << YAML::Value << sample.liftMm << YAML::EndMap;
    out << YAML::EndSeq;
}

void emitFlowCurve(YAML::Emitter& out, const char* key, const std::vector<ValveFlowSample>& curve) {
    out << YAML::Key << key << YAML::Value << YAML::BeginSeq;
    for (const auto& sample : curve)
        out << YAML::BeginMap << YAML::Key << "lift_mm" << YAML::Value << sample.liftMm
            << YAML::Key << "discharge_coefficient" << YAML::Value << sample.dischargeCoefficient << YAML::EndMap;
    out << YAML::EndSeq;
}

void emitValveControl(YAML::Emitter& out, const ValveControlConfig& control) {
    out << YAML::Key << "continuous_control" << YAML::Value << YAML::BeginMap
        << YAML::Key << "enabled" << YAML::Value << control.enabled
        << YAML::Key << "response_frequency_hz" << YAML::Value << control.responseFrequencyHz
        << YAML::Key << "samples" << YAML::Value << YAML::BeginSeq;
    for (const auto& sample : control.samples)
        out << YAML::BeginMap << YAML::Key << "rpm" << YAML::Value << sample.rpm
            << YAML::Key << "load" << YAML::Value << sample.load
            << YAML::Key << "intake_advance_deg" << YAML::Value << sample.intakeAdvanceDegrees
            << YAML::Key << "exhaust_advance_deg" << YAML::Value << sample.exhaustAdvanceDegrees
            << YAML::Key << "lift_multiplier" << YAML::Value << sample.liftMultiplier << YAML::EndMap;
    out << YAML::EndSeq << YAML::EndMap;
}

void decodeExtendedCamshaft(CamshaftConfig& cam, const YAML::Node& node) {
    if (const auto fraction = node["exhaust_port_head_area_fraction"])
        cam.exhaustPortHeadAreaFraction = fraction.as<double>();
    if (const auto curve = node["intake_flow_curve"])
        for (const auto& sample : curve) cam.intakeFlowCurve.push_back({ sample["lift_mm"].as<double>(),
            sample["discharge_coefficient"].as<double>() });
    if (const auto curve = node["exhaust_flow_curve"])
        for (const auto& sample : curve) cam.exhaustFlowCurve.push_back({ sample["lift_mm"].as<double>(),
            sample["discharge_coefficient"].as<double>() });
    if (const auto control = node["continuous_control"]) {
        cam.continuousControl.enabled = control["enabled"].as<bool>(false);
        cam.continuousControl.responseFrequencyHz = control["response_frequency_hz"].as<double>(cam.continuousControl.responseFrequencyHz);
        if (const auto samples = control["samples"])
            for (const auto& sample : samples) cam.continuousControl.samples.push_back({
                sample["rpm"].as<double>(), sample["load"].as<double>(),
                sample["intake_advance_deg"].as<double>(), sample["exhaust_advance_deg"].as<double>(),
                sample["lift_multiplier"].as<double>() });
    }
}

[[nodiscard]] std::vector<ValveLiftSample> decodeLiftProfile(const YAML::Node& values) {
    std::vector<ValveLiftSample> profile;
    profile.reserve(values.size());
    for (const auto& sample : values)
        profile.push_back({ sample["angle_deg"].as<double>(), sample["lift_mm"].as<double>() });
    return profile;
}
}

std::string YamlEngineSerializer::encode(const EngineConfig& config) const {
    YAML::Emitter out;
    out << YAML::BeginMap << YAML::Key << "schema_version" << YAML::Value << currentEngineSchemaVersion
        << YAML::Key << "engine" << YAML::Value << YAML::BeginMap
        << YAML::Key << "name" << YAML::Value << config.name
        << YAML::Key << "cycle" << YAML::Value << (config.cycle == EngineCycle::fourStroke ? "four_stroke"
            : config.cycle == EngineCycle::rotary ? "rotary" : "two_stroke")
        << YAML::Key << "fuel" << YAML::Value << (config.fuel == FuelType::gasoline ? "gasoline" : "diesel")
        << YAML::Key << "fuel_properties" << YAML::Value << YAML::BeginMap
        << YAML::Key << "name" << YAML::Value << config.fuelProperties.name
        << YAML::Key << "lower_heating_value_mj_per_kg" << YAML::Value << config.fuelProperties.lowerHeatingValueMjPerKg
        << YAML::Key << "density_kg_per_l" << YAML::Value << config.fuelProperties.densityKgPerL
        << YAML::Key << "stoichiometric_afr" << YAML::Value << config.fuelProperties.stoichiometricAirFuelRatio
        << YAML::Key << "molar_mass_g_per_mol" << YAML::Value << config.fuelProperties.molarMassGramsPerMole
        << YAML::Key << "oxygen_moles_per_fuel_mole" << YAML::Value << config.fuelProperties.oxygenMolesPerFuelMole
        << YAML::Key << "product_moles_per_fuel_mole" << YAML::Value << config.fuelProperties.productMolesPerFuelMole
        << YAML::Key << "laminar_flame_speed_mps" << YAML::Value << config.fuelProperties.laminarFlameSpeedMps
        << YAML::Key << "turbulence_flame_speed_gain" << YAML::Value << config.fuelProperties.turbulenceFlameSpeedGain
        << YAML::Key << "cetane_number" << YAML::Value << config.fuelProperties.cetaneNumber
        << YAML::EndMap
        << YAML::Key << "layout" << YAML::Value << layoutName(config.layout)
        << YAML::Key << "idle_rpm" << YAML::Value << config.idleRpm
        << YAML::Key << "redline_rpm" << YAML::Value << config.redlineRpm
        << YAML::Key << "rotating_inertia_kg_m2" << YAML::Value << config.rotatingInertiaKgM2
        << YAML::Key << "friction_coefficient" << YAML::Value << config.frictionCoefficient
        << YAML::Key << "octane_rating" << YAML::Value << config.octaneRating
        << YAML::Key << "ambient_pressure_kpa" << YAML::Value << config.ambientPressureKpa
        << YAML::Key << "ambient_temperature_c" << YAML::Value << config.ambientTemperatureC
        << YAML::Key << "cooling_efficiency" << YAML::Value << config.coolingEfficiency
        << YAML::Key << "plenum_volume_l" << YAML::Value << config.plenumVolumeLitres
        << YAML::Key << "throttle_diameter_mm" << YAML::Value << config.throttleDiameterMm
        << YAML::Key << "bank_angle_deg" << YAML::Value << config.bankAngleDegrees
        << YAML::Key << "peak_pressure_limit_bar" << YAML::Value << config.peakFiringPressureLimitBar
        << YAML::Key << "forced_induction" << YAML::Value << YAML::BeginMap
        << YAML::Key << "enabled" << YAML::Value << config.forcedInduction.enabled
        << YAML::Key << "type" << YAML::Value << (config.forcedInduction.type == ForcedInductionType::supercharger ? "supercharger" : "turbocharger")
        << YAML::Key << "pressure_ratio" << YAML::Value << config.forcedInduction.pressureRatio
        << YAML::Key << "full_boost_rpm" << YAML::Value << config.forcedInduction.fullBoostRpm
        << YAML::Key << "compressor_efficiency" << YAML::Value << config.forcedInduction.compressorEfficiency
        << YAML::Key << "charge_temperature_rise_c" << YAML::Value << config.forcedInduction.chargeTemperatureRiseC
        << YAML::Key << "turbine_efficiency" << YAML::Value << config.forcedInduction.turbineEfficiency
        << YAML::Key << "shaft_inertia_kg_m2" << YAML::Value << config.forcedInduction.shaftInertiaKgM2
        << YAML::Key << "wastegate_pressure_ratio" << YAML::Value << config.forcedInduction.wastegatePressureRatio
        << YAML::Key << "design_shaft_speed_rpm" << YAML::Value << config.forcedInduction.designShaftSpeedRpm
        << YAML::Key << "bearing_friction_power_w" << YAML::Value << config.forcedInduction.bearingFrictionPowerWatts
        << YAML::Key << "turbine_flow_area_mm2" << YAML::Value << config.forcedInduction.turbineFlowAreaMm2
        << YAML::Key << "wastegate_flow_area_mm2" << YAML::Value << config.forcedInduction.wastegateFlowAreaMm2
        << YAML::Key << "compressor_blade_count" << YAML::Value << config.forcedInduction.compressorBladeCount
        << YAML::Key << "turbine_blade_count" << YAML::Value << config.forcedInduction.turbineBladeCount
        << YAML::Key << "supercharger_lobe_count" << YAML::Value << config.forcedInduction.superchargerLobeCount
        << YAML::Key << "supercharger_drive_ratio" << YAML::Value << config.forcedInduction.superchargerDriveRatio
        << YAML::Key << "supercharger_displacement_l" << YAML::Value << config.forcedInduction.superchargerDisplacementLitres
        << YAML::Key << "supercharger_bypass_area_mm2" << YAML::Value << config.forcedInduction.superchargerBypassAreaMm2
        << YAML::Key << "compressor_inducer_diameter_mm" << YAML::Value << config.forcedInduction.compressorInducerDiameterMm
        << YAML::Key << "turbine_exducer_diameter_mm" << YAML::Value << config.forcedInduction.turbineExducerDiameterMm
        << YAML::Key << "blow_off_valve_flow_area_mm2" << YAML::Value << config.forcedInduction.blowOffValveFlowAreaMm2
        << YAML::Key << "blow_off_valve_opening_pressure_ratio" << YAML::Value << config.forcedInduction.blowOffValveOpeningPressureRatio
        << YAML::Key << "blow_off_valve_discharge_coefficient" << YAML::Value << config.forcedInduction.blowOffValveDischargeCoefficient
        << YAML::Key << "compressor_surge" << YAML::Value << config.forcedInduction.compressorSurge
        << YAML::Key << "charge_volume_l" << YAML::Value << config.forcedInduction.chargeVolumeLitres
        << YAML::Key << "tonal_acoustic_efficiency" << YAML::Value << config.forcedInduction.tonalAcousticEfficiency
        << YAML::Key << "turbulent_jet_noise_coefficient" << YAML::Value << config.forcedInduction.turbulentJetNoiseCoefficient
        << YAML::Key << "turbocharger_count" << YAML::Value << config.forcedInduction.turbochargerCount
        << YAML::Key << "compressor_design_mass_flow_kg_s" << YAML::Value << config.forcedInduction.compressorDesignMassFlowKgPerSecond
        << YAML::Key << "intercooler_effectiveness" << YAML::Value << config.forcedInduction.intercoolerEffectiveness
        << YAML::Key << "maximum_shaft_speed_rpm" << YAML::Value << config.forcedInduction.maximumShaftSpeedRpm
        << YAML::EndMap
        << YAML::Key << "thermal" << YAML::Value << YAML::BeginMap
        << YAML::Key << "regulated" << YAML::Value << config.thermal.regulated
        << YAML::Key << "regulated_coolant_c" << YAML::Value << config.thermal.regulatedCoolantTemperatureC
        << YAML::Key << "regulated_oil_c" << YAML::Value << config.thermal.regulatedOilTemperatureC
        << YAML::Key << "coolant_mass_kj_per_c" << YAML::Value << config.thermal.coolantMassKjPerC
        << YAML::Key << "oil_mass_kj_per_c" << YAML::Value << config.thermal.oilMassKjPerC
        << YAML::Key << "coolant_heat_share" << YAML::Value << config.thermal.coolantHeatShare
        << YAML::Key << "oil_heat_share" << YAML::Value << config.thermal.oilHeatShare
        << YAML::Key << "cooling_power_kw_per_c" << YAML::Value << config.thermal.coolingPowerKwPerC
        << YAML::Key << "oil_cooling_power_kw_per_c" << YAML::Value << config.thermal.oilCoolingPowerKwPerC
        << YAML::Key << "liquid_cooled" << YAML::Value << config.thermal.liquidCooled
        << YAML::Key << "engine_driven_fan" << YAML::Value << config.thermal.engineDrivenFan
        << YAML::EndMap
        << YAML::Key << "combustion_calibration" << YAML::Value << YAML::BeginMap
        << YAML::Key << "base_ignition_delay_s" << YAML::Value << config.combustionCalibration.baseIgnitionDelaySeconds
        << YAML::Key << "ignition_delay_temperature_exponent" << YAML::Value << config.combustionCalibration.ignitionDelayTemperatureExponent
        << YAML::Key << "ignition_delay_pressure_exponent" << YAML::Value << config.combustionCalibration.ignitionDelayPressureExponent
        << YAML::Key << "wall_heat_transfer_w_per_k" << YAML::Value << config.combustionCalibration.wallHeatTransferCoefficientWPerK
        << YAML::Key << "residual_dilution_sensitivity" << YAML::Value << config.combustionCalibration.residualDilutionSensitivity
        << YAML::Key << "chamber_turbulence_intensity_ratio" << YAML::Value << config.combustionCalibration.chamberTurbulenceIntensityRatio
        << YAML::Key << "ignition_site_count" << YAML::Value << config.combustionCalibration.ignitionSiteCount
        << YAML::Key << "compression_ignition_delay_scale" << YAML::Value << config.combustionCalibration.compressionIgnitionDelayScale
        << YAML::Key << "compression_ignition_mixing_time_s" << YAML::Value << config.combustionCalibration.compressionIgnitionMixingTimeSeconds
        << YAML::Key << "compression_ignition_premixed_fraction" << YAML::Value << config.combustionCalibration.compressionIgnitionPremixedFraction
        << YAML::Key << "compression_ignition_mixed_premix" << YAML::Value << config.combustionCalibration.compressionIgnitionMixedPremix
        << YAML::Key << "cycle_variation_cov" << YAML::Value << config.combustionCalibration.cycleVariationCoefficientOfVariation
        << YAML::Key << "cycle_variation_correlation" << YAML::Value << config.combustionCalibration.cycleVariationCorrelation
        << YAML::EndMap
        << YAML::Key << "exhaust_afterfire" << YAML::Value << YAML::BeginMap
        << YAML::Key << "enabled" << YAML::Value << config.exhaustAfterfire.enabled
        << YAML::Key << "strategy" << YAML::Value << afterfireStrategyName(config.exhaustAfterfire.strategy)
        << YAML::Key << "ignition_temperature_k" << YAML::Value << config.exhaustAfterfire.ignitionTemperatureK
        << YAML::Key << "reaction_time_constant_s" << YAML::Value << config.exhaustAfterfire.reactionTimeConstantSeconds
        << YAML::Key << "reaction_efficiency" << YAML::Value << config.exhaustAfterfire.reactionEfficiency
        << YAML::Key << "overrun_minimum_rpm" << YAML::Value << config.exhaustAfterfire.overrunMinimumRpm
        << YAML::Key << "overrun_maximum_throttle" << YAML::Value << config.exhaustAfterfire.overrunMaximumThrottle
        << YAML::Key << "overrun_spark_advance_deg" << YAML::Value << config.exhaustAfterfire.overrunSparkAdvanceDegrees
        << YAML::Key << "induction_time_s" << YAML::Value << config.exhaustAfterfire.inductionTimeSeconds
        << YAML::Key << "induction_reference_pressure_kpa" << YAML::Value << config.exhaustAfterfire.inductionReferencePressureKpa
        << YAML::Key << "induction_activation_temperature_k" << YAML::Value << config.exhaustAfterfire.inductionActivationTemperatureK
        << YAML::Key << "induction_pressure_exponent" << YAML::Value << config.exhaustAfterfire.inductionPressureExponent
        << YAML::Key << "induction_equivalence_ratio_exponent" << YAML::Value << config.exhaustAfterfire.inductionEquivalenceRatioExponent
        << YAML::Key << "induction_decay_time_s" << YAML::Value << config.exhaustAfterfire.inductionDecayTimeSeconds
        << YAML::Key << "minimum_equivalence_ratio" << YAML::Value << config.exhaustAfterfire.minimumEquivalenceRatio
        << YAML::Key << "maximum_equivalence_ratio" << YAML::Value << config.exhaustAfterfire.maximumEquivalenceRatio
        << YAML::Key << "quench_temperature_k" << YAML::Value << config.exhaustAfterfire.quenchTemperatureK
        << YAML::Key << "pocket_mixing_time_s" << YAML::Value << config.exhaustAfterfire.pocketMixingTimeSeconds
        << YAML::Key << "overrun_spark_cut_fraction" << YAML::Value << config.exhaustAfterfire.overrunSparkCutFraction
        << YAML::EndMap
        << YAML::Key << "runner_acoustics" << YAML::Value << YAML::BeginMap
        << YAML::Key << "enabled" << YAML::Value << config.runnerAcoustics.enabled
        << YAML::Key << "damping_ratio" << YAML::Value << config.runnerAcoustics.dampingRatio
        << YAML::Key << "coupling_gain" << YAML::Value << config.runnerAcoustics.couplingGain
        << YAML::Key << "maximum_pressure_amplitude_kpa" << YAML::Value << config.runnerAcoustics.maximumPressureAmplitudeKpa
        << YAML::EndMap;
    emitStructuralNvh(out, config.structuralNvh);
    out << YAML::Key << "camshafts" << YAML::Value << YAML::BeginMap
        << YAML::Key << "intake_duration_deg" << YAML::Value << config.camshafts.intakeDurationDegrees
        << YAML::Key << "exhaust_duration_deg" << YAML::Value << config.camshafts.exhaustDurationDegrees
        << YAML::Key << "intake_lift_mm" << YAML::Value << config.camshafts.intakeLiftMm
        << YAML::Key << "exhaust_lift_mm" << YAML::Value << config.camshafts.exhaustLiftMm
        << YAML::Key << "intake_centerline_deg" << YAML::Value << config.camshafts.intakeCenterlineDegrees
        << YAML::Key << "exhaust_centerline_deg" << YAML::Value << config.camshafts.exhaustCenterlineDegrees
        << YAML::Key << "intake_flow_coefficient" << YAML::Value << config.camshafts.intakeFlowCoefficient
        << YAML::Key << "exhaust_flow_coefficient" << YAML::Value << config.camshafts.exhaustFlowCoefficient
        << YAML::Key << "variable_profile_enabled" << YAML::Value << config.camshafts.variableProfileEnabled
        << YAML::Key << "switch_rpm" << YAML::Value << config.camshafts.switchRpm
        << YAML::Key << "switch_throttle" << YAML::Value << config.camshafts.switchThrottle
        << YAML::Key << "high_intake_duration_deg" << YAML::Value << config.camshafts.highIntakeDurationDegrees
        << YAML::Key << "high_exhaust_duration_deg" << YAML::Value << config.camshafts.highExhaustDurationDegrees
        << YAML::Key << "high_intake_lift_mm" << YAML::Value << config.camshafts.highIntakeLiftMm
        << YAML::Key << "high_exhaust_lift_mm" << YAML::Value << config.camshafts.highExhaustLiftMm;
    emitLiftProfile(out, "intake_lift_profile", config.camshafts.intakeLiftProfile);
    emitLiftProfile(out, "exhaust_lift_profile", config.camshafts.exhaustLiftProfile);
    emitLiftProfile(out, "high_intake_lift_profile", config.camshafts.highIntakeLiftProfile);
    emitLiftProfile(out, "high_exhaust_lift_profile", config.camshafts.highExhaustLiftProfile);
    emitFlowCurve(out, "intake_flow_curve", config.camshafts.intakeFlowCurve);
    emitFlowCurve(out, "exhaust_flow_curve", config.camshafts.exhaustFlowCurve);
    if (config.camshafts.exhaustPortHeadAreaFraction > 0.0)
        out << YAML::Key << "exhaust_port_head_area_fraction" << YAML::Value << config.camshafts.exhaustPortHeadAreaFraction;
    emitValveControl(out, config.camshafts.continuousControl);
    out << YAML::EndMap
        << YAML::Key << "crankshafts" << YAML::Value << YAML::BeginSeq;
    for (const auto& crankshaft : config.crankshafts)
        out << YAML::BeginMap << YAML::Key << "id" << YAML::Value << crankshaft.id
            << YAML::Key << "position_x_mm" << YAML::Value << crankshaft.positionXMm
            << YAML::Key << "position_y_mm" << YAML::Value << crankshaft.positionYMm
            << YAML::Key << "phase_offset_deg" << YAML::Value << crankshaft.phaseOffsetDegrees
            << YAML::Key << "rotation_ratio" << YAML::Value << crankshaft.rotationRatio
            << YAML::Key << "mass_kg" << YAML::Value << crankshaft.massKg
            << YAML::Key << "flywheel_mass_kg" << YAML::Value << crankshaft.flywheelMassKg
            << YAML::Key << "moment_of_inertia_kg_m2" << YAML::Value << crankshaft.momentOfInertiaKgM2
            << YAML::Key << "friction_torque_nm" << YAML::Value << crankshaft.frictionTorqueNm << YAML::EndMap;
    out << YAML::EndSeq << YAML::Key << "crank_journals" << YAML::Value << YAML::BeginSeq;
    for (const auto& journal : config.crankJournals)
        out << YAML::BeginMap << YAML::Key << "id" << YAML::Value << journal.id
            << YAML::Key << "angle_deg" << YAML::Value << journal.angleDegrees
            << YAML::Key << "throw_mm" << YAML::Value << journal.throwMm
            << YAML::Key << "crankshaft_id" << YAML::Value << journal.crankshaftId << YAML::EndMap;
    out << YAML::EndSeq
        << YAML::Key << "exhaust" << YAML::Value << YAML::BeginMap
        << YAML::Key << "primary_length_mm" << YAML::Value << config.exhaust.primaryLengthMm
        << YAML::Key << "primary_diameter_mm" << YAML::Value << config.exhaust.primaryDiameterMm
        << YAML::Key << "collector_diameter_mm" << YAML::Value << config.exhaust.collectorDiameterMm
        << YAML::Key << "muffler_restriction" << YAML::Value << config.exhaust.mufflerRestriction
        << YAML::Key << "outlet_diameter_mm" << YAML::Value << config.exhaust.outletDiameterMm
        << YAML::Key << "collector_volume_l" << YAML::Value << config.exhaust.collectorVolumeLitres
        << YAML::Key << "outlet_discharge_coefficient" << YAML::Value << config.exhaust.outletDischargeCoefficient
        << YAML::Key << "muffler_chamber_diameter_mm" << YAML::Value << config.exhaust.mufflerChamberDiameterMm
        << YAML::Key << "muffler_chamber_length_mm" << YAML::Value << config.exhaust.mufflerChamberLengthMm
        << YAML::Key << "muffler_packing_flow_resistivity_pa_s_m2" << YAML::Value << config.exhaust.mufflerPackingFlowResistivityPaSPerM2
        << YAML::Key << "muffler_packing_thickness_mm" << YAML::Value << config.exhaust.mufflerPackingThicknessMm
        << YAML::Key << "muffler_perforated_open_area_ratio" << YAML::Value << config.exhaust.mufflerPerforatedOpenAreaRatio
        << YAML::Key << "midpipe_length_mm" << YAML::Value << config.exhaust.midpipeLengthMm
        << YAML::Key << "midpipe_diameter_mm" << YAML::Value << config.exhaust.midpipeDiameterMm << YAML::EndMap
        << YAML::Key << "transmission" << YAML::Value << YAML::BeginMap
        << YAML::Key << "gear_ratios" << YAML::Value << YAML::Flow << config.transmission.gearRatios
        << YAML::Key << "final_drive_ratio" << YAML::Value << config.transmission.finalDriveRatio
        << YAML::Key << "max_clutch_torque_nm" << YAML::Value << config.transmission.maxClutchTorqueNm
        << YAML::Key << "driveline_efficiency" << YAML::Value << config.transmission.drivelineEfficiency
        << YAML::Key << "driven_wheel_inertia_kg_m2" << YAML::Value << config.transmission.drivenWheelInertiaKgM2
        << YAML::Key << "clutch_lock_speed_rpm" << YAML::Value << config.transmission.clutchLockSpeedRpm
        << YAML::Key << "shift_duration_s" << YAML::Value << config.transmission.shiftDurationSeconds
        << YAML::Key << "automatic_shifting" << YAML::Value << config.transmission.automaticShifting
        << YAML::Key << "automatic_upshift_rpm" << YAML::Value << config.transmission.automaticUpshiftRpm
        << YAML::Key << "automatic_downshift_rpm" << YAML::Value << config.transmission.automaticDownshiftRpm
        << YAML::Key << "reverse_ratio" << YAML::Value << config.transmission.reverseRatio
        << YAML::Key << "gearbox_input_inertia_kg_m2" << YAML::Value << config.transmission.gearboxInputInertiaKgM2
        << YAML::Key << "differential_inertia_kg_m2" << YAML::Value << config.transmission.differentialInertiaKgM2
        << YAML::Key << "clutch_thermal_capacity_j_per_c" << YAML::Value << config.transmission.clutchThermalCapacityJPerC
        << YAML::Key << "clutch_cooling_w_per_c" << YAML::Value << config.transmission.clutchCoolingWPerC
        << YAML::Key << "clutch_fade_start_temperature_c" << YAML::Value << config.transmission.clutchFadeStartTemperatureC
        << YAML::Key << "clutch_failure_temperature_c" << YAML::Value << config.transmission.clutchFailureTemperatureC
        << YAML::Key << "shift_torque_cut_fraction" << YAML::Value << config.transmission.shiftTorqueCutFraction
        << YAML::Key << "shift_style" << YAML::Value << shiftStyleName(config.transmission.shiftStyle)
        << YAML::Key << "quickshifter" << YAML::Value << config.transmission.quickshifter
        << YAML::Key << "quickshifter_cut_s" << YAML::Value << config.transmission.quickshifterCutSeconds
        << YAML::Key << "auto_blipper" << YAML::Value << config.transmission.autoBlipper
        << YAML::Key << "dual_clutch_upshift_retard_deg" << YAML::Value
        << config.transmission.dualClutchUpshiftRetardDegrees
        << YAML::Key << "dual_clutch_upshift_cylinder_cut" << YAML::Value
        << config.transmission.dualClutchUpshiftCylinderCutFraction
        << YAML::Key << "centrifugal_clutch" << YAML::Value << config.transmission.centrifugalClutch
        << YAML::Key << "centrifugal_clutch_engage_rpm" << YAML::Value
        << config.transmission.centrifugalClutchEngageRpm << YAML::EndMap
        << YAML::Key << "vehicle" << YAML::Value << YAML::BeginMap
        << YAML::Key << "mass_kg" << YAML::Value << config.vehicle.massKg
        << YAML::Key << "drag_coefficient" << YAML::Value << config.vehicle.dragCoefficient
        << YAML::Key << "frontal_area_m2" << YAML::Value << config.vehicle.frontalAreaM2
        << YAML::Key << "tire_radius_m" << YAML::Value << config.vehicle.tireRadiusM
        << YAML::Key << "rolling_resistance_coefficient" << YAML::Value << config.vehicle.rollingResistanceCoefficient
        << YAML::Key << "tire_friction_coefficient" << YAML::Value << config.vehicle.tireFrictionCoefficient
        << YAML::Key << "tyre_grip_limit_enabled" << YAML::Value << config.vehicle.tyreGripLimitEnabled
        << YAML::Key << "driven_axle_layout" << YAML::Value << drivenAxleLayoutName(config.vehicle.drivenAxleLayout)
        << YAML::Key << "driven_axle_weight_fraction" << YAML::Value << config.vehicle.drivenAxleWeightFraction
        << YAML::Key << "wheelbase_m" << YAML::Value << config.vehicle.wheelbaseM
        << YAML::Key << "center_of_gravity_height_m" << YAML::Value << config.vehicle.centerOfGravityHeightM
        << YAML::Key << "maximum_brake_force_n" << YAML::Value << config.vehicle.maximumBrakeForceN << YAML::EndMap
        << YAML::Key << "intake" << YAML::Value << YAML::BeginMap
        << YAML::Key << "plenum_volume_l" << YAML::Value << config.intake.plenumVolumeLitres
        << YAML::Key << "throttle_diameter_mm" << YAML::Value << config.intake.throttleDiameterMm
        << YAML::Key << "throttle_count" << YAML::Value << config.intake.throttleCount
        << YAML::Key << "throttle_discharge_coefficient" << YAML::Value << config.intake.throttleDischargeCoefficient
        << YAML::Key << "runner_length_mm" << YAML::Value << config.intake.runnerLengthMm
        << YAML::Key << "runner_diameter_mm" << YAML::Value << config.intake.runnerDiameterMm
        << YAML::Key << "runner_plenum_diameter_mm" << YAML::Value << config.intake.runnerPlenumDiameterMm
        << YAML::Key << "airbox_volume_l" << YAML::Value << config.intake.airboxVolumeLitres
        << YAML::Key << "pod_filter" << YAML::Value << config.intake.podFilter
        << YAML::Key << "individual_throttles" << YAML::Value << config.intake.individualThrottles
        << YAML::Key << "throttle_distance_from_valve_mm" << YAML::Value << config.intake.throttleDistanceFromValveMm
        << YAML::Key << "inlet_duct_length_mm" << YAML::Value << config.intake.inletDuctLengthMm
        << YAML::Key << "inlet_duct_diameter_mm" << YAML::Value << config.intake.inletDuctDiameterMm
        << YAML::Key << "bellmouth_diameter_mm" << YAML::Value << config.intake.bellmouthDiameterMm
        << YAML::Key << "idle_bypass_area_mm2" << YAML::Value << config.intake.idleBypassAreaMm2
        << YAML::Key << "closed_throttle_leak_mm2" << YAML::Value << config.intake.closedThrottleLeakageAreaMm2
        << YAML::Key << "throttle_gamma" << YAML::Value << config.intake.throttleGamma
        << YAML::Key << "carburettor" << YAML::Value << YAML::BeginMap
        << YAML::Key << "enabled" << YAML::Value << config.intake.carburettor.enabled
        << YAML::Key << "venturi_diameter_mm" << YAML::Value << config.intake.carburettor.venturiDiameterMm
        << YAML::Key << "main_jet_flow_number" << YAML::Value << config.intake.carburettor.mainJetFlowNumber
        << YAML::Key << "pilot_jet_flow_number" << YAML::Value << config.intake.carburettor.pilotJetFlowNumber
        << YAML::Key << "pilot_circuit_factor" << YAML::Value << config.intake.carburettor.pilotCircuitFactor
        << YAML::Key << "needle_clip_position" << YAML::Value << config.intake.carburettor.needleClipPosition
        << YAML::Key << "fixed_venturi" << YAML::Value << config.intake.carburettor.fixedVenturi
        << YAML::Key << "air_screw_turns" << YAML::Value << config.intake.carburettor.airScrewTurns
        << YAML::Key << "idle_screw_turns" << YAML::Value << config.intake.carburettor.idleScrewTurns
        << YAML::Key << "jet_lift_mm" << YAML::Value << config.intake.carburettor.jetLiftMm
        << YAML::Key << "jet_discharge_coefficient" << YAML::Value << config.intake.carburettor.jetDischargeCoefficient
        << YAML::Key << "wall_film_fraction" << YAML::Value << config.intake.carburettor.wallFilmFraction
        << YAML::Key << "wall_film_time_constant_s" << YAML::Value << config.intake.carburettor.wallFilmTimeConstantSeconds
        << YAML::Key << "accelerator_pump_stroke_cc" << YAML::Value << config.intake.carburettor.acceleratorPumpStrokeCc
        << YAML::Key << "accelerator_pump_time_constant_s" << YAML::Value << config.intake.carburettor.acceleratorPumpTimeConstantSeconds
        << YAML::Key << "starter_jet_flow_number" << YAML::Value << config.intake.carburettor.starterJetFlowNumber
        << YAML::EndMap
        << YAML::EndMap
        << YAML::Key << "intake_paths" << YAML::Value << YAML::BeginSeq;
    for (const auto& path : config.intakePaths)
        out << YAML::BeginMap << YAML::Key << "id" << YAML::Value << path.id
            << YAML::Key << "cylinder_ids" << YAML::Value << YAML::Flow << path.cylinderIds
            << YAML::Key << "geometry" << YAML::Value << YAML::BeginMap
            << YAML::Key << "plenum_volume_l" << YAML::Value << path.geometry.plenumVolumeLitres
            << YAML::Key << "throttle_diameter_mm" << YAML::Value << path.geometry.throttleDiameterMm
            << YAML::Key << "throttle_count" << YAML::Value << path.geometry.throttleCount
            << YAML::Key << "throttle_discharge_coefficient" << YAML::Value << path.geometry.throttleDischargeCoefficient
            << YAML::Key << "carburettor" << YAML::Value << YAML::BeginMap
            << YAML::Key << "enabled" << YAML::Value << path.geometry.carburettor.enabled
            << YAML::Key << "venturi_diameter_mm" << YAML::Value << path.geometry.carburettor.venturiDiameterMm
            << YAML::Key << "main_jet_flow_number" << YAML::Value << path.geometry.carburettor.mainJetFlowNumber
            << YAML::Key << "pilot_jet_flow_number" << YAML::Value << path.geometry.carburettor.pilotJetFlowNumber
            << YAML::Key << "pilot_circuit_factor" << YAML::Value << path.geometry.carburettor.pilotCircuitFactor
            << YAML::Key << "needle_clip_position" << YAML::Value << path.geometry.carburettor.needleClipPosition
            << YAML::Key << "fixed_venturi" << YAML::Value << path.geometry.carburettor.fixedVenturi
            << YAML::Key << "air_screw_turns" << YAML::Value << path.geometry.carburettor.airScrewTurns
            << YAML::Key << "idle_screw_turns" << YAML::Value << path.geometry.carburettor.idleScrewTurns
            << YAML::Key << "jet_lift_mm" << YAML::Value << path.geometry.carburettor.jetLiftMm
            << YAML::Key << "jet_discharge_coefficient" << YAML::Value << path.geometry.carburettor.jetDischargeCoefficient
            << YAML::Key << "wall_film_fraction" << YAML::Value << path.geometry.carburettor.wallFilmFraction
            << YAML::Key << "wall_film_time_constant_s" << YAML::Value << path.geometry.carburettor.wallFilmTimeConstantSeconds
            << YAML::Key << "accelerator_pump_stroke_cc" << YAML::Value << path.geometry.carburettor.acceleratorPumpStrokeCc
            << YAML::Key << "accelerator_pump_time_constant_s" << YAML::Value << path.geometry.carburettor.acceleratorPumpTimeConstantSeconds
            << YAML::Key << "starter_jet_flow_number" << YAML::Value << path.geometry.carburettor.starterJetFlowNumber
            << YAML::EndMap
            << YAML::Key << "runner_length_mm" << YAML::Value << path.geometry.runnerLengthMm
            << YAML::Key << "runner_diameter_mm" << YAML::Value << path.geometry.runnerDiameterMm
            << YAML::Key << "runner_plenum_diameter_mm" << YAML::Value << path.geometry.runnerPlenumDiameterMm
            << YAML::Key << "airbox_volume_l" << YAML::Value << path.geometry.airboxVolumeLitres
            << YAML::Key << "pod_filter" << YAML::Value << path.geometry.podFilter
            << YAML::Key << "individual_throttles" << YAML::Value << path.geometry.individualThrottles
            << YAML::Key << "throttle_distance_from_valve_mm" << YAML::Value << path.geometry.throttleDistanceFromValveMm
            << YAML::Key << "inlet_duct_length_mm" << YAML::Value << path.geometry.inletDuctLengthMm
            << YAML::Key << "inlet_duct_diameter_mm" << YAML::Value << path.geometry.inletDuctDiameterMm
            << YAML::Key << "bellmouth_diameter_mm" << YAML::Value << path.geometry.bellmouthDiameterMm
            << YAML::Key << "idle_bypass_area_mm2" << YAML::Value << path.geometry.idleBypassAreaMm2
            << YAML::Key << "closed_throttle_leak_mm2" << YAML::Value << path.geometry.closedThrottleLeakageAreaMm2
            << YAML::Key << "throttle_gamma" << YAML::Value << path.geometry.throttleGamma
            << YAML::EndMap << YAML::EndMap;
    out << YAML::EndSeq << YAML::Key << "ignition" << YAML::Value << YAML::BeginMap
        << YAML::Key << "rev_limit_rpm" << YAML::Value << config.ignition.revLimitRpm
        << YAML::Key << "limiter_duration_s" << YAML::Value << config.ignition.limiterDurationSeconds
        << YAML::Key << "limiter_keeps_fuel" << YAML::Value << config.ignition.limiterKeepsFuel
        << YAML::Key << "timing_curve" << YAML::Value << YAML::BeginSeq;
    for (const auto& sample : config.ignition.timingCurve)
        out << YAML::BeginMap << YAML::Key << "rpm" << YAML::Value << sample.rpm
            << YAML::Key << "advance_deg" << YAML::Value << sample.advanceDegrees << YAML::EndMap;
    out << YAML::EndSeq;
    if (!config.ignition.knockLimitCurve.empty()) {
        out << YAML::Key << "knock_limit_curve" << YAML::Value << YAML::BeginSeq;
        for (const auto& sample : config.ignition.knockLimitCurve)
            out << YAML::Flow << YAML::BeginMap << YAML::Key << "rpm" << YAML::Value << sample.rpm
                << YAML::Key << "advance_deg" << YAML::Value << sample.advanceDegrees
                << YAML::Key << "map_kpa" << YAML::Value << sample.manifoldPressureKpa << YAML::EndMap;
        out << YAML::EndSeq;
    }
    out << YAML::EndMap
        << YAML::Key << "injection" << YAML::Value << YAML::BeginMap
        << YAML::Key << "mode" << YAML::Value << (config.injection.mode == InjectionMode::port ? "port" : "direct")
        << YAML::Key << "start_angle_deg" << YAML::Value << config.injection.startAngleDegrees
        << YAML::Key << "end_angle_deg" << YAML::Value << config.injection.endAngleDegrees
        << YAML::Key << "injector_flow_mg_s" << YAML::Value << config.injection.injectorFlowMgPerSecond
        << YAML::Key << "fuel_temperature_c" << YAML::Value << config.injection.fuelTemperatureC
        << YAML::Key << "rail_pressure_bar" << YAML::Value << config.injection.railPressureBar
        << YAML::Key << "reference_pressure_bar" << YAML::Value << config.injection.referencePressureBar
        << YAML::Key << "wall_film_fraction" << YAML::Value << config.injection.wallFilmFraction
        << YAML::Key << "vaporisation_time_constant_s" << YAML::Value << config.injection.vaporisationTimeConstantSeconds
        << YAML::Key << "latent_heat_kj_per_kg" << YAML::Value << config.injection.latentHeatKjPerKg
        << YAML::Key << "direct_charge_cooling_efficiency" << YAML::Value << config.injection.directChargeCoolingEfficiency
        << YAML::Key << "port_charge_cooling_efficiency" << YAML::Value << config.injection.portChargeCoolingEfficiency
        << YAML::Key << "direct_spray_vaporisation_time_constant_s" << YAML::Value << config.injection.directSprayVaporisationTimeConstantSeconds
        << YAML::Key << "direct_spray_entrainment_time_constant_s" << YAML::Value << config.injection.directSprayEntrainmentTimeConstantSeconds
        << YAML::Key << "full_load_fuel_limit" << YAML::Value << YAML::BeginSeq;
    for (const auto& sample : config.injection.fullLoadFuelLimit)
        out << YAML::BeginMap
            << YAML::Key << "rpm" << YAML::Value << sample.rpm
            << YAML::Key << "mg_per_cycle" << YAML::Value
            << sample.milligramsPerCycle << YAML::EndMap;
    out << YAML::EndSeq << YAML::EndMap
        << YAML::Key << "solver" << YAML::Value << YAML::BeginMap
        << YAML::Key << "mechanical_frequency_hz" << YAML::Value << config.solver.mechanicalFrequencyHz
        << YAML::Key << "maximum_frequency_hz" << YAML::Value << config.solver.maximumMechanicalFrequencyHz
        << YAML::Key << "maximum_crank_deg_per_step" << YAML::Value << config.solver.maximumCrankDegreesPerStep
        << YAML::Key << "gas_substeps" << YAML::Value << config.solver.gasSubsteps << YAML::EndMap
        << YAML::Key << "banks" << YAML::Value << YAML::BeginSeq;
    for (const auto& bank : config.banks) {
        out << YAML::BeginMap << YAML::Key << "id" << YAML::Value << bank.id
            << YAML::Key << "angle_deg" << YAML::Value << bank.angleDegrees
            << YAML::Key << "cylinder_ids" << YAML::Value << YAML::Flow << bank.cylinderIds
            << YAML::Key << "intake_id" << YAML::Value << bank.intakeId
            << YAML::Key << "exhaust_path_id" << YAML::Value << bank.exhaustPathId
            << YAML::Key << "camshafts" << YAML::Value << YAML::BeginMap
            << YAML::Key << "intake_duration_deg" << YAML::Value << bank.camshafts.intakeDurationDegrees
            << YAML::Key << "exhaust_duration_deg" << YAML::Value << bank.camshafts.exhaustDurationDegrees
            << YAML::Key << "intake_lift_mm" << YAML::Value << bank.camshafts.intakeLiftMm
            << YAML::Key << "exhaust_lift_mm" << YAML::Value << bank.camshafts.exhaustLiftMm
            << YAML::Key << "intake_centerline_deg" << YAML::Value << bank.camshafts.intakeCenterlineDegrees
            << YAML::Key << "exhaust_centerline_deg" << YAML::Value << bank.camshafts.exhaustCenterlineDegrees
            << YAML::Key << "intake_flow_coefficient" << YAML::Value << bank.camshafts.intakeFlowCoefficient
            << YAML::Key << "exhaust_flow_coefficient" << YAML::Value << bank.camshafts.exhaustFlowCoefficient
            << YAML::Key << "variable_profile_enabled" << YAML::Value << bank.camshafts.variableProfileEnabled
            << YAML::Key << "switch_rpm" << YAML::Value << bank.camshafts.switchRpm
            << YAML::Key << "switch_throttle" << YAML::Value << bank.camshafts.switchThrottle
            << YAML::Key << "high_intake_duration_deg" << YAML::Value << bank.camshafts.highIntakeDurationDegrees
            << YAML::Key << "high_exhaust_duration_deg" << YAML::Value << bank.camshafts.highExhaustDurationDegrees
            << YAML::Key << "high_intake_lift_mm" << YAML::Value << bank.camshafts.highIntakeLiftMm
            << YAML::Key << "high_exhaust_lift_mm" << YAML::Value << bank.camshafts.highExhaustLiftMm;
        emitLiftProfile(out, "intake_lift_profile", bank.camshafts.intakeLiftProfile);
        emitLiftProfile(out, "exhaust_lift_profile", bank.camshafts.exhaustLiftProfile);
        emitLiftProfile(out, "high_intake_lift_profile", bank.camshafts.highIntakeLiftProfile);
        emitLiftProfile(out, "high_exhaust_lift_profile", bank.camshafts.highExhaustLiftProfile);
        emitFlowCurve(out, "intake_flow_curve", bank.camshafts.intakeFlowCurve);
        emitFlowCurve(out, "exhaust_flow_curve", bank.camshafts.exhaustFlowCurve);
        if (bank.camshafts.exhaustPortHeadAreaFraction > 0.0)
            out << YAML::Key << "exhaust_port_head_area_fraction" << YAML::Value << bank.camshafts.exhaustPortHeadAreaFraction;
        emitValveControl(out, bank.camshafts.continuousControl);
        out << YAML::EndMap << YAML::EndMap;
    }
    out << YAML::EndSeq
        << YAML::Key << "acoustic_observer" << YAML::Value << YAML::BeginMap
        << YAML::Key << "left_microphone_m" << YAML::Value;
    emitPoint(out, config.acousticObserver.leftMicrophoneM);
    out << YAML::Key << "right_microphone_m" << YAML::Value;
    emitPoint(out, config.acousticObserver.rightMicrophoneM);
    out << YAML::Key << "sound_speed_mps" << YAML::Value
        << config.acousticObserver.soundSpeedMps
        << YAML::Key << "listening_distance_m" << YAML::Value
        << config.acousticObserver.listeningDistanceM << YAML::EndMap
        << YAML::Key << "exhaust_paths" << YAML::Value << YAML::BeginSeq;
    for (const auto& path : config.exhaustPaths) {
        out << YAML::BeginMap << YAML::Key << "id" << YAML::Value << path.id
            << YAML::Key << "cylinder_ids" << YAML::Value << YAML::Flow << path.cylinderIds
            << YAML::Key << "impulse_response" << YAML::Value << path.impulseResponsePath
            << YAML::Key << "audio_volume" << YAML::Value << path.audioVolume
            << YAML::Key << "turbocharger" << YAML::Value << path.turbocharger
            << YAML::Key << "acoustic_position_m" << YAML::Value;
        emitPoint(out, path.acousticPositionM);
        out << YAML::Key << "acoustic_axis" << YAML::Value;
        emitPoint(out, path.acousticAxis);
        out << YAML::Key << "acoustic_termination" << YAML::Value
            << terminationName(path.acousticTermination)
            << YAML::Key << "geometry" << YAML::Value << YAML::BeginMap
            << YAML::Key << "primary_length_mm" << YAML::Value << path.geometry.primaryLengthMm
            << YAML::Key << "primary_diameter_mm" << YAML::Value << path.geometry.primaryDiameterMm
            << YAML::Key << "collector_diameter_mm" << YAML::Value << path.geometry.collectorDiameterMm
            << YAML::Key << "muffler_restriction" << YAML::Value << path.geometry.mufflerRestriction
            << YAML::Key << "outlet_diameter_mm" << YAML::Value << path.geometry.outletDiameterMm
            << YAML::Key << "collector_volume_l" << YAML::Value << path.geometry.collectorVolumeLitres
            << YAML::Key << "outlet_discharge_coefficient" << YAML::Value << path.geometry.outletDischargeCoefficient
            << YAML::Key << "muffler_chamber_diameter_mm" << YAML::Value << path.geometry.mufflerChamberDiameterMm
            << YAML::Key << "muffler_chamber_length_mm" << YAML::Value << path.geometry.mufflerChamberLengthMm
            << YAML::Key << "muffler_packing_flow_resistivity_pa_s_m2" << YAML::Value << path.geometry.mufflerPackingFlowResistivityPaSPerM2
            << YAML::Key << "muffler_packing_thickness_mm" << YAML::Value << path.geometry.mufflerPackingThicknessMm
            << YAML::Key << "muffler_perforated_open_area_ratio" << YAML::Value << path.geometry.mufflerPerforatedOpenAreaRatio
            << YAML::Key << "midpipe_length_mm" << YAML::Value << path.geometry.midpipeLengthMm
            << YAML::Key << "midpipe_diameter_mm" << YAML::Value << path.geometry.midpipeDiameterMm
            << YAML::EndMap;
        if (path.network) {
            out << YAML::Key << "graph" << YAML::Value << YAML::BeginMap
                << YAML::Key << "components" << YAML::Value << YAML::BeginSeq;
            for (const auto& component : path.network->components) {
                out << YAML::BeginMap
                    << YAML::Key << "id" << YAML::Value << component.id
                    << YAML::Key << "type" << YAML::Value << exhaustComponentTypeName(component.type)
                    << YAML::Key << "length_mm" << YAML::Value << component.lengthMm
                    << YAML::Key << "diameter_mm" << YAML::Value << component.diameterMm
                    << YAML::Key << "outlet_diameter_mm" << YAML::Value
                    << component.outletDiameterMm
                    << YAML::Key << "volume_l" << YAML::Value << component.volumeLitres
                    << YAML::Key << "restriction" << YAML::Value << component.restriction
                    << YAML::Key << "resonance_hz" << YAML::Value << component.resonanceHz
                    << YAML::Key << "acoustic_gain" << YAML::Value << component.acousticGain
                    << YAML::Key << "discharge_coefficient" << YAML::Value << component.dischargeCoefficient
                    << YAML::Key << "packing_flow_resistivity_pa_s_m2" << YAML::Value
                    << component.packingFlowResistivityPaSPerM2
                    << YAML::Key << "packing_thickness_mm" << YAML::Value
                    << component.packingThicknessMm
                    << YAML::Key << "perforated_open_area_ratio" << YAML::Value
                    << component.perforatedOpenAreaRatio
                    << YAML::Key << "catalyst_cell_density_cpsi" << YAML::Value
                    << component.catalystCellDensityCpsi
                    << YAML::Key << "catalyst_open_area_ratio" << YAML::Value
                    << component.catalystOpenAreaRatio
                    << YAML::Key << "catalyst_substrate_volumetric_heat_capacity_j_m3_k"
                    << YAML::Value
                    << component.catalystSubstrateVolumetricHeatCapacityJPerM3K
                    << YAML::Key << "crossover_coupling" << YAML::Value
                    << component.crossoverCoupling;
                if (component.inletValve)
                    out << YAML::Key << "inlet_valve" << YAML::Value << true;
                out << YAML::Key << "acoustic_position_m" << YAML::Value;
                emitPoint(out, component.acousticPositionM);
                out << YAML::Key << "acoustic_axis" << YAML::Value;
                emitPoint(out, component.acousticAxis);
                out << YAML::Key << "acoustic_termination" << YAML::Value
                    << terminationName(component.acousticTermination)
                    << YAML::EndMap;
            }
            out << YAML::EndSeq << YAML::Key << "cylinder_connections" << YAML::Value << YAML::BeginSeq;
            for (const auto& connection : path.network->cylinderConnections)
                out << YAML::BeginMap
                    << YAML::Key << "cylinder_id" << YAML::Value << connection.cylinderId
                    << YAML::Key << "to_component_id" << YAML::Value << connection.componentId
                    << YAML::EndMap;
            out << YAML::EndSeq << YAML::Key << "connections" << YAML::Value << YAML::BeginSeq;
            for (const auto& connection : path.network->connections) {
                out << YAML::BeginMap
                    << YAML::Key << "from_component_id" << YAML::Value << connection.fromComponentId
                    << YAML::Key << "to_component_id" << YAML::Value << connection.toComponentId;
                if (connection.fromPort != unspecifiedExhaustComponentPort)
                    out << YAML::Key << "from_port" << YAML::Value
                        << static_cast<unsigned>(connection.fromPort);
                if (connection.toPort != unspecifiedExhaustComponentPort)
                    out << YAML::Key << "to_port" << YAML::Value
                        << static_cast<unsigned>(connection.toPort);
                out << YAML::EndMap;
            }
            out << YAML::EndSeq << YAML::EndMap;
        }
        out << YAML::EndMap;
    }
    out << YAML::EndSeq
        << YAML::Key << "firing_order" << YAML::Value << YAML::Flow << config.firingOrder
        << YAML::Key << "cylinders" << YAML::Value << YAML::BeginSeq;
    for (const auto& cylinder : config.cylinders) out << YAML::BeginMap
        << YAML::Key << "id" << YAML::Value << cylinder.id << YAML::Key << "bore_mm" << YAML::Value << cylinder.boreMm
        << YAML::Key << "stroke_mm" << YAML::Value << cylinder.strokeMm << YAML::Key << "connecting_rod_mm" << YAML::Value << cylinder.connectingRodMm
        << YAML::Key << "piston_mass_g" << YAML::Value << cylinder.pistonMassGrams << YAML::Key << "compression_ratio" << YAML::Value << cylinder.compressionRatio
        << YAML::Key << "connecting_rod_mass_g" << YAML::Value << cylinder.connectingRodMassGrams
        << YAML::Key << "ignition_offset_deg" << YAML::Value << cylinder.ignitionOffsetDegrees << YAML::Key << "efficiency_offset" << YAML::Value << cylinder.efficiencyOffset
        << YAML::Key << "crank_offset_deg" << YAML::Value << cylinder.crankOffsetDegrees
        << YAML::Key << "crank_journal_id" << YAML::Value << cylinder.crankJournalId
        << YAML::Key << "bank_offset_deg" << YAML::Value << cylinder.bankOffsetDegrees
        << YAML::Key << "bank_id" << YAML::Value << cylinder.bankId
        << YAML::Key << "intake_runner_length_mm" << YAML::Value << cylinder.intakeRunnerLengthMm
        << YAML::Key << "intake_runner_diameter_mm" << YAML::Value << cylinder.intakeRunnerDiameterMm
        << YAML::Key << "exhaust_primary_length_mm" << YAML::Value << cylinder.exhaustPrimaryLengthMm
        << YAML::Key << "sound_attenuation" << YAML::Value << cylinder.soundAttenuation
        << YAML::Key << "blow_by_coefficient" << YAML::Value << cylinder.blowByCoefficient
        << YAML::Key << "piston_friction_coefficient" << YAML::Value << cylinder.pistonFrictionCoefficient
        << YAML::Key << "piston_breakaway_force_n" << YAML::Value << cylinder.pistonBreakawayForceN
        << YAML::Key << "piston_breakaway_velocity_mps" << YAML::Value << cylinder.pistonBreakawayVelocityMps
        << YAML::Key << "piston_viscous_friction_ns_per_m" << YAML::Value << cylinder.pistonViscousFrictionNsPerM
        << YAML::Key << "connecting_rod_type" << YAML::Value << rodTypeName(cylinder.connectingRodType)
        << YAML::Key << "master_cylinder_id" << YAML::Value << cylinder.masterCylinderId
        << YAML::Key << "articulated_journal_radius_mm" << YAML::Value << cylinder.articulatedJournalRadiusMm
        << YAML::Key << "articulated_journal_angle_deg" << YAML::Value << cylinder.articulatedJournalAngleDegrees
        << YAML::Key << "deck_height_mm" << YAML::Value << cylinder.deckHeightMm
        << YAML::Key << "compression_height_mm" << YAML::Value << cylinder.compressionHeightMm
        << YAML::Key << "wrist_pin_offset_mm" << YAML::Value << cylinder.wristPinOffsetMm
        << YAML::Key << "piston_crown_volume_cc" << YAML::Value << cylinder.pistonCrownVolumeCc
        << YAML::Key << "head_chamber_volume_cc" << YAML::Value << cylinder.headChamberVolumeCc
        << YAML::Key << "head_gasket_thickness_mm" << YAML::Value << cylinder.headGasketThicknessMm
        << YAML::Key << "connecting_rod_inertia_kg_m2" << YAML::Value << cylinder.connectingRodMomentOfInertiaKgM2
        << YAML::Key << "intake_valve_count" << YAML::Value << cylinder.intakeValveCount
        << YAML::Key << "exhaust_valve_count" << YAML::Value << cylinder.exhaustValveCount
        << YAML::Key << "intake_valve_diameter_mm" << YAML::Value << cylinder.intakeValveDiameterMm
        << YAML::Key << "exhaust_valve_diameter_mm" << YAML::Value << cylinder.exhaustValveDiameterMm
        << YAML::EndMap;
    out << YAML::EndSeq;
    // As in JSON: the voicing lives in the catalogue's voicing files, and an
    // engine names the one it speaks with, so a copy keeps its voice.
    if (!config.audioVoicingKey.empty())
        out << YAML::Key << "audio_voicing" << YAML::Value << YAML::BeginMap
            << YAML::Key << "family" << YAML::Value << config.audioVoicingFamily
            << YAML::Key << "key" << YAML::Value << config.audioVoicingKey
            << YAML::EndMap;
    // Written for a rotary only, so a piston engine's file is unchanged.
    if (config.cycle == EngineCycle::rotary)
        out << YAML::Key << "rotary" << YAML::Value << YAML::BeginMap
            << YAML::Key << "generating_radius_mm" << YAML::Value << config.rotary.generatingRadiusMm
            << YAML::Key << "eccentricity_mm" << YAML::Value << config.rotary.eccentricityMm
            << YAML::Key << "rotor_width_mm" << YAML::Value << config.rotary.rotorWidthMm
            << YAML::Key << "rotor_count" << YAML::Value << config.rotary.rotorCount
            << YAML::EndMap;
    // Written with a valve fitted, so every other engine's file is unchanged.
    if (exhaustValveFitted(config))
        out << YAML::Key << "exhaust_valve" << YAML::Value << YAML::BeginMap
            << YAML::Key << "open_above_rpm" << YAML::Value << config.exhaustValve.openAboveRpm
            << YAML::Key << "open_above_throttle" << YAML::Value << config.exhaustValve.openAboveThrottle
            << YAML::Key << "travel_s" << YAML::Value << config.exhaustValve.travelSeconds
            << YAML::EndMap;
    // Written when a kit is fitted, so every other engine's file is unchanged.
    if (config.nitrous.fitted) {
        const auto& kit = config.nitrous;
        out << YAML::Key << "nitrous" << YAML::Value << YAML::BeginMap
            << YAML::Key << "fitted" << YAML::Value << true
            << YAML::Key << "type" << YAML::Value << (kit.type == NitrousKitType::dry ? "dry" : "wet")
            << YAML::Key << "shot_kw" << YAML::Value << kit.shotKw
            << YAML::Key << "bottle_kg" << YAML::Value << kit.bottleCapacityKg
            << YAML::Key << "unlimited_bottle" << YAML::Value << kit.unlimitedBottle
            << YAML::Key << "bottle_heater" << YAML::Value << kit.bottleHeater
            << YAML::Key << "bottle_temperature_c" << YAML::Value << kit.bottleTemperatureC
            << YAML::Key << "minimum_throttle" << YAML::Value << kit.minimumThrottle
            << YAML::Key << "minimum_rpm" << YAML::Value << kit.minimumRpm
            << YAML::Key << "maximum_rpm" << YAML::Value << kit.maximumRpm
            << YAML::Key << "push_button" << YAML::Value << kit.pushButton
            << YAML::Key << "ramp_s" << YAML::Value << kit.rampSeconds
            << YAML::Key << "spark_retard_deg_per_50hp" << YAML::Value << kit.sparkRetardDegreesPer50Hp
            << YAML::Key << "kit_lambda" << YAML::Value << kit.kitLambda
            << YAML::EndMap;
    }
    // Written when one is fitted, so every other engine's file is unchanged.
    if (config.engineBrake.fitted)
        out << YAML::Key << "engine_brake" << YAML::Value << YAML::BeginMap
            << YAML::Key << "fitted" << YAML::Value << true
            << YAML::Key << "valve_lift_mm" << YAML::Value << config.engineBrake.valveLiftMm
            << YAML::Key << "peak_after_tdc_deg" << YAML::Value << config.engineBrake.peakAfterTdcDegrees
            << YAML::Key << "duration_deg" << YAML::Value << config.engineBrake.durationDegrees
            << YAML::Key << "minimum_rpm" << YAML::Value << config.engineBrake.minimumRpm
            << YAML::Key << "stage_count" << YAML::Value << config.engineBrake.stageCount
            << YAML::EndMap;
    // Written for a two-stroke only, so a four-stroke file is unchanged.
    if (config.cycle == EngineCycle::twoStroke) {
        out << YAML::Key << "two_stroke" << YAML::Value << YAML::BeginMap
            << YAML::Key << "exhaust_port_open_deg" << YAML::Value << config.twoStroke.exhaustPortOpenDegrees
            << YAML::Key << "transfer_port_open_deg" << YAML::Value << config.twoStroke.transferPortOpenDegrees
            << YAML::Key << "exhaust_port_width_mm" << YAML::Value << config.twoStroke.exhaustPortWidthMm
            << YAML::Key << "transfer_port_width_mm" << YAML::Value << config.twoStroke.transferPortWidthMm
            << YAML::Key << "port_discharge_coefficient" << YAML::Value << config.twoStroke.portDischargeCoefficient
            << YAML::Key << "crankcase_compression_ratio" << YAML::Value << config.twoStroke.crankcaseCompressionRatio
            << YAML::Key << "scavenge_loop_length_ratio" << YAML::Value << config.twoStroke.scavengeLoopLengthRatio;
        if (config.twoStroke.powerValveClosedExhaustPortOpenDegrees != 0.0)
            out << YAML::Key << "power_valve_closed_exhaust_port_open_deg" << YAML::Value
                << config.twoStroke.powerValveClosedExhaustPortOpenDegrees
                << YAML::Key << "power_valve_opening_start_rpm" << YAML::Value << config.twoStroke.powerValveOpeningStartRpm
                << YAML::Key << "power_valve_fully_open_rpm" << YAML::Value << config.twoStroke.powerValveFullyOpenRpm;
        // Only a cylinder port: a crankcase reed's file is unchanged.
        if (config.twoStroke.intake == TwoStrokeIntake::cylinderPort)
            out << YAML::Key << "intake" << YAML::Value << twoStrokeIntakeName(config.twoStroke.intake)
                << YAML::Key << "intake_port_open_deg_btdc" << YAML::Value << config.twoStroke.intakePortOpenDegreesBtdc
                << YAML::Key << "intake_port_width_mm" << YAML::Value << config.twoStroke.intakePortWidthMm
                << YAML::Key << "intake_port_reed" << YAML::Value << config.twoStroke.intakePortReed;
        out << YAML::EndMap;
    }
    out << YAML::EndMap << YAML::EndMap;
    return out.c_str();
}

EngineDecodeResult YamlEngineSerializer::decode(std::string_view text) const noexcept {
    return decode(text, nullptr);
}

EngineDecodeResult YamlEngineSerializer::decode(std::string_view text,
                                                std::vector<std::string>* repairs) const noexcept {
    try {
        const auto document = YAML::Load(std::string(text));
        EngineConfig config;
        config.schemaVersion = document["schema_version"].as<std::uint32_t>();
        if (config.schemaVersion < minimumSupportedEngineSchemaVersion
                || config.schemaVersion > currentEngineSchemaVersion)
            return { std::nullopt, "Unsupported schema version" };
        const auto engine = document["engine"];
        config.name = engine["name"].as<std::string>();
        const auto cycle = engine["cycle"].as<std::string>();
        if (cycle == "four_stroke") config.cycle = EngineCycle::fourStroke;
        else if (cycle == "two_stroke") config.cycle = EngineCycle::twoStroke;
        else if (cycle == "rotary") config.cycle = EngineCycle::rotary;
        else return { std::nullopt, "Unknown engine cycle: " + cycle };
        const auto fuel = engine["fuel"].as<std::string>();
        if (fuel == "gasoline") config.fuel = FuelType::gasoline;
        else if (fuel == "diesel") config.fuel = FuelType::diesel;
        else return { std::nullopt, "Unknown fuel type: " + fuel };
        if (const auto properties = engine["fuel_properties"]) {
            config.fuelProperties.name = properties["name"].as<std::string>(config.fuelProperties.name);
            config.fuelProperties.lowerHeatingValueMjPerKg = properties["lower_heating_value_mj_per_kg"].as<double>(config.fuelProperties.lowerHeatingValueMjPerKg);
            config.fuelProperties.densityKgPerL = properties["density_kg_per_l"].as<double>(config.fuelProperties.densityKgPerL);
            config.fuelProperties.stoichiometricAirFuelRatio = properties["stoichiometric_afr"].as<double>(config.fuelProperties.stoichiometricAirFuelRatio);
            config.fuelProperties.molarMassGramsPerMole = properties["molar_mass_g_per_mol"].as<double>(config.fuelProperties.molarMassGramsPerMole);
            config.fuelProperties.oxygenMolesPerFuelMole = properties["oxygen_moles_per_fuel_mole"].as<double>(config.fuelProperties.oxygenMolesPerFuelMole);
            config.fuelProperties.productMolesPerFuelMole = properties["product_moles_per_fuel_mole"].as<double>(config.fuelProperties.productMolesPerFuelMole);
            config.fuelProperties.laminarFlameSpeedMps = properties["laminar_flame_speed_mps"].as<double>(config.fuelProperties.laminarFlameSpeedMps);
            config.fuelProperties.turbulenceFlameSpeedGain = properties["turbulence_flame_speed_gain"].as<double>(config.fuelProperties.turbulenceFlameSpeedGain);
            config.fuelProperties.cetaneNumber = properties["cetane_number"].as<double>(config.fuelProperties.cetaneNumber);
        }
        const auto layout = engine["layout"] ? engine["layout"].as<std::string>() : "inline";
        if (layout == "inline") config.layout = EngineLayout::inlineLayout;
        else if (layout == "v") config.layout = EngineLayout::vLayout;
        else if (layout == "flat") config.layout = EngineLayout::flat;
        else if (layout == "radial") config.layout = EngineLayout::radial;
        else if (layout == "custom") config.layout = EngineLayout::custom;
        else return { std::nullopt, "Unknown engine layout: " + layout };
        config.idleRpm = engine["idle_rpm"].as<double>(); config.redlineRpm = engine["redline_rpm"].as<double>();
        config.rotatingInertiaKgM2 = engine["rotating_inertia_kg_m2"].as<double>();
        config.frictionCoefficient = engine["friction_coefficient"].as<double>(); config.octaneRating = engine["octane_rating"].as<double>();
        if (engine["ambient_pressure_kpa"]) config.ambientPressureKpa = engine["ambient_pressure_kpa"].as<double>();
        if (engine["ambient_temperature_c"]) config.ambientTemperatureC = engine["ambient_temperature_c"].as<double>();
        if (engine["cooling_efficiency"]) config.coolingEfficiency = engine["cooling_efficiency"].as<double>();
        if (engine["plenum_volume_l"]) config.plenumVolumeLitres = engine["plenum_volume_l"].as<double>();
        if (engine["throttle_diameter_mm"]) config.throttleDiameterMm = engine["throttle_diameter_mm"].as<double>();
        if (engine["peak_pressure_limit_bar"])
            config.peakFiringPressureLimitBar = engine["peak_pressure_limit_bar"].as<double>();
        if (engine["bank_angle_deg"]) config.bankAngleDegrees = engine["bank_angle_deg"].as<double>();
        else config.bankAngleDegrees = config.layout == EngineLayout::vLayout ? 60.0
            : (config.layout == EngineLayout::flat ? 180.0 : (config.layout == EngineLayout::radial ? 72.0 : 0.0));
        if (const auto forced = engine["forced_induction"]) {
            config.forcedInduction.enabled = forced["enabled"].as<bool>(false);
            const auto type = forced["type"].as<std::string>("turbocharger");
            if (type == "turbocharger") config.forcedInduction.type = ForcedInductionType::turbocharger;
            else if (type == "supercharger") config.forcedInduction.type = ForcedInductionType::supercharger;
            else return { std::nullopt, "Unknown forced-induction type: " + type };
            config.forcedInduction.pressureRatio = forced["pressure_ratio"].as<double>(1.0);
            config.forcedInduction.fullBoostRpm = forced["full_boost_rpm"].as<double>(3'500.0);
            config.forcedInduction.compressorEfficiency = forced["compressor_efficiency"].as<double>(0.68);
            config.forcedInduction.chargeTemperatureRiseC = forced["charge_temperature_rise_c"].as<double>(35.0);
            config.forcedInduction.turbineEfficiency = forced["turbine_efficiency"].as<double>(config.forcedInduction.turbineEfficiency);
            config.forcedInduction.shaftInertiaKgM2 = forced["shaft_inertia_kg_m2"].as<double>(config.forcedInduction.shaftInertiaKgM2);
            config.forcedInduction.wastegatePressureRatio = forced["wastegate_pressure_ratio"].as<double>(config.forcedInduction.wastegatePressureRatio);
            config.forcedInduction.designShaftSpeedRpm = forced["design_shaft_speed_rpm"].as<double>(config.forcedInduction.designShaftSpeedRpm);
            config.forcedInduction.bearingFrictionPowerWatts = forced["bearing_friction_power_w"].as<double>(config.forcedInduction.bearingFrictionPowerWatts);
            config.forcedInduction.turbineFlowAreaMm2 = forced["turbine_flow_area_mm2"].as<double>(config.forcedInduction.turbineFlowAreaMm2);
            config.forcedInduction.wastegateFlowAreaMm2 = forced["wastegate_flow_area_mm2"].as<double>(config.forcedInduction.wastegateFlowAreaMm2);
            config.forcedInduction.compressorBladeCount = forced["compressor_blade_count"].as<std::uint32_t>(config.forcedInduction.compressorBladeCount);
            config.forcedInduction.turbineBladeCount = forced["turbine_blade_count"].as<std::uint32_t>(config.forcedInduction.turbineBladeCount);
            config.forcedInduction.superchargerLobeCount = forced["supercharger_lobe_count"].as<std::uint32_t>(config.forcedInduction.superchargerLobeCount);
            config.forcedInduction.superchargerDriveRatio = forced["supercharger_drive_ratio"].as<double>(config.forcedInduction.superchargerDriveRatio);
            config.forcedInduction.superchargerDisplacementLitres = forced["supercharger_displacement_l"].as<double>(config.forcedInduction.superchargerDisplacementLitres);
            config.forcedInduction.superchargerBypassAreaMm2 = forced["supercharger_bypass_area_mm2"].as<double>(config.forcedInduction.superchargerBypassAreaMm2);
            config.forcedInduction.compressorInducerDiameterMm = forced["compressor_inducer_diameter_mm"].as<double>(config.forcedInduction.compressorInducerDiameterMm);
            config.forcedInduction.turbineExducerDiameterMm = forced["turbine_exducer_diameter_mm"].as<double>(config.forcedInduction.turbineExducerDiameterMm);
            config.forcedInduction.blowOffValveFlowAreaMm2 = forced["blow_off_valve_flow_area_mm2"].as<double>(config.forcedInduction.blowOffValveFlowAreaMm2);
            config.forcedInduction.blowOffValveOpeningPressureRatio = forced["blow_off_valve_opening_pressure_ratio"].as<double>(config.forcedInduction.blowOffValveOpeningPressureRatio);
            config.forcedInduction.blowOffValveDischargeCoefficient = forced["blow_off_valve_discharge_coefficient"].as<double>(config.forcedInduction.blowOffValveDischargeCoefficient);
            config.forcedInduction.compressorSurge = forced["compressor_surge"].as<bool>(config.forcedInduction.compressorSurge);
            config.forcedInduction.chargeVolumeLitres = forced["charge_volume_l"].as<double>(config.forcedInduction.chargeVolumeLitres);
            config.forcedInduction.tonalAcousticEfficiency = forced["tonal_acoustic_efficiency"].as<double>(config.forcedInduction.tonalAcousticEfficiency);
            config.forcedInduction.turbulentJetNoiseCoefficient = forced["turbulent_jet_noise_coefficient"].as<double>(config.forcedInduction.turbulentJetNoiseCoefficient);
            config.forcedInduction.turbochargerCount = forced["turbocharger_count"].as<std::uint32_t>(config.forcedInduction.turbochargerCount);
            config.forcedInduction.compressorDesignMassFlowKgPerSecond = forced["compressor_design_mass_flow_kg_s"].as<double>(config.forcedInduction.compressorDesignMassFlowKgPerSecond);
            config.forcedInduction.intercoolerEffectiveness = forced["intercooler_effectiveness"].as<double>(config.forcedInduction.intercoolerEffectiveness);
            config.forcedInduction.maximumShaftSpeedRpm = forced["maximum_shaft_speed_rpm"].as<double>(config.forcedInduction.maximumShaftSpeedRpm);
        }
        if (const auto thermal = engine["thermal"]) {
            config.thermal.regulated = thermal["regulated"].as<bool>(config.thermal.regulated);
            config.thermal.regulatedCoolantTemperatureC = thermal["regulated_coolant_c"].as<double>(config.thermal.regulatedCoolantTemperatureC);
            config.thermal.regulatedOilTemperatureC = thermal["regulated_oil_c"].as<double>(config.thermal.regulatedOilTemperatureC);
            config.thermal.coolantMassKjPerC = thermal["coolant_mass_kj_per_c"].as<double>(config.thermal.coolantMassKjPerC);
            config.thermal.oilMassKjPerC = thermal["oil_mass_kj_per_c"].as<double>(config.thermal.oilMassKjPerC);
            config.thermal.coolantHeatShare = thermal["coolant_heat_share"].as<double>(config.thermal.coolantHeatShare);
            config.thermal.oilHeatShare = thermal["oil_heat_share"].as<double>(config.thermal.oilHeatShare);
            config.thermal.coolingPowerKwPerC = thermal["cooling_power_kw_per_c"].as<double>(config.thermal.coolingPowerKwPerC);
            config.thermal.oilCoolingPowerKwPerC = thermal["oil_cooling_power_kw_per_c"].as<double>(config.thermal.oilCoolingPowerKwPerC);
            config.thermal.liquidCooled = thermal["liquid_cooled"].as<bool>(config.thermal.liquidCooled);
            config.thermal.engineDrivenFan = thermal["engine_driven_fan"].as<bool>(config.thermal.engineDrivenFan);
        }
        if (const auto voicing = engine["audio_voicing"]) {
            config.audioVoicingFamily = voicing["family"].as<std::string>(std::string {});
            config.audioVoicingKey = voicing["key"].as<std::string>(std::string {});
        }
        if (const auto rotary = engine["rotary"]) {
            config.rotary.generatingRadiusMm = rotary["generating_radius_mm"].as<double>(config.rotary.generatingRadiusMm);
            config.rotary.eccentricityMm = rotary["eccentricity_mm"].as<double>(config.rotary.eccentricityMm);
            config.rotary.rotorWidthMm = rotary["rotor_width_mm"].as<double>(config.rotary.rotorWidthMm);
            config.rotary.rotorCount = rotary["rotor_count"].as<std::uint32_t>(config.rotary.rotorCount);
        }
        if (const auto ports = engine["two_stroke"]) {
            config.twoStroke.exhaustPortOpenDegrees = ports["exhaust_port_open_deg"].as<double>(config.twoStroke.exhaustPortOpenDegrees);
            config.twoStroke.transferPortOpenDegrees = ports["transfer_port_open_deg"].as<double>(config.twoStroke.transferPortOpenDegrees);
            config.twoStroke.exhaustPortWidthMm = ports["exhaust_port_width_mm"].as<double>(config.twoStroke.exhaustPortWidthMm);
            config.twoStroke.transferPortWidthMm = ports["transfer_port_width_mm"].as<double>(config.twoStroke.transferPortWidthMm);
            config.twoStroke.portDischargeCoefficient = ports["port_discharge_coefficient"].as<double>(config.twoStroke.portDischargeCoefficient);
            config.twoStroke.crankcaseCompressionRatio = ports["crankcase_compression_ratio"].as<double>(config.twoStroke.crankcaseCompressionRatio);
            config.twoStroke.scavengeLoopLengthRatio = ports["scavenge_loop_length_ratio"].as<double>(config.twoStroke.scavengeLoopLengthRatio);
            config.twoStroke.powerValveClosedExhaustPortOpenDegrees = ports["power_valve_closed_exhaust_port_open_deg"].as<double>(config.twoStroke.powerValveClosedExhaustPortOpenDegrees);
            config.twoStroke.powerValveOpeningStartRpm = ports["power_valve_opening_start_rpm"].as<double>(config.twoStroke.powerValveOpeningStartRpm);
            config.twoStroke.powerValveFullyOpenRpm = ports["power_valve_fully_open_rpm"].as<double>(config.twoStroke.powerValveFullyOpenRpm);
            if (const auto intake = ports["intake"]) {
                const auto parsed = parseTwoStrokeIntake(intake.as<std::string>());
                if (!parsed) throw std::runtime_error("Unknown two-stroke intake (crankcase_reed or cylinder_port)");
                config.twoStroke.intake = *parsed;
            }
            config.twoStroke.intakePortOpenDegreesBtdc = ports["intake_port_open_deg_btdc"].as<double>(config.twoStroke.intakePortOpenDegreesBtdc);
            config.twoStroke.intakePortWidthMm = ports["intake_port_width_mm"].as<double>(config.twoStroke.intakePortWidthMm);
            config.twoStroke.intakePortReed = ports["intake_port_reed"].as<bool>(config.twoStroke.intakePortReed);
        }
        if (const auto calibration = engine["combustion_calibration"]) {
            config.combustionCalibration.baseIgnitionDelaySeconds = calibration["base_ignition_delay_s"].as<double>(config.combustionCalibration.baseIgnitionDelaySeconds);
            config.combustionCalibration.ignitionDelayTemperatureExponent = calibration["ignition_delay_temperature_exponent"].as<double>(config.combustionCalibration.ignitionDelayTemperatureExponent);
            config.combustionCalibration.ignitionDelayPressureExponent = calibration["ignition_delay_pressure_exponent"].as<double>(config.combustionCalibration.ignitionDelayPressureExponent);
            config.combustionCalibration.wallHeatTransferCoefficientWPerK = calibration["wall_heat_transfer_w_per_k"].as<double>(config.combustionCalibration.wallHeatTransferCoefficientWPerK);
            config.combustionCalibration.residualDilutionSensitivity = calibration["residual_dilution_sensitivity"].as<double>(config.combustionCalibration.residualDilutionSensitivity);
            config.combustionCalibration.chamberTurbulenceIntensityRatio = calibration["chamber_turbulence_intensity_ratio"].as<double>(config.combustionCalibration.chamberTurbulenceIntensityRatio);
            config.combustionCalibration.ignitionSiteCount = calibration["ignition_site_count"].as<std::uint32_t>(config.combustionCalibration.ignitionSiteCount);
            config.combustionCalibration.compressionIgnitionDelayScale = calibration["compression_ignition_delay_scale"].as<double>(config.combustionCalibration.compressionIgnitionDelayScale);
            config.combustionCalibration.compressionIgnitionMixingTimeSeconds = calibration["compression_ignition_mixing_time_s"].as<double>(config.combustionCalibration.compressionIgnitionMixingTimeSeconds);
            config.combustionCalibration.compressionIgnitionPremixedFraction = calibration["compression_ignition_premixed_fraction"].as<double>(config.combustionCalibration.compressionIgnitionPremixedFraction);
            config.combustionCalibration.compressionIgnitionMixedPremix = calibration["compression_ignition_mixed_premix"].as<bool>(config.combustionCalibration.compressionIgnitionMixedPremix);
            config.combustionCalibration.cycleVariationCoefficientOfVariation = calibration["cycle_variation_cov"].as<double>(config.combustionCalibration.cycleVariationCoefficientOfVariation);
            config.combustionCalibration.cycleVariationCorrelation = calibration["cycle_variation_correlation"].as<double>(config.combustionCalibration.cycleVariationCorrelation);
        }
        if (const auto afterfire = engine["exhaust_afterfire"]) {
            config.exhaustAfterfire.enabled = afterfire["enabled"].as<bool>(config.exhaustAfterfire.enabled);
            if (const auto strategy = afterfire["strategy"])
                config.exhaustAfterfire.strategy = decodeAfterfireStrategy(
                    strategy.as<std::string>());
            config.exhaustAfterfire.ignitionTemperatureK = afterfire["ignition_temperature_k"].as<double>(config.exhaustAfterfire.ignitionTemperatureK);
            config.exhaustAfterfire.reactionTimeConstantSeconds = afterfire["reaction_time_constant_s"].as<double>(config.exhaustAfterfire.reactionTimeConstantSeconds);
            config.exhaustAfterfire.reactionEfficiency = afterfire["reaction_efficiency"].as<double>(config.exhaustAfterfire.reactionEfficiency);
            config.exhaustAfterfire.overrunMinimumRpm = afterfire["overrun_minimum_rpm"].as<double>(config.exhaustAfterfire.overrunMinimumRpm);
            config.exhaustAfterfire.overrunMaximumThrottle = afterfire["overrun_maximum_throttle"].as<double>(config.exhaustAfterfire.overrunMaximumThrottle);
            config.exhaustAfterfire.overrunSparkAdvanceDegrees = afterfire["overrun_spark_advance_deg"].as<double>(config.exhaustAfterfire.overrunSparkAdvanceDegrees);
            config.exhaustAfterfire.inductionTimeSeconds = afterfire["induction_time_s"].as<double>(config.exhaustAfterfire.inductionTimeSeconds);
            config.exhaustAfterfire.inductionReferencePressureKpa = afterfire["induction_reference_pressure_kpa"].as<double>(config.exhaustAfterfire.inductionReferencePressureKpa);
            config.exhaustAfterfire.inductionActivationTemperatureK = afterfire["induction_activation_temperature_k"].as<double>(config.exhaustAfterfire.inductionActivationTemperatureK);
            config.exhaustAfterfire.inductionPressureExponent = afterfire["induction_pressure_exponent"].as<double>(config.exhaustAfterfire.inductionPressureExponent);
            config.exhaustAfterfire.inductionEquivalenceRatioExponent = afterfire["induction_equivalence_ratio_exponent"].as<double>(config.exhaustAfterfire.inductionEquivalenceRatioExponent);
            config.exhaustAfterfire.inductionDecayTimeSeconds = afterfire["induction_decay_time_s"].as<double>(config.exhaustAfterfire.inductionDecayTimeSeconds);
            config.exhaustAfterfire.minimumEquivalenceRatio = afterfire["minimum_equivalence_ratio"].as<double>(config.exhaustAfterfire.minimumEquivalenceRatio);
            config.exhaustAfterfire.maximumEquivalenceRatio = afterfire["maximum_equivalence_ratio"].as<double>(config.exhaustAfterfire.maximumEquivalenceRatio);
            config.exhaustAfterfire.quenchTemperatureK = afterfire["quench_temperature_k"].as<double>(config.exhaustAfterfire.quenchTemperatureK);
            config.exhaustAfterfire.pocketMixingTimeSeconds = afterfire["pocket_mixing_time_s"].as<double>(config.exhaustAfterfire.pocketMixingTimeSeconds);
            config.exhaustAfterfire.overrunSparkCutFraction = afterfire["overrun_spark_cut_fraction"].as<double>(config.exhaustAfterfire.overrunSparkCutFraction);
        }
        if (const auto acoustics = engine["runner_acoustics"]) {
            config.runnerAcoustics.enabled = acoustics["enabled"].as<bool>(config.runnerAcoustics.enabled);
            config.runnerAcoustics.dampingRatio = acoustics["damping_ratio"].as<double>(config.runnerAcoustics.dampingRatio);
            config.runnerAcoustics.couplingGain = acoustics["coupling_gain"].as<double>(config.runnerAcoustics.couplingGain);
            config.runnerAcoustics.maximumPressureAmplitudeKpa = acoustics["maximum_pressure_amplitude_kpa"].as<double>(config.runnerAcoustics.maximumPressureAmplitudeKpa);
        }
        if (const auto structuralNvh = engine["structural_nvh"])
            config.structuralNvh =
                decodeStructuralNvh(structuralNvh);
        if (const auto cams = engine["camshafts"]) {
            config.camshafts = { cams["intake_duration_deg"].as<double>(248.0),
                cams["exhaust_duration_deg"].as<double>(244.0), cams["intake_lift_mm"].as<double>(10.2),
                cams["exhaust_lift_mm"].as<double>(9.8), cams["intake_centerline_deg"].as<double>(110.0),
                cams["exhaust_centerline_deg"].as<double>(112.0) };
            config.camshafts.intakeFlowCoefficient = cams["intake_flow_coefficient"].as<double>(0.62);
            config.camshafts.exhaustFlowCoefficient = cams["exhaust_flow_coefficient"].as<double>(0.62);
            config.camshafts.variableProfileEnabled = cams["variable_profile_enabled"].as<bool>(false);
            config.camshafts.switchRpm = cams["switch_rpm"].as<double>(config.camshafts.switchRpm);
            config.camshafts.switchThrottle = cams["switch_throttle"].as<double>(config.camshafts.switchThrottle);
            config.camshafts.highIntakeDurationDegrees = cams["high_intake_duration_deg"].as<double>(config.camshafts.highIntakeDurationDegrees);
            config.camshafts.highExhaustDurationDegrees = cams["high_exhaust_duration_deg"].as<double>(config.camshafts.highExhaustDurationDegrees);
            config.camshafts.highIntakeLiftMm = cams["high_intake_lift_mm"].as<double>(config.camshafts.highIntakeLiftMm);
            config.camshafts.highExhaustLiftMm = cams["high_exhaust_lift_mm"].as<double>(config.camshafts.highExhaustLiftMm);
            if (cams["intake_lift_profile"]) config.camshafts.intakeLiftProfile = decodeLiftProfile(cams["intake_lift_profile"]);
            if (cams["exhaust_lift_profile"]) config.camshafts.exhaustLiftProfile = decodeLiftProfile(cams["exhaust_lift_profile"]);
            if (cams["high_intake_lift_profile"]) config.camshafts.highIntakeLiftProfile = decodeLiftProfile(cams["high_intake_lift_profile"]);
            if (cams["high_exhaust_lift_profile"]) config.camshafts.highExhaustLiftProfile = decodeLiftProfile(cams["high_exhaust_lift_profile"]);
            decodeExtendedCamshaft(config.camshafts, cams);
        }
        if (const auto crankshafts = engine["crankshafts"]) {
            for (const auto& item : crankshafts) {
                CrankshaftConfig crankshaft;
                crankshaft.id = item["id"].as<std::uint32_t>();
                crankshaft.positionXMm = item["position_x_mm"].as<double>(0.0);
                crankshaft.positionYMm = item["position_y_mm"].as<double>(0.0);
                crankshaft.phaseOffsetDegrees = item["phase_offset_deg"].as<double>(0.0);
                crankshaft.rotationRatio = item["rotation_ratio"].as<double>(1.0);
                crankshaft.massKg = item["mass_kg"].as<double>(crankshaft.massKg);
                crankshaft.flywheelMassKg = item["flywheel_mass_kg"].as<double>(crankshaft.flywheelMassKg);
                crankshaft.momentOfInertiaKgM2 = item["moment_of_inertia_kg_m2"].as<double>(config.rotatingInertiaKgM2);
                crankshaft.frictionTorqueNm = item["friction_torque_nm"].as<double>(0.0);
                config.crankshafts.push_back(crankshaft);
            }
        }
        if (const auto crankJournals = engine["crank_journals"]) {
            for (const auto& journal : crankJournals)
                config.crankJournals.push_back({ journal["id"].as<std::uint32_t>(),
                    journal["angle_deg"].as<double>(), journal["throw_mm"].as<double>(),
                    journal["crankshaft_id"].as<std::uint32_t>(1) });
        }
        if (const auto exhaust = engine["exhaust"]) config.exhaust = {
            exhaust["primary_length_mm"].as<double>(480.0), exhaust["primary_diameter_mm"].as<double>(42.0),
            exhaust["collector_diameter_mm"].as<double>(58.0), exhaust["muffler_restriction"].as<double>(0.28),
            exhaust["outlet_diameter_mm"].as<double>(65.0), exhaust["collector_volume_l"].as<double>(2.0),
            exhaust["outlet_discharge_coefficient"].as<double>(0.72),
            exhaust["muffler_chamber_diameter_mm"].as<double>(0.0),
            exhaust["muffler_chamber_length_mm"].as<double>(0.0),
            exhaust["muffler_packing_flow_resistivity_pa_s_m2"].as<double>(0.0),
            exhaust["muffler_packing_thickness_mm"].as<double>(0.0),
            exhaust["muffler_perforated_open_area_ratio"].as<double>(0.0),
            exhaust["midpipe_length_mm"].as<double>(0.0),
            exhaust["midpipe_diameter_mm"].as<double>(0.0) };
        if (const auto transmission = engine["transmission"]) {
            if (transmission["gear_ratios"]) config.transmission.gearRatios = transmission["gear_ratios"].as<std::vector<double>>();
            if (transmission["final_drive_ratio"]) config.transmission.finalDriveRatio = transmission["final_drive_ratio"].as<double>();
            if (transmission["max_clutch_torque_nm"]) config.transmission.maxClutchTorqueNm = transmission["max_clutch_torque_nm"].as<double>();
            if (transmission["driveline_efficiency"]) config.transmission.drivelineEfficiency = transmission["driveline_efficiency"].as<double>();
            if (transmission["driven_wheel_inertia_kg_m2"]) config.transmission.drivenWheelInertiaKgM2 = transmission["driven_wheel_inertia_kg_m2"].as<double>();
            if (transmission["clutch_lock_speed_rpm"]) config.transmission.clutchLockSpeedRpm = transmission["clutch_lock_speed_rpm"].as<double>();
            if (transmission["shift_duration_s"]) config.transmission.shiftDurationSeconds = transmission["shift_duration_s"].as<double>();
            if (transmission["automatic_shifting"]) config.transmission.automaticShifting = transmission["automatic_shifting"].as<bool>();
            if (transmission["automatic_upshift_rpm"]) config.transmission.automaticUpshiftRpm = transmission["automatic_upshift_rpm"].as<double>();
            if (transmission["automatic_downshift_rpm"]) config.transmission.automaticDownshiftRpm = transmission["automatic_downshift_rpm"].as<double>();
            if (transmission["reverse_ratio"]) config.transmission.reverseRatio = transmission["reverse_ratio"].as<double>();
            if (transmission["gearbox_input_inertia_kg_m2"]) config.transmission.gearboxInputInertiaKgM2 = transmission["gearbox_input_inertia_kg_m2"].as<double>();
            if (transmission["differential_inertia_kg_m2"]) config.transmission.differentialInertiaKgM2 = transmission["differential_inertia_kg_m2"].as<double>();
            if (transmission["clutch_thermal_capacity_j_per_c"]) config.transmission.clutchThermalCapacityJPerC = transmission["clutch_thermal_capacity_j_per_c"].as<double>();
            if (transmission["clutch_cooling_w_per_c"]) config.transmission.clutchCoolingWPerC = transmission["clutch_cooling_w_per_c"].as<double>();
            if (transmission["clutch_fade_start_temperature_c"]) config.transmission.clutchFadeStartTemperatureC = transmission["clutch_fade_start_temperature_c"].as<double>();
            if (transmission["clutch_failure_temperature_c"]) config.transmission.clutchFailureTemperatureC = transmission["clutch_failure_temperature_c"].as<double>();
            if (transmission["shift_torque_cut_fraction"]) config.transmission.shiftTorqueCutFraction = transmission["shift_torque_cut_fraction"].as<double>();
            if (transmission["shift_style"]) {
                const auto styleName = transmission["shift_style"].as<std::string>();
                const auto style = parseShiftStyle(styleName);
                if (!style) throw std::invalid_argument("Unknown shift style: " + styleName);
                config.transmission.shiftStyle = *style;
            }
            if (transmission["quickshifter"]) config.transmission.quickshifter = transmission["quickshifter"].as<bool>();
            if (transmission["quickshifter_cut_s"]) config.transmission.quickshifterCutSeconds = transmission["quickshifter_cut_s"].as<double>();
            if (transmission["auto_blipper"]) config.transmission.autoBlipper = transmission["auto_blipper"].as<bool>();
            if (transmission["dual_clutch_upshift_retard_deg"])
                config.transmission.dualClutchUpshiftRetardDegrees =
                    transmission["dual_clutch_upshift_retard_deg"].as<double>();
            if (transmission["dual_clutch_upshift_cylinder_cut"])
                config.transmission.dualClutchUpshiftCylinderCutFraction =
                    transmission["dual_clutch_upshift_cylinder_cut"].as<double>();
            if (transmission["centrifugal_clutch"])
                config.transmission.centrifugalClutch = transmission["centrifugal_clutch"].as<bool>();
            if (transmission["centrifugal_clutch_engage_rpm"])
                config.transmission.centrifugalClutchEngageRpm =
                    transmission["centrifugal_clutch_engage_rpm"].as<double>();
        }
        if (const auto vehicle = engine["vehicle"]) {
            if (vehicle["mass_kg"]) config.vehicle.massKg = vehicle["mass_kg"].as<double>();
            if (vehicle["drag_coefficient"]) config.vehicle.dragCoefficient = vehicle["drag_coefficient"].as<double>();
            if (vehicle["frontal_area_m2"]) config.vehicle.frontalAreaM2 = vehicle["frontal_area_m2"].as<double>();
            if (vehicle["tire_radius_m"]) config.vehicle.tireRadiusM = vehicle["tire_radius_m"].as<double>();
            if (vehicle["rolling_resistance_coefficient"])
                config.vehicle.rollingResistanceCoefficient = vehicle["rolling_resistance_coefficient"].as<double>();
            if (vehicle["tire_friction_coefficient"]) config.vehicle.tireFrictionCoefficient = vehicle["tire_friction_coefficient"].as<double>();
            if (vehicle["tyre_grip_limit_enabled"])
                config.vehicle.tyreGripLimitEnabled = vehicle["tyre_grip_limit_enabled"].as<bool>();
            config.vehicle.drivenAxleLayout = decodeDrivenAxleLayout(
                vehicle["driven_axle_layout"].as<std::string>(
                    drivenAxleLayoutName(
                        config.vehicle.drivenAxleLayout)));
            if (vehicle["driven_axle_weight_fraction"]) config.vehicle.drivenAxleWeightFraction = vehicle["driven_axle_weight_fraction"].as<double>();
            if (vehicle["wheelbase_m"])
                config.vehicle.wheelbaseM =
                    vehicle["wheelbase_m"].as<double>();
            if (vehicle["center_of_gravity_height_m"])
                config.vehicle.centerOfGravityHeightM =
                    vehicle["center_of_gravity_height_m"].as<double>();
            if (vehicle["maximum_brake_force_n"]) config.vehicle.maximumBrakeForceN = vehicle["maximum_brake_force_n"].as<double>();
        }
        if (const auto valve = engine["exhaust_valve"]) {
            auto& value = config.exhaustValve;
            value.openAboveRpm = valve["open_above_rpm"].as<double>(value.openAboveRpm);
            value.openAboveThrottle = valve["open_above_throttle"].as<double>(value.openAboveThrottle);
            value.travelSeconds = valve["travel_s"].as<double>(value.travelSeconds);
        }
        if (const auto kit = engine["nitrous"]) {
            auto& value = config.nitrous;
            value.fitted = kit["fitted"].as<bool>(value.fitted);
            value.type = kit["type"].as<std::string>("wet") == "dry" ? NitrousKitType::dry : NitrousKitType::wet;
            value.shotKw = kit["shot_kw"].as<double>(value.shotKw);
            value.bottleCapacityKg = kit["bottle_kg"].as<double>(value.bottleCapacityKg);
            value.unlimitedBottle = kit["unlimited_bottle"].as<bool>(value.unlimitedBottle);
            value.bottleHeater = kit["bottle_heater"].as<bool>(value.bottleHeater);
            value.bottleTemperatureC = kit["bottle_temperature_c"].as<double>(value.bottleTemperatureC);
            value.minimumThrottle = kit["minimum_throttle"].as<double>(value.minimumThrottle);
            value.minimumRpm = kit["minimum_rpm"].as<double>(value.minimumRpm);
            value.maximumRpm = kit["maximum_rpm"].as<double>(value.maximumRpm);
            value.pushButton = kit["push_button"].as<bool>(value.pushButton);
            value.rampSeconds = kit["ramp_s"].as<double>(value.rampSeconds);
            value.sparkRetardDegreesPer50Hp = kit["spark_retard_deg_per_50hp"].as<double>(value.sparkRetardDegreesPer50Hp);
            value.kitLambda = kit["kit_lambda"].as<double>(value.kitLambda);
        }
        if (const auto brake = engine["engine_brake"]) {
            auto& value = config.engineBrake;
            value.fitted = brake["fitted"].as<bool>(value.fitted);
            value.valveLiftMm = brake["valve_lift_mm"].as<double>(value.valveLiftMm);
            value.peakAfterTdcDegrees = brake["peak_after_tdc_deg"].as<double>(value.peakAfterTdcDegrees);
            value.durationDegrees = brake["duration_deg"].as<double>(value.durationDegrees);
            value.minimumRpm = brake["minimum_rpm"].as<double>(value.minimumRpm);
            value.stageCount = brake["stage_count"].as<std::uint32_t>(value.stageCount);
        }
        config.intake.plenumVolumeLitres = config.plenumVolumeLitres;
        config.intake.throttleDiameterMm = config.throttleDiameterMm;
        if (const auto intake = engine["intake"]) {
            config.intake.plenumVolumeLitres = intake["plenum_volume_l"].as<double>(config.intake.plenumVolumeLitres);
            config.intake.throttleDiameterMm = intake["throttle_diameter_mm"].as<double>(config.intake.throttleDiameterMm);
            config.intake.throttleCount = intake["throttle_count"].as<std::uint32_t>(config.intake.throttleCount);
            config.intake.throttleDischargeCoefficient = intake["throttle_discharge_coefficient"].as<double>(config.intake.throttleDischargeCoefficient);
            readCarburettor(intake, config.intake.carburettor);
            config.intake.runnerLengthMm = intake["runner_length_mm"].as<double>(config.intake.runnerLengthMm);
            config.intake.runnerDiameterMm = intake["runner_diameter_mm"].as<double>(config.intake.runnerDiameterMm);
            config.intake.runnerPlenumDiameterMm = intake["runner_plenum_diameter_mm"].as<double>(config.intake.runnerPlenumDiameterMm);
            config.intake.airboxVolumeLitres = intake["airbox_volume_l"].as<double>(config.intake.airboxVolumeLitres);
            config.intake.podFilter = intake["pod_filter"].as<bool>(config.intake.podFilter);
            config.intake.individualThrottles = intake["individual_throttles"].as<bool>(config.intake.individualThrottles);
            config.intake.throttleDistanceFromValveMm = intake["throttle_distance_from_valve_mm"].as<double>(config.intake.throttleDistanceFromValveMm);
            config.intake.inletDuctLengthMm = intake["inlet_duct_length_mm"].as<double>(config.intake.inletDuctLengthMm);
            config.intake.inletDuctDiameterMm = intake["inlet_duct_diameter_mm"].as<double>(config.intake.inletDuctDiameterMm);
            config.intake.bellmouthDiameterMm = intake["bellmouth_diameter_mm"].as<double>(config.intake.bellmouthDiameterMm);
            config.intake.idleBypassAreaMm2 = intake["idle_bypass_area_mm2"].as<double>(config.intake.idleBypassAreaMm2);
            config.intake.closedThrottleLeakageAreaMm2 = intake["closed_throttle_leak_mm2"].as<double>(config.intake.closedThrottleLeakageAreaMm2);
            config.intake.throttleGamma = intake["throttle_gamma"].as<double>(config.intake.throttleGamma);
        }
        if (const auto paths = engine["intake_paths"]) {
            for (const auto& item : paths) {
                IntakePathConfig path;
                path.id = item["id"].as<std::uint32_t>();
                path.cylinderIds = item["cylinder_ids"].as<std::vector<std::uint32_t>>();
                if (const auto geometry = item["geometry"]) {
                    path.geometry.plenumVolumeLitres = geometry["plenum_volume_l"].as<double>(path.geometry.plenumVolumeLitres);
                    path.geometry.throttleDiameterMm = geometry["throttle_diameter_mm"].as<double>(path.geometry.throttleDiameterMm);
                    path.geometry.throttleCount = geometry["throttle_count"].as<std::uint32_t>(path.geometry.throttleCount);
                    path.geometry.throttleDischargeCoefficient = geometry["throttle_discharge_coefficient"].as<double>(path.geometry.throttleDischargeCoefficient);
                    readCarburettor(geometry, path.geometry.carburettor);
                    path.geometry.runnerLengthMm = geometry["runner_length_mm"].as<double>(path.geometry.runnerLengthMm);
                    path.geometry.runnerDiameterMm = geometry["runner_diameter_mm"].as<double>(path.geometry.runnerDiameterMm);
                    path.geometry.runnerPlenumDiameterMm = geometry["runner_plenum_diameter_mm"].as<double>(path.geometry.runnerPlenumDiameterMm);
                    path.geometry.airboxVolumeLitres = geometry["airbox_volume_l"].as<double>(path.geometry.airboxVolumeLitres);
                    path.geometry.podFilter = geometry["pod_filter"].as<bool>(path.geometry.podFilter);
                    path.geometry.individualThrottles = geometry["individual_throttles"].as<bool>(path.geometry.individualThrottles);
                    path.geometry.throttleDistanceFromValveMm = geometry["throttle_distance_from_valve_mm"].as<double>(path.geometry.throttleDistanceFromValveMm);
                    path.geometry.inletDuctLengthMm = geometry["inlet_duct_length_mm"].as<double>(path.geometry.inletDuctLengthMm);
                    path.geometry.inletDuctDiameterMm = geometry["inlet_duct_diameter_mm"].as<double>(path.geometry.inletDuctDiameterMm);
                    path.geometry.bellmouthDiameterMm = geometry["bellmouth_diameter_mm"].as<double>(path.geometry.bellmouthDiameterMm);
                    path.geometry.idleBypassAreaMm2 = geometry["idle_bypass_area_mm2"].as<double>(path.geometry.idleBypassAreaMm2);
                    path.geometry.closedThrottleLeakageAreaMm2 = geometry["closed_throttle_leak_mm2"].as<double>(path.geometry.closedThrottleLeakageAreaMm2);
                    path.geometry.throttleGamma = geometry["throttle_gamma"].as<double>(path.geometry.throttleGamma);
                }
                config.intakePaths.push_back(std::move(path));
            }
        }
        config.ignition.revLimitRpm = config.redlineRpm;
        if (const auto ignition = engine["ignition"]) {
            config.ignition.revLimitRpm = ignition["rev_limit_rpm"].as<double>(config.redlineRpm);
            config.ignition.limiterDurationSeconds = ignition["limiter_duration_s"].as<double>(config.ignition.limiterDurationSeconds);
            config.ignition.limiterKeepsFuel = ignition["limiter_keeps_fuel"].as<bool>(config.ignition.limiterKeepsFuel);
            if (ignition["timing_curve"]) {
                config.ignition.timingCurve.clear();
                for (const auto& sample : ignition["timing_curve"])
                    config.ignition.timingCurve.push_back({ sample["rpm"].as<double>(), sample["advance_deg"].as<double>() });
            }
            if (ignition["knock_limit_curve"]) {
                config.ignition.knockLimitCurve.clear();
                for (const auto& sample : ignition["knock_limit_curve"])
                    config.ignition.knockLimitCurve.push_back({ sample["rpm"].as<double>(),
                        sample["advance_deg"].as<double>(), sample["map_kpa"].as<double>() });
            }
        }
        if (const auto injection = engine["injection"]) {
            const auto mode = injection["mode"].as<std::string>("direct");
            if (mode == "port") {
                config.injection.mode = InjectionMode::port;
                config.injection.startAngleDegrees = 250.0;
                config.injection.endAngleDegrees = 620.0;
                config.injection.injectorFlowMgPerSecond = 5'000.0;
                config.injection.railPressureBar = 4.0;
                config.injection.referencePressureBar = 4.0;
                config.injection.wallFilmFraction = 0.22;
                config.injection.vaporisationTimeConstantSeconds = 0.26;
            }
            else if (mode == "direct") config.injection.mode = InjectionMode::direct;
            else return { std::nullopt, "Unknown injection mode: " + mode };
            config.injection.startAngleDegrees = injection["start_angle_deg"].as<double>(config.injection.startAngleDegrees);
            config.injection.endAngleDegrees = injection["end_angle_deg"].as<double>(config.injection.endAngleDegrees);
            config.injection.injectorFlowMgPerSecond = injection["injector_flow_mg_s"].as<double>(config.injection.injectorFlowMgPerSecond);
            config.injection.fuelTemperatureC = injection["fuel_temperature_c"].as<double>(config.injection.fuelTemperatureC);
            config.injection.railPressureBar = injection["rail_pressure_bar"].as<double>(config.injection.railPressureBar);
            config.injection.referencePressureBar = injection["reference_pressure_bar"].as<double>(config.injection.referencePressureBar);
            config.injection.wallFilmFraction = injection["wall_film_fraction"].as<double>(config.injection.wallFilmFraction);
            config.injection.vaporisationTimeConstantSeconds = injection["vaporisation_time_constant_s"].as<double>(config.injection.vaporisationTimeConstantSeconds);
            config.injection.latentHeatKjPerKg = injection["latent_heat_kj_per_kg"].as<double>(config.injection.latentHeatKjPerKg);
            config.injection.directChargeCoolingEfficiency = injection["direct_charge_cooling_efficiency"].as<double>(config.injection.directChargeCoolingEfficiency);
            config.injection.portChargeCoolingEfficiency = injection["port_charge_cooling_efficiency"].as<double>(config.injection.portChargeCoolingEfficiency);
            config.injection.directSprayVaporisationTimeConstantSeconds = injection["direct_spray_vaporisation_time_constant_s"].as<double>(config.injection.directSprayVaporisationTimeConstantSeconds);
            config.injection.directSprayEntrainmentTimeConstantSeconds = injection["direct_spray_entrainment_time_constant_s"].as<double>(config.injection.directSprayEntrainmentTimeConstantSeconds);
            if (const auto limit = injection["full_load_fuel_limit"]) {
                config.injection.fullLoadFuelLimit.clear();
                for (const auto& sample : limit)
                    config.injection.fullLoadFuelLimit.push_back({
                        sample["rpm"].as<double>(),
                        sample["mg_per_cycle"].as<double>() });
            }
        }
        if (const auto solver = engine["solver"]) {
            config.solver.mechanicalFrequencyHz = solver["mechanical_frequency_hz"].as<double>(config.solver.mechanicalFrequencyHz);
            config.solver.maximumMechanicalFrequencyHz = solver["maximum_frequency_hz"].as<double>(config.solver.maximumMechanicalFrequencyHz);
            config.solver.maximumCrankDegreesPerStep = solver["maximum_crank_deg_per_step"].as<double>(config.solver.maximumCrankDegreesPerStep);
            config.solver.gasSubsteps = solver["gas_substeps"].as<std::uint32_t>(config.solver.gasSubsteps);
        }
        if (const auto banks = engine["banks"]) {
            for (const auto& item : banks) {
                CylinderBankConfig bank;
                bank.id = item["id"].as<std::uint32_t>();
                bank.angleDegrees = item["angle_deg"].as<double>(0.0);
                bank.cylinderIds = item["cylinder_ids"].as<std::vector<std::uint32_t>>();
                bank.intakeId = item["intake_id"].as<std::uint32_t>(0);
                bank.exhaustPathId = item["exhaust_path_id"].as<std::uint32_t>(0);
                if (const auto cams = item["camshafts"]) {
                    bank.camshafts.intakeDurationDegrees = cams["intake_duration_deg"].as<double>(bank.camshafts.intakeDurationDegrees);
                    bank.camshafts.exhaustDurationDegrees = cams["exhaust_duration_deg"].as<double>(bank.camshafts.exhaustDurationDegrees);
                    bank.camshafts.intakeLiftMm = cams["intake_lift_mm"].as<double>(bank.camshafts.intakeLiftMm);
                    bank.camshafts.exhaustLiftMm = cams["exhaust_lift_mm"].as<double>(bank.camshafts.exhaustLiftMm);
                    bank.camshafts.intakeCenterlineDegrees = cams["intake_centerline_deg"].as<double>(bank.camshafts.intakeCenterlineDegrees);
                    bank.camshafts.exhaustCenterlineDegrees = cams["exhaust_centerline_deg"].as<double>(bank.camshafts.exhaustCenterlineDegrees);
                    bank.camshafts.intakeFlowCoefficient = cams["intake_flow_coefficient"].as<double>(bank.camshafts.intakeFlowCoefficient);
                    bank.camshafts.exhaustFlowCoefficient = cams["exhaust_flow_coefficient"].as<double>(bank.camshafts.exhaustFlowCoefficient);
                    bank.camshafts.variableProfileEnabled = cams["variable_profile_enabled"].as<bool>(false);
                    bank.camshafts.switchRpm = cams["switch_rpm"].as<double>(bank.camshafts.switchRpm);
                    bank.camshafts.switchThrottle = cams["switch_throttle"].as<double>(bank.camshafts.switchThrottle);
                    bank.camshafts.highIntakeDurationDegrees = cams["high_intake_duration_deg"].as<double>(bank.camshafts.highIntakeDurationDegrees);
                    bank.camshafts.highExhaustDurationDegrees = cams["high_exhaust_duration_deg"].as<double>(bank.camshafts.highExhaustDurationDegrees);
                    bank.camshafts.highIntakeLiftMm = cams["high_intake_lift_mm"].as<double>(bank.camshafts.highIntakeLiftMm);
                    bank.camshafts.highExhaustLiftMm = cams["high_exhaust_lift_mm"].as<double>(bank.camshafts.highExhaustLiftMm);
                    if (cams["intake_lift_profile"]) bank.camshafts.intakeLiftProfile = decodeLiftProfile(cams["intake_lift_profile"]);
                    if (cams["exhaust_lift_profile"]) bank.camshafts.exhaustLiftProfile = decodeLiftProfile(cams["exhaust_lift_profile"]);
                    if (cams["high_intake_lift_profile"]) bank.camshafts.highIntakeLiftProfile = decodeLiftProfile(cams["high_intake_lift_profile"]);
                    if (cams["high_exhaust_lift_profile"]) bank.camshafts.highExhaustLiftProfile = decodeLiftProfile(cams["high_exhaust_lift_profile"]);
                    decodeExtendedCamshaft(bank.camshafts, cams);
                } else bank.camshafts = config.camshafts;
                config.banks.push_back(std::move(bank));
            }
        }
        if (const auto observer = engine["acoustic_observer"]) {
            if (observer["left_microphone_m"])
                config.acousticObserver.leftMicrophoneM = decodePoint(
                    observer["left_microphone_m"],
                    config.acousticObserver.leftMicrophoneM);
            if (observer["right_microphone_m"])
                config.acousticObserver.rightMicrophoneM = decodePoint(
                    observer["right_microphone_m"],
                    config.acousticObserver.rightMicrophoneM);
            config.acousticObserver.soundSpeedMps = observer["sound_speed_mps"]
                .as<double>(config.acousticObserver.soundSpeedMps);
            config.acousticObserver.listeningDistanceM =
                observer["listening_distance_m"].as<double>(
                    config.acousticObserver.listeningDistanceM);
        }
        if (const auto paths = engine["exhaust_paths"]) {
            for (const auto& item : paths) {
                ExhaustPathConfig path;
                path.id = item["id"].as<std::uint32_t>();
                path.cylinderIds = item["cylinder_ids"].as<std::vector<std::uint32_t>>();
                path.impulseResponsePath = item["impulse_response"].as<std::string>("");
                path.audioVolume = item["audio_volume"].as<double>(1.0);
                path.turbocharger = item["turbocharger"].as<std::int32_t>(-1);
                if (item["acoustic_position_m"])
                    path.acousticPositionM = decodePoint(item["acoustic_position_m"]);
                if (item["acoustic_axis"])
                    path.acousticAxis = decodePoint(
                        item["acoustic_axis"], path.acousticAxis);
                path.acousticTermination = item["acoustic_termination"]
                    .as<std::string>("unflanged") == "flanged"
                    ? AcousticTerminationType::flanged
                    : AcousticTerminationType::unflanged;
                if (const auto geometry = item["geometry"]) path.geometry = {
                    geometry["primary_length_mm"].as<double>(480.0), geometry["primary_diameter_mm"].as<double>(42.0),
                    geometry["collector_diameter_mm"].as<double>(58.0), geometry["muffler_restriction"].as<double>(0.28),
                    geometry["outlet_diameter_mm"].as<double>(65.0), geometry["collector_volume_l"].as<double>(2.0),
                    geometry["outlet_discharge_coefficient"].as<double>(0.72),
                    geometry["muffler_chamber_diameter_mm"].as<double>(0.0),
                    geometry["muffler_chamber_length_mm"].as<double>(0.0),
                    geometry["muffler_packing_flow_resistivity_pa_s_m2"].as<double>(0.0),
                    geometry["muffler_packing_thickness_mm"].as<double>(0.0),
                    geometry["muffler_perforated_open_area_ratio"].as<double>(0.0),
                    geometry["midpipe_length_mm"].as<double>(0.0),
                    geometry["midpipe_diameter_mm"].as<double>(0.0) };
                if (const auto encodedGraph = item["graph"]) {
                    ExhaustNetworkConfig network;
                    for (const auto& encodedComponent : encodedGraph["components"]) {
                        const auto typeName = encodedComponent["type"].as<std::string>();
                        const auto type = decodeExhaustComponentType(typeName);
                        if (!type) return { std::nullopt, "Unknown exhaust component type: " + typeName };
                        ExhaustComponentConfig component;
                        component.id = encodedComponent["id"].as<std::uint32_t>();
                        component.type = *type;
                        component.lengthMm = encodedComponent["length_mm"].as<double>(component.lengthMm);
                        component.diameterMm = encodedComponent["diameter_mm"].as<double>(component.diameterMm);
                        component.outletDiameterMm = encodedComponent[
                            "outlet_diameter_mm"].as<double>(
                                component.outletDiameterMm);
                        component.volumeLitres = encodedComponent["volume_l"].as<double>(component.volumeLitres);
                        component.restriction = encodedComponent["restriction"].as<double>(component.restriction);
                        component.resonanceHz = encodedComponent["resonance_hz"].as<double>(component.resonanceHz);
                        component.acousticGain = encodedComponent["acoustic_gain"].as<double>(component.acousticGain);
                        component.dischargeCoefficient = encodedComponent["discharge_coefficient"].as<double>(
                            component.dischargeCoefficient);
                        component.packingFlowResistivityPaSPerM2 = encodedComponent[
                            "packing_flow_resistivity_pa_s_m2"].as<double>(
                                component.packingFlowResistivityPaSPerM2);
                        component.packingThicknessMm = encodedComponent[
                            "packing_thickness_mm"].as<double>(component.packingThicknessMm);
                        component.perforatedOpenAreaRatio = encodedComponent[
                            "perforated_open_area_ratio"].as<double>(
                                component.perforatedOpenAreaRatio);
                        component.catalystCellDensityCpsi = encodedComponent[
                            "catalyst_cell_density_cpsi"].as<double>(
                                component.catalystCellDensityCpsi);
                        component.catalystOpenAreaRatio = encodedComponent[
                            "catalyst_open_area_ratio"].as<double>(
                                component.catalystOpenAreaRatio);
                        component.catalystSubstrateVolumetricHeatCapacityJPerM3K =
                            encodedComponent[
                                "catalyst_substrate_volumetric_heat_capacity_j_m3_k"].as<double>(
                                    component.catalystSubstrateVolumetricHeatCapacityJPerM3K);
                        component.crossoverCoupling = encodedComponent[
                            "crossover_coupling"].as<double>(
                                component.crossoverCoupling);
                        component.inletValve = encodedComponent[
                            "inlet_valve"].as<bool>(component.inletValve);
                        if (encodedComponent["acoustic_position_m"])
                            component.acousticPositionM = decodePoint(
                                encodedComponent["acoustic_position_m"]);
                        if (encodedComponent["acoustic_axis"])
                            component.acousticAxis = decodePoint(
                                encodedComponent["acoustic_axis"], component.acousticAxis);
                        component.acousticTermination =
                            encodedComponent["acoustic_termination"].as<std::string>(
                                "unflanged") == "flanged"
                                ? AcousticTerminationType::flanged
                                : AcousticTerminationType::unflanged;
                        network.components.push_back(component);
                    }
                    for (const auto& encodedConnection : encodedGraph["cylinder_connections"])
                        network.cylinderConnections.push_back({
                            encodedConnection["cylinder_id"].as<std::uint32_t>(),
                            encodedConnection["to_component_id"].as<std::uint32_t>() });
                    for (const auto& encodedConnection : encodedGraph["connections"])
                        network.connections.push_back({
                            encodedConnection["from_component_id"].as<std::uint32_t>(),
                            encodedConnection["to_component_id"].as<std::uint32_t>(),
                            decodeOptionalCrossoverPort(
                                encodedConnection, "from_port"),
                            decodeOptionalCrossoverPort(
                                encodedConnection, "to_port") });
                    path.network = std::move(network);
                }
                config.exhaustPaths.push_back(std::move(path));
            }
        }
        config.firingOrder = engine["firing_order"].as<std::vector<std::uint32_t>>();
        for (const auto& item : engine["cylinders"]) {
            const std::uint32_t cylinderId = item["id"].as<std::uint32_t>();
            double crankOffset = 0.0;
            if (item["crank_offset_deg"]) {
                crankOffset = item["crank_offset_deg"].as<double>();
            } else {
                const auto it = std::find(config.firingOrder.begin(), config.firingOrder.end(), cylinderId);
                if (it != config.firingOrder.end()) {
                    const auto orderIndex = static_cast<double>(std::distance(config.firingOrder.begin(), it));
                    crankOffset = orderIndex * (cycleDegreesOf(config.cycle) / static_cast<double>(config.firingOrder.size()));
                }
            }
            CylinderConfig cylinder {
                cylinderId, item["bore_mm"].as<double>(), item["stroke_mm"].as<double>(),
                item["connecting_rod_mm"].as<double>(), item["piston_mass_g"].as<double>(), item["compression_ratio"].as<double>(),
                item["ignition_offset_deg"].as<double>(), item["efficiency_offset"].as<double>(), crankOffset };
            cylinder.crankJournalId = item["crank_journal_id"].as<std::uint32_t>(0);
            cylinder.connectingRodMassGrams = item["connecting_rod_mass_g"].as<double>(cylinder.connectingRodMassGrams);
            cylinder.bankOffsetDegrees = item["bank_offset_deg"].as<double>(0.0);
            cylinder.bankId = item["bank_id"].as<std::uint32_t>(0);
            cylinder.intakeRunnerLengthMm = item["intake_runner_length_mm"].as<double>(cylinder.intakeRunnerLengthMm);
            cylinder.intakeRunnerDiameterMm = item["intake_runner_diameter_mm"].as<double>(cylinder.intakeRunnerDiameterMm);
            cylinder.exhaustPrimaryLengthMm = item["exhaust_primary_length_mm"].as<double>(cylinder.exhaustPrimaryLengthMm);
            cylinder.soundAttenuation = item["sound_attenuation"].as<double>(cylinder.soundAttenuation);
            cylinder.blowByCoefficient = item["blow_by_coefficient"].as<double>(cylinder.blowByCoefficient);
            cylinder.pistonFrictionCoefficient = item["piston_friction_coefficient"].as<double>(cylinder.pistonFrictionCoefficient);
            cylinder.pistonBreakawayForceN = item["piston_breakaway_force_n"].as<double>(cylinder.pistonBreakawayForceN);
            cylinder.pistonBreakawayVelocityMps = item["piston_breakaway_velocity_mps"].as<double>(cylinder.pistonBreakawayVelocityMps);
            cylinder.pistonViscousFrictionNsPerM = item["piston_viscous_friction_ns_per_m"].as<double>(cylinder.pistonViscousFrictionNsPerM);
            const auto rodType = item["connecting_rod_type"].as<std::string>("conventional");
            if (rodType == "conventional") cylinder.connectingRodType = ConnectingRodType::conventional;
            else if (rodType == "master") cylinder.connectingRodType = ConnectingRodType::master;
            else if (rodType == "articulated") cylinder.connectingRodType = ConnectingRodType::articulated;
            else return { std::nullopt, "Unknown connecting-rod type: " + rodType };
            cylinder.masterCylinderId = item["master_cylinder_id"].as<std::uint32_t>(0);
            cylinder.articulatedJournalRadiusMm = item["articulated_journal_radius_mm"].as<double>(0.0);
            cylinder.articulatedJournalAngleDegrees = item["articulated_journal_angle_deg"].as<double>(0.0);
            cylinder.deckHeightMm = item["deck_height_mm"].as<double>(0.0);
            cylinder.compressionHeightMm = item["compression_height_mm"].as<double>(0.0);
            cylinder.wristPinOffsetMm = item["wrist_pin_offset_mm"].as<double>(0.0);
            cylinder.pistonCrownVolumeCc = item["piston_crown_volume_cc"].as<double>(0.0);
            cylinder.headChamberVolumeCc = item["head_chamber_volume_cc"].as<double>(0.0);
            cylinder.headGasketThicknessMm = item["head_gasket_thickness_mm"].as<double>(0.0);
            cylinder.connectingRodMomentOfInertiaKgM2 = item["connecting_rod_inertia_kg_m2"].as<double>(0.0);
            cylinder.intakeValveCount = item["intake_valve_count"].as<std::uint32_t>(cylinder.intakeValveCount);
            cylinder.exhaustValveCount = item["exhaust_valve_count"].as<std::uint32_t>(cylinder.exhaustValveCount);
            cylinder.intakeValveDiameterMm = item["intake_valve_diameter_mm"].as<double>(0.0);
            cylinder.exhaustValveDiameterMm = item["exhaust_valve_diameter_mm"].as<double>(0.0);
            config.cylinders.push_back(cylinder);
        }
        normaliseEngineConfig(config);
        if (repairs != nullptr) *repairs = repairEngineConfigRanges(config);
        if (const auto error = validateEngineConfig(config)) return { std::nullopt, *error };
        return { std::move(config), {} };
    } catch (const std::exception& error) { return { std::nullopt, error.what() }; }
}
} // namespace enginelab
