#include <enginelab/gasdynamics/ExhaustGasNetwork.hpp>

#include <algorithm>
#include <bit>
#include <cmath>
#include <cstdint>
#include <limits>
#include <numbers>
#include <optional>
#if defined(_MSC_VER) && defined(_M_X64)
#include <immintrin.h>
#include <intrin.h>
#endif

namespace enginelab::gasdynamics {
namespace {

#if defined(_MSC_VER) && defined(_M_X64)
// MSVC's std::fma is a library routine (`fmal` was 1-1.4 % of a run) even on
// a processor with the instruction. A fused multiply-add is correctly rounded
// either way, so the instruction gives the same double; it is used only where
// the processor has FMA3 and the OS saves the AVX state it lives in.
const bool hardwareFusedMultiplyAdd = [] {
    int registers[4] {};
    __cpuid(registers, 1);
    const auto ecx = static_cast<unsigned>(registers[2]);
    constexpr unsigned fma3 = 1U << 12U;
    constexpr unsigned osxsave = 1U << 27U;
    constexpr unsigned avx = 1U << 28U;
    if ((ecx & (fma3 | osxsave | avx)) != (fma3 | osxsave | avx)) return false;
    return (_xgetbv(0) & 0x6U) == 0x6U;
}();

[[nodiscard]] inline double fusedMultiplyAdd(double a, double b, double c) noexcept {
    if (hardwareFusedMultiplyAdd)
        return _mm_cvtsd_f64(_mm_fmadd_sd(_mm_set_sd(a), _mm_set_sd(b), _mm_set_sd(c)));
    return std::fma(a, b, c);
}
#else
[[nodiscard]] inline double fusedMultiplyAdd(double a, double b, double c) noexcept {
    return std::fma(a, b, c);
}
#endif

[[nodiscard]] constexpr bool finite(double value) noexcept {
    static_assert(std::numeric_limits<double>::is_iec559
                  && sizeof(double) == sizeof(std::uint64_t),
        "the conservative gas solver requires IEEE-754 binary64 doubles");
    constexpr auto exponentMask = std::uint64_t { 0x7ff0000000000000ULL };
    return (std::bit_cast<std::uint64_t>(value) & exponentMask) != exponentMask;
}

[[nodiscard]] bool identicalStateBits(
    const ConservativeState& first, const ConservativeState& second) noexcept {
    for (std::size_t index = 0; index < gasSpeciesCount; ++index) {
        if (std::bit_cast<std::uint64_t>(first.speciesMassDensityKgPerM3[index])
            != std::bit_cast<std::uint64_t>(second.speciesMassDensityKgPerM3[index]))
            return false;
    }
    return std::bit_cast<std::uint64_t>(first.momentumDensityKgPerM2S)
            == std::bit_cast<std::uint64_t>(second.momentumDensityKgPerM2S)
        && std::bit_cast<std::uint64_t>(first.totalEnergyDensityJPerM3)
            == std::bit_cast<std::uint64_t>(second.totalEnergyDensityJPerM3);
}

/** Normalised modified-Arrhenius ignition delay used by the local
 * Livengood-Wu integral.
 *
 * tau = tau_ref * exp[(Ea/R)(1/T - 1/T_ref)]
 *               * (p/p_ref)^(-n) * phi^m
 *
 * Every coefficient is authored in ExhaustFuelReactionConfig. Setting Ea/R,
 * n and m to zero returns the schema-7 flat timer exactly. This routine does
 * not clamp a physical delay: overflow means no induction at that condition,
 * while underflow means the integral completes in the current coupling step.
 */
/** The rich flammability limit of a mixture at `temperatureK`: hot gas burns
 * richer than the room-temperature limit (Zabetakis' widening, see
 * `ExhaustFuelReactionConfig::richLimitWideningPerK`). */
[[nodiscard]] double richEquivalenceLimit(
    const ExhaustFuelReactionConfig& reaction, double temperatureK) noexcept {
    if (!(reaction.richLimitWideningPerK > 0.0) || !finite(temperatureK))
        return reaction.maximumEquivalenceRatio;
    return reaction.maximumEquivalenceRatio
        * (1.0 + reaction.richLimitWideningPerK * std::max(0.0, temperatureK - 298.15));
}

[[nodiscard]] double localInductionDelaySeconds(
    const ExhaustFuelReactionConfig& reaction, double ignitionSourceK,
    double pressurePa, double equivalenceRatio) noexcept {
    if (reaction.inductionActivationTemperatureK == 0.0
        && reaction.inductionPressureExponent == 0.0
        && reaction.inductionEquivalenceRatioExponent == 0.0)
        return reaction.inductionTimeSeconds;
    if (!(ignitionSourceK > 0.0) || !(pressurePa > 0.0)
        || !(equivalenceRatio > 0.0))
        return std::numeric_limits<double>::infinity();
    const auto referencePressurePa =
        reaction.inductionReferencePressureKpa * 1'000.0;
    auto logDelayScale = 0.0;
    if (reaction.inductionActivationTemperatureK != 0.0) {
        logDelayScale += reaction.inductionActivationTemperatureK
            * (1.0 / ignitionSourceK
                - 1.0 / reaction.ignitionTemperatureK);
    }
    if (reaction.inductionPressureExponent != 0.0) {
        logDelayScale -= reaction.inductionPressureExponent
            * std::log(pressurePa / referencePressurePa);
    }
    if (reaction.inductionEquivalenceRatioExponent != 0.0) {
        logDelayScale += reaction.inductionEquivalenceRatioExponent
            * std::log(equivalenceRatio);
    }
    const auto delay = reaction.inductionTimeSeconds
        * std::exp(logDelayScale);
    if (finite(delay)) return std::max(0.0, delay);
    return logDelayScale > 0.0
        ? std::numeric_limits<double>::infinity() : 0.0;
}

/**
 * Boundary state at a terminal opening discharging into open atmosphere.
 *
 * The atmosphere is a reservoir, not a neighbouring cell. Solving a Riemann
 * problem between the last duct state and a cell of ambient air makes the
 * exhaust push a semi-infinite column of cold dense gas out of the way: the
 * flux is then limited by the *ambient* acoustic impedance rho_a*c_a, which for
 * 22 degC air is larger than the hot exhaust's own. Measured on the LS3 at
 * 5990 rpm, the tailpipe sat 79 kPa above ambient while discharging at only
 * 68 m/s where a free expansion gives 699, and lightening the ambient reservoir
 * by 17x dropped that to 16 kPa -- the back pressure was the boundary, not the
 * pipe. It is wrong acoustically for the same reason: an open end must reflect
 * a compression as a rarefaction, and against a denser reservoir it reflected
 * with the sign of a closed one.
 *
 * The standard characteristic treatment instead imposes the reservoir's static
 * pressure at the exit plane and takes everything else from the outgoing
 * invariant u + 2c/(gamma-1), which is the only information the interior sends
 * to the boundary while the flow there is subsonic. Once the exit is sonic no
 * information travels upstream at all and the interior state stands unchanged.
 * Entropy and composition come from whichever side the gas actually arrives
 * from, so backflow draws air rather than re-inhaling its own exhaust.
 *
 * When the invariant says the end is DRAWING from the reservoir, the ghost
 * must not be the reservoir at rest: a Riemann flux against a RESTING
 * reservoir cell meters the inflow by the acoustic impedance rho*c, a
 * linearised small-signal law. Measured on a 250 mm intake runner at steady
 * draw, the duct had to sit 10.5 kPa below a 101.3 kPa reservoir to pull
 * 26 m/s where the isentropic (Bernoulli) entry needs 0.4 kPa — a 13 % steady
 * mass-flow deficit through the downstream valve, which is what capped every
 * engine's high-rpm breathing once the intake runners became resolved ducts.
 * Inflow matches the interior's outgoing pressure/velocity wave to gas with
 * the reservoir's stagnation conditions. Imposing the interior static pressure
 * first and deriving velocity from its entire pressure deficit gives a
 * square-root response to a small acoustic perturbation. The matching solve
 * instead has a finite acoustic admittance, while keeping the incoming gas's
 * entropy, gamma and composition distinct from the interior gas's.
 */
struct ReservoirInflowConstants final {
    double gamma;
    double soundSpeedSquared;
    double sonicVelocity;
    double stagnationExponent;
};

[[nodiscard]] ReservoirInflowConstants reservoirInflowConstants(
    const PrimitiveState& ambient) noexcept {
    const auto gamma = std::clamp(ambient.heatCapacityRatio, 1.01, 2.0);
    return { gamma,
        ambient.speedOfSoundMps * ambient.speedOfSoundMps,
        -ambient.speedOfSoundMps * std::sqrt(2.0 / (gamma + 1.0)),
        gamma / (gamma - 1.0) };
}

[[nodiscard]] std::optional<PrimitiveState> openEndBoundaryPrimitive(
    const PrimitiveState& interior, const PrimitiveState& ambient,
    std::optional<ReservoirInflowConstants>* sharedInflowConstants = nullptr) noexcept {
    const auto gamma = interior.heatCapacityRatio;
    if (!(gamma > 1.0) || !(interior.pressurePa > 0.0)
        || !(interior.densityKgPerM3 > 0.0) || !(interior.speedOfSoundMps > 0.0)
        || !(ambient.pressurePa > 0.0) || !(ambient.densityKgPerM3 > 0.0)
        || !(ambient.speedOfSoundMps > 0.0))
        return std::nullopt;
    // Sonic or supersonic outflow: the exit plane is determined entirely from
    // inside, so the interior state is already the boundary state.
    if (interior.velocityMps >= interior.speedOfSoundMps) return interior;

    PrimitiveState boundary = interior;
    boundary.pressurePa = ambient.pressurePa;
    // Isentropic along the interior's own entropy, which is what an outflowing
    // particle carries with it to the exit plane.
    boundary.densityKgPerM3 = interior.densityKgPerM3
        * std::pow(ambient.pressurePa / interior.pressurePa, 1.0 / gamma);
    if (!(boundary.densityKgPerM3 > 0.0)) return std::nullopt;
    boundary.speedOfSoundMps = std::sqrt(gamma * boundary.pressurePa
        / boundary.densityKgPerM3);
    boundary.velocityMps = interior.velocityMps
        + 2.0 * (interior.speedOfSoundMps - boundary.speedOfSoundMps) / (gamma - 1.0);
    // Backflow: the duct is drawing from the atmosphere, which is a reservoir at
    // rest. The invariant above cannot be continued across that contact -- it
    // holds only within one gamma and one entropy, and evaluating it on the hot
    // gas's sound speed while assigning it the atmosphere's produced a 2 km/s
    // outflow in the branch meant to model an inflow. Every catalogue engine but
    // one stalled on that. Each gas therefore keeps its own thermodynamics;
    // only pressure and velocity are matched across the incoming contact.
    if (boundary.velocityMps < 0.0) {
        // Every mouth in this RK stage sees the same reservoir. Prepare only
        // when one actually draws, preserving the arithmetic used by an
        // uncached opening and avoiding work for wholly outgoing stages.
        const auto constants = [&]() noexcept {
            if (!sharedInflowConstants) return reservoirInflowConstants(ambient);
            if (!*sharedInflowConstants)
                *sharedInflowConstants = reservoirInflowConstants(ambient);
            return **sharedInflowConstants;
        }();
        const auto reservoirGamma = constants.gamma;
        const auto reservoirSoundSpeedSquared = constants.soundSpeedSquared;
        const auto sonicVelocity = constants.sonicVelocity;
        const auto stagnationExponent = constants.stagnationExponent;
        const auto rarefactionExponent = (gamma - 1.0) / (2.0 * gamma);
        const auto shockA = 2.0 / ((gamma + 1.0) * interior.densityKgPerM3);
        const auto shockB = (gamma - 1.0) / (gamma + 1.0) * interior.pressurePa;
        // The left-wave curve is u_w(p)=u_i-f_i(p): a shock for compression,
        // an isentropic rarefaction for expansion. f_i'(p) is positive.
        const auto waveCurve = [&](double pressure) noexcept -> std::array<double, 2> {
            if (pressure > interior.pressurePa) {
                const auto scale = std::sqrt(shockA / (pressure + shockB));
                const auto difference = pressure - interior.pressurePa;
                return { difference * scale,
                    scale * (1.0 - 0.5 * difference / (pressure + shockB)) };
            }
            const auto powerMinusOne = std::expm1(rarefactionExponent
                * std::log1p((pressure - interior.pressurePa) / interior.pressurePa));
            return { 2.0 * interior.speedOfSoundMps / (gamma - 1.0) * powerMinusOne,
                interior.speedOfSoundMps / (gamma * pressure) * (1.0 + powerMinusOne) };
        };
        const auto zeroVelocityResidual =
            waveCurve(ambient.pressurePa)[0] - interior.velocityMps;
        if (!finite(zeroVelocityResidual)) return std::nullopt;
        // F(u)=u-u_i+f_i(p_r(u)) is strictly increasing on the subsonic
        // inflow interval: p_r'(u)>=0 and f_i'(p)>0, hence F'(u)>=1.
        // This also makes -F(0) a lower bound unless the entry is choked.
        auto lower = std::max(sonicVelocity, -std::max(0.0, zeroVelocityResidual));
        auto upper = 0.0;
        auto velocity = lower;
        const auto velocityTolerance = 1.0e-9
            * std::max(ambient.speedOfSoundMps, interior.speedOfSoundMps);
        for (std::size_t iteration = 0; iteration < 32; ++iteration) {
            const auto temperatureRatio = 1.0
                - 0.5 * (reservoirGamma - 1.0) * velocity * velocity
                    / reservoirSoundSpeedSquared;
            const auto pressure = ambient.pressurePa
                * std::pow(temperatureRatio, stagnationExponent);
            const auto wave = waveCurve(pressure);
            const auto residual = velocity - interior.velocityMps + wave[0];
            if (!finite(residual) || !finite(wave[1])) return std::nullopt;
            // No subsonic root exists if F is already positive at Mach -1.
            // The reservoir then supplies its sonic, maximum-flow state.
            if (iteration == 0 && velocity == sonicVelocity && residual >= 0.0)
                break;
            if (std::abs(residual) <= velocityTolerance
                || upper - lower <= velocityTolerance)
                break;
            if (residual < 0.0) lower = velocity;
            else upper = velocity;
            const auto pressureDerivative = -reservoirGamma * pressure * velocity
                / (reservoirSoundSpeedSquared * temperatureRatio);
            const auto derivative = 1.0 + wave[1] * pressureDerivative;
            const auto next = velocity - residual / derivative;
            velocity = finite(next) && next > lower && next < upper
                ? next : 0.5 * (lower + upper);
        }
        const auto temperatureRatio = 1.0
            - 0.5 * (reservoirGamma - 1.0) * velocity * velocity
                / reservoirSoundSpeedSquared;
        const auto pressureRatio = std::pow(temperatureRatio, stagnationExponent);
        PrimitiveState inflow = ambient;
        inflow.pressurePa = ambient.pressurePa * pressureRatio;
        inflow.densityKgPerM3 = ambient.densityKgPerM3
            * pressureRatio / temperatureRatio;
        if (!(inflow.densityKgPerM3 > 0.0)) return std::nullopt;
        inflow.temperatureK = ambient.temperatureK * temperatureRatio;
        inflow.speedOfSoundMps = ambient.speedOfSoundMps * std::sqrt(temperatureRatio);
        inflow.velocityMps = velocity;
        if (!finite(inflow.velocityMps) || !finite(inflow.speedOfSoundMps))
            return std::nullopt;
        return inflow;
    }
    if (!finite(boundary.velocityMps) || !finite(boundary.speedOfSoundMps))
        return std::nullopt;
    return boundary;
}

[[nodiscard]] ConservativeState addScaled(const ConservativeState& first,
                                           const ConservativeState& second,
                                           double scale) noexcept {
    auto result = first;
    for (std::size_t index = 0; index < gasSpeciesCount; ++index) {
        result.speciesMassDensityKgPerM3[index] +=
            second.speciesMassDensityKgPerM3[index] * scale;
    }
    result.momentumDensityKgPerM2S += second.momentumDensityKgPerM2S * scale;
    result.totalEnergyDensityJPerM3 += second.totalEnergyDensityJPerM3 * scale;
    return result;
}

/** Net mass a chamber loses through its other openings, as a fraction per
 *  second of the content it starts the advance with; zero when nothing net
 *  leaves (an inflow keeps its supplied rates). */
[[nodiscard]] double otherOutflowDrainRatePerS(
    const CylinderValveBoundary& boundary) noexcept {
    auto outflowKgPerS = 0.0;
    auto densityKgPerM3 = 0.0;
    for (std::size_t species = 0; species < gasSpeciesCount; ++species) {
        outflowKgPerS += boundary.otherOutflowSpeciesKgPerS[species];
        densityKgPerM3 += boundary.cylinderState.speciesMassDensityKgPerM3[species];
    }
    const auto massKg = densityKgPerM3 * boundary.cylinderVolumeM3;
    if (!(outflowKgPerS > 0.0) || !(massKg > 0.0) || !finite(outflowKgPerS / massKg))
        return 0.0;
    return outflowKgPerS / massKg;
}

[[nodiscard]] ConservativeState rk2Combination(
    const ConservativeState& initial,
    const ConservativeState& firstStage,
    const ConservativeState& secondResidual,
    double timeStepSeconds) noexcept {
    ConservativeState result;
    for (std::size_t index = 0; index < gasSpeciesCount; ++index) {
        result.speciesMassDensityKgPerM3[index] = 0.5
            * (initial.speciesMassDensityKgPerM3[index]
               + fusedMultiplyAdd(timeStepSeconds,
                          secondResidual.speciesMassDensityKgPerM3[index],
                          firstStage.speciesMassDensityKgPerM3[index]));
    }
    result.momentumDensityKgPerM2S = 0.5
        * (initial.momentumDensityKgPerM2S + firstStage.momentumDensityKgPerM2S
           + timeStepSeconds * secondResidual.momentumDensityKgPerM2S);
    result.totalEnergyDensityJPerM3 = 0.5
        * (initial.totalEnergyDensityJPerM3 + firstStage.totalEnergyDensityJPerM3
           + timeStepSeconds * secondResidual.totalEnergyDensityJPerM3);
    return result;
}

[[nodiscard]] EulerFlux areaAveragedBoundaryFlux(
    const EulerFlux& apertureFlux,
    double apertureAreaM2,
    double cellAreaM2,
    double cellPressurePa) noexcept {
    const auto openArea = std::clamp(apertureAreaM2, 0.0, cellAreaM2);
    const auto openFraction = cellAreaM2 > 0.0 ? openArea / cellAreaM2 : 0.0;
    EulerFlux result;
    for (std::size_t index = 0; index < gasSpeciesCount; ++index) {
        result.speciesMassFluxKgPerM2S[index] =
            apertureFlux.speciesMassFluxKgPerM2S[index] * openFraction;
    }
    // The closed part of a partially open face remains a pressure-loaded wall.
    result.momentumFluxPa = apertureFlux.momentumFluxPa * openFraction
        + cellPressurePa * (1.0 - openFraction);
    result.totalEnergyFluxWPerM2 = apertureFlux.totalEnergyFluxWPerM2 * openFraction;
    return result;
}

[[nodiscard]] double sumSpecies(
    const std::array<double, gasSpeciesCount>& species) noexcept {
    double result = 0.0;
    for (const auto value : species) result += value;
    return result;
}

/**
 * Quasi-steady flux through a compact valve aperture.
 *
 * A cylinder valve is a converging nozzle, not a zero-length continuation of
 * the runner. A plain shock-tube Riemann flux is appropriate between adjacent
 * duct cells but substantially under-predicts reservoir blowdown once the
 * pressure ratio is choked. This boundary uses the isentropic nozzle solution;
 * the separately supplied effective area already contains the measured valve
 * discharge coefficient. Species and stagnation enthalpy are transported from
 * the upstream state, so the finite cylinder reservoir and network remain one
 * conservative mass/energy system. Valve-wall reaction carries the unresolved
 * momentum, as it must for a zero-dimensional cylinder reservoir.
 */
[[nodiscard]] EulerFlux compressibleValveFlux(
    const ConservativeState& leftState,
    const PrimitiveState& left,
    const ConservativeState& rightState,
    const PrimitiveState& right) noexcept {
    EulerFlux result;
    const auto meanPressure = 0.5 * (left.pressurePa + right.pressurePa);
    result.momentumFluxPa = meanPressure;

    const auto pressureScale = std::max({ left.pressurePa, right.pressurePa, 1.0 });
    if (std::abs(left.pressurePa - right.pressurePa)
            <= pressureScale * 32.0 * std::numeric_limits<double>::epsilon())
        return result;

    const auto forward = left.pressurePa > right.pressurePa;
    const auto& upstreamState = forward ? leftState : rightState;
    const auto& upstream = forward ? left : right;
    const auto& downstream = forward ? right : left;
    const auto direction = forward ? 1.0 : -1.0;
    const auto gamma = std::clamp(upstream.heatCapacityRatio, 1.01, 2.0);
    const auto gasConstant = upstream.pressurePa
        / (upstream.densityKgPerM3 * upstream.temperatureK);
    if (!(gasConstant > 0.0) || !finite(gasConstant)) return result;

    // The selected upstream cell supplies the quasi-steady reservoir pressure
    // and temperature for this compact aperture. Cylinder momentum is zero by
    // construction; for reverse flow the transported total enthalpy below also
    // retains the runner's resolved kinetic energy.
    const auto upstreamPressurePa = upstream.pressurePa;
    const auto upstreamTemperatureK = upstream.temperatureK;
    const auto pressureRatio = std::clamp(
        downstream.pressurePa / upstreamPressurePa, 0.0, 1.0);
    const auto criticalPressureRatio = std::pow(
        2.0 / (gamma + 1.0), gamma / (gamma - 1.0));

    double massFluxMagnitude = 0.0;
    double exitPressurePa = downstream.pressurePa;
    double exitTemperatureK = upstreamTemperatureK;
    if (pressureRatio <= criticalPressureRatio) {
        const auto criticalTemperatureRatio = 2.0 / (gamma + 1.0);
        exitPressurePa = upstreamPressurePa * criticalPressureRatio;
        exitTemperatureK = upstreamTemperatureK * criticalTemperatureRatio;
        // Algebraically reuse the critical pressure ratio:
        // t^((gamma+1)/(2(gamma-1))) = t^(gamma/(gamma-1))/sqrt(t).
        // This is the exact nozzle relation with one transcendental evaluation,
        // which matters because every open valve is sampled at solver cadence.
        massFluxMagnitude = upstreamPressurePa
            / std::sqrt(gasConstant * upstreamTemperatureK)
            * std::sqrt(gamma)
            * criticalPressureRatio / std::sqrt(criticalTemperatureRatio);
    } else {
        // Let q=r^(1/gamma). Then r^(2/gamma)=q^2,
        // r^((gamma+1)/gamma)=r*q and r^((gamma-1)/gamma)=r/q.
        // One pow therefore supplies all three exact isentropic terms.
        const auto pressureRoot = std::pow(pressureRatio, 1.0 / gamma);
        const auto firstPower = pressureRoot * pressureRoot;
        const auto secondPower = pressureRatio * pressureRoot;
        massFluxMagnitude = upstreamPressurePa
            / std::sqrt(gasConstant * upstreamTemperatureK)
            * std::sqrt(std::max(0.0,
                2.0 * gamma / (gamma - 1.0) * (firstPower - secondPower)));
        exitTemperatureK = upstreamTemperatureK
            * pressureRatio / pressureRoot;
    }
    if (!(massFluxMagnitude >= 0.0) || !finite(massFluxMagnitude)
        || !(exitTemperatureK > 0.0) || !finite(exitTemperatureK))
        return result;

    const auto signedMassFlux = direction * massFluxMagnitude;
    const auto upstreamDensity = upstream.densityKgPerM3;
    for (std::size_t species = 0; species < gasSpeciesCount; ++species) {
        result.speciesMassFluxKgPerM2S[species] = signedMassFlux
            * upstreamState.speciesMassDensityKgPerM3[species]
            / upstreamDensity;
    }
    const auto totalSpecificEnthalpy =
        (upstreamState.totalEnergyDensityJPerM3 + upstream.pressurePa)
        / upstreamDensity;
    result.totalEnergyFluxWPerM2 = signedMassFlux * totalSpecificEnthalpy;

    const auto exitDensity = exitPressurePa / (gasConstant * exitTemperatureK);
    const auto exitVelocityMagnitude = exitDensity > 0.0
        ? massFluxMagnitude / exitDensity : 0.0;
    // rho*u^2 is positive in either direction. Pressure is evaluated at the
    // nozzle exit (critical section if choked, downstream static pressure if not).
    result.momentumFluxPa = exitPressurePa
        + massFluxMagnitude * exitVelocityMagnitude;
    return result;
}

/** Isentropic nozzle mass flux per unit throat area, choked below the
 * critical pressure ratio. */
[[nodiscard]] double nozzleMassFlux(double stagnationPressurePa,
                                    double stagnationTemperatureK,
                                    double gasConstant, double gamma,
                                    double criticalPressureRatio,
                                    double downstreamPressurePa) noexcept {
    const auto ratio = std::clamp(downstreamPressurePa / stagnationPressurePa,
        criticalPressureRatio, 1.0);
    const auto root = std::pow(ratio, 1.0 / gamma);
    return stagnationPressurePa / std::sqrt(gasConstant * stagnationTemperatureK)
        * std::sqrt(std::max(0.0,
            2.0 * gamma / (gamma - 1.0) * (root * root - ratio * root)));
}

/**
 * Flux through a throttle plate between two duct ends, per unit open area,
 * positive from the left duct (whose outlet meets the plate) to the right.
 *
 * The gas approaching the plate keeps its kinetic energy: the orifice is fed
 * by the approaching cell's stagnation state, not its static state, so a
 * plate open to the full bore passes the duct's own flow without a loss. The
 * loss is the jet re-expanding into the receiving duct, which the caller
 * carries by loading the closed part of each face with that cell's pressure
 * (Borda-Carnot). The flow runs from the side whose stagnation pressure
 * exceeds the other's static pressure by more.
 */
[[nodiscard]] EulerFlux restrictionOrificeFlux(
    const ConservativeState& leftState,
    const PrimitiveState& left,
    const ConservativeState& rightState,
    const PrimitiveState& right) noexcept {
    EulerFlux result;
    result.momentumFluxPa = 0.5 * (left.pressurePa + right.pressurePa);
    struct Stagnation final { double pressurePa; double temperatureK; };
    const auto stagnation = [](const PrimitiveState& state,
                               double towardPlateMps) noexcept {
        const auto gamma = std::clamp(state.heatCapacityRatio, 1.01, 2.0);
        const auto mach = state.speedOfSoundMps > 0.0
            ? std::max(0.0, towardPlateMps) / state.speedOfSoundMps : 0.0;
        const auto ratio = 1.0 + 0.5 * (gamma - 1.0) * mach * mach;
        return Stagnation { state.pressurePa * std::pow(ratio, gamma / (gamma - 1.0)),
                            state.temperatureK * ratio };
    };
    // The left duct's outlet faces the plate along +x, the right duct's inlet
    // along -x.
    const auto leftTotal = stagnation(left, left.velocityMps);
    const auto rightTotal = stagnation(right, -right.velocityMps);
    const auto forwardDrivePa = leftTotal.pressurePa - right.pressurePa;
    const auto reverseDrivePa = rightTotal.pressurePa - left.pressurePa;
    if (!(forwardDrivePa > 0.0) && !(reverseDrivePa > 0.0)) return result;
    const auto forward = forwardDrivePa >= reverseDrivePa;
    const auto& upstreamState = forward ? leftState : rightState;
    const auto& upstream = forward ? left : right;
    const auto& downstream = forward ? right : left;
    const auto& total = forward ? leftTotal : rightTotal;
    const auto gamma = std::clamp(upstream.heatCapacityRatio, 1.01, 2.0);
    const auto gasConstant = upstream.pressurePa
        / (upstream.densityKgPerM3 * upstream.temperatureK);
    if (!(gasConstant > 0.0) || !finite(gasConstant)
        || !(total.pressurePa > 0.0) || !(total.temperatureK > 0.0))
        return result;
    const auto criticalPressureRatio = std::pow(
        2.0 / (gamma + 1.0), gamma / (gamma - 1.0));
    const auto massFluxMagnitude = nozzleMassFlux(total.pressurePa,
        total.temperatureK, gasConstant, gamma, criticalPressureRatio,
        downstream.pressurePa);
    // The throat: the receiving pressure, or the critical one when choked.
    const auto exitPressurePa = std::max(downstream.pressurePa,
        total.pressurePa * criticalPressureRatio);
    const auto exitTemperatureK = total.temperatureK
        * std::pow(exitPressurePa / total.pressurePa, (gamma - 1.0) / gamma);
    const auto exitDensity = exitPressurePa / (gasConstant * exitTemperatureK);
    if (!(massFluxMagnitude >= 0.0) || !finite(massFluxMagnitude)
        || !(exitDensity > 0.0) || !finite(exitDensity))
        return result;

    const auto signedMassFlux = (forward ? 1.0 : -1.0) * massFluxMagnitude;
    const auto upstreamDensity = upstream.densityKgPerM3;
    for (std::size_t species = 0; species < gasSpeciesCount; ++species)
        result.speciesMassFluxKgPerM2S[species] = signedMassFlux
            * upstreamState.speciesMassDensityKgPerM3[species] / upstreamDensity;
    result.totalEnergyFluxWPerM2 = signedMassFlux
        * (upstreamState.totalEnergyDensityJPerM3 + upstream.pressurePa)
        / upstreamDensity;
    // rho*u^2 is positive in either direction.
    result.momentumFluxPa = exitPressurePa
        + massFluxMagnitude * massFluxMagnitude / exitDensity;
    return result;
}

/** Isentropic enthalpy drop, J/kg, from the stagnation state of gas
 * approaching a face at `towardFaceMps` down to `outletPressurePa`: what a
 * turbine wheel of unit total-to-static efficiency would take from it. */
[[nodiscard]] double isentropicExpansionWorkJPerKg(const PrimitiveState& inlet,
                                                   double towardFaceMps,
                                                   double outletPressurePa) noexcept {
    const auto gamma = std::clamp(inlet.heatCapacityRatio, 1.01, 2.0);
    const auto gasConstant = inlet.pressurePa
        / (inlet.densityKgPerM3 * inlet.temperatureK);
    if (!(gasConstant > 0.0) || !finite(gasConstant)) return 0.0;
    const auto mach = inlet.speedOfSoundMps > 0.0
        ? std::max(0.0, towardFaceMps) / inlet.speedOfSoundMps : 0.0;
    const auto ratio = 1.0 + 0.5 * (gamma - 1.0) * mach * mach;
    const auto exponent = (gamma - 1.0) / gamma;
    const auto stagnationTemperatureK = inlet.temperatureK * ratio;
    // (p_out / p0)^((g-1)/g) = (p_out / p)^((g-1)/g) / ratio.
    const auto expansion = std::pow(
        std::max(0.0, outletPressurePa) / inlet.pressurePa, exponent) / ratio;
    const auto work = gasConstant * stagnationTemperatureK / exponent
        * (1.0 - std::min(1.0, expansion));
    return finite(work) ? work : 0.0;
}

/** Root of a monotone function on [low, high], or the end it tends to when
 * the root lies outside. Secant steps from `guess` (the previous solution, or
 * the middle) and `slope` (the previous secant slope, in/out), each value
 * narrowing the bracket by its sign alone, so neither end is ever evaluated;
 * a step leaving the bracket bisects instead. */
template <class Residual>
[[nodiscard]] double monotoneRoot(Residual&& residual, double low, double high,
                                  bool increasing, double guess, double& slope,
                                  double tolerance) noexcept {
    auto point = finite(guess) && guess > low && guess < high ? guess : 0.5 * (low + high);
    auto value = residual(point);
    if (!finite(value)) return point;
    const auto narrow = [&](double at, double result) noexcept {
        if ((result > 0.0) == increasing) high = at;
        else low = at;
    };
    narrow(point, value);
    // The previous slope, or else a probe toward the root, starts the secant.
    auto previous = point;
    auto previousValue = value;
    const auto newton = point - value / slope;
    point = finite(newton) && (slope > 0.0) == increasing && newton > low && newton < high
        ? newton
        : std::clamp(point + ((value > 0.0) == increasing ? -1.0 : 1.0)
            * std::max(tolerance, 1.0e-4 * (high - low)), low, high);
    if (point == previous) return point;
    for (std::size_t iteration = 0; iteration < 40; ++iteration) {
        value = residual(point);
        if (!finite(value)) return previous;
        if (value == 0.0) return point;
        narrow(point, value);
        if (value != previousValue) slope = (value - previousValue) / (point - previous);
        auto next = point - value / slope;
        if (!finite(next) || !(next > low) || !(next < high)) next = 0.5 * (low + high);
        if (std::abs(next - point) <= tolerance || high - low <= tolerance)
            return std::clamp(next, low, high);
        previous = point;
        previousValue = value;
        point = next;
    }
    return point;
}

/**
 * Characteristic (Benson-type) valve boundary at a duct-inlet face.
 *
 * compressibleValveFlux meters the nozzle against the first cell's average.
 * Its square-root law has an unbounded small-signal admittance as the
 * pressure difference vanishes, while the duct can only answer through a wave
 * of admittance A/c: an explicit step overshoots, and the intake charge
 * depended on the step (K20 at 3500 rpm: -21.6 % torque at Courant 0.8,
 * converged only below about 0.27).
 *
 * Here the face state lies on the wave curve the interior cell can reach, and
 * the valve closes the problem. Outflow (duct to cylinder) expands the face
 * stagnation state through the valve to the cylinder pressure. Inflow
 * (cylinder to duct) is a jet from the cylinder at rest whose throat sits at
 * the face static pressure; it keeps its stagnation enthalpy but loses
 * stagnation pressure in the sudden expansion to the face area. A closing
 * valve tends to the reflecting wall. The flux is per unit FACE area along +x
 * (into the duct). Nullopt for a state outside this model's reach.
 *
 * `faceSolve`, when given, holds this valve's last face pressure and residual
 * slope: the solve starts there (4.3 residual evaluations on average against
 * 8.4 from the bracket ends) and leaves its own result for the next one.
 */
[[nodiscard]] std::optional<EulerFlux> characteristicInletValveFlux(
    const ConservativeState& cylinderState, const PrimitiveState& cylinder,
    const ConservativeState& interiorState, const PrimitiveState& interior,
    double valveAreaM2, double faceAreaM2,
    const EulerMixtureModel& model, double* faceSolve) noexcept {
    const auto gamma = std::clamp(interior.heatCapacityRatio, 1.01, 2.0);
    const auto interiorPressure = interior.pressurePa;
    const auto interiorSound = interior.speedOfSoundMps;
    const auto cylinderPressure = cylinder.pressurePa;
    if (!(faceAreaM2 > 0.0) || !(interiorPressure > 0.0)
        || !(interior.densityKgPerM3 > 0.0) || !(interior.temperatureK > 0.0)
        || !(interiorSound > 0.0) || !(cylinderPressure > 0.0)
        || !(cylinder.densityKgPerM3 > 0.0) || !(cylinder.temperatureK > 0.0))
        return std::nullopt;
    const auto areaRatio = std::clamp(valveAreaM2 / faceAreaM2, 0.0, 1.0);
    // Velocity toward the valve, which sits on the -x side of the face.
    const auto towardValve = -interior.velocityMps;
    if (!(towardValve < interiorSound)) return std::nullopt;
    const auto rarefactionExponent = (gamma - 1.0) / (2.0 * gamma);
    const auto shockA = 2.0 / ((gamma + 1.0) * interior.densityKgPerM3);
    const auto shockB = (gamma - 1.0) / (gamma + 1.0) * interiorPressure;
    // Right-facing wave from the interior: velocity toward the valve and
    // density at face pressure p (shock above the interior pressure,
    // isentropic rarefaction below).
    const auto faceVelocity = [&](double pressure) noexcept {
        if (pressure > interiorPressure)
            return towardValve - (pressure - interiorPressure)
                * std::sqrt(shockA / (pressure + shockB));
        return towardValve - 2.0 * interiorSound / (gamma - 1.0)
            * std::expm1(rarefactionExponent * std::log(pressure / interiorPressure));
    };
    const auto faceDensity = [&](double pressure) noexcept {
        const auto ratio = pressure / interiorPressure;
        if (ratio > 1.0) {
            const auto beta = (gamma - 1.0) / (gamma + 1.0);
            return interior.densityKgPerM3 * (ratio + beta) / (beta * ratio + 1.0);
        }
        return interior.densityKgPerM3 * std::pow(ratio, 1.0 / gamma);
    };
    // The face pressure that stops the gas: the reflecting-wall pressure.
    double wallPressure = interiorPressure;
    if (towardValve > 0.0) {
        const auto squared = towardValve * towardValve;
        wallPressure += (squared + std::sqrt(squared * squared
            + 4.0 * shockA * squared * (interiorPressure + shockB))) / (2.0 * shockA);
    } else {
        const auto base = 1.0 + 0.5 * (gamma - 1.0) * towardValve / interiorSound;
        if (!(base > 0.0)) return std::nullopt;
        wallPressure *= std::pow(base, 1.0 / rarefactionExponent);
    }
    if (!finite(wallPressure) || !(wallPressure > 0.0)) return std::nullopt;
    const auto tolerance = 1.0e-6 * std::max(wallPressure, cylinderPressure);
    const auto guess = faceSolve ? faceSolve[0] : std::numeric_limits<double>::quiet_NaN();
    auto slope = faceSolve ? faceSolve[1] : std::numeric_limits<double>::quiet_NaN();

    EulerFlux result;
    if (wallPressure > cylinderPressure) {
        // Duct to cylinder. The face carries the interior gas.
        const auto gasConstant = interiorPressure
            / (interior.densityKgPerM3 * interior.temperatureK);
        const auto heatCapacity = gamma * gasConstant / (gamma - 1.0);
        const auto critical = std::pow(2.0 / (gamma + 1.0), gamma / (gamma - 1.0));
        const auto residual = [&](double pressure) noexcept {
            const auto velocity = faceVelocity(pressure);
            const auto density = faceDensity(pressure);
            const auto temperature = pressure / (density * gasConstant);
            const auto stagnationTemperature = temperature
                + 0.5 * velocity * velocity / heatCapacity;
            const auto stagnationPressure = pressure * std::pow(
                stagnationTemperature / temperature, gamma / (gamma - 1.0));
            return density * velocity - areaRatio * nozzleMassFlux(
                stagnationPressure, stagnationTemperature, gasConstant, gamma,
                critical, cylinderPressure);
        };
        // A face cannot pass the sonic point of its own rarefaction; the
        // valve, never larger than the face, chokes first.
        const auto sonicSound = (gamma - 1.0) / (gamma + 1.0)
            * (towardValve + 2.0 * interiorSound / (gamma - 1.0));
        const auto low = std::max(cylinderPressure, interiorPressure
            * std::pow(sonicSound / interiorSound, 1.0 / rarefactionExponent));
        auto pressure = wallPressure;
        if (areaRatio > 0.0 && low < wallPressure)
            pressure = monotoneRoot(residual, low, wallPressure, false, guess, slope,
                tolerance);
        if (faceSolve) {
            faceSolve[0] = pressure;
            faceSolve[1] = slope;
        }
        const auto density = faceDensity(pressure);
        const auto velocity = -faceVelocity(pressure);
        const auto face = model.conservativeFromPrimitive(density, velocity, pressure,
            GasComposition { interior.massFractions });
        if (!face) return std::nullopt;
        const auto massFlux = density * velocity;
        for (std::size_t species = 0; species < gasSpeciesCount; ++species)
            result.speciesMassFluxKgPerM2S[species] = massFlux
                * interiorState.speciesMassDensityKgPerM3[species]
                / interior.densityKgPerM3;
        result.momentumFluxPa = pressure + massFlux * velocity;
        result.totalEnergyFluxWPerM2 = massFlux
            * (face->totalEnergyDensityJPerM3 + pressure) / density;
    } else {
        // Cylinder to duct. The face carries the cylinder gas.
        const auto cylinderGamma = std::clamp(cylinder.heatCapacityRatio, 1.01, 2.0);
        const auto gasConstant = cylinderPressure
            / (cylinder.densityKgPerM3 * cylinder.temperatureK);
        const auto heatCapacity = cylinderGamma * gasConstant / (cylinderGamma - 1.0);
        const auto critical = std::pow(2.0 / (cylinderGamma + 1.0),
            cylinderGamma / (cylinderGamma - 1.0));
        const auto faceState = [&](double pressure) noexcept {
            const auto velocity = -faceVelocity(pressure);
            const auto temperature = std::max(cylinder.temperatureK
                - 0.5 * velocity * velocity / heatCapacity, 0.05 * cylinder.temperatureK);
            return std::array<double, 2> { pressure / (gasConstant * temperature), velocity };
        };
        const auto residual = [&](double pressure) noexcept {
            const auto [density, velocity] = faceState(pressure);
            return density * velocity - areaRatio * nozzleMassFlux(
                cylinderPressure, cylinder.temperatureK, gasConstant, cylinderGamma,
                critical, pressure);
        };
        auto pressure = wallPressure;
        if (areaRatio > 0.0 && wallPressure < cylinderPressure)
            pressure = monotoneRoot(residual, wallPressure, cylinderPressure, true,
                guess, slope, tolerance);
        if (faceSolve) {
            faceSolve[0] = pressure;
            faceSolve[1] = slope;
        }
        const auto [density, velocity] = faceState(pressure);
        const auto massFlux = density * velocity;
        for (std::size_t species = 0; species < gasSpeciesCount; ++species)
            result.speciesMassFluxKgPerM2S[species] = massFlux
                * cylinderState.speciesMassDensityKgPerM3[species]
                / cylinder.densityKgPerM3;
        result.momentumFluxPa = pressure + massFlux * velocity;
        result.totalEnergyFluxWPerM2 = massFlux
            * (cylinderState.totalEnergyDensityJPerM3 + cylinderPressure)
            / cylinder.densityKgPerM3;
    }
    if (!finite(result.momentumFluxPa) || !finite(result.totalEnergyFluxWPerM2))
        return std::nullopt;
    return result;
}

/** Valve area `elapsedSeconds` into an advance; see CylinderValveBoundary. */
[[nodiscard]] double suppliedValveAreaM2(const CylinderValveBoundary& boundary,
                                         double elapsedSeconds) noexcept {
    if (elapsedSeconds >= boundary.valveClosesAfterSeconds
        || elapsedSeconds < boundary.valveOpensAfterSeconds) return 0.0;
    return std::max(0.0, boundary.effectiveValveAreaM2
        + boundary.effectiveValveAreaRateM2PerS
            * (elapsedSeconds - boundary.valveOpensAfterSeconds));
}

[[nodiscard]] bool validMovingBoundary(const CylinderValveBoundary& boundary) noexcept {
    return std::isfinite(boundary.cylinderVolumeRateM3PerS)
        && std::isfinite(boundary.effectiveValveAreaRateM2PerS)
        && std::isfinite(boundary.valveOpensAfterSeconds)
        && !std::isnan(boundary.valveClosesAfterSeconds);
}

} // namespace

bool ExhaustGasNetworkConfig::valid() const noexcept {
    return finite(initialPressurePa) && initialPressurePa > 0.0
        && finite(initialTemperatureK) && initialTemperatureK > 0.0
        && finite(absoluteRoughnessM) && absoluteRoughnessM >= 0.0
        && finite(wallHeatTransferWPerM2K) && wallHeatTransferWPerM2K >= 0.0
        && finite(wallTemperatureK) && wallTemperatureK > 0.0
        && (!dynamicWallHeatTransferEnabled || wallHeatTransferWPerM2K == 0.0)
        && finite(wallThicknessM) && wallThicknessM > 0.0
        && finite(wallDensityKgPerM3) && wallDensityKgPerM3 > 0.0
        && finite(wallSpecificHeatJPerKgK) && wallSpecificHeatJPerKgK > 0.0
        && finite(externalWallHeatTransferWPerM2K)
        && externalWallHeatTransferWPerM2K >= 0.0
        && finite(externalTemperatureK) && externalTemperatureK > 0.0
        && finite(maximumCourantNumber) && maximumCourantNumber > 0.0
        && maximumCourantNumber <= 1.0 && maximumSubstepsPerAdvance > 0;
}

double CylinderGasExchange::totalMassKg() const noexcept {
    return sumSpecies(speciesMassKg);
}

ExhaustGasNetwork::ExhaustGasNetwork(ThermodynamicModel model) noexcept
    : mixtureModel_(model) {}

bool ExhaustGasNetwork::configure(const ExhaustNetworkLayout& layout,
                                  ExhaustGasNetworkConfig config) {
    configured_ = false;
    if (!layout.valid() || !config.valid()) return false;
    const auto initialState = mixtureModel_.conservativeFromPressureTemperature(
        config.initialPressurePa, config.initialTemperatureK, 0.0,
        config.initialComposition);
    if (!initialState) return false;

    layout_ = layout;
    config_ = config;
    ducts_.clear();
    ducts_.reserve(layout_.ducts().size());
    for (const auto& descriptor : layout_.ducts()) {
        DuctGeometry geometry;
        geometry.lengthM = descriptor.lengthM;
        geometry.crossSectionAreaM2 = descriptor.flowAreaM2;
        geometry.inletCrossSectionAreaM2 = descriptor.inletFlowAreaM2;
        geometry.outletCrossSectionAreaM2 = descriptor.outletFlowAreaM2;
        geometry.diameterM = descriptor.hydraulicDiameterM;
        geometry.cellCount = descriptor.cellCount;
        geometry.wallFrictionEnabled = true;
        geometry.absoluteRoughnessM = config.absoluteRoughnessM;
        geometry.localLossCoefficient = descriptor.lossCoefficient;
        geometry.wallHeatTransferWPerM2K = config.wallHeatTransferWPerM2K;
        geometry.wallTemperatureK = config.wallTemperatureK;
        geometry.dynamicWallHeatTransferEnabled =
            config.dynamicWallHeatTransferEnabled;
        geometry.wallThicknessM = config.wallThicknessM;
        geometry.wallDensityKgPerM3 = config.wallDensityKgPerM3;
        geometry.wallSpecificHeatJPerKgK = config.wallSpecificHeatJPerKgK;
        geometry.externalWallHeatTransferWPerM2K =
            config.externalWallHeatTransferWPerM2K;
        geometry.externalTemperatureK = config.externalTemperatureK;
        geometry.wallHeatUpdateIntervalSeconds =
            config.wallHeatUpdateIntervalSeconds;
        geometry.homogenisedCellularSubstrate =
            descriptor.homogenisedCatalystMonolith;
        geometry.cellularSubstrateOpenAreaRatio =
            descriptor.catalystOpenAreaRatio;
        geometry.cellularSubstrateVolumetricHeatCapacityJPerM3K =
            descriptor.catalystSubstrateVolumetricHeatCapacityJPerM3K;
        ducts_.emplace_back(mixtureModel_.thermodynamics());
        if (!ducts_.back().configure(geometry, *initialState)) {
            ducts_.clear();
            return false;
        }
    }

    junctionStates_.assign(layout_.junctions().size(), *initialState);
    for (auto& state : junctionStates_) state.momentumDensityKgPerM2S = 0.0;
    junctionStage_.resize(junctionStates_.size());
    junctionCandidate_.resize(junctionStates_.size());
    junctionResidual_.resize(junctionStates_.size());
    junctionStageResidual_.resize(junctionStates_.size());
    const auto initialPrimitive = mixtureModel_.primitiveFromConservative(*initialState);
    if (!initialPrimitive) return false;
    junctionPrimitives_.assign(junctionStates_.size(), *initialPrimitive);
    junctionStagePrimitives_.resize(junctionStates_.size());
    junctionCandidatePrimitives_.resize(junctionStates_.size());
    junctionPortAreaSums_.assign(junctionStates_.size(), 0.0);
    cylinderReservoirStates_.resize(layout_.cylinderPorts().size());
    cylinderReservoirStage_.resize(layout_.cylinderPorts().size());
    cylinderReservoirCandidate_.resize(layout_.cylinderPorts().size());
    cylinderReservoirResidual_.resize(layout_.cylinderPorts().size());
    cylinderReservoirStageResidual_.resize(layout_.cylinderPorts().size());
    cylinderReservoirPrimitives_.resize(layout_.cylinderPorts().size());
    cylinderReservoirStagePrimitives_.resize(layout_.cylinderPorts().size());
    cylinderReservoirCandidatePrimitives_.resize(layout_.cylinderPorts().size());
    cylinderReservoirVolumesM3_.resize(layout_.cylinderPorts().size());
    cylinderReservoirInitialVolumesM3_.resize(layout_.cylinderPorts().size());
    cylinderReservoirActive_.resize(layout_.cylinderPorts().size());
    cylinderReservoirClosed_.resize(layout_.cylinderPorts().size());
    cylinderBoundaryIndices_.resize(layout_.cylinderPorts().size());

    const auto endpointArea = [this](const ExhaustEndpoint& endpoint) noexcept {
        if (endpoint.type == ExhaustEndpointType::junction) {
            const auto diameter = layout_.junctions()[endpoint.elementIndex]
                .characteristicDiameterM;
            return 0.25 * std::acos(-1.0) * diameter * diameter;
        }
        const auto& duct = layout_.ducts()[endpoint.elementIndex];
        return endpoint.type == ExhaustEndpointType::ductInlet
            ? std::min(duct.inletConnectionAreaM2, duct.inletFlowAreaM2)
            : std::min(duct.outletConnectionAreaM2, duct.outletFlowAreaM2);
    };
    interfaceOpeningAreasM2_.clear();
    interfaceFaceAreasM2_.clear();
    interfaceTurbines_.assign(layout_.interfaces().size(), {});
    interfaceFirstStageRate_.assign(layout_.interfaces().size(), {});
    interfaceSecondStageRate_.assign(layout_.interfaces().size(), {});
    interfaceTransfers_.assign(layout_.interfaces().size(), {});
    for (const auto& connection : layout_.interfaces()) {
        const auto area = std::min(endpointArea(connection.upstream),
                                   endpointArea(connection.downstream));
        interfaceOpeningAreasM2_.push_back(area);
        interfaceFaceAreasM2_.push_back(area);
        if (connection.upstream.type == ExhaustEndpointType::junction)
            junctionPortAreaSums_[connection.upstream.elementIndex] += area;
        if (connection.downstream.type == ExhaustEndpointType::junction)
            junctionPortAreaSums_[connection.downstream.elementIndex] += area;
    }
    for (const auto& port : layout_.cylinderPorts()) {
        if (port.networkEndpoint.type == ExhaustEndpointType::junction) {
            junctionPortAreaSums_[port.networkEndpoint.elementIndex] +=
                std::min(port.runnerConnectionAreaM2, endpointArea(port.networkEndpoint));
        }
    }
    for (const auto& outlet : layout_.outlets()) {
        if (outlet.networkEndpoint.type == ExhaustEndpointType::junction) {
            junctionPortAreaSums_[outlet.networkEndpoint.elementIndex] +=
                std::min(outlet.openingAreaM2, endpointArea(outlet.networkEndpoint));
        }
    }

    // Every duct face must have exactly one physical owner. This is checked
    // once here so the realtime stage evaluator never has to resolve topology.
    std::vector<std::size_t> inletOwners(ducts_.size(), 0);
    std::vector<std::size_t> outletOwners(ducts_.size(), 0);
    const auto countEndpoint = [&inletOwners, &outletOwners](
        const ExhaustEndpoint& endpoint) noexcept {
        if (endpoint.type == ExhaustEndpointType::ductInlet)
            ++inletOwners[endpoint.elementIndex];
        else if (endpoint.type == ExhaustEndpointType::ductOutlet)
            ++outletOwners[endpoint.elementIndex];
    };
    for (const auto& connection : layout_.interfaces()) {
        countEndpoint(connection.upstream);
        countEndpoint(connection.downstream);
    }
    for (const auto& port : layout_.cylinderPorts()) countEndpoint(port.networkEndpoint);
    for (const auto& outlet : layout_.outlets()) countEndpoint(outlet.networkEndpoint);
    if (!std::all_of(inletOwners.begin(), inletOwners.end(),
            [](std::size_t count) { return count == 1; })
        || !std::all_of(outletOwners.begin(), outletOwners.end(),
            [](std::size_t count) { return count == 1; })) {
        ducts_.clear();
        return false;
    }

    ductInletAssigned_.resize(ducts_.size());
    ductOutletAssigned_.resize(ducts_.size());
    ductSucceeded_.assign(ducts_.size(), std::uint8_t { 1 });
    // Reserved here so that building the chunks inside a noexcept stage never
    // allocates.
    ductChunkBegin_.clear();
    ductChunkBegin_.reserve(ducts_.size() + 1);
    ductStageRejected_.assign(ducts_.size(), std::uint8_t { 0 });
    ductWallHeatRejectedJ_.assign(ducts_.size(), 0.0);
    portFluxes_.assign(layout_.cylinderPorts().size(), BoundaryFlux {});
    outletFluxes_.assign(layout_.outlets().size(), BoundaryFlux {});
    ductPorts_.assign(ducts_.size(), {});
    ductOutlets_.assign(ducts_.size(), {});
    for (std::size_t index = 0; index < layout_.cylinderPorts().size(); ++index) {
        const auto& endpoint = layout_.cylinderPorts()[index].networkEndpoint;
        if (endpoint.type != ExhaustEndpointType::junction)
            ductPorts_[endpoint.elementIndex].push_back(index);
    }
    for (std::size_t index = 0; index < layout_.outlets().size(); ++index) {
        const auto& endpoint = layout_.outlets()[index].networkEndpoint;
        if (endpoint.type != ExhaustEndpointType::junction)
            ductOutlets_[endpoint.elementIndex].push_back(index);
    }
    interfaceFluxes_.assign(layout_.interfaces().size(), InterfaceFlux {});
    interfaceOwnerDuct_.assign(layout_.interfaces().size(), noInterfaceOwner);
    ductInterfaces_.assign(ducts_.size(), {});
    for (std::size_t index = 0; index < layout_.interfaces().size(); ++index) {
        const auto& connection = layout_.interfaces()[index];
        if (connection.restriction) continue;
        const auto& owner = connection.upstream.type != ExhaustEndpointType::junction
            ? connection.upstream : connection.downstream;
        if (owner.type == ExhaustEndpointType::junction) continue;
        interfaceOwnerDuct_[index] = owner.elementIndex;
        ductInterfaces_[owner.elementIndex].push_back(index);
    }
    for (auto& duct : ducts_) duct.thirdOrderReconstruction_ = config_.thirdOrderReconstruction;
    interfaceReconstructed_.assign(layout_.interfaces().size(), std::uint8_t { 0 });
    ductEndNeighbour_.assign(2 * ducts_.size(), std::nullopt);
    ductEndGhost_.assign(2 * ducts_.size(), ConservativeState {});
    if (config_.reconstructAcrossInterfaces) {
        const auto endSlot = [](const ExhaustEndpoint& endpoint) noexcept {
            return 2 * endpoint.elementIndex
                + (endpoint.type == ExhaustEndpointType::ductInlet ? 0 : 1);
        };
        for (std::size_t index = 0; index < layout_.interfaces().size(); ++index) {
            const auto& connection = layout_.interfaces()[index];
            if (connection.restriction
                || connection.upstream.type == ExhaustEndpointType::junction
                || connection.downstream.type == ExhaustEndpointType::junction)
                continue;
            interfaceReconstructed_[index] = 1;
            ductEndNeighbour_[endSlot(connection.upstream)] = connection.downstream;
            ductEndNeighbour_[endSlot(connection.downstream)] = connection.upstream;
        }
    }
    valveInterfaces_ = exhaustValveInterfaces(layout_);
    interfaceValveThrottled_.assign(layout_.interfaces().size(), std::uint8_t { 0 });
    interfaceValveAreasM2_.assign(layout_.interfaces().size(), 0.0);
    valveOpening_ = 1.0;
    valveThrottled_ = false;
    cylinderFirstStageFlow_.resize(layout_.cylinderPorts().size());
    cylinderSecondStageFlow_.resize(layout_.cylinderPorts().size());
    outletFirstStageFlow_.resize(layout_.outlets().size());
    outletSecondStageFlow_.resize(layout_.outlets().size());
    cylinderExchanges_.resize(layout_.cylinderPorts().size());
    valveFaceSolve_.assign(layout_.cylinderPorts().size(),
        { std::numeric_limits<double>::quiet_NaN(), std::numeric_limits<double>::quiet_NaN() });
    for (std::size_t index = 0; index < cylinderExchanges_.size(); ++index) {
        cylinderExchanges_[index].cylinderId = layout_.cylinderPorts()[index].cylinderId;
        cylinderExchanges_[index].pathIndex = layout_.cylinderPorts()[index].pathIndex;
    }
    outletSamples_.resize(layout_.outlets().size());
    for (std::size_t index = 0; index < outletSamples_.size(); ++index) {
        outletSamples_[index].outletNodeId = layout_.outlets()[index].outletNodeId;
        outletSamples_[index].pathIndex = layout_.outlets()[index].pathIndex;
        outletSamples_[index].openingAreaM2 = layout_.outlets()[index].openingAreaM2;
    }
    ductReactionStates_.clear();
    ductReactionStates_.reserve(ducts_.size());
    for (const auto& duct : ducts_)
        ductReactionStates_.emplace_back(duct.cells_.size());
    junctionReactionStates_.assign(junctionStates_.size(), {});
    unburnedPockets_.fill(UnburnedPocket {});
    configured_ = true;
    return true;
}

bool ExhaustGasNetwork::reset(double pressurePa,
                              double temperatureK,
                              GasComposition composition) noexcept {
    if (!configured_) return false;
    const auto initialState = mixtureModel_.conservativeFromPressureTemperature(
        pressurePa, temperatureK, 0.0, composition);
    if (!initialState) return false;
    const auto initialPrimitive = mixtureModel_.primitiveFromConservative(*initialState);
    if (!initialPrimitive) return false;

    config_.initialPressurePa = pressurePa;
    config_.initialTemperatureK = temperatureK;
    config_.initialComposition = composition;
    for (auto& duct : ducts_) {
        auto cells = duct.cells();
        std::fill(cells.begin(), cells.end(), *initialState);
        duct.resetWallTemperature(temperatureK);
        if (!duct.refreshCellStateCache()) return false;
    }
    for (auto& sites : ductReactionStates_)
        std::fill(sites.begin(), sites.end(), ReactionSiteState {});
    std::fill(junctionReactionStates_.begin(),
              junctionReactionStates_.end(), ReactionSiteState {});
    unburnedPockets_.fill(UnburnedPocket {});
    wallHeatPendingSeconds_ = 0.0;
    std::fill(junctionStates_.begin(), junctionStates_.end(), *initialState);
    for (auto& state : junctionStates_) state.momentumDensityKgPerM2S = 0.0;
    std::fill(junctionPrimitives_.begin(), junctionPrimitives_.end(), *initialPrimitive);
    std::fill(cylinderReservoirStates_.begin(), cylinderReservoirStates_.end(),
              ConservativeState {});
    std::fill(cylinderReservoirVolumesM3_.begin(), cylinderReservoirVolumesM3_.end(), 0.0);
    std::fill(cylinderReservoirActive_.begin(), cylinderReservoirActive_.end(),
              std::uint8_t { 0 });
    for (std::size_t index = 0; index < cylinderExchanges_.size(); ++index) {
        cylinderExchanges_[index] = {};
        cylinderExchanges_[index].cylinderId = layout_.cylinderPorts()[index].cylinderId;
        cylinderExchanges_[index].pathIndex = layout_.cylinderPorts()[index].pathIndex;
    }
    for (std::size_t index = 0; index < outletSamples_.size(); ++index) {
        outletSamples_[index] = {};
        outletSamples_[index].outletNodeId = layout_.outlets()[index].outletNodeId;
        outletSamples_[index].pathIndex = layout_.outlets()[index].pathIndex;
        outletSamples_[index].openingAreaM2 = layout_.outlets()[index].openingAreaM2;
    }
    std::fill(interfaceTransfers_.begin(), interfaceTransfers_.end(), InterfaceTransfer {});
    updateOutletSamples(0.0);
    return true;
}

namespace {

/** Share of new cell `to` (of `toCount`) covered by old cell `from` (of
 * `fromCount`), both meshes spanning the same normalised length. */
[[nodiscard]] double remapOverlap(std::size_t from, std::size_t fromCount,
                                  std::size_t to, std::size_t toCount) noexcept {
    const auto fromStart = static_cast<double>(from) / static_cast<double>(fromCount);
    const auto fromEnd = static_cast<double>(from + 1U) / static_cast<double>(fromCount);
    const auto toStart = static_cast<double>(to) / static_cast<double>(toCount);
    const auto toEnd = static_cast<double>(to + 1U) / static_cast<double>(toCount);
    return std::max(0.0, std::min(fromEnd, toEnd) - std::max(fromStart, toStart))
        * static_cast<double>(toCount);
}

/** The same share, by volume, of a duct whose radius runs linearly from its
 * inlet to its outlet: a taper's cells hold the gas of their frustum, so an
 * overlap weighted by its length alone moved inventory across the remap
 * (audit PG-05). A uniform duct keeps the length weight, its exact value. */
[[nodiscard]] double remapOverlapWeight(std::size_t from, std::size_t fromCount,
                                        std::size_t to, std::size_t toCount,
                                        const DuctGeometry& geometry) noexcept {
    const auto length = remapOverlap(from, fromCount, to, toCount);
    if (!(length > 0.0) || !geometry.hasVariableArea()) return length;
    const auto start = std::max(static_cast<double>(from) / static_cast<double>(fromCount),
                                static_cast<double>(to) / static_cast<double>(toCount));
    const auto end = std::min(static_cast<double>(from + 1U) / static_cast<double>(fromCount),
                              static_cast<double>(to + 1U) / static_cast<double>(toCount));
    const auto inletRadius = std::sqrt(geometry.inletAreaM2() / std::numbers::pi);
    const auto outletRadius = std::sqrt(geometry.outletAreaM2() / std::numbers::pi);
    const auto startRadius = std::lerp(inletRadius, outletRadius, start);
    const auto endRadius = std::lerp(inletRadius, outletRadius, end);
    // A frustum's mean area, (r0^2 + r0 r1 + r1^2) / 3 times pi.
    const auto meanArea = std::numbers::pi
        * (startRadius * startRadius + startRadius * endRadius + endRadius * endRadius) / 3.0;
    return length * meanArea;
}

} // namespace

bool ExhaustGasNetwork::adoptStateFrom(const ExhaustGasNetwork& previous) noexcept {
    if (!configured_ || !previous.configured_
        || !layout_.sameTopology(previous.layout_)
        || valveFaceSolve_.size() != previous.valveFaceSolve_.size()
        || ducts_.size() != previous.ducts_.size()
        || junctionStates_.size() != previous.junctionStates_.size()
        || cylinderReservoirStates_.size() != previous.cylinderReservoirStates_.size())
        return false;

    // Remap into the candidate buffers first so a refused state leaves the
    // network untouched.
    for (std::size_t ductIndex = 0; ductIndex < ducts_.size(); ++ductIndex) {
        auto& duct = ducts_[ductIndex];
        const auto& source = previous.ducts_[ductIndex];
        const auto fromCount = source.cells_.size();
        const auto toCount = duct.cells_.size();
        if (fromCount == 0 || toCount == 0 || duct.candidate_.size() != toCount
            || duct.candidateWallStates_.size() != duct.wallStates_.size()
            || source.wallStates_.size() != fromCount
            || duct.wallStates_.size() != toCount)
            return false;
        for (std::size_t to = 0; to < toCount; ++to) {
            if (fromCount == toCount) {
                duct.candidate_[to] = source.cells_[to];
                duct.candidateWallStates_[to] = source.wallStates_[to];
            } else {
                ConservativeState state {};
                auto wallTemperatureK = 0.0;
                auto weightSum = 0.0;
                auto wallWeightSum = 0.0;
                for (std::size_t from = 0; from < fromCount; ++from) {
                    const auto wallWeight = remapOverlap(from, fromCount, to, toCount);
                    if (wallWeight <= 0.0) continue;
                    const auto weight = remapOverlapWeight(from, fromCount, to, toCount,
                                                           duct.geometry_);
                    const auto& cell = source.cells_[from];
                    for (std::size_t species = 0; species < gasSpeciesCount; ++species)
                        state.speciesMassDensityKgPerM3[species] +=
                            weight * cell.speciesMassDensityKgPerM3[species];
                    state.momentumDensityKgPerM2S += weight * cell.momentumDensityKgPerM2S;
                    state.totalEnergyDensityJPerM3 += weight * cell.totalEnergyDensityJPerM3;
                    wallTemperatureK += wallWeight * source.wallStates_[from].temperatureK;
                    weightSum += weight;
                    wallWeightSum += wallWeight;
                }
                if (!(weightSum > 0.0) || !(wallWeightSum > 0.0)) return false;
                for (auto& species : state.speciesMassDensityKgPerM3) species /= weightSum;
                state.momentumDensityKgPerM2S /= weightSum;
                state.totalEnergyDensityJPerM3 /= weightSum;
                duct.candidate_[to] = state;
                duct.candidateWallStates_[to].temperatureK = wallTemperatureK / wallWeightSum;
            }
            if (!mixtureModel_.isPhysical(duct.candidate_[to])) return false;
        }
    }
    for (std::size_t index = 0; index < junctionStates_.size(); ++index) {
        const auto primitive = mixtureModel_.primitiveFromConservative(
            previous.junctionStates_[index]);
        if (!primitive) return false;
        junctionCandidatePrimitives_[index] = *primitive;
    }

    for (std::size_t ductIndex = 0; ductIndex < ducts_.size(); ++ductIndex) {
        auto& duct = ducts_[ductIndex];
        const auto& source = previous.ducts_[ductIndex];
        auto cells = duct.cells();
        std::copy(duct.candidate_.begin(), duct.candidate_.end(), cells.begin());
        std::copy(duct.candidateWallStates_.begin(), duct.candidateWallStates_.end(),
                  duct.wallStates_.begin());
        duct.wallHeatPendingSeconds_ = source.wallHeatPendingSeconds_;
        auto& sites = ductReactionStates_[ductIndex];
        const auto& sourceSites = previous.ductReactionStates_[ductIndex];
        for (std::size_t to = 0; to < sites.size(); ++to) {
            const auto from = std::min(sourceSites.size() - 1U,
                static_cast<std::size_t>((static_cast<double>(to) + 0.5)
                    * static_cast<double>(sourceSites.size())
                    / static_cast<double>(sites.size())));
            sites[to] = sourceSites[from];
        }
        if (!duct.refreshCellStateCache()) return false;
    }
    std::copy(previous.junctionStates_.begin(), previous.junctionStates_.end(),
              junctionStates_.begin());
    std::copy(junctionCandidatePrimitives_.begin(), junctionCandidatePrimitives_.end(),
              junctionPrimitives_.begin());
    std::copy(previous.junctionReactionStates_.begin(),
              previous.junctionReactionStates_.end(), junctionReactionStates_.begin());
    // Same ducts, another mesh: a pocket's position is in metres.
    unburnedPockets_ = previous.unburnedPockets_;
    std::copy(previous.cylinderReservoirStates_.begin(),
              previous.cylinderReservoirStates_.end(), cylinderReservoirStates_.begin());
    std::copy(previous.cylinderReservoirPrimitives_.begin(),
              previous.cylinderReservoirPrimitives_.end(),
              cylinderReservoirPrimitives_.begin());
    std::copy(previous.cylinderReservoirVolumesM3_.begin(),
              previous.cylinderReservoirVolumesM3_.end(),
              cylinderReservoirVolumesM3_.begin());
    std::copy(previous.cylinderReservoirActive_.begin(),
              previous.cylinderReservoirActive_.end(), cylinderReservoirActive_.begin());
    std::copy(previous.cylinderExchanges_.begin(), previous.cylinderExchanges_.end(),
              cylinderExchanges_.begin());
    std::copy(previous.valveFaceSolve_.begin(), previous.valveFaceSolve_.end(),
              valveFaceSolve_.begin());
    for (std::size_t index = 0; index < outletSamples_.size(); ++index) {
        outletSamples_[index] = previous.outletSamples_[index];
        outletSamples_[index].openingAreaM2 = layout_.outlets()[index].openingAreaM2;
    }
    wallHeatPendingSeconds_ = previous.wallHeatPendingSeconds_;
    wallHeatUpdateRequested_ = previous.wallHeatUpdateRequested_;
    // A plate keeps its opening, within the new bore, and a turbine its wheel.
    for (std::size_t index = 0; index < layout_.interfaces().size(); ++index)
        if (layout_.interfaces()[index].restriction)
            static_cast<void>(setRestrictionOpeningAreaM2(
                index, previous.interfaceOpeningAreasM2_[index]));
    interfaceTurbines_ = previous.interfaceTurbines_;
    interfaceTransfers_ = previous.interfaceTransfers_;
    static_cast<void>(setExhaustValveOpening(previous.valveOpening_));
    return true;
}

bool ExhaustGasNetwork::setExhaustValveOpening(double openFraction) noexcept {
    if (!std::isfinite(openFraction)) return false;
    valveOpening_ = std::clamp(openFraction, 0.0, 1.0);
    valveThrottled_ = !valveInterfaces_.empty() && valveOpening_ < 1.0;
    const auto endSlot = [](const ExhaustEndpoint& endpoint) noexcept {
        return 2 * endpoint.elementIndex
            + (endpoint.type == ExhaustEndpointType::ductInlet ? 0 : 1);
    };
    for (const auto index : valveInterfaces_) {
        const auto& connection = layout_.interfaces()[index];
        interfaceValveThrottled_[index] = valveThrottled_ ? 1 : 0;
        interfaceValveAreasM2_[index] = valveOpening_ * interfaceOpeningAreasM2_[index];
        // Shut, the two sides no longer see each other's cells.
        if (interfaceReconstructed_[index] != 0) {
            ductEndNeighbour_[endSlot(connection.upstream)] = valveThrottled_
                ? std::nullopt : std::optional<ExhaustEndpoint>(connection.downstream);
            ductEndNeighbour_[endSlot(connection.downstream)] = valveThrottled_
                ? std::nullopt : std::optional<ExhaustEndpoint>(connection.upstream);
        }
    }
    return true;
}

bool ExhaustGasNetwork::setRestrictionTurbine(std::size_t interfaceIndex,
                                              double wheelShare,
                                              double efficiency) noexcept {
    if (interfaceIndex >= layout_.interfaces().size()
        || interfaceIndex >= interfaceTurbines_.size()
        || !layout_.interfaces()[interfaceIndex].restriction
        || !std::isfinite(wheelShare) || !std::isfinite(efficiency))
        return false;
    interfaceTurbines_[interfaceIndex] = {
        std::clamp(wheelShare, 0.0, 1.0), std::clamp(efficiency, 0.0, 1.0) };
    return true;
}

bool ExhaustGasNetwork::setRestrictionOpeningAreaM2(std::size_t interfaceIndex,
                                                    double areaM2) noexcept {
    if (interfaceIndex >= layout_.interfaces().size()
        || interfaceIndex >= interfaceOpeningAreasM2_.size()
        || !std::isfinite(areaM2))
        return false;
    const auto& connection = layout_.interfaces()[interfaceIndex];
    if (!connection.restriction) return false;
    const auto faceAreaM2 = [this](const ExhaustEndpoint& endpoint) noexcept {
        if (endpoint.type == ExhaustEndpointType::junction) {
            const auto diameter = layout_.junctions()[endpoint.elementIndex]
                .characteristicDiameterM;
            return 0.25 * std::acos(-1.0) * diameter * diameter;
        }
        const auto& duct = layout_.ducts()[endpoint.elementIndex];
        return endpoint.type == ExhaustEndpointType::ductInlet
            ? std::min(duct.inletConnectionAreaM2, duct.inletFlowAreaM2)
            : std::min(duct.outletConnectionAreaM2, duct.outletFlowAreaM2);
    };
    interfaceOpeningAreasM2_[interfaceIndex] = std::clamp(areaM2, 0.0,
        std::min(faceAreaM2(connection.upstream), faceAreaM2(connection.downstream)));
    return true;
}

bool ExhaustGasNetwork::settleAtRest(double pressurePa) noexcept {
    if (!configured_) return false;
    const auto settled = [this, pressurePa](const ConservativeState& state)
        -> std::optional<ConservativeState> {
        const auto primitive = mixtureModel_.primitiveFromConservative(state);
        if (!primitive) return std::nullopt;
        return mixtureModel_.conservativeFromPressureTemperature(
            pressurePa, primitive->temperatureK, 0.0, { primitive->massFractions });
    };
    // Into the candidate buffers first, so a refused state changes nothing.
    for (auto& duct : ducts_) {
        if (duct.candidate_.size() != duct.cells_.size()) return false;
        for (std::size_t index = 0; index < duct.cells_.size(); ++index) {
            const auto state = settled(duct.cells_[index]);
            if (!state) return false;
            duct.candidate_[index] = *state;
        }
    }
    for (std::size_t index = 0; index < junctionStates_.size(); ++index) {
        const auto state = settled(junctionStates_[index]);
        if (!state) return false;
        const auto primitive = mixtureModel_.primitiveFromConservative(*state);
        if (!primitive) return false;
        junctionCandidate_[index] = *state;
        junctionCandidatePrimitives_[index] = *primitive;
    }
    for (auto& duct : ducts_) {
        auto cells = duct.cells();
        std::copy(duct.candidate_.begin(), duct.candidate_.end(), cells.begin());
        if (!duct.refreshCellStateCache()) return false;
    }
    std::copy(junctionCandidate_.begin(), junctionCandidate_.end(), junctionStates_.begin());
    std::copy(junctionCandidatePrimitives_.begin(), junctionCandidatePrimitives_.end(),
              junctionPrimitives_.begin());
    return true;
}

ExhaustNetworkInventory ExhaustGasNetwork::inventory() const noexcept {
    ExhaustNetworkInventory result;
    for (const auto& duct : ducts_) {
        const auto ductInventory = duct.inventory();
        for (std::size_t index = 0; index < gasSpeciesCount; ++index)
            result.speciesMassKg[index] += ductInventory.speciesMassKg[index];
        result.totalEnergyJ += ductInventory.totalEnergyJ;
        result.resolvedAxialMomentumKgMps += ductInventory.axialMomentumKgMps;
        result.wallThermalEnergyJ += duct.wallThermalEnergyJ();
    }
    for (std::size_t index = 0; index < junctionStates_.size(); ++index) {
        const auto volume = layout_.junctions()[index].volumeM3;
        for (std::size_t species = 0; species < gasSpeciesCount; ++species) {
            result.speciesMassKg[species] +=
                junctionStates_[index].speciesMassDensityKgPerM3[species] * volume;
        }
        result.totalEnergyJ += junctionStates_[index].totalEnergyDensityJPerM3 * volume;
        result.resolvedAxialMomentumKgMps +=
            junctionStates_[index].momentumDensityKgPerM2S * volume;
    }
    return result;
}

double ExhaustGasNetwork::peakWallTemperatureK() const noexcept {
    auto peak = 0.0;
    for (const auto& duct : ducts_)
        for (const auto& wall : duct.wallStates_)
            peak = std::max(peak, wall.temperatureK);
    return peak;
}

void ExhaustGasNetwork::markUpstreamOfTurbine(std::vector<std::uint8_t> ducts,
                                              std::vector<std::uint8_t> junctions) {
    ductUpstreamOfTurbine_ = std::move(ducts);
    junctionUpstreamOfTurbine_ = std::move(junctions);
}

ExhaustFuelReactionResult ExhaustGasNetwork::reactUnburnedFuel(
    double durationSeconds,
    const ExhaustFuelReactionConfig& reaction) noexcept {
    ExhaustFuelReactionResult result;
    if (!configured_ || !(durationSeconds > 0.0)
        || !finite(durationSeconds)
        || !(reaction.ignitionTemperatureK > 0.0)
        || !(reaction.reactionTimeConstantSeconds > 0.0)
        || !(reaction.reactionEfficiency > 0.0)
        || !(reaction.oxygenMolesPerFuelMole > 0.0)
        || !(reaction.fuelMolarMassKg > 0.0)
        || !(reaction.lowerHeatingValueJPerKg > 0.0)
        || !(reaction.inductionTimeSeconds > 0.0)
        || !finite(reaction.inductionTimeSeconds)
        || !(reaction.inductionReferencePressureKpa > 0.0)
        || !finite(reaction.inductionReferencePressureKpa)
        || !(reaction.inductionActivationTemperatureK >= 0.0)
        || !finite(reaction.inductionActivationTemperatureK)
        || !(reaction.inductionPressureExponent >= 0.0)
        || !finite(reaction.inductionPressureExponent)
        || !finite(reaction.inductionEquivalenceRatioExponent)
        || !(reaction.inductionDecayTimeSeconds > 0.0)
        || !finite(reaction.inductionDecayTimeSeconds)
        || !(reaction.minimumEquivalenceRatio > 0.0)
        || !(reaction.maximumEquivalenceRatio
            > reaction.minimumEquivalenceRatio)
        || !(reaction.richLimitWideningPerK >= 0.0)
        || !finite(reaction.richLimitWideningPerK)
        || !(reaction.quenchTemperatureK > 0.0))
        return result;

    const auto oxygen = static_cast<std::size_t>(GasSpecies::oxygen);
    const auto fuel = static_cast<std::size_t>(GasSpecies::fuel);
    const auto burned = static_cast<std::size_t>(GasSpecies::burned);
    const auto oxygenMassPerFuelMass =
        reaction.oxygenMolesPerFuelMole * 0.032
        / reaction.fuelMolarMassKg;
    const auto efficiency = std::clamp(reaction.reactionEfficiency, 0.0, 1.0);

    struct ReactionAggregate final {
        double energyJ { 0.0 };
        double fuelKg { 0.0 };
        double energyWeightedAxial { 0.0 };
        double energyWeightedDensity { 0.0 };
        double energyWeightedSoundSpeed { 0.0 };
    };
    const auto appendSource = [&](const ReactionAggregate& aggregate,
                                  std::uint32_t nodeId,
                                  std::uint32_t sourceComponentId,
                                  std::uint32_t pathIndex,
                                  double flowAreaM2) noexcept {
        if (!(aggregate.energyJ > 0.0)) return;
        if (result.sourceCount >= result.sources.size()) {
            ++result.droppedSourceCount;
            return;
        }
        auto& source = result.sources[result.sourceCount++];
        source.nodeId = nodeId;
        source.sourceComponentId = sourceComponentId;
        source.pathIndex = pathIndex;
        source.axialPosition = std::clamp(
            aggregate.energyWeightedAxial / aggregate.energyJ, 0.0, 1.0);
        source.releasedEnergyJoules = aggregate.energyJ;
        source.burnedFuelMassKg = aggregate.fuelKg;
        source.durationSeconds = durationSeconds;
        source.densityKgPerM3 = aggregate.energyWeightedDensity
            / aggregate.energyJ;
        source.speedOfSoundMps = aggregate.energyWeightedSoundSpeed
            / aggregate.energyJ;
        source.flowAreaM2 = flowAreaM2;
    };

    // Local induction and flame state persist across coupling calls. Fuel and
    // oxygen may therefore convect through cold cells without globally reacting
    // the instant any temperature threshold is crossed. The dimensionless
    // Livengood-Wu integral advances by dt/tau(T,p,phi); once a kernel is
    // established it burns its local inventory until it is depleted, becomes
    // non-flammable or is genuinely quenched.
    const auto reactState = [&](ConservativeState& state, double volumeM3,
                                double wallTemperatureK,
                                ReactionSiteState& site,
                                double axialPosition,
                                ReactionAggregate& aggregate) noexcept {
        const auto primitive = mixtureModel_.primitiveFromConservative(state);
        if (!primitive || !(volumeM3 > 0.0)) return false;
        const auto ignitionSourceK =
            std::max(primitive->temperatureK, wallTemperatureK);
        const auto fuelDensity = state.speciesMassDensityKgPerM3[fuel];
        const auto oxygenDensity = state.speciesMassDensityKgPerM3[oxygen];
        const auto equivalenceRatio = oxygenDensity > 0.0
            ? fuelDensity * oxygenMassPerFuelMass / oxygenDensity
            : std::numeric_limits<double>::infinity();
        const auto flammable = fuelDensity > 0.0 && oxygenDensity > 0.0
            && equivalenceRatio >= reaction.minimumEquivalenceRatio
            && equivalenceRatio <= richEquivalenceLimit(reaction, primitive->temperatureK);
        const auto ignitionCondition =
            ignitionSourceK >= reaction.ignitionTemperatureK;
        if (!site.burning && flammable && ignitionCondition) {
            const auto localDelaySeconds = localInductionDelaySeconds(
                reaction, ignitionSourceK, primitive->pressurePa,
                equivalenceRatio);
            if (localDelaySeconds > 0.0 && finite(localDelaySeconds)
                && (result.minimumInductionDelaySeconds == 0.0
                    || localDelaySeconds
                        < result.minimumInductionDelaySeconds)) {
                result.minimumInductionDelaySeconds = localDelaySeconds;
            }
            if (localDelaySeconds > 0.0 && finite(localDelaySeconds)) {
                result.maximumInductionDelaySeconds = std::max(
                    result.maximumInductionDelaySeconds, localDelaySeconds);
            }
            const auto inductionIncrement = localDelaySeconds > 0.0
                ? (finite(localDelaySeconds)
                    ? durationSeconds / localDelaySeconds : 0.0)
                : 1.0;
            site.inductionIntegral = std::min(
                1.0, site.inductionIntegral + inductionIncrement);
            if (site.inductionIntegral >= 1.0) {
                site.burning = true;
                site.wallIgnited = primitive->temperatureK
                        < reaction.ignitionTemperatureK
                    && wallTemperatureK >= reaction.ignitionTemperatureK;
            }
        } else if (!site.burning) {
            site.inductionIntegral = std::max(0.0,
                site.inductionIntegral - durationSeconds
                    / reaction.inductionDecayTimeSeconds);
        }
        if (!flammable
            || ignitionSourceK < reaction.quenchTemperatureK) {
            site.burning = false;
            site.wallIgnited = false;
            if (!flammable) site.inductionIntegral = 0.0;
            result.maximumInductionIntegral = std::max(
                result.maximumInductionIntegral, site.inductionIntegral);
            return false;
        }
        result.maximumInductionIntegral = std::max(
            result.maximumInductionIntegral, site.inductionIntegral);
        if (!site.burning) return false;
        const auto reactedFraction = efficiency * (1.0 - std::exp(
            -durationSeconds / reaction.reactionTimeConstantSeconds));
        const auto stoichiometricFuelDensity =
            oxygenDensity / oxygenMassPerFuelMass;
        const auto consumedFuelDensity = std::min(
            fuelDensity, stoichiometricFuelDensity) * reactedFraction;
        if (!(consumedFuelDensity > 0.0)) return false;
        const auto consumedOxygenDensity =
            consumedFuelDensity * oxygenMassPerFuelMass;
        auto candidate = state;
        candidate.speciesMassDensityKgPerM3[fuel] -= consumedFuelDensity;
        candidate.speciesMassDensityKgPerM3[oxygen] -= consumedOxygenDensity;
        candidate.speciesMassDensityKgPerM3[burned] +=
            consumedFuelDensity + consumedOxygenDensity;
        const auto releasedEnergyDensity = consumedFuelDensity
            * reaction.lowerHeatingValueJPerKg;
        candidate.totalEnergyDensityJPerM3 += releasedEnergyDensity;
        if (!mixtureModel_.primitiveFromConservative(candidate)) return false;
        state = candidate;
        result.burnedFuelMassKg += consumedFuelDensity * volumeM3;
        result.consumedOxygenMassKg += consumedOxygenDensity * volumeM3;
        result.releasedEnergyJoules += releasedEnergyDensity * volumeM3;
        ++result.reactingControlVolumes;
        if (site.wallIgnited) ++result.wallIgnitedControlVolumes;
        const auto releasedEnergyJ = releasedEnergyDensity * volumeM3;
        aggregate.energyJ += releasedEnergyJ;
        aggregate.fuelKg += consumedFuelDensity * volumeM3;
        aggregate.energyWeightedAxial += releasedEnergyJ * axialPosition;
        aggregate.energyWeightedDensity += releasedEnergyJ
            * primitive->densityKgPerM3;
        aggregate.energyWeightedSoundSpeed += releasedEnergyJ
            * primitive->speedOfSoundMps;
        if (candidate.speciesMassDensityKgPerM3[fuel] <= 1.0e-12
            || candidate.speciesMassDensityKgPerM3[oxygen] <= 1.0e-12) {
            site.burning = false;
            site.inductionIntegral = 0.0;
            site.wallIgnited = false;
        }
        return true;
    };

    // A pocket warms towards its host cell, lights from its own temperature
    // or from a burning host, and then burns at the reaction time constant
    // whatever the host's mean mixture: the fuel and oxygen it burns are the
    // host's own, so a pocket whose fuel the cells no longer hold has nothing
    // to burn and ends.
    const auto pocketsEnabled = reaction.pocketMixingTimeSeconds > 0.0
        && finite(reaction.pocketMixingTimeSeconds);
    const auto reactPocket = [&](UnburnedPocket& pocket,
                                 ConservativeState& host, double hostVolumeM3,
                                 bool hostBurning, double axialPosition,
                                 ReactionAggregate& aggregate) noexcept {
        const auto primitive = mixtureModel_.primitiveFromConservative(host);
        if (!primitive || !(hostVolumeM3 > 0.0)) return false;
        pocket.temperatureK += (primitive->temperatureK - pocket.temperatureK)
            * (1.0 - std::exp(-durationSeconds
                / reaction.pocketMixingTimeSeconds));
        pocket.ageSeconds += durationSeconds;
        const auto equivalenceRatio = pocket.oxygenKg > 0.0
            ? pocket.fuelKg * oxygenMassPerFuelMass / pocket.oxygenKg
            : std::numeric_limits<double>::infinity();
        if (!(pocket.fuelKg > 0.0)
            || equivalenceRatio < reaction.minimumEquivalenceRatio
            || equivalenceRatio > richEquivalenceLimit(reaction, pocket.temperatureK)) {
            pocket.active = false;
            return false;
        }
        if (!pocket.burning && hostBurning) {
            pocket.burning = true;
        } else if (!pocket.burning
                   && pocket.temperatureK >= reaction.ignitionTemperatureK) {
            const auto delaySeconds = localInductionDelaySeconds(reaction,
                pocket.temperatureK, primitive->pressurePa, equivalenceRatio);
            pocket.inductionIntegral += delaySeconds > 0.0
                ? (finite(delaySeconds) ? durationSeconds / delaySeconds : 0.0)
                : 1.0;
            pocket.burning = pocket.inductionIntegral >= 1.0;
        }
        if (!pocket.burning) {
            if (pocket.ageSeconds > 3.0 * reaction.pocketMixingTimeSeconds)
                pocket.active = false;
            return false;
        }
        const auto hostFuelKg =
            host.speciesMassDensityKgPerM3[fuel] * hostVolumeM3;
        const auto hostOxygenKg =
            host.speciesMassDensityKgPerM3[oxygen] * hostVolumeM3;
        const auto consumedFuelKg = std::min({
            pocket.fuelKg * efficiency * (1.0 - std::exp(
                -durationSeconds / reaction.reactionTimeConstantSeconds)),
            hostFuelKg, hostOxygenKg / oxygenMassPerFuelMass });
        if (!(consumedFuelKg > 1.0e-15)) {
            pocket.active = false;
            return false;
        }
        const auto consumedOxygenKg = consumedFuelKg * oxygenMassPerFuelMass;
        const auto releasedEnergyJ =
            consumedFuelKg * reaction.lowerHeatingValueJPerKg;
        auto candidate = host;
        candidate.speciesMassDensityKgPerM3[fuel] -=
            consumedFuelKg / hostVolumeM3;
        candidate.speciesMassDensityKgPerM3[oxygen] -=
            consumedOxygenKg / hostVolumeM3;
        candidate.speciesMassDensityKgPerM3[burned] +=
            (consumedFuelKg + consumedOxygenKg) / hostVolumeM3;
        candidate.totalEnergyDensityJPerM3 += releasedEnergyJ / hostVolumeM3;
        if (!mixtureModel_.primitiveFromConservative(candidate)) return false;
        host = candidate;
        pocket.fuelKg -= consumedFuelKg;
        pocket.oxygenKg = std::max(0.0, pocket.oxygenKg - consumedOxygenKg);
        if (pocket.fuelKg <= 1.0e-12) pocket.active = false;
        result.burnedFuelMassKg += consumedFuelKg;
        result.consumedOxygenMassKg += consumedOxygenKg;
        result.releasedEnergyJoules += releasedEnergyJ;
        aggregate.energyJ += releasedEnergyJ;
        aggregate.fuelKg += consumedFuelKg;
        aggregate.energyWeightedAxial += releasedEnergyJ * axialPosition;
        aggregate.energyWeightedDensity += releasedEnergyJ
            * primitive->densityKgPerM3;
        aggregate.energyWeightedSoundSpeed += releasedEnergyJ
            * primitive->speedOfSoundMps;
        return true;
    };

    for (std::size_t ductIndex = 0; ductIndex < ducts_.size(); ++ductIndex) {
        auto& duct = ducts_[ductIndex];
        ReactionAggregate aggregate;
        auto reacted = false;
        const auto& layoutDuct = layout_.ducts()[ductIndex];
        for (std::size_t index = 0; index < duct.cells_.size(); ++index) {
            const auto wallTemperatureK = index < duct.wallStates_.size()
                ? duct.wallStates_[index].temperatureK : 0.0;
            reacted = reactState(duct.cells_[index],
                duct.cellVolumesM3_[index], wallTemperatureK,
                ductReactionStates_[ductIndex][index],
                (static_cast<double>(index) + 0.5)
                    / static_cast<double>(duct.cells_.size()),
                aggregate) || reacted;
        }
        for (auto& pocket : unburnedPockets_) {
            if (!pocketsEnabled || !pocket.active || pocket.inJunction
                || pocket.elementIndex != ductIndex || duct.cells_.empty())
                continue;
            const auto cell = pocketCellIndex(pocket, layoutDuct.lengthM,
                duct.cells_.size());
            reacted = reactPocket(pocket, duct.cells_[cell],
                duct.cellVolumesM3_[cell],
                ductReactionStates_[ductIndex][cell].burning,
                (static_cast<double>(cell) + 0.5)
                    / static_cast<double>(duct.cells_.size()),
                aggregate) || reacted;
        }
        if (reacted) duct.cellStateCacheIsValid_ = false;
        if (ductIndex < ductUpstreamOfTurbine_.size() && ductUpstreamOfTurbine_[ductIndex] != 0U)
            result.burnedFuelBeforeTurbineMassKg += aggregate.fuelKg;
        appendSource(aggregate, layoutDuct.nodeId,
            layoutDuct.sourceComponentId, layoutDuct.pathIndex,
            layoutDuct.flowAreaM2);
    }
    for (std::size_t index = 0; index < junctionStates_.size(); ++index) {
        ReactionAggregate aggregate;
        auto reacted = reactState(junctionStates_[index],
            layout_.junctions()[index].volumeM3, 0.0,
            junctionReactionStates_[index], 0.5, aggregate);
        for (auto& pocket : unburnedPockets_) {
            if (!pocketsEnabled || !pocket.active || !pocket.inJunction
                || pocket.elementIndex != index)
                continue;
            reacted = reactPocket(pocket, junctionStates_[index],
                layout_.junctions()[index].volumeM3,
                junctionReactionStates_[index].burning, 0.5, aggregate)
                || reacted;
        }
        if (!reacted) continue;
        if (index < junctionUpstreamOfTurbine_.size() && junctionUpstreamOfTurbine_[index] != 0U)
            result.burnedFuelBeforeTurbineMassKg += aggregate.fuelKg;
        const auto primitive = mixtureModel_.primitiveFromConservative(
            junctionStates_[index]);
        if (primitive) junctionPrimitives_[index] = *primitive;
        const auto& junction = layout_.junctions()[index];
        const auto flowAreaM2 = 0.25 * std::numbers::pi
            * junction.characteristicDiameterM
            * junction.characteristicDiameterM;
        appendSource(aggregate, junction.nodeId,
            junction.sourceComponentId, junction.pathIndex, flowAreaM2);
    }
    if (pocketsEnabled)
        for (auto& pocket : unburnedPockets_)
            if (pocket.active) carryPocket(pocket, durationSeconds);
    return result;
}

std::size_t ExhaustGasNetwork::pocketCellIndex(const UnburnedPocket& pocket,
                                               double ductLengthM,
                                               std::size_t cellCount) noexcept {
    if (cellCount == 0 || !(ductLengthM > 0.0)) return 0;
    const auto cell = static_cast<std::size_t>(std::max(0.0,
        pocket.positionM / ductLengthM * static_cast<double>(cellCount)));
    return std::min(cell, cellCount - 1);
}

void ExhaustGasNetwork::carryPocket(UnburnedPocket& pocket,
                                    double durationSeconds) noexcept {
    const auto interfaces = layout_.interfaces();
    const auto matches = [](const ExhaustEndpoint& endpoint,
                            ExhaustEndpointType type, std::size_t index) {
        return endpoint.type == type && endpoint.elementIndex == index;
    };
    // A junction is well mixed: a pocket leaves it by its first outgoing duct
    // on the next call.
    if (pocket.inJunction) {
        for (const auto& face : interfaces) {
            if (!matches(face.upstream, ExhaustEndpointType::junction,
                    pocket.elementIndex)
                || face.downstream.type != ExhaustEndpointType::ductInlet)
                continue;
            pocket.inJunction = false;
            pocket.elementIndex = face.downstream.elementIndex;
            pocket.positionM = 0.0;
            return;
        }
        pocket.active = false;
        return;
    }
    if (pocket.elementIndex >= ducts_.size()) {
        pocket.active = false;
        return;
    }
    const auto& duct = ducts_[pocket.elementIndex];
    const auto lengthM = layout_.ducts()[pocket.elementIndex].lengthM;
    if (duct.cells_.empty() || !(lengthM > 0.0)) {
        pocket.active = false;
        return;
    }
    const auto primitive = mixtureModel_.primitiveFromConservative(
        duct.cells_[pocketCellIndex(pocket, lengthM, duct.cells_.size())]);
    if (!primitive) return;
    pocket.positionM += primitive->velocityMps * durationSeconds;
    // One element per call: the coupling interval moves gas a few cells.
    if (pocket.positionM > lengthM) {
        for (const auto& face : interfaces) {
            if (!matches(face.upstream, ExhaustEndpointType::ductOutlet,
                    pocket.elementIndex))
                continue;
            if (face.downstream.type == ExhaustEndpointType::junction) {
                pocket.inJunction = true;
                pocket.elementIndex = face.downstream.elementIndex;
            } else if (face.downstream.type == ExhaustEndpointType::ductInlet
                       && face.downstream.elementIndex < ducts_.size()) {
                pocket.positionM = std::min(pocket.positionM - lengthM,
                    layout_.ducts()[face.downstream.elementIndex].lengthM);
                pocket.elementIndex = face.downstream.elementIndex;
            }
            return;
        }
        // Out of the tailpipe.
        pocket.active = false;
    } else if (pocket.positionM < 0.0) {
        for (const auto& face : interfaces) {
            if (!matches(face.downstream, ExhaustEndpointType::ductInlet,
                    pocket.elementIndex))
                continue;
            if (face.upstream.type == ExhaustEndpointType::junction) {
                pocket.inJunction = true;
                pocket.elementIndex = face.upstream.elementIndex;
            } else if (face.upstream.type == ExhaustEndpointType::ductOutlet
                       && face.upstream.elementIndex < ducts_.size()) {
                const auto upstreamLengthM =
                    layout_.ducts()[face.upstream.elementIndex].lengthM;
                pocket.positionM = std::max(0.0,
                    upstreamLengthM + pocket.positionM);
                pocket.elementIndex = face.upstream.elementIndex;
            }
            return;
        }
        // Pushed back against the valve it came from.
        pocket.positionM = 0.0;
    }
}

bool ExhaustGasNetwork::emitUnburnedPocket(
    std::uint32_t cylinderId, double fuelKg, double oxygenKg,
    double temperatureK, const ExhaustFuelReactionConfig& reaction) noexcept {
    if (!configured_ || !(reaction.pocketMixingTimeSeconds > 0.0)
        || !(fuelKg > 0.0) || !(oxygenKg > 0.0) || !(temperatureK > 0.0)
        || !finite(fuelKg) || !finite(oxygenKg) || !finite(temperatureK)
        || !(reaction.fuelMolarMassKg > 0.0))
        return false;
    const auto oxygenMassPerFuelMass =
        reaction.oxygenMolesPerFuelMole * 0.032 / reaction.fuelMolarMassKg;
    const auto equivalenceRatio = fuelKg * oxygenMassPerFuelMass / oxygenKg;
    if (equivalenceRatio < reaction.minimumEquivalenceRatio
        || equivalenceRatio > richEquivalenceLimit(reaction, temperatureK))
        return false;
    const auto ports = layout_.cylinderPorts();
    const auto port = std::find_if(ports.begin(), ports.end(),
        [cylinderId](const CompiledCylinderPort& candidate) {
            return candidate.cylinderId == cylinderId;
        });
    if (port == ports.end()) return false;
    const auto slot = std::find_if(unburnedPockets_.begin(),
        unburnedPockets_.end(),
        [](const UnburnedPocket& pocket) { return !pocket.active; });
    if (slot == unburnedPockets_.end()) return false;
    const auto& endpoint = port->networkEndpoint;
    UnburnedPocket pocket;
    pocket.active = true;
    pocket.inJunction = endpoint.type == ExhaustEndpointType::junction;
    pocket.elementIndex = endpoint.elementIndex;
    pocket.positionM = endpoint.type == ExhaustEndpointType::ductOutlet
            && endpoint.elementIndex < ducts_.size()
        ? layout_.ducts()[endpoint.elementIndex].lengthM : 0.0;
    pocket.fuelKg = fuelKg;
    pocket.oxygenKg = oxygenKg;
    pocket.temperatureK = temperatureK;
    *slot = pocket;
    return true;
}

void ExhaustGasNetwork::igniteUnburnedPockets(std::uint32_t cylinderId) noexcept {
    const auto ports = layout_.cylinderPorts();
    const auto port = std::find_if(ports.begin(), ports.end(),
        [cylinderId](const CompiledCylinderPort& candidate) {
            return candidate.cylinderId == cylinderId;
        });
    if (port == ports.end()) return;
    const auto& endpoint = port->networkEndpoint;
    const auto inJunction = endpoint.type == ExhaustEndpointType::junction;
    for (auto& pocket : unburnedPockets_)
        if (pocket.active && pocket.inJunction == inJunction
            && pocket.elementIndex == endpoint.elementIndex)
            pocket.burning = true;
}

std::size_t ExhaustGasNetwork::activeUnburnedPocketCount() const noexcept {
    return static_cast<std::size_t>(std::count_if(unburnedPockets_.begin(),
        unburnedPockets_.end(),
        [](const UnburnedPocket& pocket) { return pocket.active; }));
}

bool ExhaustGasNetwork::sampleCylinderBoundaries(
    std::span<const CylinderValveBoundary> cylinderBoundaries,
    std::span<CylinderBoundaryFlowSample> samples) const noexcept {
    const auto ports = layout_.cylinderPorts();
    if (!configured_ || samples.size() < ports.size()) return false;

    for (std::size_t index = 0; index < ports.size(); ++index) {
        samples[index] = {};
        samples[index].cylinderId = ports[index].cylinderId;
        samples[index].pathIndex = ports[index].pathIndex;
    }
    // Mutable access to a duct's initial condition deliberately invalidates its
    // derived cache. Rebuild it here as advance() would before observing it.
    for (const auto& duct : ducts_)
        if (!duct.refreshCellStateCache()) return false;

    const auto suppliedInPortOrder = cylinderBoundaries.size() == ports.size()
        && std::equal(cylinderBoundaries.begin(), cylinderBoundaries.end(),
            ports.begin(), [](const CylinderValveBoundary& boundary,
                              const CompiledCylinderPort& port) {
                return boundary.cylinderId == port.cylinderId;
            });

    for (std::size_t index = 0; index < cylinderBoundaries.size(); ++index) {
        const auto& boundary = cylinderBoundaries[index];
        if (!finite(boundary.cylinderVolumeM3) || !(boundary.cylinderVolumeM3 > 0.0)
            || !finite(boundary.effectiveValveAreaM2) || boundary.effectiveValveAreaM2 < 0.0
            || !finite(boundary.dischargeCoefficient) || boundary.dischargeCoefficient < 0.0)
            return false;
        if (!suppliedInPortOrder) {
            const auto known = std::find_if(ports.begin(), ports.end(),
                [&boundary](const CompiledCylinderPort& port) {
                    return port.cylinderId == boundary.cylinderId;
                });
            if (known == ports.end()) return false;
            for (std::size_t other = index + 1; other < cylinderBoundaries.size(); ++other)
                if (boundary.cylinderId == cylinderBoundaries[other].cylinderId) return false;
        }
    }

    const auto endpointState = [this](const ExhaustEndpoint& endpoint)
        -> const ConservativeState& {
        if (endpoint.type == ExhaustEndpointType::junction)
            return junctionStates_[endpoint.elementIndex];
        const auto& cells = ducts_[endpoint.elementIndex].cells_;
        return endpoint.type == ExhaustEndpointType::ductInlet
            ? cells.front() : cells.back();
    };
    const auto endpointPrimitive = [this](const ExhaustEndpoint& endpoint)
        -> const PrimitiveState& {
        if (endpoint.type == ExhaustEndpointType::junction)
            return junctionPrimitives_[endpoint.elementIndex];
        const auto& primitives = ducts_[endpoint.elementIndex].cellPrimitives_;
        return endpoint.type == ExhaustEndpointType::ductInlet
            ? primitives.front() : primitives.back();
    };

    for (std::size_t portIndex = 0; portIndex < ports.size(); ++portIndex) {
        const auto& port = ports[portIndex];
        auto& sample = samples[portIndex];
        const auto& networkPrimitive = endpointPrimitive(port.networkEndpoint);
        sample.networkPressurePa = networkPrimitive.pressurePa;
        sample.networkTemperatureK = networkPrimitive.temperatureK;
        sample.networkDensityKgPerM3 = networkPrimitive.densityKgPerM3;
        sample.networkVelocityMps = networkPrimitive.velocityMps;
        sample.networkSpeedOfSoundMps = networkPrimitive.speedOfSoundMps;

        const auto supplied = suppliedInPortOrder
            ? cylinderBoundaries.begin() + static_cast<std::ptrdiff_t>(portIndex)
            : std::find_if(cylinderBoundaries.begin(), cylinderBoundaries.end(),
                [&port](const CylinderValveBoundary& boundary) {
                    return boundary.cylinderId == port.cylinderId;
                });
        if (supplied == cylinderBoundaries.end()) continue;
        const auto cylinderPrimitive = mixtureModel_.primitiveFromConservative(
            supplied->cylinderState);
        if (!cylinderPrimitive) return false;
        const auto openingAreaM2 = std::min(
            supplied->effectiveValveAreaM2
                * std::clamp(supplied->dischargeCoefficient, 0.0, 1.5),
            port.runnerConnectionAreaM2 * port.dischargeCoefficient);
        if (openingAreaM2 > 0.0) {
            std::optional<EulerFlux> faceFlux;
            auto faceAreaM2 = 0.0;
            if (config_.characteristicValveBoundary
                && port.networkEndpoint.type == ExhaustEndpointType::ductInlet) {
                faceAreaM2 = ducts_[port.networkEndpoint.elementIndex].faceAreasM2_.front();
                faceFlux = characteristicInletValveFlux(
                    supplied->cylinderState, *cylinderPrimitive,
                    endpointState(port.networkEndpoint), networkPrimitive,
                    openingAreaM2, faceAreaM2, mixtureModel_, nullptr);
            }
            const auto flux = faceFlux ? *faceFlux : compressibleValveFlux(
                supplied->cylinderState, *cylinderPrimitive,
                endpointState(port.networkEndpoint), networkPrimitive);
            sample.massFlowKgPerSecond = (faceFlux ? faceAreaM2 : openingAreaM2)
                * sumSpecies(flux.speciesMassFluxKgPerM2S);
        }
        sample.valid = finite(sample.massFlowKgPerSecond)
            && sample.networkPressurePa > 0.0
            && sample.networkTemperatureK > 0.0
            && sample.networkDensityKgPerM3 > 0.0
            && sample.networkSpeedOfSoundMps > 0.0;
    }
    return true;
}

double ExhaustGasNetwork::maximumStableTimeStep(
    std::span<const CylinderValveBoundary> cylinderBoundaries,
    const ExhaustAmbientBoundary& ambient) const noexcept {
    auto stableStep = std::numeric_limits<double>::infinity();
    for (const auto& duct : ducts_) {
        stableStep = std::min(stableStep,
            duct.maximumStableTimeStep(config_.maximumCourantNumber));
    }
    for (std::size_t index = 0; index < junctionStates_.size(); ++index) {
        const auto& primitive = junctionPrimitives_[index];
        const auto areaSum = junctionPortAreaSums_[index];
        // The duct cells' convention: a cell of length dx between two faces
        // of area A takes C dx / (|u| + c) = 2 C V / (sum of A (|u| + c)).
        // Without the factor 2 a compact crossover (2 A d over four ports)
        // took half its pipes' step and set the whole network's; torque and
        // sound did not move between half and twice this step (LS3, journal
        // 2026-10-09).
        if (areaSum > 0.0) {
            stableStep = std::min(stableStep,
                2.0 * config_.maximumCourantNumber * layout_.junctions()[index].volumeM3
                    / (areaSum * (std::abs(primitive.velocityMps)
                                  + primitive.speedOfSoundMps)));
        }
    }

    const auto endpointPrimitive = [this](const ExhaustEndpoint& endpoint)
        -> const PrimitiveState& {
        if (endpoint.type == ExhaustEndpointType::junction)
            return junctionPrimitives_[endpoint.elementIndex];
        const auto& primitives = ducts_[endpoint.elementIndex].cellPrimitives_;
        return endpoint.type == ExhaustEndpointType::ductInlet
            ? primitives.front() : primitives.back();
    };
    const auto endpointVolume = [this](const ExhaustEndpoint& endpoint) noexcept {
        if (endpoint.type == ExhaustEndpointType::junction)
            return layout_.junctions()[endpoint.elementIndex].volumeM3;
        const auto& duct = ducts_[endpoint.elementIndex];
        const auto cellIndex = endpoint.type == ExhaustEndpointType::ductInlet
            ? std::size_t { 0 } : duct.cells().size() - 1;
        return duct.cellVolumesM3_[cellIndex];
    };
    const auto endpointOpenArea = [this](const ExhaustEndpoint& endpoint) noexcept {
        if (endpoint.type == ExhaustEndpointType::junction) {
            const auto diameter = layout_.junctions()[endpoint.elementIndex]
                .characteristicDiameterM;
            return 0.25 * std::acos(-1.0) * diameter * diameter;
        }
        const auto& duct = layout_.ducts()[endpoint.elementIndex];
        return endpoint.type == ExhaustEndpointType::ductInlet
            ? std::min(duct.inletConnectionAreaM2, duct.inletFlowAreaM2)
            : std::min(duct.outletConnectionAreaM2, duct.outletFlowAreaM2);
    };
    const auto constrainBoundary = [this, &stableStep, &endpointPrimitive, &endpointVolume](
        const PrimitiveState& reservoir,
        const ExhaustEndpoint& endpoint,
        double openingAreaM2) noexcept {
        if (!(openingAreaM2 > 0.0)) return;
        const auto& endpointState = endpointPrimitive(endpoint);
        const auto signalSpeed = std::max(
            std::abs(reservoir.velocityMps) + reservoir.speedOfSoundMps,
            std::abs(endpointState.velocityMps) + endpointState.speedOfSoundMps);
        stableStep = std::min(stableStep,
            config_.maximumCourantNumber * endpointVolume(endpoint)
                / (openingAreaM2 * signalSpeed));
    };
    for (std::size_t index = 0; index < layout_.cylinderPorts().size(); ++index) {
        if (cylinderReservoirActive_[index] == 0) continue;
        const auto& port = layout_.cylinderPorts()[index];
        const auto boundaryIndex = cylinderBoundaryIndices_[index];
        if (boundaryIndex >= cylinderBoundaries.size()) continue;
        const auto& boundary = cylinderBoundaries[boundaryIndex];
        const auto opening = std::min({
            suppliedValveAreaM2(boundary, boundaryElapsedSeconds_)
                * std::clamp(boundary.dischargeCoefficient, 0.0, 1.5),
            port.runnerConnectionAreaM2 * port.dischargeCoefficient,
            endpointOpenArea(port.networkEndpoint) });
        const auto& reservoirPrimitive = cylinderReservoirPrimitives_[index];
        const auto& networkPrimitive = endpointPrimitive(port.networkEndpoint);
        constrainBoundary(reservoirPrimitive, port.networkEndpoint, opening);
        const auto signalSpeed = std::max(
            reservoirPrimitive.speedOfSoundMps,
            std::abs(networkPrimitive.velocityMps) + networkPrimitive.speedOfSoundMps);
        if (opening > 0.0) {
            stableStep = std::min(stableStep,
                config_.maximumCourantNumber * cylinderReservoirVolumesM3_[index]
                    / (opening * signalSpeed));
        }
        // The drain through the other valve may take at most the Courant share
        // of the content in one step.
        const auto drainRate = otherOutflowDrainRatePerS(boundary);
        if (drainRate > 0.0)
            stableStep = std::min(stableStep, config_.maximumCourantNumber / drainRate);
    }
    auto ambientAreaSignalSumM3PerS = 0.0;
    for (const auto& outlet : layout_.outlets()) {
        const auto opening = std::min(endpointOpenArea(outlet.networkEndpoint),
            outlet.openingAreaM2 * outlet.dischargeCoefficient
                * std::clamp(ambient.openingScale, 0.0, 1.0));
        constrainBoundary(ambientPrimitive_, outlet.networkEndpoint, opening);
        if (ambientReservoirVolumeM3_ > 0.0 && opening > 0.0) {
            auto effectiveOpening = opening;
            if (outlet.networkEndpoint.type == ExhaustEndpointType::junction) {
                effectiveOpening /= std::sqrt(1.0
                    + layout_.junctions()[outlet.networkEndpoint.elementIndex].lossCoefficient);
            }
            const auto& networkPrimitive = endpointPrimitive(outlet.networkEndpoint);
            const auto signalSpeed = std::max(ambientPrimitive_.speedOfSoundMps,
                std::abs(networkPrimitive.velocityMps) + networkPrimitive.speedOfSoundMps);
            ambientAreaSignalSumM3PerS += effectiveOpening * signalSpeed;
        }
    }
    // All openings share the finite inventory. Opposite signed flows can
    // cancel in their net transfer without reducing the reservoir's stiffness.
    if (ambientReservoirVolumeM3_ > 0.0 && ambientAreaSignalSumM3PerS > 0.0)
        stableStep = std::min(stableStep, config_.maximumCourantNumber
            * ambientReservoirVolumeM3_ / ambientAreaSignalSumM3PerS);
    return stableStep;
}

template <typename Body>
bool ExhaustGasNetwork::forEachDuct(const Body& body) noexcept {
    const auto count = ducts_.size();
    if (parallelFor_.run == nullptr || count < 2) {
        // Every duct runs even after a failure, exactly as in a parallel
        // dispatch, so both schedules leave the same per-duct flags behind.
        auto succeeded = true;
        for (std::size_t index = 0; index < count; ++index)
            succeeded = body(index) && succeeded;
        return succeeded;
    }
    if (ductChunkBegin_.empty()) buildDuctChunks();
    struct Context final {
        const Body* body;
        std::uint8_t* succeeded;
        const std::size_t* chunkBegin;
    } context { &body, ductSucceeded_.data(), ductChunkBegin_.data() };
    parallelFor_.run(parallelFor_.executor, ductChunkBegin_.size() - 1,
        [](void* raw, std::size_t chunk) noexcept {
            const auto& job = *static_cast<Context*>(raw);
            for (auto index = job.chunkBegin[chunk]; index < job.chunkBegin[chunk + 1]; ++index)
                job.succeeded[index] = (*job.body)(index) ? 1 : 0;
        },
        &context);
    return std::all_of(ductSucceeded_.begin(), ductSucceeded_.end(),
        [](std::uint8_t succeeded) { return succeeded != 0; });
}

void ExhaustGasNetwork::buildDuctChunks() noexcept {
    // One contiguous run of ducts per thread. Handed out one duct at a time,
    // a two-stroke's expansion chamber (cones of two or three cells) cost an
    // atomic claim per few cells: one chunk per thread ran the designed
    // two-stroke triple and V4 5 % faster and the LS3 2.5 %; two per thread
    // gained nothing more (journal 2026-10-24). The ducts and their order are
    // unchanged, so the result is bit-identical.
    const auto count = ducts_.size();
    ductChunkBegin_.clear();
    const auto chunks = std::clamp<std::size_t>(parallelFor_.threads, 1, count);
    // A duct's work is its cells plus a fixed part (its two end faces, its
    // caches): weigh both, so a chain of two-cell cones is not one chunk.
    constexpr double fixedCellsPerDuct = 2.0;
    auto total = 0.0;
    for (const auto& duct : ducts_) total += static_cast<double>(duct.cells_.size()) + fixedCellsPerDuct;
    ductChunkBegin_.push_back(0);
    auto accumulated = 0.0;
    for (std::size_t index = 0; index < count; ++index) {
        accumulated += static_cast<double>(ducts_[index].cells_.size()) + fixedCellsPerDuct;
        const auto filled = ductChunkBegin_.size();
        if (filled < chunks && index + 1 < count
            && accumulated >= total * static_cast<double>(filled) / static_cast<double>(chunks))
            ductChunkBegin_.push_back(index + 1);
    }
    ductChunkBegin_.push_back(count);
}

bool ExhaustGasNetwork::evaluateStage(
    bool useStageState,
    std::span<const CylinderValveBoundary> cylinderBoundaries,
    const ExhaustAmbientBoundary& ambient) noexcept {
    return evaluateStage(useStageState, cylinderBoundaries, ambient, StagePart::whole,
        [](std::size_t) noexcept { return true; });
}

template <typename Prelude>
bool ExhaustGasNetwork::evaluateStage(
    bool useStageState,
    std::span<const CylinderValveBoundary> cylinderBoundaries,
    const ExhaustAmbientBoundary& ambient,
    StagePart part,
    const Prelude& prelude) noexcept {
    auto& cylinderFlows = useStageState ? cylinderSecondStageFlow_ : cylinderFirstStageFlow_;
    auto& outletFlows = useStageState ? outletSecondStageFlow_ : outletFirstStageFlow_;
    auto& interfaceRates = useStageState
        ? interfaceSecondStageRate_ : interfaceFirstStageRate_;
    auto& junctionResiduals = useStageState ? junctionStageResidual_ : junctionResidual_;
    auto& cylinderResiduals = useStageState
        ? cylinderReservoirStageResidual_ : cylinderReservoirResidual_;
    auto& ambientResidual = useStageState
        ? ambientReservoirStageResidual_ : ambientReservoirResidual_;
    const auto& ambientState = ambientReservoirVolumeM3_ > 0.0
        ? (useStageState ? ambientReservoirStage_ : ambientReservoirState_)
        : ambient.reservoirState;
    const auto& ambientPrimitive = ambientReservoirVolumeM3_ > 0.0 && useStageState
        ? ambientStagePrimitive_ : ambientPrimitive_;
    // Every mouth in this stage sees the same reservoir. Prepared once up
    // front (the same arithmetic as preparing it on the first drawing mouth),
    // so the per-duct pass below shares it without a race.
    std::optional<ReservoirInflowConstants> sharedInflowConstants =
        reservoirInflowConstants(ambientPrimitive);

    const auto& junctionStates = useStageState ? junctionStage_ : junctionStates_;
    const auto& junctionPrimitives = useStageState
        ? junctionStagePrimitives_ : junctionPrimitives_;
    const auto& cylinderPrimitives = useStageState
        ? cylinderReservoirStagePrimitives_ : cylinderReservoirPrimitives_;
    const auto endpointState = [this, useStageState, &junctionStates](
        const ExhaustEndpoint& endpoint) -> const ConservativeState& {
        if (endpoint.type == ExhaustEndpointType::junction)
            return junctionStates[endpoint.elementIndex];
        const auto& duct = ducts_[endpoint.elementIndex];
        const auto& states = useStageState ? duct.stage_ : duct.cells_;
        return endpoint.type == ExhaustEndpointType::ductInlet
            ? states.front() : states.back();
    };
    const auto endpointPrimitive = [this, useStageState, &junctionPrimitives](
        const ExhaustEndpoint& endpoint) -> const PrimitiveState& {
        if (endpoint.type == ExhaustEndpointType::junction)
            return junctionPrimitives[endpoint.elementIndex];
        const auto& duct = ducts_[endpoint.elementIndex];
        const auto& primitives = useStageState
            ? duct.stagePrimitives_ : duct.cellPrimitives_;
        return endpoint.type == ExhaustEndpointType::ductInlet
            ? primitives.front() : primitives.back();
    };
    const auto endpointArea = [this](const ExhaustEndpoint& endpoint) noexcept {
        if (endpoint.type == ExhaustEndpointType::junction) {
            const auto diameter = layout_.junctions()[endpoint.elementIndex]
                .characteristicDiameterM;
            return 0.25 * std::acos(-1.0) * diameter * diameter;
        }
        const auto& duct = layout_.ducts()[endpoint.elementIndex];
        return endpoint.type == ExhaustEndpointType::ductInlet
            ? std::min(duct.inletConnectionAreaM2, duct.inletFlowAreaM2)
            : std::min(duct.outletConnectionAreaM2, duct.outletFlowAreaM2);
    };
    const auto makeFlowRate = [](const EulerFlux& flux, double areaM2) noexcept {
        ConservedFlowRate result;
        for (std::size_t index = 0; index < gasSpeciesCount; ++index)
            result.speciesMassKgPerS[index] = flux.speciesMassFluxKgPerM2S[index] * areaM2;
        result.momentumN = flux.momentumFluxPa * areaM2;
        result.totalEnergyW = flux.totalEnergyFluxWPerM2 * areaM2;
        return result;
    };
    const auto addJunctionFlow = [&junctionResiduals, &junctionPrimitives, this](
        std::size_t junctionIndex, const ConservedFlowRate& flow,
        double openingAreaM2, double sign, bool sideBranch = false) noexcept {
        const auto inverseVolume = 1.0 / layout_.junctions()[junctionIndex].volumeM3;
        for (std::size_t species = 0; species < gasSpeciesCount; ++species) {
            junctionResiduals[junctionIndex].speciesMassDensityKgPerM3[species] +=
                sign * flow.speciesMassKgPerS[species] * inverseVolume;
        }
        // The unresolved wall balances the junction's own static pressure over
        // each face. What remains is the graph-axis pressure difference plus
        // advective momentum. With momentum evolution disabled the junction is
        // the historical well-mixed plenum; when enabled, a collector carries
        // momentum toward its trunk without inventing a net force at rest.
        const auto resolvedAxialForceN = flow.momentumN
            - junctionPrimitives[junctionIndex].pressurePa * openingAreaM2;
        // A side branch's face lies along the axis: its flow and the wall
        // around it push across the axis, not along it.
        if (config_.evolveJunctionAxialMomentum && !sideBranch) {
            junctionResiduals[junctionIndex].momentumDensityKgPerM2S +=
                sign * resolvedAxialForceN * inverseVolume;
        }
        junctionResiduals[junctionIndex].totalEnergyDensityJPerM3 +=
            sign * flow.totalEnergyW * inverseVolume;
    };
    const auto assignDuctBoundary = [this, useStageState](
        const ExhaustEndpoint& endpoint, const EulerFlux& newFlux) noexcept {
        if (endpoint.type == ExhaustEndpointType::junction) return true;
        const auto ductIndex = endpoint.elementIndex;
        auto& duct = ducts_[ductIndex];
        auto& assigned = endpoint.type == ExhaustEndpointType::ductInlet
            ? ductInletAssigned_[ductIndex] : ductOutletAssigned_[ductIndex];
        if (assigned != 0) return false;
        assigned = 1;
        auto& residual = useStageState ? duct.stageResidual_ : duct.residual_;
        auto& faceFluxes = useStageState ? duct.stageFaceFluxes_ : duct.faceFluxes_;
        const auto faceIndex = endpoint.type == ExhaustEndpointType::ductInlet
            ? std::size_t { 0 } : faceFluxes.size() - 1;
        const auto residualIndex = endpoint.type == ExhaustEndpointType::ductInlet
            ? std::size_t { 0 } : residual.size() - 1;
        const auto sign = endpoint.type == ExhaustEndpointType::ductInlet ? 1.0 : -1.0;
        const auto faceAreaM2 = duct.faceAreasM2_[faceIndex];
        const auto inverseCellVolumeM3 =
            duct.inverseCellVolumesM3_[residualIndex];
        const auto& oldFlux = faceFluxes[faceIndex];
        for (std::size_t species = 0; species < gasSpeciesCount; ++species) {
            residual[residualIndex].speciesMassDensityKgPerM3[species] +=
                sign * faceAreaM2 * inverseCellVolumeM3
                * (newFlux.speciesMassFluxKgPerM2S[species]
                   - oldFlux.speciesMassFluxKgPerM2S[species]);
        }
        residual[residualIndex].momentumDensityKgPerM2S +=
            sign * faceAreaM2 * inverseCellVolumeM3
            * (newFlux.momentumFluxPa - oldFlux.momentumFluxPa);
        residual[residualIndex].totalEnergyDensityJPerM3 +=
            sign * faceAreaM2 * inverseCellVolumeM3
            * (newFlux.totalEnergyFluxWPerM2 - oldFlux.totalEnergyFluxWPerM2);
        faceFluxes[faceIndex] = newFlux;
        return true;
    };
    const auto ductBoundaryFlux = [this, &endpointState, &endpointPrimitive](
        const ExhaustEndpoint& endpoint,
        const EulerFlux& apertureFlux,
        double apertureAreaM2) noexcept {
        const auto& duct = ducts_[endpoint.elementIndex];
        const auto& geometry = duct.geometry();
        const auto faceIndex = endpoint.type == ExhaustEndpointType::ductInlet
            ? std::size_t { 0 } : geometry.cellCount;
        const auto faceAreaM2 = duct.faceAreasM2_[faceIndex];
        const auto& primitive = endpointPrimitive(endpoint);
        auto wallPressurePa = primitive.pressurePa;
        // A closed face loads its wall with the cell's own pressure, a centred
        // term: SSP-RK2 holds it, but one forward-Euler stage amplifies a
        // closed duct's acoustic mode (Hancock: 1.2-479x above Courant 0.3,
        // IntakeAcousticConvergenceTests). The single-stage schemes take the
        // reflected Riemann pressure there, upwind like any face. Not on the
        // closed part of a partly open face: its cell velocity is the flow
        // through the opening, not onto the wall, and p + rho c u there cost
        // the RD350 40 % of its torque at 50 mm.
        if (config_.firstOrderTimeIntegration && !(apertureAreaM2 > 0.0)) {
            const auto& state = endpointState(endpoint);
            auto mirroredState = state;
            mirroredState.momentumDensityKgPerM2S = -state.momentumDensityKgPerM2S;
            auto mirroredPrimitive = primitive;
            mirroredPrimitive.velocityMps = -primitive.velocityMps;
            wallPressurePa = (endpoint.type == ExhaustEndpointType::ductInlet
                ? mixtureModel_.riemannFluxPrepared(
                    mirroredState, mirroredPrimitive, state, primitive)
                : mixtureModel_.riemannFluxPrepared(
                    state, primitive, mirroredState, mirroredPrimitive)).momentumFluxPa;
        }
        return areaAveragedBoundaryFlux(apertureFlux, apertureAreaM2,
            faceAreaM2, wallPressurePa);
    };
    // An open interface's flux reads only the two end states it joins, so
    // the duct owning it computes it with its own pass; it is applied below,
    // in interface order.
    const auto computeInterfaceFlux = [&](std::size_t index) noexcept {
        const auto& connection = layout_.interfaces()[index];
        const auto& upstream = connection.upstream;
        const auto& downstream = connection.downstream;
        auto effectiveArea = std::max(0.0,
            std::min(endpointArea(upstream), endpointArea(downstream)));
        if (upstream.type == ExhaustEndpointType::junction) {
            effectiveArea /= std::sqrt(1.0
                + layout_.junctions()[upstream.elementIndex].lossCoefficient);
        }
        auto& result = interfaceFluxes_[index];
        if (interfaceReconstructed_[index] != 0) {
            // Both ends were reconstructed through each other by their own
            // duct passes, which have all run by now.
            const auto& up = ducts_[upstream.elementIndex];
            const auto& down = ducts_[downstream.elementIndex];
            const auto upInlet = upstream.type == ExhaustEndpointType::ductInlet;
            const auto downInlet = downstream.type == ExhaustEndpointType::ductInlet;
            const auto upCell = upInlet ? std::size_t { 0 } : up.reconstructedRight_.size() - 1;
            const auto downCell = downInlet ? std::size_t { 0 } : down.reconstructedRight_.size() - 1;
            result.rawFlux = effectiveArea > 0.0
                ? mixtureModel_.riemannFluxPrepared(
                    upInlet ? up.reconstructedLeft_[upCell] : up.reconstructedRight_[upCell],
                    upInlet ? up.reconstructedLeftPrimitives_[upCell]
                            : up.reconstructedRightPrimitives_[upCell],
                    downInlet ? down.reconstructedLeft_[downCell] : down.reconstructedRight_[downCell],
                    downInlet ? down.reconstructedLeftPrimitives_[downCell]
                              : down.reconstructedRightPrimitives_[downCell])
                : EulerFlux {};
        } else if (connection.upstreamPort == exhaustSideBranchPort
                   || connection.downstreamPort == exhaustSideBranchPort) {
            // A duct meeting a junction at right angles sees it at rest: the
            // junction's velocity is along its own axis, across the branch.
            auto upstreamState = endpointState(upstream);
            auto upstreamPrimitive = endpointPrimitive(upstream);
            auto downstreamState = endpointState(downstream);
            auto downstreamPrimitive = endpointPrimitive(downstream);
            const auto atRest = [](ConservativeState& state, PrimitiveState& primitive) noexcept {
                state.totalEnergyDensityJPerM3 -= 0.5 * state.momentumDensityKgPerM2S * primitive.velocityMps;
                state.momentumDensityKgPerM2S = 0.0;
                primitive.velocityMps = 0.0;
            };
            if (upstream.type == ExhaustEndpointType::junction
                && connection.upstreamPort == exhaustSideBranchPort)
                atRest(upstreamState, upstreamPrimitive);
            if (downstream.type == ExhaustEndpointType::junction
                && connection.downstreamPort == exhaustSideBranchPort)
                atRest(downstreamState, downstreamPrimitive);
            result.rawFlux = effectiveArea > 0.0
                ? mixtureModel_.riemannFluxPrepared(
                    upstreamState, upstreamPrimitive, downstreamState, downstreamPrimitive)
                : EulerFlux {};
        } else {
            result.rawFlux = effectiveArea > 0.0
                ? mixtureModel_.riemannFluxPrepared(
                    endpointState(upstream), endpointPrimitive(upstream),
                    endpointState(downstream), endpointPrimitive(downstream))
                : EulerFlux {};
        }
        result.effectiveAreaM2 = effectiveArea;
        if (upstream.type != ExhaustEndpointType::junction)
            result.upstreamDuctFlux = ductBoundaryFlux(upstream, result.rawFlux, effectiveArea);
        if (downstream.type != ExhaustEndpointType::junction)
            result.downstreamDuctFlux =
                ductBoundaryFlux(downstream, result.rawFlux, effectiveArea);
    };
    const auto applyInterfaceFlux = [&](std::size_t index) noexcept {
        const auto& connection = layout_.interfaces()[index];
        const auto& upstream = connection.upstream;
        const auto& downstream = connection.downstream;
        const auto& result = interfaceFluxes_[index];
        const auto effectiveArea = result.effectiveAreaM2;
        const auto flow = makeFlowRate(result.rawFlux, effectiveArea);
        if (upstream.type == ExhaustEndpointType::junction) {
            addJunctionFlow(upstream.elementIndex, flow, effectiveArea, -1.0,
                connection.upstreamPort == exhaustSideBranchPort);
        } else if (!assignDuctBoundary(upstream, result.upstreamDuctFlux)) {
            return false;
        }
        if (downstream.type == ExhaustEndpointType::junction) {
            addJunctionFlow(downstream.elementIndex, flow, effectiveArea, 1.0,
                connection.downstreamPort == exhaustSideBranchPort);
        } else if (!assignDuctBoundary(downstream, result.downstreamDuctFlux)) {
            return false;
        }
        return true;
    };
    // A stage pass with a prelude rewrites each duct's states as it goes, so
    // a neighbour's end cell is only ready once every duct has passed.
    // Reconstructed across, an interface also needs its other duct's pass.
    const auto interfacesInDuctPass = part == StagePart::whole
        && !config_.reconstructAcrossInterfaces;

    // A port's face flux depends only on its cylinder reservoir and its own
    // duct end, so it can be computed with that duct; it is applied below.
    const auto computePortFlux = [&](std::size_t index) noexcept {
        const auto& port = layout_.cylinderPorts()[index];
        const auto suppliedIndex = cylinderBoundaryIndices_[index];
        auto openingArea = 0.0;
        if (suppliedIndex < cylinderBoundaries.size()) {
            const auto& supplied = cylinderBoundaries[suppliedIndex];
            openingArea = std::min({
                suppliedValveAreaM2(supplied, boundaryElapsedSeconds_)
                    * std::clamp(supplied.dischargeCoefficient, 0.0, 1.5),
                port.runnerConnectionAreaM2 * port.dischargeCoefficient,
                endpointArea(port.networkEndpoint) });
        }

        const auto& activeCylinderState = useStageState
            ? cylinderReservoirStage_[index] : cylinderReservoirStates_[index];
        const auto networkState = endpointState(port.networkEndpoint);
        // The characteristic boundary returns a flux over the whole face,
        // which then needs no area averaging.
        std::optional<EulerFlux> faceFlux;
        auto faceAreaM2 = 0.0;
        auto& result = portFluxes_[index];
        // The solve's warm start is committed only where the serial loop
        // applies this flux, so a stage abandoned earlier leaves it untouched.
        result.faceSolve = valveFaceSolve_[index];
        if (openingArea > 0.0 && config_.characteristicValveBoundary
            && port.networkEndpoint.type == ExhaustEndpointType::ductInlet) {
            faceAreaM2 = ducts_[port.networkEndpoint.elementIndex].faceAreasM2_.front();
            faceFlux = characteristicInletValveFlux(
                activeCylinderState, cylinderPrimitives[index],
                networkState, endpointPrimitive(port.networkEndpoint),
                openingArea, faceAreaM2, mixtureModel_, result.faceSolve.data());
        }
        result.rawFlux = faceFlux ? *faceFlux
            : openingArea > 0.0
            ? compressibleValveFlux(
                activeCylinderState, cylinderPrimitives[index],
                networkState, endpointPrimitive(port.networkEndpoint))
            : EulerFlux {};
        result.openingAreaM2 = openingArea;
        result.flowAreaM2 = faceFlux ? faceAreaM2 : openingArea;
        if (port.networkEndpoint.type != ExhaustEndpointType::junction)
            result.ductFlux = faceFlux ? *faceFlux
                : ductBoundaryFlux(port.networkEndpoint, result.rawFlux, openingArea);
    };
    const auto computeOutletFlux = [&](std::size_t index) noexcept {
        const auto& outlet = layout_.outlets()[index];
        auto openingArea = std::min(endpointArea(outlet.networkEndpoint),
            outlet.openingAreaM2 * outlet.dischargeCoefficient
                * std::clamp(ambient.openingScale, 0.0, 1.0));
        if (outlet.networkEndpoint.type == ExhaustEndpointType::junction) {
            openingArea /= std::sqrt(1.0
                + layout_.junctions()[outlet.networkEndpoint.elementIndex].lossCoefficient);
        }
        // Terminal openings use the characteristic open-end boundary rather
        // than a Riemann problem against a cell of ambient air; see
        // openEndBoundaryPrimitive. The Riemann form is kept as the fallback
        // for a state the characteristic reconstruction cannot represent, so an
        // unphysical corner degrades to the previous behaviour instead of
        // producing no flux at all.
        auto rawFlux = EulerFlux {};
        if (openingArea > 0.0) {
            const auto& interiorPrimitive = endpointPrimitive(outlet.networkEndpoint);
            const auto boundary = openEndBoundaryPrimitive(
                interiorPrimitive, ambientPrimitive, &sharedInflowConstants);
            const auto boundaryState = boundary
                ? mixtureModel_.conservativeFromPrimitive(
                    boundary->densityKgPerM3, boundary->velocityMps, boundary->pressurePa,
                    GasComposition { boundary->massFractions })
                : std::nullopt;
            // Ghost-cell form deliberately, not the boundary state's physical
            // flux: the terminal cell is not uniformly at the exit state, and
            // taking the raw flux there let a blowdown drain the whole cell in
            // one substep. Going back through the Riemann solver keeps its wave
            // speeds and positivity safeguards while the ghost still carries the
            // atmosphere's pressure with the exhaust's own density (or, on
            // inflow, the reservoir's own gas already moving at its isentropic
            // entry speed), so the duct neither shoves a column of cold dense
            // air aside nor meters its intake by the acoustic impedance.
            // conservativeFromPrimitive already enforces the complete EOS
            // admissibility gate; repeating it adds no validation.
            rawFlux = boundaryState
                ? mixtureModel_.riemannFluxPrepared(
                    endpointState(outlet.networkEndpoint), interiorPrimitive,
                    *boundaryState, *boundary)
                : mixtureModel_.riemannFluxPrepared(
                    endpointState(outlet.networkEndpoint), interiorPrimitive,
                    ambientState, ambientPrimitive);
        }
        auto& result = outletFluxes_[index];
        result.rawFlux = rawFlux;
        result.openingAreaM2 = openingArea;
        result.flowAreaM2 = openingArea;
        if (outlet.networkEndpoint.type != ExhaustEndpointType::junction)
            result.ductFlux = ductBoundaryFlux(outlet.networkEndpoint, rawFlux, openingArea);
    };

    const auto transmissive = DuctBoundaryCondition::transmissive();
    const auto ductPass = [&](std::size_t ductIndex) noexcept {
        auto& duct = ducts_[ductIndex];
        const auto states = useStageState
            ? std::span<const ConservativeState>(duct.stage_)
            : std::span<const ConservativeState>(duct.cells_);
        const auto primitives = useStageState
            ? std::span<const PrimitiveState>(duct.stagePrimitives_)
            : std::span<const PrimitiveState>(duct.cellPrimitives_);
        const auto sourceTerms = useStageState
            ? std::span<const ConservativeState>(duct.stageSourceTerms_)
            : std::span<const ConservativeState>(duct.cellSourceTerms_);
        auto residual = useStageState
            ? std::span<ConservativeState>(duct.stageResidual_)
            : std::span<ConservativeState>(duct.residual_);
        auto faceFluxes = useStageState
            ? std::span<EulerFlux>(duct.stageFaceFluxes_)
            : std::span<EulerFlux>(duct.faceFluxes_);
        if (!prelude(ductIndex)) return false;
        const auto neighbourCell = [&](std::size_t slot) noexcept
            -> const ConservativeState* {
            const auto& neighbour = ductEndNeighbour_[slot];
            if (!neighbour) {
                if (!config_.reconstructAcrossInterfaces || !config_.extrapolateOpenEnds
                    || states.size() < 2)
                    return nullptr;
                const auto inlet = slot % 2 == 0;
                const auto& end = inlet ? states.front() : states.back();
                const auto& next = inlet ? states[1] : states[states.size() - 2];
                auto& ghost = ductEndGhost_[slot];
                ghost = addScaled(addScaled(end, end, 1.0), next, -1.0);
                PrimitiveState primitive;
                return mixtureModel_.recoverPrimitive(ghost, primitive) ? &ghost : nullptr;
            }
            const auto& other = ducts_[neighbour->elementIndex];
            const auto& otherStates = useStageState ? other.stage_ : other.cells_;
            return neighbour->type == ExhaustEndpointType::ductInlet
                ? &otherStates.front() : &otherStates.back();
        };
        duct.leftReconstructionNeighbour_ = neighbourCell(2 * ductIndex);
        duct.rightReconstructionNeighbour_ = neighbourCell(2 * ductIndex + 1);
        const auto computed = duct.computeResidual(states, primitives, sourceTerms,
                transmissive, transmissive, residual, faceFluxes, false,
                useStageState ? 0.0 : hancockHalfStepSeconds_);
        duct.leftReconstructionNeighbour_ = nullptr;
        duct.rightReconstructionNeighbour_ = nullptr;
        if (!computed) return false;
        for (const auto port : ductPorts_[ductIndex]) computePortFlux(port);
        for (const auto outlet : ductOutlets_[ductIndex]) computeOutletFlux(outlet);
        if (interfacesInDuctPass)
            for (const auto connection : ductInterfaces_[ductIndex])
                computeInterfaceFlux(connection);
        return true;
    };
    if (part != StagePart::coupling && !forEachDuct(ductPass)) return false;
    if (part == StagePart::ductPass) return true;

    std::fill(ductInletAssigned_.begin(), ductInletAssigned_.end(), std::uint8_t { 0 });
    std::fill(ductOutletAssigned_.begin(), ductOutletAssigned_.end(), std::uint8_t { 0 });
    std::fill(cylinderFlows.begin(), cylinderFlows.end(), ConservedFlowRate {});
    std::fill(outletFlows.begin(), outletFlows.end(), ConservedFlowRate {});
    std::fill(junctionResiduals.begin(), junctionResiduals.end(), ConservativeState {});
    std::fill(cylinderResiduals.begin(), cylinderResiduals.end(), ConservativeState {});
    if (ambientReservoirVolumeM3_ > 0.0) ambientResidual = {};

    // A plate (or a turbine) on a face, and an active valve that is not fully
    // open: at most one side is a junction (ExhaustNetworkLayout::assemble).
    // A junction side exchanges through the open area itself; it has no face
    // to load around the jet.
    const auto exchangeThroughOrifice = [&](std::size_t index,
                                            double openingAreaM2) noexcept {
        const auto& connection = layout_.interfaces()[index];
        const auto& upstreamCell = endpointPrimitive(connection.upstream);
        const auto& downstreamCell = endpointPrimitive(connection.downstream);
        const auto rawFlux = openingAreaM2 > 0.0
            ? restrictionOrificeFlux(
                endpointState(connection.upstream), upstreamCell,
                endpointState(connection.downstream), downstreamCell)
            : EulerFlux {};
        const auto massFlux = sumSpecies(rawFlux.speciesMassFluxKgPerM2S);
        const auto forward = massFlux >= 0.0;
        // The supplying side loses its gas at its own velocity against
        // its own pressure: the acceleration to the throat happens past
        // the face, and the plate's upstream side carries its reaction.
        // Handing it the throat's momentum instead (up to 1.27 p0 when
        // choked) gave -1.4 % against the isentropic choked flow (-0.2 %
        // this way). The receiving side takes the jet (Borda-Carnot),
        // less what a turbine wheel takes from it.
        auto upstreamFlux = rawFlux;
        auto downstreamFlux = rawFlux;
        auto& supplyFlux = forward ? upstreamFlux : downstreamFlux;
        const auto& supplyCell = forward ? upstreamCell : downstreamCell;
        supplyFlux.momentumFluxPa = supplyCell.pressurePa + massFlux * supplyCell.velocityMps;
        const auto& turbine = interfaceTurbines_[index];
        auto workFlux = 0.0;
        if (massFlux > 0.0 && turbine.wheelShare > 0.0 && turbine.efficiency > 0.0) {
            workFlux = massFlux * turbine.wheelShare * turbine.efficiency
                * isentropicExpansionWorkJPerKg(upstreamCell,
                    upstreamCell.velocityMps, downstreamCell.pressurePa);
            downstreamFlux.totalEnergyFluxWPerM2 -= workFlux;
            // The wheel turns its nozzles' jet into shaft work: what
            // leaves it carries no jet into the outlet. Left in, the
            // jet held the outlet cell at a quarter of the inlet
            // pressure and the wheel took 1.7 times what expanding to
            // the atmosphere could give. The bypass jet is dropped too
            // (its dynamic head fully dissipated, the Borda-Carnot limit
            // of a gate small against its outlet): half open, it still
            // drew the outlet down and gave the wheel +32 % per kg.
            downstreamFlux.momentumFluxPa = downstreamCell.pressurePa
                + massFlux * downstreamCell.velocityMps;
        }
        interfaceRates[index] = { massFlux * openingAreaM2, workFlux * openingAreaM2 };
        const auto apply = [&](const ExhaustEndpoint& endpoint, const EulerFlux& flux,
                               double sign) noexcept {
            if (endpoint.type == ExhaustEndpointType::junction) {
                addJunctionFlow(endpoint.elementIndex,
                    makeFlowRate(flux, openingAreaM2), openingAreaM2, sign,
                    (sign < 0.0 ? connection.upstreamPort : connection.downstreamPort)
                        == exhaustSideBranchPort);
                return true;
            }
            return assignDuctBoundary(endpoint,
                ductBoundaryFlux(endpoint, flux, openingAreaM2));
        };
        return apply(connection.upstream, upstreamFlux, -1.0)
            && apply(connection.downstream, downstreamFlux, 1.0);
    };
    for (std::size_t index = 0; index < layout_.interfaces().size(); ++index) {
        const auto& connection = layout_.interfaces()[index];
        // A plate open to its full face between two ducts is the plain face,
        // bit for bit: the quasi-steady orifice there passed the steady flow
        // but damped the ram wave (individual throttles lost 10-11 % of
        // their WOT torque; journal 2026-11-22). A turbine stays an orifice.
        if (connection.restriction
            && interfaceTurbines_[index].wheelShare <= 0.0
            && interfaceOpeningAreasM2_[index] >= interfaceFaceAreasM2_[index]
            && connection.upstream.type != ExhaustEndpointType::junction
            && connection.downstream.type != ExhaustEndpointType::junction) {
            computeInterfaceFlux(index);
            if (!applyInterfaceFlux(index)) return false;
            continue;
        }
        if (connection.restriction) {
            if (!exchangeThroughOrifice(index, interfaceOpeningAreasM2_[index]))
                return false;
            continue;
        }
        // A fully open valve is the plain face below, bit for bit.
        if (valveThrottled_ && interfaceValveThrottled_[index] != 0) {
            if (!exchangeThroughOrifice(index, interfaceValveAreasM2_[index]))
                return false;
            continue;
        }
        if (!interfacesInDuctPass || interfaceOwnerDuct_[index] == noInterfaceOwner)
            computeInterfaceFlux(index);
        if (!applyInterfaceFlux(index)) return false;
    }

    for (std::size_t index = 0; index < layout_.cylinderPorts().size(); ++index) {
        const auto& port = layout_.cylinderPorts()[index];
        const auto suppliedIndex = cylinderBoundaryIndices_[index];
        if (port.networkEndpoint.type == ExhaustEndpointType::junction)
            computePortFlux(index);
        const auto& flux = portFluxes_[index];
        valveFaceSolve_[index] = flux.faceSolve;
        const auto openingArea = flux.openingAreaM2;
        const auto& activeCylinderState = useStageState
            ? cylinderReservoirStage_[index] : cylinderReservoirStates_[index];
        cylinderFlows[index] = makeFlowRate(flux.rawFlux, flux.flowAreaM2);
        if (openingArea > 0.0 && cylinderReservoirActive_[index] != 0) {
            const auto inverseVolume = 1.0 / cylinderReservoirVolumesM3_[index];
            for (std::size_t species = 0; species < gasSpeciesCount; ++species) {
                cylinderResiduals[index].speciesMassDensityKgPerM3[species] -=
                    cylinderFlows[index].speciesMassKgPerS[species] * inverseVolume;
            }
            cylinderResiduals[index].totalEnergyDensityJPerM3 -=
                cylinderFlows[index].totalEnergyW * inverseVolume;
        }
        // A moving piston: the reservoir densities dilute with its volume and
        // the gas does p dV work on the piston.
        if (suppliedIndex < cylinderBoundaries.size()
            && cylinderReservoirActive_[index] != 0) {
            const auto volumeRate =
                cylinderBoundaries[suppliedIndex].cylinderVolumeRateM3PerS;
            if (volumeRate != 0.0) {
                const auto dilution = volumeRate / cylinderReservoirVolumesM3_[index];
                for (std::size_t species = 0; species < gasSpeciesCount; ++species)
                    cylinderResiduals[index].speciesMassDensityKgPerM3[species] -=
                        activeCylinderState.speciesMassDensityKgPerM3[species] * dilution;
                cylinderResiduals[index].totalEnergyDensityJPerM3 -=
                    (activeCylinderState.totalEnergyDensityJPerM3
                        + cylinderPrimitives[index].pressurePa) * dilution;
            }
            const auto& supplied = cylinderBoundaries[suppliedIndex];
            const auto drainRate = otherOutflowDrainRatePerS(supplied);
            if (drainRate > 0.0) {
                // A net outflow leaves with the reservoir's own composition and
                // stagnation enthalpy, at its rate relative to the content the
                // advance started from. Fixed rates computed on the previous
                // window's hot burned gas drained the energy of a chamber
                // refilling with cold charge (a closed throttle at the
                // limiter) to 0 K, and every later attempt was rejected.
                for (std::size_t species = 0; species < gasSpeciesCount; ++species)
                    cylinderResiduals[index].speciesMassDensityKgPerM3[species] -=
                        activeCylinderState.speciesMassDensityKgPerM3[species] * drainRate;
                cylinderResiduals[index].totalEnergyDensityJPerM3 -=
                    (activeCylinderState.totalEnergyDensityJPerM3
                        + cylinderPrimitives[index].pressurePa) * drainRate;
            } else if (supplied.otherOutflowEnergyW != 0.0) {
                const auto inverseVolume = 1.0 / cylinderReservoirVolumesM3_[index];
                for (std::size_t species = 0; species < gasSpeciesCount; ++species)
                    cylinderResiduals[index].speciesMassDensityKgPerM3[species] -=
                        supplied.otherOutflowSpeciesKgPerS[species] * inverseVolume;
                cylinderResiduals[index].totalEnergyDensityJPerM3 -=
                    supplied.otherOutflowEnergyW * inverseVolume;
            }
        }
        if (port.networkEndpoint.type == ExhaustEndpointType::junction) {
            addJunctionFlow(port.networkEndpoint.elementIndex, cylinderFlows[index],
                openingArea, 1.0);
        } else if (!assignDuctBoundary(port.networkEndpoint, flux.ductFlux)) {
            return false;
        }
    }

    for (std::size_t index = 0; index < layout_.outlets().size(); ++index) {
        const auto& outlet = layout_.outlets()[index];
        if (outlet.networkEndpoint.type == ExhaustEndpointType::junction)
            computeOutletFlux(index);
        const auto& flux = outletFluxes_[index];
        outletFlows[index] = makeFlowRate(flux.rawFlux, flux.flowAreaM2);
        if (ambientReservoirVolumeM3_ > 0.0) {
            const auto inverseVolume = 1.0 / ambientReservoirVolumeM3_;
            for (std::size_t species = 0; species < gasSpeciesCount; ++species) {
                ambientResidual.speciesMassDensityKgPerM3[species] +=
                    outletFlows[index].speciesMassKgPerS[species] * inverseVolume;
            }
            ambientResidual.totalEnergyDensityJPerM3 +=
                outletFlows[index].totalEnergyW * inverseVolume;
        }
        if (outlet.networkEndpoint.type == ExhaustEndpointType::junction) {
            addJunctionFlow(outlet.networkEndpoint.elementIndex, outletFlows[index],
                flux.openingAreaM2, -1.0);
        } else if (!assignDuctBoundary(outlet.networkEndpoint, flux.ductFlux)) {
            return false;
        }
    }

    return std::all_of(ductInletAssigned_.begin(), ductInletAssigned_.end(),
               [](std::uint8_t assigned) { return assigned != 0; })
        && std::all_of(ductOutletAssigned_.begin(), ductOutletAssigned_.end(),
               [](std::uint8_t assigned) { return assigned != 0; });
}

bool ExhaustGasNetwork::prepareNonDuctStageStates(bool candidateStage) noexcept {
    const auto& states = candidateStage ? junctionCandidate_ : junctionStage_;
    auto& junctionPrimitives = candidateStage
        ? junctionCandidatePrimitives_ : junctionStagePrimitives_;
    for (std::size_t index = 0; index < states.size(); ++index) {
        const auto primitive = mixtureModel_.primitiveFromConservative(states[index]);
        if (!primitive) return false;
        junctionPrimitives[index] = *primitive;
    }
    const auto& reservoirs = candidateStage
        ? cylinderReservoirCandidate_ : cylinderReservoirStage_;
    auto& reservoirPrimitives = candidateStage
        ? cylinderReservoirCandidatePrimitives_ : cylinderReservoirStagePrimitives_;
    for (std::size_t index = 0; index < reservoirs.size(); ++index) {
        if (cylinderReservoirActive_[index] == 0) continue;
        if (cylinderReservoirClosed_[index] != 0
            && identicalStateBits(reservoirs[index], cylinderReservoirStates_[index])) {
            reservoirPrimitives[index] = cylinderReservoirPrimitives_[index];
            continue;
        }
        const auto primitive = mixtureModel_.primitiveFromConservative(reservoirs[index]);
        if (!primitive) return false;
        reservoirPrimitives[index] = *primitive;
    }
    if (ambientReservoirVolumeM3_ > 0.0) {
        auto& state = candidateStage ? ambientReservoirCandidate_ : ambientReservoirStage_;
        auto& primitive = candidateStage ? ambientCandidatePrimitive_ : ambientStagePrimitive_;
        if (!mixtureModel_.canonicaliseSpeciesRoundoff(state)
            || !mixtureModel_.recoverPrimitive(state, primitive))
            return false;
    }
    return true;
}

ExhaustNetworkAdvanceResult ExhaustGasNetwork::advance(
    double durationSeconds,
    std::span<const CylinderValveBoundary> cylinderBoundaries,
    const ExhaustAmbientBoundary& ambient) noexcept {
    ExhaustNetworkAdvanceResult result;
    // Every call owns its published transfers, including calls rejected before
    // accepting time. Keep accepted partial transfers if a later step fails.
    for (auto& exchange : cylinderExchanges_) {
        const auto cylinderId = exchange.cylinderId;
        const auto pathIndex = exchange.pathIndex;
        exchange = {};
        exchange.cylinderId = cylinderId;
        exchange.pathIndex = pathIndex;
    }
    for (auto& sample : outletSamples_) {
        const auto nodeId = sample.outletNodeId;
        const auto pathIndex = sample.pathIndex;
        const auto openingArea = sample.openingAreaM2;
        sample = {};
        sample.outletNodeId = nodeId;
        sample.pathIndex = pathIndex;
        sample.openingAreaM2 = openingArea;
    }
    std::fill(interfaceTransfers_.begin(), interfaceTransfers_.end(), InterfaceTransfer {});
    if (!configured_ || !finite(durationSeconds) || durationSeconds < 0.0
        || !finite(ambient.openingScale) || ambient.openingScale < 0.0
        || ambient.openingScale > 1.0 || !finite(ambient.reservoirVolumeM3)
        || ambient.reservoirVolumeM3 < 0.0) {
        result.completed = false;
        return result;
    }
    const auto ambientPrimitive = mixtureModel_.primitiveFromConservative(
        ambient.reservoirState);
    if (!ambientPrimitive) {
        result.completed = false;
        return result;
    }
    ambientPrimitive_ = *ambientPrimitive;
    ambientReservoirVolumeM3_ = ambient.reservoirVolumeM3;
    if (ambientReservoirVolumeM3_ > 0.0)
        ambientReservoirState_ = ambient.reservoirState;
    const auto ports = layout_.cylinderPorts();
    const auto suppliedInPortOrder = cylinderBoundaries.size() == ports.size()
        && std::equal(cylinderBoundaries.begin(), cylinderBoundaries.end(),
            ports.begin(), [](const CylinderValveBoundary& boundary,
                              const CompiledCylinderPort& port) {
                return boundary.cylinderId == port.cylinderId;
            });
    std::fill(cylinderBoundaryIndices_.begin(), cylinderBoundaryIndices_.end(),
              cylinderBoundaries.size());
    for (std::size_t index = 0; index < cylinderBoundaries.size(); ++index) {
        const auto& boundary = cylinderBoundaries[index];
        const auto primitive = mixtureModel_.primitiveFromConservative(
            boundary.cylinderState);
        if (!finite(boundary.cylinderVolumeM3) || !(boundary.cylinderVolumeM3 > 0.0)
            || !finite(boundary.effectiveValveAreaM2) || boundary.effectiveValveAreaM2 < 0.0
            || !finite(boundary.dischargeCoefficient) || boundary.dischargeCoefficient < 0.0
            || !validMovingBoundary(boundary) || !primitive) {
            result.completed = false;
            return result;
        }
        const auto port = suppliedInPortOrder ? ports.begin()
                + static_cast<std::ptrdiff_t>(index)
            : std::find_if(ports.begin(), ports.end(),
                [&boundary](const CompiledCylinderPort& candidate) {
                    return candidate.cylinderId == boundary.cylinderId;
                });
        if (port == ports.end()) {
            result.completed = false;
            return result;
        }
        const auto portIndex = suppliedInPortOrder ? index
            : static_cast<std::size_t>(std::distance(ports.begin(), port));
        if (cylinderBoundaryIndices_[portIndex] < cylinderBoundaries.size()) {
            result.completed = false;
            return result;
        }
        cylinderBoundaryIndices_[portIndex] = index;
        cylinderReservoirPrimitives_[portIndex] = *primitive;
    }

    for (std::size_t index = 0; index < cylinderExchanges_.size(); ++index) {
        const auto boundaryIndex = cylinderBoundaryIndices_[index];
        if (boundaryIndex < cylinderBoundaries.size()) {
            const auto& boundary = cylinderBoundaries[boundaryIndex];
            cylinderReservoirStates_[index] = boundary.cylinderState;
            cylinderReservoirVolumesM3_[index] = boundary.cylinderVolumeM3;
            cylinderReservoirInitialVolumesM3_[index] = boundary.cylinderVolumeM3;
            cylinderReservoirActive_[index] = 1;
            cylinderReservoirClosed_[index] = (boundary.effectiveValveAreaM2 == 0.0
                    && boundary.effectiveValveAreaRateM2PerS <= 0.0
                    && boundary.cylinderVolumeRateM3PerS == 0.0
                    && boundary.otherOutflowEnergyW == 0.0)
                || boundary.dischargeCoefficient == 0.0;
        } else {
            cylinderReservoirStates_[index] = {};
            cylinderReservoirVolumesM3_[index] = 0.0;
            cylinderReservoirInitialVolumesM3_[index] = 0.0;
            cylinderReservoirActive_[index] = 0;
            cylinderReservoirClosed_[index] = 0;
        }
    }
    if (durationSeconds == 0.0) {
        updateOutletSamples(0.0);
        return result;
    }

    auto remaining = durationSeconds;
    auto attempts = std::size_t { 0 };
    const auto completionTolerance = std::max(1.0e-15, durationSeconds * 1.0e-13);
    // Places the moving boundaries at `elapsedSeconds` into this advance. With
    // no supplied rates every volume stays exactly at its initial value.
    const auto placeBoundaries = [&](double elapsedSeconds) noexcept {
        boundaryElapsedSeconds_ = elapsedSeconds;
        for (std::size_t index = 0; index < cylinderReservoirVolumesM3_.size(); ++index) {
            const auto boundaryIndex = cylinderBoundaryIndices_[index];
            if (boundaryIndex >= cylinderBoundaries.size()) continue;
            const auto rate = cylinderBoundaries[boundaryIndex].cylinderVolumeRateM3PerS;
            if (rate == 0.0) continue;
            const auto initial = cylinderReservoirInitialVolumesM3_[index];
            cylinderReservoirVolumesM3_[index] = std::max(0.25 * initial,
                initial + rate * elapsedSeconds);
        }
    };
    while (remaining > completionTolerance
           && attempts < config_.maximumSubstepsPerAdvance) {
        placeBoundaries(durationSeconds - remaining);
        const auto stableStep = maximumStableTimeStep(cylinderBoundaries, ambient);
        if (!(stableStep > 0.0) || !finite(stableStep)) {
            result.completed = false;
            break;
        }
        auto trialStep = std::min(remaining, stableStep);
        auto accepted = false;
        while (!accepted && attempts < config_.maximumSubstepsPerAdvance) {
            ++attempts;
            placeBoundaries(durationSeconds - remaining);
            hancockHalfStepSeconds_ = config_.firstOrderTimeIntegration
                    && config_.hancockPredictor ? 0.5 * trialStep : 0.0;
            const auto firstStagePassed = evaluateStage(false, cylinderBoundaries, ambient);
            hancockHalfStepSeconds_ = 0.0;
            if (!firstStagePassed) {
                result.completed = false;
                break;
            }
            const auto rejectAttempt = [&]() noexcept {
                ++result.rejectedSubsteps;
                trialStep *= 0.5;
                return trialStep > std::numeric_limits<double>::epsilon()
                    * std::max(1.0, durationSeconds);
            };
            // Euler stage of everything that is not a duct first: it reads
            // only this step's residuals, and the ducts' second-stage pass
            // below needs these stage primitives (reservoir faces, the shared
            // reservoir's state).
            for (std::size_t index = 0; index < junctionStates_.size(); ++index) {
                junctionStage_[index] = addScaled(
                    junctionStates_[index], junctionResidual_[index], trialStep);
                if (!config_.evolveJunctionAxialMomentum)
                    junctionStage_[index].momentumDensityKgPerM2S = 0.0;
            }
            for (std::size_t index = 0; index < cylinderReservoirStates_.size(); ++index) {
                if (cylinderReservoirActive_[index] == 0) continue;
                cylinderReservoirStage_[index] = addScaled(
                    cylinderReservoirStates_[index],
                    cylinderReservoirResidual_[index], trialStep);
                cylinderReservoirStage_[index].momentumDensityKgPerM2S = 0.0;
            }
            if (ambientReservoirVolumeM3_ > 0.0) {
                ambientReservoirStage_ = addScaled(ambientReservoirState_,
                    ambientReservoirResidual_, trialStep);
                ambientReservoirStage_.momentumDensityKgPerM2S = 0.0;
            }
            for (auto& state : junctionStage_)
                (void) mixtureModel_.canonicaliseSpeciesRoundoff(state);
            for (std::size_t index = 0; index < cylinderReservoirStage_.size(); ++index)
                if (cylinderReservoirActive_[index] != 0)
                    (void) mixtureModel_.canonicaliseSpeciesRoundoff(
                        cylinderReservoirStage_[index]);
            if (!prepareNonDuctStageStates(false)) {
                if (!rejectAttempt()) break;
                continue;
            }

            // Each duct's Euler update, round-off canonicalisation and
            // primitive/source cache, and (for RK2) its second-stage interior
            // residual and boundary face fluxes, form one per-duct pass, so a
            // parallel schedule crosses a single barrier here. A duct whose
            // own stage is inadmissible rejects the attempt; a stage that is
            // admissible but cannot be evaluated ends the advance, as before.
            std::fill(ductStageRejected_.begin(), ductStageRejected_.end(),
                      std::uint8_t { 0 });
            const auto eulerStage = [&](std::size_t ductIndex) noexcept {
                auto& duct = ducts_[ductIndex];
                for (std::size_t index = 0; index < duct.cells_.size(); ++index)
                    duct.stage_[index] = addScaled(
                        duct.cells_[index], duct.residual_[index], trialStep);
                for (auto& state : duct.stage_)
                    (void) mixtureModel_.canonicaliseSpeciesRoundoff(state);
                if (duct.prepareStateCache(duct.stage_, duct.stagePrimitives_,
                        duct.stageSourceTerms_, duct.maximumStageSignalSpeedMps_,
                        duct.stageSourceLimitedTimeStepSeconds_))
                    return true;
                ductStageRejected_[ductIndex] = 1;
                return false;
            };
            const auto stageRejected = [&]() noexcept {
                return std::any_of(ductStageRejected_.begin(), ductStageRejected_.end(),
                    [](std::uint8_t rejected) { return rejected != 0; });
            };

            if (config_.firstOrderTimeIntegration) {
                if (!forEachDuct(eulerStage)) {
                    if (!rejectAttempt()) break;
                    continue;
                }
                // The validated stage is the conservative Euler candidate.
                // Reuse the normal candidate/commit path so positivity, wall
                // heat and conservation accounting remain common with RK2.
                junctionCandidate_ = junctionStage_;
                cylinderReservoirCandidate_ = cylinderReservoirStage_;
                if (ambientReservoirVolumeM3_ > 0.0)
                    ambientReservoirCandidate_ = ambientReservoirStage_;
                // The trapezoidal transfer accounting below becomes exactly
                // dt*f(U_n) when both slots carry the first-stage flow.
                cylinderSecondStageFlow_ = cylinderFirstStageFlow_;
                outletSecondStageFlow_ = outletFirstStageFlow_;
                interfaceSecondStageRate_ = interfaceFirstStageRate_;
            } else {
                placeBoundaries(durationSeconds - remaining + trialStep);
                // Reconstructing across interfaces, a duct's second-stage pass
                // reads its neighbours' stage states: every Euler stage first.
                const auto stagePassed = config_.reconstructAcrossInterfaces
                    ? forEachDuct(eulerStage)
                        && evaluateStage(true, cylinderBoundaries, ambient,
                            StagePart::ductPass, [](std::size_t) noexcept { return true; })
                    : evaluateStage(true, cylinderBoundaries,
                        ambient, StagePart::ductPass, eulerStage);
                if (stageRejected()) {
                    if (!rejectAttempt()) break;
                    continue;
                }
                if (!stagePassed || !evaluateStage(true, cylinderBoundaries, ambient,
                        StagePart::coupling,
                        [](std::size_t) noexcept { return true; })) {
                    result.completed = false;
                    break;
                }
                for (std::size_t index = 0; index < junctionStates_.size(); ++index) {
                    junctionCandidate_[index] = rk2Combination(
                        junctionStates_[index], junctionStage_[index],
                        junctionStageResidual_[index], trialStep);
                    if (!config_.evolveJunctionAxialMomentum)
                        junctionCandidate_[index].momentumDensityKgPerM2S = 0.0;
                }
                for (std::size_t index = 0;
                     index < cylinderReservoirStates_.size(); ++index) {
                    if (cylinderReservoirActive_[index] == 0) continue;
                    cylinderReservoirCandidate_[index] = rk2Combination(
                        cylinderReservoirStates_[index],
                        cylinderReservoirStage_[index],
                        cylinderReservoirStageResidual_[index], trialStep);
                    cylinderReservoirCandidate_[index].momentumDensityKgPerM2S = 0.0;
                }
                if (ambientReservoirVolumeM3_ > 0.0) {
                    ambientReservoirCandidate_ = rk2Combination(ambientReservoirState_,
                        ambientReservoirStage_, ambientReservoirStageResidual_, trialStep);
                    ambientReservoirCandidate_.momentumDensityKgPerM2S = 0.0;
                }
            }
            for (auto& state : junctionCandidate_)
                (void) mixtureModel_.canonicaliseSpeciesRoundoff(state);
            for (std::size_t index = 0; index < cylinderReservoirCandidate_.size(); ++index)
                if (cylinderReservoirActive_[index] != 0)
                    (void) mixtureModel_.canonicaliseSpeciesRoundoff(
                        cylinderReservoirCandidate_[index]);
            // Decided before any work from this attempt's own trial step, so a
            // halved retry re-decides consistently and nothing is committed
            // until the sub-step is accepted. A duct only defers its candidate
            // cache when its walls are actually going to run; skipping the
            // exchange therefore also skips the extra `recoverPrimitiveStates`
            // pass that exists solely to feed it, which is the larger half of
            // what sub-rating buys.
            const auto wallPendingSeconds = wallHeatPendingSeconds_ + trialStep;
            const auto applyWallHeat = config_.wallHeatUpdateExternallyTriggered
                ? wallHeatUpdateRequested_
                : wallPendingSeconds >= config_.wallHeatUpdateIntervalSeconds;
            // Candidate: RK2 combination (or the Euler stage), canonicalisation,
            // wall heat and cache, again one per-duct pass.
            const auto firstOrder = config_.firstOrderTimeIntegration;
            const auto candidateStage = [&](std::size_t ductIndex) noexcept {
                auto& duct = ducts_[ductIndex];
                const auto wallHeat = applyWallHeat
                    && duct.geometry_.dynamicWallHeatTransferEnabled;
                if (firstOrder) {
                    // The Euler stage is the candidate, already canonical, and
                    // its cache was prepared with it: only a wall exchange
                    // changes it again. The next stage overwrites `stage_`.
                    duct.candidate_.swap(duct.stage_);
                    duct.candidatePrimitives_.swap(duct.stagePrimitives_);
                    duct.candidateSourceTerms_.swap(duct.stageSourceTerms_);
                    duct.maximumCandidateSignalSpeedMps_ = duct.maximumStageSignalSpeedMps_;
                    duct.candidateSourceLimitedTimeStepSeconds_ =
                        duct.stageSourceLimitedTimeStepSeconds_;
                    if (!wallHeat) {
                        ductWallHeatRejectedJ_[ductIndex] = 0.0;
                        return true;
                    }
                } else {
                    for (std::size_t index = 0; index < duct.cells_.size(); ++index)
                        duct.candidate_[index] = rk2Combination(
                            duct.cells_[index], duct.stage_[index],
                            duct.stageResidual_[index], trialStep);
                }
                for (auto& state : duct.candidate_)
                    (void) mixtureModel_.canonicaliseSpeciesRoundoff(state);
                auto& heatRejectedJ = ductWallHeatRejectedJ_[ductIndex];
                heatRejectedJ = 0.0;
                if (wallHeat) {
                    if (!duct.recoverPrimitiveStates(
                            duct.candidate_, duct.candidatePrimitives_))
                        return false;
                    duct.candidateWallStates_ = duct.wallStates_;
                    if (!duct.applyDynamicWallHeatTransfer(
                            duct.candidate_, duct.candidatePrimitives_,
                            duct.candidateWallStates_, wallPendingSeconds,
                            heatRejectedJ))
                        return false;
                }
                return duct.prepareStateCache(
                    duct.candidate_, duct.candidatePrimitives_,
                    duct.candidateSourceTerms_,
                    duct.maximumCandidateSignalSpeedMps_,
                    duct.candidateSourceLimitedTimeStepSeconds_);
            };
            const auto ductCandidatesValid = forEachDuct(candidateStage);
            if (!ductCandidatesValid || !prepareNonDuctStageStates(true)) {
                ++result.rejectedSubsteps;
                trialStep *= 0.5;
                if (!(trialStep > std::numeric_limits<double>::epsilon()
                                  * std::max(1.0, durationSeconds)))
                    break;
                continue;
            }
            auto candidateWallHeatRejectedJ = 0.0;
            if (applyWallHeat)
                for (const auto heatRejectedJ : ductWallHeatRejectedJ_)
                    candidateWallHeatRejectedJ += heatRejectedJ;

            const auto integrationWeight = 0.5 * trialStep;
            for (std::size_t index = 0; index < cylinderExchanges_.size(); ++index) {
                for (std::size_t species = 0; species < gasSpeciesCount; ++species) {
                    cylinderExchanges_[index].speciesMassKg[species] += integrationWeight
                        * (cylinderFirstStageFlow_[index].speciesMassKgPerS[species]
                           + cylinderSecondStageFlow_[index].speciesMassKgPerS[species]);
                }
                cylinderExchanges_[index].totalEnergyJ += integrationWeight
                    * (cylinderFirstStageFlow_[index].totalEnergyW
                       + cylinderSecondStageFlow_[index].totalEnergyW);
                cylinderExchanges_[index].axialMomentumImpulseNs += integrationWeight
                    * (cylinderFirstStageFlow_[index].momentumN
                       + cylinderSecondStageFlow_[index].momentumN);
            }
            for (std::size_t index = 0; index < outletSamples_.size(); ++index) {
                for (std::size_t species = 0; species < gasSpeciesCount; ++species) {
                    outletSamples_[index].speciesMassKg[species] += integrationWeight
                        * (outletFirstStageFlow_[index].speciesMassKgPerS[species]
                           + outletSecondStageFlow_[index].speciesMassKgPerS[species]);
                }
                outletSamples_[index].transferredEnergyJ += integrationWeight
                    * (outletFirstStageFlow_[index].totalEnergyW
                       + outletSecondStageFlow_[index].totalEnergyW);
            }
            for (std::size_t index = 0; index < interfaceTransfers_.size(); ++index) {
                interfaceTransfers_[index].massKg += integrationWeight
                    * (interfaceFirstStageRate_[index].massKg
                       + interfaceSecondStageRate_[index].massKg);
                interfaceTransfers_[index].workJ += integrationWeight
                    * (interfaceFirstStageRate_[index].workJ
                       + interfaceSecondStageRate_[index].workJ);
            }

            for (auto& duct : ducts_) {
                if (duct.cellLengthM_ > 0.0) {
                    const auto stepPerLength = trialStep / duct.cellLengthM_;
                    result.maximumAcceptedDuctCourantCurrent = std::max(
                        result.maximumAcceptedDuctCourantCurrent,
                        stepPerLength * duct.maximumCellSignalSpeedMps_);
                    result.maximumAcceptedDuctCourantPredictor = std::max(
                        result.maximumAcceptedDuctCourantPredictor,
                        stepPerLength * duct.maximumStageSignalSpeedMps_);
                }
                duct.cells_.swap(duct.candidate_);
                duct.cellPrimitives_.swap(duct.candidatePrimitives_);
                duct.cellSourceTerms_.swap(duct.candidateSourceTerms_);
                std::swap(duct.maximumCellSignalSpeedMps_,
                          duct.maximumCandidateSignalSpeedMps_);
                std::swap(duct.cellSourceLimitedTimeStepSeconds_,
                          duct.candidateSourceLimitedTimeStepSeconds_);
                duct.cellStateCacheIsValid_ = true;
                if (applyWallHeat
                    && duct.geometry_.dynamicWallHeatTransferEnabled)
                    duct.wallStates_.swap(duct.candidateWallStates_);
            }
            if (applyWallHeat) {
                wallHeatPendingSeconds_ = 0.0;
                wallHeatUpdateRequested_ = false;
            } else {
                wallHeatPendingSeconds_ = wallPendingSeconds;
            }
            result.wallHeatRejectedJ += candidateWallHeatRejectedJ;
            if (!result.completed) break;
            junctionStates_.swap(junctionCandidate_);
            junctionPrimitives_.swap(junctionCandidatePrimitives_);
            cylinderReservoirStates_.swap(cylinderReservoirCandidate_);
            cylinderReservoirPrimitives_.swap(
                cylinderReservoirCandidatePrimitives_);
            if (ambientReservoirVolumeM3_ > 0.0) {
                ambientReservoirState_ = ambientReservoirCandidate_;
                ambientPrimitive_ = ambientCandidatePrimitive_;
            }
            remaining -= trialStep;
            result.advancedTimeSeconds += trialStep;
            result.minimumAcceptedTimeStepSeconds = result.acceptedSubsteps == 0
                ? trialStep
                : std::min(result.minimumAcceptedTimeStepSeconds, trialStep);
            result.maximumAcceptedTimeStepSeconds = std::max(
                result.maximumAcceptedTimeStepSeconds, trialStep);
            result.maximumAcceptedStableStepRatio = std::max(
                result.maximumAcceptedStableStepRatio, trialStep / stableStep);
            ++result.acceptedSubsteps;
            accepted = true;
        }
        if (!accepted) {
            result.completed = false;
            break;
        }
    }
    if (remaining > completionTolerance) result.completed = false;
    boundaryElapsedSeconds_ = 0.0;
    updateOutletSamples(result.advancedTimeSeconds);
    return result;
}

std::optional<ExhaustOutletFlowSample> ExhaustGasNetwork::predictOutletTransfer(
    std::size_t outletIndex,
    const ExhaustAmbientBoundary& ambient,
    double durationSeconds) const noexcept {
    if (!configured_ || outletIndex >= layout_.outlets().size()) return std::nullopt;
    if (!finite(durationSeconds) || !(durationSeconds > 0.0)) return std::nullopt;
    const auto& outlet = layout_.outlets()[outletIndex];
    // Only a plain duct end is supported. A junction's primitive cache is not
    // owned by a duct and no compiled runner layout produces one here.
    if (outlet.networkEndpoint.type == ExhaustEndpointType::junction)
        return std::nullopt;
    const auto& duct = ducts_[outlet.networkEndpoint.elementIndex];
    if (duct.cells_.size() < 2 || !duct.refreshCellStateCache()) return std::nullopt;
    const auto& compiled = layout_.ducts()[outlet.networkEndpoint.elementIndex];
    const auto isInlet = outlet.networkEndpoint.type == ExhaustEndpointType::ductInlet;
    const auto& interiorState = isInlet ? duct.cells_.front() : duct.cells_.back();
    const auto& interiorPrimitive =
        isInlet ? duct.cellPrimitives_.front() : duct.cellPrimitives_.back();
    const auto connectionAreaM2 = isInlet
        ? std::min(compiled.inletConnectionAreaM2, compiled.inletFlowAreaM2)
        : std::min(compiled.outletConnectionAreaM2, compiled.outletFlowAreaM2);
    const auto openingArea = std::min(connectionAreaM2,
        outlet.openingAreaM2 * outlet.dischargeCoefficient
            * std::clamp(ambient.openingScale, 0.0, 1.0));

    ExhaustOutletFlowSample sample;
    sample.outletNodeId = outlet.outletNodeId;
    sample.pathIndex = outlet.pathIndex;
    sample.openingAreaM2 = outlet.openingAreaM2;
    if (!(openingArea > 0.0)) return sample;

    PrimitiveState reservoirPrimitive;
    if (!mixtureModel_.recoverPrimitive(ambient.reservoirState, reservoirPrimitive))
        return std::nullopt;
    // Same characteristic open-end treatment `evaluateStage` uses, with the
    // same Riemann-ghost fallback, so the prediction is the flux the advance
    // would start from rather than a second, differently-behaved boundary.
    const auto mouthFlux = [&](const ConservativeState& state,
                               const PrimitiveState& primitive) noexcept {
        const auto ghost = openEndBoundaryPrimitive(primitive, reservoirPrimitive);
        const auto ghostState = ghost
            ? mixtureModel_.conservativeFromPrimitive(
                ghost->densityKgPerM3, ghost->velocityMps, ghost->pressurePa,
                GasComposition { ghost->massFractions })
            : std::nullopt;
        return ghostState
            ? mixtureModel_.riemannFluxPrepared(state, primitive, *ghostState, *ghost)
            : mixtureModel_.riemannFluxPrepared(
                state, primitive, ambient.reservoirState, reservoirPrimitive);
    };
    const auto firstFlux = mouthFlux(interiorState, interiorPrimitive);

    // Heun on a local terminal-cell copy with its full current finite-volume
    // residual. The internal face and geometric pressure force must balance
    // the mouth even at rest; using the mouth alone invents a momentum change
    // and therefore a transfer in a network that advance leaves at equilibrium.
    auto secondFlux = firstFlux;
    const auto terminalFaceAreaM2 = isInlet
        ? duct.faceAreasM2_.front() : duct.faceAreasM2_.back();
    const auto boundaryFlux = areaAveragedBoundaryFlux(firstFlux, openingArea,
        terminalFaceAreaM2, interiorPrimitive.pressurePa);
    ConservativeState terminalResidual;
    if (!duct.currentTerminalCellResidual(isInlet, boundaryFlux, terminalResidual))
        return std::nullopt;
    {
        auto predictedState = interiorState;
        for (std::size_t species = 0; species < gasSpeciesCount; ++species) {
            predictedState.speciesMassDensityKgPerM3[species] +=
                terminalResidual.speciesMassDensityKgPerM3[species] * durationSeconds;
        }
        predictedState.momentumDensityKgPerM2S +=
            terminalResidual.momentumDensityKgPerM2S * durationSeconds;
        predictedState.totalEnergyDensityJPerM3 +=
            terminalResidual.totalEnergyDensityJPerM3 * durationSeconds;
        PrimitiveState predictedPrimitive;
        // An inadmissible extrapolation just falls back to the one-stage
        // estimate rather than poisoning the staircase.
        if (mixtureModel_.canonicaliseSpeciesRoundoff(predictedState)
            && mixtureModel_.recoverPrimitive(predictedState, predictedPrimitive))
            secondFlux = mouthFlux(predictedState, predictedPrimitive);
    }

    // No orientation flip: `outletSamples_` accumulates makeFlowRate(rawFlux,
    // area) unsigned by endpoint type, so a prediction that flipped it would
    // not be comparable with the transfer it is standing in for.
    const auto scale = 0.5 * openingArea * durationSeconds;
    for (std::size_t species = 0; species < gasSpeciesCount; ++species) {
        sample.speciesMassKg[species] = scale
            * (firstFlux.speciesMassFluxKgPerM2S[species]
               + secondFlux.speciesMassFluxKgPerM2S[species]);
    }
    sample.transferredEnergyJ = scale
        * (firstFlux.totalEnergyFluxWPerM2 + secondFlux.totalEnergyFluxWPerM2);
    sample.staticPressurePa = interiorPrimitive.pressurePa;
    sample.temperatureK = interiorPrimitive.temperatureK;
    sample.densityKgPerM3 = interiorPrimitive.densityKgPerM3;
    sample.speedOfSoundMps = interiorPrimitive.speedOfSoundMps;
    sample.axialVelocityMps = interiorPrimitive.velocityMps;
    if (durationSeconds > 0.0) {
        auto massKg = 0.0;
        for (const auto species : sample.speciesMassKg) massKg += species;
        sample.massFlowKgPerS = massKg / durationSeconds;
        sample.totalEnergyFlowW = sample.transferredEnergyJ / durationSeconds;
        sample.volumeFlowM3PerS = sample.densityKgPerM3 > 0.0
            ? sample.massFlowKgPerS / sample.densityKgPerM3 : 0.0;
    }
    return sample;
}

bool ExhaustGasNetwork::injectSpeciesAtPort(std::size_t portIndex,
                                            GasSpecies species,
                                            double massKg,
                                            double temperatureK,
                                            double additionalHeatJ) noexcept {
    if (!configured_ || portIndex >= layout_.cylinderPorts().size()) return false;
    if (!finite(massKg) || massKg < 0.0 || !finite(temperatureK)
        || temperatureK <= 0.0 || !finite(additionalHeatJ))
        return false;
    if (massKg == 0.0 && additionalHeatJ == 0.0) return true;
    const auto& endpoint = layout_.cylinderPorts()[portIndex].networkEndpoint;
    if (endpoint.type == ExhaustEndpointType::junction) return false;
    return injectSpeciesAtDuctEnd(endpoint, species, massKg, temperatureK, additionalHeatJ);
}

bool ExhaustGasNetwork::injectSpeciesAtDuctInlet(std::size_t ductIndex,
                                                 GasSpecies species,
                                                 double massKg,
                                                 double temperatureK,
                                                 double additionalHeatJ) noexcept {
    if (!configured_ || ductIndex >= ducts_.size()) return false;
    if (!finite(massKg) || massKg < 0.0 || !finite(temperatureK)
        || temperatureK <= 0.0 || !finite(additionalHeatJ))
        return false;
    if (massKg == 0.0 && additionalHeatJ == 0.0) return true;
    return injectSpeciesAtDuctEnd({ ExhaustEndpointType::ductInlet, ductIndex, 0 },
        species, massKg, temperatureK, additionalHeatJ);
}

bool ExhaustGasNetwork::injectSpeciesAtDuctEnd(const ExhaustEndpoint& endpoint,
                                               GasSpecies species,
                                               double massKg,
                                               double temperatureK,
                                               double additionalHeatJ) noexcept {
    auto& duct = ducts_[endpoint.elementIndex];
    // The source is spread over the spray-and-film footprint next to the
    // valve, not an arbitrary number of mesh cells. A port injector cone wets
    // roughly a few centimetres. The old fixed three-cell footprint therefore
    // changed physical length with solver resolution: 60 mm on a fine 20 mm
    // mesh but 285 mm on the realtime 95 mm mesh, placing most of the fuel far
    // upstream and creating the severe lean/misfire interval after DFCO. Keep
    // the footprint at about 60 mm, bounded to the original three cells. A
    // coarse first cell already represents a sufficiently large volume to
    // avoid the single-sliver cooling failure measured on the 2.25 L/cyl V12.
    constexpr double sprayAndFilmFootprintM = 0.060;
    const auto spreadCells = std::min<std::size_t>(
        3, std::min(duct.cells_.size(),
            std::max<std::size_t>(1, static_cast<std::size_t>(std::ceil(
                sprayAndFilmFootprintM / duct.geometry_.cellLengthM())))));
    if (spreadCells == 0) return false;
    const auto speciesIndex = static_cast<std::size_t>(species);
    const auto share = 1.0 / static_cast<double>(spreadCells);
    const auto energyShareJ = (massKg
        * mixtureModel_.speciesInternalEnergyJPerKg(speciesIndex, temperatureK)
        + additionalHeatJ) * share;
    // All-or-nothing: every touched cell must stay admissible before any is
    // committed, so a pathological command cannot half-apply.
    std::array<ConservativeState, 3> candidates {};
    for (std::size_t offset = 0; offset < spreadCells; ++offset) {
        const auto cellIndex = endpoint.type == ExhaustEndpointType::ductInlet
            ? offset : duct.cells_.size() - 1 - offset;
        const auto cellVolumeM3 = duct.geometry_.cellVolumeM3(cellIndex);
        if (!(cellVolumeM3 > 0.0)) return false;
        auto candidate = duct.cells_[cellIndex];
        candidate.speciesMassDensityKgPerM3[speciesIndex] +=
            massKg * share / cellVolumeM3;
        candidate.totalEnergyDensityJPerM3 += energyShareJ / cellVolumeM3;
        if (!mixtureModel_.isPhysical(candidate)) return false;
        candidates[offset] = candidate;
    }
    for (std::size_t offset = 0; offset < spreadCells; ++offset) {
        const auto cellIndex = endpoint.type == ExhaustEndpointType::ductInlet
            ? offset : duct.cells_.size() - 1 - offset;
        duct.cells_[cellIndex] = candidates[offset];
    }
    duct.cellStateCacheIsValid_ = false;
    return true;
}

void ExhaustGasNetwork::updateOutletSamples(double durationSeconds) noexcept {
    const auto endpointPrimitive = [this](const ExhaustEndpoint& endpoint)
        -> const PrimitiveState& {
        if (endpoint.type == ExhaustEndpointType::junction)
            return junctionPrimitives_[endpoint.elementIndex];
        const auto& primitives = ducts_[endpoint.elementIndex].cellPrimitives_;
        return endpoint.type == ExhaustEndpointType::ductInlet
            ? primitives.front() : primitives.back();
    };
    for (std::size_t index = 0; index < cylinderExchanges_.size(); ++index) {
        if (cylinderReservoirActive_[index] != 0) {
            const auto& cylinderPrimitive = cylinderReservoirPrimitives_[index];
            cylinderExchanges_[index].cylinderPressurePaAfter =
                cylinderPrimitive.pressurePa;
            cylinderExchanges_[index].cylinderTemperatureKAfter =
                cylinderPrimitive.temperatureK;
        }
        const auto& endpoint = layout_.cylinderPorts()[index].networkEndpoint;
        const auto& primitive = endpointPrimitive(endpoint);
        cylinderExchanges_[index].networkPressurePa = primitive.pressurePa;
        cylinderExchanges_[index].networkTemperatureK = primitive.temperatureK;
        cylinderExchanges_[index].networkDensityKgPerM3 = primitive.densityKgPerM3;
        cylinderExchanges_[index].networkVelocityMps = primitive.velocityMps;
        cylinderExchanges_[index].networkSpeedOfSoundMps = primitive.speedOfSoundMps;
    }
    for (std::size_t index = 0; index < outletSamples_.size(); ++index) {
        auto& sample = outletSamples_[index];
        const auto& endpoint = layout_.outlets()[index].networkEndpoint;
        const auto& primitive = endpointPrimitive(endpoint);
        sample.staticPressurePa = primitive.pressurePa;
        sample.temperatureK = primitive.temperatureK;
        sample.axialVelocityMps = primitive.velocityMps;
        sample.densityKgPerM3 = primitive.densityKgPerM3;
        sample.speedOfSoundMps = primitive.speedOfSoundMps;
        if (durationSeconds > 0.0) {
            sample.massFlowKgPerS = sumSpecies(sample.speciesMassKg) / durationSeconds;
            sample.totalEnergyFlowW = sample.transferredEnergyJ / durationSeconds;
            sample.volumeFlowM3PerS = sample.densityKgPerM3 > 0.0
                ? sample.massFlowKgPerS / sample.densityKgPerM3 : 0.0;
        }
    }
}

} // namespace enginelab::gasdynamics
