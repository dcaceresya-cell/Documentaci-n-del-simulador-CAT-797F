#include <enginelab/foundation/EngineTypes.hpp>
#include <enginelab/foundation/CatalystMonolithGeometry.hpp>
#include <enginelab/exhaust/ExhaustGraph.hpp>
#include <enginelab/gasdynamics/ExhaustNetworkLayout.hpp>

#include <algorithm>
#include <cmath>
#include <cstdlib>
#include <iostream>
#include <numbers>
#include <numeric>
#include <string_view>

namespace {

using namespace enginelab;
using namespace enginelab::gasdynamics;

void requireLayout(bool condition, std::string_view message) {
    if (condition) return;
    std::cerr << "FAILED: " << message << '\n';
    std::exit(EXIT_FAILURE);
}

[[nodiscard]] ExhaustComponentConfig component(std::uint32_t id,
                                                ExhaustComponentType type,
                                                double lengthMm,
                                                double diameterMm) {
    ExhaustComponentConfig result;
    result.id = id;
    result.type = type;
    result.lengthMm = lengthMm;
    result.diameterMm = diameterMm;
    return result;
}

[[nodiscard]] EngineConfig customNetworkConfig(double audioGain = 1.0) {
    auto config = makeDefaultInlineFour();
    auto& path = config.exhaustPaths.front();
    path.audioVolume = audioGain;
    ExhaustNetworkConfig network;
    for (std::size_t index = 0; index < config.cylinders.size(); ++index) {
        const auto id = static_cast<std::uint32_t>(101 + index);
        auto primary = component(id, ExhaustComponentType::pipe,
                                 440.0 + 10.0 * static_cast<double>(index), 41.0);
        primary.restriction = 0.015;
        primary.dischargeCoefficient = 0.81;
        network.components.push_back(primary);
        network.cylinderConnections.push_back({ config.cylinders[index].id, id });
        network.connections.push_back({ id, 200 });
    }
    auto merge = component(200, ExhaustComponentType::merge, 0.0, 60.0);
    merge.volumeLitres = 0.42;
    network.components.push_back(merge);
    auto muffler = component(300, ExhaustComponentType::muffler, 500.0, 62.0);
    muffler.volumeLitres = 8.0;
    muffler.restriction = 0.24;
    network.components.push_back(muffler);
    auto outlet = component(400, ExhaustComponentType::outlet, 160.0, 70.0);
    outlet.dischargeCoefficient = 0.76;
    network.components.push_back(outlet);
    network.connections.push_back({ 200, 300 });
    network.connections.push_back({ 300, 400 });
    path.network = std::move(network);
    normaliseEngineConfig(config);
    return config;
}

void testAuthoredTopologyCompilation() {
    const auto config = customNetworkConfig();
    requireLayout(!validateEngineConfig(config), "layout fixture must be a valid authored graph");
    const auto graph = ExhaustGraph::makeForEngine(config);
    const auto layout = ExhaustNetworkLayout::compile(graph);
    requireLayout(layout.valid(), "valid authored graph must compile to a physical layout");
    requireLayout(layout.ducts().size() == 6,
                  "four primaries, chamber and outlet must remain distinct ducts");
    requireLayout(layout.junctions().size() == 1,
                  "only the authored merge may become a well-mixed junction");
    requireLayout(layout.interfaces().size() == 6,
                  "all non-cylinder graph edges must survive as physical interfaces");
    requireLayout(layout.cylinderPorts().size() == config.cylinders.size(),
                  "each cylinder must own one valve-to-network boundary");
    requireLayout(layout.outlets().size() == 1,
                  "the authored terminal component must become one physical outlet");

    const auto muffler = std::find_if(layout.ducts().begin(), layout.ducts().end(),
        [](const CompiledExhaustDuct& duct) { return duct.sourceComponentId == 300; });
    requireLayout(muffler != layout.ducts().end(), "muffler duct is missing");
    requireLayout(std::abs(muffler->volumeM3 - 0.008) < 1.0e-12
            && std::abs(muffler->flowAreaM2 - 0.016) < 1.0e-12
            && muffler->areaWasDerivedFromVolume,
        "an explicit chamber volume must determine resolved flow area exactly");
    requireLayout(std::abs(muffler->lossCoefficient - 0.24) < 1.0e-12,
        "the physical solver must receive authored local K without legacy geometric reduction");

    const auto merge = layout.junctions().front();
    requireLayout(std::abs(merge.volumeM3 - 0.00042) < 1.0e-12
            && !merge.volumeWasDerived,
        "an authored junction volume must remain authoritative");
    const auto outlet = layout.outlets().front();
    requireLayout(outlet.networkEndpoint.type == ExhaustEndpointType::ductOutlet
            && std::abs(outlet.dischargeCoefficient - 0.76) < 1.0e-12,
        "outlet area and discharge must be exposed at the terminal duct face");
    requireLayout(std::all_of(layout.cylinderPorts().begin(), layout.cylinderPorts().end(),
        [](const CompiledCylinderPort& port) {
            return port.networkEndpoint.type == ExhaustEndpointType::ductInlet
                && port.runnerConnectionAreaM2 > 0.0
                && std::abs(port.dischargeCoefficient - 0.81) < 1.0e-12;
        }), "authored primary throats must be retained for every cylinder");
    const auto summedCells = std::accumulate(layout.ducts().begin(), layout.ducts().end(),
        std::size_t { 0 }, [](std::size_t sum, const CompiledExhaustDuct& duct) {
            return sum + duct.cellCount;
        });
    requireLayout(summedCells == layout.totalCellCount() && summedCells > 40,
        "reported network cell count must equal the preallocated duct meshes");
}

void testAudioFieldsCannotChangePhysicalLayout() {
    auto quietConfig = customNetworkConfig(0.0);
    auto loudConfig = customNetworkConfig(8.0);
    for (auto& componentConfig : quietConfig.exhaustPaths.front().network->components)
        componentConfig.acousticGain = 0.0;
    for (auto& componentConfig : loudConfig.exhaustPaths.front().network->components)
        componentConfig.acousticGain = 8.0;
    const auto quiet = ExhaustNetworkLayout::compile(ExhaustGraph::makeForEngine(quietConfig));
    const auto loud = ExhaustNetworkLayout::compile(ExhaustGraph::makeForEngine(loudConfig));
    requireLayout(quiet.valid() && loud.valid() && quiet.ducts().size() == loud.ducts().size(),
        "audio-independence fixtures must compile equally");
    for (std::size_t index = 0; index < quiet.ducts().size(); ++index) {
        const auto& first = quiet.ducts()[index];
        const auto& second = loud.ducts()[index];
        requireLayout(first.nodeId == second.nodeId
                && first.lengthM == second.lengthM
                && first.flowAreaM2 == second.flowAreaM2
                && first.lossCoefficient == second.lossCoefficient
                && first.cellCount == second.cellCount,
            "audio gain and path volume must not leak into gas geometry");
    }
}

void testLegacyTopologyCompilation() {
    const auto config = makeDefaultInlineFour();
    const auto graph = ExhaustGraph::makeForEngine(config);
    const auto layout = ExhaustNetworkLayout::compile(graph);
    requireLayout(layout.valid(), "legacy geometry must compile without an authored DAG");
    requireLayout(layout.cylinderPorts().size() == config.cylinders.size(),
        "legacy root pipes must expose implicit cylinder boundaries");
    requireLayout(layout.ducts().size() == config.cylinders.size() + 2
            && layout.junctions().size() == 1 && layout.outlets().size() == 1,
        "legacy geometry must become primaries, merge, chamber and outlet");
    requireLayout(std::all_of(layout.cylinderPorts().begin(), layout.cylinderPorts().end(),
        [](const CompiledCylinderPort& port) {
            return port.networkEndpoint.type == ExhaustEndpointType::ductInlet;
        }), "legacy cylinder IDs must map to primary inlets, not artificial plenums");
}

void testAuthoredTaperSurvivesTopologyCompilation() {
    auto config = customNetworkConfig();
    auto& taperedPrimary =
        config.exhaustPaths.front().network->components.front();
    taperedPrimary.outletDiameterMm = 55.0;
    requireLayout(!validateEngineConfig(config),
        "an authored outlet diameter must be valid exhaust geometry");
    const auto layout =
        ExhaustNetworkLayout::compile(ExhaustGraph::makeForEngine(config));
    const auto compiled = std::find_if(
        layout.ducts().begin(), layout.ducts().end(),
        [&taperedPrimary](const CompiledExhaustDuct& duct) {
            return duct.sourceComponentId == taperedPrimary.id;
        });
    const auto circularArea = [](double diameterMm) {
        return std::numbers::pi
            * std::pow(diameterMm * 0.0005, 2.0);
    };
    const auto inletAreaM2 = circularArea(41.0);
    const auto outletAreaM2 = circularArea(55.0);
    requireLayout(layout.valid() && compiled != layout.ducts().end(),
        "an authored tapered component must compile to one physical duct");
    requireLayout(std::abs(compiled->inletFlowAreaM2 - inletAreaM2) < 1.0e-14
            && std::abs(compiled->outletFlowAreaM2 - outletAreaM2) < 1.0e-14
            && std::abs(compiled->inletConnectionAreaM2 - inletAreaM2) < 1.0e-14
            && std::abs(compiled->outletConnectionAreaM2 - outletAreaM2) < 1.0e-14
            && std::abs(compiled->volumeM3
                - (inletAreaM2 + std::sqrt(inletAreaM2 * outletAreaM2)
                    + outletAreaM2) / 3.0 * 0.44) < 1.0e-14
            && !compiled->areaWasDerivedFromVolume,
        "topology compilation must preserve both taper faces and exact frustum volume");
}

void testCrossoverUsesTwoPhysicalSectionsAndRetainsPorts() {
    auto config = makeDefaultInlineTwo();
    auto& path = config.exhaustPaths.front();
    ExhaustNetworkConfig network;
    for (const auto id : { 101U, 102U, 301U, 302U })
        network.components.push_back(component(
            id, ExhaustComponentType::pipe, 180.0, 60.0));
    auto crossover = component(
        200U, ExhaustComponentType::crossover, 0.0, 60.0);
    crossover.crossoverCoupling = 0.30;
    network.components.push_back(crossover);
    network.components.push_back(component(
        401U, ExhaustComponentType::outlet, 180.0, 60.0));
    network.components.push_back(component(
        402U, ExhaustComponentType::outlet, 180.0, 60.0));
    network.cylinderConnections = {
        { config.cylinders[0].id, 101U },
        { config.cylinders[1].id, 102U },
    };
    network.connections = {
        { 101U, 200U, unspecifiedExhaustComponentPort, 0U },
        { 102U, 200U, unspecifiedExhaustComponentPort, 1U },
        { 200U, 301U, 0U, unspecifiedExhaustComponentPort },
        { 200U, 302U, 1U, unspecifiedExhaustComponentPort },
        { 301U, 401U }, { 302U, 402U },
    };
    path.network = std::move(network);
    normaliseEngineConfig(config);
    requireLayout(!validateEngineConfig(config),
        "the crossover layout fixture must validate");

    const auto layout = ExhaustNetworkLayout::compile(
        ExhaustGraph::makeForEngine(config));
    const auto compiled = std::find_if(
        layout.junctions().begin(), layout.junctions().end(),
        [](const auto& junction) {
            return junction.sourceComponentId == 200U;
        });
    const auto areaM2 = std::numbers::pi * std::pow(0.030, 2.0);
    requireLayout(layout.valid() && compiled != layout.junctions().end()
            && compiled->sourceType == ExhaustNodeType::crossover
            && compiled->volumeWasDerived
            && std::abs(compiled->volumeM3
                - 2.0 * areaM2 * 0.060) < 1.0e-14
            && std::abs(compiled->crossoverCoupling - 0.30) < 1.0e-12,
        "a compact X must retain two intersecting A*d gas sections and coupling");

    std::array<bool, 2> inputs {};
    std::array<bool, 2> outputs {};
    for (const auto& interface : layout.interfaces()) {
        if (interface.downstream.nodeId == compiled->nodeId
            && interface.downstreamPort <= 1U)
            inputs[interface.downstreamPort] = true;
        if (interface.upstream.nodeId == compiled->nodeId
            && interface.upstreamPort <= 1U)
            outputs[interface.upstreamPort] = true;
    }
    requireLayout(inputs == std::array<bool, 2> { true, true }
            && outputs == std::array<bool, 2> { true, true },
        "layout compilation must retain all explicit crossover port identities");

    const auto productionMesh = realtimeExhaustFeedbackDiscretisation();
    const auto production = ExhaustNetworkLayout::compile(
        ExhaustGraph::makeForEngine(config), productionMesh);
    requireLayout(production.valid()
            && std::abs(production.minimumCellLengthM() - 0.180) < 1.0e-12
            && std::abs(production.minimumCflLengthM() - 0.060) < 1.0e-12,
        "CFL metrology must expose crossover 2 V/sum(A), not only duct dx");
}

void testPerforatedCoreMufflerSeparatesFlowDuctFromOuterCan() {
    auto config = customNetworkConfig();
    auto& muffler = *std::find_if(
        config.exhaustPaths.front().network->components.begin(),
        config.exhaustPaths.front().network->components.end(),
        [](const ExhaustComponentConfig& value) {
            return value.type == ExhaustComponentType::muffler;
        });
    muffler.packingFlowResistivityPaSPerM2 = 24'000.0;
    muffler.packingThicknessMm = 35.0;
    muffler.perforatedOpenAreaRatio = 0.28;
    requireLayout(!validateEngineConfig(config),
        "a complete perforated-core muffler fixture must be valid");

    const auto layout = ExhaustNetworkLayout::compile(
        ExhaustGraph::makeForEngine(config));
    const auto compiled = std::find_if(
        layout.ducts().begin(), layout.ducts().end(),
        [id = muffler.id](const CompiledExhaustDuct& duct) {
            return duct.sourceComponentId == id;
        });
    requireLayout(layout.valid() && compiled != layout.ducts().end(),
        "the perforated-core muffler must compile to one bounded gas duct");

    const auto coreAreaM2 = std::numbers::pi
        * std::pow(muffler.diameterMm * 0.0005, 2.0);
    const auto coreVolumeM3 = coreAreaM2 * muffler.lengthMm * 0.001;
    requireLayout(std::abs(compiled->flowAreaM2 - coreAreaM2) < 1.0e-14
            && std::abs(compiled->inletFlowAreaM2 - coreAreaM2) < 1.0e-14
            && std::abs(compiled->outletFlowAreaM2 - coreAreaM2) < 1.0e-14
            && std::abs(compiled->volumeM3 - coreVolumeM3) < 1.0e-14
            && !compiled->areaWasDerivedFromVolume
            && compiled->perforatedCoreMuffler
            && std::abs(compiled->mufflerAnnularVolumeM3
                - (muffler.volumeLitres * 0.001 - coreVolumeM3)) < 1.0e-14,
        "packing must not turn the outer can volume into the mean-flow bore");
}

void testHomogenisedCatalystPreservesTheHardRealtimeBudget() {
    auto bypassConfig = customNetworkConfig();
    auto& bypassComponent = *std::find_if(
        bypassConfig.exhaustPaths.front().network->components.begin(),
        bypassConfig.exhaustPaths.front().network->components.end(),
        [](const ExhaustComponentConfig& value) { return value.id == 300; });
    bypassComponent.type = ExhaustComponentType::catalyst;
    bypassComponent.lengthMm = 180.0;
    bypassComponent.diameterMm = 58.0;
    bypassComponent.volumeLitres = 0.0;
    bypassComponent.packingFlowResistivityPaSPerM2 = 0.0;
    bypassComponent.packingThicknessMm = 0.0;
    bypassComponent.perforatedOpenAreaRatio = 0.0;

    auto monolithConfig = bypassConfig;
    auto& monolithComponent = *std::find_if(
        monolithConfig.exhaustPaths.front().network->components.begin(),
        monolithConfig.exhaustPaths.front().network->components.end(),
        [](const ExhaustComponentConfig& value) { return value.id == 300; });
    monolithComponent.catalystCellDensityCpsi = 400.0;
    monolithComponent.catalystOpenAreaRatio = 0.80;
    monolithComponent.catalystSubstrateVolumetricHeatCapacityJPerM3K =
        2'000'000.0;
    auto incompleteConfig = bypassConfig;
    auto& incompleteComponent = *std::find_if(
        incompleteConfig.exhaustPaths.front().network->components.begin(),
        incompleteConfig.exhaustPaths.front().network->components.end(),
        [](const ExhaustComponentConfig& value) { return value.id == 300; });
    incompleteComponent.catalystCellDensityCpsi = 400.0;
    incompleteComponent.catalystOpenAreaRatio = 0.80;
    requireLayout(!validateEngineConfig(bypassConfig)
            && !validateEngineConfig(monolithConfig),
        "both catalyst compatibility and monolith fixtures must be valid");

    const auto bypass = ExhaustNetworkLayout::compile(
        ExhaustGraph::makeForEngine(bypassConfig));
    const auto monolith = ExhaustNetworkLayout::compile(
        ExhaustGraph::makeForEngine(monolithConfig));
    const auto incomplete = ExhaustNetworkLayout::compile(
        ExhaustGraph::makeForEngine(incompleteConfig));
    const auto findCatalyst = [](const ExhaustNetworkLayout& layout) {
        return std::find_if(layout.ducts().begin(), layout.ducts().end(),
            [](const CompiledExhaustDuct& duct) {
                return duct.sourceComponentId == 300;
            });
    };
    const auto bypassDuct = findCatalyst(bypass);
    const auto monolithDuct = findCatalyst(monolith);
    const auto incompleteDuct = findCatalyst(incomplete);
    requireLayout(bypass.valid() && monolith.valid()
            && bypassDuct != bypass.ducts().end()
            && monolithDuct != monolith.ducts().end(),
        "both catalyst layouts must compile to one physical duct");
    requireLayout(incomplete.valid()
            && incompleteDuct != incomplete.ducts().end()
            && !incompleteDuct->homogenisedCatalystMonolith
            && incompleteDuct->flowAreaM2 == bypassDuct->flowAreaM2
            && incompleteDuct->hydraulicDiameterM
                == bypassDuct->hydraulicDiameterM,
        "an unvalidated partial substrate must fail safe to the exact bypass");

    const auto geometry = catalystMonolithGeometry(400.0, 0.80);
    const auto housingAreaM2 = std::numbers::pi * std::pow(0.058 * 0.5, 2.0);
    requireLayout(geometry.active
            && monolithDuct->homogenisedCatalystMonolith
            && !bypassDuct->homogenisedCatalystMonolith
            && std::abs(monolithDuct->catalystOpenAreaRatio - 0.80) < 1.0e-12
            && std::abs(monolithDuct
                    ->catalystSubstrateVolumetricHeatCapacityJPerM3K
                - 2'000'000.0) < 1.0e-12
            && std::abs(monolithDuct->flowAreaM2 - housingAreaM2 * 0.80) < 1.0e-14
            && std::abs(monolithDuct->inletConnectionAreaM2 - housingAreaM2) < 1.0e-14
            && std::abs(monolithDuct->outletConnectionAreaM2 - housingAreaM2) < 1.0e-14
            && std::abs(monolithDuct->hydraulicDiameterM
                - geometry.hydraulicDiameterM) < 1.0e-14,
        "the homogenised substrate must separate housing aperture, open area and channel scale");
    requireLayout(monolithDuct->cellCount == bypassDuct->cellCount
            && monolith.totalCellCount() == bypass.totalCellCount()
            && monolith.ducts().size() == bypass.ducts().size(),
        "cpsi must not multiply gas cells, ducts or explicit-solver work");
}

void testZeroLengthResolutionAndHardCellBudget() {
    auto config = customNetworkConfig();
    auto& outlet = config.exhaustPaths.front().network->components.back();
    outlet.lengthMm = 0.0;
    outlet.volumeLitres = 0.0;
    const auto graph = ExhaustGraph::makeForEngine(config);
    const auto resolved = ExhaustNetworkLayout::compile(graph);
    requireLayout(resolved.valid(),
        "a zero-length terminal restriction must receive an explicit, diagnosed thickness");
    requireLayout(std::any_of(resolved.diagnostics().begin(), resolved.diagnostics().end(),
        [](const ExhaustNetworkLayoutDiagnostic& diagnostic) {
            return diagnostic.issue == ExhaustNetworkLayoutIssue::zeroLengthComponentResolved;
        }), "a derived component length must never be silent");

    ExhaustNetworkDiscretisation impossible;
    impossible.maximumTotalCells = 4;
    const auto rejected = ExhaustNetworkLayout::compile(graph, impossible);
    requireLayout(!rejected.valid()
            && std::any_of(rejected.diagnostics().begin(), rejected.diagnostics().end(),
                [](const ExhaustNetworkLayoutDiagnostic& diagnostic) {
                    return diagnostic.issue == ExhaustNetworkLayoutIssue::cellBudgetExceeded;
                }),
        "a hard cell budget must reject an impossible topology instead of dropping ducts");
}

void testShortestCellIsReportedAndTracksOneShortElement() {
    // The shortest cell anywhere sets the explicit time step for the WHOLE
    // network, so it is the number that says what an authored geometry will
    // cost the solver. `cellBudgetExceeded` does not cover this: it guards the
    // TOTAL cell count, and the coarsening loop in `compile` only reacts to
    // that total, never to one duct being far shorter than the target.
    auto config = customNetworkConfig();
    const auto baseline = ExhaustNetworkLayout::compile(
        ExhaustGraph::makeForEngine(config));
    requireLayout(baseline.valid(), "the reference network must compile");

    const auto shortestM = baseline.minimumCellLengthM();
    requireLayout(shortestM > 0.0,
        "a compiled network must report a positive shortest cell");
    auto expected = 0.0;
    for (const auto& duct : baseline.ducts()) {
        if (duct.cellCount == 0 || !(duct.lengthM > 0.0)) continue;
        const auto cellM = duct.lengthM / static_cast<double>(duct.cellCount);
        if (expected == 0.0 || cellM < expected) expected = cellM;
    }
    requireLayout(shortestM == expected,
        "the reported shortest cell must be the minimum over the compiled ducts");

    // Now shorten ONE pipe far below the meshing target. Everything else is
    // untouched, so any change is attributable to that element alone. A pipe is
    // used rather than a chamber deliberately: ExhaustGraph floors a chamber at
    // its own plane-wave resolution limit, and a pipe has no such floor, so
    // this is the case that survives that fix and still needs to be visible.
    auto& components = config.exhaustPaths.front().network->components;
    auto* pipe = static_cast<ExhaustComponentConfig*>(nullptr);
    for (auto& candidate : components) {
        if (candidate.type == ExhaustComponentType::pipe) { pipe = &candidate; break; }
    }
    requireLayout(pipe != nullptr, "the reference network must contain a pipe");
    pipe->lengthMm = 8.0;
    const auto degraded = ExhaustNetworkLayout::compile(
        ExhaustGraph::makeForEngine(config));
    requireLayout(degraded.valid(), "a short pipe must still compile");
    const auto degradedM = degraded.minimumCellLengthM();
    requireLayout(degradedM > 0.0 && degradedM < shortestM,
        "one short element must lower the network's shortest cell");
    // The substep rate is proportional to 1/dx for the same gas, so this ratio
    // is exactly the factor by which the whole exhaust solver gets slower.
    const auto costRatio = shortestM / degradedM;
    requireLayout(costRatio > 2.0,
        "an 8 mm element must show up as a large, visible solver-cost ratio");
    std::cout << "shortest cell: " << shortestM * 1'000.0 << " mm -> "
              << degradedM * 1'000.0 << " mm, solver cost x"
              << costRatio << '\n';
}

void testDerivedLengthIsFlooredAtThePlaneWaveLimit() {
    // A component with neither length nor volume used to take
    // `minimumResolvedLengthM` (5 mm) as its LENGTH. That constant is a
    // numerical guard against a degenerate zero, not a physical scale, and the
    // explicit time step is the minimum over cells of dx/(c+|u|) -- so one such
    // element made every duct in the network substep at 5 mm.
    //
    // This was not a corner case. `defaultComponent` in the exhaust designer
    // gives an outlet no length and no volume, and EVERY network has an outlet,
    // so every user-authored exhaust hit it: measured on the 2JZ and the LS3,
    // 180 mm shipped against 5 mm authored, i.e. x36 solver cost for a geometry
    // the user never chose. That is the whole of "any exhaust I apply from the
    // designer drops the simulation below realtime, whatever I draw".
    auto config = customNetworkConfig();
    auto& components = config.exhaustPaths.front().network->components;
    auto* outlet = static_cast<ExhaustComponentConfig*>(nullptr);
    for (auto& candidate : components) {
        if (candidate.type == ExhaustComponentType::outlet) {
            outlet = &candidate;
            break;
        }
    }
    requireLayout(outlet != nullptr, "the reference network must contain an outlet");
    outlet->lengthMm = 0.0;
    outlet->volumeLitres = 0.0;
    const auto outletDiameterMm = outlet->diameterMm;

    const auto layout = ExhaustNetworkLayout::compile(
        ExhaustGraph::makeForEngine(config));
    requireLayout(layout.valid(), "a length-less outlet must still compile");

    // Below L ~= 0.853 d the first plane-wave resonance has left the band the
    // 1-D element is valid in, so the derived length carries nothing usable and
    // flooring it there is not an approximation. Same constant as the short
    // silencer body floor in ExhaustGraph.cpp.
    constexpr double planeWaveResonantLengthRatio = 0.853;
    const auto flooredM = planeWaveResonantLengthRatio * outletDiameterMm * 0.001;

    // Assert on the OUTLET's own duct, not on the network minimum: this
    // reference network already contains a shorter element elsewhere, so the
    // network minimum would be satisfied without the outlet ever being floored
    // and the test would pass vacuously.
    const auto outletDuct = std::find_if(
        layout.ducts().begin(), layout.ducts().end(),
        [id = outlet->id](const CompiledExhaustDuct& duct) {
            return duct.sourceComponentId == id;
        });
    requireLayout(outletDuct != layout.ducts().end(),
        "the length-less outlet must still be compiled as a duct");
    requireLayout(outletDuct->cellCount > 0, "the outlet duct must carry cells");
    if (!(outletDuct->lengthM >= flooredM * 0.999)) {
        std::cout << "outlet length " << outletDuct->lengthM * 1'000.0
                  << " mm, floor " << flooredM * 1'000.0 << " mm\n";
    }
    requireLayout(outletDuct->lengthM >= flooredM * 0.999,
        "a derived length must be floored at the element's plane-wave limit, "
        "never at the numerical minimumResolvedLengthM");

    // What the user actually pays is the CELL, so check it under the mesh the
    // simulator really uses (EngineSimulator::configurePhysicalExhaustNetwork:
    // 360 mm target, one cell minimum). Before the floor this element was 5 mm.
    ExhaustNetworkDiscretisation productionMesh;
    productionMesh.targetCellLengthM = 0.360;
    productionMesh.minimumCellsPerDuct = 1;
    productionMesh.maximumCellsPerDuct = 64;
    productionMesh.maximumTotalCells = 1'024;
    const auto production = ExhaustNetworkLayout::compile(
        ExhaustGraph::makeForEngine(config), productionMesh);
    requireLayout(production.valid(), "the production mesh must compile");
    const auto productionOutlet = std::find_if(
        production.ducts().begin(), production.ducts().end(),
        [id = outlet->id](const CompiledExhaustDuct& duct) {
            return duct.sourceComponentId == id;
        });
    requireLayout(productionOutlet != production.ducts().end()
            && productionOutlet->cellCount > 0,
        "the outlet must compile under the production mesh");
    const auto productionCellM =
        productionOutlet->lengthM / static_cast<double>(productionOutlet->cellCount);
    requireLayout(productionCellM > 5.0 * 0.005,
        "a length-less outlet must not mesh anywhere near the 5 mm numerical floor");
    std::cout << "length-less outlet: length " << outletDuct->lengthM * 1'000.0
              << " mm (floor " << flooredM * 1'000.0
              << " mm), production cell " << productionCellM * 1'000.0
              << " mm against 5 mm before the fix\n";
}

} // namespace

void runExhaustNetworkLayoutTests() {
    testAuthoredTopologyCompilation();
    testCrossoverUsesTwoPhysicalSectionsAndRetainsPorts();
    testAudioFieldsCannotChangePhysicalLayout();
    testPerforatedCoreMufflerSeparatesFlowDuctFromOuterCan();
    testLegacyTopologyCompilation();
    testAuthoredTaperSurvivesTopologyCompilation();
    testHomogenisedCatalystPreservesTheHardRealtimeBudget();
    testZeroLengthResolutionAndHardCellBudget();
    testShortestCellIsReportedAndTracksOneShortElement();
    testDerivedLengthIsFlooredAtThePlaneWaveLimit();
}
