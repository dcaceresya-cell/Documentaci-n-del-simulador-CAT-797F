#include <enginelab/ecu/SimpleEcuModel.hpp>
#include <enginelab/calibration/EcuCalibration.hpp>
#include <enginelab/calibration/EcuCalibrationKeys.hpp>
#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <cstdlib>
#include <numbers>
#include <string_view>
namespace enginelab {
namespace {
constexpr std::array<double, 4> rpmAxis { 0.0, 2'000.0, 4'500.0, 8'000.0 };
constexpr std::array<double, 3> loadAxis { 0.0, 0.5, 1.0 };
/** Lambda learning stays suspended this long after a fuel-cut resume. */
constexpr double postFuelCutLambdaLearningHoldSeconds = 2.0;
/** A shut-throttle engine losing at least this share of its idle speed per
 * second is coasting down (a tip-out from a rev loses ~1). */
constexpr double coastingNormalizedRpmRate = 0.05;
using CalibrationTable = std::array<std::array<double, loadAxis.size()>, rpmAxis.size()>;

double interpolate(const CalibrationTable& table, double rpm, double load) noexcept {
    const auto upperRpm = std::upper_bound(rpmAxis.begin(), rpmAxis.end(), rpm);
    const auto upperLoad = std::upper_bound(loadAxis.begin(), loadAxis.end(), load);
    const auto r1 = static_cast<std::size_t>(std::clamp<std::ptrdiff_t>(upperRpm - rpmAxis.begin(), 1, rpmAxis.size() - 1));
    const auto l1 = static_cast<std::size_t>(std::clamp<std::ptrdiff_t>(upperLoad - loadAxis.begin(), 1, loadAxis.size() - 1));
    const auto r0 = r1 - 1; const auto l0 = l1 - 1;
    const auto rt = std::clamp((rpm - rpmAxis[r0]) / (rpmAxis[r1] - rpmAxis[r0]), 0.0, 1.0);
    const auto lt = std::clamp((load - loadAxis[l0]) / (loadAxis[l1] - loadAxis[l0]), 0.0, 1.0);
    const auto low = std::lerp(table[r0][l0], table[r0][l1], lt);
    const auto high = std::lerp(table[r1][l0], table[r1][l1], lt);
    return std::lerp(low, high, rt);
}

double interpolateTimingCurve(const std::vector<IgnitionMapSample>& curve, double rpm) noexcept {
    if (curve.empty()) return 18.0;
    if (curve.size() == 1 || rpm <= curve.front().rpm) return curve.front().advanceDegrees;
    for (std::size_t index = 1; index < curve.size(); ++index) {
        if (rpm <= curve[index].rpm) {
            const auto span = std::max(1.0, curve[index].rpm - curve[index - 1].rpm);
            const auto t = std::clamp((rpm - curve[index - 1].rpm) / span, 0.0, 1.0);
            return std::lerp(curve[index - 1].advanceDegrees, curve[index].advanceDegrees, t);
        }
    }
    return curve.back().advanceDegrees;
}

/** The map held under the full-load knock limit: none at or below the
 *  pressure where knock starts to matter (the ambient for a boosted engine,
 *  0.7 of the limit's own for one that is not), all of it at the pressure the
 *  limit was measured at, linear between. Not measured between those two
 *  pressures: the knock control trims what the line leaves. */
double knockLimitedAdvance(const std::vector<KnockLimitSample>& curve, double advanceDegrees,
                           double rpm, double manifoldPressureKpa, double ambientPressureKpa) noexcept {
    if (curve.empty()) return advanceDegrees;
    auto limit = curve.front();
    if (curve.size() > 1 && rpm > curve.front().rpm) {
        limit = curve.back();
        for (std::size_t index = 1; index < curve.size(); ++index) {
            if (rpm <= curve[index].rpm) {
                const auto span = std::max(1.0, curve[index].rpm - curve[index - 1].rpm);
                const auto t = std::clamp((rpm - curve[index - 1].rpm) / span, 0.0, 1.0);
                limit.advanceDegrees = std::lerp(curve[index - 1].advanceDegrees, curve[index].advanceDegrees, t);
                limit.manifoldPressureKpa = std::lerp(curve[index - 1].manifoldPressureKpa,
                                                      curve[index].manifoldPressureKpa, t);
                break;
            }
        }
    }
    const auto onsetKpa = std::min(ambientPressureKpa, 0.7 * limit.manifoldPressureKpa);
    const auto share = std::clamp((manifoldPressureKpa - onsetKpa)
        / std::max(1.0, limit.manifoldPressureKpa - onsetKpa), 0.0, 1.0);
    return advanceDegrees - share * std::max(0.0, advanceDegrees - limit.advanceDegrees);
}

}

SimpleEcuModel::SimpleEcuModel()
    : SimpleEcuModel(std::make_shared<calibration::CalibrationStore>()) {}

SimpleEcuModel::SimpleEcuModel(
    std::shared_ptr<calibration::CalibrationStore> calibrations)
    : calibrations_(calibrations ? std::move(calibrations)
                                 : std::make_shared<calibration::CalibrationStore>()),
      calibrationReader_(calibrations_->registerReader()),
      frameCalibration_(calibrations_->snapshot()) {}

void SimpleEcuModel::initialiseCalibration(const EngineConfig& config) {
    if (calibrations_->snapshot()->revision() == 0) {
        (void)calibrations_->publish(calibration::makeDefaultEcuCalibration(config),
                                     { 0, "engine-default" });
    }
    beginFrame();
}

void SimpleEcuModel::beginFrame() noexcept {
    auto next = pinnedCalibration_
        ? pinnedCalibration_ : calibrations_->snapshot();
    frameCalibration_ = std::move(next);
    calibrationReader_->acknowledge(frameCalibration_->revision());
}

std::uint64_t SimpleEcuModel::pinCalibrationSnapshot(
    std::shared_ptr<const calibration::CalibrationSnapshot> accepted) noexcept {
    pinnedCalibration_ = accepted ? std::move(accepted)
                                  : calibrations_->snapshot();
    frameCalibration_ = pinnedCalibration_;
    calibrationReader_->acknowledge(frameCalibration_->revision());
    return frameCalibration_->revision();
}

void SimpleEcuModel::releasePinnedCalibrationSnapshot() noexcept {
    // Do not swap frameCalibration_ half way through a simulator frame. The
    // normal beginFrame() boundary will adopt the newest published revision.
    pinnedCalibration_.reset();
}

double activeRevLimitRpm(const EngineConfig& config,
                         const calibration::CalibrationSnapshot& calibration) noexcept {
    return std::clamp(calibration.scalarOr(calibration::keys::revLimit, config.ignition.revLimitRpm),
        calibration::ecuLimits::minimumRevLimitRpm, calibration::ecuLimits::maximumRevLimitRpm);
}

double displayRedlineRpm(const EngineConfig& config,
                         const calibration::CalibrationSnapshot& calibration) noexcept {
    const auto active = activeRevLimitRpm(config, calibration);
    const auto authored = std::clamp(config.ignition.revLimitRpm,
        calibration::ecuLimits::minimumRevLimitRpm, calibration::ecuLimits::maximumRevLimitRpm);
    return std::abs(active - authored) < 0.5 ? config.redlineRpm : active;
}

double activeIdleTargetRpm(const EngineConfig& config,
                           const calibration::CalibrationSnapshot& calibration) noexcept {
    const auto authored = std::max(calibration::ecuLimits::minimumIdleTargetRpm, config.idleRpm);
    if (idleCarburettor(config) != nullptr) return authored;
    return std::clamp(calibration.scalarOr(calibration::keys::idleTarget, authored),
        calibration::ecuLimits::minimumIdleTargetRpm, calibration::ecuLimits::maximumIdleTargetRpm);
}

double launchControlRpm(const calibration::CalibrationSnapshot& calibration) noexcept {
    return std::clamp(calibration.scalarOr(calibration::keys::launchLimit, 0.0),
        0.0, calibration::ecuLimits::maximumRevLimitRpm);
}

double overboostCutMarginKpa(const calibration::CalibrationSnapshot& calibration) noexcept {
    return std::clamp(calibration.scalarOr(calibration::keys::overboostCut,
                                           calibration::ecuLimits::defaultOverboostCutMarginKpa),
        0.0, calibration::ecuLimits::maximumOverboostCutMarginKpa);
}

double knockRetardGainDegrees(const calibration::CalibrationSnapshot& calibration) noexcept {
    return std::clamp(calibration.scalarOr(calibration::keys::knockRetardGain,
                                           calibration::ecuLimits::defaultKnockRetardGainDegrees),
        calibration::ecuLimits::minimumKnockRetardGainDegrees,
        calibration::ecuLimits::maximumKnockRetardGainDegrees);
}

EcuCommand SimpleEcuModel::evaluate(const EngineConfig& config, const EngineState& state,
                                    const EngineControls& controls) const noexcept {
    const auto& calibrationSnapshot = frameCalibration_;
    const calibration::AxisCoordinate rpmCoordinate {
        calibration::AxisQuantity::engineSpeed,
        calibration::CalibrationUnit::revolutionsPerMinute,
        state.rpm
    };
    // A two-stroke's manifold pressure is its crankcase's pumping, about
    // ambient at any throttle; its load is the delivery ratio the simulator
    // keeps in state.load (alpha-N would be the closest real ECU input).
    const auto normalizedLoad = std::clamp(
        config.fuel == FuelType::diesel
            ? std::max(controls.throttle, state.load)
            : config.cycle == EngineCycle::twoStroke
            ? state.load
            : state.manifoldPressureKpa
                / std::max(1.0, config.ambientPressureKpa),
        calibration::ecuLimits::minimumNormalizedLoad,
        calibration::ecuLimits::maximumNormalizedLoad);
    const calibration::AxisCoordinate loadCoordinate {
        calibration::AxisQuantity::normalizedLoad,
        calibration::CalibrationUnit::ratio,
        normalizedLoad
    };
    const auto revLimit = activeRevLimitRpm(config, *calibrationSnapshot);
    // Launch control (two-step): standing in gear with the throttle past half,
    // the limiter cuts at the launch speed instead, so the clutch takes up
    // from there; it lets go once the vehicle rolls. The driveline counts its
    // gears from 0 (first) and -1 is neutral: `gear >= 1` armed it from
    // second only (owner report 2026-10-31).
    const auto launchRpm = launchControlRpm(*calibrationSnapshot);
    const auto launchActive = launchRpm > 0.0 && state.gear >= 0
        && state.vehicleSpeedMps < launchControlReleaseSpeedMps && controls.throttle > 0.5;
    const auto cutRpm = launchActive ? std::min(revLimit, launchRpm) : revLimit;
    // The limiter's bands are a car's 220 and 180 rpm, the radial's 9 % and
    // 7 % of its 2,450 below that: a 750 rpm marine six cut fuel from 530 rpm
    // and sat on its limiter at its full-load speed (journal 2026-10-30).
    const auto limiterBandScale = std::min(1.0, cutRpm / 2'450.0);
    auto limiterActive = limiterLatched_.load(std::memory_order_relaxed);
    if (state.rpm >= cutRpm) {
        limiterActive = true;
        limiterReleaseTime_.store(state.simulationTimeSeconds + config.ignition.limiterDurationSeconds,
                                  std::memory_order_relaxed);
    } else if (state.rpm < cutRpm - 180.0 * limiterBandScale
               && state.simulationTimeSeconds >= limiterReleaseTime_.load(std::memory_order_relaxed)) {
        limiterActive = false;
    }
    limiterLatched_.store(limiterActive, std::memory_order_relaxed);

    // Overboost cut: the fuel is cut while the manifold pressure runs the
    // margin past the boost target, given back at half of it (a real ECU's
    // boost fuel cut). The target is the one the wastegate controller holds:
    // the boost table at this speed, else the configuration's sea-level
    // wastegate ratio as a gauge boost.
    auto overboostActive = false;
    if (config.forcedInduction.enabled
            && config.forcedInduction.type == ForcedInductionType::turbocharger) {
        const auto marginKpa = overboostCutMarginKpa(*calibrationSnapshot);
        if (marginKpa > 0.0) {
            constexpr double seaLevelPressureKpa = 101.325;
            const auto table = calibrationSnapshot->sampleCurve(calibration::keys::boostTargetGauge, rpmCoordinate);
            const auto targetGaugeKpa = table
                ? std::clamp(*table, calibration::ecuLimits::minimumBoostTargetGaugeKpa,
                      calibration::ecuLimits::maximumBoostTargetGaugeKpa)
                : (config.forcedInduction.wastegatePressureRatio - 1.0) * seaLevelPressureKpa;
            const auto gaugeKpa = state.manifoldPressureKpa - config.ambientPressureKpa;
            overboostActive = overboostLatched_.load(std::memory_order_relaxed);
            if (gaugeKpa > targetGaugeKpa + marginKpa) overboostActive = true;
            else if (gaugeKpa < targetGaugeKpa + 0.5 * marginKpa) overboostActive = false;
        }
    }
    overboostLatched_.store(overboostActive, std::memory_order_relaxed);

    // The driver's throttle and the idle-air actuator are separate physical
    // controls.  The former must be able to close completely; using a minimum
    // throttle opening as an idle controller made every engine idle high and
    // made a released keyboard throttle remain physically open.
    const auto effectiveThrottle = std::clamp(controls.throttle, 0.0, 1.0);
    const auto previousIdleTime = previousIdleEvaluationTime_.exchange(
        state.simulationTimeSeconds, std::memory_order_relaxed);
    const auto idleDt = previousIdleTime > 0.0
        ? std::clamp(state.simulationTimeSeconds - previousIdleTime, 0.0, 0.02) : 0.0;
    auto idleIntegral = idleIntegral_.load(std::memory_order_relaxed);
    auto idleDashpot = idleDashpot_.load(std::memory_order_relaxed);
    auto idleAirOpening = 0.0;
    const auto idleTargetRpm = activeIdleTargetRpm(config, *calibrationSnapshot);
    const auto* const carburettor = idleCarburettor(config);
    // The filtered speed's rate (rpm/s), for the fuel-cut resume below.
    double idleRpmRatePerSecond = 0.0;
    if (controls.ignitionEnabled || controls.starterEngaged) {
        const auto targetRpm = idleTargetRpm;
        const auto normalizedError = (targetRpm - state.rpm) / targetRpm;
        // Derivative damping uses a filtered physical speed, not firing ripple.
        // The former PI loop was underdamped on the high-authority aircraft V12:
        // it swung 619-852 rpm around an 800 rpm target with a ~4 s period even
        // though its mean was correct. A generic PID derivative term anticipates
        // the stored rotational energy instead of adding a per-engine exception.
        auto filteredRpm = idleFilteredRpm_.load(std::memory_order_relaxed);
        if (!(filteredRpm > 0.0) || idleDt <= 0.0)
            filteredRpm = state.rpm;
        const auto previousFilteredRpm = filteredRpm;
        constexpr double derivativeFilterTimeConstantSeconds = 0.080;
        filteredRpm += (state.rpm - filteredRpm) * (1.0 - std::exp(
            -idleDt / derivativeFilterTimeConstantSeconds));
        const auto normalizedRpmRate = idleDt > 0.0
            ? (filteredRpm - previousFilteredRpm) / (idleDt * targetRpm)
            : 0.0;
        const auto governorOwnsSpeedDamping = effectiveThrottle <= 0.02
            && state.rpm < targetRpm * 1.30
            // Do not open extra air into a fuel film that is still refilling
            // after DFCO. On the LS3 the derivative correctly saw the falling
            // speed, but its extra bypass air arrived while fuel resume was
            // only 0.32 and drove AFR to the model's 100:1 ceiling. Let the
            // existing dashpot own that coordinated relight first.
            && decelerationFuelResume_.load(std::memory_order_relaxed) > 0.95;
        idleFilteredRpm_.store(filteredRpm, std::memory_order_relaxed);
        idleRpmRatePerSecond = normalizedRpmRate * targetRpm;
        // Cross-fade against the physical (smoothed) throttle plate, not the
        // driver's instantaneous request. Otherwise the bypass snaps shut one
        // integration step before the plate has opened and creates a real air
        // gap during tip-in.
        const auto driverOverride = std::clamp(1.0 - state.throttle * 12.0, 0.0, 1.0);
        constexpr double feedForward = carburettorPilotSizingIdleOpening;
        // The gains were set on four-strokes. On a two-stroke, whose idle air
        // goes through the crankcase first, they hunt: the RD350 swung
        // 1,006-1,565 rpm with its fuel trim frozen (std 165) and 1,175-1,398
        // with it; at half the gain, 1,271-1,349 and 1,279-1,325 (journal
        // 2026-10-23).
        const auto governorGainShare = config.cycle == EngineCycle::twoStroke ? 0.5 : 1.0;
        const auto proportionalGain = 0.90 * governorGainShare;
        const auto integralGain = 0.55 * governorGainShare;
        constexpr double derivativeGainSeconds = 0.12;
        constexpr double minimumIntegral = -0.20;
        // The idle air is sized for the configured idle. A target set above it
        // on the ECU page needs more air than the bypass passes fully open
        // (the 2JZ held 1,125 rpm for 1,520, the Aircooled 1,106 for 1,250),
        // so the governor may then open past it, as an electronic throttle
        // cracks its plate once its idle valve is open: two bypasses more per
        // configured idle of raise. At the configured idle it is exactly the
        // bypass's own travel.
        const auto idleAuthority = 1.0 + 2.0 * std::max(0.0,
            targetRpm / std::max(calibration::ecuLimits::minimumIdleTargetRpm, config.idleRpm) - 1.0);
        const auto maximumIntegral = 0.58 + (idleAuthority - 1.0);
        if (effectiveThrottle > 0.02) {
            // A real throttle/idle system does not snap from a driven opening
            // to the closed-throttle stop. Preserve a short deceleration-air
            // dashpot so manifold filling and fuel transport can settle before
            // the PI loop resumes sole authority.
            idleDashpot = std::max(idleDashpot,
                std::clamp(effectiveThrottle * 2.0, 0.0, 0.65));
        } else if (state.rpm < targetRpm * 1.30
                || normalizedRpmRate > -coastingNormalizedRpmRate
                || config.cycle == EngineCycle::twoStroke) {
            // Near idle, or no longer coasting down: hand back to the
            // governor, bleeding the dashpot out.
            idleDashpot *= std::exp(-idleDt * 1.25);
        }
        // Above ~1.3x idle at a shut throttle the dashpot is HELD, not decayed.
        // A tip-out from a rev coasts down over seconds; the former fixed ~0.8 s
        // decay expired while the engine was still far above idle, so the bypass
        // was already shut when it finally arrived. With the plate shut too, the
        // manifold had pumped down to vacuum, the first fired cycles after the
        // fuel cut released made almost no torque, and the engine sagged straight
        // through idle and stalled (measured: LS3 to 314 rpm, Merlin to a full
        // stall on a 0.5 s blip recovery). Holding the dashpot through the coast
        // keeps a live manifold charge so combustion re-establishes at idle. It
        // only ever charges from a throttle-open condition, so a pure motoring
        // overrun (throttle never opened) is unaffected.
        //
        // Held only while the engine is actually coasting down. A fuelled
        // engine can sustain its own speed on the dashpot's air: once the
        // learned lambda trim no longer went lean after a fuel-cut resume, the
        // EJ25 sat at 1,200 rpm (1.46 x idle) for good, the dashpot held by
        // the very speed it was holding.
        //
        // Never held on a two-stroke: it keeps its fuel on overrun (below),
        // so there is no cut-and-vacuum relight to protect, and the held air
        // fed it instead. On Blair's lower friction the RD350 then coasted
        // from 9,970 rpm at 450-900 rpm/s and was still at 2,262 rpm 12 s
        // after a WOT blip (journal 2026-10-28).
        //
        // Post-start air.
        //
        // Cranking air was commanded only below 350 rpm, so it vanished the
        // instant the engine caught. The idle PI then saw a speed far above its
        // target -- the post-start flare every engine has -- and closed the
        // bypass completely. With the plate also shut the engine had almost no
        // air path at all: measured on the catalogue, manifold pressure fell to
        // about 10 kPa, cycle torque went to roughly -75 Nm as the engine pumped
        // against the vacuum it had created, and it died before the PI could
        // reopen. Only the two engines whose flare stayed near their idle target
        // survived.
        //
        // Real engine management does not hand the idle valve to the governor at
        // the moment of catch. It holds an elevated opening after start and bleeds
        // it out over seconds, so the engine breathes while its speed settles and
        // while the port fuel film is still building. That schedule is what is
        // modelled here: charged during cranking, then decaying with a time
        // constant, and always a floor under the governor rather than a
        // replacement for it. The governor still has full authority to open
        // further, and once the schedule has bled away it has sole authority.
        //
        // Cold engines need it for longer, because a cold port wets more fuel and
        // a cold engine has more friction to overcome.
        const auto postStartDecaySeconds = std::clamp(
            2.5 + (70.0 - state.coolantTemperatureC) * 0.045, 2.5, 6.0);
        auto postStartAir = postStartAirOpening_.load(std::memory_order_relaxed);
        if (controls.starterEngaged || state.rpm < 350.0) {
            // Cranking: hold the schedule charged, so it starts full at catch.
            postStartAir = 0.88;
        } else {
            // Releasing this floor faster when the engine flares was measured
            // and REJECTED. It does fix the two engines whose flare is worst
            // (radial 0 -> 683 rpm, Big Twin sigma 57.7 -> 16.7), but the floor
            // is precisely what keeps a flaring engine breathing: bleeding it on
            // overspeed at 6.0/s took the Audi I5 from a settled 780/746 rpm
            // (sigma 9.3) to a full stall. The flare is not the destructive
            // event -- the fuel cut that the flare triggers is. See the
            // after-start DFCO inhibit below.
            postStartAir *= std::exp(-idleDt / postStartDecaySeconds);
            if (postStartAir < 1.0e-4) postStartAir = 0.0;
        }
        postStartAirOpening_.store(postStartAir, std::memory_order_relaxed);

        // The governor's own command, and the position the actuator will
        // actually take. They are NOT the same signal: the post-start floor and
        // the deceleration dashpot each override the governor from below, so
        // for seconds after a catch the valve is held open by the schedule
        // while the governor's output is ignored.
        const auto governorCommand = [&](double integral) noexcept {
            return feedForward + proportionalGain * normalizedError + integral
                - (governorOwnsSpeedDamping
                    ? derivativeGainSeconds * normalizedRpmRate : 0.0);
        };
        const auto deliveredFor = [&](double integral) noexcept {
            return std::max(postStartAir,
                std::max(std::clamp(governorCommand(integral), 0.0, idleAuthority), idleDashpot)
                    * driverOverride);
        };

        if (driverOverride < 0.999) {
            // The driver's pedal is physically closing the bypass downstream of
            // this PI controller.  Integrating an overspeed error while the
            // actuator is overridden used to wind the state down to -0.42; on
            // lift-off the bypass then stayed shut until the engine had already
            // fallen through its combustion threshold.  Track the neutral
            // feed-forward state while overridden so returning to idle is
            // bumpless even after a long rev.
            //
            // A raised target's extra air is kept: it is what held the idle
            // before the blip, and rebuilt from zero at the integral's rate it
            // took the 2JZ more than 12 s to climb back to 1,220 rpm (1,136).
            // At the configured idle there is no extra authority to keep.
            const auto keptIntegral = std::clamp(idleIntegral, 0.0, idleAuthority - 1.0);
            idleIntegral = keptIntegral + (idleIntegral - keptIntegral) * std::exp(-idleDt * 3.0);
        } else {
            const auto proposedIntegral = std::clamp(
                idleIntegral + normalizedError * integralGain * idleDt,
                minimumIntegral, maximumIntegral);
            const auto proposedCommand = governorCommand(proposedIntegral);
            // Anti-windup has to test the DELIVERED actuator position, not the
            // governor's own command, and this is the difference between an
            // idle that settles and one that hunts.
            //
            // While the post-start floor holds the valve open, the engine sits
            // ABOVE its idle target (that is what a post-start flare is), so
            // the error is negative and the integral winds down -- even though
            // the governor is not moving the actuator at all. The old guard
            // could not see this, because it compared the governor's own
            // command against 0 and 1 and that command sits mid-range.
            // Measured on the 2JZ: from t=5.0 s to t=9.25 s the delivered
            // opening equalled the floor to three decimals while the integral
            // was driven to its -0.20 stop and pinned there for two seconds.
            // The floor then bled below the governor and handed over to a
            // controller with no authority left; the engine sagged from 847 to
            // 571 rpm while the integral climbed back at 0.11/s, overshot, and
            // rang at ~0.2 Hz for the rest of the run. That ringing is what the
            // idle gate was sampling -- whether a run "passed" depended on
            // which phase of it the 4 s measurement window happened to catch.
            //
            // So: when something other than the governor owns the actuator,
            // the governor is saturated LOW and may only integrate in the
            // direction that takes it back into control (error > 0, engine
            // below target). Otherwise it holds its authority.
            const auto governorOwnsActuator =
                std::clamp(proposedCommand, 0.0, idleAuthority) * driverOverride
                    >= deliveredFor(proposedIntegral) - 1.0e-9;
            const auto admissible = governorOwnsActuator
                ? ((proposedCommand > 0.0 && proposedCommand < idleAuthority)
                    || (proposedCommand <= 0.0 && normalizedError > 0.0)
                    || (proposedCommand >= idleAuthority && normalizedError < 0.0))
                : normalizedError > 0.0;
            if (admissible) idleIntegral = proposedIntegral;
        }

        if (carburettor != nullptr) {
            // A carburettor has no governor: its idle stop screw holds the
            // slide where it was set and the engine idles wherever that air
            // takes it. The after-start floor stays, as the start aid a
            // carburettor's choke and fast idle are; nothing else moves it.
            idleIntegral = 0.0;
            idleDashpot = 0.0;
            idleAirOpening = std::max(postStartAir,
                carburettorIdleScrewOpening(carburettor->idleScrewTurns) * driverOverride);
        } else {
            idleAirOpening = deliveredFor(idleIntegral);
        }
    } else {
        idleIntegral *= std::exp(-idleDt * 5.0);
        idleDashpot *= std::exp(-idleDt * 5.0);
    }
    idleIntegral_.store(idleIntegral, std::memory_order_relaxed);
    idleDashpot_.store(idleDashpot, std::memory_order_relaxed);
    idleAirOpening_.store(idleAirOpening, std::memory_order_relaxed);
    const auto warmupCorrection = std::clamp(1.0 + (70.0 - state.coolantTemperatureC) * 0.0025, 1.0, 1.12);
    const auto crankingCorrection = controls.starterEngaged
        ? 1.0 + std::clamp((700.0 - state.rpm) / 700.0, 0.0, 1.0) * 0.38 : 1.0;
    constexpr CalibrationTable afrCorrection {{
        {{ 0.0, 0.0, -0.3 }}, {{ 0.7, 0.1, -1.0 }},
        {{ 0.9, 0.0, -1.5 }}, {{ 0.6, -0.2, -1.7 }} }};
    constexpr CalibrationTable advanceCorrection {{
        {{ -5.0, -5.0, -6.0 }}, {{ 5.0, 2.0, -1.0 }},
        {{ 9.0, 5.0, 1.0 }}, {{ 11.0, 6.0, 0.0 }} }};
    const auto legacyAfr = calibration::ecuLimits::referenceAirFuelRatio
        + afrTrim_.load(std::memory_order_relaxed)
        + interpolate(afrCorrection, state.rpm, normalizedLoad);
    auto calibratedAfr = calibrationSnapshot->sampleTable(
        calibration::keys::targetAirFuelRatio, rpmCoordinate, loadCoordinate);
    if (!calibratedAfr)
        calibratedAfr = calibrationSnapshot->sampleCurve(
            calibration::keys::targetAirFuelRatio, rpmCoordinate);
    // The lightweight live control is an explicit trim around the active map.
    const auto afrCommand = calibratedAfr
        ? *calibratedAfr + afrTrim_.load(std::memory_order_relaxed)
        : legacyAfr;
    const auto minimumMappedAfr = config.fuel == FuelType::diesel
        ? config.fuelProperties.stoichiometricAirFuelRatio * 1.16
        : calibration::ecuLimits::minimumAirFuelRatio;
    const auto maximumMappedAfr = config.fuel == FuelType::diesel
        ? calibration::ecuLimits::maximumDieselSmokeLimitAirFuelRatio
        : calibration::ecuLimits::maximumGasolineAirFuelRatio;
    auto mappedAfr = std::clamp(
        afrCommand, minimumMappedAfr, maximumMappedAfr);
    const auto dieselFuelQuantityLimit = config.fuel == FuelType::diesel
        ? calibrationSnapshot->sampleCurve(
            calibration::keys::dieselFuelQuantityMgPerCycle,
            rpmCoordinate).value_or(0.0)
        : 0.0;
    const auto configuredAdvance = interpolateTimingCurve(config.ignition.timingCurve, state.rpm);
    const auto liveTrim = ignitionTrimDegrees_.load(std::memory_order_relaxed);
    const auto legacyAdvance = configuredAdvance
        + interpolate(advanceCorrection, state.rpm, normalizedLoad);
    auto calibratedAdvance = calibrationSnapshot->sampleTable(
        calibration::keys::ignitionAdvance, rpmCoordinate, loadCoordinate);
    if (!calibratedAdvance)
        calibratedAdvance = calibrationSnapshot->sampleCurve(
            calibration::keys::ignitionAdvance, rpmCoordinate);
    const auto limitedAdvance = knockLimitedAdvance(config.ignition.knockLimitCurve,
        calibratedAdvance.value_or(legacyAdvance), state.rpm, state.manifoldPressureKpa,
        config.ambientPressureKpa);
    auto mappedAdvance = std::clamp(limitedAdvance + liveTrim,
        calibration::ecuLimits::minimumIgnitionAdvanceDegrees,
        calibration::ecuLimits::maximumIgnitionAdvanceDegrees);
    const auto previousThrottle = previousThrottle_.exchange(effectiveThrottle, std::memory_order_relaxed);
    const auto throttleIncrease = std::clamp(effectiveThrottle - previousThrottle, 0.0, 0.35);
    auto accelerationFuelEnrichment = accelerationFuelEnrichment_.load(std::memory_order_relaxed);
    if (throttleIncrease > 0.0) {
        // Accumulate the complete pedal movement even though evaluate() runs at
        // the solver substep rate. The former one-substep AFR trim vanished on
        // the next substep and made tip-in behaviour depend on solver frequency.
        accelerationFuelEnrichment = std::clamp(
            accelerationFuelEnrichment + throttleIncrease * 2.0, 0.0, 0.80);
    } else {
        accelerationFuelEnrichment *= std::exp(-idleDt * 1.8);
    }
    accelerationFuelEnrichment_.store(accelerationFuelEnrichment,
                                      std::memory_order_relaxed);
    // The physical X-tau wall-film model in EngineSimulator owns tip-in fuel.
    // A second, solver-rate ECU enrichment used to multiply that compensation
    // by as much as 1.98 and then taught the closed-loop trim against the
    // uncorrected target. Keep the transient state only to suspend learning
    // while charge transport settles; do not create a second fuel authority.
    mappedAfr = std::clamp(mappedAfr
        - std::max(0.0, state.coolantTemperatureC - 108.0) * 0.025,
        minimumMappedAfr, maximumMappedAfr);
    // Knock control as an ECU does it: knock the sensor hears pulls the spark
    // back fast, a clean stretch gives it back slowly, so the retard settles
    // where knock just stops (the knock-limited advance). A retard
    // proportional to the knock it removes could only hold by keeping knock.
    // The threshold is ~1 bar of oscillation, where measurements start
    // calling a cycle knocking. A heavy event (0.5, decaying at 45/s) pulls
    // about 1.3 deg, within the 1-3 deg production controls take per knocking
    // cycle; the recovery is 1 deg/s at 12 deg of authority.
    constexpr double knockDetectionLevel = 0.1;
    constexpr double knockAttackPerSecond = 20.0;
    constexpr double knockRecoveryPerSecond = 0.08;
    auto knockRetardShare = knockRetardShare_.load(std::memory_order_relaxed);
    knockRetardShare = std::clamp(state.knockLevel > knockDetectionLevel
            ? knockRetardShare + (state.knockLevel - knockDetectionLevel) * knockAttackPerSecond * idleDt
            : knockRetardShare - knockRecoveryPerSecond * idleDt,
        0.0, 1.0);
    knockRetardShare_.store(knockRetardShare, std::memory_order_relaxed);
    const auto knockRetardDegrees = knockRetardShare * knockRetardGainDegrees(*calibrationSnapshot);
    mappedAdvance = std::clamp(mappedAdvance - knockRetardDegrees
        - std::max(0.0, controls.shiftSparkRetardDegrees)
        - std::max(0.0, state.coolantTemperatureC - 108.0) * 0.20,
        calibration::ecuLimits::minimumIgnitionAdvanceDegrees,
        calibration::ecuLimits::maximumIgnitionAdvanceDegrees);
    // A cranking-retard clamp (`rpm < 500 -> advance <= 4 deg`) was tried here
    // to cure the radial R5's start kickback and is deliberately NOT kept: the
    // real cause was starter sizing (see EngineSimulator), and measured with
    // that fixed the clamp is unnecessary -- the R5 starts and idles without
    // it. It is not free either. A bare rpm threshold is inside the normal
    // operating envelope of a low-idling engine, so it fires on an ordinary
    // idle dip and yanks the advance exactly when the engine needs torque to
    // recover: it alone took the 2JZ idle from 728/709 rpm (sigma 12.1) to
    // 682/559 (sigma 52.8) and the Audi I5 from 760/737 to 718/594. A real
    // start-mode retard is gated on the ECU's run/start state, not on speed.
    const auto softLimit = state.rpm > cutRpm - 220.0 * limiterBandScale;
    const auto alternatingCut = softLimit && (static_cast<std::uint64_t>(state.simulationTimeSeconds * 120.0) & 1U) != 0U;
    // A quickshifter cuts the way the limiter does: spark, and fuel too
    // unless the limiter keeps it, so a wet cut sends the charge unburnt to
    // the exhaust.
    const auto shiftCut = controls.shiftIgnitionCut;
    const auto fuelEnabled = controls.ignitionEnabled && !overboostActive
        && (!(limiterActive || shiftCut) || config.ignition.limiterKeepsFuel);
    const auto sparkEnabled = controls.ignitionEnabled && !limiterActive && !shiftCut;
    auto decelerationFuelCut = decelerationFuelCutLatched_.load(
        std::memory_order_relaxed);
    const auto decelerationFuelCutWasActive = decelerationFuelCut;
    // The ratio scales the refill window with each engine's idle speed while
    // retaining real hysteresis against the 1.65-times-idle entry threshold.
    // Resume must precede the idle catch by enough crank travel to purge the
    // retained port vapour and then deliver one complete, synchronised pulse.
    // At 1.25-times idle the large-inertia Merlin crossed the threshold near
    // 1,000 rpm but its first complete pulse did not arrive until about
    // 765 rpm; the crank then fell through 300 rpm before combustion recovered.
    // A 1.50 ratio leaves a real 0.15-idle hysteresis, starts transport settling
    // before the governor catch, and remains below the normal DFCO entry point.
    // Pedal tip-in still resumes immediately through the throttle clause below.
    // A rotary's face takes 1,080 deg of the shaft from its intake to its
    // fire, half again a four-stroke's travel, and its light shaft coasts down
    // twice as fast (13B: 2,600 rpm/s at 1,000 rpm, a K20 1,300): from 1.50 x
    // idle it stalled before its first fire, from 1.75 x it dipped to 0.57 x
    // idle after a wide-open blip. From 2.25 x it holds 0.89 x.
    const auto rotary = config.cycle == EngineCycle::rotary;
    // A production ECU resumes on the deceleration too, not on the speed
    // alone: a heavy engine falling fast resumes earlier, so its film refills
    // before it reaches idle. Without it the thermally perfect gas's Merlin
    // fell to 1,150 rpm/s, resumed at 1.50 x idle with an empty port film,
    // misfired lean (AFR 24) and dipped to 589 rpm after a WOT blip (the
    // flat-6 to 591). 0.45 s of the fall ahead of idle, at most 1.55 x idle,
    // below the 1.65 x entry (journal 2026-11-05).
    constexpr double resumeLeadSeconds = 0.45;
    constexpr double latestResumeRatio = 1.55;
    const auto decelerationFuelResumeRpm = std::max(idleTargetRpm * (rotary ? 2.25 : 1.50),
        std::min(idleTargetRpm * latestResumeRatio,
                 idleTargetRpm + std::max(0.0, -idleRpmRatePerSecond) * resumeLeadSeconds));
    const auto decelerationFuelCutRpm = idleTargetRpm * (rotary ? 2.50 : 1.65);
    // Deceleration fuel cut is an OVERRUN function: it presumes a running,
    // warmed engine coasting down under a shut throttle. The post-start flare
    // satisfies its speed threshold while being the exact opposite condition --
    // the engine is accelerating away from a catch with an empty port film --
    // and cutting there is what makes a marginal idle unrecoverable. Measured
    // on the radial: fuel was cut 0.3 s after catch at 1433 rpm against a 640
    // target, cycle torque went from +209 to -70 Nm, the engine fell back
    // through the catch threshold, re-cranked, and repeated. Every production
    // ECU inhibits overrun cut through the after-start phase for this reason.
    //
    // The after-start air schedule IS that phase, already maintained above and
    // already longer on a cold engine, which is exactly when a real inhibit
    // lasts longest. Gate on it rather than adding a second timer -- the
    // comment on the start-mode retard above makes the same point: this belongs
    // on the ECU's run/start state, not on a speed threshold.
    // A pops-and-bangs map keeps the full charge and fires it late.
    const auto lateSparkOverrun = config.exhaustAfterfire.strategy
        == ExhaustAfterfireStrategy::lateSparkOverrun;
    auto overrunAfterfireArmed = overrunAfterfireArmed_.load(
        std::memory_order_relaxed);
    if (!controls.ignitionEnabled || controls.starterEngaged) {
        overrunAfterfireArmed = false;
    } else if (lateSparkOverrun
            && effectiveThrottle > 0.20
            && state.rpm >= config.exhaustAfterfire.overrunMinimumRpm) {
        // The post-start air floor can remain above its normal DFCO-inhibit
        // threshold for more than ten seconds on a cold start. An authored
        // afterfire engine which the driver has deliberately taken above its
        // RPM gate is no longer in an accidental start flare: arm its next
        // lift-off without changing clean/default engines or weakening the
        // ordinary idle-stability protection.
        overrunAfterfireArmed = true;
    }
    overrunAfterfireArmed_.store(overrunAfterfireArmed,
        std::memory_order_relaxed);
    // The same holds for every engine: once the driver has opened the
    // throttle past the flare, the start is over, and a lift-off is an
    // overrun. Blipped 6 s after a start, the 2JZ coasted down from 6,800 rpm
    // fuelled, its wet runner flooding the charge to lambda 0.27 with 90 %
    // misfires for 4 s, and the fuel cut came at 1,800 rpm.
    auto driverRevvedSinceStart = driverRevvedSinceStart_.load(
        std::memory_order_relaxed);
    if (!controls.ignitionEnabled || controls.starterEngaged)
        driverRevvedSinceStart = false;
    else if (effectiveThrottle > 0.20)
        driverRevvedSinceStart = true;
    driverRevvedSinceStart_.store(driverRevvedSinceStart,
        std::memory_order_relaxed);
    const auto afterStartPhase =
        postStartAirOpening_.load(std::memory_order_relaxed) > 0.05
        && !overrunAfterfireArmed;
    // When rally anti-lag lets go (its time, its exhaust limit), the plate it
    // held open takes ~0.3 s to close, and the boosted manifold fired normal
    // charges at the mapped spark: +370 N.m for 0.2 s, the 2JZ up 530 rpm on
    // a lift (journal 2026-11-14). The pedal is shut, so the overrun cut
    // starts at once. Never set with anti-lag off.
    auto antiLagLeftPlateOpen = antiLagLeftPlateOpen_.load(std::memory_order_relaxed);
    if (state.throttle < 0.02 || effectiveThrottle > 0.02) antiLagLeftPlateOpen = false;
    antiLagLeftPlateOpen_.store(antiLagLeftPlateOpen, std::memory_order_relaxed);
    // A two-stroke keeps its fuel on overrun, as its carburettor's pilot
    // circuit does. Cut, it scavenges the cylinder clean, so every resume
    // fires a full fresh charge: the RD350 swung between the 1.50 and 1.65 x
    // idle thresholds for 4 s after a WOT blip (+5 N.m bursts) and settled at
    // 1,750 rpm against 1,300. Fuelled, it settles at 1,430.
    if (controls.starterEngaged || effectiveThrottle > 0.02
            || config.cycle == EngineCycle::twoStroke
            || (afterStartPhase && !driverRevvedSinceStart)
            || state.rpm < decelerationFuelResumeRpm) {
        decelerationFuelCut = false;
    } else if ((state.throttle < 0.02 || antiLagLeftPlateOpen) && state.rpm > decelerationFuelCutRpm) {
        // Stop metering fuel on closed-throttle overrun so port film and
        // residual chamber inventory cannot flood the charge that must catch
        // the engine at idle. Hysteresis keeps the injector command stable.
        decelerationFuelCut = true;
    }
    decelerationFuelCutLatched_.store(decelerationFuelCut,
                                      std::memory_order_relaxed);
    const auto decelerationFuelResumeEvent =
        decelerationFuelCutWasActive && !decelerationFuelCut;
    auto decelerationFuelResume = decelerationFuelResume_.load(
        std::memory_order_relaxed);
    if (decelerationFuelCut) {
        decelerationFuelResume = 0.0;
    } else if (controls.starterEngaged || effectiveThrottle > 0.02) {
        decelerationFuelResume = 1.0;
    } else {
        decelerationFuelResume = std::min(1.0,
            decelerationFuelResume + idleDt * 3.0);
    }
    decelerationFuelResume_.store(decelerationFuelResume,
                                  std::memory_order_relaxed);
    // Production ECUs close the lambda loop again only seconds after a fuel
    // cut ends. For about 1.5 s after the resume the charge reference still
    // carries the cut's air-rich residual while the manifold pumps down, and
    // the mixture runs rich (2JZ: AFR 10-12). Learning it took the 2JZ idle
    // trim from 0.81 to 0.57 in 2 s; once the governor refilled the manifold
    // the engine ran AFR 17.4, misfired and fell to 516 rpm (760 target).
    auto lambdaLearningHold = lambdaLearningHoldSeconds_.load(
        std::memory_order_relaxed);
    // A two-stroke's overrun is fuelled (above) but just as unsettled: the
    // film the open throttle left drains into a charge the meter did not ask
    // for. Learning it took the RD350's trim to 0.64 by the tip-in (AFR 25,
    // 20 misfires), or to its 0.55 floor on the way back to idle. The hold is
    // refreshed through the overrun, so it also runs on after it.
    const auto twoStrokeOverrun = config.cycle == EngineCycle::twoStroke
        && state.throttle < 0.02 && state.rpm > idleTargetRpm * 1.65;
    lambdaLearningHold = decelerationFuelResumeEvent || twoStrokeOverrun
        ? postFuelCutLambdaLearningHoldSeconds
        : std::max(0.0, lambdaLearningHold - idleDt);
    lambdaLearningHoldSeconds_.store(lambdaLearningHold,
                                     std::memory_order_relaxed);
    // An ECU calibration, not a pop scheduler: while the DFCO state proves a
    // closed-throttle overrun, the map keeps fuelling and fires late, and the
    // downstream chemistry must still find oxygen and a hot enough gas before
    // any heat or sound comes of it.
    const auto overrunAfterfireActive =
        config.fuel == FuelType::gasoline
        && lateSparkOverrun
        && decelerationFuelCut && !limiterActive
        // The overboost cut wins: the overrun map's fuel ORed past it, so
        // the boost protection did nothing while the pops ran (audit PG-06).
        && !overboostActive
        && controls.ignitionEnabled && !controls.starterEngaged
        && state.rpm >= config.exhaustAfterfire.overrunMinimumRpm
        && effectiveThrottle <= config.exhaustAfterfire.overrunMaximumThrottle;
    // Publish WHY, not just whether. Every clause above is an independent
    // precondition and they are indistinguishable from the outside: an
    // afterfire that never fires produces exactly the same silence whether it
    // is unauthored, the throttle stopped 3 % short, or the engine is still in
    // its after-start flare. Mirror the conjunction term by term rather than
    // deriving a reason afterwards, so the two can never disagree.
    const auto overrunAfterfireBlockers = static_cast<std::uint32_t>(
        (config.fuel == FuelType::gasoline && lateSparkOverrun
             ? 0U : static_cast<std::uint32_t>(AfterfireBlocker::notAuthored))
        | (controls.ignitionEnabled
             ? 0U : static_cast<std::uint32_t>(AfterfireBlocker::ignitionOff))
        | (controls.starterEngaged
             ? static_cast<std::uint32_t>(AfterfireBlocker::cranking) : 0U)
        | (effectiveThrottle <= config.exhaustAfterfire.overrunMaximumThrottle
             ? 0U : static_cast<std::uint32_t>(AfterfireBlocker::throttleOpen))
        | (state.rpm >= config.exhaustAfterfire.overrunMinimumRpm
             ? 0U
             : static_cast<std::uint32_t>(AfterfireBlocker::belowMinimumRpm))
        | (decelerationFuelCut
             ? 0U
             : static_cast<std::uint32_t>(AfterfireBlocker::fuelCutInactive))
        | (limiterActive
             ? static_cast<std::uint32_t>(AfterfireBlocker::revLimiterActive)
             : 0U)
        | (overboostActive
             ? static_cast<std::uint32_t>(AfterfireBlocker::overboostCut)
             : 0U)
        // Not part of the conjunction: arming gates the DFCO inhibit rather
        // than the afterfire directly, so it is reported as the upstream
        // explanation for a `fuelCutInactive` that would otherwise look
        // inexplicable on a warm engine at a shut throttle.
        | (overrunAfterfireArmed || !lateSparkOverrun
             ? 0U : static_cast<std::uint32_t>(AfterfireBlocker::notArmed)));
    const auto fuelCorrection = overrunAfterfireActive
        // The late-spark map keeps the normal charge: what it changes is the
        // spark, not the fuel. The resume ramp is zero across the fuel cut
        // this overrun replaces, and the tip-in reserve is excluded as above.
        ? warmupCorrection * crankingCorrection
        : warmupCorrection * crankingCorrection
            // Cranking is the one phase in which the dry runner/port film has
            // no preceding cycle to estimate, so the reserve is kept only while
            // the starter turns. Once the engine has caught, every pedal tip-in
            // is owned solely by the physical X-tau model. Keeping it through
            // the post-start window (up to ~14 s after catch) stacked x2.12 on
            // top of X-tau at a WOT launch: 6 of 14 road engines flooded to
            // AFR 4.7-7 and stalled 4 s after start, while the same launch
            // after 25 s of idle was fine (LoadedAccelerationHarness
            // --standing-start --launch-at 4 / 25).
            * (1.0 + (controls.starterEngaged
                ? accelerationFuelEnrichment * 1.40 : 0.0))
            * decelerationFuelResume;
    const auto commandedFuelEnabled = overrunAfterfireActive
        || (fuelEnabled && !decelerationFuelCut);
    const auto commandedSparkEnabled = sparkEnabled && !alternatingCut;
    const auto wetSparkCutActive =
        config.fuel == FuelType::gasoline
        && config.ignition.limiterKeepsFuel
        && !overrunAfterfireActive
        && commandedFuelEnabled && !commandedSparkEnabled
        && !controls.starterEngaged
        && (limiterActive || alternatingCut || shiftCut);
    const auto lambdaLearningAllowed = commandedFuelEnabled
        && commandedSparkEnabled
        && !decelerationFuelCut
        && decelerationFuelResume > 0.98
        && !(lambdaLearningHold > 0.0)
        // The dry port film has no usable pre-start reference. During the
        // explicit starter/post-start state the measured chamber mixture is the
        // feedback that converges it; suppressing learning here left the Merlin
        // at AFR ~5 and negative cycle torque until it stalled. Outside that
        // identified start state, suspend adaptation while a pedal transient is
        // active so the controller cannot learn against unsettled transport.
        && (controls.starterEngaged || afterStartPhase
            || accelerationFuelEnrichment < 0.03)
        && !overrunAfterfireActive;
    // A spark engine's mixture map is in petrol AFR (lambda x 14.7), as a
    // flex-fuel ECU works in lambda: another fuel is metered at the same
    // lambda, its own stoichiometric ratio. Exactly 1 on a 14.7 petrol.
    if (config.fuel != FuelType::diesel)
        mappedAfr *= config.fuelProperties.stoichiometricAirFuelRatio
            / calibration::ecuLimits::petrolStoichiometricAirFuelRatio;
    EcuCommand command { mappedAfr, mappedAdvance,
             effectiveThrottle, idleAirOpening,
             fuelCorrection, dieselFuelQuantityLimit,
             commandedFuelEnabled,
             commandedSparkEnabled,
             overrunAfterfireActive,
             wetSparkCutActive,
             softLimit,
             limiterActive,
             alternatingCut,
             decelerationFuelCut,
             overrunAfterfireBlockers,
             lambdaLearningAllowed,
             decelerationFuelResumeEvent };
    command.revLimitRpm = revLimit;
    // A dual clutch's upshift asks for less torque than the retard floor
    // leaves: the rest is met by suppressing injection on a share of the
    // firings. A cut cylinder's air is no lambda observation.
    command.cylinderCutFraction = std::isfinite(controls.shiftCylinderCutFraction)
        ? std::clamp(controls.shiftCylinderCutFraction, 0.0, 1.0) : 0.0;
    if (command.cylinderCutFraction > 0.0)
        command.lambdaLearningAllowed = false;
    // VTEC: the ECU's switch over the high cam, read only from tables that
    // carry it. Without it the cams run as authored: on, at each camshaft's
    // own switch speed and throttle.
    if (const auto vtec = calibrationSnapshot->scalar(calibration::keys::vtecEnabled)) {
        command.vtecEnabled = *vtec >= 0.5;
        command.vtecEngageRpm = std::clamp(calibrationSnapshot->scalarOr(calibration::keys::vtecEngage, -1.0),
            -1.0, calibration::ecuLimits::maximumRevLimitRpm);
        command.vtecHysteresisRpm = std::clamp(calibrationSnapshot->scalarOr(calibration::keys::vtecHysteresis, 0.0),
            0.0, calibration::ecuLimits::maximumVtecHysteresisRpm);
        const auto throttlePercent = calibrationSnapshot->scalarOr(calibration::keys::vtecMinimumThrottle, -1.0);
        command.vtecMinimumThrottle = throttlePercent < 0.0 ? -1.0
            : std::min(throttlePercent, calibration::ecuLimits::maximumVtecThrottlePercent) / 100.0;
    }
    // Past the map's -10 deg floor on purpose: the flame lit 20-40 deg after
    // top dead centre is still burning when the exhaust valve opens, and that
    // late, hot, partly burnt charge is what a pops-and-bangs map sends down
    // the pipe. The spark schedule carries up to 260 deg of travel.
    if (overrunAfterfireActive)
        command.ignitionAdvanceDegrees =
            config.exhaustAfterfire.overrunSparkAdvanceDegrees;
    // Anti-lag (calibration `antilag.*`, a turbocharged petrol engine; off
    // unless armed). Rally: with the driver's foot off above its speed, the
    // throttle is held open, the map's mixture and spark give way to its own
    // late spark and lambda, and a share of the firings is cut with its fuel
    // kept: the late flame and the unlit charges keep the turbine fed. How
    // many firings it cuts, then how far it opens, is a feedback on the
    // engine's torque: it holds the engine to a share of its own drag
    // (friction and a shut throttle's pumping), so it never drives the engine
    // and brakes as much as it is asked to. Launch:
    // only while launch control holds the engine, foot down; the limiter
    // keeps its speed, anti-lag fires late and cuts sparks to build boost.
    // Exits: neutral or the clutch out past a gear change (rally), a speed,
    // a time on one lift, an exhaust temperature. Its mixture is no lambda
    // observation.
    if (config.fuel == FuelType::gasoline && config.forcedInduction.enabled
            && config.forcedInduction.type == ForcedInductionType::turbocharger
            && calibrationSnapshot->scalarOr(calibration::keys::antiLagEnabled, 0.0) >= 0.5) {
        using calibration::ecuLimits::maximumRevLimitRpm;
        const auto setting = [&](std::string_view key, double fallback, double low, double high) {
            const auto value = calibrationSnapshot->scalarOr(key, fallback);
            return std::isfinite(value) ? std::clamp(value, low, high) : fallback;
        };
        command.antiLagArmed = true;
        const auto launchMode = setting(calibration::keys::antiLagMode, 0.0, 0.0, 1.0) >= 0.5;
        const auto minimumRpm = setting(calibration::keys::antiLagMinimumRpm, 0.0, 0.0, maximumRevLimitRpm);
        const auto maximumRpm = setting(calibration::keys::antiLagMaximumRpm, 0.0, 0.0, maximumRevLimitRpm);
        const auto maximumSeconds = setting(calibration::keys::antiLagMaximumSeconds, 0.0, 0.0,
            calibration::ecuLimits::maximumAntiLagSeconds);
        const auto exhaustLimitC = setting(calibration::keys::antiLagExhaustLimit, 0.0, 0.0,
            calibration::ecuLimits::maximumAntiLagExhaustLimitC);
        const auto dt = idleDt;
        // The latched exits: the time on this lift until the driver presses
        // the throttle again, the exhaust 50 C under its limit. The exhaust
        // is read at the turbine inlet, where its cut charges burn: the
        // cylinders' mean read ~420 C with 90 % of them unlit.
        auto timedOut = antiLagTimedOut_.load(std::memory_order_relaxed);
        if (controls.throttle > calibration::ecuLimits::antiLagRearmThrottle && !launchMode) timedOut = false;
        if (launchMode && !launchActive) timedOut = false;
        auto tooHot = antiLagTooHot_.load(std::memory_order_relaxed);
        if (!(exhaustLimitC > 0.0)) tooHot = false;
        else if (state.turbineInletTemperatureC > exhaustLimitC) tooHot = true;
        else if (state.turbineInletTemperatureC < exhaustLimitC - 50.0) tooHot = false;
        const auto decoupledSeconds = controls.drivelineDecoupled
            ? antiLagDecoupledSeconds_.load(std::memory_order_relaxed) + dt : 0.0;
        antiLagDecoupledSeconds_.store(decoupledSeconds, std::memory_order_relaxed);
        const auto bit = [](AntiLagBlocker blocker) { return static_cast<std::uint32_t>(blocker); };
        const auto blockers = (controls.ignitionEnabled && !controls.starterEngaged ? 0U : bit(AntiLagBlocker::ignition))
            | (launchMode || controls.throttle <= calibration::ecuLimits::antiLagMaximumDriverThrottle
                ? 0U : bit(AntiLagBlocker::throttle))
            | (!launchMode || launchActive ? 0U : bit(AntiLagBlocker::notLaunching))
            | (state.rpm >= minimumRpm ? 0U : bit(AntiLagBlocker::belowMinimumRpm))
            | (!(maximumRpm > 0.0) || state.rpm <= maximumRpm ? 0U : bit(AntiLagBlocker::aboveMaximumRpm))
            | (launchMode || decoupledSeconds <= calibration::ecuLimits::antiLagDecoupledExitSeconds
                ? 0U : bit(AntiLagBlocker::decoupled))
            | (timedOut ? bit(AntiLagBlocker::timeUp) : 0U)
            | (tooHot ? bit(AntiLagBlocker::exhaustTooHot) : 0U)
            | (state.damage < 1.0 && !overboostActive && (launchMode || !limiterActive)
                ? 0U : bit(AntiLagBlocker::protection));
        command.antiLagBlockers = blockers;
        const auto active = blockers == 0U;
        auto activeSeconds = active ? antiLagActiveSeconds_.load(std::memory_order_relaxed) + dt : 0.0;
        if (active && maximumSeconds > 0.0 && activeSeconds > maximumSeconds) timedOut = true;
        if (!active) activeSeconds = 0.0;
        antiLagActiveSeconds_.store(activeSeconds, std::memory_order_relaxed);
        antiLagTimedOut_.store(timedOut, std::memory_order_relaxed);
        antiLagTooHot_.store(tooHot, std::memory_order_relaxed);
        const auto wasActive = antiLagWasActive_.exchange(active, std::memory_order_relaxed);
        if (wasActive && !active && !launchMode) antiLagLeftPlateOpen_.store(true, std::memory_order_relaxed);
        if (active) {
            const auto airShare = setting(calibration::keys::antiLagAir, 0.0, 0.0, 100.0) / 100.0;
            const auto sparkAtdc = setting(calibration::keys::antiLagRetard, 0.0, 0.0,
                calibration::ecuLimits::maximumAntiLagSparkAtdcDegrees);
            const auto lambda = setting(calibration::keys::antiLagLambda, 1.0,
                calibration::ecuLimits::minimumAntiLagLambda, calibration::ecuLimits::maximumAntiLagLambda);
            const auto cut = setting(calibration::keys::antiLagCut, 0.0, 0.0, 100.0) / 100.0;
            command.antiLagActive = true;
            command.targetAirFuelRatio = lambda * config.fuelProperties.stoichiometricAirFuelRatio;
            command.ignitionAdvanceDegrees = -sparkAtdc;
            command.sparkCutFraction = cut;
            command.lambdaLearningAllowed = false;
            if (launchMode) {
                // The limiter holds the speed; the driver's throttle is open.
                antiLagAuthority_.store(1.0, std::memory_order_relaxed);
                command.antiLagAuthority = 1.0;
            } else {
                // The drag torque model: friction now, and a shut throttle's
                // pumping over the swept volume (4 pi per cycle of a
                // four-stroke, 2 pi of a two-stroke).
                const auto cyclePerRevolution = config.cycle == EngineCycle::twoStroke ? 2.0 : 4.0;
                const auto dragNm = std::max(1.0, std::max(0.0, state.frictionTorqueNm)
                    + calibration::ecuLimits::antiLagShutThrottlePumpingBar * 1.0e5
                        * breathingDisplacementLitres(config) * 1.0e-3 / (cyclePerRevolution * std::numbers::pi));
                const auto kept = setting(calibration::keys::antiLagBrakingKept, 50.0, 0.0, 100.0) / 100.0;
                const auto ceiling = setting(calibration::keys::antiLagAggressiveness, 100.0, 0.0, 100.0) / 100.0;
                // Zero, not -0 (shown as "-0 N.m"), when none is kept.
                const auto targetNm = kept > 0.0 ? -kept * dragNm : 0.0;
                // How much it lets the engine burn, 0-1: a PI on the torque
                // over 50 ms, normalised by the drag (1.5 per second of a
                // whole drag's error, 0.3 at once). Its lower half opens the
                // air with as many firings cut as it may; its upper half
                // keeps the air open and gives firings back down to the
                // calibrated cut. A rally system holds its air and kills the torque with
                // cut firings and a late spark, so the charges it cuts feed
                // the turbine. Closing the air instead, by an integral that
                // shut it at once on any driving torque, emptied the manifold
                // and hunted (2JZ: 20-110 kPa, the shaft down to two thirds;
                // journal 2026-11-14). A new lift starts with the air open and
                // as many firings cut as it may.
                constexpr double torqueFilterSeconds = 0.05;
                constexpr double integralGainPerSecond = 1.5;
                constexpr double proportionalGain = 0.3;
                const auto maximumCut = std::max(cut, calibration::ecuLimits::antiLagMaximumCutFraction);
                auto torqueNm = antiLagTorqueNm_.load(std::memory_order_relaxed);
                auto authority = antiLagAuthority_.load(std::memory_order_relaxed);
                if (!wasActive) {
                    // Seeded on the target, not on this frame's torque: one
                    // instantaneous sample lands on a firing or between two
                    // (2JZ at the lift: +940 or -7 N.m), and a firing kept
                    // the air shut for 150 ms, emptied the manifold and took
                    // 500 rpm off a lift that keeps no braking.
                    torqueNm = targetNm;
                    authority = 0.5;
                }
                torqueNm += (state.torqueNm - torqueNm) * std::clamp(dt / torqueFilterSeconds, 0.0, 1.0);
                const auto error = (torqueNm - targetNm) / dragNm;
                authority = std::clamp(authority - integralGainPerSecond * error * dt, 0.0, 1.0);
                const auto applied = std::clamp(authority - proportionalGain * error, 0.0, 1.0);
                antiLagTorqueNm_.store(torqueNm, std::memory_order_relaxed);
                antiLagAuthority_.store(authority, std::memory_order_relaxed);
                command.antiLagAuthority = applied;
                command.antiLagTargetTorqueNm = targetNm;
                const auto airOpening = airShare * ceiling * std::clamp(2.0 * applied, 0.0, 1.0);
                command.sparkCutFraction = std::lerp(maximumCut, cut, std::clamp(2.0 * applied - 1.0, 0.0, 1.0));
                command.effectiveThrottle = std::max(command.effectiveThrottle, airOpening);
                command.fuelCorrection = warmupCorrection * crankingCorrection;
                command.fuelEnabled = true;
                command.sparkEnabled = true;
                command.decelerationFuelCutActive = false;
                command.overrunAfterfireActive = false;
                command.wetSparkCutActive = false;
            }
        } else {
            antiLagAuthority_.store(0.0, std::memory_order_relaxed);
        }
    }
    if (config.forcedInduction.enabled
            && config.forcedInduction.type == ForcedInductionType::turbocharger) {
        if (const auto boost = calibrationSnapshot->sampleCurve(
                calibration::keys::boostTargetGauge, rpmCoordinate))
            command.boostTargetGaugeKpa = std::clamp(*boost,
                calibration::ecuLimits::minimumBoostTargetGaugeKpa,
                calibration::ecuLimits::maximumBoostTargetGaugeKpa);
    }
    // Telemetry only: which of the ECU's own protections hold the engine back.
    // Half a degree of knock retard, as the spark map is not finer than that.
    constexpr double reportedKnockRetardDegrees = 0.5;
    command.activeLimits =
        ((softLimit || limiterActive) ? static_cast<std::uint32_t>(ActiveLimit::revLimiter) : 0U)
        | (knockRetardDegrees >= reportedKnockRetardDegrees
            ? static_cast<std::uint32_t>(ActiveLimit::knockRetard) : 0U)
        | (state.coolantTemperatureC > 108.0
            ? static_cast<std::uint32_t>(ActiveLimit::coolantProtection) : 0U)
        | (launchActive && (softLimit || limiterActive)
            ? static_cast<std::uint32_t>(ActiveLimit::launchControl) : 0U)
        | (overboostActive ? static_cast<std::uint32_t>(ActiveLimit::overboostCut) : 0U);
    return command;
}
} // namespace enginelab
