#pragma once
#include <enginelab/calibration/CalibrationStore.hpp>
#include <enginelab/calibration/EcuCalibrationKeys.hpp>
#include <enginelab/ecu/IEcuModel.hpp>
#include <algorithm>
#include <atomic>
#include <cmath>
#include <memory>
namespace enginelab {
/** The rev limit the ECU applies: the calibration's `limits.rev_rpm`, else the
 *  authored `ignition.revLimitRpm`, in the tuner's range. Everything that must
 *  stop where the limiter does (the dyno's sweep, over-rev damage) reads it
 *  here rather than from the authored config. */
[[nodiscard]] double activeRevLimitRpm(const EngineConfig& config,
                                       const calibration::CalibrationSnapshot& calibration) noexcept;
/** Where the tachometer's red zone starts: the authored `redlineRpm` while
 *  the ECU's rev limit is the authored one, the ECU's rev limit once it has
 *  been moved, so a limiter raised or lowered in the tuner moves the mark. */
[[nodiscard]] double displayRedlineRpm(const EngineConfig& config,
                                       const calibration::CalibrationSnapshot& calibration) noexcept;
/** The idle speed the ECU governs to: the calibration's `idle.target_rpm`,
 *  else the authored `idleRpm`, in the tuner's range. A carburetted engine
 *  has no governor and no such key: its idle stop screw sets its idle, and
 *  this is then the authored `idleRpm`, which its overrun thresholds use. */
[[nodiscard]] double activeIdleTargetRpm(const EngineConfig& config,
                                         const calibration::CalibrationSnapshot& calibration) noexcept;
/** The ECU's knock control authority: the most spark it may pull, from the
 *  calibration's `knock.retard_deg_per_intensity` (12 deg when the
 *  calibration has none). Zero turns knock control off. */
[[nodiscard]] double knockRetardGainDegrees(const calibration::CalibrationSnapshot& calibration) noexcept;
/** Launch control's rev limit (calibration `limits.launch_rpm`); 0 = off. */
[[nodiscard]] double launchControlRpm(const calibration::CalibrationSnapshot& calibration) noexcept;
/** The overboost cut's margin over the boost target, gauge kPa (calibration
 *  `limits.overboost_kpa`, 0 when the calibration has none); 0 = off. */
[[nodiscard]] double overboostCutMarginKpa(const calibration::CalibrationSnapshot& calibration) noexcept;
/** Launch control lets go above this road speed (5 km/h). */
inline constexpr double launchControlReleaseSpeedMps = 5.0 / 3.6;
/** Configured ignition curve plus live AFR/advance trims, transient enrichment and latched limiter. */
class SimpleEcuModel final : public IEcuModel {
public:
    SimpleEcuModel();
    explicit SimpleEcuModel(std::shared_ptr<calibration::CalibrationStore> calibrations);

    [[nodiscard]] EcuCommand evaluate(const EngineConfig&, const EngineState&, const EngineControls&) const noexcept override;
    void beginFrame() noexcept override;
    void initialise(const EngineConfig& config) override { initialiseCalibration(config); }
    void initialiseCalibration(const EngineConfig&);
    [[nodiscard]] std::shared_ptr<calibration::CalibrationStore> calibrationStore() const noexcept {
        return calibrations_;
    }
    /** Freeze one coherent calibration for a measurement session. Calls are
     * made by the simulation thread, so evaluate() remains lock-free. */
    [[nodiscard]] std::uint64_t pinCalibrationSnapshot(
        std::shared_ptr<const calibration::CalibrationSnapshot> accepted = {}) noexcept;
    void releasePinnedCalibrationSnapshot() noexcept;
    [[nodiscard]] bool calibrationSnapshotPinned() const noexcept {
        return pinnedCalibration_ != nullptr;
    }
    void reset() noexcept override {
        limiterLatched_.store(false, std::memory_order_relaxed);
        overboostLatched_.store(false, std::memory_order_relaxed);
        decelerationFuelCutLatched_.store(false, std::memory_order_relaxed);
        decelerationFuelResume_.store(1.0, std::memory_order_relaxed);
        lambdaLearningHoldSeconds_.store(0.0, std::memory_order_relaxed);
        limiterReleaseTime_.store(0.0, std::memory_order_relaxed);
        previousThrottle_.store(0.0, std::memory_order_relaxed);
        accelerationFuelEnrichment_.store(0.0, std::memory_order_relaxed);
        idleIntegral_.store(0.0, std::memory_order_relaxed);
        idleAirOpening_.store(0.0, std::memory_order_relaxed);
        idleFilteredRpm_.store(0.0, std::memory_order_relaxed);
        idleDashpot_.store(0.0, std::memory_order_relaxed);
        previousIdleEvaluationTime_.store(0.0, std::memory_order_relaxed);
        postStartAirOpening_.store(0.0, std::memory_order_relaxed);
        overrunAfterfireArmed_.store(false, std::memory_order_relaxed);
        driverRevvedSinceStart_.store(false, std::memory_order_relaxed);
        knockRetardShare_.store(0.0, std::memory_order_relaxed);
        // A run that timed anti-lag out left it out on the next one, and its
        // feedback started from the last run's torque (audit PH-03).
        antiLagAuthority_.store(0.0, std::memory_order_relaxed);
        antiLagTorqueNm_.store(0.0, std::memory_order_relaxed);
        antiLagActiveSeconds_.store(0.0, std::memory_order_relaxed);
        antiLagDecoupledSeconds_.store(0.0, std::memory_order_relaxed);
        antiLagWasActive_.store(false, std::memory_order_relaxed);
        antiLagTimedOut_.store(false, std::memory_order_relaxed);
        antiLagTooHot_.store(false, std::memory_order_relaxed);
        antiLagLeftPlateOpen_.store(false, std::memory_order_relaxed);
    }
    /**
     * Read-only view of the idle governor's internal state, for diagnostics.
     *
     * The idle actuator is the sum of a PI governor and a decaying post-start
     * floor, and an idle fault is usually a handoff between the two rather than
     * either one alone. That is invisible from rpm/MAP telemetry, so these
     * expose the three states an idle trace needs. They are observations only;
     * nothing in the control path reads them back.
     */
    [[nodiscard]] double idleIntegral() const noexcept {
        return idleIntegral_.load(std::memory_order_relaxed);
    }
    [[nodiscard]] double postStartAirOpening() const noexcept {
        return postStartAirOpening_.load(std::memory_order_relaxed);
    }
    [[nodiscard]] double idleAirOpening() const noexcept {
        return idleAirOpening_.load(std::memory_order_relaxed);
    }
    [[nodiscard]] bool decelerationFuelCutActive() const noexcept {
        return decelerationFuelCutLatched_.load(std::memory_order_relaxed);
    }
    [[nodiscard]] double decelerationFuelResume() const noexcept {
        return decelerationFuelResume_.load(std::memory_order_relaxed);
    }
    /** The knock control's retard as a share of its authority, 0-1. */
    [[nodiscard]] double knockRetardShare() const noexcept {
        return knockRetardShare_.load(std::memory_order_relaxed);
    }
    void setAirFuelRatioTrim(double value) noexcept {
        afrTrim_.store(std::isfinite(value)
            ? std::clamp(value,
                calibration::ecuLimits::minimumAirFuelRatioTrim,
                calibration::ecuLimits::maximumAirFuelRatioTrim)
            : 0.0);
    }
    /** Compatibility API: converts the former absolute AFR knob into a trim. */
    void setTargetAirFuelRatio(double value) noexcept { setAirFuelRatioTrim(value - 14.2); }
    void setIgnitionTrimDegrees(double value) noexcept {
        ignitionTrimDegrees_.store(std::isfinite(value) ? std::clamp(value, -30.0, 30.0) : 0.0);
    }
    void setIgnitionAdvanceDegrees(double value) noexcept { setIgnitionTrimDegrees(value); }
private:
    std::shared_ptr<calibration::CalibrationStore> calibrations_;
    std::shared_ptr<calibration::CalibrationReaderEpoch> calibrationReader_;
    std::shared_ptr<const calibration::CalibrationSnapshot> frameCalibration_;
    std::shared_ptr<const calibration::CalibrationSnapshot> pinnedCalibration_;
    std::atomic<double> afrTrim_ { 0.0 };
    std::atomic<double> ignitionTrimDegrees_ { 0.0 };
    mutable std::atomic<bool> limiterLatched_ { false };
    mutable std::atomic<bool> overboostLatched_ { false };
    mutable std::atomic<bool> decelerationFuelCutLatched_ { false };
    mutable std::atomic<double> decelerationFuelResume_ { 1.0 };
    /** The knock control's retard as a share of its authority, 0-1. */
    mutable std::atomic<double> knockRetardShare_ { 0.0 };
    mutable std::atomic<double> lambdaLearningHoldSeconds_ { 0.0 };
    mutable std::atomic<double> limiterReleaseTime_ { 0.0 };
    mutable std::atomic<double> previousThrottle_ { 0.0 };
    mutable std::atomic<double> accelerationFuelEnrichment_ { 0.0 };
    mutable std::atomic<double> idleIntegral_ { 0.0 };
    mutable std::atomic<double> idleAirOpening_ { 0.0 };
    mutable std::atomic<double> idleFilteredRpm_ { 0.0 };
    mutable std::atomic<double> idleDashpot_ { 0.0 };
    mutable std::atomic<double> previousIdleEvaluationTime_ { 0.0 };
    /** Decaying post-start idle air opening. See evaluate(). */
    mutable std::atomic<double> postStartAirOpening_ { 0.0 };
    /** Latched only after a deliberate high-speed driver power request. */
    mutable std::atomic<bool> overrunAfterfireArmed_ { false };
    /** Anti-lag's feedback: the share of its air it opens, its filtered
     *  torque, its time on this lift, how long the driveline has been
     *  decoupled, and its latched exits. */
    mutable std::atomic<double> antiLagAuthority_ { 0.0 };
    mutable std::atomic<double> antiLagTorqueNm_ { 0.0 };
    mutable std::atomic<double> antiLagActiveSeconds_ { 0.0 };
    mutable std::atomic<double> antiLagDecoupledSeconds_ { 0.0 };
    mutable std::atomic<bool> antiLagWasActive_ { false };
    mutable std::atomic<bool> antiLagTimedOut_ { false };
    mutable std::atomic<bool> antiLagTooHot_ { false };
    // Rally anti-lag let go while it held the plate open: the overrun fuel
    // cut reads the driver's shut pedal until the plate has closed.
    mutable std::atomic<bool> antiLagLeftPlateOpen_ { false };
    mutable std::atomic<bool> driverRevvedSinceStart_ { false };
};
} // namespace enginelab
