#pragma once
#include <enginelab/ecu/IEcuModel.hpp>
#include <enginelab/events/IFiringEventGenerator.hpp>
#include <enginelab/exhaust/IExhaustModel.hpp>
#include <enginelab/physics/IPhysicsModel.hpp>
#include <enginelab/physics/ConservativeGasSystem.hpp>
#include <enginelab/physics/FlamePhysicsModel.hpp>
#include <enginelab/physics/CarburettorModel.hpp>
#include <enginelab/physics/CompressionIgnitionModel.hpp>
#include <enginelab/physics/FuelInjectionModel.hpp>
#include <enginelab/physics/EndGasKnockModel.hpp>
#include <enginelab/physics/IndicatedWorkModel.hpp>
#include <enginelab/physics/ValveTrainModel.hpp>
#include <enginelab/simulation/ValveProfileActuator.hpp>
#include <enginelab/physics/HelmholtzRunnerModel.hpp>
#include <enginelab/physics/MechanicalKinematics.hpp>
#include <enginelab/physics/DuctWallHeatTransferModel.hpp>
#include <enginelab/foundation/GasFieldSnapshot.hpp>
#include <enginelab/foundation/TwoStrokeScavenging.hpp>
#include <enginelab/simulation/CylinderWorkerPool.hpp>
#include <enginelab/simulation/IEngineSimulation.hpp>
#include <enginelab/events/CylinderPressureSample.hpp>
#include <enginelab/events/ExhaustAcousticSample.hpp>
#include <enginelab/foundation/SpscQueue.hpp>
#include <enginelab/gasdynamics/ExhaustGasNetwork.hpp>
#include <enginelab/gasdynamics/PartitionedExhaustNetwork.hpp>
#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <memory>
#include <optional>
#include <vector>
namespace enginelab {

/** Diagnostic/runtime policy knobs that do not belong in an engine file.
 *
 * Every field defaults to the production policy. Overrides exist so a harness
 * can run a same-process A/B without editing a machine-specific constant into
 * the simulator or the catalogue.
 */
struct EngineSimulatorOptions final {
    /** Number of background intake workers. The simulation thread still
     * participates, so N workers means N+1 runner participants. `0` forces the
     * serial null control. */
    std::optional<std::size_t> intakeWorkerCount;
    /** From eight cylinders up, run the per-cylinder pass of each sub-step on
     * the intake workers. Absent selects it; false keeps it inline for A/B
     * controls. The result is bit-identical either way. */
    std::optional<bool> parallelCylinderPass;
    /** With the pass above on, also publish each cylinder's end-of-sub-step
     * state (kinematics included) on the workers. Absent selects it. */
    std::optional<bool> parallelCylinderPublish;
    /** With a joint intake manifold on two paths or more (a multi-cylinder
     * two-stroke's crankcases) and the worker pool on, run each path's
     * forward intake flush on its own worker instead of one after another.
     * Absent selects it; false keeps the serial path loop for A/B controls.
     * Bit-identical either way. */
    std::optional<bool> parallelIntakePaths;
    /** Cap the spatial cells in each intake runner. Diagnostic A/Bs use this
     * to establish a convergence point without rewriting authored geometry. */
    std::optional<std::size_t> intakeMaximumCellCount;
    /** Diagnostic spatial target for the intake FV oracle/reduced mesh.
     * Absent selects the measured production target (95 mm). */
    std::optional<double> intakeTargetCellLengthM;
    /** Diagnostic temporal refinement at a fixed intake mesh and coupling
     * interval. Absent retains the production maximum Courant number, 0.8. */
    std::optional<double> intakeMaximumCourantNumber;
    /** Fixed-point rounds used to reconstruct the shared-plenum staircase
     * before concurrent runner advances. */
    std::optional<std::size_t> intakeStaircaseRounds;
    /** Integrate all runners on an intake path against one finite plenum in
     * the same RK stages. False retains the historical separate-runner path
     * for numerical controls. Production uses the joint manifold. */
    std::optional<bool> intakeJointManifold;
    /** Maximum intake coupling interval. Joint manifolds run forward over it
     * (below); absent selects 330 us there. Zero, or an interval shorter than
     * 1.5 mechanical substeps, exchanges on every substep. With forward
     * coupling off, a positive interval holds a time-averaged boundary and
     * intake-valve closing forces a flush; the historical separate-runner
     * path defaults to 400 us. */
    std::optional<double> intakeCouplingIntervalSeconds;
    /** Joint manifold only, with a coupling interval above: advance the
     * network AHEAD of the chambers over the interval, each chamber volume and
     * valve area moving at its current rate (and an open exhaust valve
     * draining it at its latest rate), and hand its transfers to the chambers
     * evenly across the interval instead of averaging a past one. Absent
     * selects it; false restores the time-averaged diagnostic. */
    std::optional<bool> intakeForwardCoupling;
    /** Meter the intake valves with the characteristic valve boundary
     * (ExhaustGasNetworkConfig::characteristicValveBoundary). Absent selects
     * it; false restores the quasi-steady nozzle for A/B controls. */
    std::optional<bool> intakeCharacteristicValve;
    /** Low-speed cap for the nonlinear exhaust coupling interval. Absent uses
     * 125 us (at least 4 kHz physical-boundary Nyquist); harnesses can A/B it
     * against the historical 250 us cap and the full-substep oracle. */
    std::optional<double> maximumLowSpeedExhaustCouplingSeconds;
    /** Diagnostic: couple the exhaust every mechanical substep while any
     * cylinder's phase lies in [first, second] degrees, in place of the
     * scavenging window below. Absent: that window. */
    std::optional<std::array<double, 2>> exhaustFineCouplingWindowDegrees;
    /** A two-stroke couples its exhaust every mechanical substep while any
     * cylinder is between bottom dead centre and its transfers' closing.
     * Absent: on; false for A/B controls. */
    std::optional<bool> exhaustFineCouplingWhileScavenging;
    /** Target cell length of the nonlinear exhaust feedback mesh. Absent keeps
     * the production scale (EngineSimulator::productionExhaustCellLengthM:
     * 360 mm, 100 mm on a two-stroke). This is a diagnostic/convergence knob:
     * the characteristic audio network still owns audio-band propagation. */
    std::optional<double> exhaustTargetCellLengthM;
    /** Diagnostic exhaust Courant number. Absent keeps the production 0.8. */
    std::optional<double> exhaustMaximumCourantNumber;
    /** Diagnostic exhaust time integration: true takes one forward-Euler
     * stage per substep, with `exhaustHancockPredictor` its MUSCL-Hancock
     * form. Absent keeps SSP-RK2. */
    std::optional<bool> exhaustFirstOrderTimeIntegration;
    std::optional<bool> exhaustHancockPredictor;
    /** Exhaust reconstruction across duct-to-duct interfaces
     * (ExhaustGasNetworkConfig::reconstructAcrossInterfaces). Absent: on for
     * a two-stroke only. */
    std::optional<bool> exhaustReconstructAcrossInterfaces;
    /** Diagnostic: meter the exhaust valves with the characteristic boundary
     * (ExhaustGasNetworkConfig::characteristicValveBoundary). Absent: off. */
    std::optional<bool> exhaustCharacteristicValve;
    /** Diagnostic (ExhaustGasNetworkConfig::extrapolateOpenEnds). */
    std::optional<bool> exhaustExtrapolateOpenEnds;
    /** Diagnostic: third-order limited face reconstruction in every exhaust duct. */
    std::optional<bool> exhaustThirdOrderReconstruction;
    /** Diagnostic lower-bound experiment: reset the exhaust network to ambient
     * before every coupling advance. Never use in production; it deliberately
     * discards pulse history to reveal the valve/timing-only pumping floor. */
    std::optional<bool> resetExhaustToAmbientEachCoupling;
    /** Diagnostic effective-area multipliers used by gas-exchange ablations.
     * Production leaves both absent (exactly 1). */
    std::optional<double> intakeValveAreaMultiplier;
    std::optional<double> exhaustValveAreaMultiplier;
    /** Diagnostic port plateau, expressed as effective area / valve-head area. */
    std::optional<double> exhaustMaximumHeadAreaFraction;
    /** A/B override for directed exhaust-collector momentum. Production uses it. */
    std::optional<bool> evolveExhaustJunctionAxialMomentum;
    /** A/B override: advance the exhaust's unconnected parts as networks of
     * their own (PartitionedExhaustNetwork). Absent: on for a two-stroke. */
    std::optional<bool> partitionExhaustNetwork;
    /** Historical Euler diagnostic. Production uses SSP-RK2: omitting its
     * corrector with MUSCL can amplify passive acoustic modes. */
    std::optional<bool> intakeFirstOrderTimeIntegration;
    [[nodiscard]] bool intakeUsesForwardEuler() const noexcept {
        return intakeFirstOrderTimeIntegration.value_or(false);
    }
    /** Diagnostic cadence for the finite-capacity intake-wall heat exchange.
     * Gas/solid energy is accumulated between updates rather than discarded. */
    std::optional<double> intakeWallHeatUpdateIntervalSeconds;
};

/** Orchestrates policies and integrates state; owns no thread and performs no audio work. */
/** Gas reversed through a throttle and still upstream of it. */
struct AirboxSlug final {
    double massKg { 0.0 };
    double fuelMoles { 0.0 };
};

/** Observed continuity of a finite, time-averaged cylinder reservoir between
 * two intake half-advances. These are measurements of the supplied boundaries,
 * not adjustments to them. Read by the simulation owner after step(). */
struct IntakeSplitReservoirDiagnostics final {
    std::uint64_t observationCount { 0 };
    std::uint32_t observedCylinderMask { 0 };
    double absoluteFirstHalfTransferredMassKg { 0.0 };
    std::uint64_t interveningExhaustObservationCount { 0 };
    std::uint32_t interveningExhaustCylinderMask { 0 };
    double absoluteInterveningExhaustTransferredMassKg { 0.0 };
    double maximumSpeciesInventoryMismatchKg { 0.0 };
    double maximumEnergyInventoryMismatchJ { 0.0 };
    double maximumObservedSpeciesInventoryKg { 0.0 };
    double maximumObservedEnergyInventoryJ { 0.0 };
    double maximumVolumeMismatchM3 { 0.0 };
};

/** The pedal above which the engine brake lets go (a real one's throttle
 *  switch opens at the first travel of the pedal). */
inline constexpr double engineBrakeMaximumThrottle = 0.02;

class EngineSimulator final : public IEngineSimulation {
public:
    EngineSimulator(EngineConfig, IEcuModel&, IPhysicsModel&, IFiringEventGenerator&,
                    IExhaustModel&, EngineSimulatorOptions = {});
    [[nodiscard]] SimulationFrame step(double dtSeconds, const EngineControls&) noexcept override;
    [[nodiscard]] const EngineState& state() const noexcept override { return state_; }
    /** Actual discrete valve profile, indexed by configuration cylinder order.
     * Read by the simulation owner after step(); invalid indices return low. */
    [[nodiscard]] bool appliedHighValveProfile(std::size_t cylinderIndex) const noexcept {
        return cylinderIndex < config_.cylinders.size()
            && valveProfileActuators_[cylinderIndex].appliedHigh();
    }
    void setIntakeSplitReservoirDiagnosticsEnabled(bool enabled) noexcept {
        intakeSplitReservoirDiagnosticsEnabled_ = enabled;
        intakeSplitReservoirDiagnostics_ = {};
    }
    [[nodiscard]] const IntakeSplitReservoirDiagnostics&
    intakeSplitReservoirDiagnostics() const noexcept {
        return intakeSplitReservoirDiagnostics_;
    }
    /** Apply only live audio/combustion calibration. Called by the owning
     * simulation thread; it intentionally leaves every dynamic state and
     * compiled gas network untouched. */
    void applyAudioPhysicsCalibration(
        const AudioPhysicsCalibration& calibration) noexcept;
    [[nodiscard]] std::size_t intakeWorkerCount() const noexcept {
        return intakeWorkerPool_ ? intakeWorkerPool_->workerCount() : 0U;
    }
    void setIntakeWallHeatUpdateIntervalSeconds(double seconds) noexcept {
        if (std::isfinite(seconds))
            intakeWallHeatUpdateIntervalSeconds_ =
                std::clamp(seconds, 50.0e-6, 2.0e-3);
    }
    [[nodiscard]] double intakeWallHeatUpdateIntervalSeconds() const noexcept {
        return intakeWallHeatUpdateIntervalSeconds_;
    }
    [[nodiscard]] bool tryPopCylinderPressureSample(CylinderPressureSample& sample) noexcept {
        return pressureSamples_ && pressureSamples_->tryPop(sample);
    }
    [[nodiscard]] bool tryPopExhaustAcousticSample(ExhaustAcousticSample& sample) noexcept {
        return exhaustAcousticSamples_ && exhaustAcousticSamples_->tryPop(sample);
    }
    void setPressureSamplingEnabled(bool enabled);
    /** Instrument use: publish the exhaust acoustic state (outlet flows) on
     * every exhaust coupling, not only when a reaction source exists or the
     * 240 Hz refresh is due. A probe binning the outlets by crank angle needs
     * it: at 240 Hz a held speed only samples a few phases of its cycle.
     * Off by default; the audio path is unchanged either way. */
    void setExhaustAcousticEveryCoupling(bool enabled) noexcept {
        exhaustAcousticEveryCoupling_ = enabled;
    }
    /** Diagnostic oracle: advance the nonlinear exhaust network on every
     * mechanical substep instead of using the production multirate interval.
     *
     * This is intentionally opt-in and is not realtime-safe on large engines.
     * It exists so audio-band approximations can be compared with the more
     * expensive physical solution rather than calibrated against themselves.
     */
    void setExhaustCouplingEverySubstep(bool enabled) noexcept {
        exhaustCouplingEverySubstep_ = enabled;
    }
    void reset() noexcept override;
    /** Production cell length of `config`'s nonlinear exhaust mesh, used when
     * EngineSimulatorOptions::exhaustTargetCellLengthM is absent: 360 mm
     * (realtimeExhaustFeedbackDiscretisation), 100 mm on a two-stroke, whose
     * expansion chamber needs the finer mesh for its suction and plugging
     * waves (RD350 at 8,000 rpm: 9.8 N.m at 360 mm, 12.3 at 100). */
    [[nodiscard]] static double productionExhaustCellLengthM(const EngineConfig& config) noexcept;
    /** The nonlinear exhaust network of `config` built as the simulator builds
     * its own, at `targetCellLengthM` (absent: the construction mesh), for
     * replaceExhaustNetwork(). Null when it does not compile or does not have
     * the topology the simulator was built with: a live change may resize and
     * remesh the exhaust, never reconnect it. Not realtime-safe; any thread,
     * since it reads only what construction fixed. */
    [[nodiscard]] std::unique_ptr<gasdynamics::PartitionedExhaustNetwork> buildLiveExhaustNetwork(
        const EngineConfig& config,
        std::optional<double> targetCellLengthM = {}) const;
    /** Swap in a network from buildLiveExhaustNetwork() for `config`'s exhaust,
     * between two steps, without a restart: the new network takes over the
     * running gas and wall state (ExhaustGasNetwork::adoptStateFrom). On success
     * `network` holds the previous network; on failure nothing changes.
     * Simulation thread only, like step(). */
    [[nodiscard]] bool replaceExhaustNetwork(
        std::unique_ptr<gasdynamics::PartitionedExhaustNetwork>& network,
        const EngineConfig& config);
    /** Whether `edited`'s injectors and forced induction can replace
     * `running`'s in a running engine (replaceSettings): the same injection
     * mode, forced induction on or off alike, of the same type, with the same
     * blade and lobe counts (the sound is built around them), and the same
     * crankshafts (count, ratios, phases, positions). */
    [[nodiscard]] static bool settingsReplaceable(const EngineConfig& running,
                                                  const EngineConfig& edited) noexcept;
    /** Take `config`'s injector, forced-induction, ignition and afterfire
     * settings, its crankshafts' inertia, friction and masses, its ambient
     * air, gearbox, vehicle and thermal model between two steps, without a
     * restart (a regulated thermal model sets the temperatures at once): the simulation reads them at every step and
     * keeps nothing derived from them. They are swapped in, so this thread
     * does not allocate; `config` leaves with the previous ones. False, with
     * nothing changed, when !settingsReplaceable(). Simulation thread only,
     * like step(). */
    [[nodiscard]] bool replaceSettings(EngineConfig& config) noexcept;
    /** The intake runners of a live intake change (buildLiveIntake). */
    struct LiveIntake final {
        std::array<std::unique_ptr<gasdynamics::ExhaustGasNetwork>, 32> runners;
        std::array<std::unique_ptr<gasdynamics::ExhaustGasNetwork>, 32> manifolds;
        std::array<std::size_t, 32> runnerDuctIndex {};
        std::array<std::size_t, 32> runnerPortIndex {};
    };
    /** Whether `edited`'s intake can replace `running`'s in a running engine
     * (replaceIntake): the same cylinders on the same intake paths, the same
     * throttle count, an airbox only where there was one. Lengths,
     * diameters, volumes and coefficients may change. */
    [[nodiscard]] static bool intakeReplaceable(const EngineConfig& running,
                                                const EngineConfig& edited) noexcept;
    /** The intake runners of `config` built as the simulator builds its own,
     * for replaceIntake(). Null when they do not compile. The caller checks
     * intakeReplaceable() first. Not realtime-safe; any thread, since it reads
     * only `config` and what construction fixed. */
    [[nodiscard]] std::unique_ptr<LiveIntake> buildLiveIntake(const EngineConfig& config) const;
    /** Take `config`'s intake between two steps, without a restart: each new
     * runner takes over its predecessor's gas and wall state
     * (ExhaustGasNetwork::adoptStateFrom), each plenum keeps its gas state at
     * its new volume (GasCell::resizeKeepingState) and takes its new throttle
     * area; the rest of the intake is read at every step. On success `intake`
     * and `config` hold the previous runners and intake, freed by the caller;
     * on failure nothing changes. Simulation thread only, like step(). */
    [[nodiscard]] bool replaceIntake(LiveIntake& intake, EngineConfig& config) noexcept;
    /** Move the cylinders to `target`'s bore, stroke, connecting rod, deck
     * height and compression ratio while the engine runs; nothing else of `target` is
     * read. The cylinders on one crank journal change together, at the
     * gas-exchange TDC of the first of them to reach it, when the chamber
     * holds only its clearance volume; the gas keeps its mass through the
     * volume step. With `rampSeconds` > 0 each such TDC takes the size
     * interpolated at that moment, until the target. False, with nothing
     * changed, if `target` does not have the same cylinders and journals.
     * Replaces a resize still in progress, from where it got to. Simulation
     * thread only, like step(). */
    [[nodiscard]] bool beginCylinderResize(const EngineConfig& target, double rampSeconds);
    /** Whether `edited`'s camshafts can replace `running`'s in a running
     * engine (beginCamshaftChange): the same banks, and continuous valve
     * control switched on or off alike. VTEC cams may be fitted or taken off:
     * fitted, they start on the low cam; taken off while the high cam runs,
     * it drops back on a base circle. */
    [[nodiscard]] static bool camshaftsReplaceable(const EngineConfig& running,
                                                   const EngineConfig& edited) noexcept;
    /** Move the camshafts (the engine's and every bank's) to `target`'s while
     * the engine runs; nothing else of `target` is read. Durations, lifts,
     * centrelines, flow coefficients and the profile switch glide over
     * `rampSeconds`, or change at the next sub-step with 0; lift profiles,
     * flow curves and continuous control are swapped in at once, `target`
     * leaving with the previous ones. The valve train reads the camshafts at
     * every sub-step and keeps only its phaser state. False, with nothing
     * changed, when !camshaftsReplaceable(). Replaces a change still in
     * progress, from where it got to. Simulation thread only, like step(). */
    [[nodiscard]] bool beginCamshaftChange(EngineConfig& target, double rampSeconds);
    [[nodiscard]] bool camshaftChangeActive() const noexcept { return camshaftChange_.has_value(); }
    /** True while a resize has cylinders still to change. */
    [[nodiscard]] bool cylinderResizeActive() const noexcept { return cylinderResize_.has_value(); }
    /** Counts the cylinder geometry changes applied, so an owner can refresh
     * what it derived from the configuration (config()). */
    [[nodiscard]] std::uint64_t cylinderGeometryRevision() const noexcept {
        return cylinderGeometryRevision_;
    }
    /** The configuration the simulator runs, live changes included.
     * Simulation thread only. */
    [[nodiscard]] const EngineConfig& config() const noexcept { return config_; }
    /** How many collector faces carry the turbocharger's turbine in the gas
     * network; 0 when the turbine is the older restriction at the outlets. */
    [[nodiscard]] std::size_t exhaustTurbineFaceCount() const noexcept {
        return exhaustTurbineFaces_.size();
    }
    /** Keep the gas field (GasFieldSnapshot) captured at a crank angle over
     * the cycle: each time the crank crosses it between two sub-steps, and at
     * the end of a frame once 0.25 s of simulated time has passed without a
     * crossing (a stopped engine). Calling it again moves the angle without
     * losing a crossing in progress. Reading the solver state does not
     * change it. Simulation thread only, like step(). */
    void trackGasFieldAngle(double crankAngleDegrees) noexcept;
    void stopGasFieldTracking() noexcept { gasFieldArmed_ = false; }
    /** Capture the gas field at the current crank angle. */
    void captureGasFieldNow() noexcept { captureGasField(); }
    /** The latest capture; sequence 0 until the first one. */
    [[nodiscard]] const GasFieldSnapshot& gasField() const noexcept { return gasField_; }
    /** Record the pressure of one gas field element and sample (as in
     * gasField().elements) at every sub-step, binned by crank angle over the
     * cycle (GasProbeTrace). Setting another place clears the trace. Reading
     * the solver state does not change it. Simulation thread only. */
    void probeGasField(std::int32_t element, std::uint8_t sample) noexcept;
    void stopGasProbe() noexcept { gasProbe_.element = -1; }
    /** The probe's trace; its sequence grows at the end of every frame it
        records. */
    [[nodiscard]] const GasProbeTrace& gasProbe() const noexcept { return gasProbe_; }
private:
    /** Sized once the networks exist, so a capture never allocates. */
    void configureGasFieldSnapshot();
    void pollGasFieldCapture() noexcept;
    void captureGasField() noexcept;
    /** Pressure of one cell of the solver, by gas field element and sample. */
    [[nodiscard]] double gasFieldPressurePa(std::size_t element, std::size_t sample) const noexcept;
    void recordGasProbe() noexcept;
    /** Compile and allocate the mandatory nonlinear exhaust network. */
    void configurePhysicalExhaustNetwork();
    [[nodiscard]] std::unique_ptr<gasdynamics::PartitionedExhaustNetwork> buildPhysicalExhaustNetwork(
        const EngineConfig& config, double targetCellLengthM) const;
    /** Assemble one 1-D finite-volume runner duct per cylinder.
     *
     * Intake tuning is a wave phenomenon: a lumped runner cell has no
     * propagation delay, so nothing can arrive at the valve in phase and the
     * fill can never exceed static manifold density. Four algebraic bias
     * formulations were measured and refuted before this (physics-audit.md in the archive/docs-2026-09 tag
     * "L'inertance de runner"); what was missing is the dimension, not a
     * coefficient. Each runner reuses the exhaust's FV network machinery with
     * the intake valve as the cylinder Riemann port and the plenum as the
     * ambient reservoir behind the runner mouth.
     */
    void configurePhysicalIntakeNetworks();
    /** Individual throttles: each plate of the path's runners opens
     *  `openFraction` (0-1) of its bore, `plateAreaM2` shared equally by
     *  the runners and no wider than a runner's face. */
    void setIndividualThrottleAreas(std::size_t pathIndex, double openFraction,
                                    double plateAreaM2) noexcept;
    /** Individual throttles: the manifold pressure behind the path's plates,
     *  as a balance manifold reads it; advanced by `subDt`. */
    [[nodiscard]] double individualThrottleManifoldPressureKpa(std::size_t pathIndex,
                                                               double subDt) noexcept;
    [[nodiscard]] std::unique_ptr<gasdynamics::ExhaustGasNetwork> buildIntakeRunnerNetwork(
        const EngineConfig& config, std::size_t cylinderIndex) const;
    [[nodiscard]] std::unique_ptr<gasdynamics::ExhaustGasNetwork> buildIntakeManifoldNetwork(
        const EngineConfig& config, std::size_t pathIndex,
        std::array<std::size_t, 32>& runnerDuctIndex,
        std::array<std::size_t, 32>& runnerPortIndex) const;
    /** A rotary's three faces share their rotor's runner, so it always runs
     *  the joint manifold. */
    [[nodiscard]] bool jointIntakeManifold() const noexcept {
        return config_.cycle == EngineCycle::rotary || options_.intakeJointManifold.value_or(true);
    }
    /** Whether the joint intake paths are flushed one per worker (see
     *  SimulatorOptions::parallelIntakePaths); their networks then run serial
     *  inside, since the pool is not reentrant. Only paths of one cylinder
     *  each (a two-stroke's crankcases), the case measured: a path of several
     *  runners keeps its per-duct dispatch. Set by attachNetworkParallelFor. */
    [[nodiscard]] bool intakePathsConcurrent() const noexcept { return intakePathsConcurrent_; }
    /** Whether cylinder `index` is the first on its intake runner duct (every
     *  cylinder but a rotary's second and third faces). */
    [[nodiscard]] bool ownsIntakeRunner(std::size_t index) const noexcept {
        return config_.cycle != EngineCycle::rotary || index % 3 == 0;
    }
    [[nodiscard]] gasdynamics::ExhaustGasNetwork& intakeNetworkForCylinder(std::size_t index) noexcept;
    [[nodiscard]] const gasdynamics::ExhaustGasNetwork& intakeNetworkForCylinder(std::size_t index) const noexcept;
    [[nodiscard]] const gasdynamics::FiniteVolumeDuct& intakeDuctForCylinder(std::size_t index) const noexcept;
    void configureIntakeWorkerPool();
    /** Points the exhaust network and the joint intake networks at
     *  intakeWorkerPool_ (or at nothing). Per-runner intake networks are
     *  advanced inside the pool and must never be given it. */
    void attachNetworkParallelFor() noexcept;
    [[nodiscard]] RunningState determineRunningState(const EngineControls&) const noexcept;
    /** Crank degrees of one cylinder cycle: 720, or 360 for a two-stroke.
     *  The crank angle itself always runs over 720 degrees. */
    [[nodiscard]] double cylinderCycleDegrees() const noexcept { return cycleDegreesOf(config_.cycle); }
    /** Injector open time divided by the complete cylinder cycle. */
    [[nodiscard]] double injectorDutyCycle(std::size_t cylinderIndex) const noexcept {
        const auto windowSubsteps = injectorWindowSubsteps_[cylinderIndex];
        if (windowSubsteps <= 0.0) return 0.0;
        const auto windowDegrees = std::fmod(
            config_.injection.endAngleDegrees
                - config_.injection.startAngleDegrees + cylinderCycleDegrees(), cylinderCycleDegrees());
        const auto openFraction =
            injectorOpenSubsteps_[cylinderIndex] / windowSubsteps;
        return std::clamp(
            openFraction * windowDegrees / cylinderCycleDegrees(), 0.0, 1.0);
    }
    /** Fraction of the authored crank window for which the injector was open. */
    [[nodiscard]] double injectorWindowUtilisation(
        std::size_t cylinderIndex) const noexcept {
        const auto windowSubsteps = injectorWindowSubsteps_[cylinderIndex];
        if (windowSubsteps <= 0.0) return 0.0;
        return std::clamp(injectorOpenSubsteps_[cylinderIndex]
            / windowSubsteps, 0.0, 1.0);
    }
    /** `ActiveLimit` bits the simulator observes itself (the ECU adds its
     *  own): an open wastegate, a capped diesel, a saturated injector. */
    [[nodiscard]] std::uint32_t publishedSimulatorLimits() const noexcept {
        constexpr double regulatingWastegateOpening = 0.02;
        constexpr double saturatedInjectorUtilisation = 0.99;
        auto bits = state_.wastegateOpening > regulatingWastegateOpening
            ? static_cast<std::uint32_t>(ActiveLimit::boostAtTarget) : 0U;
        if (config_.forcedInduction.enabled && config_.forcedInduction.type == ForcedInductionType::turbocharger) {
            const auto topRpm = turboMaximumShaftSpeedRpm(config_.forcedInduction);
            const auto units = std::min<std::size_t>(state_.turbochargerCount, state_.turbochargers.size());
            for (std::size_t index = 0; index < units; ++index) {
                const auto& unit = state_.turbochargers[index];
                if (unit.shaftSpeedRpm > topRpm || unit.wheelDamage >= 1.0)
                    bits |= static_cast<std::uint32_t>(ActiveLimit::turboOverspeed);
            }
        }
        const auto cylinders = std::min<std::size_t>(config_.cylinders.size(), dieselFuelLimitBits_.size());
        for (std::size_t index = 0; index < cylinders; ++index) {
            bits |= dieselFuelLimitBits_[index];
            // The last completed cycle's: the live counters are mid-window,
            // where an injector still open reads as open for all of it.
            if (1.0 - injectorCapacityRatio_[index] >= saturatedInjectorUtilisation)
                bits |= static_cast<std::uint32_t>(ActiveLimit::injectorSaturated);
        }
        return bits;
    }
    void accumulateCycleTelemetry(double previousAngleDegrees, double travelledDegrees,
                                  double dtSeconds, double indicatedTorqueNm,
                                  double brakeTorqueNm,
                                  SimulationFrame& frame) noexcept;
    EngineConfig config_;
    EngineSimulatorOptions options_;
    EngineKinematicsReference kinematicsReference_;
    IEcuModel& ecu_;
    IPhysicsModel& physics_;
    IFiringEventGenerator& eventGenerator_;
    IExhaustModel& exhaust_;
    EngineState state_;
    /** Immutable authored topology compiled once. Path/bank searches used to
     * run several times per cylinder per gas substep, despite none of their
     * inputs changing during a simulation. */
    std::array<std::size_t, 32> intakePathIndexByCylinder_ {};
    std::array<std::size_t, 32> exhaustPathIndexByCylinder_ {};
    std::array<double, 32> previousCylinderPhases_ {};
    std::array<double, 32> intakeRunnerPressureKpa_ {};
    /** Intake runner column velocity at the valve plane, and the stagnation head
     *  rho*u^2/2 it carries, per cylinder. Diagnostics; neither drives flow.
     *
     * A 0-D runner cell cannot represent its own inertance: the cell's
     * `bulkVelocityMps()` is a net average that does not collapse when the valve
     * shuts, so the event that actually creates ram charging is absent from it.
     * These carry the velocity referred to the runner cross-section,
     * u = mdot_valve / (rho * A_runner), which does collapse (measured 82.5 ->
     * -2.8 m/s across IVC against 40.9 -> 40.3 for the cell average). See the
     * second intake half-step in EngineSimulator.cpp for what was measured on
     * top of them and why none of it is wired. */
    std::array<double, 32> intakeValveColumnVelocityMps_ {};
    std::array<double, 32> intakePortRamKpa_ {};
    std::array<double, 32> exhaustRunnerPressureKpa_ {};
    std::array<double, 32> exhaustRunnerVelocityMps_ {};
    std::array<double, 32> exhaustRunnerTemperatureK_ {};
    /** Network-side exhaust boundary at the two most recent network solutions.
     *
     * The exhaust network is integrated on a multirate stride, so its state is
     * only new on the substeps where it is flushed. Holding that state on the
     * substeps in between makes the published boundary a zero-order-hold
     * staircase clocked at the coupling rate, which for a running engine lands
     * between roughly 2 and 4 kHz -- squarely audible, and heard as a metallic
     * tone unrelated to the engine. Keeping the last two solutions lets the
     * published boundary be reconstructed by linear interpolation across the
     * stride instead, at the cost of one coupling interval (at most 250 us) of
     * group delay on the exhaust boundary alone.
     */
    struct ExhaustNetworkBoundary final {
        double pressureKpa {};
        double velocityMps {};
        double temperatureK {};
        double massFlowKgPerSecond {};
        double densityKgPerM3 {};
        double speedOfSoundMps {};
        /** Simulation time this knot was sampled at. */
        double timeSeconds {};
        bool valid { false };
    };
    /** Timestamped ring of boundary knots, reconstructed at a CONSTANT delay.
     *
     * Coupling intervals are not uniform: the end of every frame forces a
     * flush, so the frame's last interval is short whenever the substep count
     * is not a multiple of the stride; the stride changes with engine speed;
     * and the substep duration drifts frame to frame. Any reconstruction whose
     * delay follows the current interval -- a substep counter, or even a phase
     * over the latest pair of knot times -- therefore jumps at every interval
     * change, and the frame-rate repetition of those jumps was measured as a
     * comb at exact multiples of 240 Hz across the catalogue, engine
     * independent, with firing sidebands: the dominant metallic residue.
     *
     * Publishing the boundary at one fixed delay behind now, interpolated
     * between whichever ring knots bracket that instant, is continuous by
     * construction through every interval change. The delay must exceed the
     * longest coupling interval so a bracketing pair always exists.
     */
    /** Enough knots to span the delay at the finest coupling: a two-stroke's
     * scavenging window flushes every mechanical substep, down to 10 us at the
     * 100 kHz solver ceiling. Eight spanned 210 us at a 30 us flush, so the
     * search ran out of history and published the oldest knot at a delay that
     * followed the cadence (audit PG-01): 625 us at 10 us is 63 intervals,
     * and a frame's short last substep adds at most one more. */
    static constexpr std::size_t exhaustBoundaryKnotCount = 96;
    /** Above the 250 us low-speed coupling cap with slack, and about 0.6 ms of
     * group delay on the exhaust boundary alone -- inaudible as latency. */
    static constexpr double exhaustBoundaryReconstructionDelaySeconds = 625.0e-6;
    // The validated solver ceiling is 100 kHz (EngineTypes.cpp): the ring must
    // span the delay at that substep, with a short substep and a knot to spare.
    static_assert(static_cast<double>(exhaustBoundaryKnotCount - 3) / 100'000.0
                      >= exhaustBoundaryReconstructionDelaySeconds,
        "the boundary history must span its reconstruction delay at the finest coupling");
    /** Multirate coupling accumulators, carried ACROSS frames.
     *
     * The network flush used to be forced on the last substep of every frame,
     * which cut the final averaging window short whenever the frame's substep
     * count was not a multiple of the coupling stride. That repeats the same
     * irregular window pattern every frame, so the network's own solution --
     * not merely its reconstruction -- was modulated at the frame rate. It was
     * measured as a comb at exact multiples of 240 Hz that survived muting
     * every other layer, replacing the IR with a unit impulse, ramping every
     * delay, and smoothing the harness dyno. Keeping the accumulation in
     * members and flushing on accumulated duration alone decouples the
     * network's integration grid from the frame grid entirely.
     */
    std::array<double, 32> exhaustValveConductanceTimeIntegralM2S_ {};
    std::array<gasdynamics::ConservativeState, 32> exhaustBoundaryStateTimeIntegral_ {};
    std::array<double, 32> exhaustBoundaryVolumeTimeIntegralM3S_ {};
    double exhaustCouplingDurationSeconds_ { 0.0 };
    double outletOpeningScaleTimeIntegralSeconds_ { 0.0 };
    bool exhaustCouplingEverySubstep_ { false };
    /** On the heap: 196 kB of history would grow a simulator that tests keep
     * on the stack. Sized once, never reallocated. */
    std::vector<std::array<ExhaustNetworkBoundary, exhaustBoundaryKnotCount>>
        exhaustBoundaryKnots_ = std::vector<std::array<ExhaustNetworkBoundary, exhaustBoundaryKnotCount>>(32);
    std::size_t exhaustBoundaryKnotWrite_ { 0 };
    /** The valve's instantaneous flow and conductance, published to the audio
     * at the boundary's own delay. The renderer sums this high band with the
     * network's low band through complementary filters, which only make an
     * all-pass when both describe the same instant: published at now beside a
     * boundary 625 us behind, the two cancelled up to 10 dB around the
     * crossover (audit A2-08). Recorded every substep a pressure sample is
     * published; a substep is never shorter than the boundary's finest
     * coupling, so the knot count above spans it. */
    struct ValveFlowKnot final {
        double timeSeconds {};
        double massFlowKgPerSecond {};
        double conductanceAreaM2 {};
        bool valid { false };
    };
    std::vector<std::array<ValveFlowKnot, exhaustBoundaryKnotCount>> valveFlowHistory_ =
        std::vector<std::array<ValveFlowKnot, exhaustBoundaryKnotCount>>(32);
    std::size_t valveFlowHistoryWrite_ { 0 };
    /** Length-mean acoustic medium of every compiled exhaust duct. Reaction
     * events remain coupling-rate, while these slowly varying states are
     * refreshed at the 240 Hz product-frame cadence: the audio renderer applies
     * boundaries once per 187.5 Hz block, so copying them at ~8 kHz discarded
     * CPU without increasing the delivered temporal resolution. */
    std::array<float, ExhaustAcousticSample::maximumDucts>
        exhaustDuctDensityKgPerM3_ {};
    std::array<float, ExhaustAcousticSample::maximumDucts>
        exhaustDuctSpeedOfSoundMps_ {};
    std::size_t exhaustDuctMediumCount_ { 0 };
    double lastExhaustAcousticStatePublishSeconds_ { -1.0 };
    bool exhaustAcousticEveryCoupling_ { false };
    std::array<double, 32> chamberPressureBar_ {};
    /** Each cylinder's highest pressure since it last entered its gas
     * exchange (kPa), the highest of its last completed cycle, and whether it
     * was in its gas exchange at the previous sub-step. */
    std::array<double, 32> cyclePeakPressureKpa_ {};
    std::array<double, 32> lastCyclePeakPressureKpa_ {};
    std::array<bool, 32> inGasExchange_ {};
    std::array<double, 32> intakeFlowMgPerCycle_ {};
    std::array<double, 32> exhaustFlowMgPerCycle_ {};
    std::array<double, 32> intakeFlowMgThisCycle_ {};
    std::array<double, 32> exhaustFlowMgThisCycle_ {};
    /** Oxygen-equivalent fresh air across the intake valve, signed and NET, so
     *  reversion subtracts what it carries back out. Latched per cycle beside
     *  the total-charge accumulators above. */
    std::array<double, 32> deliveredAirMgPerCycle_ {};
    std::array<double, 32> deliveredAirMgThisCycle_ {};
    /** Two-stroke only, per intake path (one crankcase each): air drawn
     *  through the reed since the cylinder's transfers last closed, and the
     *  fill latched at that closing, which is the charge reference. */
    std::array<double, 32> reedInflowMgThisFill_ {};
    std::array<double, 32> reedInflowMgLastFill_ {};
    std::array<bool, 32> cylinderFlowCycleStarted_ {};
    std::array<double, 32> cylinderWallTemperatureC_ {};
    /** Time each chamber's ring blow-by has not yet been applied for; see
     *  blowByUpdateIntervalSeconds in EngineSimulator.cpp. */
    std::array<double, 32> blowByPendingSeconds_ {};
    /** Per intake path with individual throttles: the filtered pressure
     *  behind the plates (individualThrottleManifoldPressureKpa). */
    std::array<double, 32> individualThrottleMapKpa_ {};
    std::array<GasCell, 32> intakePlenumGas_ {};
    std::size_t intakePlenumCount_ { 1 };
    /** Historical separate-runner network ownership retained for numerical
     * controls. Production owns one multi-duct network per intake path below,
     * with timely mechanical half-step exchange and a common finite plenum. */
    std::array<std::unique_ptr<gasdynamics::ExhaustGasNetwork>, 32> intakeRunnerNetworks_;
    /** One shared finite-plenum RK solve per authored intake path. The runner
     * duct and cylinder-port order match, and both are indexed by this map. */
    std::array<std::unique_ptr<gasdynamics::ExhaustGasNetwork>, 32> intakeManifoldNetworks_;
    /** See intakePathsConcurrent(). */
    bool intakePathsConcurrent_ { false };
    std::array<std::size_t, 32> intakeRunnerDuctIndex_ {};
    /** The cylinder's port in its joint network: its runner duct's index,
     *  except on a rotary, whose faces are three ports on one runner. */
    std::array<std::size_t, 32> intakeRunnerPortIndex_ {};
    GasFieldSnapshot gasField_;
    double gasFieldTargetDegrees_ { 0.0 };
    double gasFieldLastDegrees_ { 0.0 };
    double gasFieldCaptureSeconds_ { 0.0 };
    bool gasFieldArmed_ { false };
    GasProbeTrace gasProbe_;
    double gasProbeLastDegrees_ { 0.0 };
    bool gasProbeStarted_ { false };
    /** Workers for the per-cylinder half of the runner advance, which the
     * profiler puts at 75-84% of the mechanical sub-step. Null when the engine
     * is too small or the machine too narrow for a barrier to pay for itself,
     * in which case the phase runs inline. Read CylinderWorkerPool's header
     * before touching this: an earlier per-cylinder fork-join over a much
     * smaller body was measured and removed. */
    std::unique_ptr<CylinderWorkerPool> intakeWorkerPool_;
    /** Scratch plenum cells the Gauss-Seidel staircase is walked through
     * before the runner advances run concurrently. A member rather than a
     * local so a V12 does not copy twelve gas cells onto the stack twice per
     * mechanical sub-step. Nothing outside that pre-pass reads it, and it is
     * fully overwritten at the start of every pass. */
    std::array<GasCell, 32> plenumStaircaseScratch_ {};
    /** Historical boundary-history reduction for positive diagnostic coupling
     * overrides. Conservation of the applied transfer does not establish the
     * accuracy of an averaged moving-cylinder thermodynamic trajectory. */
    std::array<gasdynamics::ConservativeState, 32>
        intakeBoundaryStateTimeIntegral_ {};
    std::array<double, 32> intakeBoundaryVolumeTimeIntegralM3S_ {};
    std::array<double, 32> intakeValveConductanceTimeIntegralM2S_ {};
    double intakeCouplingDurationSeconds_ { 0.0 };
    /** Periodic deadline phase, independent of forced valve-closing flushes.
     * Retaining the rounding residual avoids RPM-dependent cadence jumps. */
    double intakeSchedulingPhaseSeconds_ { 0.0 };
    /** Forward intake coupling (EngineSimulatorOptions::intakeForwardCoupling):
     * transfers the network has already computed for the current interval and
     * not yet handed over, and the mechanical substeps left in that interval. */
    std::array<gasdynamics::CylinderGasExchange, 32> intakeForwardPendingExchange_ {};
    /** Each chamber's latest exhaust exchange as rates out of the chamber
     * (species kg/s, total energy W): what a forward intake advance must
     * also drain from its reservoir while the exhaust valve is open. */
    std::array<std::array<double, gasdynamics::gasSpeciesCount>, 32> exhaustOutflowSpeciesKgPerS_ {};
    std::array<double, 32> exhaustOutflowEnergyW_ {};
    std::array<GasInventoryDelta, 32> intakeForwardPendingPlenumDelta_ {};
    std::size_t intakeForwardRemainingSubsteps_ { 0 };
    // How far the forward intake network's clock runs ahead of the chambers'.
    double intakeForwardClockLeadSeconds_ { 0.0 };
    bool intakeSplitReservoirDiagnosticsEnabled_ { false };
    IntakeSplitReservoirDiagnostics intakeSplitReservoirDiagnostics_ {};
    /** How many serial groups the concurrent runner pass is split into. One is
     * full concurrency; a group per cylinder is the old serial scheme exactly,
     * which is what an engine with no worker pool gets. Chosen from the
     * measured accuracy of the plenum staircase prediction, not from the thread
     * count -- see `configureIntakeWorkerPool`. */
    double intakeWallHeatPendingSeconds_ { 0.0 };
    double intakeWallHeatUpdateIntervalSeconds_ { 150.0e-6 };
    std::size_t intakePredictionGroupCount_ { 32 };
    /** Fixed-point rounds used to reconstruct the plenum drawdown staircase.
     * Production keeps the two converged Heun rounds: zero leaves a stationary-
     * manifold pressure bias, while one is only borderline at the invariant's
     * 0.01 kPa tolerance. Multirate coupling amortises their dispatch cost. */
    std::size_t intakeStaircaseRounds_ { 2 };
    /** Port-end (valve-side) runner state published for telemetry, the
     * Helmholtz telemetry model and the acoustic intake excitation. Refreshed
     * from each network advance's exchange record. */
    std::array<double, 32> intakePortTemperatureK_ {};
    std::array<double, 32> intakePortDensityKgPerM3_ {};
    std::array<double, 32> intakePortSpeedOfSoundMps_ {};
    std::array<GasCell, 32> cylinderGas_ {};
    std::array<double, 32> instantaneousCombustionPulse_ {};
    std::array<double, 32> injectedFuelMolesThisCycle_ {};
    std::array<double, 32> entrainedFuelMolesThisCycle_ {};
    std::array<double, 32> meteredFuelMolesLastCycle_ {};
    std::array<double, 32> deliveredFuelMolesLastCycle_ {};
    std::array<double, 32> requestedFuelMolesThisCycle_ {};
    /** `ActiveLimit` bits of each diesel cylinder's last fuel decision: which
     *  ceiling (smoke or quantity) capped it. Per cylinder: cylinders may be
     *  stepped on worker threads. Telemetry only. */
    std::array<std::uint32_t, 32> dieselFuelLimitBits_ {};
    /** Port pulse terms, sampled once at the first metering substep of a
     *  cycle: credited wall-film and misfired-chamber fuel, DFCO-resume prime
     *  deficit and the fraction of a new pulse available before spark.
     *  Re-reading them every substep turned transient vapour transport into
     *  extra injector pulses that could never be taken back. */
    std::array<bool, 32> portPulseCreditSampled_ {};
    /** A dual clutch's injection cut: whether this cylinder's pulse is
     *  suppressed for the cycle that began at its injection start, and how
     *  many injection starts it has seen (its place in the firing sequence
     *  that spreads the cut). */
    std::array<bool, 32> injectionCutThisCycle_ {};
    /** Anti-lag's ignition cut, fuel kept: whether this cylinder's spark is
     *  cut for the cycle that began at its injection start, spread over the
     *  firings as the dual clutch's injection cut is. */
    std::array<bool, 32> sparkCutThisCycle_ {};
    std::array<std::uint64_t, 32> injectionStartCount_ {};
    std::array<double, 32> portPulseInventoryCreditMoles_ {};
    std::array<double, 32> portPulsePrimeDeficitMoles_ {};
    std::array<double, 32> portPulseAvailableFraction_ {};
    /** Gas pushed back through the throttle, held just upstream of it. A WOT
     *  launch near 1000 rpm reverses about half the metered fuel out of the
     *  plenum; the fixed-composition upstream boundary used to destroy it, so
     *  the ECU saw a lean cylinder it could not correct (CP2: 592 of 1192 mg
     *  lost). See throttleFlowKeepingReversedFuel(). */
    std::array<AirboxSlug, 32> airboxSlug_ {};
    /** One carburettor per intake path, holding the fuel on its walls. */
    std::array<CarburettorState, 32> carburettorStates_ {};
    /** What the jets passed this substep, for the fuel flow and the total. */
    double carburettorFuelMassKgThisStep_ {};
    // A wet nitrous kit's fuel, sprayed into the plenums (audit PG-02).
    double nitrousFuelMassKgThisStep_ {};
    /** Density-scaled previous charge sampled once at the injector-start edge.
     *  Resolved chamber oxygen may raise the request later in the intake event,
     *  but sub-cycle plenum waves must not be peak-detected into pulse width. */
    std::array<double, 32> predictedPortChargeMassMgThisCycle_ {};
    std::array<double, 32> trappedAirMassMgLastCycle_ {};
    std::array<double, 32> trappedAirSourcePressureKpaLastCycle_ {};
    std::array<double, 32> trappedAirSourceTemperatureKLastCycle_ {};
    std::array<double, 32> actualAfrLastCycle_ {};
    std::array<double, 32> actualAfrFuelMassMgLastCycle_ {};
    std::array<bool, 32> actualAfrValidLastCycle_ {};
    /** Per-cylinder observation state after a DFCO fuel-resume edge.
     *  `prepared` proves that an injection window has begun in the new epoch;
     *  until then the next spark cannot be treated as a fresh AFR observation. */
    std::array<bool, 32> portFuelResumePending_ {};
    std::array<bool, 32> portFuelResumePrepared_ {};
    /** First post-cut injection edge owns an unfuelled airflow purge; the next
     *  edge may prepare a complete synchronised pulse. */
    std::array<bool, 32> portFuelResumePurgeCycleSeen_ {};
    std::array<double, 32> portFuelResumeOpenLoopSecondsRemaining_ {};
    std::array<double, 32> portFuelResumeEpochAgeSeconds_ {};
    /** Fast, per-cylinder lambda correction owned only by the observable
     *  post-DFCO transport epoch. It starts at authored unity and converges from
     *  completed combustion observations without contaminating steady cells. */
    std::array<double, 32> portFuelResumeFuelTrim_ {};
    std::array<double, 32> portInjectorFootprintFuelMoles_ {};
    std::array<double, 32> portInjectorFootprintTargetFuelMoles_ {};
    std::array<bool, 32> combustionCommandAvailable_ {};
    std::array<double, 32> fuelDeliveryRatio_ {};
    // Largest pulse the injector was asked to deliver this cycle, and the
    // fraction of it that actually metered before the window closed. The latter
    // isolates real injector-capacity saturation from closed-loop trim: it reads
    // 1.0 whenever the injector keeps up with its command, however large the
    // trim, and only falls when the injector physically runs out of time.
    std::array<double, 32> commandedFuelMolesMaxThisCycle_ {};
    /** Sub-steps on which the injector actually flowed, and sub-steps spent
     *  inside its angular window, both per cycle. Their ratio scaled by the
     *  window's share of the 720 deg cycle is the injector's DUTY CYCLE, and
     *  `injectorCapacityRatio_` is now the headroom left on it (1 - duty).
     *  `injectorOpenSubsteps_` is a historical name: it stores the SUM of
     *  fractional openings, not an integer count.
     *
     *  The ratio above it used to be `injected sum / largest single-sub-step
     *  command`, which compares two quantities that are not commensurable: the
     *  command is a "place the whole remaining deficit now" figure recomputed
     *  every sub-step against an inventory that includes runner vapour and wall
     *  film, so it inflates whenever transport losses reopen the deficit, while
     *  the numerator is a per-cycle total. Measured, it disagreed with delivery
     *  in BOTH directions: the Flat-6 at a quarter throttle read 1.000 while
     *  only 27.9 mg of a 34.2 mg request reached the charge, and a K20A about
     *  fifteen per cent short read 0.11. So the warning missed real shortfalls
     *  and fired on healthy engines, which is what was reported from the
     *  application.
     *
     *  Deficit over request was tried next and is also wrong, for a subtler
     *  reason worth keeping: the inventory it subtracts is discounted by the
     *  vaporisation-availability model, which collapses as the window closes,
     *  so the deficit reads large at the very instant it must be sampled even
     *  though the fuel is physically present. Measured, it reported 0.46-0.56
     *  on a Flat-6 and an LS3 that were holding their commanded AFR to within
     *  0.03 with no misfire at all.
     *
     *  Duty cycle has none of those problems because it is a statement about
     *  the ACTUATOR rather than about any fuel accounting: how much of the
     *  cycle the injector had to spend open. Its fault threshold comes from
     *  production practice -- a port injector is sized to stay under roughly
     *  85-90 % duty at rated power -- and not from anything this simulator
     *  reports. */
    std::array<double, 32> injectorOpenSubsteps_ {};
    std::array<double, 32> injectorWindowSubsteps_ {};
    std::array<double, 32> injectorCapacityRatio_ {};
    std::array<double, 32> injectorDutyCycle_ {};
    std::array<double, 32> closedLoopFuelTrim_ {};
    /** Separate high-throttle adaptation cell. A single scalar let a rich WOT
     *  transient erase the low-load correction needed on return to idle. */
    std::array<double, 32> highLoadClosedLoopFuelTrim_ {};
    /** The first transition must be continuous: seed the high-load cell from
     *  the already learned low-load value, then let both regions diverge. */
    std::array<FlameEvent, 32> flameEvents_ {};
    std::array<CompressionIgnitionState, 32> compressionIgnitionStates_ {};
    std::array<CompressionIgnitionResult, 32> compressionIgnitionResults_ {};
    std::array<FuelInjectionState, 32> injectionStates_ {};
    std::array<EndGasKnockState, 32> endGasKnockStates_ {};
    /** A two-stroke's exhaust power valve, 0 shut to 1 open, behind its
     *  servo's lag. */
    double powerValveOpening_ { 1.0 };
    std::array<IndicatedWorkState, 32> indicatedWorkStates_ {};
    std::array<ValveTrainState, 32> valveTrainStates_ {};
    std::array<ValveTrainResult, 32> valveTrainResults_ {};
    std::array<HelmholtzRunnerState, 32> runnerAcousticStates_ {};
    std::array<HelmholtzRunnerResult, 32> runnerAcousticResults_ {};
    std::array<double, 32> ignitionDelayRemainingSeconds_ {};
    /** Burned mole fraction sampled at the instant of ignition. Nothing has
     *  burned yet at that point, so it is the residual left by gas exchange --
     *  the quantity the flame model has always consumed and nothing published. */
    std::array<double, 32> residualGasFractionAtSpark_ {};
    std::array<double, 32> diluentFractionAtSpark_ {};
    /** Equivalence ratio the flame actually saw at ignition. Not the same as
     *  the cycle AFR the ECU reports: with a late injection window the charge
     *  can still be arriving when the spark fires. */
    std::array<double, 32> equivalenceRatioAtSpark_ {};
    std::array<bool, 32> ignitionPending_ {};
    std::array<bool, 32> sparkScheduleArmed_ {};
    std::array<double, 32> scheduledSparkPhaseDegrees_ {};
    /** A diesel's injector has reached the ECU's start of injection this
     *  cycle: the advance the spark schedule latched at the start of
     *  compression, bounded by the injection part's window. */
    std::array<bool, 32> dieselInjectionStarted_ {};
    /** Woschni's reference state, latched at intake closing, from which the
     *  motored pressure of the closed cycle is extrapolated (polytropic,
     *  n = 1.35); valid until the exhaust opens. A diesel's only. */
    std::array<bool, 32> woschniReferenceValid_ {};
    std::array<double, 32> woschniReferenceVolumeL_ {};
    std::array<double, 32> woschniReferencePressureKpa_ {};
    std::array<double, 32> woschniReferenceTemperatureK_ {};
    /** Crank degrees still to travel before the latched spark event fires.
     *  A remaining DISTANCE, not an absolute phase: a commanded retard past
     *  firing TDC places the event after the cycle boundary, which no
     *  single-arc phase target can express. See the latch in step(). */
    std::array<double, 32> sparkScheduleTravelRemainingDegrees_ {};
    std::array<std::uint32_t, 32> commandedSparkEventsThisCycle_ {};
    std::array<std::uint32_t, 32> commandedSparkEventsLastCycle_ {};
    std::array<std::uint32_t, 32> completedIgnitionEventsThisCycle_ {};
    std::array<std::uint32_t, 32> completedIgnitionEventsLastCycle_ {};
    std::array<double, 32> commandedSparkPhaseThisCycle_ {};
    std::array<double, 32> commandedSparkPhaseLastCycle_ {};
    std::array<double, 32> completedIgnitionPhaseThisCycle_ {};
    std::array<double, 32> completedIgnitionPhaseLastCycle_ {};
    FlamePhysicsModel flamePhysics_ {};
    /** Where each two-stroke cylinder stands in its scavenging window. The
     *  window is a state because the composition bias it produces must not be
     *  a function of the port flow it then modulates: a bias derived from its
     *  own flow over-determines the orifice, and its gain grows as the time
     *  step shrinks. Untouched on a four-stroke, where every window reports a
     *  mixed fraction of one and the exhaust boundary is bit-exact unchanged. */
    std::array<TwoStrokeScavengeState, 32> scavengeStates_ {};
    std::array<bool, 32> cylinderMisfires_ {};
    /** Unburnt charge a cylinder exhausted at its EVO, emitted as a pocket
     *  once the per-cylinder pass is done (it may run in parallel). */
    struct PendingUnburnedPocket final {
        bool pending { false };
        double fuelKg { 0.0 };
        double oxygenKg { 0.0 };
        double temperatureK { 0.0 };
        /** The cycle fired: its exhaust lights the pockets already waiting
         *  in the primary. */
        bool lightsResident { false };
    };
    std::array<PendingUnburnedPocket, 32> pendingUnburnedPockets_ {};
    bool previousAfrObservationCommandEnabled_ { false };
    // Whether the engine brake held last step (its speed cut-out's hysteresis).
    void updateExhaustValve(double dtSeconds, const EngineControls&) noexcept;
    /** The nitrous kit (config_.nitrous), once a frame: whether it sprays,
     *  its flow, the bottle's liquid and temperature. */
    void updateNitrous(double dtSeconds, const EngineControls&) noexcept;
    void fillNitrousBottle() noexcept;
    /** The decomposition heat of the nitrous oxygen a reaction consumed,
     *  added to `cell`; J (0 without nitrous in the charge). */
    double releaseNitrousDecomposition(GasCell& cell, double burnedFuelMoles) const noexcept;
    double nitrousBottleMassKg_ { 0.0 };
    double nitrousBottleTemperatureK_ { 293.15 };
    double nitrousSprayFraction_ { 0.0 };
    double nitrousMassFlowKgPerSecond_ { 0.0 };
    /** Oxygen into the plenum, mol/s, from the kit and through the throttle,
     *  smoothed over 0.15 s: their ratio is the charge's nitrous share. */
    double nitrousOxygenRateMolPerSecond_ { 0.0 };
    double throttleOxygenRateMolPerSecond_ { 0.0 };
    double nitrousOxygenShare_ { 0.0 };
    std::uint32_t nitrousRefillsSeen_ { 0 };
    bool engineBrakeHeld_ { false };
    /** The active exhaust valves' actuator (updateExhaustValve). */
    bool exhaustValveStarted_ { false };
    bool exhaustValveAutoOpen_ { false };
    std::unique_ptr<gasdynamics::PartitionedExhaustNetwork> physicalExhaustNetwork_;
    /** The exhaust layout at construction. Live changes keep its topology, so
     * it stays the reference a new network is checked against, from any
     * thread. */
    gasdynamics::ExhaustNetworkLayout constructionExhaustLayout_;
    double constructionExhaustCellLengthM_ { 0.0 };
    /** The cylinder fields a live resize moves. */
    struct CylinderGeometry final {
        double boreMm {};
        double strokeMm {};
        double deckHeightMm {};
        double compressionRatio {};
        double connectingRodMm {};
    };
    struct CylinderResize final {
        std::vector<CylinderGeometry> from;
        std::vector<CylinderGeometry> to;
        std::vector<bool> pending;
        double startSeconds {};
        double rampSeconds {};
    };
    /** Applies the resize to the journals whose cylinders reach their
     * gas-exchange TDC in the coming sub-step. */
    void advanceCylinderResize();
    std::optional<CylinderResize> cylinderResize_;
    /** The camshaft fields a live change glides. */
    struct CamshaftTiming final {
        std::array<double, 14> values {};
    };
    /** Index 0 is config_.camshafts, index 1 + i is config_.banks[i]'s. */
    struct CamshaftChange final {
        std::vector<CamshaftTiming> from;
        std::vector<CamshaftTiming> to;
        double startSeconds {};
        double rampSeconds {};
    };
    void advanceCamshaftChange();
    /** Coolant and oil at their set temperatures when the thermal model is
     *  regulated; nothing otherwise. */
    void applyRegulatedTemperatures() noexcept;
    std::optional<CamshaftChange> camshaftChange_;
    std::uint64_t cylinderGeometryRevision_ { 0 };
    /** Heap-owned scratch keeps the bounded source list out of step()'s large
     * Windows stack frame. */
    gasdynamics::ExhaustFuelReactionResult exhaustFuelReactionScratch_ {};
    gasdynamics::ConservativeState physicalExhaustAmbientState_ {};
    /** Total configured conductance of the network's terminal openings, m^2.
     *  Cached from the compiled layout so the forced-induction block can charge
     *  the turbine its real downstream back pressure. */
    double exhaustOutletConductanceM2_ { 0.0 };
    /** A turbocharger's turbine faces in the exhaust network (one per path,
     *  at its collector) with each one's share of the cylinders; empty when
     *  the turbine is applied at the outlets instead (no collector found). */
    struct ExhaustTurbineFace final {
        std::size_t interfaceIndex { 0 };
        double cylinderShare { 0.0 };
        /** The turbocharger it drives, and its share of that one's cylinders
         *  (the share of the turbine area it gets). */
        std::size_t turbocharger { 0 };
        double turbochargerShare { 0.0 };
    };
    std::vector<ExhaustTurbineFace> exhaustTurbineFaces_;
    /** What each turbocharger's faces did over the last exhaust advance. */
    std::array<double, maximumTurbochargers> networkTurbinePowerW_ {};
    double networkTurbineOutletPressureKpa_ { 0.0 };
    /** Several compressors: the ratio they last held together, each one's
     *  share of the flow, and the time since that solve. */
    double parallelCompressorPressureRatio_ { 1.0 };
    std::array<double, maximumTurbochargers> parallelCompressorFlowShare_ {};
    double parallelCompressorSolveAgeSeconds_ { 0.0 };
    /** The boost controller's integral term, as a wastegate opening. */
    double wastegateIntegral_ { 0.0 };
    /** `compressorSurge`: the charge's pressure, the duct's flow, and the
     *  mass the throttles passed over the last substep. */
    double chargePressureKpa_ { 0.0 };
    double compressorDuctFlowKgPerSecond_ { 0.0 };
    double throttleFlowKgLastStep_ { 0.0 };
    /** Network-port order -> EngineConfig cylinder order, compiled once. */
    std::array<std::size_t, 32> exhaustNetworkCylinderIndex_ {};
    std::unique_ptr<SpscQueue<CylinderPressureSample, 1'024>> pressureSamples_;
    // Coupling-rate exhaust media/reaction telemetry is intentionally separate
    // from the much denser thermodynamic pressure stream.
    std::unique_ptr<SpscQueue<ExhaustAcousticSample, 1'024>> exhaustAcousticSamples_;
    std::uint32_t randomState_ { 0x6d2b79f5U };
    // Engines below the threading threshold retain randomState_ and therefore
    // their historical misfire sequence. Thread-eligible engines use independent
    // seeded streams: a shared xorshift would race and its advance order would
    // depend on worker scheduling. This intentionally changes the exact misfire
    // sequence for 8+ cylinders while keeping it deterministic across runs and
    // across machines with different hardware concurrency.
    std::array<std::uint32_t, 32> cylinderRandomState_ {};
    /** Independent stream keeps opt-in cyclic variability from changing the
     * deterministic misfire decisions. */
    std::array<std::uint32_t, 32> combustionVariationRandomState_ {};
    std::array<double, 32> combustionVariationNormalisedState_ {};
    std::array<double, 32> combustionCycleMultiplier_ {};
    double eventEvaluationAngleDegrees_ { 719.9 };
    double eventEvaluationTimeSeconds_ { 0.0 };
    double indicatedWorkThisCycleJoules_ { 0.0 };
    double brakeWorkThisCycleJoules_ { 0.0 };
    double integratedCrankRadiansThisCycle_ { 0.0 };
    double cycleElapsedSeconds_ { 0.0 };
    double cycleStartTimeSeconds_ { 0.0 };
    std::uint64_t nextCompletedBrakeCycleId_ { 1 };
    bool cycleTelemetryStarted_ { false };
    bool cycleNumericalFault_ { false };
    // Appended owned state: no EngineState ABI or per-engine tuning.
    cam_controller::ShaftCycleWindow valveProfileShaftCycle_;
    std::array<cam_controller::ValveProfileActuator, 32> valveProfileActuators_ {};
    bool hasVariableValveProfiles_ { false };
};
} // namespace enginelab
