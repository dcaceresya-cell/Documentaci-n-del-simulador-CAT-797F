#include <enginelab/simulation/DynoAbsorberController.hpp>

#include <algorithm>
#include <cmath>
#include <limits>
#include <numbers>

namespace enginelab {

DynoAbsorberController::DynoAbsorberController(
    const EngineConfig& config) noexcept {
    // What the engine breathes every 720 deg: a rotary's every face sweeps
    // 1,080, so its summed faces would scale the gains 1.5 times too high
    // (a 13B swung 1,750-5,300 rpm about a 4,000 rpm point).
    const auto displacementM3 =
        breathingDisplacementLitres(config) * 0.001;
    // Controller scaling follows a strong naturally aspirated engine, while
    // the absorber itself has four times that capacity. Equipment capacity
    // must not be confused with a prediction of engine output.
    constexpr double controllerBrakeMeanEffectivePressurePa = 2'500'000.0;
    constexpr double absorberBrakeMeanEffectivePressurePa = 10'000'000.0;
    controllerTorqueScaleNm_ = std::max(
        1.0, controllerBrakeMeanEffectivePressurePa * displacementM3
            / (4.0 * std::numbers::pi));
    maximumBrakeTorqueNm_ = std::max(
        controllerTorqueScaleNm_,
        absorberBrakeMeanEffectivePressurePa * displacementM3
            / (4.0 * std::numbers::pi));
    // The acceleration feedback is a virtual inertia, and behind the speed
    // and acceleration filters (8 and 6 rad/s) and a frame's delay it is
    // stable only while it stays within a few times the shaft's own. Scaled
    // with displacement alone it reached 26-56 times on the catalogue: light
    // shafts (Hayabusa, CP3, CP4, the 13B) swung 15-61 rpm at a held point,
    // and a CP2 the dyno caught at 1,800 rpm fell into a brake limit cycle
    // that its stall recovery re-entered 293 times. Capped at 16 times the
    // shaft, every catalogue point holds within 9 rpm (journal 2026-10-30).
    constexpr double maximumVirtualInertiaRatio = 16.0;
    accelerationGain_ = std::min(controllerTorqueScaleNm_ / 800.0,
        maximumVirtualInertiaRatio * effectiveRotatingInertiaKgM2(config)
            * std::numbers::pi / 30.0);
}

void DynoAbsorberController::reset(
    double initialRpm, double initialBrakeTorqueNm) noexcept {
    filteredRpm_ = std::isfinite(initialRpm)
        ? std::max(0.0, initialRpm) : 0.0;
    filteredTargetRpm_ = filteredRpm_;
    feedForwardTorqueNm_ = std::isfinite(initialBrakeTorqueNm)
        ? std::clamp(initialBrakeTorqueNm, 0.0, maximumBrakeTorqueNm_)
        : 0.0;
    filteredAccelerationRpmPerSecond_ = 0.0;
    filteredTargetAccelerationRpmPerSecond_ = 0.0;
    integralTorqueNm_ = 0.0;
    brakeTorqueNm_ = 0.0;
    fullContactLatched_ = false;
    initialised_ = true;
}

DynoAbsorberOutput DynoAbsorberController::advance(
    double dtSeconds, double targetRpm,
    const EngineState& engineState,
    double requestedContactBandRpm) noexcept {
    const auto dt = std::isfinite(dtSeconds)
        ? std::clamp(dtSeconds, 0.0, 0.05) : 0.0;
    const auto target = std::isfinite(targetRpm)
        ? std::max(1.0, targetRpm) : 1.0;
    if (!initialised_)
        reset(engineState.rpm, engineState.torqueNm);

    // A non-finite observation is not a zero-speed impulse. Hold the last
    // finite observation so one corrupt frame cannot inject an artificial
    // acceleration spike into the controller.
    // The speed averaged over the frame, not the speed at its end: sampled
    // once a frame, the firing ripple aliases into a slow wander the brake
    // answered. A two-stroke twin, firing at 233 Hz at 7,000 rpm, swung
    // +-50 rpm on a 240 Hz frame and could not be held there (nor at 3,500
    // or 7,500 rpm); on a 300 Hz frame it held (journal 2026-10-23).
    const auto observedRpm = engineState.frameAveragedRpm > 0.0
        ? engineState.frameAveragedRpm : engineState.rpm;
    const auto measuredRpm = std::isfinite(observedRpm)
        ? std::max(0.0, observedRpm) : filteredRpm_;
    const auto previousFilteredRpm = filteredRpm_;
    const auto speedFilterAlpha = 1.0 - std::exp(-dt * 8.0);
    filteredRpm_ += (measuredRpm - filteredRpm_)
        * speedFilterAlpha;
    // Compare signals with identical group delay. Comparing filtered rotor
    // speed with an instantaneous 500 rpm/s target creates a deterministic
    // 62.5 rpm error (rate/bandwidth), enough to release the 60 rpm brake
    // contact even when the shaft follows the ramp perfectly.
    const auto previousFilteredTargetRpm = filteredTargetRpm_;
    filteredTargetRpm_ += (target - filteredTargetRpm_)
        * speedFilterAlpha;
    const auto accelerationObservation = dt > 0.0
        ? (filteredRpm_ - previousFilteredRpm) / dt : 0.0;
    const auto rawAcceleration = std::isfinite(accelerationObservation)
        ? accelerationObservation : 0.0;
    filteredAccelerationRpmPerSecond_ +=
        (rawAcceleration - filteredAccelerationRpmPerSecond_)
        * (1.0 - std::exp(-dt * 6.0));
    filteredTargetAccelerationRpmPerSecond_ = dt > 0.0
        ? (filteredTargetRpm_ - previousFilteredTargetRpm) / dt : 0.0;

    // A cycle-average is the actual quantity the absorber must balance. Using
    // instantaneous gas torque makes the brake chase each firing pulse and can
    // excite the crank/flywheel mode it is supposed to hold.
    const auto cycleBrakeTorqueNm =
        std::isfinite(engineState.cycleAveragedTorqueNm)
            && engineState.cycleAveragedTorqueNm > 0.0
        ? engineState.cycleAveragedTorqueNm : 0.0;
    const auto instantaneousBrakeTorqueNm =
        std::isfinite(engineState.torqueNm)
        ? std::max(0.0, engineState.torqueNm) : 0.0;
    const auto measuredBrakeTorqueNm = cycleBrakeTorqueNm > 0.0
        ? cycleBrakeTorqueNm : instantaneousBrakeTorqueNm;
    feedForwardTorqueNm_ += (
        measuredBrakeTorqueNm - feedForwardTorqueNm_)
        * (1.0 - std::exp(-dt * 8.0));
    const auto errorRpm = filteredRpm_ - filteredTargetRpm_;
    const auto proportionalGain = controllerTorqueScaleNm_ / 600.0;
    const auto integralGain = controllerTorqueScaleNm_ / 1'800.0;
    const auto accelerationGain = accelerationGain_;

    // Ramp the absorber into contact across the final 60 rpm. Switching the
    // full feed-forward torque at one threshold creates a relaxation
    // oscillator, most visibly on the high-compression diesel. A wider band
    // starts absorbing too early at the catalogue's 2,000 rpm points and can
    // leave the one-way brake wound up below its target.
    const auto contactBandRpm = std::isfinite(requestedContactBandRpm)
        ? std::clamp(requestedContactBandRpm, 20.0, 1'000.0)
        : 60.0;
    const auto contactPhase = std::clamp(
        (errorRpm + contactBandRpm) / contactBandRpm, 0.0, 1.0);
    const auto approachContactScale =
        contactPhase * contactPhase * (3.0 - 2.0 * contactPhase);
    // The smooth approach prevents a brake step. Once it carries roughly 90%
    // of the requested torque, capture the rotor and expose full contact; the
    // old memoryless scale could settle permanently around 93%, making a 95%
    // measurement gate mathematically unreachable. A full contact is released
    // only after falling an entire band below target, so ramp ripple cannot
    // chatter the coupling state.
    if (!fullContactLatched_ && approachContactScale >= 0.90)
        fullContactLatched_ = true;
    else if (fullContactLatched_ && errorRpm < -contactBandRpm)
        fullContactLatched_ = false;
    const auto contactScale = fullContactLatched_
        ? 1.0 : approachContactScale;
    const auto contactedFeedForwardTorqueNm =
        feedForwardTorqueNm_ * contactScale;
    auto unclampedBrakeTorqueNm = 0.0;
    auto saturatedLow = false;
    auto saturatedHigh = false;
    if (contactScale <= 0.0) {
        integralTorqueNm_ = 0.0;
        brakeTorqueNm_ = 0.0;
    } else {
        // Do not integrate the several-thousand-rpm pull-down from a cold
        // free-rev. That stored brake torque used to survive after the shaft
        // reached its setpoint and held the EA288 just below 2,000 rpm. Only
        // trim steady-state error inside the contact band; outside it, forget
        // any trim left by a previous sweep target.
        const auto integralCandidate =
            std::abs(errorRpm) <= contactBandRpm
            ? integralTorqueNm_ + errorRpm * integralGain * dt
            : integralTorqueNm_ * std::exp(-dt * 4.0);
        // Acceleration feedback is relative to the commanded ramp. The former
        // absolute term added brake whenever the rotor accelerated at all, so
        // an ideal 500 rpm/s follower was actively resisted and repeatedly
        // fell out of contact. At a steady hold target acceleration is zero,
        // preserving the established damping law.
        const auto accelerationErrorRpmPerSecond =
            filteredAccelerationRpmPerSecond_
            - filteredTargetAccelerationRpmPerSecond_;
        const auto unsaturated = contactedFeedForwardTorqueNm
            + integralCandidate
            + errorRpm * proportionalGain
            + accelerationErrorRpmPerSecond * accelerationGain;
        const auto saturated = std::clamp(
            unsaturated, 0.0, maximumBrakeTorqueNm_);
        if (unsaturated == saturated
            || (unsaturated < 0.0 && errorRpm > 0.0)
            || (unsaturated > maximumBrakeTorqueNm_
                && errorRpm < 0.0)) {
            integralTorqueNm_ = integralCandidate;
        }
        integralTorqueNm_ = std::clamp(
            integralTorqueNm_,
            -maximumBrakeTorqueNm_, maximumBrakeTorqueNm_);
        unclampedBrakeTorqueNm = contactedFeedForwardTorqueNm
            + integralTorqueNm_
            + errorRpm * proportionalGain
            + accelerationErrorRpmPerSecond * accelerationGain;
        if (!std::isfinite(unclampedBrakeTorqueNm))
            unclampedBrakeTorqueNm = 0.0;
        brakeTorqueNm_ = std::clamp(
            unclampedBrakeTorqueNm, 0.0, maximumBrakeTorqueNm_);

        // The clamp can change a value by a few ULPs at a boundary. Expose a
        // capacity event only when the rejected torque is material compared
        // with the scale of this absorber.
        const auto saturationToleranceNm =
            64.0 * std::numeric_limits<double>::epsilon()
            * std::max(1.0, maximumBrakeTorqueNm_);
        saturatedLow = unclampedBrakeTorqueNm < -saturationToleranceNm;
        saturatedHigh = unclampedBrakeTorqueNm
            > maximumBrakeTorqueNm_ + saturationToleranceNm;
    }
    return {
        brakeTorqueNm_,
        filteredRpm_,
        filteredAccelerationRpmPerSecond_,
        contactScale > 0.0,
        contactScale,
        unclampedBrakeTorqueNm,
        saturatedLow,
        saturatedHigh,
    };
}

} // namespace enginelab
