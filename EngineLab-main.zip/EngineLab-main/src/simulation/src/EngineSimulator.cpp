#include <enginelab/simulation/EngineSimulator.hpp>
#include <enginelab/foundation/TwoStrokePorts.hpp>
#include <enginelab/foundation/ForcedInductionFlow.hpp>
#include <enginelab/foundation/ThreadScheduling.hpp>
#include <enginelab/simulation/EngineThermalModel.hpp>
#include <enginelab/simulation/TransientChargeEstimator.hpp>
#include <enginelab/exhaust/ExhaustGraph.hpp>
#include <enginelab/physics/MechanicalKinematics.hpp>
#include <enginelab/physics/CylinderHeatTransferModel.hpp>
#include <enginelab/physics/CombustionCycleVariation.hpp>
#include <enginelab/physics/DuctWallHeatTransferModel.hpp>
#include <algorithm>
#include <cstdlib>
#include <bit>
#include <array>
#include <cmath>
#include <exception>
#include <limits>
#include <numbers>
#include <numeric>
#include <optional>
#include <span>
#include <stdexcept>
#include <utility>

namespace enginelab {
namespace {
[[nodiscard]] double smooth(double current, double target, double dt, double rate) noexcept {
    return current + (target - current) * (1.0 - std::exp(-dt * rate));
}

[[nodiscard]] gasdynamics::ThermodynamicModel exhaustThermodynamicsFor(
    const EngineConfig& config) noexcept {
    auto model = gasdynamics::ThermodynamicModel::standardCombustionGas();
    const auto fuelIndex = static_cast<std::size_t>(gasdynamics::GasSpecies::fuel);
    const auto burnedIndex = static_cast<std::size_t>(gasdynamics::GasSpecies::burned);
    const auto fuelMolarMassKg = config.fuelProperties.molarMassGramsPerMole * 0.001;
    model.species[fuelIndex].molarMassKgPerMol = fuelMolarMassKg;
    model.species[burnedIndex].molarMassKgPerMol =
        (fuelMolarMassKg
         + config.fuelProperties.oxygenMolesPerFuelMole * GasCell::oxygenMolarMassKg)
        / config.fuelProperties.productMolesPerFuelMole;
    return model;
}

[[nodiscard]] gasdynamics::ConservativeState networkStateForGasCell(
    const GasCell& cell) noexcept {
    gasdynamics::ConservativeState result;
    const auto inverseVolume = 1.0 / cell.volumeM3();
    result.speciesMassDensityKgPerM3[
        static_cast<std::size_t>(gasdynamics::GasSpecies::oxygen)] =
        cell.mixture().oxygenMoles * GasCell::oxygenMolarMassKg * inverseVolume;
    result.speciesMassDensityKgPerM3[
        static_cast<std::size_t>(gasdynamics::GasSpecies::inert)] =
        cell.mixture().inertMoles * GasCell::inertMolarMassKg * inverseVolume;
    result.speciesMassDensityKgPerM3[
        static_cast<std::size_t>(gasdynamics::GasSpecies::fuel)] =
        cell.mixture().fuelMoles * cell.configuredFuelMolarMassKg() * inverseVolume;
    result.speciesMassDensityKgPerM3[
        static_cast<std::size_t>(gasdynamics::GasSpecies::burned)] =
        cell.mixture().burnedMoles * cell.configuredBurnedGasMolarMassKg() * inverseVolume;
    // The chamber is a zero-dimensional reservoir. Its resolved bulk momentum
    // has no unique exhaust-axis projection; valve-wall reactions carry it.
    result.momentumDensityKgPerM2S = 0.0;
    result.totalEnergyDensityJPerM3 = cell.internalEnergyJoules() * inverseVolume;
    return result;
}

/** The cylinder's composition as the exhaust port sees it during a scavenging
 * window, biased towards burned gas by `mixedFraction`.
 *
 * Conservation is free here, and that is the whole reason the model goes in at
 * this point rather than at the port areas. The network removes exactly the
 * species masses this state offers, reports them back in a
 * `CylinderGasExchange`, and `cylinderDeltaForExchange` negates those same
 * masses onto the cylinder. Species, mass and energy therefore balance for any
 * composition presented here; the only way to break it is to offer more of a
 * species than the cylinder holds, which `biasedOutflowDensities` caps against.
 *
 * A `mixedFraction` of one -- every four-stroke, and any two-stroke whose loop
 * length is zero -- returns `networkStateForGasCell` bit for bit.
 */
[[nodiscard]] gasdynamics::ConservativeState scavengedNetworkStateForGasCell(
    const GasCell& cell, double mixedFraction) noexcept {
    auto result = networkStateForGasCell(cell);
    if (mixedFraction >= 1.0) return result;
    const auto oxygen = static_cast<std::size_t>(gasdynamics::GasSpecies::oxygen);
    const auto inert = static_cast<std::size_t>(gasdynamics::GasSpecies::inert);
    const auto fuel = static_cast<std::size_t>(gasdynamics::GasSpecies::fuel);
    const auto burned = static_cast<std::size_t>(gasdynamics::GasSpecies::burned);
    const auto biased = biasedOutflowDensities(
        result.speciesMassDensityKgPerM3[oxygen],
        result.speciesMassDensityKgPerM3[inert],
        result.speciesMassDensityKgPerM3[fuel],
        result.speciesMassDensityKgPerM3[burned],
        mixedFraction);
    result.speciesMassDensityKgPerM3[oxygen] = biased.oxygen;
    result.speciesMassDensityKgPerM3[inert] = biased.inert;
    result.speciesMassDensityKgPerM3[fuel] = biased.fuel;
    result.speciesMassDensityKgPerM3[burned] = biased.burned;
    // The energy density is deliberately left alone. Pressure and temperature
    // at the boundary drive the flow; this model says what the gas leaving IS,
    // not how much of it leaves.
    return result;
}

[[nodiscard]] GasInventoryDelta cylinderDeltaForExchange(
    const gasdynamics::CylinderGasExchange& exchange,
    const GasCell& cell) noexcept {
    const auto oxygen = static_cast<std::size_t>(gasdynamics::GasSpecies::oxygen);
    const auto inert = static_cast<std::size_t>(gasdynamics::GasSpecies::inert);
    const auto fuel = static_cast<std::size_t>(gasdynamics::GasSpecies::fuel);
    const auto burned = static_cast<std::size_t>(gasdynamics::GasSpecies::burned);
    return {
        {
            -exchange.speciesMassKg[oxygen] / GasCell::oxygenMolarMassKg,
            -exchange.speciesMassKg[inert] / GasCell::inertMolarMassKg,
            -exchange.speciesMassKg[fuel] / cell.configuredFuelMolarMassKg(),
            -exchange.speciesMassKg[burned] / cell.configuredBurnedGasMolarMassKg(),
        },
        -exchange.totalEnergyJ,
        0.0,
        0.0,
    };
}

[[nodiscard]] bool carryCylinderExchange(
    gasdynamics::ConservativeState& reservoir, double volumeM3,
    const gasdynamics::CylinderGasExchange& exchange,
    const gasdynamics::EulerMixtureModel& mixture) noexcept {
    if (!(volumeM3 > 0.0)) return false;
    const auto inverseVolume = 1.0 / volumeM3;
    for (std::size_t species = 0;
         species < gasdynamics::gasSpeciesCount; ++species)
        reservoir.speciesMassDensityKgPerM3[species] -=
            exchange.speciesMassKg[species] * inverseVolume;
    reservoir.totalEnergyDensityJPerM3 -= exchange.totalEnergyJ * inverseVolume;
    return mixture.canonicaliseSpeciesRoundoff(reservoir)
        && mixture.primitiveFromConservative(reservoir).has_value();
}

/** Inventory delta a runner-mouth sample applies to the plenum cell.
 *
 * The runner mouth is compiled as the network's "outlet" whose ambient
 * reservoir is the plenum, so a mouth sample is positive from the runner INTO
 * the plenum: the plenum's inventory moves WITH the sample (the network's own
 * inventory already moved against it). During a normal intake stroke every
 * component is therefore negative — the plenum is being drawn down.
 */
[[nodiscard]] GasInventoryDelta plenumDeltaForMouthSample(
    const gasdynamics::ExhaustOutletFlowSample& sample,
    const GasCell& cell) noexcept {
    const auto oxygen = static_cast<std::size_t>(gasdynamics::GasSpecies::oxygen);
    const auto inert = static_cast<std::size_t>(gasdynamics::GasSpecies::inert);
    const auto fuel = static_cast<std::size_t>(gasdynamics::GasSpecies::fuel);
    const auto burned = static_cast<std::size_t>(gasdynamics::GasSpecies::burned);
    return {
        {
            sample.speciesMassKg[oxygen] / GasCell::oxygenMolarMassKg,
            sample.speciesMassKg[inert] / GasCell::inertMolarMassKg,
            sample.speciesMassKg[fuel] / cell.configuredFuelMolarMassKg(),
            sample.speciesMassKg[burned] / cell.configuredBurnedGasMolarMassKg(),
        },
        sample.transferredEnergyJ,
        0.0,
        0.0,
    };
}

// From this cylinder count up, the shared intake plenum is frozen at the start of
// each gas sub-step and every cylinder reads that snapshot (Jacobi) instead of
// seeing the previous cylinder's writes (Gauss-Seidel).
//
// The threshold originally existed to make a per-cylinder fork-join safe, and was
// named for it. That fork-join has been REMOVED, and its removal is not an
// optimisation to be reversed on a faster machine: the dispatch rate is one
// barrier per gas sub-step, which at 5,940 rpm on a V8 is ~19,000/s, and no
// condition-variable barrier can amortise a body that small. Measured on a
// 16-thread laptop, realtime factor (simulated seconds produced per wall second,
// EngineLabRealtimeBudgetHarness), LS3 V8 / Merlin V12:
//
//   fork-join, broadcast wake + 2048-yield spin   0.266 / 0.286
//   fork-join, per-worker targeted wake + spin    0.249 / 0.256
//   fork-join, per-worker wake, no spin           0.282 / 0.336
//   inline (shipped)                              0.343 / 0.396
//
// Every threaded variant lost, and the spin actively stole cycles from the very
// thread the barrier was waiting on. A real parallelisation here would have to
// keep the worker threads resident ACROSS sub-steps, synchronising only where the
// shared plenum is touched -- a different architecture, not a tuning of this one.
// The removal was verified bit-identical on the LS3 (torque, IMEP, VE and
// air_mg agree to every printed digit).
//
// That architecture now exists: the intake/exhaust CylinderWorkerPool is resident
// and the per-cylinder body grew to 1.5-2.2 us. The pass runs on it again from
// this threshold up, measured 2026-10-20 against the inline loop in the same
// binary (best of 4, free-run): designed V12 0.711 -> 0.877, LS3 1.171 -> 1.368,
// Merlin 1.400 -> 1.755, 2JZ control unchanged; publishing each cylinder's
// end-of-sub-step state on the workers too: 0.933, 1.427, 1.855 (journal).
constexpr std::size_t decoupledSharedVolumeCylinderThreshold = 8;

// Forward intake coupling interval. With the characteristic valve boundary the
// joint network is accurate at Courant 0.8, so the interval, not the Courant
// limit, sets its cost. K20, against exchange on every substep: 250 us within
// 0.8 % of torque, 330 us within 1.3 %, 400 us within 1.5 %. Realtime at
// 5000 rpm (Merlin 3040): LS3 1.04 / 1.08, Merlin 0.98-1.01 / 1.15 at
// 250 / 330 us (journal 2026-10-09).
constexpr double defaultForwardIntakeIntervalSeconds = 330.0e-6;

// Representative metal defaults for thermal walls. They describe
// geometry/material, never a target gas temperature: both wall temperatures
// emerge from conserved exchange with the simulated gas.
constexpr double aluminiumRunnerWallThicknessM = 0.003;
constexpr double aluminiumDensityKgPerM3 = 2'700.0;
constexpr double aluminiumSpecificHeatJPerKgK = 900.0;
constexpr double runnerExternalHeatTransferWPerM2K = 12.0;
// The duct wall exchange is sub-rated to this interval instead of running on
// every solver sub-step. A runner cell moves about 0.04% of the gas-wall
// equilibrium gap per sub-step -- a ~69 ms time constant integrated every
// ~26 us -- so the exchange itself is resolved some three orders of magnitude
// finer than it needs. What sets the floor is not that time constant but the
// sampling of the heat-transfer coefficient, which follows the flow: the
// binding scale is the cell residence time L/u, about 600 us at 50 m/s
// through a 30 mm cell. 150 us keeps four samples inside the fastest
// residence time and about thirty across an intake valve event at 7,000 rpm,
// while cutting the wall work by four.
constexpr double ductWallHeatUpdateIntervalSeconds = 150.0e-6;
// Ring blow-by is sub-rated the same way. Its ~0.1 mm2 leak passes well under
// one per cent of the charge per cycle; 100 us is 7 crank degrees at 12,000 rpm
// and leaves every sub-step longer than that (idle, cruise) exactly as it was.
constexpr double blowByUpdateIntervalSeconds = 100.0e-6;
constexpr double stainlessExhaustWallThicknessM = 0.0015;
/** Zabetakis' modified Burgess-Wheeler law: a hydrocarbon's flammability
 * limits widen by 0.0721 % of their 25 C value per kelvin (US Bureau of
 * Mines Bulletin 627, 1965). */
constexpr double zabetakisRichLimitWideningPerK = 7.21e-4;
constexpr double stainlessDensityKgPerM3 = 7'900.0;
constexpr double stainlessSpecificHeatJPerKgK = 500.0;
constexpr double exhaustExternalHeatTransferWPerM2K = 18.0;

/**
 * Flow area an intake still presents with the throttle plate fully closed.
 *
 * Scaled by the number of bores, exactly as the plate area is: leakage is a
 * property of each plate-in-bore fit, so a four-throttle intake leaks four
 * times as much as a single-throttle one of the same bore size. Clamped
 * non-negative so an authored configuration cannot subtract flow area.
 *
 * See IntakeConfig::closedThrottleLeakageAreaMm2 for why this belongs to the
 * hardware rather than to the ECU's idle command.
 */
[[nodiscard]] double closedThrottleLeakageAreaM2(const IntakeConfig& intake) noexcept {
    const auto perBoreMm2 = std::isfinite(intake.closedThrottleLeakageAreaMm2)
        ? std::max(0.0, intake.closedThrottleLeakageAreaMm2) : 0.0;
    return perBoreMm2 * static_cast<double>(std::max<std::uint32_t>(1, intake.throttleCount))
        * 1.0e-6;
}

/** What feeds the plenum: the throttle, or with individual throttles the bores
 *  held fully open, the plenum being the airbox and the plates in the runners. */
/** A carburettor's idle air path against the one its pilot was sized at:
 *  the closed-slide leak plus the bypass at the idle governor's neutral
 *  opening. The ECU's idle air stands in for the slide's idle stop, and
 *  opening that stop uncovers the progression holes, so the pilot follows.
 *  The idle stop screw can hold the slide past the bypass's whole travel. */
[[nodiscard]] double carburettorIdleCircuitOpening(const IntakeConfig& intake,
                                                   double idleAirOpening) noexcept {
    const auto leak = closedThrottleLeakageAreaM2(intake);
    const auto bypass = std::max(0.0, intake.idleBypassAreaMm2) * 1.0e-6;
    const auto neutral = leak + bypass * carburettorPilotSizingIdleOpening;
    if (!(neutral > 0.0)) return 1.0;
    return (leak + bypass * std::clamp(idleAirOpening, 0.0,
        carburettorIdleScrewOpening(carburettorMaximumIdleScrewTurns))) / neutral;
}

[[nodiscard]] double plenumInletAreaM2(const IntakeConfig& intake,
                                       double throttleAreaM2,
                                       double throttlePlateAreaM2) noexcept {
    return intake.individualThrottles ? throttlePlateAreaM2 : throttleAreaM2;
}

/** Where a turbine sits: the face out of each exhaust path's collector, the
 *  first junction all of the path's cylinders reach (where the 3-D view bolts
 *  the turbo), when it leaves through a single face into a duct; on a path
 *  with no junction, the face out of the one pipe its ports open into. Each
 *  face carries its path's share of the cylinders. Empty unless every path
 *  with cylinders has one. */
struct TurbineFace final {
    std::size_t interfaceIndex { 0 };
    double cylinderShare { 0.0 };
    std::size_t pathIndex { 0 };
    std::size_t cylinders { 0 };
};
[[nodiscard]] std::vector<TurbineFace> collectorTurbineFaces(
    const gasdynamics::ExhaustNetworkLayout& layout) {
    using gasdynamics::ExhaustEndpointType;
    const auto ductCount = layout.ducts().size();
    const auto slot = [ductCount](const gasdynamics::ExhaustEndpoint& endpoint) {
        return endpoint.type == ExhaustEndpointType::junction
            ? ductCount + endpoint.elementIndex : endpoint.elementIndex;
    };
    // Cylinders reaching each element (ducts, then junctions), relaxed along
    // the faces until it settles: the graph is a DAG of finite depth.
    std::vector<std::size_t> own(ductCount + layout.junctions().size(), 0);
    std::vector<std::size_t> pathCylinders;
    for (const auto& port : layout.cylinderPorts()) {
        ++own[slot(port.networkEndpoint)];
        if (port.pathIndex >= pathCylinders.size()) pathCylinders.resize(port.pathIndex + 1, 0);
        ++pathCylinders[port.pathIndex];
    }
    auto fed = own;
    for (std::size_t pass = 0; pass <= fed.size(); ++pass) {
        auto next = own;
        for (const auto& connection : layout.interfaces())
            next[slot(connection.downstream)] += fed[slot(connection.upstream)];
        if (next == fed) break;
        fed = std::move(next);
    }
    const auto totalCylinders = layout.cylinderPorts().size();
    std::vector<TurbineFace> faces;
    for (std::size_t path = 0; path < pathCylinders.size(); ++path) {
        if (pathCylinders[path] == 0) continue;
        auto found = false;
        for (std::size_t junction = 0; junction < layout.junctions().size() && !found; ++junction) {
            if (layout.junctions()[junction].pathIndex != path
                || fed[ductCount + junction] != pathCylinders[path])
                continue;
            std::size_t outgoing = 0;
            std::size_t outgoingIndex = 0;
            auto upstreamComplete = false;
            for (std::size_t index = 0; index < layout.interfaces().size(); ++index) {
                const auto& connection = layout.interfaces()[index];
                if (connection.upstream.type == ExhaustEndpointType::junction
                    && connection.upstream.elementIndex == junction) {
                    ++outgoing;
                    outgoingIndex = index;
                }
                if (connection.downstream.type == ExhaustEndpointType::junction
                    && connection.downstream.elementIndex == junction
                    && fed[slot(connection.upstream)] == pathCylinders[path])
                    upstreamComplete = true;
            }
            if (upstreamComplete || outgoing != 1
                || layout.interfaces()[outgoingIndex].downstream.type
                    == ExhaustEndpointType::junction)
                continue;
            faces.push_back({ outgoingIndex, static_cast<double>(pathCylinders[path])
                / static_cast<double>(std::max<std::size_t>(1, totalCylinders)), path, pathCylinders[path] });
            found = true;
        }
        // No junction: every port of the path opens into one pipe (a single,
        // or a path a cylinder has to itself). Its turbine is bolted where
        // that primary ends, into the duct that follows -- where the 3-D view
        // draws it. Without this the turbine was a lumped one at the outlet.
        if (!found) {
            std::optional<std::size_t> primary;
            auto onePipe = true;
            for (const auto& port : layout.cylinderPorts()) {
                if (port.pathIndex != path) continue;
                if (port.networkEndpoint.type == ExhaustEndpointType::junction
                    || (primary && *primary != port.networkEndpoint.elementIndex))
                    onePipe = false;
                primary = port.networkEndpoint.elementIndex;
            }
            std::size_t outgoing = 0;
            std::size_t outgoingIndex = 0;
            for (std::size_t index = 0; onePipe && primary && index < layout.interfaces().size(); ++index) {
                const auto& connection = layout.interfaces()[index];
                if (connection.upstream.type == ExhaustEndpointType::ductOutlet
                    && connection.upstream.elementIndex == *primary) {
                    ++outgoing;
                    outgoingIndex = index;
                }
            }
            if (onePipe && primary && outgoing == 1
                && layout.interfaces()[outgoingIndex].downstream.type != ExhaustEndpointType::junction) {
                faces.push_back({ outgoingIndex, static_cast<double>(pathCylinders[path])
                    / static_cast<double>(std::max<std::size_t>(1, totalCylinders)), path, pathCylinders[path] });
                found = true;
            }
        }
        if (!found) return {};
    }
    return faces;
}

/** Throttle flow between the plenum and its upstream boundary, keeping the
 * fuel vapour that reverses through the throttle.
 *
 * The upstream side is a fixed-composition boundary, so fuel leaving the
 * plenum there used to vanish. The reversed gas is tracked as a slug sitting
 * just upstream of the throttle: a pulsating column is plug flow, so forward
 * flow draws the slug back first, at its own fuel concentration. The slug
 * cannot outgrow the airbox; what overflows it leaves through the snorkel.
 * Without an airbox (open bellmouth) nothing is kept.
 */
void throttleFlowKeepingReversedFuel(GasCell& plenum, AirboxSlug& slug,
                                     double airboxVolumeLitres,
                                     double boundaryPressureKpa,
                                     double boundaryTemperatureK,
                                     double throttleAreaM2,
                                     double dischargeCoefficient,
                                     double dtSeconds,
                                     bool reedValve = false) noexcept {
    // A two-stroke's reed valve only lets the charge into its crankcase: shut
    // while the crankcase is above the carburettor, and a step that would
    // have reversed is undone (a perfect check valve, no petal dynamics).
    if (reedValve && plenum.pressureKpa() >= boundaryPressureKpa) return;
    const auto beforeReed = reedValve ? std::optional<GasCell>(plenum) : std::nullopt;
    const auto fuelBeforeMoles = plenum.mixture().fuelMoles;
    const auto massBeforeKg = plenum.massKg();
    (void)ConservativeGasSystem::flowFromBoundary(plenum, boundaryPressureKpa,
        boundaryTemperatureK, throttleAreaM2, dischargeCoefficient, dtSeconds,
        0.0, -1.0); // plenum -> upstream compressor/atmosphere
    if (beforeReed && plenum.massKg() < massBeforeKg) {
        plenum = *beforeReed;
        return;
    }
    if (!(airboxVolumeLitres > 0.0)) {
        slug = {};
        return;
    }
    const auto netInflowKg = plenum.massKg() - massBeforeKg;
    if (netInflowKg < 0.0) {
        constexpr double airMolarMassKgPerMol = 0.028965;
        constexpr double gasConstantJPerMolK = 8.314462618;
        const auto airboxMassKg = boundaryPressureKpa * airboxVolumeLitres
            * airMolarMassKgPerMol
            / (gasConstantJPerMolK * std::max(1.0, boundaryTemperatureK));
        slug.massKg -= netInflowKg;
        slug.fuelMoles += std::max(0.0, fuelBeforeMoles - plenum.mixture().fuelMoles);
        if (slug.massKg > airboxMassKg) {
            slug.fuelMoles *= airboxMassKg / slug.massKg;
            slug.massKg = airboxMassKg;
        }
        return;
    }
    if (!(netInflowKg > 0.0) || !(slug.massKg > 0.0))
        return;
    const auto drawnFraction = std::min(1.0, netInflowKg / slug.massKg);
    const auto returnedMoles = slug.fuelMoles * drawnFraction;
    plenum.injectFuelMoles(returnedMoles, boundaryTemperatureK);
    slug.fuelMoles -= returnedMoles;
    slug.massKg -= slug.massKg * drawnFraction;
}

/** Isentropic ideal-gas orifice flow from an upstream reservoir.
 *
 * Used for the compressor bypass valve, whose upstream charge pipe is a
 * boundary reservoir in the current zero-dimensional boost model. This is the
 * same choked/subcritical law used by the conservative gas solver, exposed
 * here without fabricating a control-volume inventory that the schema does not
 * yet provide.
 */
[[nodiscard]] double reservoirOrificeMassFlowKgPerSecond(
    double upstreamPressureKpa, double downstreamPressureKpa,
    double temperatureK, double effectiveAreaM2,
    double dischargeCoefficient) noexcept {
    if (!(upstreamPressureKpa > downstreamPressureKpa)
        || !(downstreamPressureKpa > 0.0) || !(temperatureK > 0.0)
        || !(effectiveAreaM2 > 0.0) || !(dischargeCoefficient > 0.0))
        return 0.0;
    constexpr double gamma = 1.4;
    constexpr double specificGasConstant = 287.05;
    const auto pressureRatio = downstreamPressureKpa / upstreamPressureKpa;
    const auto criticalRatio = std::pow(2.0 / (gamma + 1.0),
        gamma / (gamma - 1.0));
    const auto upstreamPressurePa = upstreamPressureKpa * 1'000.0;
    if (pressureRatio <= criticalRatio) {
        return dischargeCoefficient * effectiveAreaM2 * upstreamPressurePa
            * std::sqrt(gamma / (specificGasConstant * temperatureK))
            * std::pow(2.0 / (gamma + 1.0),
                (gamma + 1.0) / (2.0 * (gamma - 1.0)));
    }
    const auto pressureTerm = 2.0 * gamma / (gamma - 1.0)
        * (std::pow(pressureRatio, 2.0 / gamma)
            - std::pow(pressureRatio, (gamma + 1.0) / gamma));
    return dischargeCoefficient * effectiveAreaM2 * upstreamPressurePa
        / std::sqrt(specificGasConstant * temperatureK)
        * std::sqrt(std::max(0.0, pressureTerm));
}

// Private per-cylinder scratch for one gas sub-step. Every cross-cylinder result
// the loop used to accumulate into a shared scalar (or into a shared plenum /
// collector) is written here per cylinder instead, so the per-cylinder body has
// no shared write and can run in any order. The fixed-order reductions after the
// loop reproduce the original serial sums bit-for-bit.
struct CylinderSubstepScratch final {
    double reciprocatingTorque {};
    double combustionPulse {};
    double gasIndicatedTorque {};
    double intakeRunnerPressure {};
    double exhaustRunnerPressure {};
    double exhaustTemperatureK {};
    double pistonFrictionPowerW {};
    double pistonBreakawayTorqueNm {};
    double pistonSpeed {};
    double peakPistonAcceleration {};
    double endGasKnockLevel {};
    double releasedEnergyJoules {};
    double meteredFuelMassKg {};
    // Engine-wide events the cylinder pass raised. They are applied to state_
    // in cylinder order after the pass, so the pass writes nothing shared.
    std::uint64_t commandedSparkEvents {};
    bool misfired {};
    double misfireAirFuelRatio {};
    bool solverResolutionLimited {};
};

struct ParallelSubstepState final {
    std::array<GasCell, 32> frozenPlenum {};
    std::array<CylinderSubstepScratch, 32> scratch {};
};

/**
 * Effective (Cd-weighted) valve flow area in mm^2.
 *
 * Two regimes, and the discharge coefficient means different things in each.
 * At low lift the jet stays attached to the seat and the flow is genuinely
 * curtain-limited, so `dischargeCoefficient` is the curtain-referenced Cd the
 * camshaft authors (0.6-0.7 for a real port, which is what the authored flow
 * curves carry). Above roughly L/D 0.2 the jet separates and the effective area
 * stops growing with lift: what it saturates at is a property of the PORT, and
 * the literature reports it as a fraction of the valve head area pi*D^2/4 --
 * 0.55-0.65 for a good production intake port, 0.50-0.55 for an exhaust one
 * (Heywood, Internal Combustion Engine Fundamentals, ch. 6).
 *
 * This used to cap the GEOMETRIC curtain at a geometric seat throat (0.88*D)
 * and let the caller multiply by Cd afterwards, which applied the seat
 * contraction twice: the delivered plateau came out at 0.62 * 0.88^2 = 0.48 of
 * head area, below any real production port. Measured on the CP3, restoring the
 * plateau to the literature band is worth ~12 % of peak power on its own. The
 * cap is therefore applied to the EFFECTIVE area, after Cd, and stated in the
 * units the literature reports it in. Low lift is untouched, which matters:
 * that regime governs idle bypass flow and overlap backflow.
 *
 * The returned area already carries Cd, so callers pass a discharge coefficient
 * of 1.0 alongside it.
 */
[[nodiscard]] double effectiveValveAreaMm2(double boreMm, double liftMm,
                                           std::uint32_t valveCount,
                                           double configuredDiameterMm,
                                           double dischargeCoefficient,
                                           double multiValveBoreRatio,
                                           double singleValveBoreRatio,
                                           double maximumHeadAreaFraction) noexcept {
    const auto count = static_cast<double>(std::clamp<std::uint32_t>(valveCount, 1, 4));
    // A multi-valve head packs smaller valves: literature per-valve D/B is
    // 0.44-0.48 intake and 0.38-0.42 exhaust for a two-valve head, against
    // 0.37-0.40 and 0.30-0.34 for a four-valve one. The ordering is what buys
    // a four-valve head its extra total area despite the smaller valves.
    const auto derivedRatio = valveCount == 1 ? singleValveBoreRatio : multiValveBoreRatio;
    const auto diameterMm = configuredDiameterMm > 0.0
        ? configuredDiameterMm : std::clamp(boreMm * derivedRatio, 12.0, 80.0);
    const auto coefficient = std::max(0.0, dischargeCoefficient);
    const auto curtainAreaMm2 = count * std::numbers::pi * diameterMm
        * std::max(0.0, liftMm);
    const auto headAreaMm2 = count * std::numbers::pi * diameterMm * diameterMm * 0.25;
    return std::min(coefficient * curtainAreaMm2,
                    maximumHeadAreaFraction * headAreaMm2);
}

[[nodiscard]] double crankOffsetDegreesFor(const EngineConfig& config, const CylinderConfig& cylinder) noexcept {
    (void)config;
    return cylinder.crankOffsetDegrees;
}

/** Added to (crank angle - offset) before wrapping it into `cycle`: above any
 *  offset and a whole number of cycles. 1,440 is not one of a rotary face's
 *  1,080 (it put every port 360 deg off its face's volume); the piston cycles
 *  keep 1,440, which a larger bias would round differently. */
[[nodiscard]] constexpr double phaseWrapBiasDegrees(double cycle) noexcept {
    return cycle > 720.0 ? 2'160.0 : 1'440.0;
}

[[nodiscard]] std::size_t exhaustPathIndexFor(const EngineConfig& config,
                                              const CylinderConfig& cylinder) noexcept {
    const auto path = std::find_if(config.exhaustPaths.begin(), config.exhaustPaths.end(),
        [&cylinder](const ExhaustPathConfig& item) {
            return std::find(item.cylinderIds.begin(), item.cylinderIds.end(), cylinder.id)
                != item.cylinderIds.end();
        });
    return path != config.exhaustPaths.end()
        ? static_cast<std::size_t>(std::distance(config.exhaustPaths.begin(), path)) : 0U;
}

[[nodiscard]] std::size_t intakePathIndexFor(const EngineConfig& config,
                                             const CylinderConfig& cylinder) noexcept {
    const auto path = std::find_if(config.intakePaths.begin(), config.intakePaths.end(),
        [&cylinder](const IntakePathConfig& item) {
            return std::find(item.cylinderIds.begin(), item.cylinderIds.end(), cylinder.id)
                != item.cylinderIds.end();
        });
    return path != config.intakePaths.end()
        ? static_cast<std::size_t>(std::distance(config.intakePaths.begin(), path)) : 0U;
}

[[nodiscard]] const IntakeConfig& intakeGeometryAt(const EngineConfig& config,
                                                   std::size_t pathIndex) noexcept {
    return pathIndex < config.intakePaths.size() ? config.intakePaths[pathIndex].geometry : config.intake;
}

/** Forward travel from `previous` to `current` on a cycle of `cycle`
 *  degrees: 720 for a cylinder of a four-stroke, 360 for a two-stroke, and
 *  720 for the crank angle itself, whatever the engine. */
[[nodiscard]] double forwardPhaseDegrees(double previous, double current, double cycle) noexcept {
    return std::fmod(current - previous + cycle, cycle);
}

[[nodiscard]] bool crossedPhase(double previous, double current, double target, double cycle) noexcept {
    const auto travel = forwardPhaseDegrees(previous, current, cycle);
    if (travel <= 1.0e-9) return false;
    const auto distance = std::fmod(target - previous + cycle, cycle);
    return distance <= travel;
}

[[nodiscard]] bool phaseInsideWindow(double phase, double start, double end) noexcept {
    if (start < end) return phase >= start && phase <= end;
    return phase >= start || phase <= end;
}

[[nodiscard]] double fullLoadFuelLimitMg(
    const InjectionConfig& injection, double rpm) noexcept {
    const auto& curve = injection.fullLoadFuelLimit;
    if (curve.empty()) return std::numeric_limits<double>::infinity();
    if (curve.size() == 1 || rpm <= curve.front().rpm)
        return curve.front().milligramsPerCycle;
    for (std::size_t index = 1; index < curve.size(); ++index) {
        if (rpm <= curve[index].rpm) {
            const auto span = std::max(
                1.0, curve[index].rpm - curve[index - 1].rpm);
            const auto fraction = std::clamp(
                (rpm - curve[index - 1].rpm) / span, 0.0, 1.0);
            return std::lerp(
                curve[index - 1].milligramsPerCycle,
                curve[index].milligramsPerCycle, fraction);
        }
    }
    return curve.back().milligramsPerCycle;
}

/** The metering's sanity bounds were written in petrol AFR (5-30 for a
 *  command, 4-40 for an observation). Another fuel takes them at the same
 *  lambda: on methanol (6.47) a fixed AFR 4 is lambda 0.62, so the learner
 *  dropped the rich cycles and held the mixture at lambda 0.74 against a
 *  0.84 target. Exactly 1 on a 14.7 petrol; a diesel keeps its own. */
[[nodiscard]] double petrolAfrBoundScale(const EngineConfig& config) noexcept {
    const auto stoichiometric = config.fuelProperties.stoichiometricAirFuelRatio;
    return config.fuel == FuelType::diesel || !(stoichiometric > 0.0)
        ? 1.0 : stoichiometric / 14.7;
}

[[nodiscard]] double airFuelRatioForCell(const GasCell& cell, const FuelConfig& fuel) noexcept {
    const auto fuelMoles = cell.mixture().fuelMoles;
    if (fuelMoles <= 1.0e-15) return 100.0;
    // Residual nitrogen remains in the cylinder after combustion and cannot be
    // counted as fresh intake air.  Mixture strength is therefore derived from
    // the oxygen actually available to the fuel, then converted back to the
    // calibrated mass AFR for display and ECU feedback.
    const auto lambda = cell.mixture().oxygenMoles
        / std::max(1.0e-15, fuelMoles * fuel.oxygenMolesPerFuelMole);
    return std::clamp(lambda * fuel.stoichiometricAirFuelRatio, 0.0, 100.0);
}

/** A multi-valve pent-roof head's charge tumbles: the intake jet rolls it
 *  into a vortex across the bore whose angular speed is a fixed ratio of the
 *  crank's (the tumble ratio), and compression breaks it into the turbulence
 *  the flame burns in, so u' goes as the crank speed times the bore. The
 *  flame model's u' goes as the mean piston speed, crank speed times the
 *  stroke: this is the ratio between the two, 1 on a square engine. Without
 *  it a short-stroke engine burnt over more crank degrees the more
 *  oversquare it was (CA50 41 deg ATDC on a designed CBR1000RR-R; journal
 *  2026-11-02/03). A two-valve head has no tumble to speak of and keeps u'
 *  in piston speed; a two-stroke, a rotary and a diesel are not on this
 *  flame. */
[[nodiscard]] double tumbleTurbulenceScale(const EngineConfig& config,
                                           const CylinderConfig& cylinder) noexcept {
    if (config.cycle != EngineCycle::fourStroke || config.fuel == FuelType::diesel
        || cylinder.intakeValveCount < 2 || !(cylinder.strokeMm > 0.0))
        return 1.0;
    return std::clamp(cylinder.boreMm / cylinder.strokeMm, 0.5, 2.5);
}

[[nodiscard]] double stribeckFrictionForce(const CylinderConfig& cylinder,
                                            double pistonSpeedMps,
                                            double cylinderWallForceN) noexcept {
    const auto velocity = std::abs(pistonSpeedMps);
    const auto coulomb = cylinder.pistonFrictionCoefficient * std::abs(cylinderWallForceN);
    const auto stribeckVelocity = std::max(1.0e-6, cylinder.pistonBreakawayVelocityMps);
    const auto staticFriction = std::max(coulomb, cylinder.pistonBreakawayForceN);
    const auto stribeck = coulomb + (staticFriction - coulomb)
        * std::exp(-std::pow(velocity / stribeckVelocity, 2.0));
    return std::max(0.0, stribeck + cylinder.pistonViscousFrictionNsPerM * velocity);
}

struct ActiveCamshaft final {
    const CamshaftConfig* config {};
    bool highProfile { false };
    [[nodiscard]] double intakeDuration() const noexcept { return highProfile ? config->highIntakeDurationDegrees : config->intakeDurationDegrees; }
    [[nodiscard]] double exhaustDuration() const noexcept { return highProfile ? config->highExhaustDurationDegrees : config->exhaustDurationDegrees; }
    [[nodiscard]] double intakeLift() const noexcept { return highProfile ? config->highIntakeLiftMm : config->intakeLiftMm; }
    [[nodiscard]] double exhaustLift() const noexcept { return highProfile ? config->highExhaustLiftMm : config->exhaustLiftMm; }
    [[nodiscard]] const std::vector<ValveLiftSample>& intakeProfile() const noexcept {
        return highProfile && !config->highIntakeLiftProfile.empty() ? config->highIntakeLiftProfile : config->intakeLiftProfile;
    }
    [[nodiscard]] const std::vector<ValveLiftSample>& exhaustProfile() const noexcept {
        return highProfile && !config->highExhaustLiftProfile.empty() ? config->highExhaustLiftProfile : config->exhaustLiftProfile;
    }
};

[[nodiscard]] ActiveCamshaft activeCamshaft(
    const EngineConfig& config, const CylinderConfig& cylinder,
    double rpm, double throttle) noexcept {
    const CamshaftConfig* selected = &config.camshafts;
    const auto bank = std::find_if(
        config.banks.begin(), config.banks.end(),
        [&cylinder](const CylinderBankConfig& item) {
            return item.id == cylinder.bankId
                || std::find(item.cylinderIds.begin(),
                    item.cylinderIds.end(), cylinder.id)
                    != item.cylinderIds.end();
        });
    if (bank != config.banks.end()) selected = &bank->camshafts;
    const auto high = selected->variableProfileEnabled
        && rpm >= selected->switchRpm
        && throttle >= selected->switchThrottle;
    return { selected, high };
}

/** The ECU's VTEC strategy over one camshaft: its settings where its tables
 *  carry them, the camshaft's own switch where they do not. A minimum
 *  throttle past 99.9 % is the pedal floored: the plate follows the pedal
 *  exponentially and never reads exactly 1. */
[[nodiscard]] cam_controller::ValveProfileStrategy vtecStrategy(const CamshaftConfig& cam,
                                                                const EcuCommand& command) noexcept {
    constexpr double flooredThrottle = 0.999;
    const auto engage = command.vtecEngageRpm >= 0.0 ? command.vtecEngageRpm : cam.switchRpm;
    return { command.vtecEnabled, engage, engage - std::max(0.0, command.vtecHysteresisRpm),
             command.vtecMinimumThrottle >= 0.0 ? std::min(command.vtecMinimumThrottle, flooredThrottle)
                                                : cam.switchThrottle };
}

}

EngineSimulator::EngineSimulator(EngineConfig config, IEcuModel& ecu, IPhysicsModel& physics,
                                 IFiringEventGenerator& events, IExhaustModel& exhaust,
                                 EngineSimulatorOptions options)
    : config_(std::move(config)), options_(std::move(options)), ecu_(ecu), physics_(physics),
      eventGenerator_(events), exhaust_(exhaust) {
    normaliseEngineConfig(config_);
    if (const auto error = validateEngineConfig(config_)) throw std::invalid_argument(*error);
    eventGenerator_.configure(config_);
    setIntakeWallHeatUpdateIntervalSeconds(
        options_.intakeWallHeatUpdateIntervalSeconds.value_or(
            ductWallHeatUpdateIntervalSeconds));
    for (std::size_t index = 0; index < config_.cylinders.size(); ++index) {
        const auto& cylinder = config_.cylinders[index];
        intakePathIndexByCylinder_[index] =
            intakePathIndexFor(config_, cylinder);
        exhaustPathIndexByCylinder_[index] =
            exhaustPathIndexFor(config_, cylinder);
    }
    hasVariableValveProfiles_ = std::any_of(config_.cylinders.begin(), config_.cylinders.end(),
        [this](const CylinderConfig& cylinder) {
            return activeCamshaft(config_, cylinder, 0.0, 0.0).config->variableProfileEnabled;
        });
    ecu_.initialise(config_);
    kinematicsReference_ = buildEngineKinematicsReference(config_);
    configurePhysicalExhaustNetwork();
    configurePhysicalIntakeNetworks();
    configureIntakeWorkerPool();
    attachNetworkParallelFor();
    configureGasFieldSnapshot();
    reset();
}

void EngineSimulator::configureIntakeWorkerPool() {
    // Per-runner intakes dispatch only the 1-D runner advance, and only its
    // per-cylinder half. The 95 mm production mesh makes each item too short
    // to amortise one participant per cylinder: on the 12-thread reference
    // machine a same-hour, counterbalanced free-run sweep found two workers
    // best for the V8 and three for the V12. Four and five workers lost to
    // barrier/atomic traffic; an undispatched twin tracked machine drift as
    // the null control.
    //
    // A joint manifold owns one finite plenum in its RK stages, so whole
    // runners cannot be dispatched: that would split the shared reservoir
    // again. The pool serves it, and the exhaust, per duct inside each stage
    // instead (attachNetworkParallelFor), with bit-identical results.
    //
    // The work-cardinality cap below preserves those measured optima. The
    // hardware cap is still lower when necessary, and half the reported
    // concurrency remains reserved for the audio callback, UI and OS. Explicit
    // harness overrides deliberately bypass this production policy.
    //
    // A two-stroke takes one thread per cylinder, up to four: three quarters
    // of its time is the exhaust (an expansion chamber per cylinder at the
    // 100 mm mesh), whose pipes are advanced one per thread. One worker ran
    // the designed twin at 1.84 x real time against 1.53 without, and three
    // the designed V4 at 1.24-1.28 against 1.05-1.13 with two (journal
    // 2026-10-24). A four-stroke twin keeps none.
    const auto cylinderCount = config_.cylinders.size();
    if (options_.intakeStaircaseRounds.has_value())
        intakeStaircaseRounds_ = std::clamp<std::size_t>(
            *options_.intakeStaircaseRounds, 0, 4);
    const auto twoStrokeTwin = cylinderCount == 2 && config_.cycle == EngineCycle::twoStroke;
    if (cylinderCount < 2
        || (cylinderCount < 3 && !twoStrokeTwin && !options_.intakeWorkerCount.has_value()))
        return;
    std::size_t workerCount = 0;
    if (options_.intakeWorkerCount.has_value()) {
        workerCount = std::min(*options_.intakeWorkerCount, cylinderCount - 1);
    } else {
        const auto reportedConcurrency = platform::usableProcessorCount();
        if (reportedConcurrency < 4) return;
        const auto usableThreads = std::max<std::size_t>(1, reportedConcurrency / 2);
        const std::size_t workloadWorkerCap =
            cylinderCount >= 10 || config_.cycle == EngineCycle::twoStroke ? 3 : 2;
        workerCount = std::min(
            { cylinderCount - 1, usableThreads - 1, workloadWorkerCap });
    }
    if (workerCount == 0) return;
    intakeWorkerPool_ = std::make_unique<CylinderWorkerPool>(workerCount);
    // Only a group with more than one cylinder in it needs the plenum staircase
    // reconstructed. Without a pool the groups stay singletons and the runner
    // pass is the original serial Gauss-Seidel, exactly, at the original cost.
    if (!jointIntakeManifold()) intakePredictionGroupCount_ = 1;
}

void EngineSimulator::attachNetworkParallelFor() noexcept {
    // The exhaust network is advanced on the simulation thread between pool
    // dispatches, so it can borrow the same workers; see setParallelFor.
    gasdynamics::ExhaustGasNetwork::ParallelFor parallelFor;
    if (intakeWorkerPool_) {
        parallelFor.run = [](void* executor, std::size_t count,
                             gasdynamics::ExhaustGasNetwork::ParallelFor::Body body,
                             void* context) noexcept {
            static_cast<CylinderWorkerPool*>(executor)->runIndices(count, body, context);
        };
        parallelFor.executor = intakeWorkerPool_.get();
        parallelFor.threads = intakeWorkerPool_->workerCount() + 1;
    }
    if (physicalExhaustNetwork_) physicalExhaustNetwork_->setParallelFor(parallelFor);
    intakePathsConcurrent_ = false;
    if (!jointIntakeManifold()) return;
    // A multi-cylinder two-stroke's crankcases: one intake path a cylinder.
    // Each is flushed on its own worker, its ducts serially inside (V4 1.03
    // -> 1.27 x real time; journal 2026-11-21).
    if (intakeWorkerPool_ && intakePlenumCount_ >= 2
        && options_.parallelIntakePaths.value_or(true)) {
        std::array<std::size_t, 32> cylindersOnPath {};
        for (std::size_t index = 0; index < config_.cylinders.size(); ++index)
            ++cylindersOnPath[intakePathIndexByCylinder_[index]];
        intakePathsConcurrent_ = std::all_of(cylindersOnPath.begin(),
            cylindersOnPath.begin() + static_cast<std::ptrdiff_t>(intakePlenumCount_),
            [](std::size_t count) { return count == 1; });
    }
    if (intakePathsConcurrent_) parallelFor = {};
    for (auto& network : intakeManifoldNetworks_)
        if (network) network->setParallelFor(parallelFor);
}

void EngineSimulator::configurePhysicalIntakeNetworks() {
    intakePlenumCount_ = std::max<std::size_t>(1,
        std::min<std::size_t>(config_.intakePaths.size(), intakePlenumGas_.size()));
    if (jointIntakeManifold()) {
        for (std::size_t path = 0; path < intakePlenumCount_; ++path)
            intakeManifoldNetworks_[path] = buildIntakeManifoldNetwork(
                config_, path, intakeRunnerDuctIndex_, intakeRunnerPortIndex_);
    } else {
        for (std::size_t index = 0; index < config_.cylinders.size(); ++index)
            intakeRunnerNetworks_[index] = buildIntakeRunnerNetwork(config_, index);
    }
}

double EngineSimulator::individualThrottleManifoldPressureKpa(std::size_t pathIndex,
                                                               double subDt) noexcept {
    // Each runner taps the cell behind its plate, and the taps meet in a small
    // balance manifold: a first-order lag over the intake pulses.
    constexpr double tappingTimeConstantSeconds = 0.030;
    auto sumKpa = 0.0;
    auto runners = std::size_t { 0 };
    for (std::size_t index = 0; index < config_.cylinders.size(); ++index) {
        if (intakePathIndexByCylinder_[index] != pathIndex || !ownsIntakeRunner(index)) continue;
        const auto cells = intakeDuctForCylinder(index).cellPrimitives();
        if (cells.empty()) continue;
        auto ductKpa = 0.0;
        for (const auto& cell : cells) ductKpa += cell.pressurePa * 0.001;
        sumKpa += ductKpa / static_cast<double>(cells.size());
        ++runners;
    }
    auto& filteredKpa = individualThrottleMapKpa_[pathIndex];
    if (runners != 0)
        filteredKpa += (sumKpa / static_cast<double>(runners) - filteredKpa)
            * (1.0 - std::exp(-std::max(0.0, subDt) / tappingTimeConstantSeconds));
    return filteredKpa;
}

void EngineSimulator::setIndividualThrottleAreas(std::size_t pathIndex,
                                                 double openFraction,
                                                 double plateAreaM2) noexcept {
    auto runners = std::size_t { 0 };
    for (std::size_t index = 0; index < config_.cylinders.size(); ++index)
        if (intakePathIndexByCylinder_[index] == pathIndex && ownsIntakeRunner(index)) ++runners;
    if (runners == 0) return;
    // Each runner's plate opens its share of the bores. Wide open, a plate
    // whose bore spans its runner is the runner itself (the network's plain
    // face): an orifice there, even at the full face, lost 10-11 % of the
    // WOT torque by damping the ram wave (journal 2026-11-22).
    const auto fraction = std::clamp(openFraction, 0.0, 1.0);
    const auto borePerRunnerM2 = plateAreaM2 / static_cast<double>(runners);
    for (std::size_t index = 0; index < config_.cylinders.size(); ++index) {
        if (intakePathIndexByCylinder_[index] != pathIndex || !ownsIntakeRunner(index)) continue;
        // In a joint manifold the plates are numbered like the runners.
        auto& network = intakeNetworkForCylinder(index);
        const auto plate = jointIntakeManifold() ? intakeRunnerDuctIndex_[index] : 0;
        static_cast<void>(network.setRestrictionOpeningAreaM2(plate,
            fraction * std::min(borePerRunnerM2, network.restrictionFaceAreaM2(plate))));
    }
}

gasdynamics::ExhaustGasNetwork& EngineSimulator::intakeNetworkForCylinder(std::size_t index) noexcept {
    return jointIntakeManifold() ? *intakeManifoldNetworks_[intakePathIndexByCylinder_[index]]
        : *intakeRunnerNetworks_[index];
}

const gasdynamics::ExhaustGasNetwork& EngineSimulator::intakeNetworkForCylinder(std::size_t index) const noexcept {
    return jointIntakeManifold() ? *intakeManifoldNetworks_[intakePathIndexByCylinder_[index]]
        : *intakeRunnerNetworks_[index];
}

const gasdynamics::FiniteVolumeDuct& EngineSimulator::intakeDuctForCylinder(std::size_t index) const noexcept {
    return intakeNetworkForCylinder(index).ducts()[jointIntakeManifold() ? intakeRunnerDuctIndex_[index] : 0];
}

std::unique_ptr<gasdynamics::ExhaustGasNetwork> EngineSimulator::buildIntakeManifoldNetwork(
    const EngineConfig& config, std::size_t pathIndex,
    std::array<std::size_t, 32>& runnerDuctIndex,
    std::array<std::size_t, 32>& runnerPortIndex) const {
    std::vector<gasdynamics::CompiledExhaustDuct> ducts;
    std::vector<gasdynamics::CompiledExhaustDuct> bellmouthDucts;
    std::vector<gasdynamics::CompiledExhaustInterface> plates;
    std::vector<gasdynamics::CompiledCylinderPort> ports;
    std::vector<gasdynamics::CompiledExhaustOutlet> mouths;
    std::vector<gasdynamics::CompiledExhaustJunction> passages;
    std::vector<gasdynamics::CompiledExhaustInterface> passageFaces;
    gasdynamics::ExhaustGasNetworkConfig networkConfig;
    const auto rotary = config.cycle == EngineCycle::rotary;
    for (std::size_t index = 0; index < config.cylinders.size(); ++index) {
        if (intakePathIndexFor(config, config.cylinders[index]) != pathIndex) continue;
        if (rotary && index % 3 != 0) continue;
        const auto runner = buildIntakeRunnerNetwork(config, index);
        networkConfig = runner->config();
        auto port = runner->layout().cylinderPorts().front();
        auto mouth = runner->layout().outlets().front();
        runnerDuctIndex[index] = ducts.size();
        runnerPortIndex[index] = ports.size();
        port.networkEndpoint.elementIndex = ducts.size();
        mouth.networkEndpoint.elementIndex = ducts.size();
        ducts.push_back(runner->layout().ducts().front());
        if (!runner->layout().interfaces().empty()) {
            // The bellmouth sides follow every valve side; indices are
            // rebased below, once the valve-side count is known.
            auto plate = runner->layout().interfaces().front();
            plate.upstream.elementIndex = ducts.size() - 1;
            plate.downstream.elementIndex = bellmouthDucts.size();
            mouth.networkEndpoint.elementIndex = bellmouthDucts.size();
            plates.push_back(plate);
            bellmouthDucts.push_back(runner->layout().ducts().back());
        }
        if (rotary) {
            // The rotor's three faces open in turn onto one port in its
            // housing: a passage (a well-mixed junction two and a half
            // runner diameters long) between the faces and the runner.
            const auto runnerAreaM2 = port.runnerConnectionAreaM2;
            const auto diameterM = 2.0 * std::sqrt(runnerAreaM2 / std::numbers::pi);
            gasdynamics::CompiledExhaustJunction passage;
            passage.nodeId = config.cylinders[index].id + 2'000U;
            passage.sourceComponentId = config.cylinders[index].id;
            passage.pathIndex = port.pathIndex;
            passage.volumeM3 = runnerAreaM2 * 2.5 * diameterM;
            passage.characteristicDiameterM = diameterM;
            gasdynamics::CompiledExhaustInterface face;
            face.upstream = { gasdynamics::ExhaustEndpointType::junction, passages.size(), passage.nodeId };
            face.downstream = { gasdynamics::ExhaustEndpointType::ductInlet, ducts.size() - 1,
                ducts[ducts.size() - 1].nodeId };
            passageFaces.push_back(face);
            for (std::size_t faceIndex = index; faceIndex < index + 3; ++faceIndex) {
                auto facePort = port;
                facePort.cylinderId = config.cylinders[faceIndex].id;
                facePort.networkEndpoint = { gasdynamics::ExhaustEndpointType::junction, passages.size(),
                    passage.nodeId };
                runnerDuctIndex[faceIndex] = ducts.size() - 1;
                runnerPortIndex[faceIndex] = ports.size();
                ports.push_back(facePort);
            }
            passages.push_back(passage);
        } else {
            ports.push_back(port);
        }
        mouths.push_back(mouth);
    }
    if (ducts.empty()) return {};
    if (!bellmouthDucts.empty()) {
        const auto valveSides = ducts.size();
        for (auto& plate : plates) plate.downstream.elementIndex += valveSides;
        for (auto& mouth : mouths) mouth.networkEndpoint.elementIndex += valveSides;
        ducts.insert(ducts.end(), bellmouthDucts.begin(), bellmouthDucts.end());
    }
    // The passages' faces follow the plates, so a plate's index stays its
    // runner's.
    plates.insert(plates.end(), passageFaces.begin(), passageFaces.end());
    const auto layout = gasdynamics::ExhaustNetworkLayout::assemble(
        std::move(ducts), std::move(passages), std::move(plates), std::move(ports), std::move(mouths));
    auto network = std::make_unique<gasdynamics::ExhaustGasNetwork>(exhaustThermodynamicsFor(config));
    if (!network->configure(layout, networkConfig))
        throw std::runtime_error("failed to configure shared intake manifold");
    return network;
}

std::unique_ptr<gasdynamics::ExhaustGasNetwork> EngineSimulator::buildIntakeRunnerNetwork(
    const EngineConfig& config, std::size_t index) const {
    {
        const auto& cylinder = config.cylinders[index];
        const auto intakePathIndex = intakePathIndexByCylinder_[index];
        const auto& intake = intakeGeometryAt(config, intakePathIndex);
        const auto lengthM = (cylinder.intakeRunnerLengthMm > 0.0
            ? cylinder.intakeRunnerLengthMm : intake.runnerLengthMm) * 0.001;
        const auto inletDiameterM = (cylinder.intakeRunnerDiameterMm > 0.0
            ? cylinder.intakeRunnerDiameterMm : intake.runnerDiameterMm) * 0.001;
        const auto outletDiameterM = (intake.runnerPlenumDiameterMm > 0.0
            ? intake.runnerPlenumDiameterMm : inletDiameterM * 1'000.0) * 0.001;
        const auto areaAt = [](double diameterM) noexcept {
            return std::numbers::pi * diameterM * diameterM * 0.25;
        };
        const auto inletAreaM2 = areaAt(inletDiameterM);
        const auto outletAreaM2 = areaAt(outletDiameterM);
        const auto runnerLengthM = std::max(0.03, lengthM);
        // The realtime mesh targets 95 mm while retaining at least three
        // volumes: a quarter-wave fundamental (lambda ~= 4L) therefore has at
        // least twelve cells per wavelength under the unchanged MUSCL spatial
        // reconstruction. Explicit diagnostic overrides can refine to twelve
        // cells even on the short CP2 runners; they are not realtime defaults.
        const auto targetCellLengthM = std::clamp(
            options_.intakeTargetCellLengthM.value_or(0.095),
            0.010, 0.150);
        const auto makeDuct = [&](std::uint32_t nodeId, double ductLengthM,
                                  double ductInletAreaM2, double ductOutletAreaM2,
                                  std::size_t minimumCellCount) {
            const auto meanAreaM2 = (ductInletAreaM2
                + std::sqrt(ductInletAreaM2 * ductOutletAreaM2) + ductOutletAreaM2) / 3.0;
            gasdynamics::CompiledExhaustDuct duct;
            duct.nodeId = nodeId;
            duct.sourceComponentId = cylinder.id;
            duct.pathIndex = static_cast<std::uint32_t>(intakePathIndex);
            duct.lengthM = ductLengthM;
            duct.flowAreaM2 = meanAreaM2;
            duct.inletFlowAreaM2 = ductInletAreaM2;
            duct.outletFlowAreaM2 = ductOutletAreaM2;
            duct.connectionAreaM2 = meanAreaM2;
            duct.inletConnectionAreaM2 = ductInletAreaM2;
            duct.outletConnectionAreaM2 = ductOutletAreaM2;
            duct.hydraulicDiameterM = 2.0 * std::sqrt(meanAreaM2 / std::numbers::pi);
            duct.volumeM3 = meanAreaM2 * duct.lengthM;
            duct.cellCount = std::clamp<std::size_t>(
                static_cast<std::size_t>(std::llround(duct.lengthM / targetCellLengthM)),
                minimumCellCount, 12);
            if (options_.intakeMaximumCellCount.has_value())
                duct.cellCount = std::min(duct.cellCount, std::clamp<std::size_t>(
                    *options_.intakeMaximumCellCount, minimumCellCount, 12));
            return duct;
        };

        std::vector<gasdynamics::CompiledExhaustDuct> ducts;
        std::vector<gasdynamics::CompiledExhaustInterface> plates;
        if (intake.individualThrottles) {
            // Valve side first, so a runner's port index stays its duct index
            // in a joint manifold; the bellmouth side carries the mouth. Two
            // cells each keep three faces per side for the reconstruction and
            // an interior face for the mouth's transfer prediction.
            const auto plateFromValveM = std::clamp(intake.throttleDistanceFromValveMm > 0.0
                    ? intake.throttleDistanceFromValveMm * 0.001 : 0.55 * runnerLengthM,
                0.015, runnerLengthM - 0.015);
            const auto plateAreaM2 = areaAt(inletDiameterM
                + (outletDiameterM - inletDiameterM) * plateFromValveM / runnerLengthM);
            ducts.push_back(makeDuct(cylinder.id, plateFromValveM, inletAreaM2, plateAreaM2, 2));
            ducts.push_back(makeDuct(cylinder.id + 1'000U, runnerLengthM - plateFromValveM,
                plateAreaM2, outletAreaM2, 2));
            gasdynamics::CompiledExhaustInterface plate;
            plate.upstream = { gasdynamics::ExhaustEndpointType::ductOutlet, 0, cylinder.id };
            plate.downstream = {
                gasdynamics::ExhaustEndpointType::ductInlet, 1, cylinder.id + 1'000U };
            plate.restriction = true;
            plates.push_back(plate);
        } else {
            ducts.push_back(makeDuct(cylinder.id, runnerLengthM, inletAreaM2, outletAreaM2, 3));
        }

        gasdynamics::CompiledCylinderPort port;
        port.cylinderId = cylinder.id;
        port.pathIndex = ducts.front().pathIndex;
        port.networkEndpoint = {
            gasdynamics::ExhaustEndpointType::ductInlet, 0, cylinder.id };
        port.runnerConnectionAreaM2 = inletAreaM2;
        port.dischargeCoefficient = 1.0; // the valve Cd arrives per advance
        gasdynamics::CompiledExhaustOutlet mouth;
        mouth.outletNodeId = cylinder.id;
        mouth.pathIndex = ducts.front().pathIndex;
        mouth.networkEndpoint = { gasdynamics::ExhaustEndpointType::ductOutlet,
            ducts.size() - 1, ducts.back().nodeId };
        mouth.openingAreaM2 = outletAreaM2;
        mouth.dischargeCoefficient = 1.0; // a runner mouth is a bellmouth

        const auto layout = gasdynamics::ExhaustNetworkLayout::assemble(
            std::move(ducts), {}, std::move(plates), { port }, { mouth });
        if (!layout.valid())
            throw std::runtime_error("failed to assemble intake runner layout");
        auto network = std::make_unique<gasdynamics::ExhaustGasNetwork>(
            exhaustThermodynamicsFor(config));
        gasdynamics::ExhaustGasNetworkConfig networkConfig;
        networkConfig.initialPressurePa = config.ambientPressureKpa * 1'000.0;
        networkConfig.initialTemperatureK = config.ambientTemperatureC + 273.15;
        networkConfig.absoluteRoughnessM = 1.5e-6; // smooth aluminium/plastic
        networkConfig.maximumCourantNumber =
            options_.intakeMaximumCourantNumber.value_or(0.8);
        networkConfig.wallHeatTransferWPerM2K = 0.0;
        networkConfig.wallTemperatureK = config.ambientTemperatureC + 273.15;
        networkConfig.dynamicWallHeatTransferEnabled = true;
        networkConfig.wallThicknessM = aluminiumRunnerWallThicknessM;
        networkConfig.wallDensityKgPerM3 = aluminiumDensityKgPerM3;
        networkConfig.wallSpecificHeatJPerKgK = aluminiumSpecificHeatJPerKgK;
        networkConfig.externalWallHeatTransferWPerM2K =
            runnerExternalHeatTransferWPerM2K;
        networkConfig.externalTemperatureK = config.ambientTemperatureC + 273.15;
        // The runner networks are advanced concurrently, so the cadence is
        // driven from `advanceIntakeRunners` on the second half-step, where
        // every cylinder is dispatched together. A self-timed network would
        // burst on a different dispatch from its siblings and the barrier
        // would pay every burst.
        networkConfig.wallHeatUpdateExternallyTriggered = true;
        networkConfig.firstOrderTimeIntegration =
            options_.intakeUsesForwardEuler();
        networkConfig.characteristicValveBoundary =
            options_.intakeCharacteristicValve.value_or(true);
        if (!network->configure(layout, networkConfig))
            throw std::runtime_error("failed to configure intake runner network");
        return network;
    }
}

bool EngineSimulator::intakeReplaceable(const EngineConfig& running,
                                        const EngineConfig& edited) noexcept {
    if (running.cylinders.size() != edited.cylinders.size()
        || running.cylinders.size() > 32
        || running.intakePaths.size() != edited.intakePaths.size())
        return false;
    for (std::size_t index = 0; index < running.cylinders.size(); ++index)
        if (running.cylinders[index].id != edited.cylinders[index].id) return false;
    const auto sameParts = [](const IntakeConfig& was, const IntakeConfig& now) {
        return was.throttleCount == now.throttleCount
            && (was.airboxVolumeLitres > 0.0) == (now.airboxVolumeLitres > 0.0)
            && was.individualThrottles == now.individualThrottles;
    };
    if (!sameParts(running.intake, edited.intake)) return false;
    for (std::size_t index = 0; index < running.intakePaths.size(); ++index) {
        const auto& was = running.intakePaths[index];
        const auto& now = edited.intakePaths[index];
        if (was.id != now.id || was.cylinderIds != now.cylinderIds
            || was.inheritsGlobalGeometry != now.inheritsGlobalGeometry
            || !sameParts(was.geometry, now.geometry))
            return false;
    }
    return true;
}

std::unique_ptr<EngineSimulator::LiveIntake> EngineSimulator::buildLiveIntake(
    const EngineConfig& config) const {
    auto intake = std::make_unique<LiveIntake>();
    try {
        if (jointIntakeManifold()) {
            for (std::size_t path = 0; path < intakePlenumCount_; ++path)
                intake->manifolds[path] = buildIntakeManifoldNetwork(config, path, intake->runnerDuctIndex,
                    intake->runnerPortIndex);
        } else {
            for (std::size_t index = 0; index < config.cylinders.size() && index < intake->runners.size(); ++index)
                intake->runners[index] = buildIntakeRunnerNetwork(config, index);
        }
    } catch (const std::exception&) {
        return {};
    }
    return intake;
}

bool EngineSimulator::replaceIntake(LiveIntake& intake, EngineConfig& config) noexcept {
    if (!intakeReplaceable(config_, config)) return false;
    const auto count = config_.cylinders.size();
    auto& incomingNetworks = jointIntakeManifold() ? intake.manifolds : intake.runners;
    auto& runningNetworks = jointIntakeManifold() ? intakeManifoldNetworks_ : intakeRunnerNetworks_;
    const auto networkCount = jointIntakeManifold() ? intakePlenumCount_ : count;
    for (std::size_t index = 0; index < networkCount; ++index) {
        const auto& incoming = incomingNetworks[index];
        const auto& running = runningNetworks[index];
        if (!incoming && !running) continue;
        if (!incoming || !running || !incoming->layout().sameTopology(running->layout())) return false;
    }
    // Every network takes its state before any is swapped in: a refusal leaves
    // every running runner and the external finite plenum untouched.
    for (std::size_t index = 0; index < networkCount; ++index)
        if (incomingNetworks[index] && !incomingNetworks[index]->adoptStateFrom(*runningNetworks[index])) return false;
    for (std::size_t index = 0; index < networkCount; ++index)
        std::swap(incomingNetworks[index], runningNetworks[index]);
    if (jointIntakeManifold()) {
        std::swap(intake.runnerDuctIndex, intakeRunnerDuctIndex_);
        std::swap(intake.runnerPortIndex, intakeRunnerPortIndex_);
    }
    // The outgoing networks keep a pointer to the pool but are never advanced
    // again; the incoming ones are built without one.
    attachNetworkParallelFor();
    // Swapped, so this thread does not allocate; `config` leaves with the
    // previous intake.
    std::swap(config_.intake, config.intake);
    std::swap(config_.intakePaths, config.intakePaths);
    std::swap(config_.plenumVolumeLitres, config.plenumVolumeLitres);
    std::swap(config_.throttleDiameterMm, config.throttleDiameterMm);
    for (std::size_t index = 0; index < count; ++index) {
        std::swap(config_.cylinders[index].intakeRunnerLengthMm, config.cylinders[index].intakeRunnerLengthMm);
        std::swap(config_.cylinders[index].intakeRunnerDiameterMm, config.cylinders[index].intakeRunnerDiameterMm);
    }
    for (std::size_t pathIndex = 0; pathIndex < intakePlenumCount_; ++pathIndex) {
        const auto& geometry = intakeGeometryAt(config_, pathIndex);
        auto& plenum = intakePlenumGas_[pathIndex];
        plenum.resizeKeepingState(geometry.plenumVolumeLitres);
        const auto throttleRadius = geometry.throttleDiameterMm * 0.0005;
        plenum.setGeometry(std::numbers::pi * throttleRadius * throttleRadius,
                           plenum.orientationDx(), plenum.orientationDy());
    }
    return true;
}

std::unique_ptr<gasdynamics::PartitionedExhaustNetwork> EngineSimulator::buildPhysicalExhaustNetwork(
    const EngineConfig& config, double targetCellLengthM) const {
    const auto physicalGraph = ExhaustGraph::makeForEngine(config);
    auto feedbackMesh =
        gasdynamics::realtimeExhaustFeedbackDiscretisation();
    // The realtime FV mesh owns nonlinear mean-flow/back-pressure feedback,
    // not audio-band propagation. A 360 mm maximum cell length gives five
    // control volumes per 1.8 m wavelength (roughly 330-360 Hz in hot exhaust),
    // covering the resolved firing fundamentals of the shipped engines. The
    // characteristic audio network transports the remaining band without asking
    // every exhaust cell to run at more than 100 kHz. This is an explicit
    // physical scale separation: no
    // authored component, volume, area or loss is removed from either model.
    feedbackMesh.targetCellLengthM = std::clamp(targetCellLengthM, 0.025, 0.600);
    // Components shorter than the feedback scale remain one conservative
    // finite volume with their exact volume, ports and loss. Their propagation
    // delay is owned by the characteristic network, so duplicating a second FV
    // cell would add cost but no resolved mean-flow information.
    auto layout = gasdynamics::ExhaustNetworkLayout::compile(
        physicalGraph, feedbackMesh);
    // A turbocharger's turbine is a face of the network, at the collector:
    // what follows it (downpipe, mid pipe, silencer) is its cold side.
    if (config.forcedInduction.enabled
        && config.forcedInduction.type == ForcedInductionType::turbocharger)
        for (const auto& face : collectorTurbineFaces(layout))
            if (!layout.makeRestriction(face.interfaceIndex))
                throw std::runtime_error("failed to place the turbine");
    auto network = std::make_unique<gasdynamics::PartitionedExhaustNetwork>(
        exhaustThermodynamicsFor(config));
    gasdynamics::ExhaustGasNetworkConfig networkConfig;
    networkConfig.initialPressurePa = config.ambientPressureKpa * 1'000.0;
    networkConfig.initialTemperatureK = config.ambientTemperatureC + 273.15;
    networkConfig.absoluteRoughnessM = 4.5e-5;
    networkConfig.maximumCourantNumber =
        options_.exhaustMaximumCourantNumber.value_or(0.8);
    networkConfig.firstOrderTimeIntegration =
        options_.exhaustFirstOrderTimeIntegration.value_or(false);
    networkConfig.hancockPredictor = options_.exhaustHancockPredictor.value_or(false);
    // An expansion chamber is a chain of short cones: at the two-stroke mesh
    // most of them are two or three cells, which first-order ends left
    // entirely first order (RD350 at 8,000 rpm: 12.1 N.m, 21.9 reconstructed
    // across, as much as 25 mm cells gave without; journal 2026-10-16).
    networkConfig.reconstructAcrossInterfaces =
        options_.exhaustReconstructAcrossInterfaces.value_or(
            config.cycle == EngineCycle::twoStroke);
    networkConfig.characteristicValveBoundary =
        options_.exhaustCharacteristicValve.value_or(false);
    networkConfig.extrapolateOpenEnds = options_.exhaustExtrapolateOpenEnds.value_or(false);
    networkConfig.thirdOrderReconstruction =
        options_.exhaustThirdOrderReconstruction.value_or(false);
    // Exhaust-wall temperature is a finite-capacity state. Internal exchange
    // conserves gas plus metal energy; only the explicit outside convection
    // below rejects heat from that combined subsystem to the environment.
    networkConfig.wallHeatTransferWPerM2K = 0.0;
    networkConfig.wallTemperatureK = config.ambientTemperatureC + 273.15;
    networkConfig.dynamicWallHeatTransferEnabled = true;
    networkConfig.wallThicknessM = stainlessExhaustWallThicknessM;
    networkConfig.wallDensityKgPerM3 = stainlessDensityKgPerM3;
    networkConfig.wallSpecificHeatJPerKgK = stainlessSpecificHeatJPerKgK;
    networkConfig.externalWallHeatTransferWPerM2K =
        exhaustExternalHeatTransferWPerM2K;
    networkConfig.externalTemperatureK = config.ambientTemperatureC + 273.15;
    networkConfig.wallHeatUpdateIntervalSeconds =
        ductWallHeatUpdateIntervalSeconds;
    networkConfig.evolveJunctionAxialMomentum =
        options_.evolveExhaustJunctionAxialMomentum.value_or(true);
    // A two-stroke's pipes share nothing (one expansion chamber per cylinder,
    // each to its own outlet), and advanced as networks of their own they run
    // on separate threads with a CFL step each (journal 2026-10-24). A
    // four-stroke stays one network, so its numerics and sound are unchanged.
    const auto partition = options_.partitionExhaustNetwork.value_or(
        config.cycle == EngineCycle::twoStroke);
    if (!network->configure(layout, networkConfig, partition))
        throw std::runtime_error("failed to configure conservative exhaust network");
    return network;
}

double EngineSimulator::productionExhaustCellLengthM(const EngineConfig& config) noexcept {
    // A two-stroke's torque lives in its expansion chamber's waves: 360 mm
    // cells left the RD350 a quarter of its maker's torque. 100 mm is the
    // finest mesh measured in real time on the reference machine (1.22-1.26
    // free run with audio and the gas view, RK2, no duct worker pool on a
    // twin); 75 and 50 mm were not (journal 2026-10-15).
    constexpr double twoStrokeCellLengthM = 0.100;
    return config.cycle == EngineCycle::twoStroke
        ? twoStrokeCellLengthM
        : gasdynamics::realtimeExhaustFeedbackDiscretisation().targetCellLengthM;
}

void EngineSimulator::configurePhysicalExhaustNetwork() {
    constructionExhaustCellLengthM_ = options_.exhaustTargetCellLengthM.value_or(
        productionExhaustCellLengthM(config_));
    auto network = buildPhysicalExhaustNetwork(config_, constructionExhaustCellLengthM_);
    const auto& layout = network->layout();
    constructionExhaustLayout_ = layout;
    exhaustTurbineFaces_.clear();
    // Each path's face drives its turbocharger: the authored one, else the
    // path's index modulo the count. A face gets the share of its
    // turbocharger's turbine area that its cylinders are of that one's.
    const auto turbochargerCount = std::clamp<std::size_t>(
        config_.forcedInduction.turbochargerCount, 1, maximumTurbochargers);
    std::array<std::size_t, maximumTurbochargers> turbochargerCylinders {};
    for (const auto& face : collectorTurbineFaces(layout)) {
        if (!layout.interfaces()[face.interfaceIndex].restriction) continue;
        const auto authored = face.pathIndex < config_.exhaustPaths.size()
            ? config_.exhaustPaths[face.pathIndex].turbocharger : -1;
        const auto turbocharger = authored >= 0
            ? std::min<std::size_t>(static_cast<std::size_t>(authored), turbochargerCount - 1)
            : face.pathIndex % turbochargerCount;
        turbochargerCylinders[turbocharger] += face.cylinders;
        exhaustTurbineFaces_.push_back(ExhaustTurbineFace { face.interfaceIndex, face.cylinderShare,
            turbocharger, static_cast<double>(face.cylinders) });
    }
    {
        // The fuel balance's "before the turbine": every element from which
        // a turbine face can be reached.
        const auto& interfaces = layout.interfaces();
        std::vector<std::uint8_t> ducts(layout.ducts().size(), 0U);
        std::vector<std::uint8_t> junctions(layout.junctions().size(), 0U);
        const auto mark = [&](const gasdynamics::ExhaustEndpoint& endpoint) {
            auto& flags = endpoint.type == gasdynamics::ExhaustEndpointType::junction ? junctions : ducts;
            if (endpoint.elementIndex >= flags.size() || flags[endpoint.elementIndex] != 0U) return false;
            flags[endpoint.elementIndex] = 1U;
            return true;
        };
        for (const auto& face : exhaustTurbineFaces_)
            if (face.interfaceIndex < interfaces.size()) static_cast<void>(mark(interfaces[face.interfaceIndex].upstream));
        for (auto changed = true; changed;) {
            changed = false;
            for (const auto& connection : interfaces) {
                const auto& down = connection.downstream;
                const auto& flags = down.type == gasdynamics::ExhaustEndpointType::junction ? junctions : ducts;
                const auto marked = down.elementIndex < flags.size() && flags[down.elementIndex] != 0U;
                if (marked && mark(connection.upstream)) changed = true;
            }
        }
        network->markUpstreamOfTurbine(ducts, junctions);
    }
    for (auto& face : exhaustTurbineFaces_)
        face.turbochargerShare /= static_cast<double>(std::max<std::size_t>(1,
            turbochargerCylinders[face.turbocharger]));
    networkTurbinePowerW_.fill(0.0);
    networkTurbineOutletPressureKpa_ = config_.ambientPressureKpa;
    const auto ambientState = network->mixtureModel().conservativeFromPressureTemperature(
        config_.ambientPressureKpa * 1'000.0,
        config_.ambientTemperatureC + 273.15);
    if (!ambientState)
        throw std::runtime_error("failed to construct physical exhaust ambient state");
    physicalExhaustAmbientState_ = *ambientState;
    for (std::size_t portIndex = 0;
         portIndex < layout.cylinderPorts().size(); ++portIndex) {
        const auto cylinderId = layout.cylinderPorts()[portIndex].cylinderId;
        const auto cylinder = std::find_if(config_.cylinders.begin(), config_.cylinders.end(),
            [cylinderId](const CylinderConfig& candidate) {
                return candidate.id == cylinderId;
            });
        if (cylinder == config_.cylinders.end())
            throw std::runtime_error("exhaust network references an unknown cylinder");
        exhaustNetworkCylinderIndex_[portIndex] = static_cast<std::size_t>(
            std::distance(config_.cylinders.begin(), cylinder));
    }
    physicalExhaustNetwork_ = std::move(network);
}

std::unique_ptr<gasdynamics::PartitionedExhaustNetwork> EngineSimulator::buildLiveExhaustNetwork(
    const EngineConfig& config, std::optional<double> targetCellLengthM) const {
    std::unique_ptr<gasdynamics::PartitionedExhaustNetwork> network;
    try {
        network = buildPhysicalExhaustNetwork(
            config, targetCellLengthM.value_or(constructionExhaustCellLengthM_));
    } catch (const std::exception&) {
        return {};
    }
    if (!network->layout().sameTopology(constructionExhaustLayout_)) return {};
    return network;
}

bool EngineSimulator::beginCylinderResize(const EngineConfig& target, double rampSeconds) {
    if (!std::isfinite(rampSeconds) || rampSeconds < 0.0
        || target.cylinders.size() != config_.cylinders.size()
        || target.crankJournals.size() != config_.crankJournals.size())
        return false;
    for (std::size_t index = 0; index < config_.cylinders.size(); ++index) {
        const auto& running = config_.cylinders[index];
        const auto& wanted = target.cylinders[index];
        if (running.id != wanted.id || running.crankJournalId != wanted.crankJournalId) return false;
    }
    CylinderResize resize;
    resize.startSeconds = state_.simulationTimeSeconds;
    resize.rampSeconds = rampSeconds;
    for (std::size_t index = 0; index < config_.cylinders.size(); ++index) {
        const auto& running = config_.cylinders[index];
        const auto& wanted = target.cylinders[index];
        resize.from.push_back({ running.boreMm, running.strokeMm, running.deckHeightMm,
                                running.compressionRatio, running.connectingRodMm });
        resize.to.push_back({ wanted.boreMm, wanted.strokeMm, wanted.deckHeightMm,
                              wanted.compressionRatio, wanted.connectingRodMm });
        resize.pending.push_back(true);
    }
    cylinderResize_ = std::move(resize);
    return true;
}

void EngineSimulator::advanceCylinderResize() {
    if (!cylinderResize_) return;
    auto& resize = *cylinderResize_;
    // A stopped engine crosses no TDC: it takes the target at once.
    const auto stopped = std::abs(state_.rpm) < 1.0;
    const auto fraction = resize.rampSeconds > 0.0 && !stopped
        ? std::clamp((state_.simulationTimeSeconds - resize.startSeconds) / resize.rampSeconds, 0.0, 1.0)
        : 1.0;
    const auto at = [fraction](double from, double to) {
        return fraction >= 1.0 ? to : from + (to - from) * fraction;
    };
    auto changed = false;
    for (std::size_t index = 0; index < config_.cylinders.size(); ++index) {
        if (!resize.pending[index]) continue;
        const auto& cylinder = config_.cylinders[index];
        const auto cycle = cylinderCycleDegrees();
        const auto phase = std::fmod(state_.crankAngleDegrees - crankOffsetDegreesFor(config_, cylinder)
            + phaseWrapBiasDegrees(cycle), cycle);
        // Phase 0 is firing TDC: 360 is the overlap TDC, the chamber at its
        // clearance volume with both valves near their crossing. A two-stroke
        // resizes at bottom dead centre (180), its ports open.
        if (!stopped && !crossedPhase(previousCylinderPhases_[index], phase, cycle * 0.5, cycle)) continue;
        const auto journalId = cylinder.crankJournalId;
        for (std::size_t member = 0; member < config_.cylinders.size(); ++member) {
            auto& sized = config_.cylinders[member];
            if (sized.crankJournalId != journalId) continue;
            const auto& from = resize.from[member];
            const auto& to = resize.to[member];
            sized.boreMm = at(from.boreMm, to.boreMm);
            sized.strokeMm = at(from.strokeMm, to.strokeMm);
            sized.deckHeightMm = at(from.deckHeightMm, to.deckHeightMm);
            sized.compressionRatio = at(from.compressionRatio, to.compressionRatio);
            sized.connectingRodMm = at(from.connectingRodMm, to.connectingRodMm);
            if (fraction >= 1.0) resize.pending[member] = false;
        }
        for (auto& journal : config_.crankJournals)
            if (journal.id == journalId) journal.throwMm = cylinder.strokeMm * 0.5;
        changed = true;
    }
    if (!changed) return;
    kinematicsReference_ = buildEngineKinematicsReference(config_);
    ++cylinderGeometryRevision_;
    if (std::none_of(resize.pending.begin(), resize.pending.end(), [](bool pending) { return pending; }))
        cylinderResize_.reset();
}

namespace {

/** What a live camshaft change glides; the rest is swapped at once. */
constexpr std::array<double CamshaftConfig::*, 14> camshaftTimingFields {
    &CamshaftConfig::intakeDurationDegrees, &CamshaftConfig::exhaustDurationDegrees,
    &CamshaftConfig::intakeLiftMm, &CamshaftConfig::exhaustLiftMm,
    &CamshaftConfig::intakeCenterlineDegrees, &CamshaftConfig::exhaustCenterlineDegrees,
    &CamshaftConfig::intakeFlowCoefficient, &CamshaftConfig::exhaustFlowCoefficient,
    &CamshaftConfig::switchRpm, &CamshaftConfig::switchThrottle,
    &CamshaftConfig::highIntakeDurationDegrees, &CamshaftConfig::highExhaustDurationDegrees,
    &CamshaftConfig::highIntakeLiftMm, &CamshaftConfig::highExhaustLiftMm,
};

[[nodiscard]] CamshaftConfig& camshaftAt(EngineConfig& config, std::size_t index) noexcept {
    return index == 0 ? config.camshafts : config.banks[index - 1].camshafts;
}

[[nodiscard]] const CamshaftConfig& camshaftAt(const EngineConfig& config, std::size_t index) noexcept {
    return index == 0 ? config.camshafts : config.banks[index - 1].camshafts;
}

} // namespace

bool EngineSimulator::camshaftsReplaceable(const EngineConfig& running,
                                           const EngineConfig& edited) noexcept {
    if (running.banks.size() != edited.banks.size()) return false;
    for (std::size_t index = 0; index < running.banks.size(); ++index)
        if (running.banks[index].id != edited.banks[index].id
            || running.banks[index].cylinderIds != edited.banks[index].cylinderIds)
            return false;
    for (std::size_t index = 0; index <= running.banks.size(); ++index) {
        const auto& was = camshaftAt(running, index);
        const auto& now = camshaftAt(edited, index);
        // VTEC cams fit and come off live: fitted, they start on the low cam;
        // off, a high cam still running drops back on its next base circle.
        if (was.continuousControl.enabled != now.continuousControl.enabled)
            return false;
    }
    return true;
}

bool EngineSimulator::beginCamshaftChange(EngineConfig& target, double rampSeconds) {
    if (!std::isfinite(rampSeconds) || rampSeconds < 0.0 || !camshaftsReplaceable(config_, target))
        return false;
    CamshaftChange change;
    change.startSeconds = state_.simulationTimeSeconds;
    change.rampSeconds = rampSeconds;
    std::vector<char> switchedBefore(config_.cylinders.size());
    for (std::size_t index = 0; index < config_.cylinders.size(); ++index)
        switchedBefore[index] = camshaftOfCylinder(config_, config_.cylinders[index]).variableProfileEnabled;
    for (std::size_t index = 0; index <= config_.banks.size(); ++index) {
        auto& running = camshaftAt(config_, index);
        auto& wanted = camshaftAt(target, index);
        CamshaftTiming from;
        CamshaftTiming to;
        for (std::size_t field = 0; field < camshaftTimingFields.size(); ++field) {
            from.values[field] = running.*camshaftTimingFields[field];
            to.values[field] = wanted.*camshaftTimingFields[field];
        }
        change.from.push_back(from);
        change.to.push_back(to);
        std::swap(running.intakeLiftProfile, wanted.intakeLiftProfile);
        std::swap(running.exhaustLiftProfile, wanted.exhaustLiftProfile);
        std::swap(running.highIntakeLiftProfile, wanted.highIntakeLiftProfile);
        std::swap(running.highExhaustLiftProfile, wanted.highExhaustLiftProfile);
        std::swap(running.intakeFlowCurve, wanted.intakeFlowCurve);
        std::swap(running.exhaustFlowCurve, wanted.exhaustFlowCurve);
        std::swap(running.continuousControl, wanted.continuousControl);
        running.exhaustPortHeadAreaFraction = wanted.exhaustPortHeadAreaFraction;
        running.variableProfileEnabled = wanted.variableProfileEnabled;
        // The shaft-cycle clock the high cam engages on runs from here.
        hasVariableValveProfiles_ = hasVariableValveProfiles_ || running.variableProfileEnabled;
    }
    // VTEC cams fitted here engage on a whole cycle that ends after the fit,
    // never on one the engine ran before it.
    for (std::size_t index = 0; index < config_.cylinders.size() && index < valveProfileActuators_.size(); ++index)
        if (!switchedBefore[index] && camshaftOfCylinder(config_, config_.cylinders[index]).variableProfileEnabled)
            valveProfileActuators_[index].awaitCycleAfter(valveProfileShaftCycle_.completed());
    camshaftChange_ = std::move(change);
    advanceCamshaftChange();
    return true;
}

void EngineSimulator::applyRegulatedTemperatures() noexcept {
    if (!config_.thermal.regulated) return;
    state_.coolantTemperatureC = config_.thermal.regulatedCoolantTemperatureC;
    state_.oilTemperatureC = config_.thermal.regulatedOilTemperatureC;
}

void EngineSimulator::advanceCamshaftChange() {
    if (!camshaftChange_) return;
    const auto& change = *camshaftChange_;
    const auto stopped = std::abs(state_.rpm) < 1.0;
    const auto fraction = change.rampSeconds > 0.0 && !stopped
        ? std::clamp((state_.simulationTimeSeconds - change.startSeconds) / change.rampSeconds, 0.0, 1.0)
        : 1.0;
    for (std::size_t index = 0; index < change.from.size(); ++index) {
        auto& camshaft = camshaftAt(config_, index);
        for (std::size_t field = 0; field < camshaftTimingFields.size(); ++field) {
            const auto from = change.from[index].values[field];
            const auto to = change.to[index].values[field];
            camshaft.*camshaftTimingFields[field] = fraction >= 1.0 ? to : from + (to - from) * fraction;
        }
    }
    if (fraction >= 1.0) camshaftChange_.reset();
}

bool EngineSimulator::replaceExhaustNetwork(
    std::unique_ptr<gasdynamics::PartitionedExhaustNetwork>& network,
    const EngineConfig& config) {
    // The turbine faces are shared out between turbochargers when the network
    // is built: another sharing takes a restart.
    auto sameTurbochargers = true;
    for (std::size_t index = 0; index < std::min(config.exhaustPaths.size(), config_.exhaustPaths.size()); ++index)
        sameTurbochargers = sameTurbochargers
            && config.exhaustPaths[index].turbocharger == config_.exhaustPaths[index].turbocharger;
    if (!network || !physicalExhaustNetwork_ || !sameTurbochargers
        || !network->layout().sameTopology(constructionExhaustLayout_)
        || !network->adoptStateFrom(*physicalExhaustNetwork_))
        return false;
    std::swap(network, physicalExhaustNetwork_);
    attachNetworkParallelFor();
    // Only the network reads the exhaust geometry; the copy keeps config_
    // describing the engine that runs.
    config_.exhaust = config.exhaust;
    config_.exhaustPaths = config.exhaustPaths;
    config_.exhaustValve = config.exhaustValve;
    return true;
}

bool EngineSimulator::settingsReplaceable(const EngineConfig& running,
                                          const EngineConfig& edited) noexcept {
    const auto& was = running.forcedInduction;
    const auto& now = edited.forcedInduction;
    if (running.crankshafts.size() != edited.crankshafts.size()) return false;
    for (std::size_t index = 0; index < running.crankshafts.size(); ++index) {
        const auto& before = running.crankshafts[index];
        const auto& after = edited.crankshafts[index];
        if (before.id != after.id || before.rotationRatio != after.rotationRatio
            || before.phaseOffsetDegrees != after.phaseOffsetDegrees
            || before.positionXMm != after.positionXMm || before.positionYMm != after.positionYMm)
            return false;
    }
    return running.injection.mode == edited.injection.mode
        && running.transmission.gearRatios.size() == edited.transmission.gearRatios.size()
        && was.enabled == now.enabled && was.type == now.type
        && was.compressorBladeCount == now.compressorBladeCount
        && was.turbineBladeCount == now.turbineBladeCount
        && was.superchargerLobeCount == now.superchargerLobeCount
        // The turbine faces are shared out when the exhaust network is built.
        && was.turbochargerCount == now.turbochargerCount
        && running.cycle == edited.cycle;
}

bool EngineSimulator::replaceSettings(EngineConfig& config) noexcept {
    if (!settingsReplaceable(config_, config)) return false;
    // The exhaust outlet's reservoir is the one ambient state kept between
    // steps; everything else reads the ambient at every step.
    if (physicalExhaustNetwork_
        && (config.ambientPressureKpa != config_.ambientPressureKpa
            || config.ambientTemperatureC != config_.ambientTemperatureC)) {
        const auto ambientState = physicalExhaustNetwork_->mixtureModel().conservativeFromPressureTemperature(
            config.ambientPressureKpa * 1'000.0, config.ambientTemperatureC + 273.15);
        if (!ambientState) return false;
        physicalExhaustAmbientState_ = *ambientState;
    }
    config_.ambientPressureKpa = config.ambientPressureKpa;
    config_.ambientTemperatureC = config.ambientTemperatureC;
    std::swap(config_.injection, config.injection);
    std::swap(config_.forcedInduction, config.forcedInduction);
    std::swap(config_.ignition, config.ignition);
    std::swap(config_.exhaustAfterfire, config.exhaustAfterfire);
    std::swap(config_.engineBrake, config.engineBrake);
    std::swap(config_.exhaustValve, config.exhaustValve);
    {
        // A kit just fitted comes with a full bottle; a smaller bottle holds
        // no more than it can.
        const auto wasFitted = config_.nitrous.fitted;
        std::swap(config_.nitrous, config.nitrous);
        if (config_.nitrous.fitted && !wasFitted) fillNitrousBottle();
        nitrousBottleMassKg_ = std::min(nitrousBottleMassKg_, config_.nitrous.bottleCapacityKg);
    }
    // The driveline (EngineRuntime) runs on these; the copy keeps config()
    // describing the engine that runs.
    std::swap(config_.transmission, config.transmission);
    std::swap(config_.vehicle, config.vehicle);
    // A regulated engine is at its set temperatures at once; one let free
    // starts from where it is.
    config_.thermal = config.thermal;
    applyRegulatedTemperatures();
    // Field by field: the kinematics read the crankshafts' layout, which
    // stays. effectiveRotatingInertiaKgM2() reads these at every step.
    for (std::size_t index = 0; index < config_.crankshafts.size(); ++index) {
        auto& crankshaft = config_.crankshafts[index];
        const auto& source = config.crankshafts[index];
        crankshaft.momentOfInertiaKgM2 = source.momentOfInertiaKgM2;
        crankshaft.frictionTorqueNm = source.frictionTorqueNm;
        crankshaft.massKg = source.massKg;
        crankshaft.flywheelMassKg = source.flywheelMassKg;
    }
    config_.rotatingInertiaKgM2 = config.rotatingInertiaKgM2;
    // The knock model reads the octane at every step.
    config_.octaneRating = config.octaneRating;
    return true;
}

void EngineSimulator::setPressureSamplingEnabled(bool enabled) {
    if (enabled && !pressureSamples_) {
        pressureSamples_ = std::make_unique<SpscQueue<CylinderPressureSample, 1'024>>();
        exhaustAcousticSamples_ =
            std::make_unique<SpscQueue<ExhaustAcousticSample, 1'024>>();
    } else if (!enabled) {
        pressureSamples_.reset();
        exhaustAcousticSamples_.reset();
    }
}

void EngineSimulator::applyAudioPhysicsCalibration(
    const AudioPhysicsCalibration& calibration) noexcept {
    config_.combustionCalibration.cycleVariationCoefficientOfVariation =
        calibration.cycleVariationCoefficientOfVariation;
    config_.combustionCalibration.cycleVariationCorrelation =
        calibration.cycleVariationCorrelation;
    config_.ignition.limiterKeepsFuel = calibration.limiterKeepsFuel;
    config_.exhaustAfterfire = calibration.exhaustAfterfire;
}

void EngineSimulator::updateExhaustValve(double dtSeconds,
                                         const EngineControls& controls) noexcept {
    // One actuator drives every active valve of the exhaust. Automatic opens
    // them at a speed or a throttle and shuts them 250 rpm and 5 % under
    // both, so a speed sitting on the threshold does not chatter them. The
    // butterfly turns at a constant rate (a full stroke in travelSeconds);
    // its open share of the face is 1 - cos of its angle.
    const auto valves = physicalExhaustNetwork_
        ? physicalExhaustNetwork_->exhaustValveCount() : std::size_t { 0 };
    state_.exhaustValveCount = static_cast<std::uint32_t>(valves);
    if (valves == 0) {
        state_.exhaustValveStroke = 1.0;
        state_.exhaustValveOpening = 1.0;
        exhaustValveStarted_ = false;
        return;
    }
    const auto& valve = config_.exhaustValve;
    auto open = false;
    switch (controls.exhaustValveMode) {
    case ExhaustValveMode::closed: open = false; break;
    case ExhaustValveMode::open: open = true; break;
    case ExhaustValveMode::automatic: {
        const auto throttleThreshold = std::min(valve.openAboveThrottle, 0.999);
        const auto rpmMargin = exhaustValveAutoOpen_ ? 250.0 : 0.0;
        const auto throttleMargin = exhaustValveAutoOpen_ ? 0.05 : 0.0;
        open = state_.rpm >= valve.openAboveRpm - rpmMargin
            || controls.throttle >= throttleThreshold - throttleMargin;
        break;
    }
    }
    exhaustValveAutoOpen_ = open;
    const auto target = open ? 1.0 : 0.0;
    auto stroke = state_.exhaustValveStroke;
    if (!exhaustValveStarted_ || !(valve.travelSeconds > 0.0)) {
        stroke = target;
        exhaustValveStarted_ = true;
    } else {
        const auto travel = dtSeconds / valve.travelSeconds;
        stroke = target > stroke ? std::min(target, stroke + travel)
                                 : std::max(target, stroke - travel);
    }
    state_.exhaustValveStroke = stroke;
    state_.exhaustValveOpening = stroke >= 1.0 ? 1.0
        : 1.0 - std::cos(0.5 * std::numbers::pi * stroke);
}

namespace {
/** Nitrous oxide's molar mass, kg/mol, and its critical temperature, K. */
constexpr double nitrousMolarMassKg = 0.0440128;
constexpr double nitrousCriticalTemperatureK = 309.57;
/** Saturated vapour pressure, kPa: ln p = A - B / T through 31.3 bar at 0 C
 *  and 63.2 bar at 30 C (50.8 at 20 C), the bottle's pressure while it holds
 *  liquid. Past the critical point the same law goes on. */
[[nodiscard]] double nitrousVapourPressureKpa(double temperatureK) noexcept {
    return 100.0 * std::exp(10.552 - 1'942.0 / std::max(150.0, temperatureK));
}
/** Latent heat of evaporation, J/kg: 376 kJ/kg at the 184.7 K boiling point,
 *  Watson's (Tc - T)^0.38 above it, zero at the critical point (123 kJ/kg at
 *  30 C, 175 at 20 C). */
[[nodiscard]] double nitrousLatentHeatJPerKg(double temperatureK) noexcept {
    const auto reduced = std::clamp((nitrousCriticalTemperatureK - temperatureK)
        / (nitrousCriticalTemperatureK - 184.67), 0.0, 2.0);
    return 376'000.0 * std::pow(reduced, 0.38);
}
/** Saturated liquid and vapour densities, kg/m3, within about 10 %: the
 *  liquid 905 at 0 C, 786 at 20 C, closing on the vapour, which an ideal gas
 *  at compressibility 0.7 gives, at the critical point. */
[[nodiscard]] double nitrousVapourShareOfDrawnLiquid(double temperatureK) noexcept {
    const auto vapour = nitrousVapourPressureKpa(temperatureK) * 1'000.0 * nitrousMolarMassKg
        / (0.7 * GasCell::universalGasConstant * std::max(150.0, temperatureK));
    const auto liquid = std::max(vapour * 1.05, 905.0 - 6.0 * (temperatureK - 273.15));
    return vapour / (liquid - vapour);
}
/** The decomposition N2O -> N2 + 1/2 O2 releases its enthalpy of formation,
 *  82.05 kJ/mol: per mole of the oxygen it carries, twice that. */
constexpr double nitrousDecompositionJPerOxygenMole = 2.0 * 82'050.0;
} // namespace

void EngineSimulator::fillNitrousBottle() noexcept {
    const auto& kit = config_.nitrous;
    nitrousBottleMassKg_ = kit.bottleCapacityKg;
    nitrousBottleTemperatureK_ = (kit.bottleHeater ? kit.bottleTemperatureC : config_.ambientTemperatureC) + 273.15;
}

void EngineSimulator::updateNitrous(double dtSeconds, const EngineControls& controls) noexcept {
    const auto& kit = config_.nitrous;
    if (!kit.fitted) {
        nitrousSprayFraction_ = 0.0;
        nitrousMassFlowKgPerSecond_ = 0.0;
        nitrousOxygenRateMolPerSecond_ = 0.0;
        throttleOxygenRateMolPerSecond_ = 0.0;
        nitrousOxygenShare_ = 0.0;
        state_.nitrousSpraying = false;
        state_.nitrousMassFlowKgPerSecond = 0.0;
        state_.nitrousBottleMassKg = 0.0;
        state_.nitrousBottlePressureKpa = 0.0;
        state_.nitrousBottleTemperatureC = 0.0;
        state_.nitrousOxygenShare = 0.0;
        state_.nitrousBlockers = 0U;
        nitrousRefillsSeen_ = controls.nitrousRefills;
        return;
    }
    if (controls.nitrousRefills != nitrousRefillsSeen_) {
        nitrousRefillsSeen_ = controls.nitrousRefills;
        fillNitrousBottle();
    }
    const auto restingK = (kit.bottleHeater ? kit.bottleTemperatureC : config_.ambientTemperatureC) + 273.15;
    if (kit.unlimitedBottle) {
        nitrousBottleMassKg_ = kit.bottleCapacityKg;
        nitrousBottleTemperatureK_ = restingK;
    }
    nitrousBottleMassKg_ = std::clamp(nitrousBottleMassKg_, 0.0, kit.bottleCapacityKg);
    const auto bottlePressureKpa = nitrousVapourPressureKpa(nitrousBottleTemperatureK_);
    const auto maximumRpm = kit.maximumRpm > 0.0 ? kit.maximumRpm : std::numeric_limits<double>::infinity();
    const auto bit = [](NitrousBlocker blocker) { return static_cast<std::uint32_t>(blocker); };
    const auto blockers = (controls.nitrousArmed ? 0U : bit(NitrousBlocker::notArmed))
        | (controls.nitrousButton || !kit.pushButton ? 0U : bit(NitrousBlocker::pushButton))
        | (controls.ignitionEnabled ? 0U : bit(NitrousBlocker::ignitionOff))
        | (controls.throttle >= std::min(kit.minimumThrottle, 0.999) ? 0U : bit(NitrousBlocker::throttle))
        | (state_.rpm >= kit.minimumRpm ? 0U : bit(NitrousBlocker::belowMinimumRpm))
        | (state_.rpm <= maximumRpm ? 0U : bit(NitrousBlocker::aboveMaximumRpm))
        | (nitrousBottleMassKg_ > 0.0 ? 0U : bit(NitrousBlocker::bottleEmpty));
    state_.nitrousBlockers = blockers;
    const auto requested = blockers == 0U;
    nitrousSprayFraction_ = !requested ? 0.0
        : kit.rampSeconds > 0.0 ? std::min(1.0, nitrousSprayFraction_ + dtSeconds / kit.rampSeconds)
        : 1.0;
    // A liquid jet: the flow follows the square root of the pressure across
    // it, rated at 900 psi into an atmospheric manifold.
    const auto dropKpa = std::max(0.0, bottlePressureKpa - state_.manifoldPressureKpa);
    auto flow = nitrousSprayFraction_ * kit.shotKw * nitrousMassFlowPerShotKw
        * std::sqrt(dropKpa / (nitrousReferenceBottlePressureKpa - 101.325));
    if (!kit.unlimitedBottle && dtSeconds > 0.0) flow = std::min(flow, nitrousBottleMassKg_ / dtSeconds);
    nitrousMassFlowKgPerSecond_ = flow;
    if (!kit.unlimitedBottle) {
        // Each kilogram of liquid drawn leaves room the liquid refills by
        // boiling: its latent heat comes out of the liquid and the shell
        // (taken as 1.5 kg of aluminium per kg of capacity). A heater
        // brings back 200 W; without one the air brings 1.5 W/K.
        const auto drawnKg = flow * dtSeconds;
        nitrousBottleMassKg_ = std::max(0.0, nitrousBottleMassKg_ - drawnKg);
        const auto heatCapacity = nitrousBottleMassKg_ * 2'000.0 + 1.5 * kit.bottleCapacityKg * 900.0;
        auto heatW = -drawnKg / std::max(dtSeconds, 1.0e-9)
            * nitrousVapourShareOfDrawnLiquid(nitrousBottleTemperatureK_)
            * nitrousLatentHeatJPerKg(nitrousBottleTemperatureK_);
        heatW += kit.bottleHeater ? (nitrousBottleTemperatureK_ < restingK ? 200.0 : 0.0)
            : 1.5 * (restingK - nitrousBottleTemperatureK_);
        if (heatCapacity > 0.0) {
            const auto next = nitrousBottleTemperatureK_ + heatW * dtSeconds / heatCapacity;
            // The heater's thermostat stops at its set point.
            nitrousBottleTemperatureK_ = kit.bottleHeater && heatW > 0.0 ? std::min(next, restingK) : next;
        }
    }
    state_.nitrousSpraying = flow > 0.0;
    state_.nitrousMassFlowKgPerSecond = flow;
    state_.nitrousBottleMassKg = nitrousBottleMassKg_;
    state_.nitrousBottlePressureKpa = nitrousVapourPressureKpa(nitrousBottleTemperatureK_);
    state_.nitrousBottleTemperatureC = nitrousBottleTemperatureK_ - 273.15;
}

double EngineSimulator::releaseNitrousDecomposition(GasCell& cell, double burnedFuelMoles) const noexcept {
    if (!(nitrousOxygenShare_ > 0.0) || !(burnedFuelMoles > 0.0)) return 0.0;
    const auto joules = burnedFuelMoles * config_.fuelProperties.oxygenMolesPerFuelMole
        * nitrousOxygenShare_ * nitrousDecompositionJPerOxygenMole;
    cell.addHeatJoules(joules);
    return joules;
}

SimulationFrame EngineSimulator::step(double dtSeconds, const EngineControls& controls) noexcept {
    const auto dt = std::isfinite(dtSeconds) ? std::clamp(dtSeconds, 0.0, 0.05) : 0.0;
    if (dt <= 0.0) {
        return { state_ };
    }
    auto safeControls = controls;
    ecu_.beginFrame();
    safeControls.throttle = std::isfinite(controls.throttle) ? std::clamp(controls.throttle, 0.0, 1.0) : 0.0;
    safeControls.load = std::isfinite(controls.load) ? std::clamp(controls.load, 0.0, 1.0) : 0.0;
    safeControls.externalTorqueNm = std::isfinite(controls.externalTorqueNm)
        ? std::clamp(controls.externalTorqueNm, -5.0e6, 5.0e6) : 0.0;
    safeControls.externalRotatingInertiaKgM2 =
        std::isfinite(controls.externalRotatingInertiaKgM2)
        ? std::clamp(controls.externalRotatingInertiaKgM2, 0.0, 1.0e6)
        : 0.0;
    safeControls.dynamometerTorqueNm = std::isfinite(controls.dynamometerTorqueNm)
        ? std::clamp(controls.dynamometerTorqueNm, 0.0, 1.0e7) : 0.0;
    // The ECU reads the gear and the road speed from the state it is given.
    state_.gear = controls.engagedGear;
    state_.vehicleSpeedMps = std::isfinite(controls.vehicleSpeedMps) ? std::abs(controls.vehicleSpeedMps) : 0.0;
    updateExhaustValve(dt, safeControls);
    updateNitrous(dt, safeControls);
    // Gas pressure and crank loading need much finer resolution than UI/runtime
    // updates. Resolution increases with crank speed and remains bounded by the
    // engine definition so slow machines fail observably instead of diverging.
    // Re-evaluate the shared mechanical/gas duration after every integrated
    // crank step. A caller frame is not a constant-speed interval: its firing
    // pulse can accelerate the crank beyond a grid sized from frame-entry RPM.
    // The previous net torque predicts the next short interval; retain the
    // existing angular headroom for changes of torque within that interval.
    const auto guardedCrankDegrees = std::max(0.1,
        config_.solver.maximumCrankDegreesPerStep * 0.94);
    // gasSubsteps raises the minimum integration cadence; it must not multiply
    // the speed-dependent demand and then hide an under-resolved crank step
    // behind the configured frequency cap.
    const auto minimumGasFrequency = config_.solver.mechanicalFrequencyHz
        * static_cast<double>(config_.solver.gasSubsteps);
    const auto maximumSubStepCount = std::max(std::size_t { 1 },
        static_cast<std::size_t>(std::ceil(dt
            * config_.solver.maximumMechanicalFrequencyHz)));
    const auto integrationInertiaKgM2 = effectiveRotatingInertiaKgM2(config_)
        + safeControls.externalRotatingInertiaKgM2;
    const auto stepDisplacementLitres = engineDisplacementLitres(config_);
    const auto starterPeakTorqueNm = 45.0 + stepDisplacementLitres * 52.0
        + stepDisplacementLitres
            / static_cast<double>(std::max<std::size_t>(1, config_.cylinders.size()))
            * 350.0;
    auto remainingStepSeconds = dt;
    std::size_t integratedSubStepCount = 0;
    state_.solverResolutionLimited = false;
    state_.solverSubsteps = 0;
    double maximumIntegratedCrankStep = 0.0;
    SimulationFrame frame;
    // End-of-substep geometry is the next substep's entry geometry. Reuse
    // only an exact operand match; caller-frame and live-geometry boundaries
    // cannot carry this local cache into a different mechanical state.
    std::array<CylinderKinematics, 32> cachedKinematics {};
    std::optional<std::array<std::uint64_t, 4>> cachedKinematicsKey;

    // Couple the low-band nonlinear network at no fewer than sixteen samples per
    // four-stroke firing period. This is a physical multirate integration rate,
    // not a frame skip: valve CdA is integrated over every mechanical substep,
    // while the instantaneous Riemann boundary remains sampled at that faster
    // cadence for audio. The absolute cap also resolves cranking transients where
    // firing frequency alone approaches zero.
    //
    // The cap sets the audio bandwidth of the exhaust boundary wherever the
    // per-firing-period rule is slower than it -- i.e. at idle and low rpm,
    // and across the whole range of low-cylinder-count engines. At 500 us the
    // published coupling Nyquist was ~1 kHz there, which listeners reported as
    // a muffled, undifferentiated exhaust: every engine's blowdown edge was
    // smeared by the same reconstruction cutoff. The former 250 us production
    // cap doubled that headroom to ~2 kHz; the measured 125 us cap used here
    // doubles it again to at least 4 kHz.
    // The extra cost is per-flush overhead only (the network's internal CFL
    // substep count per second is unchanged), and the low-speed regime where
    // this cap binds is far below the redline load case that sets the budget.
    // Measured before committing: see docs/thermoacoustic-architecture.md.
    const auto maximumLowSpeedCouplingSeconds = std::clamp(
        options_.maximumLowSpeedExhaustCouplingSeconds.value_or(125.0e-6),
        25.0e-6, 500.0e-6);
    constexpr auto couplingSamplesPerFiringPeriod = 16.0;
    const auto firingFrequencyHz = std::abs(state_.rpm)
        * static_cast<double>(config_.cylinders.size()) / (cylinderCycleDegrees() / 6.0);
    const auto productionExhaustCouplingSeconds = firingFrequencyHz > 1.0e-9
        ? std::min(maximumLowSpeedCouplingSeconds,
            1.0 / (couplingSamplesPerFiringPeriod * firingFrequencyHz))
        : maximumLowSpeedCouplingSeconds;
    // Coupling accumulators are members carried across frames; see the header.
    // Diagnostic only: how much acoustic bandwidth the network resolves against
    // how much the audio boundary is allowed to observe. See EngineState.
    std::uint64_t exhaustNetworkAcceptedSubsteps = 0;
    double exhaustNetworkAdvancedSeconds = 0.0;
    std::uint32_t completedExhaustCouplingAdvances = 0;
    std::array<std::uint64_t, 32> intakeNetworkAcceptedSubsteps {};
    std::array<std::uint64_t, 32> intakeNetworkRejectedSubsteps {};
    std::array<double, 32> intakeNetworkAdvancedSeconds {};
    std::array<gasdynamics::ExhaustNetworkAdvanceResult, 32> intakeStepDiagnostics {};
    state_.exhaustNetworkMaximumAcceptedStepRatio = 0.0;
    state_.exhaustNetworkMaximumCourantCurrent = 0.0;
    state_.exhaustNetworkMaximumCourantPredictor = 0.0;
    std::array<std::uint32_t, 32> intakeCylinderTransferFailures {};
    std::array<IntakeSplitReservoirDiagnostics, 32> intakeSplitObservations {};
    intakeSplitReservoirDiagnostics_ = {};
    state_.intakeCouplingFlushCount = 0;
    state_.intakeCouplingAdvancedSeconds = 0.0;
    state_.intakeCouplingMinimumIntervalSeconds = 0.0;
    state_.intakeCouplingMaximumIntervalSeconds = 0.0;
    state_.intakePlenumTransferFailures = 0;
    std::size_t frameReactingExhaustControlVolumes = 0;
    std::size_t frameWallIgnitedExhaustControlVolumes = 0;
    double frameMaximumAfterfireInductionIntegral = 0.0;
    double frameMinimumAfterfireInductionDelaySeconds = 0.0;
    double frameMaximumAfterfireInductionDelaySeconds = 0.0;
    double frameTravelledDegrees = 0.0;
    double frameIntegratedSeconds = 0.0;
    // A power valve's servo follows its speed schedule with a lag: YPVS-type
    // servos take a few tenths of a second to sweep the valve.
    {
        constexpr double powerValveServoSeconds = 0.25;
        powerValveOpening_ += (powerValveTargetOpening(config_.twoStroke, state_.rpm)
            - powerValveOpening_) * (1.0 - std::exp(-dt / powerValveServoSeconds));
    }
    const auto exhaustPortOpenDegrees = exhaustPortOpenDegreesAt(config_.twoStroke, powerValveOpening_);

    while (remainingStepSeconds > 0.0) {
        // Predict with this frame's known external/starter commands rather
        // than the previous frame's external torque. The gas and friction
        // terms are the last resolved shaft values; no physics state is
        // advanced or discarded to choose the duration.
        const auto predictedStarterTorqueNm = safeControls.starterEngaged
            && state_.rpm < 620.0 && state_.damage < 1.0
            ? starterPeakTorqueNm * std::clamp(1.0 - state_.rpm / 760.0, 0.18, 1.0)
            : 0.0;
        const auto predictedNetTorqueNm = state_.torqueNm
            + predictedStarterTorqueNm - state_.loadTorqueNm
            + safeControls.externalTorqueNm + state_.reciprocatingTorqueNm;
        const auto positiveAngularAcceleration = std::max(0.0,
            predictedNetTorqueNm / integrationInertiaKgM2);
        const auto guardedCrankRadians = guardedCrankDegrees
            * std::numbers::pi / 180.0;
        const auto entryOmega = std::abs(state_.angularVelocityRadPerSecond);
        // Stable positive root of omega*t + alpha*t*t/2 = guarded angle.
        const auto terminalOmega = std::sqrt(entryOmega * entryOmega
            + 2.0 * positiveAngularAcceleration * guardedCrankRadians);
        const auto angleFrequency = (entryOmega + terminalOmega)
            / (2.0 * guardedCrankRadians);
        const auto requestedSolverFrequency = std::max(minimumGasFrequency,
            angleFrequency);
        const auto solverFrequency = std::min(requestedSolverFrequency,
            config_.solver.maximumMechanicalFrequencyHz);
        const auto requestedRemainingSteps = std::max(std::size_t { 1 },
            static_cast<std::size_t>(std::ceil(remainingStepSeconds * solverFrequency)));
        const auto remainingBudgetSteps = maximumSubStepCount - integratedSubStepCount;
        const auto remainingSteps = std::min(requestedRemainingSteps, remainingBudgetSteps);
        const auto subDt = remainingStepSeconds / static_cast<double>(remainingSteps);
        state_.solverResolutionLimited = state_.solverResolutionLimited
            || requestedSolverFrequency > config_.solver.maximumMechanicalFrequencyHz + 1.0e-9
            || requestedRemainingSteps > remainingBudgetSteps;
        ++integratedSubStepCount;
        // All consumers below use the same accepted duration: gas exchange,
        // chemistry, moving piston, crank work, thermal state and events.
        // From bottom dead centre to the transfers' closing, a two-stroke's
        // cylinder is a small volume between two open ports whose pressure
        // rides on a few kPa of balance between the charge coming in and the
        // gas going out, and that balance sets the trapped charge. Coupled to
        // the exhaust every 117 us there (RD350 at 8,000 rpm: 27.6 N.m), the
        // charge came out short; coupled every substep in that window only,
        // 31.1, as with every substep over the whole cycle (31.3). The first
        // half of scavenging gains nothing (journal 2026-10-16).
        const auto fineCouplingWindow = options_.exhaustFineCouplingWindowDegrees
            ? options_.exhaustFineCouplingWindowDegrees
            : config_.cycle == EngineCycle::twoStroke
                && options_.exhaustFineCouplingWhileScavenging.value_or(true)
            ? std::optional<std::array<double, 2>> { std::array<double, 2> {
                180.0, 360.0 - config_.twoStroke.transferPortOpenDegrees } }
            : std::nullopt;
        const auto inFineCouplingWindow = [&]() noexcept {
            if (!fineCouplingWindow) return false;
            const auto [first, last] = *fineCouplingWindow;
            for (const auto& cylinder : config_.cylinders) {
                const auto phase = std::fmod(state_.crankAngleDegrees
                    - crankOffsetDegreesFor(config_, cylinder) + phaseWrapBiasDegrees(cylinderCycleDegrees()),
                    cylinderCycleDegrees());
                if (phase >= first && phase <= last) return true;
            }
            return false;
        };
        const auto maximumExhaustCouplingSeconds = exhaustCouplingEverySubstep_
                || inFineCouplingWindow()
            ? subDt : productionExhaustCouplingSeconds;
        pollGasFieldCapture();
        recordGasProbe();
        advanceCylinderResize();
        advanceCamshaftChange();
        const auto subStepStartTime = state_.simulationTimeSeconds;
        const auto subPreviousRpm = state_.rpm;
        const auto subPreviousAngle = state_.crankAngleDegrees;
        // Physical intake topology supports 32 paths; the pressure/audio
        // stream separately publishes only the conductances it can hold.
        std::array<double, 32> intakeThrottleConductanceAreaM2 {};

        // Engine load is a thermodynamic state (approximately MAP / ambient
        // for a naturally aspirated SI engine), not the operator's brake
        // command.  Coupling flame turbulence and VVT to the dyno slider made
        // a wide-open, unloaded engine look like a zero-load combustion event.
        // A two-stroke's "manifold" is its crankcase, which pumps about
        // ambient at any throttle (75-87 kPa at idle): its filling is the
        // charge it delivered last cycle, the analogue of a four-stroke's MAP.
        const auto compressionIgnitionEngine =
            config_.fuel == FuelType::diesel;
        const auto thermodynamicLoad = compressionIgnitionEngine
            ? std::clamp(std::max(safeControls.throttle,
                (safeControls.ignitionEnabled || safeControls.starterEngaged)
                    ? 0.08 : 0.0), 0.0, 1.0)
            : config_.cycle == EngineCycle::twoStroke
            ? std::clamp(state_.deliveredVolumetricEfficiency, 0.0, 1.5)
            : std::clamp(state_.manifoldPressureKpa
                / std::max(1.0, config_.ambientPressureKpa), 0.0, 1.5);
        state_.load = smooth(state_.load, thermodynamicLoad, subDt, 12.0);
        auto ecuCommand = ecu_.evaluate(config_, state_, safeControls);
        if (config_.nitrous.fitted) {
            // The kit's retard box takes its spark off the map while it
            // sprays, and its oxygen is invisible to the ECU's air reading:
            // the lambda loop holds its trims while any is in the charge.
            ecuCommand.ignitionAdvanceDegrees -= nitrousSprayFraction_
                * config_.nitrous.sparkRetardDegreesPer50Hp * config_.nitrous.shotKw / (50.0 * 0.745'70);
            if (nitrousOxygenShare_ > 1.0e-4) ecuCommand.lambdaLearningAllowed = false;
        }
        if (hasVariableValveProfiles_) {
            const auto* vtecCam = firstVtecCamshaft(config_);
            state_.vtecEnabled = vtecCam != nullptr && ecuCommand.vtecEnabled;
            state_.vtecEngageRpm = vtecCam == nullptr ? 0.0
                : ecuCommand.vtecEngageRpm >= 0.0 ? ecuCommand.vtecEngageRpm : vtecCam->switchRpm;
        }
        const auto afrObservationCommandEnabled = compressionIgnitionEngine
            ? ecuCommand.fuelEnabled
            : ecuCommand.fuelEnabled && ecuCommand.sparkEnabled;
        // Start a new observation epoch after any fuel/spark cut. Until every
        // cylinder has fired a fresh fuelled charge, an engine-wide AFR would
        // mix pre-cut, cut and post-cut cycles. Retain the last numeric values
        // for diagnostics but mark them invalid instead of manufacturing 100:1.
        if (!afrObservationCommandEnabled
            || !previousAfrObservationCommandEnabled_) {
            actualAfrValidLastCycle_.fill(false);
        }
        const auto portInjectedGasoline =
            config_.fuel == FuelType::gasoline
            && config_.injection.mode == InjectionMode::port;
        if (portInjectedGasoline && ecuCommand.decelerationFuelResumeEvent) {
            for (std::size_t cylinder = 0;
                 cylinder < config_.cylinders.size(); ++cylinder) {
                portFuelResumePending_[cylinder] = true;
                portFuelResumePrepared_[cylinder] = false;
                portFuelResumePurgeCycleSeen_[cylinder] = false;
                // Require a continuously settled physical footprint below,
                // rather than assuming the port is full after a blind delay.
                portFuelResumeOpenLoopSecondsRemaining_[cylinder] =
                    4.0 * std::max(0.0,
                        config_.injection.vaporisationTimeConstantSeconds);
                portFuelResumeEpochAgeSeconds_[cylinder] = 0.0;
                // No post-cut observation exists for the first pulse. Start at
                // the positive geometric midpoint between the authored map and
                // the already identified high-load transport correction. This
                // avoids both measured extremes (unity flooded the small/large
                // NA engines; applying the full stale cell made the bikes lean)
                // and hands authority to the observable resume loop after the
                // first completed combustion.
                portFuelResumeFuelTrim_[cylinder] = std::sqrt(std::sqrt(
                    std::clamp(highLoadClosedLoopFuelTrim_[cylinder],
                        0.55, 2.20)));
            }
            actualAfrValidLastCycle_.fill(false);
        }
        previousAfrObservationCommandEnabled_ =
            afrObservationCommandEnabled;
        state_.exhaustAfterfireOverrunActive =
            ecuCommand.overrunAfterfireActive;
        state_.exhaustAfterfireBlockers = ecuCommand.overrunAfterfireBlockers;
        {
            // The engine brake holds with its switch on, the pedal released
            // and the engine running on its own, and lets go below its
            // minimum speed. It takes hold again 100 rpm higher, so a speed
            // sitting on the cut-out does not chatter it. Stage k of N
            // brakes the first round(k x cylinders / N) cylinders.
            const auto& brake = config_.engineBrake;
            const auto stages = std::max<std::uint32_t>(1, brake.stageCount);
            const auto stage = std::min(safeControls.engineBrakeStage, stages);
            const auto armed = brake.fitted && config_.cycle == EngineCycle::fourStroke && stage > 0
                && safeControls.ignitionEnabled && !safeControls.starterEngaged
                && safeControls.throttle <= engineBrakeMaximumThrottle;
            engineBrakeHeld_ = armed
                && state_.rpm >= brake.minimumRpm + (engineBrakeHeld_ ? 0.0 : 100.0);
            state_.engineBrakeCylinders = engineBrakeHeld_
                ? static_cast<std::uint32_t>(std::lround(static_cast<double>(config_.cylinders.size())
                    * static_cast<double>(stage) / static_cast<double>(stages)))
                : 0U;
        }
        state_.ecuFuelCorrection = ecuCommand.fuelCorrection;
        state_.ecuDieselFuelQuantityLimitMgPerCycle =
            ecuCommand.dieselFuelQuantityLimitMgPerCycle;
        state_.ecuFuelEnabled = ecuCommand.fuelEnabled;
        state_.ecuSparkEnabled = ecuCommand.sparkEnabled;
        state_.antiLagArmed = ecuCommand.antiLagArmed;
        state_.antiLagActive = ecuCommand.antiLagActive;
        state_.antiLagBlockers = ecuCommand.antiLagBlockers;
        state_.antiLagAuthority = ecuCommand.antiLagAuthority;
        state_.antiLagTargetTorqueNm = ecuCommand.antiLagTargetTorqueNm;
        state_.ecuSoftRevLimiterActive = ecuCommand.softRevLimiterActive;
        state_.ecuHardRevLimiterActive = ecuCommand.hardRevLimiterActive;
        state_.activeRevLimitRpm = ecuCommand.revLimitRpm;
        state_.activeLimits = ecuCommand.activeLimits;
        state_.ecuAlternatingSparkCutActive =
            ecuCommand.alternatingSparkCutActive;
        state_.ecuDecelerationFuelCutActive =
            ecuCommand.decelerationFuelCutActive;
        state_.throttle = smooth(state_.throttle, ecuCommand.effectiveThrottle, subDt, 10.0);
        if (compressionIgnitionEngine) {
            // A conventional diesel has no load-controlling throttle plate:
            // pedal and idle governor command fuel while the intake remains
            // open. `state_.load` therefore follows fuel demand rather than MAP.
            const auto idleFuelDemand =
                (safeControls.ignitionEnabled || safeControls.starterEngaged)
                ? ecuCommand.idleAirOpening * 0.20 : 0.0;
            state_.load = smooth(state_.load,
                std::clamp(std::max(state_.throttle, idleFuelDemand), 0.0, 1.0),
                subDt, 18.0);
        }
        const auto stationary = state_.rpm < 20.0 && !safeControls.starterEngaged;
        // A two-stroke's intake plenum is its crankcase: one per cylinder,
        // swept by the underside of the piston. The volume change is the
        // pumping; its work reaches the crank through the piston (below).
        const auto twoStrokeCrankcase = config_.cycle == EngineCycle::twoStroke;
        // With one cylinder a path (a multi-cylinder two-stroke's crankcases),
        // a path's crankcase volume, throttle and plenum loss below touch its
        // own gas only, so a turning engine runs them one path per pool item;
        // the sums over the paths are taken after, in path order.
        // Bit-identical (journal 2026-11-21).
        const auto intakePathPass = intakePathsConcurrent() && !stationary;
        const auto setCrankcaseVolume = [&](std::size_t index) noexcept {
            const auto& cylinder = config_.cylinders[index];
            intakePlenumGas_[intakePathIndexByCylinder_[index]].setVolumeAdiabatic(
                crankcaseVolumeLitres(cylinder, config_.twoStroke.crankcaseCompressionRatio,
                    std::fmod(state_.crankAngleDegrees - crankOffsetDegreesFor(config_, cylinder)
                        + 1'440.0, 360.0)));
        };
        if (twoStrokeCrankcase && !intakePathPass)
            for (std::size_t index = 0; index < config_.cylinders.size(); ++index)
                setCrankcaseVolume(index);
        // Resolve plenum jet mixing as a sudden expansion loss. The equivalent
        // spherical diameter supplies its characteristic length; no numerical
        // decay time is introduced.
        const auto applyPlenumLoss = [&](std::size_t pathIndex) noexcept {
            const auto volumeM3 = intakePlenumGas_[pathIndex].volumeM3();
            const auto hydraulicDiameterM = std::cbrt(6.0 * volumeM3 / std::numbers::pi);
            const auto plenumAreaM2 = std::numbers::pi * hydraulicDiameterM
                * hydraulicDiameterM * 0.25;
            const auto inletAreaRatio = std::clamp(
                intakePlenumGas_[pathIndex].characteristicAreaM2()
                    / std::max(1.0e-9, plenumAreaM2), 0.0, 1.0);
            const auto suddenExpansionLoss = std::pow(1.0 - inletAreaRatio, 2.0);
            intakePlenumGas_[pathIndex].applyFlowResistance(
                hydraulicDiameterM, hydraulicDiameterM, 1.5e-6,
                suddenExpansionLoss, subDt);
        };
        // A cylinder intake port lets the charge into the crankcase only while
        // the skirt leaves it open: its window in series with the carburettor,
        // nothing while it is covered, and a reed only if one is fitted. A
        // crankcase reed sees the carburettor alone.
        const auto cylinderPortIntake = twoStrokeCrankcase
            && config_.twoStroke.intake == TwoStrokeIntake::cylinderPort;
        const auto reedFitted = twoStrokeCrankcase
            && (!cylinderPortIntake || config_.twoStroke.intakePortReed);
        const auto crankcaseInletAreaM2 = [&](std::size_t pathIndex, double inletAreaM2,
                                              double dischargeCoefficient) {
            if (!cylinderPortIntake) return inletAreaM2;
            for (std::size_t index = 0; index < config_.cylinders.size(); ++index) {
                if (intakePathIndexByCylinder_[index] != pathIndex) continue;
                const auto& cylinder = config_.cylinders[index];
                const auto portM2 = intakePortOpenAreaMm2(config_.twoStroke, cylinder,
                        std::fmod(state_.crankAngleDegrees - crankOffsetDegreesFor(config_, cylinder)
                            + 1'440.0, 360.0))
                    * config_.twoStroke.portDischargeCoefficient * 1.0e-6;
                const auto carburettorM2 = inletAreaM2 * dischargeCoefficient;
                if (!(portM2 > 0.0) || !(carburettorM2 > 0.0)) return 0.0;
                return 1.0 / std::sqrt(1.0 / (carburettorM2 * carburettorM2) + 1.0 / (portM2 * portM2))
                    / dischargeCoefficient;
            }
            return inletAreaM2;
        };
        // A crank that is not turning passes no gas through its valves. The
        // quasi-steady valve law has an unbounded gain at zero pressure
        // difference, so an open valve held at equilibrium by a stopped crank
        // rang its runner into a self-sustained limit cycle (±15 to ±55 kPa,
        // measured on every engine, from a uniform ambient start).
        const auto valvesSealed = std::abs(state_.rpm) < 20.0
            && !safeControls.starterEngaged;
        if (stationary) {
            state_.boostPressureRatio = 1.0;
            state_.forcedInductionShaftSpeedRpm = 0.0;
            for (auto& unit : state_.turbochargers) unit = {};
            state_.wastegateOpening = 0.0;
            wastegateIntegral_ = 0.0;
            chargePressureKpa_ = 0.0;
            compressorDuctFlowKgPerSecond_ = 0.0;
            state_.compressorDuctFlowKgPerSecond = 0.0;
            state_.blowOffMassFlowKgPerSecond = 0.0;
            state_.compressorPowerKw = 0.0;
            state_.turbinePowerKw = 0.0;
            state_.turboBearingPowerKw = 0.0;
            state_.turboShaftNetPowerKw = 0.0;
            state_.forcedInductionShaftSpeedRatio = 0.0;
            for (std::size_t pathIndex = 0; pathIndex < intakePlenumCount_; ++pathIndex) {
                const auto& intake = intakeGeometryAt(config_, pathIndex);
                const auto throttleRadiusM = intake.throttleDiameterMm * 0.0005;
                const auto throttlePlateAreaM2 = static_cast<double>(intake.throttleCount)
                    * std::numbers::pi * throttleRadiusM * throttleRadiusM;
                const auto throttleAreaM2 = compressionIgnitionEngine
                    ? throttlePlateAreaM2
                    : closedThrottleLeakageAreaM2(intake)
                        + intake.idleBypassAreaMm2 * ecuCommand.idleAirOpening * 1.0e-6
                        + throttlePlateAreaM2 * std::pow(
                            state_.throttle, intake.throttleGamma);
                intakeThrottleConductanceAreaM2[pathIndex] = throttleAreaM2
                    * intake.throttleDischargeCoefficient;
                throttleFlowKeepingReversedFuel(intakePlenumGas_[pathIndex],
                    airboxSlug_[pathIndex], intake.airboxVolumeLitres,
                    config_.ambientPressureKpa, config_.ambientTemperatureC + 273.15,
                    crankcaseInletAreaM2(pathIndex, plenumInletAreaM2(intake, throttleAreaM2, throttlePlateAreaM2),
                        intake.throttleDischargeCoefficient),
                    intake.throttleDischargeCoefficient, subDt, reedFitted);
                if (intake.individualThrottles)
                    setIndividualThrottleAreas(pathIndex, throttlePlateAreaM2 > 0.0
                        ? throttleAreaM2 / throttlePlateAreaM2 : 1.0, throttlePlateAreaM2);
            }
        } else {
            constexpr double exhaustCpJPerKgK = 1'120.0;
            const auto ambientTemperatureK = config_.ambientTemperatureC + 273.15;
            const auto airMassFlowKgPerSecond = std::max(0.0, state_.airFlowGramsPerSecond) * 0.001;
            const auto compressorMassFlowKgPerSecond = airMassFlowKgPerSecond
                + std::max(0.0, state_.blowOffMassFlowKgPerSecond);
            const auto exhaustMassFlowKgPerSecond = std::max(0.0, state_.exhaustFlowGramsPerSecond) * 0.001;
            auto pressureRatioTarget = 1.0;
            auto compressorPowerW = 0.0;
            auto rootsPowerW = -1.0;
            auto chargeResolved = false;
            auto turbinePowerW = 0.0;
            state_.turboBearingPowerKw = 0.0;
            state_.turboShaftNetPowerKw = 0.0;
            state_.forcedInductionShaftSpeedRatio = 0.0;
            const auto exhaustTemperatureK = std::max(ambientTemperatureK, state_.exhaustTemperatureC + 273.15);
            if (config_.forcedInduction.enabled
                    && config_.forcedInduction.type == ForcedInductionType::supercharger) {
                // Geared to the crank, a supercharger's boost is its machine's
                // answer to the engine's draw, not a fraction of a target.
                const auto& charger = config_.forcedInduction;
                state_.forcedInductionShaftSpeedRpm = state_.rpm * charger.superchargerDriveRatio;
                state_.wastegateOpening = 0.0;
                if (charger.superchargerLobeCount > 0) {
                    // A Roots: a displacement, its leak and a bypass the
                    // manifold's vacuum opens, so it idles and cruises
                    // without pumping against the throttle.
                    const auto bypassOpening = std::clamp((config_.ambientPressureKpa
                        - state_.manifoldPressureKpa) / rootsBypassFullOpenVacuumKpa, 0.0, 1.0);
                    const auto roots = rootsOperatingPoint(rootsDisplacementLitres(config_),
                        state_.forcedInductionShaftSpeedRpm, airMassFlowKgPerSecond,
                        state_.boostPressureRatio, rootsBypassAreaM2(config_) * bypassOpening,
                        config_.ambientPressureKpa, ambientTemperatureK);
                    pressureRatioTarget = roots.pressureRatio;
                    rootsPowerW = roots.powerWatts;
                } else {
                    // A centrifugal wheel on the turbocharger's map, at the
                    // speed the drive gives it; the authored ratio is held
                    // above full-boost speed by a relief (the Merlin's boost
                    // regulator).
                    auto wheel = charger;
                    wheel.designShaftSpeedRpm = std::max(1.0, charger.fullBoostRpm * charger.superchargerDriveRatio);
                    const auto point = compressorOperatingPoint(wheel,
                        centrifugalSuperchargerDesignMassFlowKgPerSecond(config_),
                        state_.forcedInductionShaftSpeedRpm * 2.0 * std::numbers::pi / 60.0,
                        compressorMassFlowKgPerSecond, ambientTemperatureK, config_.ambientPressureKpa);
                    pressureRatioTarget = std::min(point.pressureRatio, std::max(1.0, charger.pressureRatio));
                    state_.forcedInductionShaftSpeedRatio = point.speedRatio;
                }
            } else if (config_.forcedInduction.enabled) {
                const auto& turbo = config_.forcedInduction;
                const auto turbochargerCount = std::clamp<std::size_t>(
                    turbo.turbochargerCount, 1, maximumTurbochargers);
                // Without turbine faces, the exhaust is shared equally.
                const auto exhaustFlowSplit = partitionTurboExhaustFlow(
                    config_.forcedInduction, exhaustMassFlowKgPerSecond
                        / static_cast<double>(turbochargerCount),
                    state_.wastegateOpening);
                const auto designOmega = config_.forcedInduction.designShaftSpeedRpm
                    * 2.0 * std::numbers::pi / 60.0;
                const auto turbineInletPressureKpa = std::max(state_.exhaustPressureKpa,
                                                               state_.exhaustRunnerPressureKpa);
                // A turbine expands to ITS OWN OUTLET, not to atmosphere.
                //
                // Referencing the expansion to ambient hard-wired away the one
                // thing a downpipe and a silencer actually set. The only
                // remaining path from exhaust geometry to a turbo's output was
                // then the INLET term, and that one has the wrong sign: larger
                // primaries expand the blowdown pulse into more volume and
                // lower the peak the turbine is charged with. So the model
                // could only ever answer "bigger exhaust, less boost", which is
                // what a user rebuilding a 2JZ exhaust in 80 mm reported --
                // more inertia, less response, and no improvement anywhere.
                //
                // The downstream system is not a separate control volume here,
                // so its back pressure is taken quasi-steadily from the flow it
                // is actually passing: the dynamic head an orifice of the
                // configured downstream conductance needs to pass this mass
                // flow. It is bounded well below the inlet pressure -- a
                // turbine outlet above its own inlet is not a turbine -- and it
                // reduces exactly to the previous behaviour as the downstream
                // conductance grows, so a genuinely free downpipe still reads
                // ambient.
                const auto downstreamConductanceM2 =
                    std::max(1.0e-6, exhaustOutletConductanceM2_);
                const auto downstreamDensityKgPerM3 = std::max(0.05,
                    config_.ambientPressureKpa * 1'000.0
                        / (287.0 * std::max(250.0, exhaustTemperatureK)));
                const auto downstreamVelocityMps =
                    std::max(0.0, exhaustMassFlowKgPerSecond)
                    / (downstreamDensityKgPerM3 * downstreamConductanceM2);
                const auto downstreamLossKpa = std::min(
                    0.5 * downstreamDensityKgPerM3 * downstreamVelocityMps
                        * downstreamVelocityMps * 0.001,
                    0.60 * turbineInletPressureKpa);
                const auto turbineOutletPressureKpa = std::max(1.0,
                    config_.ambientPressureKpa + downstreamLossKpa);
                state_.turbineOutletPressureKpa = turbineOutletPressureKpa;
                const auto turbineExpansionRatio = std::max(1.0,
                    turbineInletPressureKpa / turbineOutletPressureKpa);
                turbinePowerW = exhaustFlowSplit.turbineKgPerSecond
                    * exhaustCpJPerKgK * exhaustTemperatureK
                    * (1.0 - std::pow(turbineExpansionRatio,
                        -turboIsentropicExponent))
                    * config_.forcedInduction.turbineEfficiency;
                std::array<double, maximumTurbochargers> turbochargerTurbinePowerW {};
                turbochargerTurbinePowerW.fill(turbinePowerW);
                if (!exhaustTurbineFaces_.empty()) {
                    // The network's turbine faces expand the gas itself, pulse
                    // by pulse, into the pressure their downpipe actually holds.
                    turbochargerTurbinePowerW = networkTurbinePowerW_;
                    state_.turbineOutletPressureKpa = networkTurbineOutletPressureKpa_;
                }
                // Boost control: proportional-integral on the pressure ratio,
                // holding the wastegate ratio exactly. A proportional gate
                // fully open 0.08 above it was a loop gain of ~30 once the
                // turbine sat in the gas network (opening the gate drops the
                // manifold pressure at once): on the TDI's light shaft it ran a
                // 4 Hz limit cycle, gate 0 -> 0.45, torque +-15 N.m (journal
                // 2026-10-13). The integral is frozen while the gate is
                // saturated in the direction it would push.
                constexpr double wastegateBandRatio = 0.25;
                constexpr double wastegateIntegralSeconds = 0.5;
                // The actuator's spring works against the atmosphere, so it
                // holds a gauge boost: the configured ratio is the one at
                // sea-level pressure, and up high the ratio it allows rises.
                // A ratio target lost as much manifold pressure as an
                // unblown engine (2JZ at 2,000 m: -25 % torque).
                // The ECU's boost table, when it has one, is that gauge boost
                // by engine speed.
                constexpr double seaLevelPressureKpa = 101.325;
                const auto wastegateRatio = ecuCommand.boostTargetGaugeKpa >= 0.0
                    ? 1.0 + ecuCommand.boostTargetGaugeKpa / std::max(1.0, config_.ambientPressureKpa)
                    : config_.forcedInduction.wastegatePressureRatio
                        + (config_.forcedInduction.wastegatePressureRatio - 1.0)
                            * (seaLevelPressureKpa / std::max(1.0, config_.ambientPressureKpa) - 1.0);
                // The gate's authority over the boost grows with the boost it
                // holds: a fixed band that holds 2.45 ran a 13 Hz limit cycle
                // above ~2.7 (2JZ) to ~3.0 (EJ25, I5), the gate slamming 0 -> 1,
                // boost 3.0 <-> 3.7 and lambda 0.58 <-> 0.96 on an EJ25 at 3.2
                // (journal 2026-10-25). The band widens as the cube of the gauge
                // target past what the catalogue holds, so its engines are
                // untouched (linear and square still hunted on the 2JZ).
                constexpr double wastegateScheduledFromGaugeRatio = 1.5;
                const auto bandGrowth = std::max(1.0,
                    (wastegateRatio - 1.0) / wastegateScheduledFromGaugeRatio);
                const auto scheduledBandRatio = wastegateBandRatio * bandGrowth * bandGrowth * bandGrowth;
                const auto proportional = (state_.boostPressureRatio
                    - wastegateRatio) / scheduledBandRatio;
                const auto unclamped = proportional + wastegateIntegral_;
                if ((unclamped < 1.0 || proportional < 0.0) && (unclamped > 0.0 || proportional > 0.0))
                    wastegateIntegral_ = std::clamp(wastegateIntegral_
                        + proportional * subDt / wastegateIntegralSeconds, 0.0, 1.0);
                state_.wastegateOpening = std::clamp(proportional + wastegateIntegral_, 0.0, 1.0);
                // The compressors feed one charge. Each passes the share of the
                // drawn flow its map gives at the common pressure and its own
                // speed: one compressor takes it all, several are solved
                // together every 0.25 ms (the charge itself settles over tens
                // of milliseconds).
                const auto designFlowKgPerSecond = compressorDesignMassFlowKgPerSecond(config_);
                std::array<double, maximumTurbochargers> shaftOmega {};
                for (std::size_t index = 0; index < turbochargerCount; ++index)
                    shaftOmega[index] = state_.turbochargers[index].shaftSpeedRpm * 2.0 * std::numbers::pi / 60.0;
                // A burst wheel: its shaft stands, its turbine is only a
                // restriction in the gas, its compressor makes no head.
                for (std::size_t index = 0; index < turbochargerCount; ++index)
                    if (state_.turbochargers[index].wheelDamage >= 1.0) {
                        shaftOmega[index] = 0.0;
                        turbochargerTurbinePowerW[index] = 0.0;
                    }
                if (turbochargerCount > 1U) {
                    parallelCompressorSolveAgeSeconds_ += subDt;
                    if (parallelCompressorSolveAgeSeconds_ >= 2.5e-4
                            || parallelCompressorFlowShare_[0] + parallelCompressorFlowShare_[1] <= 0.0) {
                        parallelCompressorSolveAgeSeconds_ = 0.0;
                        std::array<double, maximumTurbochargers> flows {};
                        parallelCompressorPressureRatio_ = parallelCompressorPressureRatio(turbo,
                            designFlowKgPerSecond, shaftOmega, turbochargerCount,
                            compressorMassFlowKgPerSecond, ambientTemperatureK,
                            config_.ambientPressureKpa, flows);
                        for (std::size_t index = 0; index < turbochargerCount; ++index)
                            parallelCompressorFlowShare_[index] = compressorMassFlowKgPerSecond > 0.0
                                ? flows[index] / compressorMassFlowKgPerSecond
                                : 1.0 / static_cast<double>(turbochargerCount);
                    }
                }
                // Greitzer's model: the duct's flow accelerates on the head
                // the wheels hold over the charge's pressure, and the charge
                // fills with what the duct brings less what the throttles
                // and the blow-off valve pass (both from the last substep).
                // Its time scale is the Helmholtz period of duct and charge,
                // milliseconds, so it is integrated every substep: the flow
                // first, then the pressure from it (stable while the period
                // spans more than ~3 substeps).
                chargeResolved = turbo.compressorSurge;
                if (chargeResolved) {
                    if (!(chargePressureKpa_ > 0.0)) {
                        chargePressureKpa_ = config_.ambientPressureKpa * state_.boostPressureRatio;
                        compressorDuctFlowKgPerSecond_ = compressorMassFlowKgPerSecond;
                    }
                    auto head = 0.0;
                    for (std::size_t index = 0; index < turbochargerCount; ++index)
                        head += compressorSurgeHeadPressureRatio(turbo, designFlowKgPerSecond, shaftOmega[index],
                            compressorDuctFlowKgPerSecond_ / static_cast<double>(turbochargerCount),
                            ambientTemperatureK, config_.ambientPressureKpa);
                    head /= static_cast<double>(turbochargerCount);
                    const auto ductAreaM2 = compressorDuctAreaM2(config_) * static_cast<double>(turbochargerCount);
                    compressorDuctFlowKgPerSecond_ += ductAreaM2 / compressorDuctLengthM
                        * (head * config_.ambientPressureKpa - chargePressureKpa_) * 1'000.0 * subDt;
                    const auto chargeRatio = std::max(1.0, chargePressureKpa_ / config_.ambientPressureKpa);
                    const auto chargeTemperatureK = ambientTemperatureK * (1.0
                        + (std::pow(chargeRatio, turboIsentropicExponent) - 1.0)
                            / std::max(0.35, turbo.compressorEfficiency));
                    chargePressureKpa_ = std::max(0.2 * config_.ambientPressureKpa, chargePressureKpa_
                        + 287.05 * chargeTemperatureK / chargeVolumeM3(config_)
                            * (compressorDuctFlowKgPerSecond_ * subDt - throttleFlowKgLastStep_
                                - state_.blowOffMassFlowKgPerSecond * subDt) * 0.001);
                }
                auto shaftSpeedSumRpm = 0.0;
                turbinePowerW = 0.0;
                for (std::size_t index = 0; index < turbochargerCount; ++index) {
                    auto& unit = state_.turbochargers[index];
                    const auto unitFlowKgPerSecond = chargeResolved
                        ? compressorDuctFlowKgPerSecond_ / static_cast<double>(turbochargerCount)
                        : turbochargerCount == 1U ? compressorMassFlowKgPerSecond
                        : compressorMassFlowKgPerSecond * parallelCompressorFlowShare_[index];
                    const auto shaftAdvance = advanceTurboShaft(turbo, shaftOmega[index],
                        turbochargerTurbinePowerW[index], unitFlowKgPerSecond, ambientTemperatureK,
                        state_.boostPressureRatio, subDt);
                    shaftOmega[index] = shaftAdvance.angularSpeedRadPerSecond;
                    // Past the top speed line the wheel is overstressed.
                    const auto topOmega = turboMaximumShaftSpeedRpm(turbo) * 2.0 * std::numbers::pi / 60.0;
                    if (topOmega > 0.0 && shaftOmega[index] > topOmega && unit.wheelDamage < 1.0) {
                        const auto overspeed = shaftOmega[index] / topOmega - 1.0;
                        unit.wheelDamage = std::min(1.0, unit.wheelDamage
                            + turboOverspeedDamagePerSecond * overspeed * overspeed * subDt);
                        if (unit.wheelDamage >= 1.0) shaftOmega[index] = 0.0;
                    }
                    compressorPowerW += shaftAdvance.compressorPowerWatts;
                    turbinePowerW += turbochargerTurbinePowerW[index];
                    state_.turboBearingPowerKw += shaftAdvance.bearingPowerWatts * 0.001;
                    state_.turboShaftNetPowerKw += shaftAdvance.netPowerWatts * 0.001;
                    unit.shaftSpeedRpm = shaftOmega[index] * 60.0 / (2.0 * std::numbers::pi);
                    unit.turbinePowerKw = turbochargerTurbinePowerW[index] * 0.001;
                    unit.compressorPowerKw = shaftAdvance.compressorPowerWatts * 0.001;
                    unit.compressorMassFlowKgPerSecond = unitFlowKgPerSecond;
                    shaftSpeedSumRpm += unit.shaftSpeedRpm;
                }
                state_.turbochargerCount = static_cast<std::uint32_t>(turbochargerCount);
                state_.forcedInductionShaftSpeedRpm = shaftSpeedSumRpm / static_cast<double>(turbochargerCount);
                state_.forcedInductionShaftSpeedRatio = state_.forcedInductionShaftSpeedRpm
                    * 2.0 * std::numbers::pi / 60.0 / std::max(1.0, designOmega);
                // The pressure head is read from the compressor map at the
                // flow the engine draws. The throttle is not a gain here: its
                // measured flow changes the compressor work and head, and a
                // closed throttle can retain upstream pressure long enough to
                // drive a real bypass valve.
                if (turbochargerCount == 1U) {
                    const auto point = compressorOperatingPoint(turbo, designFlowKgPerSecond, shaftOmega[0],
                        compressorMassFlowKgPerSecond, ambientTemperatureK, config_.ambientPressureKpa);
                    pressureRatioTarget = point.pressureRatio;
                    state_.turbochargers[0].compressorFlowCoefficientRatio = point.flowCoefficientRatio;
                    state_.turbochargers[0].compressorEfficiency = turbo.compressorEfficiency
                        * compressorOverspeedEfficiencyScale(turbo, shaftOmega[0]);
                } else {
                    pressureRatioTarget = parallelCompressorPressureRatio_;
                    for (std::size_t index = 0; index < turbochargerCount; ++index) {
                        const auto point = compressorOperatingPoint(turbo, designFlowKgPerSecond, shaftOmega[index],
                            state_.turbochargers[index].compressorMassFlowKgPerSecond, ambientTemperatureK,
                            config_.ambientPressureKpa);
                        state_.turbochargers[index].compressorFlowCoefficientRatio = point.flowCoefficientRatio;
                        state_.turbochargers[index].compressorEfficiency = turbo.compressorEfficiency
                            * compressorOverspeedEfficiencyScale(turbo, shaftOmega[index]);
                    }
                }
                if (chargeResolved) pressureRatioTarget = chargePressureKpa_ / config_.ambientPressureKpa;
            }
            state_.compressorDuctResolved = chargeResolved;
            state_.compressorDuctFlowKgPerSecond = chargeResolved ? compressorDuctFlowKgPerSecond_ : 0.0;
            if (!config_.forcedInduction.enabled
                || config_.forcedInduction.type
                    == ForcedInductionType::supercharger) {
                compressorPowerW = compressorPowerForPressureRatioWatts(
                    config_.forcedInduction, compressorMassFlowKgPerSecond,
                    ambientTemperatureK, pressureRatioTarget);
            }
            // A Roots heats its charge by the work it does on it: its
            // efficiency is the isentropic work over that.
            auto chargeCompressionEfficiency = config_.forcedInduction.compressorEfficiency;
            // Past its top speed line a turbocharger's wheel heats the charge
            // as much as the work it loses (exactly 1 up to the line).
            if (config_.forcedInduction.enabled
                    && config_.forcedInduction.type == ForcedInductionType::turbocharger)
                chargeCompressionEfficiency *= compressorOverspeedEfficiencyScale(config_.forcedInduction,
                    state_.forcedInductionShaftSpeedRpm * 2.0 * std::numbers::pi / 60.0);
            if (rootsPowerW >= 0.0) {
                chargeCompressionEfficiency = rootsPowerW > 0.0
                    ? std::clamp(compressorPowerW * config_.forcedInduction.compressorEfficiency
                        / rootsPowerW, 0.35, 0.90)
                    : 0.90;
                compressorPowerW = rootsPowerW;
            }
            state_.compressorPowerKw = compressorPowerW * 0.001;
            state_.turbinePowerKw = turbinePowerW * 0.001;
            state_.boostPressureRatio = chargeResolved ? pressureRatioTarget
                : smooth(state_.boostPressureRatio,
                    config_.forcedInduction.enabled ? pressureRatioTarget : 1.0, subDt, 14.0);
            if (!config_.forcedInduction.enabled) {
                state_.forcedInductionShaftSpeedRpm = 0.0;
                for (auto& unit : state_.turbochargers) unit = {};
                state_.turbochargerCount = 0;
                state_.wastegateOpening = 0.0;
                state_.blowOffMassFlowKgPerSecond = 0.0;
            }
            const auto boostBlend = std::clamp((state_.boostPressureRatio - 1.0)
                / std::max(0.01, config_.forcedInduction.pressureRatio - 1.0), 0.0, 1.0);
            const auto intakeSourcePressureKpa = config_.ambientPressureKpa * state_.boostPressureRatio;
            const auto isentropicRiseC = ambientTemperatureK
                * (std::pow(std::max(1.0, state_.boostPressureRatio),
                    turboIsentropicExponent) - 1.0)
                / std::max(0.35, chargeCompressionEfficiency);
            const auto chargeTemperatureC = config_.ambientTemperatureC + isentropicRiseC
                + config_.forcedInduction.chargeTemperatureRiseC * 0.15 * boostBlend;
            // A charge-air cooler takes back its share of the rise.
            const auto cooledChargeTemperatureC = chargeTemperatureC
                - std::clamp(config_.forcedInduction.intercoolerEffectiveness, 0.0, 0.95)
                    * std::max(0.0, chargeTemperatureC - config_.ambientTemperatureC);
            const auto temperatureK = std::max(240.0, cooledChargeTemperatureC + 273.15);
            if (config_.forcedInduction.enabled
                    && config_.forcedInduction.blowOffValveFlowAreaMm2 > 0.0) {
                const auto referencePressureRatio = intakeSourcePressureKpa
                    / std::max(1.0, state_.manifoldPressureKpa);
                const auto opening = std::clamp((referencePressureRatio
                    - config_.forcedInduction.blowOffValveOpeningPressureRatio)
                    / 0.08, 0.0, 1.0);
                state_.blowOffMassFlowKgPerSecond =
                    reservoirOrificeMassFlowKgPerSecond(
                        intakeSourcePressureKpa, config_.ambientPressureKpa,
                        temperatureK,
                        config_.forcedInduction.blowOffValveFlowAreaMm2
                            * opening * 1.0e-6,
                        config_.forcedInduction.blowOffValveDischargeCoefficient);
            } else {
                state_.blowOffMassFlowKgPerSecond = 0.0;
            }

            std::array<double, 32> pathThrottleFlowKg {};
            std::array<double, 32> pathCarburettorFuelKg {};
            std::array<double, 32> pathNitrousFuelKg {};
            std::array<std::uint8_t, 32> pathCarburettorMetered {};
            std::array<std::uint8_t, 32> pathNitrousFuelled {};
            const auto throttlePath = [&](std::size_t pathIndex) noexcept {
                const auto& intake = intakeGeometryAt(config_, pathIndex);
                const auto throttleRadiusM = intake.throttleDiameterMm * 0.0005;
                const auto throttlePlateAreaM2 = static_cast<double>(intake.throttleCount)
                    * std::numbers::pi * throttleRadiusM * throttleRadiusM;
                const auto idleBypassAreaM2 = intake.idleBypassAreaMm2
                    * ecuCommand.idleAirOpening * 1.0e-6;
                const auto throttleAreaM2 = compressionIgnitionEngine
                    ? throttlePlateAreaM2
                    : closedThrottleLeakageAreaM2(intake)
                        + idleBypassAreaM2
                        + throttlePlateAreaM2 * std::pow(
                            state_.throttle, intake.throttleGamma);
                intakeThrottleConductanceAreaM2[pathIndex] = throttleAreaM2
                    * intake.throttleDischargeCoefficient;
                const auto crankcaseMassBeforeKg = intakePlenumGas_[pathIndex].massKg();
                const auto inletAreaM2 = crankcaseInletAreaM2(pathIndex,
                    plenumInletAreaM2(intake, throttleAreaM2, throttlePlateAreaM2),
                    intake.throttleDischargeCoefficient);
                // A covered cylinder port leaves the carburettor's bore standing
                // at the airbox's pressure: its pilot sees no drop.
                const auto intakePortShut = cylinderPortIntake && !(inletAreaM2 > 0.0);
                throttleFlowKeepingReversedFuel(intakePlenumGas_[pathIndex],
                    airboxSlug_[pathIndex], intake.airboxVolumeLitres,
                    intakeSourcePressureKpa, temperatureK, inletAreaM2,
                    intake.throttleDischargeCoefficient, subDt, reedFitted);
                pathThrottleFlowKg[pathIndex] = intakePlenumGas_[pathIndex].massKg() - crankcaseMassBeforeKg;
                const auto plenumInflowKg = std::max(0.0,
                    intakePlenumGas_[pathIndex].massKg() - crankcaseMassBeforeKg);
                if (twoStrokeCrankcase)
                    reedInflowMgThisFill_[pathIndex] += plenumInflowKg * 1.0e6;
                if (intake.carburettor.enabled) {
                    // A carburettor meters the air that crossed it, and the
                    // fuel it draws goes where that air went: into the
                    // crankcase, not into the transfer duct an event later.
                    // The lag to the cylinder is then the crankcase's own
                    // residence time, which is the thing an injector command
                    // had to guess at and got wrong on a tip-in.
                    constexpr double airGasConstantJPerKgK = 287.05;
                    const auto boundaryDensityKgPerM3 =
                        intakeSourcePressureKpa * 1'000.0
                        / (airGasConstantJPerKgK * std::max(1.0, temperatureK));
                    // One carburettor per bore, all alike: each passes its
                    // share of the air and meters for that share, so the
                    // bores' fuel is one bore's times their count. The pilot
                    // drop is to whatever sits behind the plates: the plenum,
                    // or with individual throttles the runners' balance tap.
                    const auto bores = static_cast<double>(std::max(1U, intake.throttleCount));
                    const auto pilotPressureKpa = intakePortShut ? intakeSourcePressureKpa
                        : intake.individualThrottles ? individualThrottleMapKpa_[pathIndex]
                        : intakePlenumGas_[pathIndex].pressureKpa();
                    // With a starter circuit the start aid's air above the
                    // idle stop is the enrichener's own passage, and carries
                    // its jet's fuel rather than the pilot's.
                    const auto screwOpening = carburettorIdleScrewOpening(intake.carburettor.idleScrewTurns);
                    const auto starterFitted = intake.carburettor.starterJetFlowNumber > 0.0;
                    const auto metering = CarburettorModel::meter(
                        intake.carburettor, config_.fuelProperties,
                        carburettorStates_[pathIndex],
                        plenumInflowKg / subDt / bores, boundaryDensityKgPerM3,
                        intakeSourcePressureKpa, pilotPressureKpa,
                        intake.throttleDiameterMm, state_.throttle,
                        throttleAreaM2 / bores * intake.throttleDischargeCoefficient,
                        throttlePlateAreaM2 / bores * std::pow(state_.throttle, intake.throttleGamma)
                            * intake.throttleDischargeCoefficient,
                        subDt,
                        carburettorIdleCircuitOpening(intake, starterFitted
                            ? std::min(ecuCommand.idleAirOpening, screwOpening) : ecuCommand.idleAirOpening),
                        starterFitted ? std::max(0.0, ecuCommand.idleAirOpening - screwOpening)
                            / carburettorPilotSizingIdleOpening : 0.0);
                    if (metering.deliveredMoles > 0.0)
                        intakePlenumGas_[pathIndex].injectFuelMoles(
                            metering.deliveredMoles * bores,
                            config_.injection.fuelTemperatureC + 273.15);
                    pathCarburettorFuelKg[pathIndex] = metering.meteredMoles * bores
                        * config_.fuelProperties.molarMassGramsPerMole * 0.001;
                    pathCarburettorMetered[pathIndex] = 1;
                }
                if (nitrousMassFlowKgPerSecond_ > 0.0) {
                    // One nozzle behind the throttle(s), shared by the plenums.
                    const auto nitrousMoles = nitrousMassFlowKgPerSecond_ * subDt / nitrousMolarMassKg
                        / static_cast<double>(intakePlenumCount_);
                    intakePlenumGas_[pathIndex].injectNitrousOxideMoles(nitrousMoles,
                        nitrousBottleTemperatureK_,
                        nitrousLatentHeatJPerKg(nitrousBottleTemperatureK_) * nitrousMolarMassKg);
                    if (config_.nitrous.type == NitrousKitType::wet) {
                        const auto kitFuelMoles = 0.5 * nitrousMoles
                            / (config_.fuelProperties.oxygenMolesPerFuelMole * config_.nitrous.kitLambda);
                        intakePlenumGas_[pathIndex].injectFuelMoles(
                            kitFuelMoles, config_.injection.fuelTemperatureC + 273.15);
                        // Counted as fuel used: it burnt uncounted, so the
                        // fuel flow and BSFC undercounted the spray (audit PG-02).
                        pathNitrousFuelKg[pathIndex] = kitFuelMoles
                            * config_.fuelProperties.molarMassGramsPerMole * 0.001;
                        pathNitrousFuelled[pathIndex] = 1;
                    }
                }
                if (intake.individualThrottles)
                    setIndividualThrottleAreas(pathIndex, throttlePlateAreaM2 > 0.0
                        ? throttleAreaM2 / throttlePlateAreaM2 : 1.0, throttlePlateAreaM2);
            };
            if (intakePathPass) {
                const auto advancePath = [&](std::size_t pathIndex) noexcept {
                    if (twoStrokeCrankcase)
                        for (std::size_t index = 0; index < config_.cylinders.size(); ++index)
                            if (intakePathIndexByCylinder_[index] == pathIndex) setCrankcaseVolume(index);
                    throttlePath(pathIndex);
                    applyPlenumLoss(pathIndex);
                };
                intakeWorkerPool_->runIndices(intakePlenumCount_,
                    [](void* context, std::size_t path) noexcept {
                        (*static_cast<const decltype(advancePath)*>(context))(path);
                    },
                    const_cast<void*>(static_cast<const void*>(&advancePath)));
            } else {
                for (std::size_t pathIndex = 0; pathIndex < intakePlenumCount_; ++pathIndex)
                    throttlePath(pathIndex);
            }
            // The serial loop's sums, in its order.
            auto throttleFlowKgThisStep = 0.0;
            for (std::size_t pathIndex = 0; pathIndex < intakePlenumCount_; ++pathIndex) {
                throttleFlowKgThisStep += pathThrottleFlowKg[pathIndex];
                if (pathCarburettorMetered[pathIndex] != 0)
                    carburettorFuelMassKgThisStep_ += pathCarburettorFuelKg[pathIndex];
                if (pathNitrousFuelled[pathIndex] != 0)
                    nitrousFuelMassKgThisStep_ += pathNitrousFuelKg[pathIndex];
            }
            throttleFlowKgLastStep_ = throttleFlowKgThisStep;
            if (config_.nitrous.fitted) {
                // The share of the plenum's oxygen that came from the kit:
                // both supplies smoothed over 0.15 s, about a cycle and the
                // runners' transit at the speeds a kit sprays at.
                const auto smoothing = 1.0 - std::exp(-subDt / 0.15);
                constexpr double airOxygenMolesPerKg = 0.2314 / 0.0319988;
                nitrousOxygenRateMolPerSecond_ += smoothing
                    * (0.5 * nitrousMassFlowKgPerSecond_ / nitrousMolarMassKg - nitrousOxygenRateMolPerSecond_);
                throttleOxygenRateMolPerSecond_ += smoothing
                    * (std::max(0.0, throttleFlowKgThisStep) / subDt * airOxygenMolesPerKg
                        - throttleOxygenRateMolPerSecond_);
                const auto total = nitrousOxygenRateMolPerSecond_ + throttleOxygenRateMolPerSecond_;
                nitrousOxygenShare_ = total > 1.0e-12 ? nitrousOxygenRateMolPerSecond_ / total : 0.0;
                if (nitrousOxygenShare_ < 1.0e-6 && nitrousMassFlowKgPerSecond_ <= 0.0) nitrousOxygenShare_ = 0.0;
                state_.nitrousOxygenShare = nitrousOxygenShare_;
            }
        }
        if (!intakePathPass)
            for (std::size_t pathIndex = 0; pathIndex < intakePlenumCount_; ++pathIndex)
                applyPlenumLoss(pathIndex);
        state_.manifoldPressureKpa = 0.0;
        for (std::size_t pathIndex = 0; pathIndex < intakePlenumCount_; ++pathIndex)
            state_.manifoldPressureKpa += intakeGeometryAt(config_, pathIndex).individualThrottles
                ? individualThrottleManifoldPressureKpa(pathIndex, subDt)
                : intakePlenumGas_[pathIndex].pressureKpa();
        state_.manifoldPressureKpa /= static_cast<double>(intakePlenumCount_);

        // The nonlinear network is mandatory and is compiled by the
        // constructor. There is intentionally no lumped-exhaust fallback.
        auto& physicalExhaustNetwork = *physicalExhaustNetwork_;
        double collectorPressureKpa = config_.ambientPressureKpa;
        // Spatial mean over the ports, taken in the same sweep as the peak. The
        // peak is what audio and blowdown telemetry need; the mean is what back
        // pressure means, and conflating them made a free-flowing engine look
        // restricted. See EngineState::exhaustPressureKpa.
        double portPressureSumKpa = 0.0;
        std::size_t portPressureCount = 0;
        for (const auto& exchange : physicalExhaustNetwork.cylinderExchanges()) {
            const auto portKpa = exchange.networkPressurePa * 0.001;
            collectorPressureKpa = std::max(collectorPressureKpa, portKpa);
            portPressureSumKpa += portKpa;
            ++portPressureCount;
        }
        state_.exhaustPressureKpa = collectorPressureKpa;
        // Damp the spatial mean over ~3 firing periods so the published figure is
        // a gauge reading rather than a snapshot of wherever in the blowdown the
        // sub-step happened to land. Floored so a cranking or stalled engine still
        // converges instead of freezing at its initial value.
        if (portPressureCount > 0) {
            const auto instantaneousMeanKpa = portPressureSumKpa
                / static_cast<double>(portPressureCount);
            state_.exhaustBackPressureKpa = smooth(state_.exhaustBackPressureKpa,
                instantaneousMeanKpa, subDt, std::max(4.0, firingFrequencyHz / 3.0));
        }
        const auto backPressure = state_.exhaustPressureKpa;
        const auto combustion = physics_.evaluateCombustion(config_, state_, safeControls, ecuCommand, backPressure);
        // A deliberate fuel cut leaves ignition enabled so the ECU can resume
        // immediately, but an enabled coil is not a commanded combustion event
        // without fuel. Counting those clean DFCO cycles as misfires polluted
        // the rolling misfire state and made the following tip-in look faulty
        // even before the first refuelled charge reached a spark.
        const auto sparkCombustionAvailable =
            config_.fuel == FuelType::gasoline
            && ecuCommand.fuelEnabled && ecuCommand.sparkEnabled
            && state_.rpm >= 220.0 && state_.damage < 1.0;
        const auto compressionIgnitionAvailable =
            config_.fuel == FuelType::diesel && ecuCommand.fuelEnabled
            && state_.rpm >= 220.0 && state_.damage < 1.0;
        const auto configuredDieselFullLoadFuelLimitMg =
            compressionIgnitionEngine && ecuCommand.fuelEnabled
            ? fullLoadFuelLimitMg(config_.injection, state_.rpm)
            : std::numeric_limits<double>::infinity();
        const auto dieselFullLoadFuelLimitMg =
            compressionIgnitionEngine && ecuCommand.fuelEnabled
                && ecuCommand.dieselFuelQuantityLimitMgPerCycle > 0.0
                && std::isfinite(ecuCommand.dieselFuelQuantityLimitMgPerCycle)
            ? ecuCommand.dieselFuelQuantityLimitMgPerCycle
            : configuredDieselFullLoadFuelLimitMg;
        const auto cranking = safeControls.starterEngaged && state_.rpm < 620.0 && state_.damage < 1.0;
        const auto displacement = engineDisplacementLitres(config_);
        const auto rotatingInertia =
            effectiveRotatingInertiaKgM2(config_)
            + safeControls.externalRotatingInertiaKgM2;
        const auto fuelMolarMassKg =
            config_.fuelProperties.molarMassGramsPerMole * 0.001;
        double pistonSpeedSum = 0.0;
        double reciprocatingTorque = 0.0;
        double peakPistonAcceleration = 0.0;
        double combustionPulseSum = 0.0;
        double gasIndicatedTorque = 0.0;
        double intakeRunnerPressureSum = 0.0;
        double exhaustRunnerPressureSum = 0.0;
        double pistonFrictionPowerW = 0.0;
        double pistonBreakawayTorqueNm = 0.0;
        double physicalEndGasKnockLevel = 0.0;
        double releasedEnergyJoules = 0.0;
        double meteredFuelMassKg = 0.0;
        double exhaustTemperatureSumK = 0.0;
        std::array<double, 32> exhaustValveAreaM2 {};
        std::array<double, 32> exhaustValveDischargeCoefficient {};
        std::array<double, 32> intakeValveAreaM2 {};
        std::array<double, 32> intakeValveDischargeCoefficient {};
        std::array<double, 32> pistonAreaM2ForSplit {};
        std::array<double, 32> chamberVolumeLitresForWork {};
        std::array<double, 32> chamberPressureBeforeNetworkKpa {};
        std::array<double, 32> gasTorqueLeverArmM {};
        std::array<double, 32> structuralInertiaForceN {};
        std::array<double, 32> structuralSideRatio {};
        std::array<double, 32> instantaneousIntakeTransferredMassKg {};
        std::array<double, 32> exhaustMassFlowKgPerSecond {};
        std::array<double, 32> exhaustAcousticMassFlowKgPerSecond {};
        std::array<double, 32> exhaustPortDensityKgPerM3 {};
        std::array<double, 32> exhaustPortSpeedOfSoundMps {};
        std::array<std::uint8_t, 32> thermoacousticBoundaryValid {};
        std::array<bool, 32> cycleBoundaryForWork {};
        // Phase 0 is firing TDC, so [180, 540) is exhaust stroke + intake
        // stroke: the pumping loop. Captured in the first per-cylinder pass and
        // consumed by the indicated-work split in the second.
        std::array<bool, 32> gasExchangeStrokeForWork {};
        // And [180, 360) alone is the exhaust stroke, which splits the pumping
        // loop into back pressure and intake depression.
        std::array<bool, 32> exhaustStrokeForWork {};
        std::array<bool, 32> intakeCloseForTrappedAir {};
        // Forward intake coupling (EngineSimulatorOptions::intakeForwardCoupling)
        // is decided before the cylinder pass, so that a substep opening a new
        // interval can sample where each chamber and intake valve will be at
        // its end. An interval already under way is always finished.
        const auto forwardIntakeRequestedSeconds = std::clamp(
            options_.intakeCouplingIntervalSeconds.value_or(
                defaultForwardIntakeIntervalSeconds), 0.0, 500.0e-6);
        const auto forwardIntake = jointIntakeManifold()
            && options_.intakeForwardCoupling.value_or(true)
            && (intakeForwardRemainingSubsteps_ > 0
                || forwardIntakeRequestedSeconds > subDt * 1.5);
        const auto forwardIntakeFlush = forwardIntake
            && intakeForwardRemainingSubsteps_ == 0;
        // A whole number of substeps, so the interval is a maximum.
        const auto forwardIntervalSubsteps = std::max<std::size_t>(1,
            static_cast<std::size_t>(std::floor(
                forwardIntakeRequestedSeconds / subDt + 1.0e-9)));
        const auto forwardIntervalSeconds =
            static_cast<double>(forwardIntervalSubsteps) * subDt;
        // The chambers re-size their substeps as the shaft accelerates, so an
        // interval rarely lasts exactly what it was opened for. The network
        // runs to where the chambers will be, from where its own clock is.
        const auto forwardNetworkSeconds = std::max(0.5 * forwardIntervalSeconds,
            forwardIntervalSeconds - intakeForwardClockLeadSeconds_);
        std::array<double, 32> intakeValveAreaAheadM2 {};
        std::array<double, 32> chamberVolumeAheadM3 {};
        std::array<double, 32> secondsToIntakeOpen {};
        std::array<double, 32> secondsToIntakeClose {};

        // Small engines retain Gauss-Seidel shared-volume updates and a shared
        // PRNG sequence; from this cylinder count up, the sub-step switches to a
        // Jacobi snapshot instead.
        //
        // This is purely a PHYSICS choice and is keyed only to cylinder count, so
        // that an engine integrates identically on every machine. The parallel
        // cylinder pass below follows it, never the reverse: changing this
        // threshold changes the shared-volume solver for real, and would move
        // every large engine's calibration.
        const auto decoupleSharedVolumes =
            config_.cylinders.size() >= decoupledSharedVolumeCylinderThreshold;
        // Freeze both shared control volumes at the start of the sub-step so that
        // every cylinder evaluates the same upstream/downstream state.
        // The plenum snapshot keeps every cylinder in the sub-step reading the
        // same upstream state; writes to the plenum happen only in the
        // intake-network advances, so no commit transaction is needed.
        std::optional<ParallelSubstepState> parallelState;
        if (decoupleSharedVolumes) {
            parallelState.emplace();
            for (std::size_t path = 0; path < intakePlenumCount_; ++path)
                parallelState->frozenPlenum[path] = intakePlenumGas_[path];
        }
        const auto accumulateContribution = [&](const CylinderSubstepScratch& contribution) noexcept {
            reciprocatingTorque += contribution.reciprocatingTorque;
            combustionPulseSum += contribution.combustionPulse;
            gasIndicatedTorque += contribution.gasIndicatedTorque;
            intakeRunnerPressureSum += contribution.intakeRunnerPressure;
            exhaustRunnerPressureSum += contribution.exhaustRunnerPressure;
            exhaustTemperatureSumK += contribution.exhaustTemperatureK;
            pistonFrictionPowerW += contribution.pistonFrictionPowerW;
            pistonBreakawayTorqueNm += contribution.pistonBreakawayTorqueNm;
            pistonSpeedSum += contribution.pistonSpeed;
            peakPistonAcceleration = std::max(
                peakPistonAcceleration, contribution.peakPistonAcceleration);
            physicalEndGasKnockLevel = std::max(
                physicalEndGasKnockLevel, contribution.endGasKnockLevel);
            releasedEnergyJoules += contribution.releasedEnergyJoules;
            meteredFuelMassKg += contribution.meteredFuelMassKg;
        };
        // Nothing in the cylinder pass reads these, so applying them after a
        // cylinder (small engines) or after the whole pass, in cylinder order
        // (large engines), gives the same state.
        const auto applyCylinderEvents = [&](const CylinderSubstepScratch& contribution) noexcept {
            state_.commandedSparkEventCount += contribution.commandedSparkEvents;
            if (contribution.misfired) {
                ++state_.misfireEventCount;
                state_.lastMisfireAirFuelRatio = contribution.misfireAirFuelRatio;
                state_.lastMisfireTimeSeconds = state_.simulationTimeSeconds;
            }
            if (contribution.solverResolutionLimited) state_.solverResolutionLimited = true;
        };

        const auto predictedAngularAcceleration = state_.netTorqueNm / rotatingInertia;
        const std::array currentKinematicsKey {
            std::bit_cast<std::uint64_t>(state_.crankAngleDegrees),
            std::bit_cast<std::uint64_t>(state_.angularVelocityRadPerSecond),
            std::bit_cast<std::uint64_t>(predictedAngularAcceleration),
            cylinderGeometryRevision_ };
        const auto reuseCachedKinematics = cachedKinematicsKey.has_value()
            && *cachedKinematicsKey == currentKinematicsKey;
        const auto twoStroke = config_.cycle == EngineCycle::twoStroke;
        const auto cycleDegrees = cylinderCycleDegrees();
        // A stroke (180 deg, 270 of a rotary's shaft) and the cycle the
        // valves (a rotary's ports) wrap in: 720, or 1,080 on a rotary.
        const auto strokeDegrees = strokeDegreesOf(config_.cycle);
        const auto valveCycleDegrees = crankDomainDegreesOf(config_.cycle);
        // A two-stroke below the decoupling threshold runs its pass on the
        // workers without changing a bit (journal 2026-11-20). Each cylinder
        // owns its crankcase (its intake path's plenum), reed fill and runner,
        // and the pass only reads the shared state; what it raises for the
        // engine is summed after it in cylinder order, as the serial loop
        // summed it. The one shared write is the misfire PRNG, drawn at a
        // spark: a sub-step in which two cylinders may spark stays serial,
        // so its draws keep their order. One spark alone cannot race.
        // From the decoupling threshold up each cylinder draws its own PRNG,
        // so the spark condition is not needed there (the pass below).
        auto twoStrokeOwnIntakePaths = twoStroke && intakeWorkerPool_ != nullptr;
        for (std::size_t first = 0; first < config_.cylinders.size() && twoStrokeOwnIntakePaths; ++first)
            for (std::size_t second = first + 1; second < config_.cylinders.size(); ++second)
                if (intakePathIndexByCylinder_[first] == intakePathIndexByCylinder_[second]) {
                    twoStrokeOwnIntakePaths = false;
                    break;
                }
        auto twoStrokeParallelPass = !decoupleSharedVolumes && twoStrokeOwnIntakePaths
            && config_.cylinders.size() >= 2
            && options_.parallelCylinderPass.value_or(true);
        if (twoStrokeParallelPass) {
            // The spark schedule's own arithmetic (below, in the pass), from
            // the same state, with a margin: a superset of the real sparks.
            std::size_t possibleSparks = 0;
            for (std::size_t index = 0; index < config_.cylinders.size(); ++index) {
                const auto phase = std::fmod(state_.crankAngleDegrees
                    - crankOffsetDegreesFor(config_, config_.cylinders[index])
                    + phaseWrapBiasDegrees(cycleDegrees), cycleDegrees);
                const auto previous = previousCylinderPhases_[index];
                if (crossedPhase(previous, phase, cycleDegrees - strokeDegrees, cycleDegrees)) {
                    ++possibleSparks;
                } else if (sparkScheduleArmed_[index]) {
                    const auto travel = forwardPhaseDegrees(previous, phase, cycleDegrees);
                    const auto credited = travel <= cycleDegrees * 0.25 ? travel : 0.0;
                    if (sparkScheduleTravelRemainingDegrees_[index] - credited <= 1.0e-6)
                        ++possibleSparks;
                }
            }
            twoStrokeParallelPass = possibleSparks < 2;
        }
        std::optional<std::array<CylinderSubstepScratch, 32>> twoStrokeScratch;
        if (twoStrokeParallelPass) twoStrokeScratch.emplace();
        const auto processCylinder = [&](std::size_t cylinderIndex) {
            CylinderSubstepScratch serialScratch {};
            auto& contribution = decoupleSharedVolumes
                ? parallelState->scratch[cylinderIndex]
                : twoStrokeParallelPass ? (*twoStrokeScratch)[cylinderIndex] : serialScratch;
            const auto& cylinder = config_.cylinders[cylinderIndex];
            const auto intakePathIndex = intakePathIndexByCylinder_[cylinderIndex];
            const auto crankOffset = crankOffsetDegreesFor(config_, cylinder);
            const auto cyclePhase = std::fmod(state_.crankAngleDegrees - crankOffset
                + phaseWrapBiasDegrees(cycleDegrees), cycleDegrees);
            auto cams = activeCamshaft(
                config_, cylinder, state_.rpm, state_.throttle);
            // VTEC cams, or cams taken off while their high cam still runs:
            // it drops back on a base circle like any other switch.
            const auto switchedProfile = cams.config->variableProfileEnabled
                || valveProfileActuators_[cylinderIndex].appliedHigh();
            if (switchedProfile) {
                auto& actuator = valveProfileActuators_[cylinderIndex];
                actuator.updateDemand(*cams.config, vtecStrategy(*cams.config, ecuCommand), state_.throttle,
                    valveProfileShaftCycle_.completed(), 1);
                cams.highProfile = actuator.appliedHigh();
            }
            const auto previousPhase = previousCylinderPhases_[cylinderIndex];
            const auto cycleBoundaryCrossed = crossedPhase(previousPhase, cyclePhase, 0.0, cycleDegrees);
            if (cycleBoundaryCrossed) {
                commandedSparkEventsLastCycle_[cylinderIndex] =
                    commandedSparkEventsThisCycle_[cylinderIndex];
                completedIgnitionEventsLastCycle_[cylinderIndex] =
                    completedIgnitionEventsThisCycle_[cylinderIndex];
                commandedSparkPhaseLastCycle_[cylinderIndex] =
                    commandedSparkPhaseThisCycle_[cylinderIndex];
                completedIgnitionPhaseLastCycle_[cylinderIndex] =
                    completedIgnitionPhaseThisCycle_[cylinderIndex];
                commandedSparkEventsThisCycle_[cylinderIndex] = 0;
                completedIgnitionEventsThisCycle_[cylinderIndex] = 0;
                commandedSparkPhaseThisCycle_[cylinderIndex] = -1.0;
                completedIgnitionPhaseThisCycle_[cylinderIndex] = -1.0;
                // A schedule deliberately SURVIVES this boundary. It used to be
                // discarded here so a prevented event could not leak into the
                // next cycle, but the cycle boundary is not the end of a spark
                // schedule: a retarded event (negative commanded advance) sits
                // just after it, and discarding it there is what turned a
                // retard into a misfire. The schedule is now a bounded
                // countdown, so it expires inside its own power stroke by
                // construction and cannot reach the next compression stroke.
                if (cylinderFlowCycleStarted_[cylinderIndex]) {
                    intakeFlowMgPerCycle_[cylinderIndex] = std::max(0.0,
                        intakeFlowMgThisCycle_[cylinderIndex]);
                    exhaustFlowMgPerCycle_[cylinderIndex] = std::max(0.0,
                        exhaustFlowMgThisCycle_[cylinderIndex]);
                    // Not clamped: a cylinder that reverts more fresh air than
                    // it draws has a genuinely negative delivery, and hiding
                    // that behind a zero would hide the failure this measures.
                    deliveredAirMgPerCycle_[cylinderIndex] =
                        deliveredAirMgThisCycle_[cylinderIndex];
                } else {
                    cylinderFlowCycleStarted_[cylinderIndex] = true;
                }
                intakeFlowMgThisCycle_[cylinderIndex] = 0.0;
                exhaustFlowMgThisCycle_[cylinderIndex] = 0.0;
                deliveredAirMgThisCycle_[cylinderIndex] = 0.0;
            }
            // A two-stroke's crankcase fill ends when the piston covers the
            // transfers: everything the reed let in since the last closing is
            // the charge the next transfer event draws on, and the pulse that
            // fuels that event is sprayed just after this point.
            if (twoStroke && crossedPhase(previousPhase, cyclePhase,
                    cycleDegrees - config_.twoStroke.transferPortOpenDegrees, cycleDegrees)) {
                reedInflowMgLastFill_[intakePathIndex] = reedInflowMgThisFill_[intakePathIndex];
                reedInflowMgThisFill_[intakePathIndex] = 0.0;
            }
            const auto kinematics = reuseCachedKinematics ? cachedKinematics[cylinderIndex]
                : evaluateCylinderKinematics(config_, kinematicsReference_, cylinderIndex,
                    state_.crankAngleDegrees, state_.angularVelocityRadPerSecond,
                    predictedAngularAcceleration);
            const auto chamberVolume = kinematics.chamberVolumeLitres;
            cylinderGas_[cylinderIndex].setVolumeAdiabatic(chamberVolume);
            valveTrainResults_[cylinderIndex] = ValveTrainModel::evaluate(*cams.config, cams.highProfile,
                valveTrainStates_[cylinderIndex], cyclePhase, state_.rpm, state_.load, subDt,
                valveCycleDegrees);
            if (switchedProfile) {
                const auto previousAppliedHigh = cams.highProfile;
                cams.highProfile = valveProfileActuators_[cylinderIndex].finish(*cams.config,
                    valveTrainStates_[cylinderIndex], cyclePhase,
                    valveProfileShaftCycle_.lastTravelDegrees(), 1, valveCycleDegrees);
                if (cams.highProfile != previousAppliedHigh)
                    valveTrainResults_[cylinderIndex] = ValveTrainModel::evaluate(*cams.config, cams.highProfile,
                        valveTrainStates_[cylinderIndex], cyclePhase, state_.rpm, state_.load, 0.0,
                        valveCycleDegrees);
            }
            // The engine brake's event on one exhaust valve, added to the cam's
            // (they never overlap: it sits at firing top dead centre). The gas
            // solver sees it as any other exhaust lift; the blowdown into the
            // exhaust is the brake's sound.
            const auto engineBraking = static_cast<std::uint32_t>(cylinderIndex)
                < state_.engineBrakeCylinders;
            if (engineBraking) {
                auto& result = valveTrainResults_[cylinderIndex];
                const auto brakeLift = engineBrakeLiftMm(config_.engineBrake, cyclePhase,
                    cylinder.exhaustValveCount);
                if (brakeLift > result.exhaustLiftMm) {
                    result.exhaustLiftMm = brakeLift;
                    result.exhaustDischargeCoefficient = valveFlowCoefficient(brakeLift,
                        cams.config->exhaustFlowCoefficient, cams.config->exhaustFlowCurve);
                }
            }
            const auto& valveTrain = valveTrainResults_[cylinderIndex];
            const auto requestedSparkPhase = std::fmod(cycleDegrees - ecuCommand.ignitionAdvanceDegrees
                + cylinder.ignitionOffsetDegrees + cycleDegrees, cycleDegrees);
            // A real ECU commits a spark event ahead of the target tooth. The
            // former code moved the crossing target at every solver substep;
            // under a loaded acceleration, a small advance change could move
            // that target across the crank between two evaluations, producing
            // no event for the entire cylinder cycle. Latch it at the start of
            // compression (phase 540) and consume it once near firing TDC.
            //
            // The schedule is carried as a REMAINING CRANK DISTANCE, not as an
            // absolute phase to be crossed again. A phase target cannot express
            // a spark that falls after the cycle boundary, and the ECU can
            // legitimately command one: `minimumIgnitionAdvanceDegrees` is
            // -10 deg, which heavy knock retard (`knockLevel * 12`) or an
            // over-temperature pull (`coolant > 108 C`) reaches. Such an event
            // lands at phase [0, 10) -- outside the (540, 720] arc the latch
            // covers -- and the boundary reset below then discarded it, turning
            // a retarded spark into a complete misfire. A countdown has no arc.
            //
            // It also cannot leak into the following cycle, which is what the
            // boundary reset existed to prevent: the reachable distance is
            // bounded by the validated ranges (advance [-10, 55], per-cylinder
            // ignition offset [-30, 30]) to [95, 220] deg, and the clamp below
            // keeps even a malformed configuration inside the same power
            // stroke.
            const auto sparkScheduleMaximumTravelDegrees = strokeDegrees + 80.0;
            // A two-stroke latches at bottom dead centre (180), the start of
            // its compression stroke.
            if (crossedPhase(previousPhase, cyclePhase, cycleDegrees - strokeDegrees, cycleDegrees)) {
                scheduledSparkPhaseDegrees_[cylinderIndex] =
                    requestedSparkPhase;
                // Measured from the CURRENT phase, not from 540: the crank has
                // already moved past 540 inside this substep, and counting from
                // the trigger angle would spend that travel twice.
                sparkScheduleTravelRemainingDegrees_[cylinderIndex] =
                    std::clamp(std::fmod(requestedSparkPhase - cyclePhase
                            + cycleDegrees, cycleDegrees),
                        0.0, sparkScheduleMaximumTravelDegrees);
                sparkScheduleArmed_[cylinderIndex] = true;
                dieselInjectionStarted_[cylinderIndex] = false;
            } else if (sparkScheduleArmed_[cylinderIndex]) {
                // `forwardPhaseDegrees` wraps, so a momentarily REVERSING crank
                // -- start kickback is real here -- reports ~720 deg of forward
                // travel for a small backward step. A crossing test shrugs that
                // off; an accumulator would not, and would fire the schedule at
                // once. One substep can never legitimately advance half a
                // cycle, so anything that large is the wrap artefact.
                const auto maximumCreditedSubstepTravelDegrees = cycleDegrees * 0.25;
                const auto travel =
                    forwardPhaseDegrees(previousPhase, cyclePhase, cycleDegrees);
                if (travel <= maximumCreditedSubstepTravelDegrees)
                    sparkScheduleTravelRemainingDegrees_[cylinderIndex] -=
                        travel;
            }
            const auto sparkPhase =
                scheduledSparkPhaseDegrees_[cylinderIndex];
            const auto sparkCrossed = sparkScheduleArmed_[cylinderIndex]
                && sparkScheduleTravelRemainingDegrees_[cylinderIndex] <= 0.0;
            // A diesel has no spark: its ECU advance is the start of
            // injection, and the spark schedule is the crank event that opens
            // the injector. The part's window still bounds it, so an advance
            // earlier than the window's start injects from that start.
            if (compressionIgnitionEngine && sparkCrossed)
                dieselInjectionStarted_[cylinderIndex] = true;
            const auto injectionStartCrossed = crossedPhase(previousPhase, cyclePhase,
                config_.injection.startAngleDegrees, cycleDegrees);
            if (injectionStartCrossed) {
                if (portInjectedGasoline
                        && portFuelResumePending_[cylinderIndex]
                        && !portFuelResumePrepared_[cylinderIndex]) {
                    if (portFuelResumePurgeCycleSeen_[cylinderIndex]) {
                        portFuelResumePrepared_[cylinderIndex] = true;
                    } else {
                        // Reopening the throttle entrains vapour left in the
                        // runner by the evaporating wall film. An immediate new
                        // pulse burns that retained inventory and the fresh
                        // request together; several catalogue engines entered
                        // their first cycle at AFR 4-9. Let one real intake cycle
                        // purge the conservative inventory, then arm a complete
                        // crank-synchronised pulse at the following edge.
                        portFuelResumePurgeCycleSeen_[cylinderIndex] = true;
                    }
                }
                if (compressionIgnitionEngine) {
                    combustionCycleMultiplier_[cylinderIndex] =
                        CombustionCycleVariation::advance(
                            config_.combustionCalibration
                                .cycleVariationCoefficientOfVariation,
                            config_.combustionCalibration
                                .cycleVariationCorrelation,
                            combustionVariationRandomState_[cylinderIndex],
                            combustionVariationNormalisedState_[cylinderIndex]);
                    meteredFuelMolesLastCycle_[cylinderIndex] =
                        injectedFuelMolesThisCycle_[cylinderIndex];
                    deliveredFuelMolesLastCycle_[cylinderIndex] =
                        entrainedFuelMolesThisCycle_[cylinderIndex];
                    injectorCapacityRatio_[cylinderIndex] =
                        1.0 - injectorWindowUtilisation(cylinderIndex);
                    injectorDutyCycle_[cylinderIndex] =
                        injectorDutyCycle(cylinderIndex);
                    CompressionIgnitionModel::beginCycle(
                        compressionIgnitionStates_[cylinderIndex]);
                    compressionIgnitionResults_[cylinderIndex] = {};
                    cylinderMisfires_[cylinderIndex] = false;
                }
                // A dual clutch's injection cut, spread over the firings as
                // an error-diffusion sequence: this pulse is the K-th of the
                // engine (K = cylinders x the cylinder's count + its place in
                // the firing order) and is cut when the running share of
                // cut pulses passes the requested fraction there. Each
                // cylinder carries its own count, so the cylinder pass may
                // run in parallel.
                {
                    const auto& order = config_.firingOrder;
                    const auto found = std::find(order.begin(), order.end(),
                        config_.cylinders[cylinderIndex].id);
                    const auto firings = static_cast<std::uint64_t>(
                        std::max<std::size_t>(1, order.empty()
                            ? config_.cylinders.size() : order.size()));
                    const auto place = static_cast<std::uint64_t>(found != order.end()
                        ? std::distance(order.begin(), found)
                        : static_cast<std::ptrdiff_t>(cylinderIndex));
                    const auto pulse = firings * injectionStartCount_[cylinderIndex] + place;
                    const auto fraction = std::clamp(ecuCommand.cylinderCutFraction, 0.0, 1.0);
                    injectionCutThisCycle_[cylinderIndex] = fraction > 0.0
                        && std::floor(static_cast<double>(pulse + 1U) * fraction)
                            > std::floor(static_cast<double>(pulse) * fraction);
                    // Anti-lag's ignition cut: its charge is injected and
                    // leaves unlit. Each cylinder cuts its own share of its
                    // own cycles (the error diffusion on its cycle count),
                    // the cylinders staggered by golden-ratio phases. The
                    // sequence above over the engine's firings locks a fixed
                    // set of cylinders when its period shares a factor with
                    // the cylinder count: at 90 % a 2JZ lit only cylinders 1,
                    // 3 and 2, an I5 only cylinder 1 (journal 2026-11-14).
                    constexpr double goldenRatioConjugate = 0.6180339887498949;
                    const auto sparkFraction = std::clamp(ecuCommand.sparkCutFraction, 0.0, 1.0);
                    const auto ownCycle = static_cast<double>(injectionStartCount_[cylinderIndex]);
                    const auto stagger = std::fmod(static_cast<double>(place) * goldenRatioConjugate, 1.0);
                    sparkCutThisCycle_[cylinderIndex] = sparkFraction > 0.0
                        && std::floor((ownCycle + 1.0) * sparkFraction + stagger)
                            > std::floor(ownCycle * sparkFraction + stagger);
                    ++injectionStartCount_[cylinderIndex];
                }
                injectedFuelMolesThisCycle_[cylinderIndex] = 0.0;
                entrainedFuelMolesThisCycle_[cylinderIndex] = 0.0;
                requestedFuelMolesThisCycle_[cylinderIndex] = 0.0;
                portPulseCreditSampled_[cylinderIndex] = false;
                commandedFuelMolesMaxThisCycle_[cylinderIndex] = 0.0;
                injectorOpenSubsteps_[cylinderIndex] = 0.0;
                injectorWindowSubsteps_[cylinderIndex] = 0.0;
            }
            const auto cylinderSparkCombustionAvailable =
                sparkCombustionAvailable
                && (!portInjectedGasoline
                    || !portFuelResumePending_[cylinderIndex]
                    || portFuelResumePrepared_[cylinderIndex]);
            combustionCommandAvailable_[cylinderIndex] =
                compressionIgnitionEngine
                ? compressionIgnitionAvailable
                : cylinderSparkCombustionAvailable;
            const auto oxygenEquivalentAirMassMg = cylinderGas_[cylinderIndex].mixture().oxygenMoles
                / 0.21 * GasCell::airMolarMassKg * 1.0e6;
            const auto& chargeSource = decoupleSharedVolumes
                ? parallelState->frozenPlenum[intakePathIndex]
                : intakePlenumGas_[intakePathIndex];
            const auto chargeSourcePressureKpa = chargeSource.pressureKpa();
            const auto chargeSourceTemperatureK = chargeSource.temperatureK();
            // A two-stroke is fuelled as a carburettor does: for the air that
            // crossed it, here the crankcase's last fill through the reed. Its
            // trapped oxygen is no reference: at idle ~85 % of the trapped
            // charge is retained from cycle to cycle, unburned oxygen and fuel
            // alike, and counting that oxygen as new air fuelled the RD350 for
            // 60 mg against 9 mg delivered (AFR 3.7, half its cycles
            // misfiring). Nor is its crankcase density, which swings within
            // every cycle. The air across the transfers was the reference
            // before: steady, it equals the fill, but on a tip-in the fill
            // leads it by an event (RD350 from idle, mg per event: fill 81,
            // 328, 287; transfers 18, 127, 192), and the pulse it sized was
            // for the event before last. Five lean misfires stalled the
            // launch from a settled idle at 100 mm cells (journal 2026-10-16).
            // Anti-lag cuts up to 90 % of the sparks with the fuel kept, so
            // the charge a cylinder retains is mostly an unlit one, its fuel
            // with it. The trapped oxygen counted that retained air as new:
            // the 2JZ's lift trapped 720 mg for 560 delivered and its fresh
            // charge ran at AFR 10.4 for 13.2 asked (journal 2026-11-14). It
            // is fuelled as a speed-density ECU fuels, for the air its
            // valve delivered, as a two-stroke is above.
            const auto antiLagFreshAirReference = !twoStroke && ecuCommand.antiLagActive
                && deliveredAirMgPerCycle_[cylinderIndex] > 0.0;
            const TrappedChargeReference chargeReference = twoStroke
                ? TrappedChargeReference {
                    std::max(0.0, reedInflowMgLastFill_[intakePathIndex]),
                    chargeSourcePressureKpa, chargeSourceTemperatureK }
                : TrappedChargeReference {
                    antiLagFreshAirReference ? deliveredAirMgPerCycle_[cylinderIndex]
                        : trappedAirMassMgLastCycle_[cylinderIndex],
                    trappedAirSourcePressureKpaLastCycle_[cylinderIndex],
                    trappedAirSourceTemperatureKLastCycle_[cylinderIndex] };
            const auto instantaneousPredictedPortChargeMassMg =
                TransientChargeEstimator::estimateFreshAirMassMg(
                0.0, chargeReference, chargeSourcePressureKpa, chargeSourceTemperatureK);
            if (injectionStartCrossed) {
                // Sample the speed-density prediction once per sequential
                // pulse. Re-evaluating it every solver substep and keeping the
                // maximum turned an intake acoustic crest into extra fuel for
                // the whole cycle (measured as an isolated AFR-9.51 EJ25
                // misfire with ample injector headroom). The chamber's resolved
                // oxygen remains a live lower bound below, so real late filling
                // and DFCO recovery are not discarded.
                predictedPortChargeMassMgThisCycle_[cylinderIndex] =
                    instantaneousPredictedPortChargeMassMg;
            }
            const auto dfcoResumeChargeTransientActive =
                portFuelResumePending_[cylinderIndex]
                || portFuelResumePrepared_[cylinderIndex]
                || (portFuelResumeOpenLoopSecondsRemaining_[cylinderIndex] > 0.0
                    // Source density is genuinely non-stationary immediately
                    // after the throttle reopens, but that is a much shorter
                    // phenomenon than the wall-film settling epoch. Coupling
                    // the two kept the live peak detector active for two full
                    // seconds: on the CP4 a late runner-pressure crest at
                    // 6,040 rpm commanded 29.15 mg instead of roughly 23 mg,
                    // delivered 26.48 mg for 269 mg of air and produced an
                    // AFR-9.90 rich misfire. 0.35 s still covers more than 17
                    // complete cycles at the lowest tested resume speed; after
                    // that, retain the high-speed start-edge sample while the
                    // independent footprint controller continues settling.
                    && portFuelResumeEpochAgeSeconds_[cylinderIndex] < 0.35);
            const auto highSpeedAcousticSamplingPosition = std::clamp(
                (state_.rpm - 3'600.0) / 800.0, 0.0, 1.0);
            const auto highSpeedAcousticSamplingBlend =
                highSpeedAcousticSamplingPosition
                * highSpeedAcousticSamplingPosition
                * (3.0 - 2.0 * highSpeedAcousticSamplingPosition);
            // The resolved-oxygen floor stands for a charge RETAINED in a
            // closed chamber (a lean or misfired cycle). With a valve open the
            // chamber is exchanging gas and its oxygen does not belong to the
            // next trapped charge, yet the request is a maximum over the
            // cycle. The floor locked onto the exhaust stroke, where gas
            // flowing back from the exhaust raised the chamber above the
            // trapped charge: at idle the CP2 requested for 71-72 mg against
            // 52-55 mg trapped, the Merlin for 580-594 against ~306, and both
            // sat on the 0.55 trim stop. With a valve open the density-scaled
            // trapped reference owns the request, as in a speed-density ECU;
            // before any trapped reference exists (cranking) the resolved
            // chamber remains the only estimate.
            // A two-stroke's closed chamber holds its retained charge: once a
            // delivered reference exists, its oxygen is never a floor.
            const auto resolvedChargeFloorMg =
                (twoStroke || antiLagFreshAirReference || valveTrain.intakeLiftMm > 0.01
                    || valveTrain.exhaustLiftMm > 0.01)
                    && chargeReference.freshAirMassMg > 0.0
                ? 0.0 : oxygenEquivalentAirMassMg;
            const auto livePredictedPortChargeMassMg =
                TransientChargeEstimator::estimateFreshAirMassMg(
                    resolvedChargeFloorMg, chargeReference,
                    chargeSourcePressureKpa, chargeSourceTemperatureK);
            const auto sampledPredictedPortChargeMassMg = std::max(
                resolvedChargeFloorMg,
                predictedPortChargeMassMgThisCycle_[cylinderIndex]);
            const auto predictedPortChargeMassMg =
                dfcoResumeChargeTransientActive
                // Unlike steady running, the source density is genuinely
                // moving quickly after a closed-throttle fuel cut. Keep the
                // live speed-density prediction during this explicit bounded
                // transient; the footprint balance and resume trim own its
                // convergence. Freezing it made the 2JZ resume 24.1 % off
                // target, while the same engine had passed with the live
                // density signal.
                ? livePredictedPortChargeMassMg
                // At low speed the 350-degree injection window lasts long
                // enough for the source-density change inside it to be a real
                // throttle transient. Sampling it once made the Merlin's
                // 0.5-second blip wet the port incorrectly, then relight from
                // DFCO into an AFR-5 rich stall. Above roughly 4,400 rpm the
                // same within-window signal is dominated by resolved intake
                // acoustics; there the start-edge sample prevents the measured
                // EJ25 AFR-9.51 false enrichment. Blend across the overlap so
                // neither pulse width nor torque acquires a regime step.
                : std::lerp(livePredictedPortChargeMassMg,
                    sampledPredictedPortChargeMassMg,
                    highSpeedAcousticSamplingBlend);
            const auto measuredChargeMassMg = config_.injection.mode == InjectionMode::direct
                    && !antiLagFreshAirReference
                ? oxygenEquivalentAirMassMg
                : predictedPortChargeMassMg;
            // Fuel adaptation belongs to an operating region, not to an entire
            // cylinder. Blend two learned cells using the smoothed physical
            // throttle so the command remains continuous through a tip-in/out.
            // The high-load cell starts from the authored map (unity), not from
            // the learned idle cell. Copying the idle trim at the first pedal
            // opening carried a 0.55 idle correction directly into WOT: the
            // Hayabusa trace went from AFR 13 at idle to AFR 30 during a blip and
            // stalled. The smoothed throttle blend below already provides a
            // continuous hand-off while the independent high-load cell learns.
            const auto highLoadTrimBlend = std::clamp(
                (state_.throttle - 0.10) / 0.15, 0.0, 1.0);
            const auto activeClosedLoopFuelTrim = std::lerp(
                closedLoopFuelTrim_[cylinderIndex],
                highLoadClosedLoopFuelTrim_[cylinderIndex],
                highLoadTrimBlend);
            // A learned trim is valid only in the observable steady region in
            // which it was identified. During the explicit DFCO resume epoch,
            // use the authored physical AFR map while the conservative footprint
            // balance below refills the dry valve-side inventory. The charge
            // reference is now frozen throughout the unobservable cut/resume
            // interval, so unity here no longer amplifies repeatedly-counted
            // residual oxygen on low-overlap engines.
            const auto appliedClosedLoopFuelTrim =
                portFuelResumeOpenLoopSecondsRemaining_[cylinderIndex] > 0.0
                ? portFuelResumeFuelTrim_[cylinderIndex]
                : activeClosedLoopFuelTrim;
            const auto dieselFuelDemand = compressionIgnitionEngine
                ? std::clamp(std::max(state_.throttle,
                    ecuCommand.idleAirOpening * 0.20), 0.0, 1.0)
                : 1.0;
            const auto targetAirFuelRatio = compressionIgnitionEngine
                ? std::max(config_.fuelProperties.stoichiometricAirFuelRatio
                        * 1.16,
                    ecuCommand.targetAirFuelRatio)
                : std::clamp(ecuCommand.targetAirFuelRatio,
                    5.0 * petrolAfrBoundScale(config_), 30.0 * petrolAfrBoundScale(config_));
            // A braking cylinder takes no fuel: its compression is the brake.
            const auto cylinderFuelEnabled = ecuCommand.fuelEnabled
                && !injectionCutThisCycle_[cylinderIndex] && !engineBraking;
            // The charge figure counts oxygen; the ECU's air reading (MAP or
            // MAF) never sees the kit's. A two-stroke's reed figure is the
            // air through its throttle already. A dry kit has the ECU add the
            // kit's fuel for its oxygen.
            const auto nitrousShare = twoStroke && config_.injection.mode != InjectionMode::direct
                ? 0.0 : nitrousOxygenShare_;
            const auto ecuChargeMassMg = nitrousShare > 0.0
                ? measuredChargeMassMg * (1.0 - nitrousShare) : measuredChargeMassMg;
            const auto dryKitFuelMoles = cylinderFuelEnabled && nitrousOxygenShare_ > 0.0
                    && config_.nitrous.type == NitrousKitType::dry
                ? measuredChargeMassMg * nitrousOxygenShare_
                    / (config_.fuelProperties.stoichiometricAirFuelRatio * config_.nitrous.kitLambda)
                    * 1.0e-6 / fuelMolarMassKg
                : 0.0;
            auto physicalFuelTargetMoles = cylinderFuelEnabled
                ? ecuChargeMassMg / targetAirFuelRatio
                    * dieselFuelDemand
                    * ecuCommand.fuelCorrection
                    * (compressionIgnitionEngine
                        ? 1.0 : appliedClosedLoopFuelTrim)
                    * 1.0e-6 / fuelMolarMassKg
                : 0.0;
            if (compressionIgnitionEngine && ecuCommand.fuelEnabled) {
                // The AFR map is a rich-side smoke boundary. Transient fuel
                // correction and the quantity map may request less fuel, never
                // more than this oxygen-derived ceiling.
                const auto smokeLimitMoles = ecuChargeMassMg
                    / targetAirFuelRatio * 1.0e-6 / fuelMolarMassKg;
                const auto quantityLimitMoles =
                    dieselFullLoadFuelLimitMg
                    * dieselFuelDemand * 1.0e-6 / fuelMolarMassKg;
                const auto fuelCeilingMoles = std::min(smokeLimitMoles, quantityLimitMoles);
                dieselFuelLimitBits_[cylinderIndex] = physicalFuelTargetMoles < fuelCeilingMoles ? 0U
                    : static_cast<std::uint32_t>(smokeLimitMoles <= quantityLimitMoles
                        ? ActiveLimit::dieselSmokeLimit : ActiveLimit::dieselQuantityLimit);
                physicalFuelTargetMoles = std::min(physicalFuelTargetMoles, fuelCeilingMoles);
            }
            if (dryKitFuelMoles > 0.0) physicalFuelTargetMoles += dryKitFuelMoles;
            requestedFuelMolesThisCycle_[cylinderIndex] = std::max(
                requestedFuelMolesThisCycle_[cylinderIndex], physicalFuelTargetMoles);
            const auto requestedFuelMoles = requestedFuelMolesThisCycle_[cylinderIndex];
            const auto crankDegreesToSpark = std::fmod(
                sparkPhase - cyclePhase + cycleDegrees, cycleDegrees);
            const auto secondsToSpark = state_.rpm > 20.0
                ? crankDegreesToSpark / (state_.rpm * 6.0) : 0.25;
            // Port injection sprays at the valve, which is now the inlet cell
            // of the 1-D runner duct. FuelInjectionModel keeps its GasCell
            // interface, so it meters against a scratch cell synchronised to
            // the port state (it only reads pressure and temperature from the
            // target); the vaporised fuel and its charge cooling are then
            // deposited into the duct cell as a conservative species source.
            const auto portInjection = config_.injection.mode == InjectionMode::port;
            GasCell portInjectionScratch;
            auto portFuelPrimeDeficitMoles = 0.0;
            portInjectorFootprintFuelMoles_[cylinderIndex] = 0.0;
            portInjectorFootprintTargetFuelMoles_[cylinderIndex] = 0.0;
            if (portInjection) {
                const auto& runnerDuct = intakeDuctForCylinder(cylinderIndex);
                const auto portPrimitives = runnerDuct.cellPrimitives();
                const auto portPressureKpa = portPrimitives.empty()
                    ? intakeRunnerPressureKpa_[cylinderIndex]
                    : portPrimitives.front().pressurePa * 0.001;
                const auto portTemperatureK = portPrimitives.empty()
                    ? intakePortTemperatureK_[cylinderIndex]
                    : portPrimitives.front().temperatureK;
                portInjectionScratch.initialise(portPressureKpa, 0.1, portTemperatureK);
                const auto fuelSpecies = static_cast<std::size_t>(
                    gasdynamics::GasSpecies::fuel);
                {
                    // A port pulse has two conservative jobs: fuel the imminent
                    // trapped charge and cover any CURRENT deficit in the
                    // valve-side spray/film footprint to the commanded mixture
                    // concentration. The old deficit treated newly accumulated
                    // vapour only as fuel available to the chamber, so filling a
                    // dry runner stole that mass from the first post-DFCO charge.
                    // Adding the full target on every cycle was measured and
                    // rejected because it did not fall as the footprint filled.
                    // Priming the entire runner was likewise
                    // rejected: upstream air has not crossed the injector yet
                    // and doing so made all three turbos severely rich. Match
                    // injectSpeciesAtPort's physical 60 mm footprint and derive
                    // its target from resolved oxygen mass. This target remains
                    // in the balance: it cancels naturally against the existing
                    // inventory once filled instead of disappearing at a timer
                    // boundary. No calibrated per-engine scalar is involved.
                    const auto oxygenSpecies = static_cast<std::size_t>(
                        gasdynamics::GasSpecies::oxygen);
                    constexpr double sprayAndFilmFootprintM = 0.060;
                    const auto portCells = runnerDuct.cells();
                    const auto footprintCells = std::min<std::size_t>(
                        3, std::min(portCells.size(), std::max<std::size_t>(1,
                            static_cast<std::size_t>(std::ceil(
                                sprayAndFilmFootprintM
                                    / runnerDuct.geometry().cellLengthM())))));
                    auto footprintOxygenMassKg = 0.0;
                    auto footprintFuelMassKg = 0.0;
                    for (std::size_t cell = 0; cell < footprintCells; ++cell) {
                        // injectSpeciesAtPort conservatively deposits into
                        // complete finite-volume cells. A realtime 95 mm cell
                        // cannot represent a 60 mm sub-cell source, so the
                        // concentration target must use that same complete
                        // numerical support. Applying a fractional 60/95
                        // overlap here compared the injected inventory with a
                        // smaller oxygen inventory and under-primed every
                        // coarse-mesh post-DFCO pulse.
                        footprintOxygenMassKg += portCells[cell]
                            .speciesMassDensityKgPerM3[oxygenSpecies]
                            * runnerDuct.geometry().cellVolumeM3(cell);
                        footprintFuelMassKg += portCells[cell]
                            .speciesMassDensityKgPerM3[fuelSpecies]
                            * runnerDuct.geometry().cellVolumeM3(cell);
                    }
                    const auto footprintOxygenMoles = footprintOxygenMassKg
                        / GasCell::oxygenMolarMassKg;
                    const auto footprintFreshAirMassKg = footprintOxygenMoles
                        / 0.21 * GasCell::airMolarMassKg;
                    const auto targetInventoryMoles = cylinderFuelEnabled
                        ? footprintFreshAirMassKg / targetAirFuelRatio
                            / fuelMolarMassKg
                        : 0.0;
                    portInjectorFootprintFuelMoles_[cylinderIndex] =
                        footprintFuelMassKg / fuelMolarMassKg;
                    portInjectorFootprintTargetFuelMoles_[cylinderIndex] =
                        targetInventoryMoles;
                    // Re-prime the runner only for the bounded DFCO-resume
                    // transport epoch. Applying the same inventory deficit at
                    // every port-injected start and throttle transient double-
                    // counted a deliberately dry runner: large engines flooded
                    // during cranking and several small engines stalled after a
                    // throttle blip. Outside an observed fuel-cut resume the
                    // ordinary pulse/film inventory model remains authoritative.
                    const auto dfcoResumeTransportActive =
                        portFuelResumePending_[cylinderIndex]
                        || portFuelResumePrepared_[cylinderIndex]
                        || (portFuelResumeOpenLoopSecondsRemaining_[cylinderIndex]
                                > 0.0
                            && portFuelResumeEpochAgeSeconds_[cylinderIndex]
                                < 2.0);
                    const auto resumeSettlingSeconds = 4.0 * std::max(
                        1.0e-4,
                        config_.injection.vaporisationTimeConstantSeconds);
                    const auto footprintFuelMoles =
                        footprintFuelMassKg / fuelMolarMassKg;
                    const auto footprintDeficitMoles = std::max(
                        0.0, targetInventoryMoles - footprintFuelMoles);
                    // Debounce convergence in physical state: every footprint
                    // observation more than five percent dry restarts a four-
                    // X-tau settling interval. This kept the 2JZ/EJ25 refill
                    // correction alive while boost was still raising the target,
                    // instead of switching it off into a delayed lean hole.
                    if (dfcoResumeTransportActive
                            && targetInventoryMoles > 1.0e-15
                            && footprintDeficitMoles
                                > targetInventoryMoles * 0.05) {
                        portFuelResumeOpenLoopSecondsRemaining_[cylinderIndex] =
                            std::max(
                                portFuelResumeOpenLoopSecondsRemaining_[cylinderIndex],
                                resumeSettlingSeconds);
                    }
                    // Signed during the resume epoch: a footprint wetter than
                    // the target is fuel the next charge sweeps in, so it comes
                    // off the pulse as a dry one adds to it. With a measured
                    // film time constant (Curtis et al., SAE 961186: ~0.6 s
                    // warm) the film keeps evaporating through the cut, and the
                    // I5's first charges took 51-53 mg for a 28-34 mg request
                    // while a footprint held 35 mg against a 10 mg target.
                    // Measured: I5 resume rich peak 36.1 -> 34.5 %, EJ25 17.0
                    // -> 15.5, CP3 15.5 -> 13.6. Counting the surplus over the
                    // charge's swept volume of runner instead moved nothing
                    // (I5 35.4 %), and no prime at all left the I5 at 35.2 %
                    // and the CP4 38.5 % lean (journal 2026-11-15).
                    portFuelPrimeDeficitMoles =
                        dfcoResumeTransportActive && cylinderFuelEnabled
                        ? targetInventoryMoles - footprintFuelMoles : 0.0;
                }
            }
            auto& injectionTarget = portInjection
                ? portInjectionScratch : cylinderGas_[cylinderIndex];
            double commandedFuelMoles = 0.0;
            // An injector fires on crank-synchronised pulses; a stopped crank
            // freezes the cycle phase, and if it freezes INSIDE the injection
            // window the phase test alone models a stuck-open injector
            // dribbling into a dead engine. Measured on the zero-lift Core
            // case: the dribble's vapour and charge cooling kept the resolved
            // runner ringing against the plenum at 0 rpm (port temperature
            // swinging 14-39 degC), holding the manifold off ambient. No crank
            // signal, no pulse.
            // Preserve the established combustion gate except for the one
            // deliberate wet strategies: authored spark-cut overrun or the
            // opt-in wet limiter. Treating every fuel-enabled/spark-disabled
            // cycle as injectable also wets ordinary cranking cuts; the
            // large-inertia Big Twin then floods before the dyno start can
            // catch. Explicit ECU bits keep both audio strategies physical
            // without changing start behaviour elsewhere.
            const auto insideInjectionWindow = phaseInsideWindow(cyclePhase,
                config_.injection.startAngleDegrees,
                config_.injection.endAngleDegrees);
            if ((combustion.combustionEnabled
                    || ecuCommand.overrunAfterfireActive
                    || ecuCommand.wetSparkCutActive)
                && state_.rpm > 20.0
                // A DFCO resume that lands midway through an angular window
                // must wait for the next injector-start edge. Otherwise some
                // cylinders receive an arbitrary partial pulse while others
                // receive a complete one, making the first valid engine AFR a
                // firing-order artefact. The observation epoch already waits
                // for this same `prepared` edge above.
                && (!portInjection
                    || !portFuelResumePending_[cylinderIndex]
                    || portFuelResumePrepared_[cylinderIndex])
                && (!compressionIgnitionEngine
                    || dieselInjectionStarted_[cylinderIndex])
                && insideInjectionWindow) {
                // Meter to the requested physical inventory, accounting for
                // vapour already present and port-wall film. Counting only the
                // current-cycle injector pulse over-fuels residual-rich cells.
                // Meter against the complete fuel inventory that can reach the
                // next trapped charge.  Port injection previously ignored fuel
                // already resident in the cylinder, so every incomplete cycle
                // added another full pulse and progressively flooded large or
                // slow-running engines.
                // Fuel in a closed cylinder belongs to the charge that is
                // currently being compressed or burned; it cannot satisfy the
                // following port-injection request. It becomes part of the
                // reachable inventory only while the intake valve actually
                // connects the chamber and runner (including reversion) — OR
                // when the last cycle MISFIRED. A misfired chamber keeps its
                // unburned air and its unburned fuel together, and the charge
                // estimator's resolved-oxygen floor deliberately counts that
                // retained air into the next request (it is a real anti-stall
                // enrichment after a lean cycle — see TransientChargeEstimator).
                // Counting the air while hiding the fuel is the asymmetry that
                // flooded the V12 at idle catch into an AFR-3 misfire lock-in;
                // after a misfire the chamber fuel must count symmetrically.
                // Symmetrically also means NOT while the exhaust valve is
                // open: the floor ignores that oxygen because the charge is
                // being expelled, and its fuel is leaving with it. A pulse
                // sized once per cycle, in the exhaust stroke, that credited
                // a misfired charge on its way out starved the next one; the
                // CP2 blip went AFR 29-33, misfired every cycle and stalled.
                const auto trappedCylinderFuel = portInjection
                    && (valveTrain.intakeLiftMm > 0.01
                        || ((cylinderMisfires_[cylinderIndex]
                                || portFuelResumePending_[cylinderIndex]
                                || portFuelResumePrepared_[cylinderIndex])
                            && !(valveTrain.exhaustLiftMm > 0.01)))
                    ? cylinderGas_[cylinderIndex].mixture().fuelMoles : 0.0;
                const auto filmTemperatureFactor = std::clamp(
                    (injectionTarget.temperatureK() - 240.0) / 120.0, 0.08, 2.0);
                const auto filmAvailableFraction = 1.0 - std::exp(-secondsToSpark
                    * filmTemperatureFactor
                    / std::max(1.0e-4, config_.injection.vaporisationTimeConstantSeconds));
                if (compressionIgnitionEngine) {
                    // Diesel injection is a metered mass per cycle. Fuel which
                    // starts burning while the pulse is still open must not be
                    // replaced, otherwise combustion rate feeds back into
                    // injected quantity and creates fuel from controller logic.
                    commandedFuelMoles = std::max(0.0,
                        requestedFuelMoles
                            - injectedFuelMolesThisCycle_[cylinderIndex]);
                } else {
                    if (portInjection) {
                        // `requestedFuelMoles` is the fuel required in the
                        // trapped charge, while the injector meters liquid.
                        // A fresh port-injection pulse is not fully available:
                        // (1-X) vaporises immediately and only the fraction
                        // below of X can leave the wall film before spark.
                        //
                        // The old code commanded the charge deficit itself.
                        // After DFCO had emptied the film this guaranteed a
                        // lean first cycle by exactly the unavailable wetting
                        // fraction. Steady closed-loop trim could hide it, but
                        // no feedback controller can repair that first pulse.
                        const auto wallFilmFraction = std::clamp(
                            config_.injection.wallFilmFraction, 0.0, 0.98);
                        const auto newPulseAvailableFraction = std::max(
                            0.02, (1.0 - wallFilmFraction)
                                + wallFilmFraction * filmAvailableFraction);
                        // A sequential port pulse is sized once per cycle:
                        // credit, prime deficit and availability are sampled
                        // at the first metering substep, then the remainder of
                        // that pulse is delivered. Re-reading the live
                        // inventory every substep of a 370-degree window was a
                        // one-way ratchet: vapour pushed upstream by reversion,
                        // or leaving the count at intake-valve closure, was
                        // re-injected and then came back in the charge.
                        // Measured on the CP2 at idle: the pulse sized at
                        // window start was 0.5-1.5 mg, the injector metered
                        // 6.3-7.4 mg for a 3.7 mg request, and the idle ran
                        // AFR 10.3 with the lambda trim on its 0.55 stop.
                        //
                        // Only the wall film (the X-tau compensation of a real
                        // ECU) and a misfired chamber are credited. Runner
                        // vapour is fuel in transit: in steady state each
                        // cycle's pulse replaces what the charge takes, so
                        // crediting the standing vapour under-fuelled every
                        // engine (delivered/requested 0.47-0.77, trims up to
                        // 1.41). The request itself may still rise inside the
                        // window (tip-in), so it is not frozen.
                        if (!portPulseCreditSampled_[cylinderIndex]) {
                            portPulseCreditSampled_[cylinderIndex] = true;
                            portPulseInventoryCreditMoles_[cylinderIndex] =
                                injectionStates_[cylinderIndex].liquidFilmMoles
                                    * filmAvailableFraction
                                + trappedCylinderFuel;
                            portPulsePrimeDeficitMoles_[cylinderIndex] =
                                portFuelPrimeDeficitMoles;
                            portPulseAvailableFraction_[cylinderIndex] =
                                newPulseAvailableFraction;
                        }
                        const auto pulseMoles = std::max(
                            0.0, requestedFuelMoles
                                + portPulsePrimeDeficitMoles_[cylinderIndex]
                                - portPulseInventoryCreditMoles_[cylinderIndex])
                            / portPulseAvailableFraction_[cylinderIndex];
                        commandedFuelMoles = std::max(0.0, pulseMoles
                            - injectedFuelMolesThisCycle_[cylinderIndex]);
                    } else {
                        // A direct pulse is not instantaneously homogeneous.
                        // Liquid droplets and the dispersing vapour cloud are
                        // already metered physical fuel, just not yet present
                        // in GasCell::mixture(). Ignoring them requested the
                        // same deficit again on every solver substep.
                        const auto existingFuelInventory =
                            FuelInjectionModel::representedDirectFuelMoles(
                                injectionStates_[cylinderIndex], injectionTarget);
                        const auto fuelInventoryDeficit = std::max(
                            0.0, requestedFuelMoles - existingFuelInventory);
                        commandedFuelMoles = fuelInventoryDeficit;
                    }
                }
            }
            // The largest single-substep command is the whole new pulse the
            // injector must place before the window closes; delivery is metered
            // per substep at the injector's flow limit, so a healthy injector
            // reaches it and a saturated one does not.
            // A carburetted path is already fuelled, in its bore. The
            // injector is commanded nothing rather than removed, so whatever
            // film it is holding still drains instead of vanishing.
            if (intakeGeometryAt(config_, intakePathIndex).carburettor.enabled)
                commandedFuelMoles = 0.0;
            commandedFuelMolesMaxThisCycle_[cylinderIndex] = std::max(
                commandedFuelMolesMaxThisCycle_[cylinderIndex], commandedFuelMoles);
            const auto injectionResult = FuelInjectionModel::deliver(config_.injection,
                config_.fuelProperties, injectionStates_[cylinderIndex], injectionTarget,
                commandedFuelMoles, subDt);
            // `deliver` also advances wall-film/spray state outside the pulse
            // window, so reaching this line does not imply injector authority.
            // Count only the actual crank window; the old unconditional
            // denominator hid a saturated pulse as about 38 percent duty.
            if (insideInjectionWindow && state_.rpm > 20.0) {
                injectorWindowSubsteps_[cylinderIndex] += 1.0;
                injectorOpenSubsteps_[cylinderIndex] +=
                    injectionResult.openFraction;
            }
            if (portInjection && injectionResult.vaporisedMoles > 0.0) {
                // Each cylinder owns its runner network, so this write is as
                // cylinder-private as the old runner-cell injection was.
                // A rotary's injector sits in its rotor's runner, beyond the
                // port passage its faces share.
                auto& network = intakeNetworkForCylinder(cylinderIndex);
                const auto vapourKg = injectionResult.vaporisedMoles * fuelMolarMassKg;
                const auto fuelTemperatureK = config_.injection.fuelTemperatureC + 273.15;
                if (!(config_.cycle == EngineCycle::rotary
                        ? network.injectSpeciesAtDuctInlet(intakeRunnerDuctIndex_[cylinderIndex],
                            gasdynamics::GasSpecies::fuel, vapourKg, fuelTemperatureK,
                            -injectionResult.chargeCoolingJoules)
                        : network.injectSpeciesAtPort(
                            jointIntakeManifold() ? intakeRunnerPortIndex_[cylinderIndex] : 0,
                            gasdynamics::GasSpecies::fuel, vapourKg, fuelTemperatureK,
                            -injectionResult.chargeCoolingJoules)))
                    contribution.solverResolutionLimited = true;
            }
            injectedFuelMolesThisCycle_[cylinderIndex] += injectionResult.meteredMoles;
            entrainedFuelMolesThisCycle_[cylinderIndex] +=
                injectionResult.entrainedMoles;
            contribution.meteredFuelMassKg += injectionResult.meteredMoles * fuelMolarMassKg;
            if (compressionIgnitionEngine) {
                flameEvents_[cylinderIndex] = {};
                ignitionPending_[cylinderIndex] = false;
                ignitionDelayRemainingSeconds_[cylinderIndex] = 0.0;
                fuelDeliveryRatio_[cylinderIndex] =
                    requestedFuelMoles > 1.0e-15
                    ? std::clamp(entrainedFuelMolesThisCycle_[cylinderIndex]
                        / requestedFuelMoles, 0.0, 1.0)
                    : 0.0;
                const auto deliveredFuelMassMg =
                    injectedFuelMolesThisCycle_[cylinderIndex]
                    * fuelMolarMassKg * 1.0e6;
                const auto cycleFreshAirMassMg = std::max(
                    trappedAirMassMgLastCycle_[cylinderIndex],
                    oxygenEquivalentAirMassMg);
                if (deliveredFuelMassMg > 1.0e-12
                    && ecuCommand.fuelEnabled) {
                    actualAfrLastCycle_[cylinderIndex] =
                        cycleFreshAirMassMg / deliveredFuelMassMg;
                    actualAfrFuelMassMgLastCycle_[cylinderIndex] =
                        deliveredFuelMassMg;
                    actualAfrValidLastCycle_[cylinderIndex] = true;
                } else {
                    actualAfrValidLastCycle_[cylinderIndex] = false;
                    actualAfrFuelMassMgLastCycle_[cylinderIndex] = 0.0;
                }
            } else if (!cylinderSparkCombustionAvailable) {
                cylinderMisfires_[cylinderIndex] = false;
                flameEvents_[cylinderIndex] = {};
                ignitionPending_[cylinderIndex] = false;
                ignitionDelayRemainingSeconds_[cylinderIndex] = 0.0;
            } else if (sparkCrossed) {
                ++commandedSparkEventsThisCycle_[cylinderIndex];
                ++contribution.commandedSparkEvents;
                commandedSparkPhaseThisCycle_[cylinderIndex] = sparkPhase;
                combustionCycleMultiplier_[cylinderIndex] =
                    CombustionCycleVariation::advance(
                        config_.combustionCalibration
                            .cycleVariationCoefficientOfVariation,
                        config_.combustionCalibration
                            .cycleVariationCorrelation,
                        combustionVariationRandomState_[cylinderIndex],
                        combustionVariationNormalisedState_[cylinderIndex]);
                meteredFuelMolesLastCycle_[cylinderIndex] = injectedFuelMolesThisCycle_[cylinderIndex];
                const auto chamberFuelMoles = cylinderGas_[cylinderIndex].mixture().fuelMoles;
                deliveredFuelMolesLastCycle_[cylinderIndex] = chamberFuelMoles;
                fuelDeliveryRatio_[cylinderIndex] = requestedFuelMoles > 1.0e-15
                    ? std::clamp(chamberFuelMoles / requestedFuelMoles, 0.0, 1.0) : 0.0;
                // Fraction of the requested charge fuel the injector DID
                // place before its window shut. Unlike `fuelDeliveryRatio` it
                // does not carry the closed-loop trim in its reference -- the
                // trim scales the request and the delivery alike -- so a
                // well-regulated engine reads ~1.0 and only a genuinely
                // undersized injector, or a pulse wider than its window, falls
                // short. See `injectorOpenSubsteps_` for why the two earlier
                // formulations measured neither.
                injectorCapacityRatio_[cylinderIndex] =
                    1.0 - injectorWindowUtilisation(cylinderIndex);
                injectorDutyCycle_[cylinderIndex] =
                    injectorDutyCycle(cylinderIndex);
                const auto mixtureAfr = airFuelRatioForCell(cylinderGas_[cylinderIndex], config_.fuelProperties);
                const auto mixtureFuelMassMg = chamberFuelMoles
                    * fuelMolarMassKg * 1.0e6;
                const auto validAfrObservation = ecuCommand.fuelEnabled
                    && ecuCommand.sparkEnabled
                    && requestedFuelMoles > 1.0e-15
                    && mixtureFuelMassMg > 1.0e-12
                    && (!portFuelResumePending_[cylinderIndex]
                        || portFuelResumePrepared_[cylinderIndex]);
                if (validAfrObservation) {
                    actualAfrLastCycle_[cylinderIndex] = mixtureAfr;
                    actualAfrFuelMassMgLastCycle_[cylinderIndex] =
                        mixtureFuelMassMg;
                    actualAfrValidLastCycle_[cylinderIndex] = true;
                    if (portFuelResumeOpenLoopSecondsRemaining_[cylinderIndex]
                            > 0.0
                        && mixtureAfr > 4.0 * petrolAfrBoundScale(config_)
                    && mixtureAfr < 40.0 * petrolAfrBoundScale(config_)) {
                        // The simulation observes the completed in-cylinder
                        // mixture directly, so the resume controller can correct
                        // the following pulse without pretending that a delayed
                        // wideband sensor is instantaneous. A quarter of the
                        // logarithmic error per cycle is fast enough to end the
                        // two-second rich lock, yet leaves transport/film state
                        // authoritative and avoids a one-cycle sign oscillation.
                        const auto targetAfr = std::clamp(
                            ecuCommand.targetAirFuelRatio, 5.0 * petrolAfrBoundScale(config_),
                            30.0 * petrolAfrBoundScale(config_));
                        const auto logarithmicError = std::clamp(
                            std::log(mixtureAfr / targetAfr), -0.70, 0.70);
                        portFuelResumeFuelTrim_[cylinderIndex] = std::clamp(
                            portFuelResumeFuelTrim_[cylinderIndex]
                                * std::exp(logarithmicError * 0.25),
                            0.55, 2.20);
                    }
                } else {
                    actualAfrValidLastCycle_[cylinderIndex] = false;
                    actualAfrFuelMassMgLastCycle_[cylinderIndex] = 0.0;
                }
                // Closed-loop lambda correction is based on the mixture that
                // actually reached the chamber, one cycle after injection.
                // It compensates port-film and runner transport losses without
                // fabricating fuel or altering the pressure-derived work.
                //
                // The observation is NOT valid during deceleration fuel cut.
                // The request is then zero but residual runner/chamber fuel
                // keeps producing an AFR; integrating that value drove the
                // learned trim from 0.80 to its 0.55 lower stop before the
                // injectors resumed. Production ECUs suspend lambda learning
                // in DFCO for the same observability reason. Transient-fuel
                // operation remains learnable here because the current start
                // model relies on the measured chamber mixture to converge its
                // initially dry port film; only a zero request is unobservable.
                const auto observableFuelCommand = ecuCommand.fuelEnabled
                    && ecuCommand.lambdaLearningAllowed
                    && requestedFuelMoles > 1.0e-15;
                if (observableFuelCommand && state_.rpm > 450.0
                    && mixtureAfr > 4.0 * petrolAfrBoundScale(config_)
                    && mixtureAfr < 40.0 * petrolAfrBoundScale(config_)) {
                    const auto targetAfr = std::clamp(
                        ecuCommand.targetAirFuelRatio, 5.0 * petrolAfrBoundScale(config_),
                            30.0 * petrolAfrBoundScale(config_));
                    // Attribute the observation to each cell in proportion to
                    // the authority it actually held over the command that
                    // produced it -- the same blend the command was built
                    // from, a few lines above. This must be the SAME weight:
                    // a cell that sets the fuel must answer for the mixture.
                    //
                    // The previous rule ("an observation in the interpolation
                    // band cannot identify which cell owns its error, so
                    // retain both") left a learning hole exactly over the
                    // authority ramp: the blend hands the high-load cell 0 to
                    // 100 % of the command between throttle 0.10 and 0.25,
                    // while neither cell learned anywhere inside that band.
                    // Worse, the ramp REACHES full authority at the same 0.25
                    // where learning was supposed to begin, and `state_.throttle`
                    // is the smoothed physical opening, so a command held at
                    // 0.25 approaches the test from below and can sit there
                    // indefinitely: full authority, zero adaptation.
                    //
                    // Measured on the Flat-6 free-revving at a fixed 0.25
                    // opening, before this change: trim pinned at 0.586 (its
                    // clamp floor is 0.55) while the engine ran AFR 20.9
                    // against a commanded 13.4 -- the controller removing 41 %
                    // of the fuel from an engine already starving, 81 % misfire,
                    // and net torque swinging -190 to +250 Nm. That torque
                    // spike is the audible "bop" reported from the application,
                    // and 0.25 is not a coincidence in the report: it is this
                    // constant. The diesel was the only catalogue engine free
                    // of it because compression ignition bypasses this trim
                    // entirely (see the `dieselFuelDemand` branch above).
                    //
                    // Proportional attribution is the textbook answer to the
                    // credit-assignment objection, not a threshold nudge: it
                    // is a normalised least-mean-squares update, it converges
                    // to the same fixed point, and it is identical to the old
                    // behaviour at both extremes (blend 0 updates only the low
                    // cell at full rate, blend 1 only the high cell).
                    const auto trimAuthorityBlend = std::clamp(
                        (state_.throttle - 0.10) / 0.15, 0.0, 1.0);
                    if (trimAuthorityBlend < 1.0) {
                        closedLoopFuelTrim_[cylinderIndex] = std::lerp(
                            closedLoopFuelTrim_[cylinderIndex],
                            FuelInjectionModel::updateClosedLoopTrim(
                                config_.injection, state_.rpm, mixtureAfr,
                                targetAfr, closedLoopFuelTrim_[cylinderIndex]),
                            1.0 - trimAuthorityBlend);
                    }
                    if (trimAuthorityBlend > 0.0) {
                        highLoadClosedLoopFuelTrim_[cylinderIndex] = std::lerp(
                            highLoadClosedLoopFuelTrim_[cylinderIndex],
                            FuelInjectionModel::updateClosedLoopTrim(
                                config_.injection, state_.rpm, mixtureAfr,
                                targetAfr,
                                highLoadClosedLoopFuelTrim_[cylinderIndex]),
                            trimAuthorityBlend);
                    }
                }
                if (portFuelResumePending_[cylinderIndex]
                        && portFuelResumePrepared_[cylinderIndex]) {
                    portFuelResumePending_[cylinderIndex] = false;
                    portFuelResumePrepared_[cylinderIndex] = false;
                    portFuelResumePurgeCycleSeen_[cylinderIndex] = false;
                }
                {
                    // Everything that is neither fresh air nor fuel dilutes.
                    const auto& sparkMixture = cylinderGas_[cylinderIndex].mixture();
                    const auto sparkMoles = sparkMixture.totalMoles();
                    diluentFractionAtSpark_[cylinderIndex] = sparkMoles > 1.0e-15
                        ? std::clamp(1.0 - (sparkMixture.oxygenMoles / 0.2095 + sparkMixture.fuelMoles)
                              / sparkMoles, 0.0, 1.0)
                        : 0.0;
                }
                const auto stoichiometricAfr = config_.fuelProperties.stoichiometricAirFuelRatio;
                // The lean draw is flat to a knee at lambda 1.60, then rises
                // to 72 % over 0.13 of lambda. A port-injected single
                // cylinder (CR 12.1, 1,500 rpm, 5.6 bar IMEP, tumble 0.6 or
                // 1.5) ran every gasoline-range fuel at lambda 1.4 at a COV
                // of IMEP of 2.1-2.6 %, so under ~0.1 % misfires, and only
                // the slowest fuel at low tumble stopped at 1.6 (Kolodziej et
                // al., SAE 2017-01-0671, OSTI 1501899). The COV of IMEP stays
                // flat until a knee, then rises linearly, and brake power is
                // gone 0.13 of lambda past it (Shiomoto, Sawyer, Kelly, SAE
                // 780235; Quader, SAE 741055, puts the limit at 0.5-0.8 %
                // motored cycles). From 1.40 over 0.35 it drew 41 % at 1.6,
                // where that chamber still ran (journal 2026-11-14).
                const auto flammabilityPenalty = std::max(0.0,
                    mixtureAfr - stoichiometricAfr * 1.60) / (stoichiometricAfr * 0.13)
                    + std::max(0.0, stoichiometricAfr * 0.68 - mixtureAfr)
                        / (stoichiometricAfr * 0.28);
                // The dilution limit: a kernel in a charge that is mostly burned
                // gas does not grow, whatever its AFR. A two-stroke's idle
                // traps 0.75-0.85 of it and, without this limit, fired every
                // revolution; a real one four-strokes, the misfire leaving a
                // fresher charge that lights a revolution or two later. The
                // flame model's own dilution terms burn such a charge slowly
                // but surely, so the limit is here, in the misfire draw. Its
                // onset sits above the most diluted four-stroke idle in the
                // catalogue (CP4 0.56; CP2 0.26), so no four-stroke idle draws
                // differently. With the draw rising to its 0.92 cap by 0.70,
                // the designed two-strokes fire 28-36 % of their sparks at
                // idle, about every third revolution (journal 2026-10-24).
                // The literature's limit is a flame temperature, not a
                // fraction: lean-limit flames of hydrocarbons in air sit near
                // 1,500-1,600 K adiabatic (NBSIR 76-1076; Zabetakis 1965,
                // 1,573 K), and Tsuchiya et al. (SAE 830091) judge a
                // two-stroke's light-load irregular firing by it. From the
                // 550-680 K the idle's charge has at the spark, 0.60 of
                // diluent leaves about 1,460 K and 0.70 about 1,250 K, so
                // the band starts at that limit (journal 2026-10-26).
                constexpr double dilutionMisfireOnset = 0.60;
                constexpr double dilutionMisfireFull = 0.70;
                const auto dilutionShare = std::clamp(
                    (diluentFractionAtSpark_[cylinderIndex] - dilutionMisfireOnset)
                        / (dilutionMisfireFull - dilutionMisfireOnset), 0.0, 1.0);
                const auto dilutionMisfire = dilutionShare * dilutionShare * (3.0 - 2.0 * dilutionShare);
                const auto actualMisfireProbability = std::clamp(
                    flammabilityPenalty * 0.72
                    + std::max(0.0, 380.0 - state_.rpm) / 1'400.0
                    + dilutionMisfire,
                    0.0, 0.92);
                // A departure from the commanded AFR is a control error, not a
                // combustion limit. The former implementation added a misfire
                // probability once actual AFR differed from the enriched WOT
                // map by 20 %. On the post-DFCO 2JZ that classified AFR 15.9
                // (lambda 1.08, still comfortably combustible) as a random
                // ignition failure. Physical rich/lean limits above already
                // describe mixture flammability; diagnostics separately expose
                // target tracking, so do not turn a calibration residual into
                // invented mechanical torque holes.
                // Do not add fuelDeliveryRatio as a second mixture penalty.
                // It compares chamber inventory with the current command and
                // legitimately sits below one on a port-injected transient;
                // the mixture above is the fuel and oxygen the flame actually
                // sees. On the boosted I5 it read ~0.48 while every cylinder
                // was at AFR 12.0-13.2 and the injector retained ~62% duty
                // headroom, yet the duplicate term invented simultaneous WOT
                // misfires. Genuine under-delivery already raises mixtureAfr
                // and therefore both mixtureError and flammabilityPenalty.
                auto& rng = decoupleSharedVolumes
                    ? cylinderRandomState_[cylinderIndex] : randomState_;
                rng ^= rng << 13U;
                rng ^= rng >> 17U;
                rng ^= rng << 5U;
                const auto randomUnit = static_cast<double>(rng) / static_cast<double>(0xffffffffU);
                cylinderMisfires_[cylinderIndex] = randomUnit < actualMisfireProbability;
                // A pops-and-bangs map's ignition cut, fuel kept: an ECU
                // decision, not a combustion limit, so it is drawn apart, and
                // only while the overrun map runs, which leaves every other
                // engine's misfire sequence as it was.
                if (!cylinderMisfires_[cylinderIndex]
                        && ecuCommand.overrunAfterfireActive
                        && config_.exhaustAfterfire.overrunSparkCutFraction > 0.0) {
                    rng ^= rng << 13U;
                    rng ^= rng >> 17U;
                    rng ^= rng << 5U;
                    cylinderMisfires_[cylinderIndex] =
                        static_cast<double>(rng) / static_cast<double>(0xffffffffU)
                        < config_.exhaustAfterfire.overrunSparkCutFraction;
                }
                // Anti-lag's cut: an ECU decision, no draw.
                if (ecuCommand.antiLagActive && sparkCutThisCycle_[cylinderIndex])
                    cylinderMisfires_[cylinderIndex] = true;
                if (cylinderMisfires_[cylinderIndex]) {
                    contribution.misfired = true;
                    contribution.misfireAirFuelRatio = mixtureAfr;
                }
                const auto totalMoles = cylinderGas_[cylinderIndex].totalMoles();
                const FlameConditions flameConditions {
                    cylinder.boreMm * 0.001, chamberVolume * 0.001,
                    cylinderGas_[cylinderIndex].temperatureK(),
                    cylinderGas_[cylinderIndex].pressureKpa() * 1'000.0,
                    config_.fuelProperties.stoichiometricAirFuelRatio / std::max(1.0, mixtureAfr),
                    totalMoles > 1.0e-15
                        ? cylinderGas_[cylinderIndex].mixture().burnedMoles / totalMoles : 0.0,
                    2.0 * cylinder.strokeMm * 0.001 * state_.rpm / 60.0,
                    state_.load, config_.combustionCalibration.residualDilutionSensitivity,
                    config_.combustionCalibration.chamberTurbulenceIntensityRatio
                        * tumbleTurbulenceScale(config_, cylinder)
                        * combustionCycleMultiplier_[cylinderIndex],
                    config_.combustionCalibration.ignitionSiteCount };
                ignitionPending_[cylinderIndex] = !cylinderMisfires_[cylinderIndex];
                ignitionDelayRemainingSeconds_[cylinderIndex] = ignitionPending_[cylinderIndex]
                    ? FlamePhysicsModel::ignitionDelaySeconds(config_.combustionCalibration, flameConditions) : 0.0;
                flameEvents_[cylinderIndex] = {};
            }
            if (sparkCrossed)
                sparkScheduleArmed_[cylinderIndex] = false;
            previousCylinderPhases_[cylinderIndex] = cyclePhase;
            portFuelResumeOpenLoopSecondsRemaining_[cylinderIndex] = std::max(
                0.0,
                portFuelResumeOpenLoopSecondsRemaining_[cylinderIndex]
                    - subDt);
            if (portFuelResumeOpenLoopSecondsRemaining_[cylinderIndex] > 0.0)
                portFuelResumeEpochAgeSeconds_[cylinderIndex] += subDt;
            else
                portFuelResumeEpochAgeSeconds_[cylinderIndex] = 0.0;
            const auto phaseTravel = forwardPhaseDegrees(previousPhase, cyclePhase, cycleDegrees);
            // Bank angle is spatial geometry, not cam timing. Valve events are
            // referenced to the cylinder's thermodynamic phase (720 degrees; a
            // two-stroke's ports, 360).
            const auto intakeLift = valveTrain.intakeLiftMm;
            const auto exhaustLift = valveTrain.exhaustLiftMm;
            const auto exhaustCenterPhase = std::fmod(valveCycleDegrees * 0.5 - cams.config->exhaustCenterlineDegrees
                - valveTrain.exhaustAdvanceDegrees + valveCycleDegrees, valveCycleDegrees);
            const auto exhaustOpenPhase = twoStroke
                ? exhaustPortOpenDegrees
                : std::fmod(exhaustCenterPhase - cams.exhaustDuration() * 0.5 + valveCycleDegrees,
                    valveCycleDegrees);
            const auto distanceToExhaustOpen = std::fmod(
                exhaustOpenPhase - previousPhase + cycleDegrees, cycleDegrees);
            const auto exhaustOpenedThisStep = phaseTravel > 1.0e-9
                && distanceToExhaustOpen <= phaseTravel;
            const auto combustionDt = exhaustOpenedThisStep
                ? subDt * std::clamp(distanceToExhaustOpen / phaseTravel, 0.0, 1.0)
                : subDt;
            const auto mixtureAfr = airFuelRatioForCell(cylinderGas_[cylinderIndex], config_.fuelProperties);
            const auto totalMoles = cylinderGas_[cylinderIndex].totalMoles();
            const FlameConditions flameConditions {
                cylinder.boreMm * 0.001, chamberVolume * 0.001,
                cylinderGas_[cylinderIndex].temperatureK(),
                cylinderGas_[cylinderIndex].pressureKpa() * 1'000.0,
                config_.fuelProperties.stoichiometricAirFuelRatio / std::max(1.0, mixtureAfr),
                totalMoles > 1.0e-15
                    ? cylinderGas_[cylinderIndex].mixture().burnedMoles / totalMoles : 0.0,
                2.0 * cylinder.strokeMm * 0.001 * state_.rpm / 60.0,
                state_.load, config_.combustionCalibration.residualDilutionSensitivity,
                config_.combustionCalibration.chamberTurbulenceIntensityRatio
                    * tumbleTurbulenceScale(config_, cylinder)
                    * combustionCycleMultiplier_[cylinderIndex],
                config_.combustionCalibration.ignitionSiteCount };
            if (compressionIgnitionEngine) {
                const auto wasAutoIgnited =
                    compressionIgnitionStates_[cylinderIndex].autoIgnited;
                auto& compressionResult =
                    compressionIgnitionResults_[cylinderIndex];
                auto cycleCalibration = config_.combustionCalibration;
                cycleCalibration.compressionIgnitionMixingTimeSeconds /=
                    std::max(0.55,
                        combustionCycleMultiplier_[cylinderIndex]);
                cycleCalibration.compressionIgnitionMixingTimeSeconds *=
                    CompressionIgnitionModel::railMixingTimeFactor(config_.injection);
                compressionResult = CompressionIgnitionModel::advance(
                    compressionIgnitionStates_[cylinderIndex],
                    cylinderGas_[cylinderIndex], config_.fuelProperties,
                    cycleCalibration,
                    { cyclePhase,
                      2.0 * cylinder.strokeMm * 0.001 * state_.rpm / 60.0,
                      compressionIgnitionAvailable,
                      injectedFuelMolesThisCycle_[cylinderIndex] > 0.0 },
                    combustionDt);
                if (!wasAutoIgnited && compressionResult.autoIgnited) {
                    residualGasFractionAtSpark_[cylinderIndex] =
                        flameConditions.burnedGasFraction;
                    equivalenceRatioAtSpark_[cylinderIndex] =
                        flameConditions.equivalenceRatio;
                }
                const auto burnAdvance =
                    compressionIgnitionStates_[cylinderIndex]
                            .cycleFuelReferenceMoles > 1.0e-15
                    ? compressionResult.reaction.burnedFuelMoles
                        / compressionIgnitionStates_[cylinderIndex]
                            .cycleFuelReferenceMoles
                    : 0.0;
                instantaneousCombustionPulse_[cylinderIndex] =
                    phaseTravel > 1.0e-6
                    ? std::clamp(burnAdvance / phaseTravel * 90.0,
                                 0.0, 4.5)
                    : 0.0;
                contribution.releasedEnergyJoules +=
                    compressionResult.reaction.releasedEnergyJoules
                    + releaseNitrousDecomposition(cylinderGas_[cylinderIndex],
                        compressionResult.reaction.burnedFuelMoles);
                endGasKnockStates_[cylinderIndex] = {};
            } else {
                if (ignitionPending_[cylinderIndex]) {
                    ignitionDelayRemainingSeconds_[cylinderIndex] -= combustionDt;
                    if (ignitionDelayRemainingSeconds_[cylinderIndex] <= 0.0) {
                        const auto burnableFuelMoles = std::min(cylinderGas_[cylinderIndex].mixture().fuelMoles,
                            cylinderGas_[cylinderIndex].mixture().oxygenMoles
                                / config_.fuelProperties.oxygenMolesPerFuelMole);
                        flamePhysics_.ignite(flameEvents_[cylinderIndex], config_.fuelProperties,
                                             flameConditions, burnableFuelMoles);
                        ++completedIgnitionEventsThisCycle_[cylinderIndex];
                        completedIgnitionPhaseThisCycle_[cylinderIndex] =
                            cyclePhase;
                        residualGasFractionAtSpark_[cylinderIndex] =
                            flameConditions.burnedGasFraction;
                        equivalenceRatioAtSpark_[cylinderIndex] =
                            flameConditions.equivalenceRatio;
                        ignitionPending_[cylinderIndex] = false;
                    }
                }
                const auto flameStep = flamePhysics_.advance(
                    flameEvents_[cylinderIndex], config_.fuelProperties,
                    flameConditions, combustionDt);
                const auto burnAdvance = flameStep.burnedFractionAdvance;
                const auto pulse = phaseTravel > 1.0e-6
                    ? std::clamp(burnAdvance / phaseTravel * 90.0,
                                 0.0, 3.5)
                    : 0.0;
                instantaneousCombustionPulse_[cylinderIndex] =
                    pulse * fuelDeliveryRatio_[cylinderIndex];
                if (burnAdvance > 0.0 && cylinderSparkCombustionAvailable
                        && !cylinderMisfires_[cylinderIndex]) {
                    const auto reaction =
                        ConservativeGasSystem::reactFuelMoles(
                            cylinderGas_[cylinderIndex],
                            flameEvents_[cylinderIndex]
                                .initialBurnableFuelMoles * burnAdvance,
                            flameStep.efficiency,
                            config_.fuelProperties.lowerHeatingValueMjPerKg
                                * 1'000'000.0);
                    contribution.releasedEnergyJoules +=
                        reaction.releasedEnergyJoules
                        + releaseNitrousDecomposition(cylinderGas_[cylinderIndex],
                            reaction.burnedFuelMoles);
                }

                // The end gas exists from the moment the cylinder seals: both
                // valves shut, or a two-stroke's transfer and exhaust ports.
                const auto cylinderSealed = twoStroke
                    ? portOpenAreaMm2(cylinder, config_.twoStroke.transferPortOpenDegrees,
                          transferPortWidthMm(config_.twoStroke, cylinder),
                          config_.twoStroke.portDischargeCoefficient, cyclePhase) <= 0.0
                        && portOpenAreaMm2(cylinder, exhaustPortOpenDegrees,
                          exhaustPortWidthMm(config_.twoStroke, cylinder),
                          config_.twoStroke.portDischargeCoefficient, cyclePhase) <= 0.0
                    : intakeLift <= 0.0 && exhaustLift <= 0.0;
                const auto& chamberMixture = cylinderGas_[cylinderIndex].mixture();
                const auto chamberMoles = std::max(1.0e-15, chamberMixture.totalMoles());
                const auto endGas = EndGasKnockModel::advance(
                    endGasKnockStates_[cylinderIndex], {
                        cylinderGas_[cylinderIndex].pressureKpa() / 100.0,
                        cylinderGas_[cylinderIndex].temperatureK(),
                        flameConditions.equivalenceRatio,
                        flameEvents_[cylinderIndex].burnedFraction,
                        config_.octaneRating,
                        cylinderSealed,
                        cylinderSparkCombustionAvailable
                            && flameEvents_[cylinderIndex].active
                            && !cylinderMisfires_[cylinderIndex],
                        chamberMixture.fuelMoles / chamberMoles,
                        chamberMixture.burnedMoles / chamberMoles,
                        cylinderGas_[cylinderIndex].volumeM3(),
                        flameEvents_[cylinderIndex].initialBurnableFuelMoles
                            * config_.fuelProperties.molarMassGramsPerMole * 0.001
                            * config_.fuelProperties.lowerHeatingValueMjPerKg * 1.0e6,
                        cylinderGas_[cylinderIndex].heatCapacityRatioEffective() },
                    combustionDt);
                if (endGas.autoIgnited
                        && endGas.autoIgnitedFuelFraction > 0.0) {
                    const auto reaction =
                        ConservativeGasSystem::reactFuelMoles(
                            cylinderGas_[cylinderIndex],
                            flameEvents_[cylinderIndex]
                                    .initialBurnableFuelMoles
                                * endGas.autoIgnitedFuelFraction,
                            std::max(0.72, flameStep.efficiency),
                            config_.fuelProperties.lowerHeatingValueMjPerKg
                                * 1'000'000.0);
                    contribution.releasedEnergyJoules +=
                        reaction.releasedEnergyJoules
                        + releaseNitrousDecomposition(cylinderGas_[cylinderIndex],
                            reaction.burnedFuelMoles);
                    flameEvents_[cylinderIndex].burnedFraction = std::clamp(
                        flameEvents_[cylinderIndex].burnedFraction
                            + endGas.autoIgnitedFuelFraction,
                        0.0, 1.0);
                    if (flameEvents_[cylinderIndex].burnedFraction >= 0.999)
                        flameEvents_[cylinderIndex].active = false;
                }
                contribution.endGasKnockLevel = std::max(
                    contribution.endGasKnockLevel, endGas.level);
            }
            if (exhaustOpenedThisStep) {
                // A premixed flame cannot propagate into the following
                // gas-exchange strokes. Only the part of this integration
                // interval preceding EVO was allowed to release heat above.
                flameEvents_[cylinderIndex].active = false;
                ignitionPending_[cylinderIndex] = false;
                ignitionDelayRemainingSeconds_[cylinderIndex] = 0.0;
                if (config_.exhaustAfterfire.pocketMixingTimeSeconds > 0.0) {
                    const auto& exhausted = cylinderGas_[cylinderIndex].mixture();
                    auto& pocket = pendingUnburnedPockets_[cylinderIndex];
                    // Half burnt or more: hot enough to light what waits in
                    // the primary. A late spark's cycle leaves at a third.
                    pocket.lightsResident = !cylinderMisfires_[cylinderIndex]
                        && flameEvents_[cylinderIndex].burnedFraction >= 0.5;
                    pocket.pending = exhausted.fuelMoles > 0.0;
                    pocket.fuelKg = exhausted.fuelMoles
                        * config_.fuelProperties.molarMassGramsPerMole * 0.001;
                    pocket.oxygenKg = exhausted.oxygenMoles * 0.032;
                    pocket.temperatureK = cylinderGas_[cylinderIndex].temperatureK();
                }
                if (compressionIgnitionEngine) {
                    cylinderMisfires_[cylinderIndex] =
                        injectedFuelMolesThisCycle_[cylinderIndex] > 1.0e-15
                        && !compressionIgnitionStates_[cylinderIndex]
                            .autoIgnited;
                    compressionIgnitionStates_[cylinderIndex].active = false;
                    compressionIgnitionResults_[cylinderIndex].active = false;
                }
            }

            auto chamberKpa = cylinderGas_[cylinderIndex].pressureKpa();
            chamberPressureBar_[cylinderIndex] = chamberKpa / 100.0;
            // Port plateaus: 0.58 and 0.51 of valve head area are the middle of
            // the production band in the literature cited on the helper. They
            // are deliberately not race-port figures -- an engine whose head
            // was flowed on a bench gives its exhaust plateau on its camshaft.
            // A two-stroke has ports instead: the piston uncovers them, the
            // transfer ports standing in for the intake valves (their duct is
            // the intake runner, the crankcase its plenum).
            const auto intakeArea = twoStroke
                ? portOpenAreaMm2(cylinder, config_.twoStroke.transferPortOpenDegrees,
                    transferPortWidthMm(config_.twoStroke, cylinder),
                    config_.twoStroke.portDischargeCoefficient, cyclePhase)
                : effectiveValveAreaMm2(cylinder.boreMm, intakeLift,
                    cylinder.intakeValveCount, cylinder.intakeValveDiameterMm,
                    valveTrain.intakeDischargeCoefficient, 0.40, 0.50, 0.58);
            const auto exhaustArea = twoStroke
                ? portOpenAreaMm2(cylinder, exhaustPortOpenDegrees,
                    exhaustPortWidthMm(config_.twoStroke, cylinder),
                    config_.twoStroke.portDischargeCoefficient, cyclePhase)
                : effectiveValveAreaMm2(cylinder.boreMm, exhaustLift,
                    cylinder.exhaustValveCount, cylinder.exhaustValveDiameterMm,
                    valveTrain.exhaustDischargeCoefficient, 0.34, 0.41,
                    std::clamp(options_.exhaustMaximumHeadAreaFraction.value_or(
                        cams.config->exhaustPortHeadAreaFraction > 0.0
                            ? cams.config->exhaustPortHeadAreaFraction : 0.51),
                        0.05, 1.5));
            // The scavenging window as a state, opened and closed by the
            // transfer ports themselves and advanced by the sub-step. What it
            // buys is in TwoStrokeScavenging.hpp: a perfectly mixed cylinder
            // cannot carry an engine-speed dependence, and this one does,
            // through the race between the loop's transit and the window.
            if (twoStroke) {
                auto& scavenge = scavengeStates_[cylinderIndex];
                const auto transferOpen = intakeArea > 0.0;
                if (!transferOpen) {
                    closeScavengeWindow(scavenge);
                } else {
                    if (!scavenge.open)
                        openScavengeWindow(scavenge,
                            std::max(0.0,
                                config_.twoStroke.scavengeLoopLengthRatio)
                                * cylinder.boreMm * 0.001);
                    // Jet velocity from the pressure the crankcase pump has
                    // built -- never from the port mass flow, which is the flow
                    // this bias goes on to shape. It is read every sub-step and
                    // integrated, because the front covers the loop at whatever
                    // the jet is doing along the way: sampling the one instant
                    // the ports crack open put the model on the pipe's
                    // returning wave and the engine hunted (the header).
                    const auto& crankcase = intakePlenumGas_[intakePathIndex];
                    const auto crankcaseVolumeM3 = crankcase.volumeM3();
                    const auto densityKgPerM3 = crankcaseVolumeM3 > 0.0
                        ? crankcase.massKg() / crankcaseVolumeM3
                        : 0.0;
                    const auto deltaKpa = crankcase.pressureKpa() - chamberKpa;
                    // No pressure across the ports, no loop: the charge
                    // dribbles in and mixes, which is what a lugged or a
                    // cranking two-stroke really does.
                    const auto jetVelocityMps =
                        (deltaKpa > 0.0 && densityKgPerM3 > 0.0)
                        ? std::sqrt(2.0 * deltaKpa * 1'000.0 / densityKgPerM3)
                        : 0.0;
                    advanceScavengeWindow(scavenge, jetVelocityMps, subDt);
                }
            }
            const auto& cylinderIntake = intakeGeometryAt(config_, intakePathIndex);
            const auto pistonAreaM2 = std::numbers::pi * std::pow(cylinder.boreMm * 0.0005, 2.0);
            // Both areas already carry their discharge coefficient, so the
            // coefficient that travels with them is unity. Everything
            // downstream multiplies the pair, so the product is what matters.
            // mm2 to m2, or shut on a stopped crank.
            const auto valveAreaScale = valvesSealed ? 0.0 : 1.0e-6;
            exhaustValveAreaM2[cylinderIndex] = exhaustArea * valveAreaScale
                * std::clamp(options_.exhaustValveAreaMultiplier.value_or(1.0),
                    0.05, 8.0);
            exhaustValveDischargeCoefficient[cylinderIndex] = 1.0;
            intakeValveAreaM2[cylinderIndex] = intakeArea * valveAreaScale
                * std::clamp(options_.intakeValveAreaMultiplier.value_or(1.0),
                    0.05, 8.0);
            intakeValveDischargeCoefficient[cylinderIndex] = 1.0;
            pistonAreaM2ForSplit[cylinderIndex] = pistonAreaM2;
            chamberVolumeLitresForWork[cylinderIndex] = chamberVolume;
            cycleBoundaryForWork[cylinderIndex] = cycleBoundaryCrossed;
            // A two-stroke has no pumping loop in its cylinder: the crankcase
            // does the pumping, so all of its cylinder work is gross work.
            gasExchangeStrokeForWork[cylinderIndex] = !twoStroke
                && cyclePhase >= strokeDegrees && cyclePhase < 3.0 * strokeDegrees;
            exhaustStrokeForWork[cylinderIndex] = !twoStroke
                && cyclePhase >= strokeDegrees && cyclePhase < 2.0 * strokeDegrees;
            const auto plenumPressureKpa = chargeSourcePressureKpa;
            // Telemetry only. The resonator frequency feeds the UI and the
            // acoustic path; its former flow role — an admittance modulating a
            // plenum->runner orifice — is superseded by the resolved 1-D
            // runner, which owns the wave physics the admittance approximated.
            runnerAcousticResults_[cylinderIndex] = HelmholtzRunnerModel::advance(config_.runnerAcoustics,
                runnerAcousticStates_[cylinderIndex], cylinder, cylinderIntake,
                intakePortTemperatureK_[cylinderIndex],
                plenumPressureKpa, intakeRunnerPressureKpa_[cylinderIndex], subDt);

            // ----------------------------------------------------------------
            // Gas flow. The intake side is a resolved 1-D finite-volume runner
            // per cylinder — plenum reservoir -> duct -> valve Riemann port —
            // advanced OUTSIDE this per-cylinder pass in a symmetric split
            // around the exhaust coupling (see advanceIntakeRunners). Wall
            // friction and the aluminium wall heat exchange are owned by the
            // duct solver. This replaced a lumped runner cell plus
            // quasi-steady valve orifice whose equilibrium clamp capped the
            // fill at static manifold density: intake tuning is a WAVE
            // phenomenon, and four algebraic bias formulations on the lumped
            // topology were measured and refuted before this
            // (physics-audit.md in the archive/docs-2026-09 tag, sections on runner
            // inertance and the architectural diagnosis). Do not re-add a pressure bias at the
            // valve: the duct carries the column's momentum as state, which is
            // the thing every bias was trying to counterfeit.
            //
            // Exhaust transfer is likewise solved by the conservative 1-D
            // network after this private-state pass.
            // ----------------------------------------------------------------
            const auto cylinderGasTemperatureK = cylinderGas_[cylinderIndex].temperatureK();
            const auto cylinderGasHeatCapacityJPerK = cylinderGas_[cylinderIndex].totalMoles()
                * cylinderGas_[cylinderIndex].molarHeatCapacityCvEffective();
            const auto valvesOpen = intakeLift > 0.01 || exhaustLift > 0.01;
            if (exhaustLift > 0.01) woschniReferenceValid_[cylinderIndex] = false;
            // Woschni's combustion term (SAE 670931; C2 = 3.24e-3 m/(s K),
            // fitted on a direct-injection diesel): the gas the burn sets in
            // motion, from the pressure above the motored one. Without it
            // the TDI turned 51 % of its fuel into indicated work at full
            // load, where a real one turns 45-47 % (journal 2026-10-28).
            // Diesel only: the spark engines' calibrations and starts were
            // measured without it (journal 2026-10-23).
            auto combustionGasVelocityMps = 0.0;
            if (compressionIgnitionEngine && !valvesOpen
                    && woschniReferenceValid_[cylinderIndex]) {
                const auto referenceVolumeL = woschniReferenceVolumeL_[cylinderIndex];
                const auto referencePressureKpa = woschniReferencePressureKpa_[cylinderIndex];
                const auto motoredPressureKpa = referencePressureKpa
                    * std::pow(referenceVolumeL / std::max(1.0e-9, chamberVolume), 1.35);
                const auto displacementL = std::numbers::pi * 0.25 * cylinder.boreMm
                    * cylinder.boreMm * cylinder.strokeMm * 1.0e-6;
                combustionGasVelocityMps = 3.24e-3 * displacementL
                    * woschniReferenceTemperatureK_[cylinderIndex]
                    / (referencePressureKpa * referenceVolumeL)
                    * std::max(0.0, chamberKpa - motoredPressureKpa);
            }
            // A rotary face's gas moves with the rotor's flank, so its
            // velocity scale is the apex speed, and its wall is the flank,
            // the housing and the side plates (rotaryChamberSurfaceM2: a 13B
            // face at top dead centre wets 0.031 m2, a piston of its
            // equivalent bore 0.023 m2).
            const auto rotaryFace = config_.cycle == EngineCycle::rotary;
            const auto wallHeatTransfer = CylinderHeatTransferModel::evaluate({
                cylinder.boreMm * 0.001,
                kinematics.pistonTravelMm * 0.001,
                rotaryFace ? rotaryApexSpeedMps(config_.rotary, state_.rpm * std::numbers::pi / 30.0)
                           : 2.0 * cylinder.strokeMm * 0.001 * state_.rpm / 60.0,
                chamberKpa,
                cylinderGasTemperatureK,
                cylinderWallTemperatureC_[cylinderIndex] + 273.15,
                cylinderGasHeatCapacityJPerK,
                config_.combustionCalibration.wallHeatTransferCoefficientWPerK,
                subDt,
                valvesOpen,
                combustionGasVelocityMps,
                rotaryFace ? rotaryChamberSurfaceM2(config_.rotary, chamberVolume) : 0.0,
            });
            cylinderGas_[cylinderIndex].addHeatJoules(wallHeatTransfer.heatToGasJ);
            if (cylinder.blowByCoefficient > 0.0) {
                // Ring blow-by is a leak of ~0.1 mm2: applied at most every
                // blowByUpdateIntervalSeconds over the time accumulated since,
                // not on every crank sub-step. At 12,300 rpm that is 7 crank
                // degrees instead of 1, and the flow solve with its equilibrium
                // search cost 12 % of a CP4 step at the limiter.
                auto& pending = blowByPendingSeconds_[cylinderIndex];
                pending += subDt;
                if (pending >= blowByUpdateIntervalSeconds) {
                    (void)ConservativeGasSystem::flowFromBoundary(cylinderGas_[cylinderIndex],
                        config_.ambientPressureKpa, config_.ambientTemperatureC + 273.15,
                        std::numbers::pi * std::pow(cylinder.boreMm * 0.0005, 2.0) * cylinder.blowByCoefficient,
                        0.65, pending);
                    pending = 0.0;
                }
            }
            chamberKpa = cylinderGas_[cylinderIndex].pressureKpa();
            chamberPressureBar_[cylinderIndex] = chamberKpa / 100.0;
            // A two-stroke traps its charge when the piston covers the
            // transfer ports again, symmetric about bottom dead centre.
            const auto intakeClosePhase = twoStroke
                ? cycleDegrees - config_.twoStroke.transferPortOpenDegrees
                : std::fmod(valveCycleDegrees * 0.5 + cams.config->intakeCenterlineDegrees
                    - valveTrain.intakeAdvanceDegrees
                    + cams.intakeDuration() * 0.5 + valveCycleDegrees, valveCycleDegrees);
            const auto intakeOpenDuration = twoStroke
                ? cycleDegrees - 2.0 * config_.twoStroke.transferPortOpenDegrees
                : cams.intakeDuration();
            intakeCloseForTrappedAir[cylinderIndex] = crossedPhase(
                previousPhase, cyclePhase, intakeClosePhase, cycleDegrees);
            if (compressionIgnitionEngine && intakeCloseForTrappedAir[cylinderIndex]) {
                woschniReferenceValid_[cylinderIndex] = chamberKpa > 0.0 && chamberVolume > 0.0;
                woschniReferenceVolumeL_[cylinderIndex] = chamberVolume;
                woschniReferencePressureKpa_[cylinderIndex] = chamberKpa;
                woschniReferenceTemperatureK_[cylinderIndex] = cylinderGas_[cylinderIndex].temperatureK();
            }
            if (forwardIntakeFlush) {
                // Where this chamber and its intake valve will be at the end of
                // the interval the network is about to run ahead over. The
                // valve train is evaluated on a copy of its state, with no time
                // step, so nothing here moves the real valve train.
                const auto degreesPerSecond = std::max(1.0e-9,
                    std::abs(state_.angularVelocityRadPerSecond) * 180.0 / std::numbers::pi);
                const auto aheadDegrees = degreesPerSecond * forwardIntervalSeconds;
                const auto intakeOpenPhase = std::fmod(intakeClosePhase
                    - intakeOpenDuration + cycleDegrees, cycleDegrees);
                secondsToIntakeOpen[cylinderIndex] = std::fmod(
                    intakeOpenPhase - cyclePhase + cycleDegrees, cycleDegrees) / degreesPerSecond;
                secondsToIntakeClose[cylinderIndex] = std::fmod(
                    intakeClosePhase - cyclePhase + cycleDegrees, cycleDegrees) / degreesPerSecond;
                auto aheadValveTrainState = valveTrainStates_[cylinderIndex];
                const auto ahead = ValveTrainModel::evaluate(*cams.config, cams.highProfile,
                    aheadValveTrainState, std::fmod(cyclePhase + aheadDegrees, valveCycleDegrees),
                    state_.rpm, state_.load, 0.0, valveCycleDegrees);
                intakeValveAreaAheadM2[cylinderIndex] = (twoStroke
                    ? portOpenAreaMm2(cylinder, config_.twoStroke.transferPortOpenDegrees,
                        transferPortWidthMm(config_.twoStroke, cylinder),
                        config_.twoStroke.portDischargeCoefficient,
                        std::fmod(cyclePhase + aheadDegrees, cycleDegrees))
                    : effectiveValveAreaMm2(
                        cylinder.boreMm, ahead.intakeLiftMm, cylinder.intakeValveCount,
                        cylinder.intakeValveDiameterMm, ahead.intakeDischargeCoefficient,
                        0.40, 0.50, 0.58)) * valveAreaScale
                    * std::clamp(options_.intakeValveAreaMultiplier.value_or(1.0),
                        0.05, 8.0);
                const auto aheadKinematics = evaluateCylinderKinematics(config_,
                    kinematicsReference_, cylinderIndex,
                    state_.crankAngleDegrees + aheadDegrees,
                    state_.angularVelocityRadPerSecond, predictedAngularAcceleration);
                chamberVolumeAheadM3[cylinderIndex] = cylinderGas_[cylinderIndex].volumeM3()
                    * aheadKinematics.chamberVolumeLitres / std::max(1.0e-9, chamberVolume);
            }
            // Intake mass accounting and the published runner state now come
            // from the network advances outside this pass.
            const auto resolvedPulse =
                instantaneousCombustionPulse_[cylinderIndex];
            cylinderWallTemperatureC_[cylinderIndex] = smooth(cylinderWallTemperatureC_[cylinderIndex],
                config_.ambientTemperatureC + combustion.heatOutput * 175.0
                    + resolvedPulse * 95.0,
                subDt, 0.22);
            contribution.intakeRunnerPressure += intakeRunnerPressureKpa_[cylinderIndex];
            const auto breathingQuality = std::clamp(intakeFlowMgPerCycle_[cylinderIndex]
                / std::max(1.0, combustion.airMassMgPerCycle / static_cast<double>(config_.cylinders.size())),
                0.45, 1.35);
            contribution.combustionPulse += resolvedPulse
                * std::clamp(1.0 + cylinder.efficiencyOffset, 0.8, 1.2)
                * breathingQuality * fuelDeliveryRatio_[cylinderIndex];
            // One third of the connecting rod mass is a standard equivalent
            // reciprocating-mass approximation; the remainder contributes to
            // crank rotational inertia represented by EngineConfig.
            // A rotor reciprocates nothing: its mass turns on the eccentric
            // and is balanced like a crank's (rotatingInertiaKgM2).
            const auto massKg = config_.cycle == EngineCycle::rotary ? 0.0
                : (cylinder.pistonMassGrams + cylinder.connectingRodMassGrams / 3.0) * 0.001;
            const auto inertiaForce = massKg * kinematics.pistonAccelerationMps2;
            structuralInertiaForceN[cylinderIndex] = inertiaForce;
            const auto leverArm = kinematics.displacementDerivativeMPerRadian;
            contribution.reciprocatingTorque += inertiaForce * leverArm;
            // pistonAreaM2 is already defined above for the gas flow calls (same scope).
            // A two-stroke's piston has its crankcase, not the atmosphere,
            // underneath: that is how the crankcase pumping loads the crank.
            const auto undersidePressureKpa = twoStroke ? chargeSourcePressureKpa : config_.ambientPressureKpa;
            const auto gasForceN = (chamberKpa - undersidePressureKpa) * 1'000.0 * pistonAreaM2;
            chamberPressureBeforeNetworkKpa[cylinderIndex] = chamberKpa;
            gasTorqueLeverArmM[cylinderIndex] = leverArm;
            contribution.gasIndicatedTorque += gasForceN * leverArm;
            // The side thrust is governed by the acute angle between the rod
            // and the cylinder axis.  Treating an aligned rod as 90 degrees
            // multiplies skirt/ring friction by tan(77 deg) and consumes most
            // of the indicated work.  MechanicalKinematics owns the geometry,
            // so use its vector-derived obliquity directly.
            const auto rodObliquityRadians = std::clamp(
                kinematics.connectingRodObliquityDegrees * std::numbers::pi / 180.0,
                0.0, 1.35);
            const auto rodSideRatio = std::abs(std::tan(rodObliquityRadians));
            const auto sideDirection = kinematics.crankPinXMm >= kinematics.wristPinXMm
                ? 1.0 : -1.0;
            structuralSideRatio[cylinderIndex] = rodSideRatio * sideDirection;
            const auto cylinderWallForceN = std::abs(gasForceN - inertiaForce) * rodSideRatio;
            const auto pistonVelocityMps = kinematics.pistonVelocityMps;
            const auto pistonFrictionForceN = stribeckFrictionForce(cylinder, pistonVelocityMps,
                                                                    cylinderWallForceN);
            contribution.pistonFrictionPowerW += pistonFrictionForceN * std::abs(pistonVelocityMps);
            contribution.pistonBreakawayTorqueNm += pistonFrictionForceN * std::abs(leverArm);
            contribution.peakPistonAcceleration = std::max(
                contribution.peakPistonAcceleration, std::abs(kinematics.pistonAccelerationMps2));
            contribution.pistonSpeed += 2.0 * cylinder.strokeMm * 0.001 * state_.rpm / 60.0;
            if (!decoupleSharedVolumes && !twoStrokeParallelPass) {
                accumulateContribution(contribution);
                applyCylinderEvents(contribution);
            }
        };
        // With the shared volumes frozen, the body writes only state private to
        // its cylinder (its scratch, its own arrays, its own runner duct), so it
        // runs on the resident intake workers. The 2026 fork-join that lost to
        // the inline loop (see `decoupledSharedVolumeCylinderThreshold`) woke
        // threads for ~0.6 us of work per cylinder; these workers are already
        // spinning between the gas dispatches and the body is now 1.5-2.2 us
        // (journal 2026-10-20). A two-stroke takes its own path below
        // (`twoStrokeParallelPass`): its reed fill is per intake path, so it
        // needs one path a cylinder, and it keeps the plenum read live.
        auto parallelCylinderPass = decoupleSharedVolumes && intakeWorkerPool_ != nullptr
            && (!twoStroke || twoStrokeOwnIntakePaths)
            && options_.parallelCylinderPass.value_or(true);
        if (parallelCylinderPass && jointIntakeManifold()) {
            // Port fuel lands in, and the port state is read from, the
            // cylinder's runner duct of the joint network: it must be its own.
            for (std::size_t first = 0; first < config_.cylinders.size() && parallelCylinderPass; ++first)
                for (std::size_t second = first + 1; second < config_.cylinders.size(); ++second)
                    if (&intakeDuctForCylinder(first) == &intakeDuctForCylinder(second)) {
                        parallelCylinderPass = false;
                        break;
                    }
        }
        if (parallelCylinderPass) {
            using ProcessCylinder = std::decay_t<decltype(processCylinder)>;
            intakeWorkerPool_->runIndices(config_.cylinders.size(),
                [](void* context, std::size_t index) noexcept {
                    (*static_cast<const ProcessCylinder*>(context))(index);
                },
                const_cast<void*>(static_cast<const void*>(&processCylinder)));
        } else if (twoStrokeParallelPass) {
            using ProcessCylinder = std::decay_t<decltype(processCylinder)>;
            intakeWorkerPool_->runIndices(config_.cylinders.size(),
                [](void* context, std::size_t index) noexcept {
                    (*static_cast<const ProcessCylinder*>(context))(index);
                },
                const_cast<void*>(static_cast<const void*>(&processCylinder)));
            // The serial loop's own order and arithmetic: nothing in the pass
            // reads these sums or counters.
            for (std::size_t index = 0; index < config_.cylinders.size(); ++index) {
                accumulateContribution((*twoStrokeScratch)[index]);
                applyCylinderEvents((*twoStrokeScratch)[index]);
            }
        } else {
            for (std::size_t cylinderIndex = 0; cylinderIndex < config_.cylinders.size(); ++cylinderIndex)
                processCylinder(cylinderIndex);
        }
        if (decoupleSharedVolumes)
            for (std::size_t index = 0; index < config_.cylinders.size(); ++index)
                applyCylinderEvents(parallelState->scratch[index]);

        const auto requestedIntakeCouplingSeconds = std::clamp(
            options_.intakeCouplingIntervalSeconds.value_or(jointIntakeManifold() ? 0.0 : 400.0e-6),
            0.0, 500.0e-6);
        const auto periodicMultirateIntake = !forwardIntake
            && requestedIntakeCouplingSeconds > subDt * 1.5;
        // A cadence change must first commit any pending boundary history.
        // The period clock is independent of that history: IVC may flush a
        // partial interval without moving the next periodic deadline.
        const auto multirateIntake = periodicMultirateIntake
            || intakeCouplingDurationSeconds_ > 0.0;
        if (periodicMultirateIntake)
            intakeSchedulingPhaseSeconds_ += subDt;
        else
            intakeSchedulingPhaseSeconds_ = 0.0;
        std::array<gasdynamics::ConservativeState, 32>
            intakeAveragedBoundaryState {};
        std::array<double, 32> intakeAveragedBoundaryVolumeM3 {};
        std::array<double, 32> intakeAveragedValveConductanceM2 {};
        if (multirateIntake) {
            intakeCouplingDurationSeconds_ += subDt;
            for (std::size_t index = 0; index < config_.cylinders.size(); ++index) {
                const auto boundaryState = networkStateForGasCell(cylinderGas_[index]);
                auto& stateIntegral = intakeBoundaryStateTimeIntegral_[index];
                for (std::size_t species = 0;
                     species < gasdynamics::gasSpeciesCount; ++species) {
                    stateIntegral.speciesMassDensityKgPerM3[species] +=
                        boundaryState.speciesMassDensityKgPerM3[species] * subDt;
                }
                stateIntegral.momentumDensityKgPerM2S +=
                    boundaryState.momentumDensityKgPerM2S * subDt;
                stateIntegral.totalEnergyDensityJPerM3 +=
                    boundaryState.totalEnergyDensityJPerM3 * subDt;
                intakeBoundaryVolumeTimeIntegralM3S_[index] +=
                    cylinderGas_[index].volumeM3() * subDt;
                intakeValveConductanceTimeIntegralM2S_[index] +=
                    intakeValveAreaM2[index]
                    * intakeValveDischargeCoefficient[index] * subDt;
            }
        }
        const auto intakeValveClosing = std::any_of(
            intakeCloseForTrappedAir.begin(),
            intakeCloseForTrappedAir.begin()
                + static_cast<std::ptrdiff_t>(config_.cylinders.size()),
            [](bool closing) { return closing; });
        const auto periodicIntakeDue = periodicMultirateIntake
            && intakeSchedulingPhaseSeconds_
                >= requestedIntakeCouplingSeconds - 0.5 * subDt;
        const auto flushIntakeNetworks = !forwardIntake
            && (!periodicMultirateIntake || intakeValveClosing || periodicIntakeDue);
        if (periodicIntakeDue)
            intakeSchedulingPhaseSeconds_ -= requestedIntakeCouplingSeconds;
        const auto intakeAdvanceDurationSeconds = multirateIntake
            ? intakeCouplingDurationSeconds_ : subDt;
        if (flushIntakeNetworks) {
            ++state_.intakeCouplingFlushCount;
            state_.intakeCouplingAdvancedSeconds += intakeAdvanceDurationSeconds;
            if (state_.intakeCouplingMinimumIntervalSeconds == 0.0)
                state_.intakeCouplingMinimumIntervalSeconds = intakeAdvanceDurationSeconds;
            else
                state_.intakeCouplingMinimumIntervalSeconds = std::min(
                    state_.intakeCouplingMinimumIntervalSeconds, intakeAdvanceDurationSeconds);
            state_.intakeCouplingMaximumIntervalSeconds = std::max(
                state_.intakeCouplingMaximumIntervalSeconds, intakeAdvanceDurationSeconds);
            for (std::size_t index = 0; index < config_.cylinders.size(); ++index) {
                if (multirateIntake) {
                    auto averagedState = intakeBoundaryStateTimeIntegral_[index];
                    for (auto& speciesDensity :
                         averagedState.speciesMassDensityKgPerM3) {
                        speciesDensity /= intakeCouplingDurationSeconds_;
                    }
                    averagedState.momentumDensityKgPerM2S /=
                        intakeCouplingDurationSeconds_;
                    averagedState.totalEnergyDensityJPerM3 /=
                        intakeCouplingDurationSeconds_;
                    intakeAveragedBoundaryState[index] = averagedState;
                    intakeAveragedBoundaryVolumeM3[index] =
                        intakeBoundaryVolumeTimeIntegralM3S_[index]
                        / intakeCouplingDurationSeconds_;
                    intakeAveragedValveConductanceM2[index] =
                        intakeValveConductanceTimeIntegralM2S_[index]
                        / intakeCouplingDurationSeconds_;
                }
            }
        }

        // The 1-D intake runners advance in a symmetric split around the
        // exhaust coupling, exactly like the lumped valve orifice they
        // replaced: half the substep before the exhaust network sees the
        // cylinders, half after. Each cylinder owns one single-duct network
        // whose ambient reservoir is its path's plenum, so cylinders still
        // interact only through the shared plenum cell, and the serial
        // cylinder order keeps every floating-point reduction fixed.
        //
        // The split is taken ONLY while a cylinder's intake valve is open. That
        // is where it earns its cost: the valve is the stiff, fast-moving
        // boundary term, and halving the step there is what keeps volumetric
        // efficiency converged. With the valve shut the runner is an isolated
        // column ringing at its own acoustic rate, well inside the mesh CFL
        // limit, and the second half-step buys almost nothing.
        //
        // Measured, LS3: collapsing the split for ALL cylinders is worth 41% of
        // the sub-step but costs 2.3% of VE and 2.6% of torque at 3,628 rpm --
        // refused, see physics-audit.md (archive/docs-2026-09 tag). Gating it on the valve keeps the
        // resolution where that error lives.
        //
        // `openIntakeValve` reads the same `intakeValveAreaM2` array in both
        // passes, and nothing writes that array between them, so every cylinder
        // advances exactly `subDt` per sub-step whichever branch it takes. That
        // is a conservation requirement, not a nicety: a cylinder that took the
        // first pass and then failed the predicate would silently lose half a
        // sub-step of mass and energy transfer.
        //
        // `advanceIntakeRunnerFor` below is the concurrent phase: it must touch
        // nothing but state private to its own cylinder. Everything shared --
        // the plenum -- is decided before it and committed after it, in
        // cylinder order, so the result cannot depend on the schedule. The
        // scheme that picks the plenum state each cylinder reads, and the three
        // that were measured and rejected first, are described on
        // `advanceIntakeRunners` further down.
        //
        // `plenumDeltaForMouthSample` reads the plenum cell only for its
        // CONFIGURED molar masses, never for its dynamic state, so holding the
        // delta back changes nothing about the delta itself; the boundary state
        // is the entire difference.
        std::array<gasdynamics::ConservativeState, 32> plenumBoundaryState {};
        std::array<gasdynamics::ExhaustOutletFlowSample, 32> predictedPlenumDraw {};
        std::array<std::uint8_t, 32> predictedPlenumDrawValid {};
        std::array<GasInventoryDelta, 32> pendingPlenumDelta {};
        std::array<std::uint8_t, 32> intakePhaseFailed {};
        // A cylinder whose intake valve is shut on the first half takes no
        // advance at all, and must not then have a zero delta pushed into the
        // plenum: `tryApplyInventoryDelta` is not required to be a no-op on a
        // zero argument, and the previous code simply did not call it.
        std::array<std::uint8_t, 32> intakePhaseProducedDelta {};
        struct ExpectedSplitReservoir final {
            std::array<double, gasdynamics::gasSpeciesCount> speciesMassKg {};
            double internalEnergyJ { 0.0 };
            double volumeM3 { 0.0 };
            double absoluteTransferredMassKg { 0.0 };
            std::uint64_t interveningExhaustObservationCount { 0 };
            double absoluteInterveningExhaustTransferredMassKg { 0.0 };
            bool valid { false };
        };
        std::optional<std::array<ExpectedSplitReservoir, 32>>
            intakeExpectedSecondHalfReservoir;
        if (intakeSplitReservoirDiagnosticsEnabled_)
            intakeExpectedSecondHalfReservoir.emplace();
        const auto observeIntakeSplitReservoir = [&](std::size_t index,
            const gasdynamics::CylinderValveBoundary& boundary, bool firstHalf, bool openIntakeValve) noexcept {
                if (intakeSplitReservoirDiagnosticsEnabled_ && multirateIntake
                        && openIntakeValve && !firstHalf
                        && (*intakeExpectedSecondHalfReservoir)[index].valid) {
                    const auto& expected = (*intakeExpectedSecondHalfReservoir)[index];
                    auto& observed = intakeSplitObservations[index];
                    ++observed.observationCount;
                    observed.observedCylinderMask |= std::uint32_t { 1 }
                        << static_cast<unsigned>(index);
                    observed.absoluteFirstHalfTransferredMassKg +=
                        expected.absoluteTransferredMassKg;
                    observed.interveningExhaustObservationCount +=
                        expected.interveningExhaustObservationCount;
                    if (expected.interveningExhaustObservationCount != 0)
                        observed.interveningExhaustCylinderMask |= std::uint32_t { 1 }
                            << static_cast<unsigned>(index);
                    observed.absoluteInterveningExhaustTransferredMassKg +=
                        expected.absoluteInterveningExhaustTransferredMassKg;
                    observed.maximumVolumeMismatchM3 = std::max(
                        observed.maximumVolumeMismatchM3,
                        std::abs(boundary.cylinderVolumeM3 - expected.volumeM3));
                    for (std::size_t species = 0;
                         species < gasdynamics::gasSpeciesCount; ++species) {
                        const auto actualMassKg = boundary.cylinderState
                            .speciesMassDensityKgPerM3[species] * boundary.cylinderVolumeM3;
                        observed.maximumSpeciesInventoryMismatchKg = std::max(
                            observed.maximumSpeciesInventoryMismatchKg,
                            std::abs(actualMassKg - expected.speciesMassKg[species]));
                        observed.maximumObservedSpeciesInventoryKg = std::max({
                            observed.maximumObservedSpeciesInventoryKg,
                            std::abs(actualMassKg), std::abs(expected.speciesMassKg[species]) });
                    }
                    const auto actualEnergyJ = boundary.cylinderState
                        .totalEnergyDensityJPerM3 * boundary.cylinderVolumeM3;
                    observed.maximumEnergyInventoryMismatchJ = std::max(
                        observed.maximumEnergyInventoryMismatchJ,
                        std::abs(actualEnergyJ - expected.internalEnergyJ));
                    observed.maximumObservedEnergyInventoryJ = std::max({
                        observed.maximumObservedEnergyInventoryJ,
                        std::abs(actualEnergyJ), std::abs(expected.internalEnergyJ) });
                }
        };
        const auto recordIntakeCylinderExchange = [&](std::size_t index,
            const gasdynamics::CylinderValveBoundary& boundary,
            const gasdynamics::CylinderGasExchange& exchange,
            const gasdynamics::EulerMixtureModel& mixture,
            bool firstHalf, bool openIntakeValve, bool completed) noexcept {
                if (intakeSplitReservoirDiagnosticsEnabled_ && multirateIntake
                        && openIntakeValve && firstHalf && completed) {
                    auto& expected = (*intakeExpectedSecondHalfReservoir)[index];
                    expected.volumeM3 = boundary.cylinderVolumeM3;
                    for (std::size_t species = 0;
                         species < gasdynamics::gasSpeciesCount; ++species) {
                        expected.speciesMassKg[species] = boundary.cylinderState
                            .speciesMassDensityKgPerM3[species] * boundary.cylinderVolumeM3
                            - exchange.speciesMassKg[species];
                        expected.absoluteTransferredMassKg +=
                            std::abs(exchange.speciesMassKg[species]);
                    }
                    expected.internalEnergyJ = boundary.cylinderState
                        .totalEnergyDensityJPerM3 * boundary.cylinderVolumeM3
                        - exchange.totalEnergyJ;
                    expected.valid = true;
                }
                if (multirateIntake && firstHalf) {
                    // Both halves share one finite virtual cylinder. Preserve
                    // the first half's conservative transfer at its averaged
                    // volume instead of restoring its pre-transfer inventory.
                    if (!carryCylinderExchange(intakeAveragedBoundaryState[index],
                            intakeAveragedBoundaryVolumeM3[index], exchange,
                            mixture))
                        intakePhaseFailed[index] = 1;
                }
                const auto nonzeroExchange = exchange.totalEnergyJ != 0.0
                    || std::any_of(exchange.speciesMassKg.begin(), exchange.speciesMassKg.end(),
                        [](double mass) { return mass != 0.0; });
                if (nonzeroExchange && !cylinderGas_[index].tryApplyInventoryDelta(
                        cylinderDeltaForExchange(exchange, cylinderGas_[index]))) {
                    intakePhaseFailed[index] = 1;
                    ++intakeCylinderTransferFailures[index];
                }
                // The exchange is positive from the cylinder into the runner,
                // so the intake mass the cylinder gained is its negation.
                instantaneousIntakeTransferredMassKg[index] += -exchange.totalMassKg();
                intakeFlowMgThisCycle_[index] += -exchange.totalMassKg() * 1.0e6;
                // Fresh air on the same oxygen basis the trapped figure uses, so
                // the two divide into a trapping efficiency. At stoichiometry the
                // residual carries no oxygen, so oxygen crossing the valve is
                // fresh air in whichever direction it goes.
                deliveredAirMgThisCycle_[index] +=
                    -exchange.speciesMassKg[static_cast<std::size_t>(
                         gasdynamics::GasSpecies::oxygen)]
                    / GasCell::oxygenMolarMassKg / 0.21 * GasCell::airMolarMassKg * 1.0e6;
                // Port-side runner state for telemetry, injection metering, the
                // Helmholtz telemetry model and the acoustic intake excitation.
                intakeRunnerPressureKpa_[index] = exchange.networkPressurePa * 0.001;
                intakePortTemperatureK_[index] = exchange.networkTemperatureK;
                intakePortDensityKgPerM3_[index] = exchange.networkDensityKgPerM3;
                intakePortSpeedOfSoundMps_[index] = exchange.networkSpeedOfSoundMps;
                // The port sits at the duct inlet, where positive axial
                // velocity points from the valve toward the plenum; the column
                // velocity TOWARD the cylinder is therefore its negation.
                intakeValveColumnVelocityMps_[index] = -exchange.networkVelocityMps;
        };
        const auto advanceIntakeRunnerFor = [&](std::size_t index,
                                                double halfStepSeconds,
                                                bool firstHalf) noexcept {
            {
                const auto openIntakeValve = multirateIntake
                    ? intakeAveragedValveConductanceM2[index] > 0.0
                    : intakeValveAreaM2[index] > 0.0;
                const auto durationSeconds = openIntakeValve
                    ? halfStepSeconds
                    : (firstHalf ? 0.0 : halfStepSeconds * 2.0);
                if (!(durationSeconds > 0.0)) return;
                auto& network = *intakeRunnerNetworks_[index];
                const auto intakePathIndex =
                    intakePathIndexByCylinder_[index];
                const gasdynamics::CylinderValveBoundary boundary {
                    config_.cylinders[index].id,
                    multirateIntake
                        ? intakeAveragedBoundaryState[index]
                        : networkStateForGasCell(cylinderGas_[index]),
                    multirateIntake
                        ? intakeAveragedBoundaryVolumeM3[index]
                        : cylinderGas_[index].volumeM3(),
                    multirateIntake
                        ? intakeAveragedValveConductanceM2[index]
                        : intakeValveAreaM2[index],
                    multirateIntake
                        ? 1.0 : intakeValveDischargeCoefficient[index],
                };
                const gasdynamics::ExhaustAmbientBoundary plenumReservoir {
                    plenumBoundaryState[index], 1.0,
                    intakePlenumGas_[intakePathIndex].volumeM3() };
                observeIntakeSplitReservoir(index, boundary, firstHalf, openIntakeValve);
                const auto advance = network.advance(durationSeconds,
                    std::span<const gasdynamics::CylinderValveBoundary>(&boundary, 1),
                    plenumReservoir);
                intakeNetworkAcceptedSubsteps[index] += advance.acceptedSubsteps;
                intakeNetworkRejectedSubsteps[index] += advance.rejectedSubsteps;
                intakeNetworkAdvancedSeconds[index] += advance.advancedTimeSeconds;
                auto& diagnostic = intakeStepDiagnostics[index];
                diagnostic.maximumAcceptedStableStepRatio = std::max(
                    diagnostic.maximumAcceptedStableStepRatio,
                    advance.maximumAcceptedStableStepRatio);
                diagnostic.maximumAcceptedDuctCourantCurrent = std::max(
                    diagnostic.maximumAcceptedDuctCourantCurrent,
                    advance.maximumAcceptedDuctCourantCurrent);
                diagnostic.maximumAcceptedDuctCourantPredictor = std::max(
                    diagnostic.maximumAcceptedDuctCourantPredictor,
                    advance.maximumAcceptedDuctCourantPredictor);
                if (!advance.completed) intakePhaseFailed[index] = 1;
                const auto& exchange = network.cylinderExchanges().front();
                recordIntakeCylinderExchange(index, boundary, exchange,
                    network.mixtureModel(), firstHalf, openIntakeValve, advance.completed);
                // Held for the serial phase below rather than applied here: the
                // shared plenum is the one thing in this body that is not
                // cylinder-private.
                pendingPlenumDelta[index] = plenumDeltaForMouthSample(
                    network.outletSamples().front(),
                    intakePlenumGas_[intakePathIndex]);
                intakePhaseProducedDelta[index] = 1;
            }
        };
        // Runs `body(i)` for every cylinder, possibly concurrently. The body
        // must write only state private to `i`; see CylinderWorkerPool.
        const auto runIntakePhaseOverRange =
            [&](std::size_t begin, std::size_t end, const auto& body) noexcept {
                using BodyType = std::decay_t<decltype(body)>;
                if (!intakeWorkerPool_) {
                    for (std::size_t index = begin; index < end; ++index) body(index);
                    return;
                }
                intakeWorkerPool_->runIndexRange(begin, end,
                    [](void* context, std::size_t index) noexcept {
                        (*static_cast<const BodyType*>(context))(index);
                    },
                    const_cast<void*>(static_cast<const void*>(&body)));
            };
        // Every cylinder in one concurrent group must read ONE plenum state,
        // and choosing it is the whole difficulty of running these advances in
        // parallel. The serial loop this replaces was Gauss-Seidel: cylinder 0
        // saw the plenum untouched, cylinder 7 saw it after seven draws.
        //
        // Simply freezing the plenum -- plain Jacobi -- is not an acceptable
        // substitute. Measured, it settles the stationary manifold pressure
        // 0.62 kPa BELOW ambient and stays there; twenty times the settling
        // time recovers 0.06 kPa of it, so it is a wrong fixed point and not
        // slow relaxation. `EngineLab.Core`'s stationary-pressure invariant
        // catches it, as does `EngineLab.CatalogPhysics`.
        //
        // What is done instead: the drawdown staircase is reconstructed from a
        // SAME-INSTANT prediction of each cylinder's draw
        // (`predictOutletTransfer`). Deviations from ambient on that invariant,
        // against +0.0004 kPa for the serial reference it stands in for:
        //
        //   frozen plenum (plain Jacobi)              -0.62    kPa
        //   staircase from the PREVIOUS pass's draws   0.17    kPa, oscillating
        //   every cylinder at the midpoint draw       -0.095   kPa
        //   same-instant staircase, one-stage          -0.0109 kPa
        //   same-instant staircase, Heun, two rounds   +0.0011 kPa   shipped
        //
        // The lag result is the one worth remembering. The correction is only
        // ~0.04% of plenum mass, and lagging it by one half-sub-step still
        // installs a permanent 0.17 kPa limit cycle where the serial reference
        // is flat to 0.002 kPa -- because the terminal runner cell's acoustic
        // response time, volume/(mouth area * c), is about 89 us against a
        // 26 us lag. Nothing this pass reads may be stale.
        //
        // `intakePredictionGroupCount_` is the escape hatch if a future engine
        // needs more accuracy than the iteration gives: a group reads a plenum
        // already carrying the ACTUAL transfers of every group before it and
        // predicts only within itself, so one group per cylinder is the old
        // serial scheme exactly, at the cost of all the concurrency.
        // Applies one group's plenum transfers, serially and in cylinder order,
        // so the plenum's floating-point reduction is fixed however the phase
        // that produced them was scheduled.
        const auto commitGroup = [&](std::size_t begin, std::size_t end) noexcept {
            for (std::size_t index = begin; index < end; ++index) {
                if (intakePhaseFailed[index] != 0)
                    state_.solverResolutionLimited = true;
                if (intakePhaseProducedDelta[index] == 0) continue;
                const auto path = intakePathIndexByCylinder_[index];
                if (!intakePlenumGas_[path].tryApplyInventoryDelta(
                        pendingPlenumDelta[index])) {
                    state_.solverResolutionLimited = true;
                    ++state_.intakePlenumTransferFailures;
                }
            }
        };
        const auto advanceIntakeRunners = [&](double halfStepSeconds,
                                              bool firstHalf) noexcept {
            const auto cylinderCount = config_.cylinders.size();
            for (std::size_t index = 0; index < cylinderCount; ++index) {
                intakePhaseFailed[index] = 0;
                intakePhaseProducedDelta[index] = 0;
            }
            // Sub-rated duct wall exchange keeps its shared second-half
            // trigger. The joint policy advances all paths in both halves;
            // the historical separate-runner first half advances only open
            // intake valves. A shared trigger also keeps legacy wall bursts
            // together instead of scattering them across worker dispatches.
            if (!firstHalf) {
                intakeWallHeatPendingSeconds_ += halfStepSeconds * 2.0;
                if (intakeWallHeatPendingSeconds_
                        >= intakeWallHeatUpdateIntervalSeconds_) {
                    intakeWallHeatPendingSeconds_ = 0.0;
                    auto& wallNetworks = jointIntakeManifold() ? intakeManifoldNetworks_ : intakeRunnerNetworks_;
                    for (auto& network : wallNetworks)
                        if (network) network->requestWallHeatUpdate();
                }
            }
            if (jointIntakeManifold()) {
                // All runner mouths on a path share ONE finite plenum in both
                // RK stages. Timely half-step exchange feeds the next piston
                // work increment; no drawdown staircase or delayed gas history
                // is needed by the production policy. Paths run one per
                // worker as in the forward flush; the engine-wide counters
                // are gathered after, in path order.
                std::array<std::uint8_t, 32> pathResolutionLimited {};
                std::array<std::uint32_t, 32> pathPlenumTransferFailures {};
                const auto advanceJointPath = [&](std::size_t path) noexcept {
                    auto& pointer = intakeManifoldNetworks_[path];
                    if (!pointer) return;
                    auto& network = *pointer;
                    std::array<gasdynamics::CylinderValveBoundary, 32> boundaries {};
                    std::array<std::size_t, 32> cylinderIndices {};
                    const auto portCount = network.layout().cylinderPorts().size();
                    for (std::size_t index = 0; index < config_.cylinders.size(); ++index) {
                        if (intakePathIndexByCylinder_[index] != path) continue;
                        const auto port = intakeRunnerPortIndex_[index];
                        cylinderIndices[port] = index;
                        boundaries[port] = {
                            config_.cylinders[index].id,
                            multirateIntake ? intakeAveragedBoundaryState[index]
                                : networkStateForGasCell(cylinderGas_[index]),
                            multirateIntake ? intakeAveragedBoundaryVolumeM3[index]
                                : cylinderGas_[index].volumeM3(),
                            multirateIntake ? intakeAveragedValveConductanceM2[index]
                                : intakeValveAreaM2[index],
                            multirateIntake ? 1.0 : intakeValveDischargeCoefficient[index],
                        };
                        observeIntakeSplitReservoir(index, boundaries[port], firstHalf,
                            boundaries[port].effectiveValveAreaM2 > 0.0);
                    }
                    const auto advance = network.advance(halfStepSeconds,
                        std::span<const gasdynamics::CylinderValveBoundary>(boundaries.data(), portCount),
                        { networkStateForGasCell(intakePlenumGas_[path]), 1.0,
                            intakePlenumGas_[path].volumeM3() });
                    const auto anchor = cylinderIndices[0];
                    intakeNetworkAcceptedSubsteps[anchor] += advance.acceptedSubsteps;
                    intakeNetworkRejectedSubsteps[anchor] += advance.rejectedSubsteps;
                    intakeNetworkAdvancedSeconds[anchor] += advance.advancedTimeSeconds;
                    auto& diagnostic = intakeStepDiagnostics[anchor];
                    diagnostic.maximumAcceptedStableStepRatio = std::max(
                        diagnostic.maximumAcceptedStableStepRatio, advance.maximumAcceptedStableStepRatio);
                    diagnostic.maximumAcceptedDuctCourantCurrent = std::max(
                        diagnostic.maximumAcceptedDuctCourantCurrent, advance.maximumAcceptedDuctCourantCurrent);
                    diagnostic.maximumAcceptedDuctCourantPredictor = std::max(
                        diagnostic.maximumAcceptedDuctCourantPredictor, advance.maximumAcceptedDuctCourantPredictor);
                    if (!advance.completed) pathResolutionLimited[path] = 1;
                    const auto exchanges = network.cylinderExchanges();
                    for (std::size_t port = 0; port < portCount; ++port) {
                        recordIntakeCylinderExchange(cylinderIndices[port], boundaries[port], exchanges[port],
                            network.mixtureModel(), firstHalf, boundaries[port].effectiveValveAreaM2 > 0.0,
                            advance.completed);
                        if (intakePhaseFailed[cylinderIndices[port]] != 0) pathResolutionLimited[path] = 1;
                    }
                    GasInventoryDelta plenumDelta {};
                    for (const auto& mouth : network.outletSamples()) {
                        const auto delta = plenumDeltaForMouthSample(mouth, intakePlenumGas_[path]);
                        plenumDelta.mixture.oxygenMoles += delta.mixture.oxygenMoles;
                        plenumDelta.mixture.inertMoles += delta.mixture.inertMoles;
                        plenumDelta.mixture.fuelMoles += delta.mixture.fuelMoles;
                        plenumDelta.mixture.burnedMoles += delta.mixture.burnedMoles;
                        plenumDelta.internalEnergyJ += delta.internalEnergyJ;
                    }
                    // This is the sole external plenum commit. Its virtual RK
                    // reservoir is not part of network.inventory().
                    const auto nonzeroPlenumDelta = plenumDelta.internalEnergyJ != 0.0
                        || plenumDelta.mixture.oxygenMoles != 0.0 || plenumDelta.mixture.inertMoles != 0.0
                        || plenumDelta.mixture.fuelMoles != 0.0 || plenumDelta.mixture.burnedMoles != 0.0;
                    if (nonzeroPlenumDelta && !intakePlenumGas_[path].tryApplyInventoryDelta(plenumDelta)) {
                        pathResolutionLimited[path] = 1;
                        ++pathPlenumTransferFailures[path];
                    }
                };
                if (intakePathsConcurrent()) {
                    intakeWorkerPool_->runIndices(intakePlenumCount_,
                        [](void* context, std::size_t path) noexcept {
                            (*static_cast<const decltype(advanceJointPath)*>(context))(path);
                        },
                        const_cast<void*>(static_cast<const void*>(&advanceJointPath)));
                } else {
                    for (std::size_t path = 0; path < intakePlenumCount_; ++path) advanceJointPath(path);
                }
                for (std::size_t path = 0; path < intakePlenumCount_; ++path) {
                    if (pathResolutionLimited[path] != 0) state_.solverResolutionLimited = true;
                    state_.intakePlenumTransferFailures += pathPlenumTransferFailures[path];
                }
                return;
            }
            const auto groupCount = std::min(cylinderCount,
                std::max<std::size_t>(1, intakePredictionGroupCount_));
            const auto groupStride = (cylinderCount + groupCount - 1) / groupCount;
            for (std::size_t begin = 0; begin < cylinderCount; begin += groupStride) {
                const auto end = std::min(cylinderCount, begin + groupStride);
                // A group of one has no staircase to reconstruct: it reads the
                // committed plenum, which IS what the serial Gauss-Seidel loop
                // gave it. Engines too small for the worker pool fall entirely
                // into this branch and keep the original scheme exactly, at the
                // original cost -- predicting for them would be pure overhead,
                // and it measured as one (the CP2 twin lost 14% of its capacity
                // to a staircase it has no use for).
                if (end - begin <= 1) {
                    plenumBoundaryState[begin] = networkStateForGasCell(
                        intakePlenumGas_[intakePathIndexByCylinder_[begin]]);
                    advanceIntakeRunnerFor(begin, halfStepSeconds, firstHalf);
                    commitGroup(begin, end);
                    continue;
                }
                // Round 0 starts every prediction from the committed plenum.
                for (std::size_t index = begin; index < end; ++index)
                    plenumBoundaryState[index] =
                        networkStateForGasCell(
                            intakePlenumGas_[intakePathIndexByCylinder_[index]]);
                // The staircase is a fixed point: cylinder i should read the
                // plenum after the cylinders before it drew, but how much they
                // draw depends on what THEY read. Iterating converges on it
                // fast -- each round cut the stationary-manifold deviation by
                // about an order of magnitude (-0.056 kPa after one round,
                // against 0.0004 for the serial reference).
                //
                // Phase A of each round is concurrent because a prediction
                // touches only its own duct; phase B is serial but arithmetic
                // only. Doing phase A serially instead was measured and
                // rejected: it handed Amdahl a serial term of the same order as
                // the parallel advance it exists to order, and cost the V8 a
                // third of the parallelism it had just gained.
                for (std::size_t round = 0; round < intakeStaircaseRounds_; ++round) {
                    runIntakePhaseOverRange(begin, end, [&](std::size_t index) noexcept {
                        predictedPlenumDrawValid[index] = 0;
                        const auto openIntakeValve = multirateIntake
                            ? intakeAveragedValveConductanceM2[index] > 0.0
                            : intakeValveAreaM2[index] > 0.0;
                        const auto durationSeconds = openIntakeValve
                            ? halfStepSeconds
                            : (firstHalf ? 0.0 : halfStepSeconds * 2.0);
                        if (!(durationSeconds > 0.0)) return;
                        const auto predicted =
                            intakeRunnerNetworks_[index]->predictOutletTransfer(0,
                                { plenumBoundaryState[index], 1.0 }, durationSeconds);
                        if (!predicted) return;
                        predictedPlenumDraw[index] = *predicted;
                        predictedPlenumDrawValid[index] = 1;
                    });
                    // Phase B, serial and cheap. The scratch starts from the
                    // real plenum, which already carries every earlier group's
                    // committed transfer.
                    for (std::size_t path = 0; path < intakePlenumCount_; ++path)
                        plenumStaircaseScratch_[path] = intakePlenumGas_[path];
                    for (std::size_t index = begin; index < end; ++index) {
                        const auto path = intakePathIndexByCylinder_[index];
                        plenumBoundaryState[index] =
                            networkStateForGasCell(plenumStaircaseScratch_[path]);
                        // A missing prediction just leaves the staircase where
                        // it is. It cannot break conservation: nothing outside
                        // this pre-pass reads the scratch cell, and the real
                        // plenum only ever receives real transfers.
                        if (predictedPlenumDrawValid[index] == 0) continue;
                        (void)plenumStaircaseScratch_[path].tryApplyInventoryDelta(
                            plenumDeltaForMouthSample(predictedPlenumDraw[index],
                                plenumStaircaseScratch_[path]));
                    }
                }
                runIntakePhaseOverRange(begin, end,
                    [&](std::size_t index) noexcept {
                        advanceIntakeRunnerFor(index, halfStepSeconds, firstHalf);
                    });
                commitGroup(begin, end);
            }
        };
        // Behind a stopped crank the runners hold still at their plenum's
        // pressure instead of advancing: with every valve shut, the explicit
        // plenum coupling alone grew roundoff about 3.7-fold per 400 us
        // flush, to ±30 to ±70 kPa, and the growth followed the coupling lag
        // (±0.05 to 0.25 kPa at 20 us), so it is numerical.
        const auto settleIntakeRunners = [&]() noexcept {
            if (jointIntakeManifold()) {
                for (std::size_t path = 0; path < intakePlenumCount_; ++path)
                    if (intakeManifoldNetworks_[path] && !intakeManifoldNetworks_[path]->settleAtRest(
                            intakePlenumGas_[path].pressureKpa() * 1'000.0))
                        state_.solverResolutionLimited = true;
            }
            for (std::size_t index = 0; index < config_.cylinders.size(); ++index) {
                const auto plenumKpa =
                    intakePlenumGas_[intakePathIndexByCylinder_[index]].pressureKpa();
                if (!jointIntakeManifold() && !intakeRunnerNetworks_[index]->settleAtRest(plenumKpa * 1'000.0))
                    state_.solverResolutionLimited = true;
                intakeRunnerPressureKpa_[index] = plenumKpa;
                intakeValveColumnVelocityMps_[index] = 0.0;
            }
        };
        // Hands `fraction` of what the forward advance computed for this
        // cylinder (and below, for each plenum) over to the real volume.
        const auto deliverIntakeForward = [&](std::size_t index, double fraction) noexcept {
            auto& pending = intakeForwardPendingExchange_[index];
            auto part = pending;
            for (std::size_t species = 0; species < gasdynamics::gasSpeciesCount; ++species) {
                part.speciesMassKg[species] *= fraction;
                pending.speciesMassKg[species] = fraction >= 1.0
                    ? 0.0 : pending.speciesMassKg[species] - part.speciesMassKg[species];
            }
            part.totalEnergyJ *= fraction;
            part.axialMomentumImpulseNs *= fraction;
            pending.totalEnergyJ = fraction >= 1.0
                ? 0.0 : pending.totalEnergyJ - part.totalEnergyJ;
            pending.axialMomentumImpulseNs = fraction >= 1.0
                ? 0.0 : pending.axialMomentumImpulseNs - part.axialMomentumImpulseNs;
            recordIntakeCylinderExchange(index, {}, part,
                intakeNetworkForCylinder(index).mixtureModel(), false,
                intakeValveAreaM2[index] > 0.0, true);
            if (intakePhaseFailed[index] != 0) state_.solverResolutionLimited = true;
        };
        const auto advanceIntakeForward = [&]() noexcept {
            if (forwardIntakeFlush) {
                intakeWallHeatPendingSeconds_ += forwardNetworkSeconds;
                if (intakeWallHeatPendingSeconds_ >= intakeWallHeatUpdateIntervalSeconds_) {
                    intakeWallHeatPendingSeconds_ = 0.0;
                    for (auto& network : intakeManifoldNetworks_)
                        if (network) network->requestWallHeatUpdate();
                }
                // The paths share nothing (each its own plenum, runners and
                // cylinders), so with the pool they run one per worker; the
                // engine-wide flag is gathered after. Bit-identical.
                std::array<std::uint8_t, 32> pathResolutionLimited {};
                const auto flushIntakePath = [&](std::size_t path) noexcept {
                    auto& pointer = intakeManifoldNetworks_[path];
                    if (!pointer) return;
                    auto& network = *pointer;
                    std::array<gasdynamics::CylinderValveBoundary, 32> boundaries {};
                    std::array<std::size_t, 32> cylinderIndices {};
                    const auto portCount = network.layout().cylinderPorts().size();
                    for (std::size_t index = 0; index < config_.cylinders.size(); ++index) {
                        if (intakePathIndexByCylinder_[index] != path) continue;
                        const auto port = intakeRunnerPortIndex_[index];
                        cylinderIndices[port] = index;
                        auto& boundary = boundaries[port];
                        boundary.cylinderId = config_.cylinders[index].id;
                        boundary.cylinderState = networkStateForGasCell(cylinderGas_[index]);
                        boundary.cylinderVolumeM3 = cylinderGas_[index].volumeM3();
                        boundary.dischargeCoefficient = intakeValveDischargeCoefficient[index];
                        if (exhaustValveAreaM2[index] > 0.0) {
                            boundary.otherOutflowSpeciesKgPerS = exhaustOutflowSpeciesKgPerS_[index];
                            boundary.otherOutflowEnergyW = exhaustOutflowEnergyW_[index];
                        }
                        boundary.cylinderVolumeRateM3PerS = (chamberVolumeAheadM3[index]
                            - boundary.cylinderVolumeM3) / forwardIntervalSeconds;
                        const auto areaNow = intakeValveAreaM2[index];
                        const auto areaAhead = intakeValveAreaAheadM2[index];
                        boundary.effectiveValveAreaM2 = areaNow;
                        if (areaNow > 0.0 && secondsToIntakeClose[index] < forwardIntervalSeconds) {
                            boundary.valveClosesAfterSeconds = secondsToIntakeClose[index];
                            boundary.effectiveValveAreaRateM2PerS = -areaNow
                                / std::max(1.0e-9, secondsToIntakeClose[index]);
                        } else if (areaNow > 0.0) {
                            boundary.effectiveValveAreaRateM2PerS =
                                (areaAhead - areaNow) / forwardIntervalSeconds;
                        } else if (areaAhead > 0.0
                                   && secondsToIntakeOpen[index] < forwardIntervalSeconds) {
                            boundary.valveOpensAfterSeconds = secondsToIntakeOpen[index];
                            boundary.effectiveValveAreaRateM2PerS = areaAhead
                                / std::max(1.0e-9, forwardIntervalSeconds
                                    - secondsToIntakeOpen[index]);
                        }
                    }
                    const auto advance = network.advance(forwardNetworkSeconds,
                        std::span<const gasdynamics::CylinderValveBoundary>(boundaries.data(), portCount),
                        { networkStateForGasCell(intakePlenumGas_[path]), 1.0,
                            intakePlenumGas_[path].volumeM3() });
                    const auto anchor = cylinderIndices[0];
                    intakeNetworkAcceptedSubsteps[anchor] += advance.acceptedSubsteps;
                    intakeNetworkRejectedSubsteps[anchor] += advance.rejectedSubsteps;
                    intakeNetworkAdvancedSeconds[anchor] += advance.advancedTimeSeconds;
                    auto& diagnostic = intakeStepDiagnostics[anchor];
                    diagnostic.maximumAcceptedStableStepRatio = std::max(
                        diagnostic.maximumAcceptedStableStepRatio, advance.maximumAcceptedStableStepRatio);
                    diagnostic.maximumAcceptedDuctCourantCurrent = std::max(
                        diagnostic.maximumAcceptedDuctCourantCurrent, advance.maximumAcceptedDuctCourantCurrent);
                    diagnostic.maximumAcceptedDuctCourantPredictor = std::max(
                        diagnostic.maximumAcceptedDuctCourantPredictor, advance.maximumAcceptedDuctCourantPredictor);
                    if (!advance.completed) pathResolutionLimited[path] = 1;
                    const auto exchanges = network.cylinderExchanges();
                    for (std::size_t port = 0; port < portCount; ++port)
                        intakeForwardPendingExchange_[cylinderIndices[port]] = exchanges[port];
                    GasInventoryDelta plenumDelta {};
                    for (const auto& mouth : network.outletSamples()) {
                        const auto delta = plenumDeltaForMouthSample(mouth, intakePlenumGas_[path]);
                        plenumDelta.mixture.oxygenMoles += delta.mixture.oxygenMoles;
                        plenumDelta.mixture.inertMoles += delta.mixture.inertMoles;
                        plenumDelta.mixture.fuelMoles += delta.mixture.fuelMoles;
                        plenumDelta.mixture.burnedMoles += delta.mixture.burnedMoles;
                        plenumDelta.internalEnergyJ += delta.internalEnergyJ;
                    }
                    intakeForwardPendingPlenumDelta_[path] = plenumDelta;
                };
                if (intakePathsConcurrent()) {
                    intakeWorkerPool_->runIndices(intakePlenumCount_,
                        [](void* context, std::size_t path) noexcept {
                            (*static_cast<const decltype(flushIntakePath)*>(context))(path);
                        },
                        const_cast<void*>(static_cast<const void*>(&flushIntakePath)));
                } else {
                    for (std::size_t path = 0; path < intakePlenumCount_; ++path) flushIntakePath(path);
                }
                for (std::size_t path = 0; path < intakePlenumCount_; ++path)
                    if (pathResolutionLimited[path] != 0) state_.solverResolutionLimited = true;
                intakeForwardRemainingSubsteps_ = forwardIntervalSubsteps;
                intakeForwardClockLeadSeconds_ += forwardNetworkSeconds;
                ++state_.intakeCouplingFlushCount;
                state_.intakeCouplingAdvancedSeconds += forwardNetworkSeconds;
                state_.intakeCouplingMinimumIntervalSeconds =
                    state_.intakeCouplingMinimumIntervalSeconds == 0.0
                    ? forwardIntervalSeconds
                    : std::min(state_.intakeCouplingMinimumIntervalSeconds, forwardIntervalSeconds);
                state_.intakeCouplingMaximumIntervalSeconds = std::max(
                    state_.intakeCouplingMaximumIntervalSeconds, forwardIntervalSeconds);
            }
            if (intakeForwardRemainingSubsteps_ == 0) return;
            // An even share per substep; a cylinder whose valve shuts on this
            // substep takes all it has left, so its trapped charge is complete.
            const auto share = 1.0 / static_cast<double>(intakeForwardRemainingSubsteps_);
            --intakeForwardRemainingSubsteps_;
            intakeForwardClockLeadSeconds_ -= subDt;
            for (std::size_t index = 0; index < config_.cylinders.size(); ++index) {
                intakePhaseFailed[index] = 0;
                deliverIntakeForward(index, intakeCloseForTrappedAir[index] ? 1.0 : share);
            }
            for (std::size_t path = 0; path < intakePlenumCount_; ++path) {
                auto& pending = intakeForwardPendingPlenumDelta_[path];
                auto part = pending;
                part.mixture.oxygenMoles *= share;
                part.mixture.inertMoles *= share;
                part.mixture.fuelMoles *= share;
                part.mixture.burnedMoles *= share;
                part.internalEnergyJ *= share;
                const auto last = share >= 1.0;
                pending.mixture.oxygenMoles = last ? 0.0 : pending.mixture.oxygenMoles - part.mixture.oxygenMoles;
                pending.mixture.inertMoles = last ? 0.0 : pending.mixture.inertMoles - part.mixture.inertMoles;
                pending.mixture.fuelMoles = last ? 0.0 : pending.mixture.fuelMoles - part.mixture.fuelMoles;
                pending.mixture.burnedMoles = last ? 0.0 : pending.mixture.burnedMoles - part.mixture.burnedMoles;
                pending.internalEnergyJ = last ? 0.0 : pending.internalEnergyJ - part.internalEnergyJ;
                const auto nonzero = part.internalEnergyJ != 0.0
                    || part.mixture.oxygenMoles != 0.0 || part.mixture.inertMoles != 0.0
                    || part.mixture.fuelMoles != 0.0 || part.mixture.burnedMoles != 0.0;
                if (nonzero && !intakePlenumGas_[path].tryApplyInventoryDelta(part)) {
                    state_.solverResolutionLimited = true;
                    ++state_.intakePlenumTransferFailures;
                }
            }
        };
        if (forwardIntake) {
            if (valvesSealed) {
                // A stopped crank: nothing still owed crosses a shut valve.
                settleIntakeRunners();
                for (auto& pending : intakeForwardPendingExchange_) {
                    const auto cylinderId = pending.cylinderId;
                    const auto pathIndex = pending.pathIndex;
                    pending = {};
                    pending.cylinderId = cylinderId;
                    pending.pathIndex = pathIndex;
                }
                intakeForwardPendingPlenumDelta_.fill({});
                intakeForwardRemainingSubsteps_ = 0;
                intakeForwardClockLeadSeconds_ = 0.0;
            } else {
                advanceIntakeForward();
            }
        } else {
            // Every-substep coupling keeps the network on the chambers' clock.
            intakeForwardClockLeadSeconds_ = 0.0;
            if (flushIntakeNetworks && !valvesSealed)
                advanceIntakeRunners(intakeAdvanceDurationSeconds * 0.5, true);
        }

        auto configuredOutletConductanceM2 = 0.0;
        for (const auto& outlet : physicalExhaustNetwork.layout().outlets())
            configuredOutletConductanceM2 +=
                outlet.openingAreaM2 * outlet.dischargeCoefficient;
        // Published so the forced-induction block can charge the turbine its
        // real downstream back pressure instead of assuming atmosphere.
        exhaustOutletConductanceM2_ = configuredOutletConductanceM2;
        auto instantaneousOutletOpeningScale = 1.0;
        if (config_.forcedInduction.enabled
            && config_.forcedInduction.type == ForcedInductionType::turbocharger
            && exhaustTurbineFaces_.empty()) {
            const auto turbineAreaM2 = (config_.forcedInduction.turbineFlowAreaMm2
                + state_.wastegateOpening
                    * config_.forcedInduction.wastegateFlowAreaMm2) * 1.0e-6
                * static_cast<double>(std::clamp<std::size_t>(
                    config_.forcedInduction.turbochargerCount, 1, maximumTurbochargers));
            // Turbine throat and downstream system are two restrictions IN
            // SERIES, so their losses add and the effective area is the
            // reciprocal-square-sum, not the smaller of the two. The old `min`
            // made the larger one perfectly invisible. On the shipped geometry
            // the two forms differ by well under one per cent, which is the
            // honest answer: a 700 mm2 turbine throat really does dominate a
            // 4000 mm2 tailpipe, and no amount of tailpipe changes that. What
            // the downstream system does change is the pressure the turbine
            // expands INTO, which is handled with the shaft power above.
            const auto downstream = std::max(1.0e-12,
                configuredOutletConductanceM2);
            const auto seriesAreaM2 = 1.0 / std::sqrt(
                1.0 / (turbineAreaM2 * turbineAreaM2)
                + 1.0 / (downstream * downstream));
            instantaneousOutletOpeningScale =
                std::clamp(seriesAreaM2 / downstream, 0.0, 1.0);
        }
        exhaustCouplingDurationSeconds_ += subDt;
        outletOpeningScaleTimeIntegralSeconds_ +=
            instantaneousOutletOpeningScale * subDt;
        for (std::size_t index = 0; index < config_.cylinders.size(); ++index) {
            exhaustValveConductanceTimeIntegralM2S_[index] +=
                exhaustValveAreaM2[index] * exhaustValveDischargeCoefficient[index] * subDt;
            const auto boundaryState = scavengedNetworkStateForGasCell(
                cylinderGas_[index],
                scavengeMixedFraction(scavengeStates_[index]));
            auto& stateIntegral = exhaustBoundaryStateTimeIntegral_[index];
            for (std::size_t species = 0; species < gasdynamics::gasSpeciesCount; ++species) {
                stateIntegral.speciesMassDensityKgPerM3[species] +=
                    boundaryState.speciesMassDensityKgPerM3[species] * subDt;
            }
            stateIntegral.momentumDensityKgPerM2S +=
                boundaryState.momentumDensityKgPerM2S * subDt;
            stateIntegral.totalEnergyDensityJPerM3 +=
                boundaryState.totalEnergyDensityJPerM3 * subDt;
            exhaustBoundaryVolumeTimeIntegralM3S_[index] +=
                cylinderGas_[index].volumeM3() * subDt;
        }

        // Duration-based flush, deliberately NOT forced at the end of the
        // frame: see the accumulator members in the header. The interval is a
        // MAXIMUM: flush now if one more substep would exceed it. Flushing on
        // the substep nearest the target instead let the interval run half a
        // substep past it, and the stride flipped between one and two
        // substeps whenever the crank-angle step crossed ~2/3 of the cap: on
        // the Merlin, 82 us substeps against the 125 us cap coupled every
        // 164 us for single frames, and the valve flow zigzagged at the
        // mechanical Nyquist inside those frames.
        const auto flushExhaustNetwork = exhaustCouplingDurationSeconds_ + subDt
            > maximumExhaustCouplingSeconds * (1.0 + 1.0e-9);
        auto exhaustNetworkCompleted = true;
        auto exhaustAdvanceDurationSeconds = 0.0;
        auto outletMassKg = 0.0;
        auto outletFuelKg = 0.0;
        auto cylinderFuelOutKg = 0.0;
        auto publishExhaustAcousticState = false;
        exhaustFuelReactionScratch_ = {};
        auto& exhaustFuelReaction = exhaustFuelReactionScratch_;
        std::array<std::uint8_t, 32> exhaustExchangeApplied {};
        exhaustExchangeApplied.fill(1);
        if (flushExhaustNetwork) {
            // This knot interval is observed, not inferred by rounding a
            // requested period against a constant mechanical grid.
            state_.exhaustCouplingFrequencyHz = 1.0 / exhaustCouplingDurationSeconds_;
            if (options_.resetExhaustToAmbientEachCoupling.value_or(false)) {
                const auto reset = physicalExhaustNetwork.reset(
                    config_.ambientPressureKpa * 1'000.0,
                    config_.ambientTemperatureC + 273.15);
                if (!reset) state_.solverResolutionLimited = true;
            }
            std::array<gasdynamics::CylinderValveBoundary, 32> averagedBoundaries {};
            const auto cylinderPorts = physicalExhaustNetwork.layout().cylinderPorts();
            for (std::size_t portIndex = 0; portIndex < cylinderPorts.size(); ++portIndex) {
                const auto index = exhaustNetworkCylinderIndex_[portIndex];
                auto averagedState = exhaustBoundaryStateTimeIntegral_[index];
                for (auto& speciesDensity : averagedState.speciesMassDensityKgPerM3)
                    speciesDensity /= exhaustCouplingDurationSeconds_;
                averagedState.momentumDensityKgPerM2S /= exhaustCouplingDurationSeconds_;
                averagedState.totalEnergyDensityJPerM3 /= exhaustCouplingDurationSeconds_;
                averagedBoundaries[portIndex] = {
                    cylinderPorts[portIndex].cylinderId,
                    averagedState,
                    exhaustBoundaryVolumeTimeIntegralM3S_[index]
                        / exhaustCouplingDurationSeconds_,
                    exhaustValveConductanceTimeIntegralM2S_[index]
                        / exhaustCouplingDurationSeconds_,
                    1.0,
                };
            }
            const gasdynamics::ExhaustAmbientBoundary ambient {
                physicalExhaustAmbientState_,
                outletOpeningScaleTimeIntegralSeconds_ / exhaustCouplingDurationSeconds_,
            };
            // The turbine and its wastegate in parallel, as one face per
            // collector; the gate's share of the gas does no work.
            const auto turbineAreaM2 = std::max(0.0,
                config_.forcedInduction.turbineFlowAreaMm2) * 1.0e-6;
            const auto gateAreaM2 = std::clamp(state_.wastegateOpening, 0.0, 1.0)
                * std::max(0.0, config_.forcedInduction.wastegateFlowAreaMm2) * 1.0e-6;
            const auto wheelShare = turbineAreaM2 + gateAreaM2 > 0.0
                ? turbineAreaM2 / (turbineAreaM2 + gateAreaM2) : 0.0;
            if (state_.exhaustValveCount != 0)
                static_cast<void>(physicalExhaustNetwork.setExhaustValveOpening(
                    state_.exhaustValveOpening));
            for (const auto& face : exhaustTurbineFaces_) {
                static_cast<void>(physicalExhaustNetwork.setRestrictionOpeningAreaM2(
                    face.interfaceIndex, (turbineAreaM2 + gateAreaM2) * face.turbochargerShare));
                static_cast<void>(physicalExhaustNetwork.setRestrictionTurbine(
                    face.interfaceIndex, wheelShare,
                    config_.forcedInduction.turbineEfficiency));
            }
            const auto networkAdvance = physicalExhaustNetwork.advance(
                exhaustCouplingDurationSeconds_,
                std::span<const gasdynamics::CylinderValveBoundary>(
                    averagedBoundaries.data(), cylinderPorts.size()),
                ambient);
            exhaustNetworkCompleted = networkAdvance.completed;
            if (networkAdvance.completed) ++completedExhaustCouplingAdvances;
            if (!exhaustTurbineFaces_.empty() && networkAdvance.advancedTimeSeconds > 0.0) {
                std::array<double, maximumTurbochargers> workJ {};
                auto outletPressureKpa = 0.0;
                for (const auto& face : exhaustTurbineFaces_) {
                    workJ[face.turbocharger] += physicalExhaustNetwork.restrictionWorkJ(face.interfaceIndex);
                    const auto& outlet = physicalExhaustNetwork.layout()
                        .interfaces()[face.interfaceIndex].downstream;
                    outletPressureKpa += face.cylinderShare * 0.001
                        * physicalExhaustNetwork.duct(outlet.elementIndex)
                            .cellPrimitives().front().pressurePa;
                }
                for (std::size_t turbocharger = 0; turbocharger < maximumTurbochargers; ++turbocharger)
                    networkTurbinePowerW_[turbocharger] = workJ[turbocharger] / networkAdvance.advancedTimeSeconds;
                networkTurbineOutletPressureKpa_ = outletPressureKpa;
                // The EGT probe at the turbine inlet: the gas beside each face.
                auto inletTemperatureK = 0.0;
                auto inletShare = 0.0;
                for (const auto& face : exhaustTurbineFaces_) {
                    const auto& inlet = physicalExhaustNetwork.layout()
                        .interfaces()[face.interfaceIndex].upstream;
                    auto temperatureK = 0.0;
                    if (inlet.type == gasdynamics::ExhaustEndpointType::junction) {
                        if (const auto primitive = physicalExhaustNetwork.mixtureModel().primitiveFromConservative(
                                physicalExhaustNetwork.junctionState(inlet.elementIndex)))
                            temperatureK = primitive->temperatureK;
                    } else {
                        const auto cells = physicalExhaustNetwork.duct(inlet.elementIndex).cellPrimitives();
                        if (!cells.empty())
                            temperatureK = inlet.type == gasdynamics::ExhaustEndpointType::ductOutlet
                                ? cells.back().temperatureK : cells.front().temperatureK;
                    }
                    if (!(temperatureK > 0.0) || !std::isfinite(temperatureK)) continue;
                    inletTemperatureK += face.cylinderShare * temperatureK;
                    inletShare += face.cylinderShare;
                }
                constexpr double egtProbeRatePerSecond = 2.0;
                if (inletShare > 0.0)
                    state_.turbineInletTemperatureC = smooth(state_.turbineInletTemperatureC,
                        inletTemperatureK / inletShare - 273.15, networkAdvance.advancedTimeSeconds,
                        egtProbeRatePerSecond);
            }
            exhaustAdvanceDurationSeconds = networkAdvance.advancedTimeSeconds;
            exhaustNetworkAcceptedSubsteps += networkAdvance.acceptedSubsteps;
            exhaustNetworkAdvancedSeconds += networkAdvance.advancedTimeSeconds;
            state_.exhaustNetworkMaximumAcceptedStepRatio = std::max(
                state_.exhaustNetworkMaximumAcceptedStepRatio,
                networkAdvance.maximumAcceptedStableStepRatio);
            state_.exhaustNetworkMaximumCourantCurrent = std::max(
                state_.exhaustNetworkMaximumCourantCurrent,
                networkAdvance.maximumAcceptedDuctCourantCurrent);
            state_.exhaustNetworkMaximumCourantPredictor = std::max(
                state_.exhaustNetworkMaximumCourantPredictor,
                networkAdvance.maximumAcceptedDuctCourantPredictor);
            if (!networkAdvance.completed) state_.solverResolutionLimited = true;
            // Chemistry and an audible afterfire have different operating
            // contracts. Hot trace HC must keep oxidising while a reaction
            // model is enabled; otherwise normal running accumulates an
            // artificial fuel reservoir. Compact acoustic events and afterfire
            // telemetry, however, belong only to a requested overrun or wet
            // limiter window. Closed-throttle DFCO remains true across the
            // pulse's OFF windows, so a transported slug continues reacting
            // after injection closes; a wet hard limiter likewise stays enabled
            // across its alternating spark phases.
            // Anti-lag armed runs the reaction model too; working, it is
            // an afterfire window: its late flames and unlit charges burn in
            // the manifold, before the turbine.
            const auto exhaustReactionModelEnabled =
                afterfireRetainsFuel(config_.exhaustAfterfire.strategy)
                || config_.ignition.limiterKeepsFuel
                || ecuCommand.antiLagArmed;
            const auto exhaustReactionOperatingState =
                (afterfireRetainsFuel(config_.exhaustAfterfire.strategy)
                    && ecuCommand.decelerationFuelCutActive)
                || (config_.ignition.limiterKeepsFuel
                    && (ecuCommand.wetSparkCutActive
                        || ecuCommand.hardRevLimiterActive))
                || ecuCommand.antiLagActive;
            if (networkAdvance.completed
                && exhaustReactionModelEnabled) {
                // Named assignments are intentional. This public chemistry
                // contract contains only doubles, so a positional aggregate
                // would still compile while silently reinterpreting every
                // trailing value whenever a new coefficient is inserted.
                gasdynamics::ExhaustFuelReactionConfig reactionConfig;
                reactionConfig.ignitionTemperatureK =
                    config_.exhaustAfterfire.ignitionTemperatureK;
                reactionConfig.reactionTimeConstantSeconds =
                    config_.exhaustAfterfire.reactionTimeConstantSeconds;
                reactionConfig.reactionEfficiency =
                    config_.exhaustAfterfire.reactionEfficiency;
                reactionConfig.oxygenMolesPerFuelMole =
                    config_.fuelProperties.oxygenMolesPerFuelMole;
                reactionConfig.fuelMolarMassKg =
                    config_.fuelProperties.molarMassGramsPerMole * 0.001;
                reactionConfig.lowerHeatingValueJPerKg =
                    config_.fuelProperties.lowerHeatingValueMjPerKg
                        * 1'000'000.0;
                reactionConfig.inductionTimeSeconds =
                    config_.exhaustAfterfire.inductionTimeSeconds;
                reactionConfig.inductionReferencePressureKpa =
                    config_.exhaustAfterfire.inductionReferencePressureKpa;
                reactionConfig.inductionActivationTemperatureK =
                    config_.exhaustAfterfire.inductionActivationTemperatureK;
                reactionConfig.inductionPressureExponent =
                    config_.exhaustAfterfire.inductionPressureExponent;
                reactionConfig.inductionEquivalenceRatioExponent =
                    config_.exhaustAfterfire
                        .inductionEquivalenceRatioExponent;
                reactionConfig.inductionDecayTimeSeconds =
                    config_.exhaustAfterfire.inductionDecayTimeSeconds;
                reactionConfig.minimumEquivalenceRatio =
                    config_.exhaustAfterfire.minimumEquivalenceRatio;
                reactionConfig.maximumEquivalenceRatio =
                    config_.exhaustAfterfire.maximumEquivalenceRatio;
                // Anti-lag's manifold holds 700-1,300 K gas, where the
                // room-temperature rich limit (1.80) left a cut charge
                // mixed with a rich firing's products unlit (2JZ lift,
                // phi 1.85-2.0 before the turbine; journal 2026-11-14).
                // The backfire's chemistry is closed and keeps it.
                reactionConfig.richLimitWideningPerK =
                    ecuCommand.antiLagArmed ? zabetakisRichLimitWideningPerK : 0.0;
                reactionConfig.quenchTemperatureK =
                    config_.exhaustAfterfire.quenchTemperatureK;
                reactionConfig.pocketMixingTimeSeconds =
                    config_.exhaustAfterfire.pocketMixingTimeSeconds;
                for (std::size_t index = 0; index < std::min(
                         config_.cylinders.size(), pendingUnburnedPockets_.size());
                     ++index) {
                    auto& pocket = pendingUnburnedPockets_[index];
                    if (pocket.lightsResident) {
                        pocket.lightsResident = false;
                        if (exhaustReactionOperatingState)
                            physicalExhaustNetwork.igniteUnburnedPockets(
                                config_.cylinders[index].id);
                    }
                    if (!pocket.pending) continue;
                    pocket.pending = false;
                    if (exhaustReactionOperatingState)
                        physicalExhaustNetwork.emitUnburnedPocket(
                            config_.cylinders[index].id, pocket.fuelKg,
                            pocket.oxygenKg, pocket.temperatureK,
                            reactionConfig);
                }
                exhaustFuelReaction = physicalExhaustNetwork.reactUnburnedFuel(
                    networkAdvance.advancedTimeSeconds,
                    reactionConfig);
                if (exhaustReactionOperatingState) {
                    frameReactingExhaustControlVolumes +=
                        exhaustFuelReaction.reactingControlVolumes;
                    frameWallIgnitedExhaustControlVolumes +=
                        exhaustFuelReaction.wallIgnitedControlVolumes;
                    frameMaximumAfterfireInductionIntegral = std::max(
                        frameMaximumAfterfireInductionIntegral,
                        exhaustFuelReaction.maximumInductionIntegral);
                    if (exhaustFuelReaction.minimumInductionDelaySeconds > 0.0) {
                        frameMinimumAfterfireInductionDelaySeconds =
                            frameMinimumAfterfireInductionDelaySeconds > 0.0
                            ? std::min(frameMinimumAfterfireInductionDelaySeconds,
                                exhaustFuelReaction.minimumInductionDelaySeconds)
                            : exhaustFuelReaction.minimumInductionDelaySeconds;
                    }
                    frameMaximumAfterfireInductionDelaySeconds = std::max(
                        frameMaximumAfterfireInductionDelaySeconds,
                        exhaustFuelReaction.maximumInductionDelaySeconds);
                } else {
                    // A hot exhaust oxidises trace HC during loaded running;
                    // disabling chemistry until lift-off accumulated tens of
                    // seconds of artificial inventory and then presented it as
                    // one long afterfire roar. Keep the conservative species
                    // and energy update, but do not label its quasi-steady
                    // housekeeping heat as an overrun event or publish it to
                    // the high-band acoustic queue. The next genuine slug then
                    // starts from the physical inventory that actually remains.
                    exhaustFuelReaction = {};
                }
            }

            // Boundary/media states are consumed only at the renderer's block
            // boundary (187.5 Hz at 48 kHz/256). Publishing them at every
            // ~8 kHz solver coupling rebuilt and copied the complete duct array
            // dozens of times before any consumer could observe it. Reaction
            // sources remain losslessly coupling-rate: any non-empty source
            // forces an immediate packet.
            constexpr double acousticStatePublishIntervalSeconds = 1.0 / 240.0;
            const auto projectedTimeSeconds =
                state_.simulationTimeSeconds + subDt;
            publishExhaustAcousticState = exhaustAcousticSamples_
                && (exhaustAcousticEveryCoupling_
                    || exhaustFuelReaction.sourceCount > 0
                    || lastExhaustAcousticStatePublishSeconds_ < 0.0
                    || projectedTimeSeconds
                        - lastExhaustAcousticStatePublishSeconds_
                        >= acousticStatePublishIntervalSeconds
                            - 0.5 * subDt);

            const auto cylinderExchanges = physicalExhaustNetwork.cylinderExchanges();
            for (std::size_t exchangeIndex = 0;
                 exchangeIndex < cylinderExchanges.size(); ++exchangeIndex) {
                const auto& exchange = cylinderExchanges[exchangeIndex];
                const auto index = exhaustNetworkCylinderIndex_[exchangeIndex];
                const auto applied = cylinderGas_[index].tryApplyInventoryDelta(
                    cylinderDeltaForExchange(exchange, cylinderGas_[index]));
                exhaustExchangeApplied[index] = static_cast<std::uint8_t>(applied);
                if (!applied) state_.solverResolutionLimited = true;
                if (applied && networkAdvance.advancedTimeSeconds > 0.0
                        && flushIntakeNetworks && multirateIntake && !valvesSealed
                        && intakeAveragedValveConductanceM2[index] > 0.0) {
                    // The second intake half follows this accepted exhaust
                    // operator, at the same averaged volume and conductance.
                    if (!carryCylinderExchange(intakeAveragedBoundaryState[index],
                            intakeAveragedBoundaryVolumeM3[index], exchange,
                            intakeNetworkForCylinder(index).mixtureModel()))
                        state_.solverResolutionLimited = true;
                }
                if (applied && networkAdvance.advancedTimeSeconds > 0.0
                        && intakeExpectedSecondHalfReservoir
                        && (*intakeExpectedSecondHalfReservoir)[index].valid) {
                    // The intervening exhaust operator changes the same finite
                    // cylinder that will supply the second intake half. Observe
                    // its accepted increment at the original averaged volume.
                    auto& expected = (*intakeExpectedSecondHalfReservoir)[index];
                    double absoluteTransferredMassKg = 0.0;
                    for (std::size_t species = 0;
                         species < gasdynamics::gasSpeciesCount; ++species) {
                        expected.speciesMassKg[species] -= exchange.speciesMassKg[species];
                        absoluteTransferredMassKg += std::abs(exchange.speciesMassKg[species]);
                    }
                    expected.internalEnergyJ -= exchange.totalEnergyJ;
                    if (absoluteTransferredMassKg > 0.0) {
                        ++expected.interveningExhaustObservationCount;
                        expected.absoluteInterveningExhaustTransferredMassKg +=
                            absoluteTransferredMassKg;
                    }
                }
                exhaustFlowMgThisCycle_[index] += exchange.totalMassKg() * 1.0e6;
                if (applied)
                    cylinderFuelOutKg += exchange.speciesMassKg[
                        static_cast<std::size_t>(gasdynamics::GasSpecies::fuel)];
                if (applied && networkAdvance.advancedTimeSeconds > 0.0) {
                    const auto inverseSeconds = 1.0 / networkAdvance.advancedTimeSeconds;
                    for (std::size_t species = 0;
                         species < gasdynamics::gasSpeciesCount; ++species)
                        exhaustOutflowSpeciesKgPerS_[index][species] =
                            exchange.speciesMassKg[species] * inverseSeconds;
                    exhaustOutflowEnergyW_[index] = exchange.totalEnergyJ * inverseSeconds;
                }
            }
            for (const auto& outlet : physicalExhaustNetwork.outletSamples()) {
                auto transferredMassKg = 0.0;
                for (const auto speciesMassKg : outlet.speciesMassKg)
                    transferredMassKg += speciesMassKg;
                outletMassKg += std::max(0.0, transferredMassKg);
                outletFuelKg += outlet.speciesMassKg[static_cast<std::size_t>(gasdynamics::GasSpecies::fuel)];
            }
            // Publish the acoustic medium of each duct, not just of the valve.
            // The waveguide's delays, wall/liner losses and radiation state all
            // read the local gas state, and it varies by hundreds of kelvin
            // between the port and the tailpipe.
            if (publishExhaustAcousticState) {
                exhaustDuctMediumCount_ = std::min(physicalExhaustNetwork.ductCount(),
                    ExhaustAcousticSample::maximumDucts);
                for (std::size_t index = 0;
                     index < exhaustDuctMediumCount_; ++index) {
                    auto densityKgPerM3 = 0.0;
                    auto speedOfSoundMps = 0.0;
                    if (!physicalExhaustNetwork.duct(index).meanAcousticMedium(
                            densityKgPerM3, speedOfSoundMps)) {
                        // Leave the previous sample in place rather than publish
                        // a zero the renderer would have to special-case.
                        continue;
                    }
                    exhaustDuctDensityKgPerM3_[index] =
                        static_cast<float>(densityKgPerM3);
                    exhaustDuctSpeedOfSoundMps_[index] =
                        static_cast<float>(speedOfSoundMps);
                }
            }

            exhaustValveConductanceTimeIntegralM2S_.fill(0.0);
            exhaustBoundaryStateTimeIntegral_.fill({});
            exhaustBoundaryVolumeTimeIntegralM3S_.fill(0.0);
            exhaustCouplingDurationSeconds_ = 0.0;
            outletOpeningScaleTimeIntegralSeconds_ = 0.0;
        }

        // Symmetric intake split around the exhaust coupling. This remains at
        // mechanical cadence even on substeps where the slower network state is
        // held, so valve overlap and trapped charge are never decimated.
        if (flushIntakeNetworks) {
            if (valvesSealed)
                settleIntakeRunners();
            else
                advanceIntakeRunners(intakeAdvanceDurationSeconds * 0.5, false);
            if (multirateIntake) {
                intakeBoundaryStateTimeIntegral_.fill({});
                intakeBoundaryVolumeTimeIntegralM3S_.fill(0.0);
                intakeValveConductanceTimeIntegralM2S_.fill(0.0);
                intakeCouplingDurationSeconds_ = 0.0;
            }
        }
        for (std::size_t index = 0; index < config_.cylinders.size(); ++index) {
            // The stagnation head the arriving column carries, published as a
            // diagnostic. The velocity is now the RESOLVED port state of the
            // 1-D runner — the duct carries the column's momentum, so the ram
            // this head used to approximate is delivered by the solver itself,
            // and IVC trapping is irreversible for the physical reason: the
            // wave is still arriving when the valve shuts.
            // Only a column travelling toward the cylinder carries a charging
            // head; reversion has its own (adverse) direction.
            const auto towardCylinderMps =
                std::max(0.0, intakeValveColumnVelocityMps_[index]);
            intakePortRamKpa_[index] = std::min(
                0.5 * intakePortDensityKgPerM3_[index]
                    * towardCylinderMps * towardCylinderMps * 0.001,
                config_.runnerAcoustics.maximumPressureAmplitudeKpa);
            if (intakeCloseForTrappedAir[index]) {
                trappedAirMassMgLastCycle_[index] = cylinderGas_[index]
                    .mixture().oxygenMoles / 0.21 * GasCell::airMolarMassKg
                        * 1.0e6;
                const auto intakePathIndex =
                    intakePathIndexByCylinder_[index];
                trappedAirSourcePressureKpaLastCycle_[index] =
                    intakePlenumGas_[intakePathIndex].pressureKpa();
                trappedAirSourceTemperatureKLastCycle_[index] =
                    intakePlenumGas_[intakePathIndex].temperatureK();
            }
            const auto finalChamberPressureKpa = cylinderGas_[index].pressureKpa();
            chamberPressureBar_[index] = finalChamberPressureKpa / 100.0;
            // The cycle's peak is published when the cylinder opens into its
            // gas exchange (bottom of the expansion stroke), where the
            // pressure is low, so no firing peak straddles two cycles. A
            // two-stroke's is the half cycle from bottom dead centre.
            const auto inGasExchange = twoStroke ? previousCylinderPhases_[index] >= 180.0
                                                 : gasExchangeStrokeForWork[index];
            if (inGasExchange && !inGasExchange_[index]) {
                lastCyclePeakPressureKpa_[index] = cyclePeakPressureKpa_[index];
                cyclePeakPressureKpa_[index] = 0.0;
            }
            inGasExchange_[index] = inGasExchange;
            cyclePeakPressureKpa_[index] = std::max(cyclePeakPressureKpa_[index], finalChamberPressureKpa);
            IndicatedWorkModel::advance(indicatedWorkStates_[index],
                finalChamberPressureKpa, chamberVolumeLitresForWork[index],
                config_.ambientPressureKpa, cycleBoundaryForWork[index],
                gasExchangeStrokeForWork[index], exhaustStrokeForWork[index]);
            const auto torqueCorrection = (finalChamberPressureKpa
                    - chamberPressureBeforeNetworkKpa[index]) * 1'000.0
                * pistonAreaM2ForSplit[index] * gasTorqueLeverArmM[index];
            if (decoupleSharedVolumes)
                parallelState->scratch[index].gasIndicatedTorque += torqueCorrection;
            else
                gasIndicatedTorque += torqueCorrection;
        }

        // Publish the instantaneous valve-plane Riemann flow after both split
        // operators. This preserves signed high-rate thermoacoustic forcing even
        // though conservative low-band state exchange is deliberately multirate.
        std::array<gasdynamics::CylinderValveBoundary, 32> instantaneousBoundaries {};
        const auto cylinderPorts = physicalExhaustNetwork.layout().cylinderPorts();
        for (std::size_t portIndex = 0; portIndex < cylinderPorts.size(); ++portIndex) {
            const auto index = exhaustNetworkCylinderIndex_[portIndex];
            instantaneousBoundaries[portIndex] = {
                cylinderPorts[portIndex].cylinderId,
                scavengedNetworkStateForGasCell(cylinderGas_[index],
                    scavengeMixedFraction(scavengeStates_[index])),
                cylinderGas_[index].volumeM3(),
                exhaustValveAreaM2[index],
                exhaustValveDischargeCoefficient[index],
            };
        }
        std::array<gasdynamics::CylinderBoundaryFlowSample, 32> boundarySamples {};
        const auto sampled = physicalExhaustNetwork.sampleCylinderBoundaries(
            std::span<const gasdynamics::CylinderValveBoundary>(
                instantaneousBoundaries.data(), cylinderPorts.size()),
            std::span<gasdynamics::CylinderBoundaryFlowSample>(
                boundarySamples.data(), physicalExhaustNetwork.layout().cylinderPorts().size()));
        collectorPressureKpa = config_.ambientPressureKpa;
        if (!sampled) state_.solverResolutionLimited = true;
        for (std::size_t portIndex = 0;
             portIndex < physicalExhaustNetwork.layout().cylinderPorts().size(); ++portIndex) {
            const auto index = exhaustNetworkCylinderIndex_[portIndex];
            const auto& sample = boundarySamples[portIndex];
            if (sampled) {
                // The network state behind this sample is only new on a flush
                // substep. Record it as a knot of the boundary's time history
                // rather than publishing it directly: publishing it on every
                // substep would hold it flat between flushes, which is a
                // zero-order hold clocked at the coupling rate and lands in the
                // audible band. See ExhaustNetworkBoundary.
                if (flushExhaustNetwork) {
                    exhaustBoundaryKnots_[index][exhaustBoundaryKnotWrite_] = {
                        sample.networkPressurePa * 0.001,
                        sample.networkVelocityMps,
                        sample.networkTemperatureK,
                        sample.massFlowKgPerSecond,
                        sample.networkDensityKgPerM3,
                        sample.networkSpeedOfSoundMps,
                        state_.simulationTimeSeconds,
                        true,
                    };
                }
                // Reconstruct the boundary at one constant delay behind now,
                // interpolated between whichever knots bracket that instant.
                // See exhaustBoundaryKnots_ for why the delay must not follow
                // the current coupling interval. The delay exceeds the longest
                // interval (the 250 us low-speed cap plus slack), so a
                // bracketing pair exists whenever the ring holds history;
                // until then the reconstruction holds the nearest knot, which
                // only occurs while the network itself is still priming.
                const auto targetTimeSeconds = state_.simulationTimeSeconds
                    - exhaustBoundaryReconstructionDelaySeconds;
                const auto& ring = exhaustBoundaryKnots_[index];
                const auto newestSlot = flushExhaustNetwork
                    ? exhaustBoundaryKnotWrite_
                    : (exhaustBoundaryKnotWrite_ + exhaustBoundaryKnotCount - 1)
                        % exhaustBoundaryKnotCount;
                const auto* before = &ring[newestSlot];
                const auto* after = &ring[newestSlot];
                for (std::size_t age = 0; age < exhaustBoundaryKnotCount; ++age) {
                    const auto slot = (newestSlot + exhaustBoundaryKnotCount - age)
                        % exhaustBoundaryKnotCount;
                    if (!ring[slot].valid) break;
                    before = &ring[slot];
                    if (ring[slot].timeSeconds <= targetTimeSeconds) break;
                    after = &ring[slot];
                }
                const auto knotInterval = after->timeSeconds - before->timeSeconds;
                const auto phase = knotInterval > 0.0
                    ? std::clamp((targetTimeSeconds - before->timeSeconds)
                        / knotInterval, 0.0, 1.0)
                    : 1.0;
                const auto& from = *before;
                const auto& to = *after;
                const auto blend = [phase](double a, double b) {
                    return a + (b - a) * phase;
                };
                exhaustRunnerPressureKpa_[index] = blend(from.pressureKpa, to.pressureKpa);
                exhaustRunnerVelocityMps_[index] = blend(from.velocityMps, to.velocityMps);
                exhaustRunnerTemperatureK_[index] = blend(from.temperatureK, to.temperatureK);
                exhaustPortDensityKgPerM3[index] =
                    blend(from.densityKgPerM3, to.densityKgPerM3);
                exhaustPortSpeedOfSoundMps[index] =
                    blend(from.speedOfSoundMps, to.speedOfSoundMps);
                // Two mass flows, deliberately, because two consumers need
                // different things and one field cannot honestly serve both.
                //
                // The acoustic one is reconstructed with the same phase as the
                // pressure, density and sound speed above. The audio path splits
                // these into characteristics as 0.5*(p' +- Zc*U'), which only
                // means anything if p' and U' describe the same instant of the
                // same field. Blending pressure between two network knots while
                // taking flow from just the latest one leaves a residual of
                // (1 - phase) * (to.p - from.p): a sawtooth clocked at the
                // coupling rate, whose harmonics reach well above the coupling
                // Nyquist and are audible there as images.
                exhaustAcousticMassFlowKgPerSecond[index] =
                    blend(from.massFlowKgPerSecond, to.massFlowKgPerSecond);
                // The instantaneous one is recomputed from the live cylinder
                // state every substep and keeps valve-plane detail the network
                // state does not carry. Mass accounting wants exactly that, and
                // smoothing it would degrade the flow balance, so it stays raw.
                exhaustMassFlowKgPerSecond[index] = sample.massFlowKgPerSecond;
            }
            thermoacousticBoundaryValid[index] = static_cast<std::uint8_t>(sampled
                && sample.valid && exhaustNetworkCompleted
                && exhaustBoundaryKnots_[index][flushExhaustNetwork
                    ? exhaustBoundaryKnotWrite_
                    : (exhaustBoundaryKnotWrite_ + exhaustBoundaryKnotCount - 1)
                        % exhaustBoundaryKnotCount].valid
                && exhaustExchangeApplied[index] != 0);
            collectorPressureKpa = std::max(
                collectorPressureKpa, exhaustRunnerPressureKpa_[index]);
        }
        // The write cursor advances only after every port has recorded its knot
        // for this flush, so all cylinders share one time base.
        if (sampled && flushExhaustNetwork)
            exhaustBoundaryKnotWrite_ = (exhaustBoundaryKnotWrite_ + 1)
                % exhaustBoundaryKnotCount;
        for (std::size_t index = 0; index < config_.cylinders.size(); ++index) {
            if (decoupleSharedVolumes) {
                parallelState->scratch[index].exhaustRunnerPressure +=
                    exhaustRunnerPressureKpa_[index];
                parallelState->scratch[index].exhaustTemperatureK +=
                    exhaustRunnerTemperatureK_[index];
            } else {
                exhaustRunnerPressureSum += exhaustRunnerPressureKpa_[index];
                exhaustTemperatureSumK += exhaustRunnerTemperatureK_[index];
            }
        }
        // Fixed-order reduction of the per-cylinder scratch. Small engines retain
        // their original serial sum; large-engine output is independent of worker
        // scheduling because the same cylinder order is always used here.
        if (decoupleSharedVolumes) {
            for (std::size_t index = 0; index < config_.cylinders.size(); ++index)
                accumulateContribution(parallelState->scratch[index]);
            // The per-cylinder pass no longer touches the shared plenum: the
            // plenum <-> runner exchange is owned by the serial intake network
            // advances, applied in cylinder order, so the N-way Jacobi commit
            // that used to reconcile parallel plenum draws is gone with the
            // lumped orifice it reconciled.
        }

        const auto meanPistonSpeed = pistonSpeedSum / static_cast<double>(config_.cylinders.size());
        const auto displacementM3 = displacement * 0.001;
        // Mean effective pressures are per litre breathed every 720 deg: a
        // rotary's summed faces (1,080 deg each) would load its shaft's
        // bearings 1.5 times a piston engine's of the same air.
        const auto breathedLitres = breathingDisplacementLitres(config_);
        const auto breathedM3 = breathedLitres * 0.001;
        // Lumped non-piston friction MEP (bearings + valvetrain + accessories),
        // a Chen-Flynn-style polynomial in displacement and speed. Piston-skirt
        // and ring friction are NOT in here: they are resolved separately below
        // via stribeckFrictionForce. The two are complementary; their sum tracks
        // the gasoline FMEP band (~0.6 bar idle -> ~2.1 bar redline), verified by
        // the friction-MEP sweep in CoreTests.
        // The base linear term is retained through the low/mid-speed range:
        // increasing it globally made the large, low-revving Merlin marginal
        // on idle catch. A small constant-power accessory/windage term is
        // faded in over 3,500-4,500 rpm: its torque falls with speed.
        // Linear in rpm, with the Stribeck piston below the sum follows
        // Sandoval's revision of Patton-Nitschke-Heywood (MIT 2002, SAE
        // 2003-01-0725) within 0.1-0.3 bar on a K20A to 8,000 rpm and a
        // CBR1000RR-R to 14,500. A 3.5e-8 rpm^2 term and a 1.5e-4 per rpm above
        // 4,000 (added for "underestimated high-rpm losses" under the
        // constant-gamma gas) charged them 0.36 and 1.12 bar over it at their
        // power points: removed (journal 2026-11-04).
        const auto accessoryRampLinear = std::clamp(
            (state_.rpm - 3'500.0) / 1'000.0, 0.0, 1.0);
        const auto accessoryRamp = accessoryRampLinear * accessoryRampLinear
            * (3.0 - 2.0 * accessoryRampLinear);
        const auto highSpeedAccessoryTorque =
            state_.angularVelocityRadPerSecond > 1.0
            ? breathedLitres * 200.0 * accessoryRamp
                / state_.angularVelocityRadPerSecond
            : 0.0;
        const auto bearingFriction = state_.rpm > 1.0
            ? breathedLitres * (1.4 + config_.frictionCoefficient * 10.0
                              + state_.rpm * 0.00055)
                + highSpeedAccessoryTorque
            : 0.0;
        const auto pistonFriction = state_.angularVelocityRadPerSecond > 1.0
            ? pistonFrictionPowerW / state_.angularVelocityRadPerSecond
            : pistonBreakawayTorqueNm;
        const auto seizureTorque = state_.damage >= 1.0 ? displacement * 250.0
            + state_.angularVelocityRadPerSecond * 0.22 : 0.0;
        double crankshaftFriction = 0.0;
        for (const auto& crankshaft : config_.crankshafts)
            crankshaftFriction += crankshaft.frictionTorqueNm * std::abs(crankshaft.rotationRatio);
        const auto superchargerTorque = config_.forcedInduction.enabled
            && config_.forcedInduction.type == ForcedInductionType::supercharger
            && state_.angularVelocityRadPerSecond > 1.0
            ? state_.compressorPowerKw * 1'000.0 / state_.angularVelocityRadPerSecond : 0.0;
        // A two-stroke has no valvetrain, rolls on needle and ball bearings and
        // carries two compression rings, not a four-stroke's ring pack: the
        // polynomial and the Stribeck rings above put the RD350 at 1.26 bar at
        // 8,000 rpm, 2.8 x Blair's relation for a rolling-bearing motorcycle
        // two-stroke, fmep = 3,150 Pa per m/s of mean piston speed (Design and
        // Simulation of Two-Stroke Engines, 1996, p. 379). It takes Blair's
        // whole relation instead (journal 2026-10-26); the breakaway still
        // holds a crank at rest.
        const auto twoStrokeFriction = state_.angularVelocityRadPerSecond > 1.0
            ? 3'150.0 * meanPistonSpeed * displacementM3 / (2.0 * std::numbers::pi)
            : pistonBreakawayTorqueNm;
        const auto mechanicalFriction = (twoStroke ? twoStrokeFriction : bearingFriction + pistonFriction)
            + crankshaftFriction + superchargerTorque;
        // Gas-pressure torque already contains the complete intake/exhaust
        // pumping loop. Adding a MAP-derived pumping loss here counted the
        // same work twice, especially at closed throttle.
        const auto frictionTorque = mechanicalFriction + seizureTorque;
        constexpr double maximumBrakeMeanEffectivePressurePa = 2'500'000.0;
        const auto loadTorque = state_.rpm > 40.0 && !safeControls.starterEngaged
            ? (safeControls.dynamometerTorqueNm > 0.0
                ? safeControls.dynamometerTorqueNm
                : safeControls.load * maximumBrakeMeanEffectivePressurePa * breathedM3
                    / (4.0 * std::numbers::pi))
            : 0.0;
        // Automotive starters deliver high reduction torque at cranking speed;
        // this must overcome resolved compression peaks, not only mean friction.
        // A real starter is sized against the PEAK single-cylinder compression
        // torque, which scales with per-cylinder displacement, not with total
        // displacement: a 6.5 L five-cylinder radial fights 1.3 L compression
        // peaks spaced 144 deg apart, a far harder duty than a 6.2 L V8's
        // 0.78 L peaks every 90 deg. The old total-displacement sizing was
        // implicitly calibrated against the lumped intake's under-filled
        // cranking charges; with the resolved runners filling properly, the
        // radial's first full compression pinned a 383 Nm starter at zero for
        // 3.4 s (measured: -1087 Nm at the crank, decaying only through wall
        // heat loss because the no-reverse clamp forbids the rock-back a real
        // crank uses to get over compression).
        const auto perCylinderDisplacement = displacement
            / static_cast<double>(std::max<std::size_t>(1, config_.cylinders.size()));
        const auto starterPeakTorque = 45.0 + displacement * 52.0
            + perCylinderDisplacement * 350.0;
        const auto starterTorque = cranking ? starterPeakTorque * std::clamp(1.0 - state_.rpm / 760.0, 0.18, 1.0) : 0.0;
        const auto normalizedCombustionPulse = std::clamp(combustionPulseSum * 8.0
            / static_cast<double>(config_.cylinders.size()), 0.0, 2.8);
        const auto modeledIndicatedTorque = combustion.indicatedTorqueNm * normalizedCombustionPulse;
        // The conservative chamber-pressure solution is authoritative from the
        // first substep. Cranking torque fills/compresses the real control
        // volumes; no elapsed-time switch can fabricate startup work.
        const auto indicatedTorque = std::isfinite(gasIndicatedTorque) ? gasIndicatedTorque : 0.0;
        constexpr double pressureBlend = 1.0;
        const auto brakeTorque = indicatedTorque - frictionTorque;
        const auto netTorque = brakeTorque + starterTorque - loadTorque
            + safeControls.externalTorqueNm + reciprocatingTorque;

        auto omega = state_.angularVelocityRadPerSecond;
        omega = std::max(0.0, omega
            + netTorque / rotatingInertia * subDt);
        state_.angularVelocityRadPerSecond = omega;
        state_.rpm = omega * 60.0 / (2.0 * std::numbers::pi);
        if (state_.rpm < 0.5 && !cranking && indicatedTorque <= 0.0) {
            state_.rpm = 0.0;
            state_.angularVelocityRadPerSecond = 0.0;
        }
        const auto subTravelled = (subPreviousRpm + state_.rpm) * 0.5 * 6.0 * subDt;
        frameTravelledDegrees += subTravelled;
        frameIntegratedSeconds += subDt;
        maximumIntegratedCrankStep = std::max(maximumIntegratedCrankStep, std::abs(subTravelled));
        cycleNumericalFault_ = cycleNumericalFault_
            || state_.solverResolutionLimited
            || std::abs(subTravelled) > config_.solver.maximumCrankDegreesPerStep + 1.0e-9;
        accumulateCycleTelemetry(subPreviousAngle, subTravelled, subDt,
                                 indicatedTorque, brakeTorque, frame);
        state_.crankAngleDegrees = std::fmod(subPreviousAngle + subTravelled, eventGenerator_.cycleDegrees());
        if (hasVariableValveProfiles_) {
            // A four-stroke's 720 deg or a rotary face's 1,080: a rotary's
            // staged intake ports switch as a cam profile does.
            if (eventGenerator_.cycleDegrees() == 720.0
                || eventGenerator_.cycleDegrees() == 1'080.0) {
                valveProfileShaftCycle_.setPeriod(eventGenerator_.cycleDegrees());
                (void)valveProfileShaftCycle_.advance(subPreviousAngle, state_.crankAngleDegrees,
                    subTravelled, subDt, subPreviousRpm, state_.rpm);
            } else
                valveProfileShaftCycle_.reset(); // Unsupported clocks leave demand unavailable.
            std::uint32_t highCylinders = 0U;
            for (std::size_t index = 0; index < config_.cylinders.size(); ++index)
                if (valveProfileActuators_[index].appliedHigh()) highCylinders |= 1U << index;
            state_.vtecHighCylinderMask = highCylinders;
        }
        state_.simulationTimeSeconds += subDt;

        state_.indicatedTorqueNm = indicatedTorque;
        state_.meanWorkTorqueNm = modeledIndicatedTorque;
        state_.cylinderPressureTorqueNm = gasIndicatedTorque;
        state_.cylinderPressureTorqueBlend = pressureBlend;
        state_.frictionTorqueNm = frictionTorque;
        state_.frictionMeanEffectivePressureBar = breathedM3 > 0.0
            ? frictionTorque * 4.0 * std::numbers::pi / breathedM3 / 100'000.0 : 0.0;
        state_.reciprocatingTorqueNm = reciprocatingTorque;
        state_.meanPistonSpeedMps = meanPistonSpeed;
        state_.loadTorqueNm = loadTorque;
        state_.starterTorqueNm = starterTorque;
        state_.netTorqueNm = netTorque;
        state_.torqueNm = brakeTorque;
        state_.knockLevel = smooth(state_.knockLevel, physicalEndGasKnockLevel, subDt, 65.0);
        const auto misfiringCylinderCount = static_cast<double>(std::count(
            cylinderMisfires_.begin(), cylinderMisfires_.begin()
                + static_cast<std::ptrdiff_t>(config_.cylinders.size()), true));
        state_.misfireRate = smooth(state_.misfireRate,
            misfiringCylinderCount / static_cast<double>(config_.cylinders.size()), subDt, 12.0);
        state_.ignitionAdvanceDegrees = ecuCommand.ignitionAdvanceDegrees;
        const auto physicalAirMassMg = std::accumulate(trappedAirMassMgLastCycle_.begin(),
            trappedAirMassMgLastCycle_.begin()
                + static_cast<std::ptrdiff_t>(config_.cylinders.size()), 0.0);
        const auto ambientTemperatureK = config_.ambientTemperatureC + 273.15;
        const auto referenceAirMassMg = config_.ambientPressureKpa * 1'000.0
            * displacement * 0.001
            / (GasCell::universalGasConstant / GasCell::airMolarMassKg * ambientTemperatureK)
            * 1.0e6;
        state_.airMassMgPerCycle = state_.rpm > 20.0 ? physicalAirMassMg : 0.0;
        if (compressionIgnitionEngine) {
            const auto smokeBoundaryAfr = std::max(
                config_.fuelProperties.stoichiometricAirFuelRatio * 1.16,
                ecuCommand.targetAirFuelRatio);
            const auto idleFuelDemand =
                (safeControls.ignitionEnabled || safeControls.starterEngaged)
                ? ecuCommand.idleAirOpening * 0.20 : 0.0;
            const auto fuelDemand = std::clamp(std::max(
                state_.throttle, idleFuelDemand), 0.0, 1.0);
            const auto quantityLimitedFuelMassMg =
                dieselFullLoadFuelLimitMg * fuelDemand
                * static_cast<double>(config_.cylinders.size());
            // Diesel pedal demand is a fuel-quantity command. When its torque
            // limiter asks for less fuel than the smoke boundary permits, the
            // effective AFR target is leaner by design. Reporting only the
            // smoke boundary made a healthy high-rpm quantity taper look like
            // a 60 percent fuelling error in the application and harness.
            const auto quantityLimitedAfr =
                quantityLimitedFuelMassMg > 1.0e-9
                    && std::isfinite(quantityLimitedFuelMassMg)
                ? state_.airMassMgPerCycle / quantityLimitedFuelMassMg
                : smokeBoundaryAfr;
            state_.targetAirFuelRatio = std::max(
                smokeBoundaryAfr, quantityLimitedAfr);
        } else {
            state_.targetAirFuelRatio = ecuCommand.targetAirFuelRatio;
        }
        state_.inductedChargeMassMgPerCycle = std::accumulate(
            intakeFlowMgPerCycle_.begin(),
            intakeFlowMgPerCycle_.begin()
                + static_cast<std::ptrdiff_t>(config_.cylinders.size()), 0.0);
        state_.volumetricEfficiency = state_.rpm > 20.0
            ? std::clamp(physicalAirMassMg / std::max(1.0, referenceAirMassMg), 0.0, 2.5) : 0.0;
        const auto deliveredAirMassMg = std::accumulate(deliveredAirMgPerCycle_.begin(),
            deliveredAirMgPerCycle_.begin()
                + static_cast<std::ptrdiff_t>(config_.cylinders.size()), 0.0);
        state_.deliveredAirMassMgPerCycle = state_.rpm > 20.0 ? deliveredAirMassMg : 0.0;
        state_.deliveredVolumetricEfficiency = state_.rpm > 20.0
            ? std::clamp(deliveredAirMassMg / std::max(1.0, referenceAirMassMg), 0.0, 2.5) : 0.0;
        const auto meteredFuelMoles = std::accumulate(meteredFuelMolesLastCycle_.begin(),
            meteredFuelMolesLastCycle_.begin()
                + static_cast<std::ptrdiff_t>(config_.cylinders.size()), 0.0);
        state_.injectedFuelMgPerCycle = ecuCommand.fuelEnabled
            ? meteredFuelMoles * config_.fuelProperties.molarMassGramsPerMole * 1'000.0 : 0.0;
        const auto deliveredFuelMoles = std::accumulate(deliveredFuelMolesLastCycle_.begin(),
            deliveredFuelMolesLastCycle_.begin()
                + static_cast<std::ptrdiff_t>(config_.cylinders.size()), 0.0);
        state_.deliveredFuelMgPerCycle = ecuCommand.fuelEnabled
            ? deliveredFuelMoles * config_.fuelProperties.molarMassGramsPerMole * 1'000.0 : 0.0;
        auto actualAfrFuelMassSumMg = 0.0;
        auto fuelWeightedAfrSum = 0.0;
        auto allAfrObservationsValid = !config_.cylinders.empty();
        for (std::size_t index = 0; index < config_.cylinders.size(); ++index) {
            allAfrObservationsValid = allAfrObservationsValid
                && actualAfrValidLastCycle_[index];
            if (!actualAfrValidLastCycle_[index]) continue;
            const auto fuelMassMg =
                actualAfrFuelMassMgLastCycle_[index];
            actualAfrFuelMassSumMg += fuelMassMg;
            fuelWeightedAfrSum += actualAfrLastCycle_[index] * fuelMassMg;
        }
        state_.airFuelRatioValid = allAfrObservationsValid
            && actualAfrFuelMassSumMg > 1.0e-12;
        if (state_.airFuelRatioValid) {
            state_.airFuelRatio = fuelWeightedAfrSum
                / actualAfrFuelMassSumMg;
            state_.lambda = state_.airFuelRatio
                / config_.fuelProperties.stoichiometricAirFuelRatio;
        }
        const auto totalMeteredFuelMassKg = meteredFuelMassKg
            + std::exchange(carburettorFuelMassKgThisStep_, 0.0)
            + std::exchange(nitrousFuelMassKgThisStep_, 0.0);
        const auto meteredFuelFlowGramsPerSecond =
            totalMeteredFuelMassKg / subDt * 1'000.0;
        state_.fuelFlowGramsPerSecond = smooth(state_.fuelFlowGramsPerSecond,
            meteredFuelFlowGramsPerSecond, subDt, 22.0);
        state_.fuelConsumedGrams += totalMeteredFuelMassKg * 1'000.0;
        state_.fuelConsumedLitres = state_.fuelConsumedGrams * 0.001
            / config_.fuelProperties.densityKgPerL;
        state_.airFlowGramsPerSecond = state_.airMassMgPerCycle
            * (state_.rpm / (cylinderCycleDegrees() / 6.0)) / 1'000.0;
        state_.exhaustPressureKpa = collectorPressureKpa;
        state_.intakeRunnerPressureKpa = intakeRunnerPressureSum / static_cast<double>(config_.cylinders.size());
        state_.exhaustRunnerPressureKpa = exhaustRunnerPressureSum / static_cast<double>(config_.cylinders.size());
        if (exhaustAdvanceDurationSeconds > 0.0) {
            const auto physicalOutletFlowGramsPerSecond = outletMassKg
                / exhaustAdvanceDurationSeconds * 1'000.0;
            state_.exhaustFlowGramsPerSecond = smooth(state_.exhaustFlowGramsPerSecond,
                physicalOutletFlowGramsPerSecond,
                exhaustAdvanceDurationSeconds, 35.0);
            state_.exhaustAfterfireHeatReleaseKw = smooth(
                state_.exhaustAfterfireHeatReleaseKw,
                exhaustFuelReaction.releasedEnergyJoules
                    / exhaustAdvanceDurationSeconds / 1'000.0,
                exhaustAdvanceDurationSeconds, 80.0);
            state_.exhaustAfterfireFuelBurnMgPerSecond = smooth(
                state_.exhaustAfterfireFuelBurnMgPerSecond,
                exhaustFuelReaction.burnedFuelMassKg
                    / exhaustAdvanceDurationSeconds * 1.0e6,
                exhaustAdvanceDurationSeconds, 80.0);
            state_.exhaustFuelBurnBeforeTurbineMgPerSecond = smooth(
                state_.exhaustFuelBurnBeforeTurbineMgPerSecond,
                exhaustFuelReaction.burnedFuelBeforeTurbineMassKg
                    / exhaustAdvanceDurationSeconds * 1.0e6,
                exhaustAdvanceDurationSeconds, 80.0);
            state_.exhaustFuelInMgPerSecond = smooth(state_.exhaustFuelInMgPerSecond,
                cylinderFuelOutKg / exhaustAdvanceDurationSeconds * 1.0e6,
                exhaustAdvanceDurationSeconds, 80.0);
            state_.tailpipeFuelMgPerSecond = smooth(state_.tailpipeFuelMgPerSecond,
                outletFuelKg / exhaustAdvanceDurationSeconds * 1.0e6,
                exhaustAdvanceDurationSeconds, 80.0);
            // Unsmoothed: the wall moves on a tens-of-seconds time constant, so
            // there is nothing here for a filter to remove.
            //
            // This is a max over every exhaust cell and it sits in the SUB-STEP
            // loop, which on this project's critical thread deserves an answer
            // rather than a shrug: ~40 cells against ~160 sub-steps per frame is
            // ~6 us of a 4166 us budget, i.e. 0.15%, and the `inventory()`
            // traversal a few lines below is already more expensive. Sampling a
            // 55 s time constant at 240 Hz would be plenty, so if this block
            // ever moves somewhere cheaper, take this with it.
            state_.exhaustWallTemperatureC =
                physicalExhaustNetwork.peakWallTemperatureK() - 273.15;
        }
        // Zero when nothing reacts, rather than holding the last value. Holding
        // it reads as "the hot-surface path is carrying almost everything"
        // exactly when the answer is "nothing is burning at all", which is the
        // most misleading moment for it to say that -- a null-control run with
        // no retained fuel reported 99.5 % beside a heat release of 0.000 kW.
        state_.exhaustAfterfireWallIgnitedFraction =
            frameReactingExhaustControlVolumes > 0
                ? static_cast<double>(
                      frameWallIgnitedExhaustControlVolumes)
                    / static_cast<double>(
                        frameReactingExhaustControlVolumes)
                : 0.0;
        state_.exhaustAfterfireInductionProgress =
            frameMaximumAfterfireInductionIntegral;
        state_.exhaustAfterfireMinimumInductionDelayMs =
            frameMinimumAfterfireInductionDelaySeconds * 1'000.0;
        state_.exhaustAfterfireMaximumInductionDelayMs =
            frameMaximumAfterfireInductionDelaySeconds * 1'000.0;
        // Read-outs only (the side panel, the instruments, after `step`), each
        // a walk over every gas cell, so taken on the frame's last sub-step:
        // what a caller reads is unchanged. Every sub-step, they were 6 % of
        // a four-cylinder two-stroke's critical thread (journal 2026-11-20).
        const auto finalSubstepOfFrame = remainingSteps == 1;
        if (finalSubstepOfFrame) {
            state_.manifoldGasMassGrams = 0.0;
            state_.cylinderGasMassGrams = 0.0;
            state_.gasInternalEnergyJoules = 0.0;
            for (std::size_t pathIndex = 0; pathIndex < intakePlenumCount_; ++pathIndex) {
                state_.manifoldGasMassGrams += intakePlenumGas_[pathIndex].massKg() * 1'000.0;
                state_.gasInternalEnergyJoules += intakePlenumGas_[pathIndex].internalEnergyJoules();
            }
            state_.gasInternalEnergyJoules += physicalExhaustNetwork.inventory().totalEnergyJ;
            for (std::size_t index = 0; index < config_.cylinders.size(); ++index) {
                state_.cylinderGasMassGrams += cylinderGas_[index].massKg() * 1'000.0;
                state_.gasInternalEnergyJoules += cylinderGas_[index].internalEnergyJoules()
                    + (ownsIntakeRunner(index) ? intakeDuctForCylinder(index).inventory().totalEnergyJ : 0.0);
            }
        }
        state_.powerKw = state_.torqueNm * state_.angularVelocityRadPerSecond / 1'000.0;
        state_.brakeSpecificFuelConsumptionGPerKwh = state_.cycleAveragedPowerKw > 1.0
            ? state_.fuelFlowGramsPerSecond * 3'600.0 / state_.cycleAveragedPowerKw : 0.0;
        state_.mechanicalEfficiency = indicatedTorque > 1.0 ? std::clamp(brakeTorque / indicatedTorque, 0.0, 1.0) : 0.0;
        state_.oilPressureKpa = state_.rpm > 0.0
            ? std::clamp(80.0 + state_.rpm * 0.055 - std::max(0.0, state_.oilTemperatureC - 105.0) * 2.0, 0.0, 520.0) : 0.0;
        state_.peakPistonAccelerationG = peakPistonAcceleration / 9.80665;
        state_.peakCylinderPressureBar = 0.0;
        for (std::size_t index = 0; index < config_.cylinders.size(); ++index)
            state_.peakCylinderPressureBar = std::max(state_.peakCylinderPressureBar,
                lastCyclePeakPressureKpa_[index] / 100.0);

        state_.resolvedHeatReleaseKw = releasedEnergyJoules / subDt / 1'000.0;
        const auto exhaustTarget = exhaustTemperatureSumK
            / static_cast<double>(config_.cylinders.size()) - 273.15;
        if (!config_.thermal.regulated) {
            // Sized from the running configuration at every step: a cylinder
            // resize ramp or a settings edit is followed at once.
            const EngineThermalModel thermalModel(config_);
            EngineThermalModel::State thermal { state_.coolantTemperatureC,
                state_.oilTemperatureC, state_.coolingFanOn };
            thermalModel.advance(thermal, { state_.resolvedHeatReleaseKw,
                    mechanicalFriction * state_.angularVelocityRadPerSecond / 1'000.0,
                    std::isfinite(safeControls.coolingAirSpeedMps) ? safeControls.coolingAirSpeedMps : 0.0,
                    state_.rpm, config_.ambientTemperatureC },
                subDt);
            state_.coolantTemperatureC = thermal.coolantTemperatureC;
            state_.oilTemperatureC = thermal.oilTemperatureC;
            state_.coolingFanOn = thermal.fanOn;
        } else {
            state_.coolingFanOn = false;
        }
        state_.exhaustTemperatureC = smooth(state_.exhaustTemperatureC, exhaustTarget, subDt, 0.18);
        if (exhaustTurbineFaces_.empty()) state_.turbineInletTemperatureC = state_.exhaustTemperatureC;
        // Over-revving is measured against the limiter the ECU applies now,
        // with 2 % for its own overshoot: under its own power the engine
        // stays there, only a driven engine (a missed downshift) goes past.
        // The redline is a display mark. The piston-acceleration term below
        // remains the physical cap whatever the limiter is set to.
        const auto overrevReferenceRpm = 1.02 * (state_.activeRevLimitRpm > 0.0
            ? state_.activeRevLimitRpm : config_.ignition.revLimitRpm);
        const auto overrev = std::max(0.0, state_.rpm / overrevReferenceRpm - 1.0);
        const auto oilStarvation = state_.rpm > 800.0 && state_.oilPressureKpa < 90.0 ? 1.0 : 0.0;
        const auto excessivePistonAcceleration = std::max(0.0, state_.peakPistonAccelerationG - 5'500.0) / 5'500.0;
        // Only severe knock (above the 0.45 the diagnostics call severe) wears
        // the engine; full knock keeps its former rate. Counting light knock
        // linearly cost every catalogue engine a permanent 0.3-0.5 % of power
        // per WOT dyno pass: they all sit at a light 0.14-0.37 there, held by
        // the ECU's proportional retard (journal 2026-10-13).
        const auto severeKnock = std::max(0.0, state_.knockLevel - 0.45) / 0.55;
        // A firing pressure over the structural limit loads the head gasket,
        // ring lands and bearings beyond their design: 10 % over takes about
        // 17 min to "damaged", 30 % about 2 min, 50 % about 40 s. The peak is
        // the last completed cycle's, and nothing replaces it once the crank
        // stops: an engine stalled at full load (a dyno brake past its torque)
        // kept its last firing peak and was destroyed standing still. Below
        // the speed at which it fires (220 rpm) it takes no such load.
        const auto overPressure = state_.rpm >= 220.0
            ? std::max(0.0, state_.peakCylinderPressureBar / peakCylinderPressureLimitBar(config_) - 1.0)
            : 0.0;
        const auto damageRate = severeKnock * state_.throttle * 0.0012 + overrev * overrev * 0.022
                              + std::max(0.0, state_.coolantTemperatureC - 115.0) * 0.000025 + oilStarvation * 0.002
                              + excessivePistonAcceleration * excessivePistonAcceleration * 0.002
                              + overPressure * overPressure * 0.05;
        state_.damage = std::clamp(state_.damage + damageRate * subDt, 0.0, 1.0);
        state_.wear = std::clamp(state_.wear + (state_.rpm / config_.redlineRpm * 0.000002 + damageRate * 0.12) * subDt, 0.0, 1.0);
        state_.runningState = determineRunningState(safeControls);
        state_.cylinderStateCount = std::min(config_.cylinders.size(), state_.cylinderStates.size());
        const auto publishedAngularAcceleration = state_.netTorqueNm / rotatingInertia;
        const std::array publishedKinematicsKey {
            std::bit_cast<std::uint64_t>(state_.crankAngleDegrees),
            std::bit_cast<std::uint64_t>(state_.angularVelocityRadPerSecond),
            std::bit_cast<std::uint64_t>(publishedAngularAcceleration),
            cylinderGeometryRevision_ };
        // Writes only cylinder `index`'s published state and cached kinematics,
        // so it runs on the workers wherever the cylinder pass did.
        const auto publishCylinder = [&](std::size_t index) noexcept {
            const auto& cylinder = config_.cylinders[index];
            const auto phase = std::fmod(state_.crankAngleDegrees - crankOffsetDegreesFor(config_, cylinder)
                + phaseWrapBiasDegrees(cylinderCycleDegrees()), cylinderCycleDegrees());
            const auto compressionIgnition =
                config_.fuel == FuelType::diesel;
            const auto active = ((compressionIgnition
                    ? compressionIgnitionStates_[index].active
                    : flameEvents_[index].active)
                || instantaneousCombustionPulse_[index] > 1.0e-9)
                && !cylinderMisfires_[index];
            const auto pulse = active ? instantaneousCombustionPulse_[index] : 0.0;
            const auto& valveTrain = valveTrainResults_[index];
            // A two-stroke has no valves: its ports are in the cylinder wall.
            const auto valves = config_.cycle != EngineCycle::twoStroke;
            const auto intakeLift = valves ? valveTrain.intakeLiftMm : 0.0;
            const auto exhaustLift = valves ? valveTrain.exhaustLiftMm : 0.0;
            const auto& gas = cylinderGas_[index];
            state_.cylinderStates[index] = { cylinder.id, phase,
                chamberPressureBar_[index],
                pulse, cylinderMisfires_[index] ? 1.0 : 0.0,
                intakeLift, exhaustLift, intakeFlowMgPerCycle_[index], exhaustFlowMgPerCycle_[index],
                exhaustRunnerPressureKpa_[index],
                config_.ambientTemperatureC + (state_.exhaustTemperatureC - config_.ambientTemperatureC)
                    * std::clamp(1.0 + cylinder.efficiencyOffset, 0.8, 1.2)
                    + (cylinderWallTemperatureC_[index] - config_.ambientTemperatureC) * 0.18,
                gas.temperatureK() - 273.15, gas.massKg() * 1.0e6,
                gas.mixture().oxygenMoles, gas.mixture().fuelMoles, gas.mixture().burnedMoles,
                intakeValveColumnVelocityMps_[index],
                exhaustRunnerVelocityMps_[index],
                fuelDeliveryRatio_[index],
                injectorCapacityRatio_[index],
                compressionIgnition ? 0.0 : flameEvents_[index].flameSpeedMps,
                compressionIgnition
                    ? compressionIgnitionResults_[index].burnedFraction
                    : flameEvents_[index].burnedFraction,
                compressionIgnition
                    ? compressionIgnitionResults_[index].efficiency
                    : flameEvents_[index].efficiency,
                compressionIgnition
                    ? 0.0 : endGasKnockStates_[index].filteredLevel,
                active, combustion.combustionEnabled && cylinderMisfires_[index] };
            const auto kinematics = evaluateCylinderKinematics(config_, kinematicsReference_, index,
                state_.crankAngleDegrees, state_.angularVelocityRadPerSecond,
                publishedAngularAcceleration);
            cachedKinematics[index] = kinematics;
            auto& cylinderState = state_.cylinderStates[index];
            cylinderState.exhaustValveConductanceAreaM2 =
                exhaustValveAreaM2[index] * exhaustValveDischargeCoefficient[index];
            cylinderState.exhaustMassFlowKgPerSecond =
                exhaustMassFlowKgPerSecond[index];
            cylinderState.trappedFreshAirMassMg =
                trappedAirMassMgLastCycle_[index];
            cylinderState.deliveredFreshAirMassMgPerCycle =
                deliveredAirMgPerCycle_[index];
            cylinderState.intakeRunnerTemperatureC =
                intakePortTemperatureK_[index] - 273.15;
            cylinderState.intakeRunnerChargePressureKpa = intakeRunnerPressureKpa_[index];
            cylinderState.airFuelRatio = actualAfrLastCycle_[index];
            cylinderState.airFuelRatioValid =
                actualAfrValidLastCycle_[index];
            cylinderState.injectorDutyCycle = injectorDutyCycle_[index];
            cylinderState.meteredFuelMgPerCycle =
                meteredFuelMolesLastCycle_[index]
                * config_.fuelProperties.molarMassGramsPerMole * 1'000.0;
            if (finalSubstepOfFrame)
                cylinderState.portFuelVapourInventoryMg =
                    intakeDuctForCylinder(index).inventory().speciesMassKg[
                        static_cast<std::size_t>(
                            gasdynamics::GasSpecies::fuel)] * 1.0e6;
            cylinderState.portLiquidFilmFuelMg =
                injectionStates_[index].liquidFilmMoles
                * config_.fuelProperties.molarMassGramsPerMole * 1'000.0;
            cylinderState.portInjectorFootprintFuelMg =
                portInjectorFootprintFuelMoles_[index]
                * config_.fuelProperties.molarMassGramsPerMole * 1'000.0;
            cylinderState.portInjectorFootprintTargetFuelMg =
                portInjectorFootprintTargetFuelMoles_[index]
                * config_.fuelProperties.molarMassGramsPerMole * 1'000.0;
            cylinderState.combustionCommandAvailable =
                combustionCommandAvailable_[index];
            cylinderState.requestedFuelMgPerCycle = requestedFuelMolesThisCycle_[index]
                * config_.fuelProperties.molarMassGramsPerMole * 1'000.0;
            cylinderState.deliveredFuelMgPerCycle = deliveredFuelMolesLastCycle_[index]
                * config_.fuelProperties.molarMassGramsPerMole * 1'000.0;
            const auto highLoadTrimBlend = std::clamp(
                (state_.throttle - 0.10) / 0.15, 0.0, 1.0);
            cylinderState.closedLoopFuelTrim = std::lerp(
                closedLoopFuelTrim_[index],
                highLoadClosedLoopFuelTrim_[index],
                highLoadTrimBlend);
            cylinderState.residualGasFractionAtSpark = residualGasFractionAtSpark_[index];
            cylinderState.diluentFractionAtSpark = diluentFractionAtSpark_[index];
            cylinderState.equivalenceRatioAtSpark = equivalenceRatioAtSpark_[index];
            cylinderState.endGasPeakTemperatureK = compressionIgnition
                ? 0.0 : endGasKnockStates_[index].lastCyclePeakUnburnedTemperatureK;
            cylinderState.knockPressureRiseBar = compressionIgnition
                ? 0.0 : endGasKnockStates_[index].lastKnockPressureRiseBar;
            cylinderState.pistonTravelMm = kinematics.pistonTravelMm;
            cylinderState.pistonPositionMm = kinematics.pistonPositionMm;
            cylinderState.pistonVelocityMps = kinematics.pistonVelocityMps;
            cylinderState.pistonAccelerationMps2 = kinematics.pistonAccelerationMps2;
            cylinderState.connectingRodAngleDegrees = kinematics.connectingRodAngleDegrees;
            cylinderState.crankPinXMm = kinematics.crankPinXMm;
            cylinderState.crankPinYMm = kinematics.crankPinYMm;
            cylinderState.wristPinXMm = kinematics.wristPinXMm;
            cylinderState.wristPinYMm = kinematics.wristPinYMm;
            cylinderState.mechanicalReactionTorqueNm = kinematics.displacementDerivativeMPerRadian
                * (gas.pressureKpa() - config_.ambientPressureKpa) * 1'000.0
                * std::numbers::pi * std::pow(cylinder.boreMm * 0.0005, 2.0);
            cylinderState.crankshaftId = kinematics.crankshaftId;
            cylinderState.crankJournalId = kinematics.crankJournalId;
            cylinderState.indicatedWorkJoulesPerCycle = indicatedWorkStates_[index].completedCycleJoules;
            const auto totalMoles = gas.totalMoles();
            cylinderState.residualGasFraction = totalMoles > 1.0e-15
                ? gas.mixture().burnedMoles / totalMoles : 0.0;
            cylinderState.intakeValveAdvanceDegrees = valveTrain.intakeAdvanceDegrees;
            cylinderState.exhaustValveAdvanceDegrees = valveTrain.exhaustAdvanceDegrees;
            cylinderState.valveLiftMultiplier = valveTrain.liftMultiplier;
            cylinderState.intakeResonancePressureKpa = runnerAcousticResults_[index].pressureAmplitudeKpa;
            cylinderState.intakeResonanceFrequencyHz = runnerAcousticResults_[index].resonanceFrequencyHz;
            cylinderState.intakePortRamPressureKpa = intakePortRamKpa_[index];
            cylinderState.intakePortColumnVelocityMps = intakeValveColumnVelocityMps_[index];
            cylinderState.compressionIgnition =
                compressionIgnition
                && compressionIgnitionResults_[index].autoIgnited;
            cylinderState.combustionStartPhaseDegrees =
                compressionIgnition
                ? compressionIgnitionResults_[index].startPhaseDegrees
                : -state_.ignitionAdvanceDegrees
                    + cylinder.ignitionOffsetDegrees;
            cylinderState.combustionDurationMs =
                compressionIgnition
                ? compressionIgnitionResults_[index].durationSeconds * 1'000.0
                : (flameEvents_[index].flameSpeedMps > 0.01
                    ? std::clamp(cylinder.boreMm * 0.5
                        / flameEvents_[index].flameSpeedMps, 1.0, 45.0)
                    : 0.0);
            cylinderState.combustionSharpness =
                compressionIgnition
                ? compressionIgnitionResults_[index].sharpness : 0.0;
            cylinderState.directLiquidSprayFuelMg =
                injectionStates_[index].directLiquidSprayMoles
                * config_.fuelProperties.molarMassGramsPerMole * 1'000.0;
            cylinderState.directDispersingFuelMg =
                injectionStates_[index].directDispersingVapourMoles
                * config_.fuelProperties.molarMassGramsPerMole * 1'000.0;
            cylinderState.combustionCycleMultiplier =
                combustionCycleMultiplier_[index];
            cylinderState.commandedSparkEventsLastCycle =
                commandedSparkEventsLastCycle_[index];
            cylinderState.completedIgnitionEventsLastCycle =
                completedIgnitionEventsLastCycle_[index];
            cylinderState.commandedSparkPhaseLastCycle =
                commandedSparkPhaseLastCycle_[index];
            cylinderState.completedIgnitionPhaseLastCycle =
                completedIgnitionPhaseLastCycle_[index];
        };
        // Each index writes its own published state only, so any order gives
        // the same bits; the two-stroke pass's sub-steps publish there too.
        if ((parallelCylinderPass || twoStrokeParallelPass)
                && options_.parallelCylinderPublish.value_or(true)) {
            using PublishCylinder = std::decay_t<decltype(publishCylinder)>;
            intakeWorkerPool_->runIndices(state_.cylinderStateCount,
                [](void* context, std::size_t index) noexcept {
                    (*static_cast<const PublishCylinder*>(context))(index);
                },
                const_cast<void*>(static_cast<const void*>(&publishCylinder)));
        } else {
            for (std::size_t index = 0; index < state_.cylinderStateCount; ++index)
                publishCylinder(index);
        }
        cachedKinematicsKey = publishedKinematicsKey;
        if (publishExhaustAcousticState && flushExhaustNetwork
            && exhaustNetworkCompleted) {
            ExhaustAcousticSample acousticSample;
            acousticSample.timeSeconds = state_.simulationTimeSeconds;
            acousticSample.couplingFrequencyHz =
                state_.exhaustCouplingFrequencyHz;
            const auto copiedReactionSourceCount = std::min(
                exhaustFuelReaction.sourceCount,
                acousticSample.reactionEvents.size());
            acousticSample.reactionEventCount =
                copiedReactionSourceCount;
            acousticSample.droppedReactionEventCount =
                exhaustFuelReaction.droppedSourceCount
                + exhaustFuelReaction.sourceCount
                    - copiedReactionSourceCount;
            for (std::size_t index = 0;
                index < copiedReactionSourceCount; ++index) {
                const auto& source = exhaustFuelReaction.sources[index];
                auto& event = acousticSample.reactionEvents[index];
                event.timeSeconds = state_.simulationTimeSeconds
                    - 0.5 * source.durationSeconds;
                event.nodeId = source.nodeId;
                event.sourceComponentId = source.sourceComponentId;
                event.pathIndex = source.pathIndex;
                event.axialPosition = static_cast<float>(
                    source.axialPosition);
                event.releasedEnergyJoules = static_cast<float>(
                    source.releasedEnergyJoules);
                event.burnedFuelMassKg = static_cast<float>(
                    source.burnedFuelMassKg);
                event.durationSeconds = static_cast<float>(
                    source.durationSeconds);
                event.densityKgPerM3 = static_cast<float>(
                    source.densityKgPerM3);
                event.speedOfSoundMps = static_cast<float>(
                    source.speedOfSoundMps);
                event.flowAreaM2 = static_cast<float>(
                    source.flowAreaM2);
            }
            const auto outletSamples = physicalExhaustNetwork.outletSamples();
            acousticSample.outletCount = std::min(
                outletSamples.size(),
                acousticSample.outletMassFlowKgPerSecond.size());
            for (std::size_t index = 0;
                 index < acousticSample.outletCount; ++index) {
                const auto& outlet = outletSamples[index];
                acousticSample.outletNodeId[index] =
                    outlet.outletNodeId;
                acousticSample.outletPathIndex[index] =
                    static_cast<std::uint8_t>(outlet.pathIndex);
                acousticSample.outletMassFlowKgPerSecond[index] =
                    static_cast<float>(outlet.massFlowKgPerS);
                acousticSample.outletDensityKgPerM3[index] =
                    static_cast<float>(outlet.densityKgPerM3);
                acousticSample.outletSpeedOfSoundMps[index] =
                    static_cast<float>(outlet.speedOfSoundMps);
                acousticSample.outletAreaM2[index] =
                    static_cast<float>(outlet.openingAreaM2);
            }
            acousticSample.ductCount = exhaustDuctMediumCount_;
            for (std::size_t index = 0;
                 index < exhaustDuctMediumCount_; ++index) {
                acousticSample.ductDensityKgPerM3[index] =
                    exhaustDuctDensityKgPerM3_[index];
                acousticSample.ductSpeedOfSoundMps[index] =
                    exhaustDuctSpeedOfSoundMps_[index];
            }
            if (exhaustAcousticSamples_->tryPush(acousticSample)) {
                ++frame.exhaustAcousticSampleCount;
                lastExhaustAcousticStatePublishSeconds_ =
                    state_.simulationTimeSeconds;
            } else {
                ++frame.droppedExhaustAcousticSampleCount;
            }
        }
        if (pressureSamples_) {
            CylinderPressureSample pressureSample;
            pressureSample.timeSeconds = state_.simulationTimeSeconds;
            pressureSample.mechanicalSamplingFrequencyHz = subDt > 0.0
                ? static_cast<float>(1.0 / subDt) : 0.0F;
            pressureSample.cylinderCount = config_.cylinders.size();
            pressureSample.structural.cylinderCount = config_.cylinders.size();
            if (exhaustNetworkCompleted) {
                const auto outletFlows = physicalExhaustNetwork.outletSamples();
                pressureSample.exhaustOutletCount = std::min(
                    outletFlows.size(), CylinderPressureSample::maximumExhaustOutlets);
                for (std::size_t outlet = 0;
                     outlet < pressureSample.exhaustOutletCount; ++outlet) {
                    pressureSample.exhaustOutletVolumeFlowM3PerS[outlet] =
                        static_cast<float>(outletFlows[outlet].volumeFlowM3PerS);
                    pressureSample.exhaustOutletNodeId[outlet] =
                        outletFlows[outlet].outletNodeId;
                    pressureSample.exhaustOutletPathIndex[outlet] =
                        static_cast<std::uint8_t>(outletFlows[outlet].pathIndex);
                }
            }
            pressureSample.intakePathCount = std::min(
                intakePlenumCount_, pressureSample.intakeThrottleConductanceAreaM2.size());
            for (std::size_t path = 0; path < pressureSample.intakePathCount; ++path) {
                pressureSample.intakeThrottleConductanceAreaM2[path] =
                    static_cast<float>(intakeThrottleConductanceAreaM2[path]);
            }
            for (std::size_t index = 0; index < config_.cylinders.size(); ++index) {
                pressureSample.pressureBar[index] = static_cast<float>(chamberPressureBar_[index]);
                const auto pistonRadiusM = config_.cylinders[index].boreMm * 0.0005;
                const auto pistonAreaM2 = std::numbers::pi * pistonRadiusM * pistonRadiusM;
                const auto gasForceN = (chamberPressureBar_[index] * 100.0
                    - config_.ambientPressureKpa) * 1'000.0 * pistonAreaM2;
                const auto inertiaForceN = structuralInertiaForceN[index];
                const auto bearingReactionForceN = gasForceN - inertiaForceN;
                pressureSample.structural.gasForceN[index] = static_cast<float>(gasForceN);
                pressureSample.structural.inertiaForceN[index] = static_cast<float>(inertiaForceN);
                pressureSample.structural.bearingReactionForceN[index] =
                    static_cast<float>(bearingReactionForceN);
                pressureSample.structural.sideThrustForceN[index] = static_cast<float>(
                    bearingReactionForceN * structuralSideRatio[index]);
                pressureSample.structural.crankReactionTorqueNm[index] = static_cast<float>(
                    bearingReactionForceN * gasTorqueLeverArmM[index]);
                // Port-end (valve-side) state of the 1-D runner, refreshed by
                // the intake network advances earlier in this substep.
                pressureSample.intakeMassFlowKgPerSecond[index] = static_cast<float>(
                    instantaneousIntakeTransferredMassKg[index] / subDt);
                pressureSample.intakeRunnerPressureKpa[index] = static_cast<float>(
                    intakeRunnerPressureKpa_[index]);
                pressureSample.intakeRunnerDensityKgPerM3[index] = static_cast<float>(
                    intakePortDensityKgPerM3_[index]);
                pressureSample.intakeRunnerSpeedOfSoundMps[index] = static_cast<float>(
                    intakePortSpeedOfSoundMps_[index]);
                pressureSample.intakeValveConductanceAreaM2[index] = static_cast<float>(
                    intakeValveAreaM2[index] * intakeValveDischargeCoefficient[index]);
                pressureSample.intakePathIndex[index] =
                    static_cast<std::uint8_t>(
                        intakePathIndexByCylinder_[index]);
                pressureSample.exhaustRunnerPressureKpa[index] = static_cast<float>(exhaustRunnerPressureKpa_[index]);
                // The valve's flow and conductance at the boundary's delay,
                // interpolated between the substeps that bracket it: see
                // valveFlowHistory_.
                auto& history = valveFlowHistory_[index];
                history[valveFlowHistoryWrite_] = {
                    state_.simulationTimeSeconds,
                    exhaustMassFlowKgPerSecond[index],
                    exhaustValveAreaM2[index] * exhaustValveDischargeCoefficient[index],
                    true,
                };
                const auto delayedTimeSeconds = state_.simulationTimeSeconds
                    - exhaustBoundaryReconstructionDelaySeconds;
                const auto* valveBefore = &history[valveFlowHistoryWrite_];
                const auto* valveAfter = valveBefore;
                for (std::size_t age = 0; age < exhaustBoundaryKnotCount; ++age) {
                    const auto slot = (valveFlowHistoryWrite_ + exhaustBoundaryKnotCount - age)
                        % exhaustBoundaryKnotCount;
                    if (!history[slot].valid) break;
                    valveBefore = &history[slot];
                    if (history[slot].timeSeconds <= delayedTimeSeconds) break;
                    valveAfter = &history[slot];
                }
                const auto valveInterval = valveAfter->timeSeconds - valveBefore->timeSeconds;
                const auto valvePhase = valveInterval > 0.0
                    ? std::clamp((delayedTimeSeconds - valveBefore->timeSeconds) / valveInterval, 0.0, 1.0)
                    : 1.0;
                pressureSample.exhaustMassFlowKgPerSecond[index] = static_cast<float>(
                    valveBefore->massFlowKgPerSecond
                    + (valveAfter->massFlowKgPerSecond - valveBefore->massFlowKgPerSecond) * valvePhase);
                pressureSample.exhaustAcousticMassFlowKgPerSecond[index] =
                    static_cast<float>(exhaustAcousticMassFlowKgPerSecond[index]);
                pressureSample.exhaustPortDensityKgPerM3[index] =
                    static_cast<float>(exhaustPortDensityKgPerM3[index]);
                pressureSample.exhaustPortSpeedOfSoundMps[index] =
                    static_cast<float>(exhaustPortSpeedOfSoundMps[index]);
                pressureSample.exhaustValveConductanceAreaM2[index] = static_cast<float>(
                    valveBefore->conductanceAreaM2
                    + (valveAfter->conductanceAreaM2 - valveBefore->conductanceAreaM2) * valvePhase);
                pressureSample.exhaustFlowMgPerCycle[index] = static_cast<float>(exhaustFlowMgPerCycle_[index]);
                auto cams = activeCamshaft(
                    config_, config_.cylinders[index],
                    state_.rpm, state_.throttle);
                if (cams.config->variableProfileEnabled || valveProfileActuators_[index].appliedHigh())
                    cams.highProfile = valveProfileActuators_[index].appliedHigh();
                const auto maximumExhaustLiftMm = std::max(0.1, cams.exhaustLift());
                // A two-stroke's opening is its exhaust port's, as a share of
                // the port fully open at bottom dead centre.
                const auto& ported = config_.cylinders[index];
                pressureSample.exhaustValveOpening[index] = static_cast<float>(std::clamp(
                    twoStroke
                        ? exhaustValveAreaM2[index] * 1.0e6 / std::max(1.0e-9, portOpenAreaMm2(ported,
                            exhaustPortOpenDegrees, exhaustPortWidthMm(config_.twoStroke, ported),
                            config_.twoStroke.portDischargeCoefficient, 180.0))
                        : valveTrainResults_[index].exhaustLiftMm / maximumExhaustLiftMm, 0.0, 1.0));
                pressureSample.exhaustPathIndex[index] =
                    static_cast<std::uint8_t>(
                        exhaustPathIndexByCylinder_[index]);
                pressureSample.thermoacousticBoundaryValid[index] =
                    thermoacousticBoundaryValid[index];
            }
            valveFlowHistoryWrite_ = (valveFlowHistoryWrite_ + 1) % exhaustBoundaryKnotCount;
            if (pressureSamples_->tryPush(pressureSample))
                ++frame.cylinderPressureSampleCount;
            else
                ++frame.droppedCylinderPressureSampleCount;
        }

        // Combustion decisions above resolve the crank interval ending at
        // `subPreviousAngle`. Generate its event now with the same ECU command
        // and actual per-cylinder misfire state. This one-substep-delayed
        // publication is bounded by the mechanical solver cadence and avoids
        // reconstructing a whole outer frame from its final limiter state.
        const auto eventTravelled = forwardPhaseDegrees(eventEvaluationAngleDegrees_,
                                                         subPreviousAngle, eventGenerator_.cycleDegrees());
        const auto eventDt = std::max(0.0, subStepStartTime - eventEvaluationTimeSeconds_);
        if (combustion.combustionEnabled && ecuCommand.fuelEnabled
                && (ecuCommand.sparkEnabled
                    || config_.fuel == FuelType::diesel)
                && eventTravelled > 0.0) {
            const auto firstEvent = frame.firingEventCount;
            auto available = std::span<FiringEvent>(frame.firingEvents).subspan(firstEvent);
            const auto generated = eventGenerator_.generate(config_, state_, ecuCommand, combustion,
                eventEvaluationTimeSeconds_, eventEvaluationAngleDegrees_, eventTravelled,
                eventDt, available);
            frame.firingEventCount += generated;
            frame.droppedFiringEventCount += eventGenerator_.droppedEventCountLastGenerate();
            for (std::size_t index = firstEvent; index < frame.firingEventCount; ++index)
                exhaust_.process(frame.firingEvents[index]);
        }
        eventEvaluationAngleDegrees_ = subPreviousAngle;
        eventEvaluationTimeSeconds_ = subStepStartTime;
        // Choosing an equal partition of the remaining interval avoids an
        // arbitrarily short trailing step. Its last part consumes the exact
        // remainder, including when the selected cadence changed mid-frame.
        remainingStepSeconds = remainingSteps == 1 ? 0.0
            : remainingStepSeconds - subDt;
    }

    state_.solverSubsteps = static_cast<std::uint32_t>(std::min<std::size_t>(
        integratedSubStepCount, std::numeric_limits<std::uint32_t>::max()));
    state_.solverFrequencyHz = static_cast<double>(integratedSubStepCount) / dt;
    state_.exhaustCouplingFrequencyHz = exhaustNetworkAdvancedSeconds > 0.0
        ? static_cast<double>(completedExhaustCouplingAdvances)
            / exhaustNetworkAdvancedSeconds : 0.0;
    state_.crankDegreesPerSolverStep = maximumIntegratedCrankStep;
    state_.solverResolutionLimited = state_.solverResolutionLimited
        || maximumIntegratedCrankStep > config_.solver.maximumCrankDegreesPerStep + 1.0e-9;
    // Rate the network resolved at, over the network time it actually advanced.
    // Dividing by frame dt instead would dilute it on frames where the coupling
    // stride left the network held, and understate the resolved bandwidth.
    state_.exhaustNetworkAcceptedSubsteps = exhaustNetworkAcceptedSubsteps;
    state_.intakeNetworkAcceptedSubsteps = 0;
    state_.intakeNetworkRejectedSubsteps = 0;
    state_.intakeNetworkAdvancedSeconds = 0.0;
    state_.intakeCylinderTransferFailures = 0;
    state_.intakeNetworkMaximumAcceptedStepRatio = 0.0;
    state_.intakeNetworkMaximumCourantCurrent = 0.0;
    state_.intakeNetworkMaximumCourantPredictor = 0.0;
    for (std::size_t index = 0; index < config_.cylinders.size(); ++index) {
        state_.intakeNetworkAcceptedSubsteps += intakeNetworkAcceptedSubsteps[index];
        state_.intakeNetworkRejectedSubsteps += intakeNetworkRejectedSubsteps[index];
        state_.intakeNetworkAdvancedSeconds += intakeNetworkAdvancedSeconds[index];
        state_.intakeCylinderTransferFailures += intakeCylinderTransferFailures[index];
        state_.intakeNetworkMaximumAcceptedStepRatio = std::max(
            state_.intakeNetworkMaximumAcceptedStepRatio,
            intakeStepDiagnostics[index].maximumAcceptedStableStepRatio);
        state_.intakeNetworkMaximumCourantCurrent = std::max(
            state_.intakeNetworkMaximumCourantCurrent,
            intakeStepDiagnostics[index].maximumAcceptedDuctCourantCurrent);
        state_.intakeNetworkMaximumCourantPredictor = std::max(
            state_.intakeNetworkMaximumCourantPredictor,
            intakeStepDiagnostics[index].maximumAcceptedDuctCourantPredictor);
        if (intakeSplitReservoirDiagnosticsEnabled_) {
            const auto& observed = intakeSplitObservations[index];
            intakeSplitReservoirDiagnostics_.observationCount += observed.observationCount;
            intakeSplitReservoirDiagnostics_.observedCylinderMask |= observed.observedCylinderMask;
            intakeSplitReservoirDiagnostics_.absoluteFirstHalfTransferredMassKg +=
                observed.absoluteFirstHalfTransferredMassKg;
            intakeSplitReservoirDiagnostics_.interveningExhaustObservationCount +=
                observed.interveningExhaustObservationCount;
            intakeSplitReservoirDiagnostics_.interveningExhaustCylinderMask |=
                observed.interveningExhaustCylinderMask;
            intakeSplitReservoirDiagnostics_.absoluteInterveningExhaustTransferredMassKg +=
                observed.absoluteInterveningExhaustTransferredMassKg;
            intakeSplitReservoirDiagnostics_.maximumSpeciesInventoryMismatchKg = std::max(
                intakeSplitReservoirDiagnostics_.maximumSpeciesInventoryMismatchKg,
                observed.maximumSpeciesInventoryMismatchKg);
            intakeSplitReservoirDiagnostics_.maximumEnergyInventoryMismatchJ = std::max(
                intakeSplitReservoirDiagnostics_.maximumEnergyInventoryMismatchJ,
                observed.maximumEnergyInventoryMismatchJ);
            intakeSplitReservoirDiagnostics_.maximumObservedSpeciesInventoryKg = std::max(
                intakeSplitReservoirDiagnostics_.maximumObservedSpeciesInventoryKg,
                observed.maximumObservedSpeciesInventoryKg);
            intakeSplitReservoirDiagnostics_.maximumObservedEnergyInventoryJ = std::max(
                intakeSplitReservoirDiagnostics_.maximumObservedEnergyInventoryJ,
                observed.maximumObservedEnergyInventoryJ);
            intakeSplitReservoirDiagnostics_.maximumVolumeMismatchM3 = std::max(
                intakeSplitReservoirDiagnostics_.maximumVolumeMismatchM3,
                observed.maximumVolumeMismatchM3);
        }
    }
    state_.exhaustNetworkSubstepFrequencyHz = exhaustNetworkAdvancedSeconds > 0.0
        ? static_cast<double>(exhaustNetworkAcceptedSubsteps) / exhaustNetworkAdvancedSeconds
        : 0.0;
    pollGasFieldCapture();
    if (gasFieldArmed_ && state_.simulationTimeSeconds - gasFieldCaptureSeconds_ > 0.25)
        captureGasField();
    recordGasProbe();
    if (gasProbe_.element >= 0) ++gasProbe_.sequence;
    // The ECU's own limit bits come from its last command; the simulator's
    // are read here, once the wastegate and injectors have their final state.
    constexpr auto ecuLimitBits = static_cast<std::uint32_t>(ActiveLimit::revLimiter)
        | static_cast<std::uint32_t>(ActiveLimit::knockRetard)
        | static_cast<std::uint32_t>(ActiveLimit::coolantProtection)
        | static_cast<std::uint32_t>(ActiveLimit::launchControl)
        | static_cast<std::uint32_t>(ActiveLimit::overboostCut);
    state_.activeLimits = (state_.activeLimits & ecuLimitBits) | publishedSimulatorLimits();
    state_.powerValveOpening = powerValveOpening_;
    state_.frameAveragedRpm = frameIntegratedSeconds > 0.0
        ? frameTravelledDegrees / (6.0 * frameIntegratedSeconds) : state_.rpm;
    frame.state = state_;
    return frame;
}

void EngineSimulator::configureGasFieldSnapshot() {
    auto& elements = gasField_.elements;
    elements.clear();
    if (physicalExhaustNetwork_) {
        const auto& layout = physicalExhaustNetwork_->layout();
        for (const auto& duct : layout.ducts()) {
            GasFieldElement element;
            element.kind = GasFieldElementKind::exhaustDuct;
            element.pathIndex = duct.pathIndex;
            element.componentId = duct.sourceComponentId;
            element.nodeId = duct.nodeId;
            element.nodeType = static_cast<std::uint8_t>(duct.sourceType);
            elements.push_back(element);
        }
        for (const auto& junction : layout.junctions()) {
            GasFieldElement element;
            element.kind = GasFieldElementKind::exhaustJunction;
            element.pathIndex = junction.pathIndex;
            element.componentId = junction.sourceComponentId;
            element.nodeId = junction.nodeId;
            element.nodeType = static_cast<std::uint8_t>(junction.sourceType);
            elements.push_back(element);
        }
    }
    for (std::size_t index = 0; index < config_.cylinders.size() && index < intakeRunnerNetworks_.size(); ++index) {
        GasFieldElement element;
        element.kind = GasFieldElementKind::intakeRunner;
        element.pathIndex = static_cast<std::uint32_t>(intakePathIndexByCylinder_[index]);
        element.cylinderId = config_.cylinders[index].id;
        elements.push_back(element);
    }
    for (std::size_t pathIndex = 0; pathIndex < intakePlenumCount_; ++pathIndex) {
        GasFieldElement element;
        element.kind = GasFieldElementKind::intakePlenum;
        element.pathIndex = static_cast<std::uint32_t>(pathIndex);
        elements.push_back(element);
    }
}

void EngineSimulator::trackGasFieldAngle(double crankAngleDegrees) noexcept {
    const auto cycle = eventGenerator_.cycleDegrees();
    gasFieldTargetDegrees_ = std::isfinite(crankAngleDegrees)
        ? std::fmod(std::fmod(crankAngleDegrees, cycle) + cycle, cycle) : 0.0;
    if (gasFieldArmed_) return;
    gasFieldArmed_ = true;
    gasFieldLastDegrees_ = state_.crankAngleDegrees;
    gasFieldCaptureSeconds_ = state_.simulationTimeSeconds;
}

void EngineSimulator::pollGasFieldCapture() noexcept {
    if (!gasFieldArmed_) return;
    // Remaining distances, never absolute angles: the crank wraps.
    const auto cycle = eventGenerator_.cycleDegrees();
    const auto forward = [cycle](double degrees) { return std::fmod(std::fmod(degrees, cycle) + cycle, cycle); };
    const auto travelled = forward(state_.crankAngleDegrees - gasFieldLastDegrees_);
    const auto toTarget = forward(gasFieldTargetDegrees_ - gasFieldLastDegrees_);
    gasFieldLastDegrees_ = state_.crankAngleDegrees;
    // A sub-step never turns the crank by half a turn: more means it ran
    // backwards (a stall rocking back), which crosses nothing.
    if (travelled <= 180.0 && toTarget <= travelled) captureGasField();
}

void EngineSimulator::probeGasField(std::int32_t element, std::uint8_t sample) noexcept {
    if (element < 0 || static_cast<std::size_t>(element) >= gasField_.elements.size()) {
        gasProbe_.element = -1;
        return;
    }
    if (element == gasProbe_.element && sample == gasProbe_.sample) return;
    gasProbe_.element = element;
    gasProbe_.sample = sample;
    gasProbe_.pressurePa.fill(0.0F);
    gasProbe_.latestBin = -1;
    gasProbeStarted_ = false;
}

double EngineSimulator::gasFieldPressurePa(std::size_t element, std::size_t sample) const noexcept {
    // The same cells captureGasField() samples: count the elements of the
    // same kind before this one.
    const auto& elements = gasField_.elements;
    const auto kind = elements[element].kind;
    std::size_t index = 0;
    for (std::size_t e = 0; e < element; ++e)
        if (elements[e].kind == kind) ++index;
    const auto cellPressure = [sample](const gasdynamics::FiniteVolumeDuct& duct, bool reversed) {
        const auto cells = duct.cells();
        const auto count = std::min(cells.size(), GasFieldElement::maximumSamples);
        if (count == 0) return 0.0;
        const auto s = std::min(sample, count - 1U);
        auto cell = std::min(cells.size() - 1U, static_cast<std::size_t>(
            (static_cast<double>(s) + 0.5) * static_cast<double>(cells.size()) / static_cast<double>(count)));
        if (reversed) cell = cells.size() - 1U - cell;
        const auto primitive = duct.mixtureModel().primitiveFromConservative(cells[cell]);
        return primitive ? primitive->pressurePa : 0.0;
    };
    switch (kind) {
    case GasFieldElementKind::exhaustDuct:
        return physicalExhaustNetwork_ ? cellPressure(physicalExhaustNetwork_->duct(index), false) : 0.0;
    case GasFieldElementKind::exhaustJunction: {
        if (!physicalExhaustNetwork_) return 0.0;
        const auto primitive = physicalExhaustNetwork_->mixtureModel().primitiveFromConservative(
            physicalExhaustNetwork_->junctionState(index));
        return primitive ? primitive->pressurePa : 0.0;
    }
    case GasFieldElementKind::intakeRunner: {
        return index < config_.cylinders.size() ? cellPressure(intakeDuctForCylinder(index), true) : 0.0;
    }
    case GasFieldElementKind::intakePlenum:
        return intakePlenumGas_[elements[element].pathIndex].pressureKpa() * 1'000.0;
    }
    return 0.0;
}

void EngineSimulator::recordGasProbe() noexcept {
    if (gasProbe_.element < 0) return;
    const auto cycle = eventGenerator_.cycleDegrees();
    const auto forward = [cycle](double degrees) { return std::fmod(std::fmod(degrees, cycle) + cycle, cycle); };
    const auto binOf = [&](double degrees) {
        return std::min<std::int32_t>(static_cast<std::int32_t>(GasProbeTrace::bins) - 1,
            static_cast<std::int32_t>(forward(degrees) / cycle * static_cast<double>(GasProbeTrace::bins)));
    };
    const auto pressure = static_cast<float>(
        gasFieldPressurePa(static_cast<std::size_t>(gasProbe_.element), gasProbe_.sample));
    gasProbe_.cycleDegrees = cycle;
    gasProbe_.ambientPressurePa = config_.ambientPressureKpa * 1'000.0;
    const auto bin = binOf(state_.crankAngleDegrees);
    // Every bin the crank crossed since the last sub-step takes this value;
    // a step backwards (a stall rocking back) only rewrites the current bin.
    const auto travelled = forward(state_.crankAngleDegrees - gasProbeLastDegrees_);
    if (gasProbeStarted_ && travelled <= 180.0) {
        for (auto b = gasProbe_.latestBin; b != bin;) {
            b = (b + 1) % static_cast<std::int32_t>(GasProbeTrace::bins);
            gasProbe_.pressurePa[static_cast<std::size_t>(b)] = pressure;
        }
    }
    gasProbe_.pressurePa[static_cast<std::size_t>(bin)] = pressure;
    gasProbe_.latestBin = bin;
    gasProbeLastDegrees_ = state_.crankAngleDegrees;
    gasProbeStarted_ = true;
}

void EngineSimulator::captureGasField() noexcept {
    gasFieldCaptureSeconds_ = state_.simulationTimeSeconds;
    ++gasField_.sequence;
    gasField_.crankAngleDegrees = state_.crankAngleDegrees;
    gasField_.simulationTimeSeconds = state_.simulationTimeSeconds;
    gasField_.ambientPressurePa = config_.ambientPressureKpa * 1'000.0;
    gasField_.ambientTemperatureK = config_.ambientTemperatureC + 273.15;
    gasField_.afterfireHeatReleaseKw = state_.exhaustAfterfireHeatReleaseKw;

    // Sample s sits at (s + 0.5) / sampleCount of the element's length: every
    // cell when it has few, evenly spread cells otherwise.
    const auto sampleDuct = [](GasFieldElement& element, const gasdynamics::FiniteVolumeDuct& duct, bool reversed) {
        const auto cells = duct.cells();
        const auto walls = duct.wallStates();
        const auto count = std::min(cells.size(), GasFieldElement::maximumSamples);
        element.sampleCount = static_cast<std::uint8_t>(count);
        for (std::size_t s = 0; s < count; ++s) {
            auto cell = std::min(cells.size() - 1U, static_cast<std::size_t>(
                (static_cast<double>(s) + 0.5) * static_cast<double>(cells.size()) / static_cast<double>(count)));
            if (reversed) cell = cells.size() - 1U - cell;
            const auto primitive = duct.mixtureModel().primitiveFromConservative(cells[cell]);
            element.pressurePa[s] = primitive ? static_cast<float>(primitive->pressurePa) : 0.0F;
            element.gasTemperatureK[s] = primitive ? static_cast<float>(primitive->temperatureK) : 0.0F;
            element.wallTemperatureK[s] = walls.empty() ? 0.0F : static_cast<float>(
                walls[std::min(walls.size() - 1U, cell * walls.size() / cells.size())].temperatureK);
        }
    };

    std::size_t ductIndex = 0;
    std::size_t junctionIndex = 0;
    std::size_t runnerIndex = 0;
    for (auto& element : gasField_.elements) {
        switch (element.kind) {
        case GasFieldElementKind::exhaustDuct:
            sampleDuct(element, physicalExhaustNetwork_->duct(ductIndex++), false);
            break;
        case GasFieldElementKind::exhaustJunction: {
            const auto primitive = physicalExhaustNetwork_->mixtureModel().primitiveFromConservative(
                physicalExhaustNetwork_->junctionState(junctionIndex++));
            element.sampleCount = 1;
            element.pressurePa[0] = primitive ? static_cast<float>(primitive->pressurePa) : 0.0F;
            element.gasTemperatureK[0] = primitive ? static_cast<float>(primitive->temperatureK) : 0.0F;
            break;
        }
        case GasFieldElementKind::intakeRunner:
            // The runner's cells run from the valve to the plenum; the field
            // runs the way the air flows.
            sampleDuct(element, intakeDuctForCylinder(runnerIndex++), true);
            break;
        case GasFieldElementKind::intakePlenum:
            element.sampleCount = 1;
            element.pressurePa[0] = static_cast<float>(intakePlenumGas_[element.pathIndex].pressureKpa() * 1'000.0);
            element.gasTemperatureK[0] = static_cast<float>(intakePlenumGas_[element.pathIndex].temperatureK());
            break;
        }
    }
}

void EngineSimulator::accumulateCycleTelemetry(double previousAngleDegrees,
                                               double travelledDegrees,
                                               double dtSeconds,
                                               double indicatedTorqueNm,
                                               double brakeTorqueNm,
                                               SimulationFrame& frame) noexcept {
    if (!(travelledDegrees > 0.0) || !(dtSeconds > 0.0)) return;
    const auto cycleDegrees = eventGenerator_.cycleDegrees();
    if (!(cycleDegrees > 0.0)) return;
    const auto cycleRadians = cycleDegrees * std::numbers::pi / 180.0;
    auto angle = std::fmod(previousAngleDegrees + cycleDegrees, cycleDegrees);
    auto remainingDegrees = travelledDegrees;
    auto elapsedSubstepSeconds = 0.0;
    // A 50 ms recovery step at the configuration ceiling of 20,000 rpm spans
    // only 8.4 four-stroke cycles. Sixteen therefore covers the declared input
    // envelope with margin and preserves a small hard realtime bound if a
    // future event generator returns a nonsensically tiny cycle angle.
    constexpr std::size_t maximumCycleSegmentsPerSubstep = 16;
    std::size_t segmentCount = 0;
    while (remainingDegrees > 1.0e-12
           && segmentCount++ < maximumCycleSegmentsPerSubstep) {
        const auto degreesToBoundary = cycleDegrees - angle;
        const auto segmentDegrees = std::min(remainingDegrees, degreesToBoundary);
        const auto segmentFraction = segmentDegrees / travelledDegrees;
        const auto segmentSeconds = dtSeconds * segmentFraction;
        const auto segmentRadians = segmentDegrees * std::numbers::pi / 180.0;
        if (cycleTelemetryStarted_) {
            indicatedWorkThisCycleJoules_ += indicatedTorqueNm * segmentRadians;
            brakeWorkThisCycleJoules_ += brakeTorqueNm * segmentRadians;
            integratedCrankRadiansThisCycle_ += segmentRadians;
            cycleElapsedSeconds_ += segmentSeconds;
        }
        remainingDegrees -= segmentDegrees;
        elapsedSubstepSeconds += segmentSeconds;
        const auto reachedBoundary = segmentDegrees >= degreesToBoundary - 1.0e-12;
        if (!reachedBoundary) {
            angle += segmentDegrees;
            continue;
        }

        if (cycleTelemetryStarted_ && cycleElapsedSeconds_ > 1.0e-12) {
            CompletedBrakeCycleSample sample;
            sample.cycleId = nextCompletedBrakeCycleId_++;
            sample.startTimeSeconds = cycleStartTimeSeconds_;
            sample.endTimeSeconds = state_.simulationTimeSeconds
                + std::min(dtSeconds, elapsedSubstepSeconds);
            sample.durationSeconds = sample.endTimeSeconds
                - sample.startTimeSeconds;
            sample.integratedCrankRadians = integratedCrankRadiansThisCycle_;
            sample.indicatedWorkJoules = indicatedWorkThisCycleJoules_;
            sample.brakeWorkJoules = brakeWorkThisCycleJoules_;
            const auto positiveDenominators = sample.durationSeconds > 1.0e-12
                && sample.integratedCrankRadians > 1.0e-12;
            if (positiveDenominators) {
                sample.meanRpm = sample.integratedCrankRadians
                    / sample.durationSeconds * 60.0
                    / (2.0 * std::numbers::pi);
                sample.meanTorqueNm = sample.brakeWorkJoules
                    / sample.integratedCrankRadians;
                sample.meanPowerKw = sample.brakeWorkJoules
                    / sample.durationSeconds / 1'000.0;
            }
            const auto timeTolerance = 1.0e-9
                * std::max({ 1.0, std::abs(sample.durationSeconds),
                             std::abs(cycleElapsedSeconds_) });
            const auto angleTolerance = 1.0e-9
                * std::max(1.0, std::abs(cycleRadians));
            sample.numericallyValid = !cycleNumericalFault_ && positiveDenominators
                && std::isfinite(sample.startTimeSeconds)
                && std::isfinite(sample.endTimeSeconds)
                && std::isfinite(sample.durationSeconds)
                && std::isfinite(sample.integratedCrankRadians)
                && std::isfinite(sample.indicatedWorkJoules)
                && std::isfinite(sample.brakeWorkJoules)
                && std::isfinite(sample.meanRpm)
                && std::isfinite(sample.meanTorqueNm)
                && std::isfinite(sample.meanPowerKw)
                && std::abs(sample.durationSeconds - cycleElapsedSeconds_)
                    <= timeTolerance
                && std::abs(sample.integratedCrankRadians - cycleRadians)
                    <= angleTolerance;

            if (frame.completedBrakeCycleSampleCount
                < frame.completedBrakeCycleSamples.size()) {
                frame.completedBrakeCycleSamples[
                    frame.completedBrakeCycleSampleCount++] = sample;
            } else {
                ++frame.droppedCompletedBrakeCycleSampleCount;
            }

            // Preserve the existing EngineState contract as a latch of the
            // latest complete, valid cycle. Frames without a boundary leave it
            // untouched; the event array above is never replayed.
            const auto displacementM3 =
                engineDisplacementLitres(config_) * 0.001;
            if (sample.numericallyValid) {
                // The window is the crank's 720 degrees: two cylinder cycles
                // of a two-stroke.
                const auto workPerCylinderCycle = sample.indicatedWorkJoules
                    / (cycleDegrees / cylinderCycleDegrees());
                state_.indicatedWorkJoulesPerCycle = workPerCylinderCycle;
                state_.indicatedMeanEffectivePressureBar = displacementM3 > 0.0
                    ? workPerCylinderCycle / displacementM3 / 100'000.0
                    : 0.0;
                state_.indicatedPowerKw = sample.indicatedWorkJoules
                    / sample.durationSeconds / 1'000.0;
                state_.pdvTorqueNm = sample.indicatedWorkJoules
                    / sample.integratedCrankRadians;
                state_.cycleAveragedTorqueNm = sample.meanTorqueNm;
                state_.cycleAveragedPowerKw = sample.meanPowerKw;
            }
            // The gas-exchange split comes from the per-cylinder p-dV integrals,
            // not from the engine-level torque accumulation above: at any crank
            // angle the cylinders are in different strokes, so only a
            // per-cylinder loop can be attributed to one stroke or the other.
            // Each cylinder contributes its most recently completed cycle,
            // exactly as CylinderState::indicatedWorkJoulesPerCycle already does.
            double pumpingJoules = 0.0;
            double exhaustStrokeJoules = 0.0;
            double totalJoules = 0.0;
            for (std::size_t index = 0; index < config_.cylinders.size(); ++index) {
                pumpingJoules += indicatedWorkStates_[index].completedPumpingCycleJoules;
                exhaustStrokeJoules +=
                    indicatedWorkStates_[index].completedExhaustStrokeCycleJoules;
                totalJoules += indicatedWorkStates_[index].completedCycleJoules;
            }
            state_.pumpingMeanEffectivePressureBar = displacementM3 > 0.0
                ? pumpingJoules / displacementM3 / 100'000.0 : 0.0;
            state_.exhaustStrokeMeanEffectivePressureBar = displacementM3 > 0.0
                ? exhaustStrokeJoules / displacementM3 / 100'000.0 : 0.0;
            state_.grossIndicatedMeanEffectivePressureBar = displacementM3 > 0.0
                ? (totalJoules - pumpingJoules) / displacementM3 / 100'000.0 : 0.0;
        }
        cycleTelemetryStarted_ = true;
        cycleStartTimeSeconds_ = state_.simulationTimeSeconds
            + std::min(dtSeconds, elapsedSubstepSeconds);
        indicatedWorkThisCycleJoules_ = 0.0;
        brakeWorkThisCycleJoules_ = 0.0;
        integratedCrankRadiansThisCycle_ = 0.0;
        cycleElapsedSeconds_ = 0.0;
        // A fault may fall anywhere in this mechanical substep. Retain it in
        // both segments when a 720-degree boundary splits that substep.
        cycleNumericalFault_ = state_.solverResolutionLimited
            || std::abs(travelledDegrees) > config_.solver.maximumCrankDegreesPerStep + 1.0e-9;
        angle = 0.0;
    }
}

void EngineSimulator::reset() noexcept {
    ecu_.reset();
    fillNitrousBottle();
    nitrousSprayFraction_ = 0.0;
    nitrousMassFlowKgPerSecond_ = 0.0;
    nitrousOxygenRateMolPerSecond_ = 0.0;
    throttleOxygenRateMolPerSecond_ = 0.0;
    nitrousOxygenShare_ = 0.0;
    eventGenerator_.reset();
    intakeBoundaryStateTimeIntegral_.fill({});
    intakeBoundaryVolumeTimeIntegralM3S_.fill(0.0);
    intakeValveConductanceTimeIntegralM2S_.fill(0.0);
    intakeCouplingDurationSeconds_ = 0.0;
    intakeSchedulingPhaseSeconds_ = 0.0;
    intakeForwardPendingExchange_.fill({});
    intakeForwardPendingPlenumDelta_.fill({});
    exhaustOutflowSpeciesKgPerS_ = {};
    exhaustOutflowEnergyW_.fill(0.0);
    intakeForwardRemainingSubsteps_ = 0;
    intakeForwardClockLeadSeconds_ = 0.0;
    intakeWallHeatPendingSeconds_ = 0.0;
    intakeSplitReservoirDiagnostics_ = {};
    exhaustBoundaryKnotWrite_ = 0;
    valveFlowHistoryWrite_ = 0;
    exhaustValveConductanceTimeIntegralM2S_.fill(0.0);
    exhaustBoundaryStateTimeIntegral_.fill({});
    exhaustBoundaryVolumeTimeIntegralM3S_.fill(0.0);
    exhaustCouplingDurationSeconds_ = 0.0;
    outletOpeningScaleTimeIntegralSeconds_ = 0.0;
    networkTurbinePowerW_.fill(0.0);
    parallelCompressorPressureRatio_ = 1.0;
    parallelCompressorFlowShare_.fill(0.0);
    parallelCompressorSolveAgeSeconds_ = 0.0;
    networkTurbineOutletPressureKpa_ = config_.ambientPressureKpa;
    wastegateIntegral_ = 0.0;
    chargePressureKpa_ = 0.0;
    compressorDuctFlowKgPerSecond_ = 0.0;
    throttleFlowKgLastStep_ = 0.0;
    lastExhaustAcousticStatePublishSeconds_ = -1.0;
    if (pressureSamples_) {
        CylinderPressureSample discarded;
        while (pressureSamples_->tryPop(discarded)) {}
    }
    if (exhaustAcousticSamples_) {
        ExhaustAcousticSample discarded;
        while (exhaustAcousticSamples_->tryPop(discarded)) {}
    }
    state_ = {};
    state_.coolantTemperatureC = config_.ambientTemperatureC;
    state_.oilTemperatureC = config_.ambientTemperatureC;
    applyRegulatedTemperatures();
    state_.exhaustTemperatureC = config_.ambientTemperatureC;
    state_.turbineInletTemperatureC = config_.ambientTemperatureC;
    state_.manifoldPressureKpa = config_.ambientPressureKpa;
    state_.boostPressureRatio = 1.0;
    state_.forcedInductionShaftSpeedRpm = 0.0;
    state_.turbochargers = {};
    state_.wastegateOpening = 0.0;
    state_.blowOffMassFlowKgPerSecond = 0.0;
    dieselFuelLimitBits_.fill(0U);
    state_.exhaustPressureKpa = config_.ambientPressureKpa;
    state_.exhaustBackPressureKpa = config_.ambientPressureKpa;
    state_.intakeRunnerPressureKpa = config_.ambientPressureKpa;
    state_.exhaustRunnerPressureKpa = config_.ambientPressureKpa;
    randomState_ = 0x6d2b79f5U;
    for (std::size_t index = 0; index < cylinderRandomState_.size(); ++index)
        cylinderRandomState_[index] = 0x6d2b79f5U
            + 0x9e3779b9U * static_cast<std::uint32_t>(index + 1);
    for (std::size_t index = 0;
            index < combustionVariationRandomState_.size(); ++index)
        combustionVariationRandomState_[index] = 0xa341316cU
            + 0x7f4a7c15U * static_cast<std::uint32_t>(index + 1);
    combustionVariationNormalisedState_.fill(0.0);
    combustionCycleMultiplier_.fill(1.0);
    cylinderMisfires_.fill(false);
    previousAfrObservationCommandEnabled_ = false;
    intakeFlowMgPerCycle_.fill(0.0);
    exhaustFlowMgPerCycle_.fill(0.0);
    intakeFlowMgThisCycle_.fill(0.0);
    exhaustFlowMgThisCycle_.fill(0.0);
    deliveredAirMgPerCycle_.fill(0.0);
    deliveredAirMgThisCycle_.fill(0.0);
    reedInflowMgThisFill_.fill(0.0);
    reedInflowMgLastFill_.fill(0.0);
    exhaustRunnerVelocityMps_.fill(0.0);
    exhaustRunnerTemperatureK_.fill(config_.ambientTemperatureC + 273.15);
    cylinderFlowCycleStarted_.fill(false);
    instantaneousCombustionPulse_.fill(0.0);
    injectedFuelMolesThisCycle_.fill(0.0);
    portPulseCreditSampled_.fill(false);
    injectionCutThisCycle_.fill(false);
    sparkCutThisCycle_.fill(false);
    injectionStartCount_.fill(0U);
    engineBrakeHeld_ = false;
    state_.engineBrakeCylinders = 0U;
    exhaustValveStarted_ = false;
    exhaustValveAutoOpen_ = false;
    portPulseInventoryCreditMoles_.fill(0.0);
    portPulsePrimeDeficitMoles_.fill(0.0);
    portPulseAvailableFraction_.fill(1.0);
    airboxSlug_.fill({});
    carburettorStates_.fill({});
    carburettorFuelMassKgThisStep_ = 0.0;
    nitrousFuelMassKgThisStep_ = 0.0;
    entrainedFuelMolesThisCycle_.fill(0.0);
    meteredFuelMolesLastCycle_.fill(0.0);
    deliveredFuelMolesLastCycle_.fill(0.0);
    requestedFuelMolesThisCycle_.fill(0.0);
    predictedPortChargeMassMgThisCycle_.fill(0.0);
    trappedAirMassMgLastCycle_.fill(0.0);
    trappedAirSourcePressureKpaLastCycle_.fill(config_.ambientPressureKpa);
    trappedAirSourceTemperatureKLastCycle_.fill(config_.ambientTemperatureC + 273.15);
    actualAfrLastCycle_.fill(config_.fuelProperties.stoichiometricAirFuelRatio);
    actualAfrFuelMassMgLastCycle_.fill(0.0);
    actualAfrValidLastCycle_.fill(false);
    portFuelResumePending_.fill(false);
    portFuelResumePrepared_.fill(false);
    portFuelResumePurgeCycleSeen_.fill(false);
    portFuelResumeOpenLoopSecondsRemaining_.fill(0.0);
    portFuelResumeEpochAgeSeconds_.fill(0.0);
    portFuelResumeFuelTrim_.fill(1.0);
    portInjectorFootprintFuelMoles_.fill(0.0);
    portInjectorFootprintTargetFuelMoles_.fill(0.0);
    combustionCommandAvailable_.fill(false);
    fuelDeliveryRatio_.fill(0.0);
    commandedFuelMolesMaxThisCycle_.fill(0.0);
    injectorOpenSubsteps_.fill(0.0);
    injectorWindowSubsteps_.fill(0.0);
    injectorCapacityRatio_.fill(1.0);
    injectorDutyCycle_.fill(0.0);
    closedLoopFuelTrim_.fill(1.0);
    highLoadClosedLoopFuelTrim_.fill(1.0);
    flameEvents_.fill({});
    compressionIgnitionStates_.fill({});
    compressionIgnitionResults_.fill({});
    injectionStates_.fill({});
    endGasKnockStates_.fill({});
    powerValveOpening_ = powerValveTargetOpening(config_.twoStroke, 0.0);
    indicatedWorkStates_.fill({});
    valveTrainStates_.fill({});
    valveTrainResults_.fill({});
    valveProfileShaftCycle_.reset();
    for (auto& actuator : valveProfileActuators_) actuator.reset();
    runnerAcousticStates_.fill({});
    runnerAcousticResults_.fill({});
    ignitionDelayRemainingSeconds_.fill(0.0);
    ignitionPending_.fill(false);
    sparkScheduleArmed_.fill(false);
    scheduledSparkPhaseDegrees_.fill(0.0);
    dieselInjectionStarted_.fill(false);
    woschniReferenceValid_.fill(false);
    sparkScheduleTravelRemainingDegrees_.fill(0.0);
    commandedSparkEventsThisCycle_.fill(0);
    commandedSparkEventsLastCycle_.fill(0);
    completedIgnitionEventsThisCycle_.fill(0);
    completedIgnitionEventsLastCycle_.fill(0);
    commandedSparkPhaseThisCycle_.fill(-1.0);
    commandedSparkPhaseLastCycle_.fill(-1.0);
    completedIgnitionPhaseThisCycle_.fill(-1.0);
    completedIgnitionPhaseLastCycle_.fill(-1.0);
    eventEvaluationAngleDegrees_ = state_.crankAngleDegrees;
    eventEvaluationTimeSeconds_ = state_.simulationTimeSeconds;
    indicatedWorkThisCycleJoules_ = 0.0;
    brakeWorkThisCycleJoules_ = 0.0;
    integratedCrankRadiansThisCycle_ = 0.0;
    cycleElapsedSeconds_ = 0.0;
    cycleStartTimeSeconds_ = 0.0;
    nextCompletedBrakeCycleId_ = 1;
    cycleTelemetryStarted_ = false;
    cycleNumericalFault_ = false;
    const auto configureFuel = [this](GasCell& cell) {
        cell.configureFuelChemistry(config_.fuelProperties.molarMassGramsPerMole * 0.001,
            config_.fuelProperties.oxygenMolesPerFuelMole,
            config_.fuelProperties.productMolesPerFuelMole);
    };
    intakePlenumCount_ = std::max<std::size_t>(1,
        std::min<std::size_t>(config_.intakePaths.size(), intakePlenumGas_.size()));
    // Manifold: large plenum, no strong directional bias — neutral orientation.
    for (std::size_t pathIndex = 0; pathIndex < intakePlenumCount_; ++pathIndex) {
        const auto& intake = intakeGeometryAt(config_, pathIndex);
        configureFuel(intakePlenumGas_[pathIndex]);
        intakePlenumGas_[pathIndex].initialise(config_.ambientPressureKpa, intake.plenumVolumeLitres,
                                               config_.ambientTemperatureC + 273.15);
        const auto throttleRadius = intake.throttleDiameterMm * 0.0005;
        const auto throttleArea = std::numbers::pi * throttleRadius * throttleRadius;
        intakePlenumGas_[pathIndex].setGeometry(throttleArea, 0.0, 1.0);
    }
    if (config_.cycle == EngineCycle::twoStroke)
        for (std::size_t index = 0; index < config_.cylinders.size(); ++index) {
            const auto& cylinder = config_.cylinders[index];
            auto& crankcase = intakePlenumGas_[intakePathIndexByCylinder_[index]];
            const auto throttleArea = crankcase.characteristicAreaM2();
            crankcase.initialise(config_.ambientPressureKpa,
                crankcaseVolumeLitres(cylinder, config_.twoStroke.crankcaseCompressionRatio,
                    std::fmod(state_.crankAngleDegrees - crankOffsetDegreesFor(config_, cylinder)
                        + 1'440.0, 360.0)),
                config_.ambientTemperatureC + 273.15);
            crankcase.setGeometry(throttleArea, 0.0, 1.0);
        }

    for (std::size_t index = 0; index < config_.cylinders.size(); ++index) {
        previousCylinderPhases_[index] = std::fmod(state_.crankAngleDegrees
            - crankOffsetDegreesFor(config_, config_.cylinders[index])
            + phaseWrapBiasDegrees(cylinderCycleDegrees()), cylinderCycleDegrees());
        intakeRunnerPressureKpa_[index] = config_.ambientPressureKpa;
        intakePortTemperatureK_[index] = config_.ambientTemperatureC + 273.15;
        intakePortDensityKgPerM3_[index] = config_.ambientPressureKpa * 1'000.0
            / (GasCell::universalGasConstant / GasCell::airMolarMassKg
               * (config_.ambientTemperatureC + 273.15));
        intakePortSpeedOfSoundMps_[index] = std::sqrt(1.4
            * GasCell::universalGasConstant / GasCell::airMolarMassKg
            * (config_.ambientTemperatureC + 273.15));
        intakeValveColumnVelocityMps_[index] = 0.0;
        intakePortRamKpa_[index] = 0.0;
        exhaustRunnerPressureKpa_[index] = config_.ambientPressureKpa;
        exhaustBoundaryKnots_[index].fill({});
        valveFlowHistory_[index].fill({});
        chamberPressureBar_[index] = config_.ambientPressureKpa / 100.0;
        cyclePeakPressureKpa_[index] = 0.0;
        lastCyclePeakPressureKpa_[index] = 0.0;
        inGasExchange_[index] = false;
        cylinderWallTemperatureC_[index] = config_.ambientTemperatureC;
        blowByPendingSeconds_[index] = 0.0;
        individualThrottleMapKpa_[index] = config_.ambientPressureKpa;
        configureFuel(cylinderGas_[index]);

        const auto& cyl = config_.cylinders[index];
        const auto pistonAreaM2 = std::numbers::pi * std::pow(cyl.boreMm * 0.0005, 2.0);

        // Geometry: positive momentum means gas flowing upward out of the
        // cylinder for exhaust. The intake runner is a 1-D duct network with
        // its own conservative state, reset below.
        cylinderGas_[index].setGeometry(pistonAreaM2, 0.0, -1.0); // upward toward head

        cylinderGas_[index].initialise(config_.ambientPressureKpa,
            evaluateCylinderKinematics(config_, kinematicsReference_, index,
                state_.crankAngleDegrees, 0.0).chamberVolumeLitres,
            config_.ambientTemperatureC + 273.15);
    }

    // Construction guarantees these invariants. reset() cannot report failure
    // through IEngineSimulation and must not silently revive the old lumped
    // exhaust or intake, so an invariant violation is deliberately fatal.
    if (!physicalExhaustNetwork_
        || !physicalExhaustNetwork_->reset(config_.ambientPressureKpa * 1'000.0,
                                            config_.ambientTemperatureC + 273.15))
        std::terminate();
    auto& intakeNetworks = jointIntakeManifold() ? intakeManifoldNetworks_ : intakeRunnerNetworks_;
    const auto intakeNetworkCount = jointIntakeManifold() ? intakePlenumCount_ : config_.cylinders.size();
    for (std::size_t index = 0; index < intakeNetworkCount; ++index) {
        if (!intakeNetworks[index] && jointIntakeManifold()) continue;
        if (!intakeNetworks[index]
            || !intakeNetworks[index]->reset(config_.ambientPressureKpa * 1'000.0,
                                                     config_.ambientTemperatureC + 273.15))
            std::terminate();
    }
}

RunningState EngineSimulator::determineRunningState(const EngineControls& controls) const noexcept {
    if (state_.damage >= 1.0) return RunningState::destroyed;
    if (state_.damage > 0.5) return RunningState::damaged;
    if (state_.coolantTemperatureC > 118.0) return RunningState::overheating;
    if (state_.knockLevel > 0.45) return RunningState::knocking;
    if (controls.starterEngaged && state_.rpm < 620.0) return RunningState::cranking;
    if (state_.rpm < 250.0) return RunningState::stopped;
    if (state_.rpm < config_.idleRpm * 1.2) return state_.misfireRate > 0.18 ? RunningState::unstable : RunningState::idling;
    return RunningState::running;
}
} // namespace enginelab
