/**
 * Does downstream exhaust geometry reach a turbocharged engine at all?
 *
 * The user-visible complaint this exists to close: on a turbo engine, enlarging
 * the exhaust changed nothing useful and could only lose power. Reading the
 * model showed why. The turbine was expanded to AMBIENT
 *
 *     expansionRatio = p_turbine_inlet / p_ambient
 *
 * so the pressure downstream of the turbine -- the one thing a downpipe and a
 * silencer actually set -- was absent from the shaft power by construction. The
 * only remaining path from exhaust geometry to performance was the inlet term,
 * and that one is NEGATIVE: larger primaries expand the blowdown pulse into
 * more volume and lower the peak the turbine is charged with. So the model could
 * only ever answer "bigger exhaust, less boost", which is backwards.
 *
 * This sweeps the downstream conductance of a catalogue turbo at one held
 * full-load point and reports what it reaches. The gate is deliberately about
 * SIGN and MONOTONICITY, not about a magnitude: an absolute boost figure for an
 * arbitrary downpipe would have to be calibrated against a dyno this project
 * does not have, whereas the direction is not in doubt anywhere in the
 * turbocharging literature -- lowering turbine outlet pressure raises the
 * expansion ratio, and a bigger downpipe is the standard way of doing it.
 *
 * A naturally aspirated engine is measured with the same sweep as a control. It
 * has no turbine, so its response comes only from pumping work and must stay
 * far smaller than the turbo's; if the two move together, the instrument is
 * measuring the sweep and not the turbine.
 */

#include <enginelab/catalog/EngineCatalog.hpp>
#include <enginelab/ecu/SimpleEcuModel.hpp>
#include <enginelab/events/FourStrokeEventGenerator.hpp>
#include <enginelab/exhaust/ExhaustGraph.hpp>
#include <enginelab/physics/SimplifiedGasolinePhysics.hpp>
#include <enginelab/simulation/DynoAbsorberController.hpp>
#include <enginelab/simulation/EngineSimulator.hpp>

#include <algorithm>
#include <array>
#include <cmath>
#include <cstdlib>
#include <exception>
#include <iomanip>
#include <iostream>
#include <string>
#include <string_view>
#include <vector>

namespace {
constexpr double dt = 1.0 / 240.0;

struct Point final {
    double outletDiameterMm { 0.0 };
    double rpm { 0.0 };
    double boostRatio { 0.0 };
    double turbineOutletKpa { 0.0 };
    double backPressureKpa { 0.0 };
    double manifoldKpa { 0.0 };
    double wastegateOpening { 0.0 };
    double shaftSpeedRpm { 0.0 };
    double shaftSpeedRatio { 0.0 };
    double compressorPowerKw { 0.0 };
    double turbinePowerKw { 0.0 };
    double bearingPowerKw { 0.0 };
    double netShaftPowerKw { 0.0 };
    double torqueNm { 0.0 };
};

[[nodiscard]] Point measure(enginelab::EngineConfig config,
                            double outletDiameterMm, double holdRpm,
                            bool raisedWastegateTarget) {
    // The stock sweep measures a regulator: extra turbine power opens the
    // wastegate and holds manifold pressure. This second, explicitly
    // out-of-design stress condition raises the set point so the shaft and
    // compressor response remain observable above the stock design point. It
    // is NOT a calibrated boost claim and it is not called an open loop: once
    // the raised target is reached, the same wastegate controller may reopen.
    if (raisedWastegateTarget) {
        config.forcedInduction.wastegatePressureRatio =
            config.forcedInduction.pressureRatio + 1.5;
    }
    // Only the DOWNSTREAM side moves. Primaries and collector are left alone on
    // purpose: changing them would also move the blowdown pulse the turbine is
    // charged with, and the question here is specifically whether what happens
    // AFTER the turbine reaches the engine.
    config.exhaust.outletDiameterMm = outletDiameterMm;
    // Catalogue scalar hardware is compiled into the canonical component DAG
    // at load time. This experiment starts from that already-normalised
    // configuration, so mutate the actual downstream components as well as the
    // legacy scalar mirror; otherwise all four points exercise the same graph.
    for (auto& path : config.exhaustPaths) {
        if (path.inheritsGlobalGeometry) path.geometry = config.exhaust;
        if (!path.network) continue;
        for (auto& component : path.network->components) {
            if (component.type == enginelab::ExhaustComponentType::outlet) {
                component.diameterMm = outletDiameterMm;
                component.outletDiameterMm = outletDiameterMm;
            }
        }
    }
    // Keep every upstream/downstream component other than the outlet fixed.
    // In particular, a packed muffler's authored diameter is its perforated
    // core, not an unconstrained outer can: scaling that number without also
    // authoring a new can volume creates impossible negative packing volume and
    // turns this one-variable experiment into a different exhaust.
    enginelab::normaliseEngineConfig(config);

    enginelab::SimpleEcuModel ecu;
    enginelab::SimplifiedGasolinePhysics physics;
    enginelab::FourStrokeEventGenerator events;
    auto exhaust = enginelab::ExhaustGraph::makeForEngine(config);
    enginelab::EngineSimulator simulator(config, ecu, physics, events, exhaust);
    for (int step = 0; step < static_cast<int>(3.0 / dt); ++step) {
        const auto time = static_cast<double>(step) * dt;
        (void)simulator.step(dt, { true, time < 1.6, 0.55, 0.0 });
    }

    enginelab::DynoAbsorberController absorber(config);
    absorber.reset(simulator.state().rpm, simulator.state().torqueNm);
    const auto settleSteps = static_cast<int>(9.0 / dt);
    const auto sampleSteps = static_cast<int>(3.0 / dt);
    Point point { outletDiameterMm };
    for (int step = 0; step < settleSteps + sampleSteps; ++step) {
        const auto output = absorber.advance(dt, holdRpm, simulator.state());
        enginelab::EngineControls controls;
        controls.ignitionEnabled = true;
        controls.throttle = 1.0;
        controls.dynamometerTorqueNm = output.brakeTorqueNm;
        const auto frame = simulator.step(dt, controls);
        if (step < settleSteps) continue;
        point.rpm += frame.state.rpm;
        point.boostRatio += frame.state.boostPressureRatio;
        point.turbineOutletKpa += frame.state.turbineOutletPressureKpa;
        point.backPressureKpa += frame.state.exhaustBackPressureKpa;
        point.manifoldKpa += frame.state.manifoldPressureKpa;
        point.wastegateOpening += frame.state.wastegateOpening;
        point.shaftSpeedRpm += frame.state.forcedInductionShaftSpeedRpm;
        point.shaftSpeedRatio +=
            frame.state.forcedInductionShaftSpeedRatio;
        point.compressorPowerKw += frame.state.compressorPowerKw;
        point.turbinePowerKw += frame.state.turbinePowerKw;
        point.bearingPowerKw += frame.state.turboBearingPowerKw;
        point.netShaftPowerKw += frame.state.turboShaftNetPowerKw;
        point.torqueNm += frame.state.cycleAveragedTorqueNm;
    }
    const auto divisor = static_cast<double>(sampleSteps);
    point.rpm /= divisor;
    point.boostRatio /= divisor;
    point.turbineOutletKpa /= divisor;
    point.backPressureKpa /= divisor;
    point.manifoldKpa /= divisor;
    point.wastegateOpening /= divisor;
    point.shaftSpeedRpm /= divisor;
    point.shaftSpeedRatio /= divisor;
    point.compressorPowerKw /= divisor;
    point.turbinePowerKw /= divisor;
    point.bearingPowerKw /= divisor;
    point.netShaftPowerKw /= divisor;
    point.torqueNm /= divisor;
    return point;
}

// `--spool`: a throttle step at a held speed. The dyno holds `holdRpm` at
// part throttle until the shaft settles, then the throttle opens fully; the
// spool time is when the boost first covers 90 % of its rise.
void spool(const enginelab::EngineConfig& config, double holdRpm, double partThrottle) {
    enginelab::SimpleEcuModel ecu;
    enginelab::SimplifiedGasolinePhysics physics;
    enginelab::FourStrokeEventGenerator events;
    auto exhaust = enginelab::ExhaustGraph::makeForEngine(config);
    enginelab::EngineSimulator simulator(config, ecu, physics, events, exhaust);
    for (int step = 0; step < static_cast<int>(3.0 / dt); ++step) {
        const auto time = static_cast<double>(step) * dt;
        (void)simulator.step(dt, { true, time < 1.6, 0.55, 0.0 });
    }
    enginelab::DynoAbsorberController absorber(config);
    absorber.reset(simulator.state().rpm, simulator.state().torqueNm);
    const auto run = [&](double throttle, double seconds) {
        std::vector<enginelab::EngineState> states;
        for (int step = 0; step < static_cast<int>(seconds / dt); ++step) {
            const auto output = absorber.advance(dt, holdRpm, simulator.state());
            enginelab::EngineControls controls;
            controls.ignitionEnabled = true;
            controls.throttle = throttle;
            controls.starterEngaged = simulator.state().rpm < enginelab::dynoStarterCutoutRpm(config);
            controls.dynamometerTorqueNm = output.brakeTorqueNm;
            states.push_back(simulator.step(dt, controls).state);
        }
        return states;
    };
    const auto part = run(partThrottle, 8.0);
    const auto full = run(1.0, 8.0);
    const auto mean = [](const std::vector<enginelab::EngineState>& states,
                         double seconds, auto field) {
        const auto count = std::min(states.size(),
            static_cast<std::size_t>(seconds / dt));
        auto sum = 0.0;
        for (auto index = states.size() - count; index < states.size(); ++index)
            sum += field(states[index]);
        return sum / static_cast<double>(std::max<std::size_t>(1, count));
    };
    const auto boost = [](const enginelab::EngineState& state) {
        return state.boostPressureRatio;
    };
    const auto before = mean(part, 1.0, boost);
    const auto after = mean(full, 1.0, boost);
    auto t90 = -1.0;
    for (std::size_t index = 0; index < full.size(); ++index) {
        if (full[index].boostPressureRatio >= before + 0.9 * (after - before)) {
            t90 = static_cast<double>(index + 1) * dt;
            break;
        }
    }
    std::cout << std::fixed << std::setprecision(3) << config.name
              << "  part_rpm=" << std::setprecision(0) << mean(part, 1.0,
                     [](const enginelab::EngineState& state) { return state.rpm; })
              << "  rpm=" << mean(full, 1.0,
                     [](const enginelab::EngineState& state) { return state.rpm; })
              << std::setprecision(3) << "  boost " << before << " -> " << after
              << "  t90_s=" << t90
              << std::setprecision(1) << "  turbine_kW=" << mean(full, 1.0,
                     [](const enginelab::EngineState& state) { return state.turbinePowerKw; })
              << "  turb_out_kPa=" << mean(full, 1.0,
                     [](const enginelab::EngineState& state) {
                         return state.turbineOutletPressureKpa; })
              << "  backP_kPa=" << mean(full, 1.0,
                     [](const enginelab::EngineState& state) {
                         return state.exhaustBackPressureKpa; })
              << "  wg=" << std::setprecision(3) << mean(full, 1.0,
                     [](const enginelab::EngineState& state) { return state.wastegateOpening; })
              << std::setprecision(1) << "  torque_Nm=" << mean(full, 1.0,
                     [](const enginelab::EngineState& state) {
                         return state.cycleAveragedTorqueNm; })
              << "  comp_kW=" << mean(full, 1.0,
                     [](const enginelab::EngineState& state) { return state.compressorPowerKw; })
              << std::setprecision(3) << "  N/Nd=" << mean(full, 1.0,
                     [](const enginelab::EngineState& state) {
                         return state.forcedInductionShaftSpeedRatio; })
              << "  phi/phid=" << mean(full, 1.0,
                     [](const enginelab::EngineState& state) {
                         return state.turbochargers[0].compressorFlowCoefficientRatio; })
              << "  eta_c=" << mean(full, 1.0,
                     [](const enginelab::EngineState& state) {
                         return state.turbochargers[0].compressorEfficiency; })
              << "  comp_kg_s=" << mean(full, 1.0,
                     [](const enginelab::EngineState& state) {
                         return state.turbochargers[0].compressorMassFlowKgPerSecond; })
              << "  lambda=" << mean(full, 1.0,
                     [](const enginelab::EngineState& state) { return state.lambda; })
              << std::setprecision(0) << "  air_mg=" << mean(full, 1.0,
                     [](const enginelab::EngineState& state) {
                         return state.deliveredAirMassMgPerCycle; })
              << "  fuel_mg=" << mean(full, 1.0,
                     [](const enginelab::EngineState& state) {
                         return state.injectedFuelMgPerCycle; })
              << "  limits=0x" << std::hex << full.back().activeLimits << std::dec
              << '\n';
}

void report(const std::string& name, const std::vector<Point>& points) {
    std::cout << "\n" << name << '\n';
    std::cout << std::right << std::setw(11) << "outlet_mm"
              << std::setw(9) << "rpm"
              << std::setw(9) << "boost"
              << std::setw(13) << "turb_out_kPa"
              << std::setw(12) << "backP_kPa"
              << std::setw(11) << "MAP_kPa"
              << std::setw(8) << "wg"
              << std::setw(12) << "shaft_rpm"
              << std::setw(8) << "N/Nd"
              << std::setw(10) << "comp_kW"
              << std::setw(10) << "turb_kW"
              << std::setw(10) << "bear_kW"
              << std::setw(10) << "net_kW"
              << std::setw(12) << "torque_Nm" << '\n';
    for (const auto& point : points) {
        std::cout << std::fixed << std::setprecision(1)
                  << std::setw(11) << point.outletDiameterMm
                  << std::setprecision(0) << std::setw(9) << point.rpm
                  << std::setprecision(3) << std::setw(9) << point.boostRatio
                  << std::setprecision(1)
                  << std::setw(13) << point.turbineOutletKpa
                  << std::setw(12) << point.backPressureKpa
                  << std::setw(11) << point.manifoldKpa
                  << std::setprecision(3) << std::setw(8)
                  << point.wastegateOpening
                  << std::setprecision(0) << std::setw(12)
                  << point.shaftSpeedRpm
                  << std::setprecision(3) << std::setw(8)
                  << point.shaftSpeedRatio
                  << std::setprecision(2) << std::setw(10)
                  << point.compressorPowerKw
                  << std::setw(10) << point.turbinePowerKw
                  << std::setw(10) << point.bearingPowerKw
                  << std::setw(10) << point.netShaftPowerKw
                  << std::setprecision(2) << std::setw(12) << point.torqueNm
                  << '\n';
    }
}
} // namespace

int runHarness(int argc, char** argv) {
    auto enforce = false;
    auto spoolRpm = 0.0;
    auto partThrottle = 0.15;
    std::string spoolEngine;
    std::string catalogRoot = ENGINELAB_CATALOG_ROOT;
    for (int index = 1; index < argc; ++index) {
        const std::string_view argument { argv[index] };
        if (argument == "--enforce") enforce = true;
        else if (argument == "--catalog-root" && index + 1 < argc)
            catalogRoot = argv[++index];
        else if (argument == "--spool" && index + 1 < argc)
            spoolRpm = std::stod(argv[++index]);
        else if (argument == "--part-throttle" && index + 1 < argc)
            partThrottle = std::stod(argv[++index]);
        else if (argument == "--engine" && index + 1 < argc)
            spoolEngine = argv[++index];
    }
    const auto catalog = enginelab::loadEngineCatalog(catalogRoot);
    if (!catalog.errors.empty()) {
        for (const auto& error : catalog.errors)
            std::cerr << "catalog: " << error << '\n';
        return EXIT_FAILURE;
    }
    if (spoolRpm > 0.0) {
        for (const auto& entry : catalog.entries) {
            if (!entry.config.forcedInduction.enabled
                || entry.config.forcedInduction.type
                    != enginelab::ForcedInductionType::turbocharger)
                continue;
            if (!spoolEngine.empty()
                && entry.config.name.find(spoolEngine) == std::string::npos)
                continue;
            spool(entry.config, spoolRpm, partThrottle);
        }
        return EXIT_SUCCESS;
    }

    const auto find = [&](bool turbo) {
        return std::find_if(catalog.entries.begin(), catalog.entries.end(),
            [turbo](const auto& entry) {
                const auto isTurbo = entry.config.forcedInduction.enabled
                    && entry.config.forcedInduction.type
                        == enginelab::ForcedInductionType::turbocharger
                    && entry.config.fuel == enginelab::FuelType::gasoline;
                return turbo ? isTurbo
                    : (!entry.config.forcedInduction.enabled
                        && entry.config.cylinders.size() >= 4
                        && entry.config.fuel == enginelab::FuelType::gasoline);
            });
    };
    const auto turbo = find(true);
    const auto control = find(false);
    if (turbo == catalog.entries.end() || control == catalog.entries.end()) {
        std::cerr << "FAIL: need one gasoline turbo and one NA control\n";
        return EXIT_FAILURE;
    }

    constexpr std::array outletsMm { 45.0, 60.0, 76.0, 95.0 };
    const auto sweep = [&](const enginelab::EngineConfig& config,
                           bool raisedWastegateTarget) {
        const auto holdRpm = std::min(0.60 * std::min(config.redlineRpm,
            config.ignition.revLimitRpm), 4'500.0);
        std::vector<Point> points;
        points.reserve(outletsMm.size());
        for (const auto outlet : outletsMm)
            points.push_back(
                measure(config, outlet, holdRpm, raisedWastegateTarget));
        return points;
    };
    const auto regulated = sweep(turbo->config, false);
    const auto stress = sweep(turbo->config, true);
    const auto controlPoints = sweep(control->config, false);
    report(turbo->config.name + "  (turbo, stock wastegate)", regulated);
    report(turbo->config.name
        + "  (turbo, raised-target energy stress; not calibrated)", stress);
    report(control->config.name + "  (naturally aspirated control)",
           controlPoints);

    const auto relativeSpan = [](const std::vector<Point>& points) {
        auto minimum = points.front().torqueNm;
        auto maximum = points.front().torqueNm;
        for (const auto& point : points) {
            minimum = std::min(minimum, point.torqueNm);
            maximum = std::max(maximum, point.torqueNm);
        }
        return maximum > 0.0 ? (maximum - minimum) / maximum : 0.0;
    };

    // 1. The mechanism itself: the turbine outlet must fall as the downstream
    //    system opens up. Before this change it was identically ambient, so
    //    this quantity could not move at all.
    //    The turbine sits in the gas network, so its outlet is a pulsating
    //    cell: once the outlet no longer restricts (76 -> 95 mm, behind the
    //    2.2 m mid pipe since 2026-10-12) it reads within +-0.5 kPa.
    auto outletFalls = true;
    for (std::size_t index = 1; index < regulated.size(); ++index)
        outletFalls = outletFalls
            && regulated[index].turbineOutletKpa
                <= regulated[index - 1].turbineOutletKpa + 1.0;

    // 2. Back pressure must follow it down. This is the quantity the user sees
    //    in the diagnostics panel and the one the complaint was about.
    const auto backPressureFalls = regulated.back().backPressureKpa
        < regulated.front().backPressureKpa - 1.0;

    // 3. The mechanism must have real magnitude, and it must be SPECIFIC to the
    //    turbine: a naturally aspirated engine has no turbine outlet, so its
    //    reading must stay exactly ambient across the same sweep. That is a
    //    control the sweep cannot accidentally satisfy.
    const auto outletSpanKpa = regulated.front().turbineOutletKpa
        - regulated.back().turbineOutletKpa;
    const auto outletSpanIsReal = outletSpanKpa > 10.0;
    auto controlOutletIsAmbient = true;
    for (const auto& point : controlPoints)
        controlOutletIsAmbient = controlOutletIsAmbient
            && std::abs(point.turbineOutletKpa
                - controlPoints.front().turbineOutletKpa) < 1.0e-6;

    // 4. Torque must improve end to end on the stock engine. This is what a
    //    user actually feels, and before the change the only sensitivity to
    //    exhaust geometry available to a turbo had the wrong sign.
    const auto torqueRises = regulated.back().torqueNm
        > regulated.front().torqueNm * 1.005;

    // 5. The stock wastegate must HOLD its boost target across the sweep. A
    //    regulator answers extra turbine power by opening further, not by
    //    overboosting; a model that raised boost here would have no regulator.
    //    The controller has an integral term, so the boost holds the target
    //    wherever the gate still has travel left.
    const auto regulatedBoostHolds = std::all_of(
        regulated.begin(), regulated.end(), [&regulated](const Point& point) {
            return point.wastegateOpening > 0.98
                || std::abs(point.boostRatio - regulated.back().boostRatio) < 0.02;
        });

    // 6. The deliberately raised-target stress must cross the former 1.16x
    //    clamp, retain downstream authority and settle through the EXPLICIT
    //    compressor/bearing work. Its absolute 3.x pressure ratio is outside
    //    the authored design point and is never treated as a calibrated claim.
    const auto stressCrossesFormerClamp = std::all_of(
        stress.begin(), stress.end(), [](const Point& point) {
            return point.shaftSpeedRatio > 1.20;
        });
    auto stressResponseIsMonotonic = true;
    for (std::size_t index = 1; index < stress.size(); ++index) {
        stressResponseIsMonotonic = stressResponseIsMonotonic
            && stress[index].boostRatio
                >= stress[index - 1].boostRatio - 0.002
            && stress[index].shaftSpeedRpm
                >= stress[index - 1].shaftSpeedRpm - 150.0;
    }
    // While the smallest outlet still starves the turbine, the authority is
    // boost and shaft speed; once even that point reaches the raised target
    // (the 2.2 m mid pipe leaves the 45 mm gate at 0.003, 2026-10-12), it is
    // the gate opening further at the same boost.
    const auto stressRetainsAuthority = (stress.back().boostRatio
            > stress.front().boostRatio + 0.010
        && stress.back().shaftSpeedRpm
            > stress.front().shaftSpeedRpm + 500.0)
        || stress.back().wastegateOpening
            > stress.front().wastegateOpening + 0.05;
    // Settled: the net shaft power is a small part of what the turbine gives.
    const auto settled = [](const Point& point) {
        return std::abs(point.netShaftPowerKw) < 0.02 * point.turbinePowerKw;
    };
    const auto shaftPowerBalances = std::all_of(regulated.begin(), regulated.end(), settled)
        && std::all_of(stress.begin(), stress.end(), settled);
    const auto stockStaysNearDesign = std::all_of(
        regulated.begin(), regulated.end(), [](const Point& point) {
            return point.shaftSpeedRatio > 0.85
                && point.shaftSpeedRatio < 1.15;
        });
    const auto turboSpan = relativeSpan(regulated);
    const auto controlSpan = relativeSpan(controlPoints);

    std::cout << "\nturbine outlet falls with downstream area: "
              << (outletFalls ? "PASS" : "FAIL")
              << "\nturbine outlet span " << std::fixed << std::setprecision(1)
              << outletSpanKpa << " kPa: "
              << (outletSpanIsReal ? "PASS" : "FAIL")
              << "\nNA control has no turbine outlet response: "
              << (controlOutletIsAmbient ? "PASS" : "FAIL")
              << "\nback pressure falls with downstream area: "
              << (backPressureFalls ? "PASS" : "FAIL")
              << "\nstock torque rises with downstream area: "
              << (torqueRises ? "PASS" : "FAIL")
              << "\nstock wastegate holds its boost target: "
              << (regulatedBoostHolds ? "PASS" : "FAIL")
              << "\nstock shaft remains near authored design speed: "
              << (stockStaysNearDesign ? "PASS" : "FAIL")
              << "\nraised-target stress crosses former clamp: "
              << (stressCrossesFormerClamp ? "PASS" : "FAIL")
              << "\nraised-target speed/boost retain downstream authority: "
              << (stressResponseIsMonotonic && stressRetainsAuthority
                    ? "PASS" : "FAIL")
              << "\nsettled shaft power balance |net| < 2 % of turbine: "
              << (shaftPowerBalances ? "PASS" : "FAIL")
              << "\n(diagnostic) torque span turbo " << std::setprecision(2)
              << turboSpan * 100.0 << " % vs NA control "
              << controlSpan * 100.0 << " %\n";

    const auto passed = outletFalls && outletSpanIsReal
        && controlOutletIsAmbient && backPressureFalls && torqueRises
        && regulatedBoostHolds && stockStaysNearDesign
        && stressCrossesFormerClamp && stressResponseIsMonotonic
        && stressRetainsAuthority && shaftPowerBalances;
    if (enforce && !passed) return EXIT_FAILURE;
    return EXIT_SUCCESS;
}

int main(int argc, char** argv) {
    try {
        return runHarness(argc, argv);
    } catch (const std::exception& error) {
        std::cerr << "FAIL: unhandled harness exception: "
                  << error.what() << '\n';
    } catch (...) {
        std::cerr << "FAIL: unhandled non-standard harness exception\n";
    }
    return EXIT_FAILURE;
}
