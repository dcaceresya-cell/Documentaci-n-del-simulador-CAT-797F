add_executable(EngineLabComparisonHarness ComparisonHarness.cpp)
target_link_libraries(EngineLabComparisonHarness PRIVATE
    EngineLab::Simulation EngineLab::Foundation EngineLab::Physics
    EngineLab::Ecu EngineLab::Events EngineLab::Exhaust EngineLab::Catalog)
enginelab_set_warnings(EngineLabComparisonHarness)

add_executable(EngineLabPhysicsPerfHarness PhysicsPerfHarness.cpp)
target_link_libraries(EngineLabPhysicsPerfHarness PRIVATE
    EngineLab::Simulation EngineLab::Foundation EngineLab::Physics
    EngineLab::Ecu EngineLab::Events EngineLab::Exhaust EngineLab::Catalog)
enginelab_set_warnings(EngineLabPhysicsPerfHarness)

add_executable(EngineLabDynoSweepHarness DynoSweepHarness.cpp)
target_link_libraries(EngineLabDynoSweepHarness PRIVATE
    EngineLab::Simulation EngineLab::Foundation EngineLab::Physics
    EngineLab::Ecu EngineLab::Events EngineLab::Exhaust EngineLab::Catalog)
enginelab_set_warnings(EngineLabDynoSweepHarness)

add_executable(EngineLabThermalHarness ThermalHarness.cpp)
target_link_libraries(EngineLabThermalHarness PRIVATE
    EngineLab::Simulation EngineLab::Foundation EngineLab::Physics
    EngineLab::Ecu EngineLab::Events EngineLab::Exhaust EngineLab::Catalog)
target_compile_definitions(EngineLabThermalHarness PRIVATE ENGINELAB_CATALOG_ROOT="${CMAKE_SOURCE_DIR}")
enginelab_set_warnings(EngineLabThermalHarness)

add_executable(EngineLabDynoCurveHarness DynoCurveHarness.cpp)
target_link_libraries(EngineLabDynoCurveHarness PRIVATE
    EngineLab::Simulation EngineLab::Foundation EngineLab::Physics
    EngineLab::Ecu EngineLab::Events EngineLab::Exhaust EngineLab::Catalog
    nlohmann_json::nlohmann_json)
execute_process(COMMAND git rev-parse HEAD WORKING_DIRECTORY "${CMAKE_SOURCE_DIR}"
    OUTPUT_VARIABLE ENGINELAB_CURVE_SOURCE_REVISION OUTPUT_STRIP_TRAILING_WHITESPACE
    ERROR_QUIET)
target_compile_definitions(EngineLabDynoCurveHarness PRIVATE
    ENGINELAB_CATALOG_ROOT="${CMAKE_SOURCE_DIR}"
    ENGINELAB_CURVE_SOURCE_REVISION="${ENGINELAB_CURVE_SOURCE_REVISION}")
enginelab_set_warnings(EngineLabDynoCurveHarness)

add_executable(EngineLabIntakeDuctBench IntakeDuctBench.cpp)
target_link_libraries(EngineLabIntakeDuctBench PRIVATE
    EngineLab::GasDynamics EngineLab::Physics EngineLab::Foundation)
enginelab_set_warnings(EngineLabIntakeDuctBench)

add_executable(EngineLabExhaustFlowBench ExhaustFlowBench.cpp)
target_link_libraries(EngineLabExhaustFlowBench PRIVATE
    EngineLab::GasDynamics EngineLab::Exhaust EngineLab::Foundation
    EngineLab::Physics EngineLab::Catalog)
enginelab_set_warnings(EngineLabExhaustFlowBench)

add_executable(EngineLabDesignBench DesignBench.cpp)
target_link_libraries(EngineLabDesignBench PRIVATE
    EngineLab::Runtime EngineLab::Catalog EngineLab::Serialization EngineLab::Foundation)
enginelab_set_warnings(EngineLabDesignBench)

add_executable(EngineLabExhaustNetworkCostBench ExhaustNetworkCostBench.cpp)
target_link_libraries(EngineLabExhaustNetworkCostBench PRIVATE
    EngineLab::GasDynamics EngineLab::Exhaust EngineLab::Foundation
    EngineLab::Physics EngineLab::Catalog)
target_compile_definitions(EngineLabExhaustNetworkCostBench PRIVATE
    ENGINELAB_CATALOG_ROOT="${CMAKE_SOURCE_DIR}")
enginelab_set_warnings(EngineLabExhaustNetworkCostBench)

add_executable(EngineLabShiftTransientHarness ShiftTransientHarness.cpp)
target_link_libraries(EngineLabShiftTransientHarness PRIVATE
    EngineLab::Audio EngineLab::Runtime EngineLab::Simulation EngineLab::Foundation EngineLab::Physics
    EngineLab::Ecu EngineLab::Events EngineLab::Exhaust EngineLab::Catalog)
target_compile_definitions(EngineLabShiftTransientHarness PRIVATE ENGINELAB_CATALOG_ROOT="${CMAKE_SOURCE_DIR}")
if(MSVC)
    target_link_options(EngineLabShiftTransientHarness PRIVATE /STACK:8388608)
endif()
enginelab_set_warnings(EngineLabShiftTransientHarness)

add_executable(EngineLabAfterfireHarness AfterfireHarness.cpp)
target_link_libraries(EngineLabAfterfireHarness PRIVATE
    EngineLab::Audio EngineLab::Runtime EngineLab::Simulation EngineLab::Foundation EngineLab::Physics
    EngineLab::Ecu EngineLab::Events EngineLab::Exhaust EngineLab::Catalog)
target_compile_definitions(EngineLabAfterfireHarness PRIVATE ENGINELAB_CATALOG_ROOT="${CMAKE_SOURCE_DIR}")
if(MSVC)
    # An EngineRuntime is ~7.4 MB of stack (SpscQueue<CylinderPressureSample, 8192>).
    target_link_options(EngineLabAfterfireHarness PRIVATE /STACK:8388608)
endif()
enginelab_set_warnings(EngineLabAfterfireHarness)

add_executable(EngineLabLoadedAccelerationHarness LoadedAccelerationHarness.cpp)
target_link_libraries(EngineLabLoadedAccelerationHarness PRIVATE
    EngineLab::Runtime EngineLab::Simulation EngineLab::Foundation EngineLab::Physics
    EngineLab::Ecu EngineLab::Events EngineLab::Exhaust EngineLab::Catalog)
target_compile_definitions(EngineLabLoadedAccelerationHarness PRIVATE
    ENGINELAB_CATALOG_ROOT="${CMAKE_SOURCE_DIR}")
if(MSVC)
    target_link_options(EngineLabLoadedAccelerationHarness PRIVATE /STACK:8388608)
endif()
enginelab_set_warnings(EngineLabLoadedAccelerationHarness)

add_executable(EngineLabDriveScenarioHarness DriveScenarioHarness.cpp)
target_link_libraries(EngineLabDriveScenarioHarness PRIVATE
    EngineLab::Runtime EngineLab::Simulation EngineLab::Foundation EngineLab::Physics
    EngineLab::Ecu EngineLab::Events EngineLab::Exhaust EngineLab::Catalog
    nlohmann_json::nlohmann_json)
target_compile_definitions(EngineLabDriveScenarioHarness PRIVATE
    ENGINELAB_CATALOG_ROOT="${CMAKE_SOURCE_DIR}")
enginelab_set_warnings(EngineLabDriveScenarioHarness)

add_executable(EngineLabUserDynoHarness UserDynoHarness.cpp)
target_link_libraries(EngineLabUserDynoHarness PRIVATE
    EngineLab::Runtime EngineLab::Simulation EngineLab::Foundation EngineLab::Physics
    EngineLab::Ecu EngineLab::Events EngineLab::Exhaust EngineLab::Catalog)
target_compile_definitions(EngineLabUserDynoHarness PRIVATE
    ENGINELAB_CATALOG_ROOT="${CMAKE_SOURCE_DIR}")
if(MSVC)
    target_link_options(EngineLabUserDynoHarness PRIVATE /STACK:8388608)
endif()
enginelab_set_warnings(EngineLabUserDynoHarness)

add_executable(EngineLabDynoRuntimeCurveHarness DynoRuntimeCurveHarness.cpp)
target_link_libraries(EngineLabDynoRuntimeCurveHarness PRIVATE
    EngineLab::Runtime EngineLab::Simulation EngineLab::Foundation EngineLab::Physics
    EngineLab::Ecu EngineLab::Events EngineLab::Exhaust EngineLab::Catalog)
target_compile_definitions(EngineLabDynoRuntimeCurveHarness PRIVATE
    ENGINELAB_CATALOG_ROOT="${CMAKE_SOURCE_DIR}")
if(MSVC)
    target_link_options(EngineLabDynoRuntimeCurveHarness PRIVATE /STACK:8388608)
endif()
enginelab_set_warnings(EngineLabDynoRuntimeCurveHarness)

add_executable(EngineLabDieselControlHarness DieselControlHarness.cpp)
target_link_libraries(EngineLabDieselControlHarness PRIVATE
    EngineLab::Simulation EngineLab::Foundation EngineLab::Physics
    EngineLab::Ecu EngineLab::Events EngineLab::Exhaust EngineLab::Catalog
    EngineLab::Diagnostics)
target_compile_definitions(EngineLabDieselControlHarness PRIVATE
    ENGINELAB_CATALOG_ROOT="${CMAKE_SOURCE_DIR}")
if(MSVC)
    target_link_options(EngineLabDieselControlHarness PRIVATE /STACK:8388608)
endif()
enginelab_set_warnings(EngineLabDieselControlHarness)

add_executable(EngineLabTurboDownstreamAuthorityHarness
    TurboDownstreamAuthorityHarness.cpp)
target_link_libraries(EngineLabTurboDownstreamAuthorityHarness PRIVATE
    EngineLab::Simulation EngineLab::Foundation EngineLab::Physics
    EngineLab::Ecu EngineLab::Events EngineLab::Exhaust EngineLab::Catalog)
target_compile_definitions(EngineLabTurboDownstreamAuthorityHarness PRIVATE
    ENGINELAB_CATALOG_ROOT="${CMAKE_SOURCE_DIR}")
if(MSVC)
    target_link_options(EngineLabTurboDownstreamAuthorityHarness PRIVATE
        /STACK:8388608)
endif()
enginelab_set_warnings(EngineLabTurboDownstreamAuthorityHarness)

add_executable(EngineLabCyclicVariabilityHarness CyclicVariabilityHarness.cpp)
target_link_libraries(EngineLabCyclicVariabilityHarness PRIVATE
    EngineLab::Simulation EngineLab::Foundation EngineLab::Physics
    EngineLab::Ecu EngineLab::Events EngineLab::Exhaust EngineLab::Catalog)
target_compile_definitions(EngineLabCyclicVariabilityHarness PRIVATE
    ENGINELAB_CATALOG_ROOT="${CMAKE_SOURCE_DIR}")
if(MSVC)
    target_link_options(EngineLabCyclicVariabilityHarness PRIVATE /STACK:8388608)
endif()
enginelab_set_warnings(EngineLabCyclicVariabilityHarness)

add_executable(EngineLabIntakeTransferHarness IntakeTransferHarness.cpp)
target_link_libraries(EngineLabIntakeTransferHarness PRIVATE
    EngineLab::Audio EngineLab::Foundation EngineLab::Catalog)
target_compile_definitions(EngineLabIntakeTransferHarness PRIVATE ENGINELAB_CATALOG_ROOT="${CMAKE_SOURCE_DIR}")
enginelab_set_warnings(EngineLabIntakeTransferHarness)

add_executable(EngineLabAudioRenderHarness AudioRenderHarness.cpp)
target_link_libraries(EngineLabAudioRenderHarness PRIVATE
    EngineLab::Audio EngineLab::Simulation EngineLab::Foundation EngineLab::Physics
    EngineLab::Ecu EngineLab::Events EngineLab::Exhaust EngineLab::Catalog)
target_compile_definitions(EngineLabAudioRenderHarness PRIVATE ENGINELAB_CATALOG_ROOT="${CMAKE_SOURCE_DIR}")
if(MSVC)
    target_link_options(EngineLabAudioRenderHarness PRIVATE /STACK:8388608)
endif()
enginelab_set_warnings(EngineLabAudioRenderHarness)

add_executable(EngineLabGeometrySensitivityHarness GeometrySensitivityHarness.cpp)
target_link_libraries(EngineLabGeometrySensitivityHarness PRIVATE
    EngineLab::Audio EngineLab::Runtime EngineLab::Simulation
    EngineLab::Foundation EngineLab::Physics EngineLab::Ecu EngineLab::Events
    EngineLab::Exhaust EngineLab::GasDynamics EngineLab::Catalog)
target_compile_definitions(EngineLabGeometrySensitivityHarness PRIVATE
    ENGINELAB_CATALOG_ROOT="${CMAKE_SOURCE_DIR}")
if(MSVC)
    # An EngineRuntime is ~7.4 MB of stack (SpscQueue<CylinderPressureSample, 8192>).
    target_link_options(EngineLabGeometrySensitivityHarness PRIVATE /STACK:8388608)
endif()
enginelab_set_warnings(EngineLabGeometrySensitivityHarness)

add_executable(EngineLabRealtimeBudgetHarness RealtimeBudgetHarness.cpp)
target_link_libraries(EngineLabRealtimeBudgetHarness PRIVATE
    EngineLab::Audio EngineLab::Runtime EngineLab::Simulation EngineLab::Foundation EngineLab::Physics
    EngineLab::Ecu EngineLab::Events EngineLab::Exhaust EngineLab::Catalog
    EngineLab::Diagnostics)
target_compile_definitions(EngineLabRealtimeBudgetHarness PRIVATE ENGINELAB_CATALOG_ROOT="${CMAKE_SOURCE_DIR}")
enginelab_set_warnings(EngineLabRealtimeBudgetHarness)

add_executable(EngineLabAbClipRenderer AbClipRenderer.cpp)
target_link_libraries(EngineLabAbClipRenderer PRIVATE
    EngineLab::Audio EngineLab::Simulation EngineLab::Foundation EngineLab::Physics
    EngineLab::Ecu EngineLab::Events EngineLab::Exhaust EngineLab::Catalog
    EngineLabJuce nlohmann_json::nlohmann_json)
target_compile_definitions(EngineLabAbClipRenderer PRIVATE ENGINELAB_CATALOG_ROOT="${CMAKE_SOURCE_DIR}")
if(MSVC)
    target_link_options(EngineLabAbClipRenderer PRIVATE /STACK:8388608)
endif()
enginelab_set_warnings(EngineLabAbClipRenderer)

add_executable(EngineLabAudioAbHarness AudioAbHarness.cpp)
target_link_libraries(EngineLabAudioAbHarness PRIVATE
    EngineLab::Audio EngineLab::Simulation EngineLab::Foundation EngineLab::Physics
    EngineLab::Ecu EngineLab::Events EngineLab::Exhaust EngineLab::Catalog)
target_compile_definitions(EngineLabAudioAbHarness PRIVATE ENGINELAB_CATALOG_ROOT="${CMAKE_SOURCE_DIR}")
if(MSVC)
    target_link_options(EngineLabAudioAbHarness PRIVATE /STACK:8388608)
endif()
enginelab_set_warnings(EngineLabAudioAbHarness)

add_executable(EngineLabOfflineAudioExporter OfflineAudioExporter.cpp)
target_link_libraries(EngineLabOfflineAudioExporter PRIVATE
    EngineLab::Audio EngineLab::Catalog)
target_compile_definitions(EngineLabOfflineAudioExporter PRIVATE
    ENGINELAB_CATALOG_ROOT="${CMAKE_SOURCE_DIR}")
if(MSVC)
    target_link_options(EngineLabOfflineAudioExporter PRIVATE /STACK:8388608)
endif()
enginelab_set_warnings(EngineLabOfflineAudioExporter)

add_executable(EngineLabSceneExport SceneExport.cpp)
target_link_libraries(EngineLabSceneExport PRIVATE EngineLab::Render EngineLab::Catalog EngineLab::Exhaust EngineLab::Foundation)
target_compile_definitions(EngineLabSceneExport PRIVATE ENGINELAB_CATALOG_ROOT="${CMAKE_SOURCE_DIR}")
enginelab_set_warnings(EngineLabSceneExport)

if(WIN32)
    add_executable(EngineLabSamplingProfiler SamplingProfiler.cpp)
    target_link_libraries(EngineLabSamplingProfiler PRIVATE Dbghelp winmm)
    enginelab_set_warnings(EngineLabSamplingProfiler)
endif()

add_executable(EngineLabKnockLimitCalibration KnockLimitCalibration.cpp)
target_link_libraries(EngineLabKnockLimitCalibration PRIVATE EngineLab::Runtime EngineLab::Catalog)
enginelab_set_warnings(EngineLabKnockLimitCalibration)

# In-pipe pressure against crank angle at one place of an exhaust, and its
# harmonics in dB SPL: a transducer, for published pipe measurements.
add_executable(EngineLabPressureProbeHarness PressureProbeHarness.cpp)
target_link_libraries(EngineLabPressureProbeHarness PRIVATE
    EngineLab::Simulation EngineLab::Foundation EngineLab::Physics
    EngineLab::Ecu EngineLab::Events EngineLab::Exhaust EngineLab::Catalog)
target_compile_definitions(EngineLabPressureProbeHarness PRIVATE ENGINELAB_CATALOG_ROOT="${CMAKE_SOURCE_DIR}")
enginelab_set_warnings(EngineLabPressureProbeHarness)

add_executable(EngineLabAcousticTransferProbe AcousticTransferProbe.cpp)
target_link_libraries(EngineLabAcousticTransferProbe PRIVATE
    EngineLab::Audio EngineLab::Exhaust EngineLab::Catalog EngineLab::Foundation)
target_compile_definitions(EngineLabAcousticTransferProbe PRIVATE ENGINELAB_CATALOG_ROOT="${CMAKE_SOURCE_DIR}")
enginelab_set_warnings(EngineLabAcousticTransferProbe)
