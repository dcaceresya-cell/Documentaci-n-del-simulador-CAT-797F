# Measurement journal

Short entries (10 lines maximum), most recent first. An entry says what was
measured, how, and what was not. Anything that becomes a lasting rule goes into
`.claude/CLAUDE.md`. Earlier history lives in the `archive/docs-2026-09` git tag
(`docs/archive/`).

## 2026-11-23 — The "Test cell" interface against the build before it

- Physics and sound: `AudioRenderHarness` output identical from its line 13 on (the lines before are the real-time wiring), `IntakeDuctBench` checksums identical (6 rows).
- Cost (`scripts/ui-scenes.ps1 -Perf`, 2JZ / Hayabusa / 13B / Merlin on a dyno run at 1440 x 860, 20 s each; 4 rounds alternating which build runs first, round 0 discarded, minimum of 3 medians, before -> after): real-time factor 1.00 -> 1.00 on all four (capped at 1: the app cannot free-run); 3-D view 60.6-61.2 fps both (v-sync); its render CPU 0.08-0.20 ms a frame both; process CPU equal within the rounds' spread (2,346-2,856 ms/s both).
- Message thread: 76 -> 92 ms/s (2JZ, Hayabusa), 61 -> 76 (Merlin), 76 -> 122 (13B). Read in steps of one 15.6 ms scheduler tick; the 13B's extra two ticks were not traced. The new cluster draws 40 segments and six traces at 30 Hz; not optimised.
- Not measured: another machine, a small PC, the 2-D cutaway before/after (the build before cannot force it; only its colours changed), the app at 125-150 % beyond the 1280 x 720 scene.
- Full `ctest -j 4` (whole project rebuilt first): 114/115; `EngineLab.AudioRender` timed out at 180 s under the load and passes alone (135 s). Captures before/after: `scripts/ui-scenes.ps1` on both builds, not seen by the owner yet.

## 2026-11-22 — The carburetted bike I4's dead idle is the outlet's oxygen, not its pilot

- Engine: designed 1.0 L bike I4, four carburettors on a 1.3 L plenum, pilot sized for AFR 13.5 at the screw's 0.42 (`PhysicsPerfHarness --trace 1 --idle --watch`, temporary probe on the metering, removed).
- Base: the carburettor meters AFR 13.4 at the screw floor, the plenum reads 16 (oxygen-based, lagging), the cylinder 23.5; the engine traps ~2.3 g/s of air-equivalent oxygen for ~1.15 g/s through the throttles. The idle valve hunts 0.42 <-> 0.88 (the starter jet rides above the screw), 1,050-1,930 rpm, and the engine stalls once the starter stops.
- One factor at a time: plenum 1.3 -> 0.3 L, same limit cycle (not the plenum's lag). Exhaust mesh 25 mm (`--exhaust-cell-mm 25`), everything else equal: a steady idle at 1,250-1,290 rpm, AFR 13.0, no misfire.
- Read: the coarse outlet cells' ambient oxygen (journal 2026-11-01/02) reaches the cylinders; injected engines trim it out in closed loop, an open-loop carburettor cannot. The pilot is right. Not fixed: the cure (`exp/outlet-mesh`) moves the default sound and costs real time; an owner decision.

## 2026-11-22 — Odd V engines; individual throttles at full load

- Odd V (designed, knock-limited, `--designer-probe` / `--idle-firing 20`): V3 4T 2.04 x real time, idle 1,408 rpm sd 19; V5 4T 1.31, 1,374 sd 13, no misfire; V3/V5 2T 1.72/1.24, firing 25-27 % at idle like designed I3/V2/V4 2T controls (not odd-V specific).
- Individual throttles (`individual_throttles`, no catalogue engine): CP2/CP4 copies lost up to 10.0/11.1 % WOT torque against one throttle (`DynoSweepHarness --step 1000`), runner tap MAP 80-85 kPa. Refuted one at a time: plenum inlet x4 (CP2 -1.8 to +0.3 %, CP4 none), plate at the full face as an orifice (no better). Cause: the quasi-steady orifice at a full-bore plate passes the steady flow but damps the ram wave; as the plain face the gap is within 0.4 %.
- Kept: a restriction opened to its full face between two ducts, without a turbine, is the plain face, bit for bit; each plate opens its fraction of its bore (no discharge coefficient), capped at its runner. CP2/CP4 now within 0.3 %, lambda and advance equal; every non-ITB row bit-identical.
- Designed I4s (1.0 L bike, 2.0 L car): ITB vs control -1.5..+0.5 % (bike), +0.8..+4.3 % (car vs one body); carburetted ITB lambda equal to the plenum carb's (fuel still enters the shared plenum: per-runner metering not needed for the mean); idles 1,306 / 1,259 (carb) / 904 rpm, all firing; real time 1.47-1.75 against 1.70-2.00 without.
- Known limit: the last bit of pedal steps from orifice to plain face (as the active exhaust valve). The acoustic intake still places the throttle at the plenum. Found, not touched: a designed carburetted bike I4 without ITB (four bodies on a plenum) does not idle at all (0 rpm), before and after this change.
- Targeted tests pass (GasDynamics, RestrictionFace, JointIntakeManifold, LiveIntake, AppLayout, EngineModel3D, RenderSnapshot, EngineDesign); full ctest not run; not seen in the app window.

## 2026-11-21 — Two-stroke crankcase paths on the workers; hardware fused multiply-add

- Profile after 75b8a15 (`SamplingProfiler`, new serial-by-line section): the V4-2S master still ran the crankcase volumes, throttles and plenum losses of its 4 paths one after another, and every duct cell's RK2 combination called MSVC's `std::fma`, a library routine (`fmal`), not the instruction.
- Kept: when every intake path holds one cylinder, a turning sub-step runs a path's crankcase volume, throttle and plenum loss as one pool item, sums after in path order; `rk2Combination` uses `_mm_fmadd_sd` when cpuid reports FMA3 and the OS saves AVX state (40 M random and cancelling triples: same double as `std::fma`).
- Bit-identical: `DynoSweepHarness --step 1000` CSVs equal 75b8a15's (V4-2S, V4-2S-Carb, I3-2S, RD350, K20A, LS3, Merlin, designed V8 two-stroke). Refuted on the way: `std::pow(x, 2.0)` -> `x * x` (0.04 % of doubles differ by an ULP; the V8's air_mg moved).
- Free run, interleaved, 5 rounds after a discarded one, medians 75b8a15 -> now: V4-2S 1.29 -> 1.40, I3-2S 1.17 -> 1.25, designed V8 two-stroke 0.59 -> 0.66, LS3 1.40 -> 1.41, RD350 1.52 -> 1.49 (spread 1.08-1.57). Host held ~1.3 cores of another job throughout.
- Not measured: the app window, other machines, a processor without FMA3 (falls back to `std::fma`). Left: the master's serial work inside the network advances (interfaces, ports, junctions applied in order), not dispatchable without changing the order. `Core`, `TwoStroke`, `JointIntakeManifold`, `GasDynamics`, exhaust tests pass; full ctest not run.

## 2026-11-21 — Latency-critical threads: one logical processor a physical core

- After the second pass the V4-2S master still waited ~23 % of its run on the pool, with its exhaust pipes even in work (max/mean 1.19 over equal substeps): the slow item was the thread, not the work. The OS placed the master and a worker on the two halves of one core (i5-10600, 6 cores x 2); a process affinity of one processor a core gave +9 %.
- Kept: `requestLatencyCriticalThread()` holds the master and the pool workers to the first logical processor of each fastest-class core (`latencyCriticalCpuSets`), only when the process affinity is the system's (a user's mask is left alone). Scheduling only: no computed value changes. `--smt-siblings` restores the old placement for measurement.
- Free run, interleaved, 5 rounds after a discarded one, medians shared -> one a core: V4-2S 1.20 -> 1.28, I3-2S 1.17 -> 1.21, designed V8 two-stroke 0.55 -> 0.62, RD350 1.49 -> 1.55, LS3 1.37 -> 1.42, K20A 1.31 -> 1.33, Merlin 1.67 -> 1.78. `--with-audio`: V4-2S 1.17-1.22 (4 of 4 valid) against 1.10-1.12 (2 of 4 valid); LS3 1.29-1.34 against 1.25-1.27.
- Not measured: the app window, a hybrid processor (P-core SMT halves), a part without SMT (unchanged by construction), more than 64 processors. Linux untouched. `ThreadScheduling` (topologies: i5-10600, hybrid, no SMT), `Core`, `TwoStroke` pass; full ctest not run.

## 2026-11-21 — Multi-cylinder two-strokes, second pass: the limiter's min and the crankcases on the workers

- Owner: optimise as far as possible, for every engine. Profile after 2026-11-20 (V4-2S, `--intake-workers 0`): `minmod` spent 9 % of the run in `std::min({ ... })`, the library's vectorised `min_element` for three values; the joint intake's forward flush (one crankcase network a cylinder) ran its paths one after another on the master. With 3 workers the V4-2S ran only 1.67 x its serial speed (0.60 -> 1.0); a temporary pool counter: ~72,000 dispatches a second, half the master's time outside them.
- Kept: a pairwise `minmod` (all three values one sign, non-zero: same double); the forward flush and the half-step joint loop one path per pool item when every path holds one cylinder, networks serial inside. A first try on the half-step loop alone measured nothing: production runs the forward flush. Multi-runner paths keep the per-duct dispatch (no such engine to measure).
- Bit-identical: `DynoSweepHarness --step 1000` CSVs equal cd43e8a's (V4-2S, V4-2S-Carb, I3-2S, RD350, K20A, LS3, Merlin, designed V8 two-stroke); `EngineLab.TwoStroke` (serial against 3 workers), `JointIntakeManifold`, `Core` pass.
- Free run, interleaved, 5 rounds after a discarded one, medians cd43e8a -> minmod -> both: V4-2S 0.86 -> 1.01 -> 1.08, I3-2S 0.88 -> 1.01 -> 1.13, designed V8 two-stroke 0.39 -> 0.48 -> 0.53, LS3 1.29 -> 1.32 -> 1.33 (paths do not apply: control), RD350 1.21 -> 1.34 -> 1.31 (one worker, spread 1.06-1.52). V4-2S `--with-audio`: always invalid before, 1.05-1.07 now (3 runs of 4 valid).
- Not measured: the app window, other machines, a multi-path four-stroke. Full ctest not run. Left: the master's serial work, about a third of the wall time.

## 2026-11-20 — Multi-cylinder two-strokes: the cylinder pass on the workers, bit-identical

- Owner: the designed V4 two-stroke below real time. `RealtimeBudgetHarness --saved-engine` (new) `--relative-rpm 0.9 --free-run`, the owner's saved engines: V4-2S 0.88-0.90 (3 workers), I3-2S 0.86, 250 single 2.17, catalogue RD350 1.25; V4-2S `--with-audio` invalid (~95,000 dropped pressure samples).
- Profile (`SamplingProfiler`, V4-2S): the 3 workers spin 70 % of their time, the master thread is saturated, so its serial work is the limit; `FiniteVolumeDuct::inventory` is 6 % of it, read-outs (gas internal energy, port vapour) walked over every cell every sub-step.
- The pass was never Gauss-Seidel in practice: it only reads the plenum (the intake network owns the exchange), its sums can be taken after it in cylinder order, and its one shared write is the misfire PRNG at a spark. Now a two-stroke with one intake path a cylinder runs pass and publish on the pool, a sub-step where two cylinders may spark stays serial; from 8 cylinders up (a PRNG each) the four-strokes' pass. Read-outs on the frame's last sub-step only.
- Bit-identical: `DynoSweepHarness --step 1000` CSVs equal the old binary's (V4-2S, V4-2S-Carb, I3-2S, a designed V8 two-stroke, RD350, K20A, LS3, the owner's V8 Truck copy); `AudioRenderHarness` RD350 WAV equal. New `EngineLab.TwoStroke` check (RD350, a both-together twin, designed V4 and V8; crank, idle misfires, full throttle; serial against 3 workers) fails without the spark guard (the draws race: counts change run to run).
- Free run, interleaved, round 0 discarded, medians before -> after: V4-2S 0.87-0.91 -> 1.03, I3-2S 0.89-0.93 -> 1.01, designed V8 two-stroke (54 x 54) 0.40 -> 0.48, LS3 1.32 -> 1.37, Merlin 1.68 -> 1.63, K20A control 1.25-1.27 -> 1.25-1.31 (host noise ~3 %: the app and a browser held ~2 cores). Read-outs +5 %, pass +5-9 %, publish ~2 % (noise). V4-2S with audio: invalid -> valid at 0.97, still under 1.
- The owner's "V8-2S" file is a four-stroke (the V8 Truck's bore, stroke and limiter, saved 6 min after it): its pass was already parallel, so `--inline-cylinders` costs it 10 % (1.30 against 1.45). A V12 two-stroke does not design (8 exhaust paths at most for audio). Not measured: the app window, the 3-D gas view, other machines. Full ctest not run (Core, JointIntakeManifold, TwoStroke pass).

## 2026-11-19 — owner: setting up an H-pipe or an X-pipe in the Exhaust designer is "horrible"

- Frictions found: the designer's connections never set port 2, so a hand-drawn H was a Y-split into a Y-merge (the jet pump of 2026-10-30, drawn as a downstream branch); a dual exhaust as two paths (flat-6, Merlin, designed "Dual" V8) could not take one at all ("- PATH" keeps one pipe); by hand 3 parts, 2 deletions, 6 drags, edits (a 1.5 L collector, 58/80 mm defaults); New engine refused one bank.
- Kept: `addCrossover` (+ H-PIPE / + X-PIPE), the designer's H/X in the best pair of pipes to different tailpipes, cut at 0.35 L; two paths joined first, both graphs whole. New engine: one bank = split, then the same call.
- `EngineLab.EngineDesign`: the one-click H on the designed dual V8 equals the designer's H part for part (type, length, bore, volume, K, k, 2 side ports). `EngineLab.ExhaustPathTopologyEditor`: H/X on graph and scalar dual V8, a second H, refusals (one pipe; two turbo paths). It caught the junctions' 300 mm config default (each side +600 mm). `EngineLab.EngineModel3D` caught the I6 one-bank H 18 mm below the corridor: its twin pipes run side by side and a 250 mm balance pipe sagged; two bores there, designed 0 of 84 implausible (clash/self/engine/bend/stretch 133/22/0/426/227 with the 4 new designs).
- Still refused: two turbocharged paths (a turbine per path collector; one graph with two collectors has none).
- Physics, gas, audio code untouched; catalogue engines and every design that built before build as before (no harness run: no input of theirs reaches the changed code). One-click H on the scalar flat-6 not checked in 3-D; not seen in the app on screen.
## 2026-11-19 — 3-D view: carburettors in a crowded valley, slide and needle, wastegate arm (owner)

- Owner: a V4-2S's carburettors "laid out anyhow"; a slide that does not shut the bore; a needle that rises with the slide; a turbo "rod, then a second at right angles". The needle does rise with its slide on every slide carburettor (it meters the jet's annulus): kept, now long enough to stay in a drawn fixed needle jet (tip 0.05 bore under the floor at full lift); slide 1.04 bore radii wide, lift 0.95 bore.
- `SceneExport` over the owner's 59 saved engines, plain and `--carburettor fit`: carburettors inside another carburettor's box 5 engines -> 0 (V4-2S x3 at 91 %, V4-4S, the radial I3 with three drums in one place); none deeper than 2 mm in an engine solid. Route totals unchanged except saved bends 160 -> 158.
- Catalogue (18) and `--designed all` (80), plain and `--carburettor fit`: ducts and issues unchanged except the carburetted RD350 (and the saved 250Mono2S), whose carburettors stand further out of the gearbox the deeper bowl reached 2.3 mm into; turbo parts changed only by the wastegate.
- 2JZ wastegate rod 14 / 9 mm outside its housings shut / open (gate > 0; an arm square to the flap fell 4.6 mm inside at 45 deg). The stub is ~2 cm, not ~12.
- New test: a designed V4 two-stroke with shared pins, 0 mm overlap (36.7 mm with the row layout disabled); slide and needle gates fail on the old geometry by construction (0.72 bore radii, needle tip 0.3 bore above the floor). `EngineLab.EngineModel3D` passes. Hayabusa with carburettors: bells inside its airbox, spigots 19 mm in its plenum box, left as is. Not seen on screen in the app.

## 2026-11-19 — 3-D view: owner's report on part D (valves, carburettors, radial cams, two-stroke plugs, solid view)

- Redrawn: throttle bodies and their plates (spindle, screws, quadrant), carburettors (bowl, slide tower, bell, choke), the exhaust valve's housing and actuator, the wastegate's canister and rod, the blow-off valve; plugs in two-strokes' heads; cam and timing covers (shells) so the solid view hides the shafts; a radial's cam ring, pushrods and rockers.
- `EngineLabSceneExport`, catalogue (18) and `--designed all` (80) against the build before part D: ducts, solids, issues, ports and every count identical (3/0/0/16/2; 127/20/0/419/224; 1 of 18 and 0 of 80 implausible).
- Radial-like R5: at each cylinder's peak lift a lobe of each track is within 5 deg of its tappet (test gate). 2JZ wastegate rod: -4.8 mm inside the turbine housing before, 66-67 mm outside after (angle-and-station check against the drawn housing; the gas volute alone did not see the clash).
- Carburettors and the exhaust valve looked at on K20A/RD350 copies (new exporter flags `--carburettor`, `--exhaust-valve fit`; the bypass fit gives K20A 1 clash, 1 stretch, not this change's). 2JZ's spindle now runs ~12 cm out past the volute to reach the rod.
- `EngineLab.EngineModel3D`, `AppLayout` pass; new checks fail on the old code (no radial cams, no two-stroke plugs, rod inside). Not seen on screen in the app; full `ctest` not run.

## 2026-11-19 — 3-D view: cams, sparks, sprays, throttles, valves, nitrous (analysis part D)

- Owner's plan, amended: spray under the strobe only; visible knock, engine on its mounts and steady-mode flow arrows dropped. Drawing only, no new solid: drawn after the layout.
- `EngineLabSceneExport` catalogue (18) and `--designed all` (80) against the build before: ducts, solids, issues and every existing part bit-identical; totals unchanged (3/0/0/16/2, 1 of 18 implausible; 127/20/0/419/224, 0 of 80).
- View cost (`--time-pose 2000`, least of n, one interleaved pair): pose +0.2-0.8 us per engine (Merlin 8.6 -> 9.4 us, 142 -> 174 parts; 13B 1.5 -> 1.7); build within run-to-run noise (LS3 455/395 ms). GPU cost not measured (headless); the app now shows the renderer's CPU ms per frame.
- K20A lobes point 11 deg off the deck centre at peak lift, with and without a 30 deg advance (test gate 20). Nitrous bottle (forced on K20A, LS3) 162-181 mm from any duct surface.
- `EngineLab.EngineModel3D` passes (new checks fail on the old code: no cams, sparks, sprays or controls); two turbo part counts now leave the flap out. Not seen on screen in the app; PNG capture not run.
- Limit: no pushrod engine in the configuration, so the LS3 is drawn with overhead cams.

## 2026-11-19 — users: silenced exhausts "blow" over the engine (2JZ); the muffler flow noise

- Cause: `MufflerFlowNoise` (0.10.0). The 2JZ's turbo_downpipe box is a 25 % perforate at L/D 7.3, held to 6: eta_w 77 + 4 x 6 = 101 dB, 20 dB over a plain chamber's plateau (81.5). Its observed jet+flow peak 1.3 Pa (flow off) -> 26.3 Pa.
- AudioRenderHarness `--catalogue-filter 2JZ`, flow noise x1 against x0 (temporary env gain, removed; jet unchanged): rms +0.2-0.6 dB, 250 Hz-1 kHz within 1 dB, but 4 kHz +4-15 dB, 8 kHz +16-35 dB, 63-125 Hz +13-37 dB under the I6's firing (185-300 Hz) once loaded. x0.1: 8 kHz +14-16, 63 Hz +20; x0.01: 8 kHz +5-7, 63 Hz +11.
- Not the packing: Delany-Bazley over the box's 0.47 m, sources spread along it, takes 3.0-3.4 dB above 1 kHz (600-800 K), so a lining term would not answer it.
- Whole catalogue, x1 against x0: bit-identical without a silencer (Aircooled, Merlin, Radial, RD350); CP3/CP4 within 0.4 dB in every octave; 8 kHz (worst 1 s window) 2JZ +25.6, I5 +22.7, EJ25 +19.7, Big Twin +37.5, CP2 +26.3, Full System/Lab +28.1, 13B +21.2, TDI +16.5, LS3 +12.5, K20A +8.1; 63 Hz up to +39.6 (EJ25).
- Unverified in the source: the 4 dB per L/D slope (Fig. 6.45 not re-read) and the flat octave spectrum to 11.3 kHz (Obata and Hirata 1978 report a Strouhal peak). Clips in `essai-soufflerie/` (current, -10, -20 dB, off).
- Owner chose "off" after listening: `setMufflerFlowNoiseEnabled`, default false (harness `--muffler-flow-noise`); default renders bit-identical to the x0 measurement (2JZ, EJ25), the flag to 0.10.0 (2JZ).

## 2026-11-18 — 3-D exhaust in the vehicle's corridor (owner: V8 HPIPE, X16 "catastrophic")

- New gauge `checkPlausibility` (vehicle frame; beside/below/above/ahead/behind, coiled, astray, mirror asymmetry). Before: catalogue 17 of 18 implausible (beside up to 1,405 mm, below 471, 10 outlets astray), owner engines 54 of 57 (beside 1,830, above 605, asymmetry 899).
- Kept, one step each, `EngineLabSceneExport` (catalogue / `--saved` / `--designed all`): a corridor with walls; collectors down then back, primaries folded past 1.3 x their reach; banks mirrored (H ends, routes bent alike, X fed side by side); a straight tail past 1.5 engine lengths drawn broken; two collars on every piece drawn short.
- After: catalogue 1 of 18 (EJ25 asymmetry 120 mm), owner 3 of 57 (Four-Rotor coiled; R8, Radial Eight 21-28 mm above), designed 0 of 80 (9 when first measured, already in the corridor). V8 HPIPE asymmetry 235 -> 7 mm, tailpipes 3 m out -> inside the plane.
- Price, clash/self/engine/bend/stretch: catalogue 0/2/0/7/4 -> 3/0/0/16/2, owner 15/2/0/75/29 -> 32/0/0/147/28 (more bends in less room); designed (first measured in the corridor) 138/20/2/417/225 -> 127/20/0/419/224.
- Refuted: an X centred on any engine (CP4 +2 bends; banked only), mirror fallback without a bend check (V4-2S +2 each), a tail keeping 3 D before its S (LS3 +4 bends). The outlet sounds from its drawn tip (contract kept; a moved mic hears a broken tail nearer).
- `EngineLab.EngineModel3D` passes (gates 3/0/0/16/2, behind and collars fail on the old code); export of the owner engines 28 s (20 s at 3decac7, not interleaved), X16 3.2 s, X12-2 2.5 s. Physics and default sound untouched (render only). Not seen in the app on screen.

## 2026-11-18 — 3-D tubing: a collector's place follows its primaries' length

- Owner: at 300 or 4,000 mm primaries the collector stayed put. Measured on four owner engines with every primary at 300/700/1,500/4,000 mm (`EngineLabSceneExport`, chord over drawn length of each primary): at 4,000 mm the slackest was 0.02-0.08 (a hairpin 1.5-1.9 m out), at 1,500 mm 0.06-0.21.
- Kept: a collector goes back along the trunk as far as every primary reaches (the rotary's rule, now all), or turns below the engine and moves out as far as they reach, whichever leaves the slackest the least to spend (turned only if +0.05; radials stay on their axis; only where the pipe after it bends within its length). Turned trunks that meet back off alike (a flat-6's two banks met under the crank).
- After: slackest 0.72-0.82 at 4,000 mm, 0.59-0.81 at 1,500 mm (I4 700 mm 0.41, X12-2 relocated 0.48-0.74 unchanged). Owner engines 34/27/0/196/21 -> 15/2/0/75/27 (V4-2S headers 2 x 3 drawn 1.18x instead of curled); catalogue 0/4/0/9/4 -> 0/2/0/7/4. Export 28 -> 20 s.
- Refuted: a tenth of the length kept spare (I6 700 mm 0.67 -> 0.54, V8 Truck bends 0 -> 26, V4-2S still stretched); a place at 0.75 of the length for a blocked collector (nothing changed).
- `checkCollectorFollowsPrimaries`: designed I6/V8 at 1.5 and 4 m, chord >= 0.6 (old code 0.15; now 0.80-0.82). `EngineModel3D` 77 s and `AppLayout` pass. Not seen in the app.

## 2026-11-18 — 3-D tubing: bent first guesses, collectors turned to face their primaries

- Issues sat within 3 D of pipe ends, and 25 of the 26 primaries entering an axial mouth from beyond it were knotted or kinked. Kept: each pipe starts from the clearest of 36 tube-bender shapes (arcs of 1.5 D), and such a mouth always turns.
- `EngineLabSceneExport`, clash/self/engine/bend/stretch: owner engines 87/29/0/252/27 -> 34/27/0/196/21; catalogue 4/4/0/21/6 -> 0/4/0/9/4 (2JZ 3/0/0/4/2 -> 0); X12-2 18/0/0/21/0 -> 3/0/0/11/3, its collector now on top, 3 primaries drawn 1.24-1.26x (it has no free place in reach).
- Envelope gate: 272 -> 264 pipes drawn longer, 0 through the engine; `EngineLab.EngineModel3D` (gates now 0/4/0/9/4, stretched <= 4; fails on the old code) and `AppLayout` pass. Physics and sound untouched (render only).
- Time: owner engines' export 33-36 -> 28-29 s; X12-2 3.8 -> 4.3-4.6 s (message thread).
- Refuted, one factor each: a cone entry (catalogue worse), smoothing (bends -8 only), relocating further, 800 passes (bends -48, 2.3x slower), 120 shape passes (bends -32, clashes +6), a 1.5 D bend target (clashes +5), holding clean guesses (no change).
- Left: LS3 self-clashes (690 mm primary on a 115 mm chord) and its X-pipes 3.4x; fat short user primaries (V8 53 mm x 430 mm) stay tight. Not seen in the app on screen.

## 2026-11-18 — 3-D layout: nothing through the engine or its gearbox (owner's X12-2)

- `checkRoutes` now counts the gearbox and turbo/intake bodies. Before the fix, over the 56 owner engines (`EngineLabSceneExport`): 105 clashes, 43 self, 148 through the engine, 299 bends, 45 stretched; after: 87, 29, 0, 252, 27. X12-2 28/7/81/35/7 -> 18/0/0/21/0 (its 12-into-1 and dimensions kept); X16 12/6/46/34/8 -> 4/2/0/12/0.
- Catalogue: counts 4/4/0/21/6 unchanged; geometry bit-identical but the Big Twin's rear pipe (it crossed the gearbox by 71 mm, unseen before step 0) and the RD350's gearbox (36.5 mm, clear of its carburettors).
- New gate in `EngineLab.EngineModel3D`: 80 designed engines (I4-I6, V8, V12, flat-6/12, X8/12/16, W8/12, V4 motorcycle x 5 exhaust systems, turbo on single/automatic): 29 failed before, 0 after (`EngineLab.EngineModel3D` 111 s, `EngineLab.AppLayout` pass).
- Model build time (SceneExport, the 54 engines matched by name): 22.7 -> 24.7 s; X12-2 2.0 -> 2.9 s (4.4 s with both layout passes whole, 8.8 s before the held re-bend). It runs on the message thread at each edit.
- Not measured: the app on screen; the X12-2's 18 remaining clashes are pipe against pipe (4-26 mm, its 12 primaries converging under the engine, two lower runners).

## 2026-11-17 — K01's outlet low band kept by the owner: on by default at 200 Hz

- Owner A/B of the six catalogue pairs (`essai-grave/`, showcase, 200 Hz against off): kept. `RealtimeEngineAudio` now starts at 200 Hz, and the first compiled network takes it too (before, only a network swapped in later did). `--outlet-low-band off` renders the network alone.

## 2026-11-17 — K03 (b) against K01's outlet low band: not the same gap

- ACME case (b) (W&P Fig 6.11b, 3,140 rpm, 25 mm, float32 stems) rendered with `--outlet-low-band 200` against off: below 250 Hz -4.6 -> -4.0 dB against the book, 250-500 Hz +2.4 -> +4.2 (already over), 500-1,000 -1.6 -> -0.9.
- The solver's own outlet monopole is -6.3 dB under the book below 250 Hz: unlike the TS125, the gas side is low there, so taking the low band from it cannot close (b). (a) and (c) are born on the gas side too (estimated lifts and Cd). K03 waits on the case's measured valve data; not measured: (a) and (c) with the low band.

## 2026-11-17 — K01: the port split fails at high amplitude; the solver's mouth flow fills the low band

- Render dumps of the port source (TS125 short pipe, 2.3 kW, 25 mm): at 67 Hz the linear split of the solver's port state gives an INCOMING wave 1.9x the outgoing (1.6x at 133 Hz), which a passive pipe cannot return. The port velocity is ~90 m/s rms: the port pressure is not a small-amplitude field there and 0.5(p +- Zc U) misplaces it; the network's port flow comes out 2.5 dB under the solver's at 67 Hz.
- Refuted, one factor: driving the network by the solver's port flow alone (rigid port): 63/125/200 Hz -6.7/-11.0/-15.4 dB against Jones & Brown (default -9.2/-12.6/-11.1). The probe's port flow is ~2.6 dB above the render's own at 67 Hz (absorber against governed hold; m/rho against m'/rho).
- Kept, off by default: `AcousticExhaustNetwork::setOutletSolverLowBand(Hz)` (`OfflineAudioExporter --outlet-low-band`): each outlet's far field below a 2nd-order Butterworth crossover follows the solver's own mouth volume flow (Q_net + LP(Q_solver - Q_net), complementary; published in `CylinderPressureSample`). TS125 at 200 Hz: -4.7/-6.7/-7.2 dB, overall -2.1 -> +0.7 dB; 400 Hz: -5.1/-6.6/-6.8, 250-630 Hz +2.8 (over). Off is bit-identical (render cmp); `EngineLab.OutletLowBand` checks it.
- Catalogue showcase at 200 Hz against off (`essai-grave/`): exhaust stem +1.5 to +3.4 dB at 125-250 Hz, +1 dB at 500, < 0.5 dB above; 31.5 Hz -0.2 to -5.3 (RD350 -14 at 16-31 Hz). For the owner's A/B. Not measured: a four-stroke reference recording, real-time cost (one biquad per outlet), the chamber case.

## 2026-11-17 — PressureProbeHarness's missing outlet table: the outlets were sampled at 240 Hz

- The simulator publishes the outlets' state on an exhaust coupling only when a reaction source exists, otherwise at its 240 Hz refresh. TS125 at 2.3 kW after `--settle 60`: no reaction left, 480 samples on 3.6 frames a cycle, 0 of 360 bins after the coupling-clock fill rule, so no table. At 4 s the pipe still reacted: 283 of 360 bins.
- `EngineSimulator::setExhaustAcousticEveryCoupling` (instrument only, off by default, read-only) now publishes on every coupling for the probe: 25,870 samples, 360 bins at 4 s and 60 s. The earlier 4 s outlet table moves under 0.3 dB to the 24th harmonic, the port tables not at all: the K01 figures stand.

## 2026-11-17 — K02: what a cooled-head port stage would move (measured, not kept)

- Temporary switch, one factor: on the first cell of each cylinder's exhaust duct, an extra loss k x the cell's own Gnielinski coefficient over 114 mm of wall (Caton & Heywood's port) held at 373 K (a coolant-held head). k = 2 is Caton's 2.2 fit over pipe correlations; k = 5 the mean-flow hand estimate of 2026-11-15. Removed; the default sweep is bit-identical (CSV and pipe temperatures).
- `DynoSweepHarness --filter K20 --step 1000`, 2,000-8,000 rpm: `egt_c` 435-707 C -> 402-656 (k = 2), 364-592 (k = 5); primaries' mean gas 632-764 -> 590-721 / 537-665 C, so their sound speed -2.1 % / -4.9 % at 8,000 rpm (tuned resonances move down by as much). Torque within 0.15 % below 7,000 rpm, +0.6 / +0.9 % at 7,000-8,000; `held_rpm_stddev` unchanged up to 6,000, 1.28-1.30 -> 1.66-1.77 at k = 5 above.
- Not kept: the catalogue's EGT is already low (2026-10-30, still 384-707 C) and its makers' points were refitted under the present port; a cooled port alone would widen that gap. Cooling the head is right in kind, but it waits on a measured EGT (or port-exit temperature) of a catalogue engine, then on an owner A/B (sound speed). Not measured: real-time cost, idles, turbo engines.

- The network alone (`AcousticTransferProbe`, TS125 short pipe, uniform 0.5 kg/m3 at 500 m/s, impulse at the port) against an open pipe's plane-wave transfer (Levine-Schwinger 0.61a, ambient far field at 5 m): -79.6/-78.8/-78.1/-77.1/-75.8 dB at 33/67/133/200/267 Hz for -78.7/-78.5/-78.0/-77.1/-75.7. Linear and right within 0.3 dB.
- The "-6.4 dB port-to-outlet" of the entry below compared the render with the solver's sampled port flow, which the network does not receive as such (its orifice port sits between): a comparison artefact, not a loss.
- The solver's own -6 to -7 dB at 67 Hz and 0.39 kW is its gas: the mean volume flow is about 5x lower at the outlet than at the port (0.001 against 0.005 m3/s; mean densities 1.05 against 0.53), the outlet breathing near-ambient air. Walls warmed 60 s instead of 4 (`--settle 60`): -7.4 -> -6.3 dB.
- Instrument oddity, not examined: `PressureProbeHarness --settle 60` at 2.3 kW prints no outlet monopole table (the port tables are there; 4 s and 0.39 kW are fine).

## 2026-11-17 — K01 deeper: the load dependence is the solver's, the network is linear

- Refuted, one factor each, TS125 short pipe at 2.32 kW against the solver's outlet monopole (67/133/200 Hz, base -6.7/-8.2/-5.1 dB): the outlet's nonlinear edge loss off -6.8/-8.0/-4.8; wave steepening off -6.7/-8.1/-5.0; the flow's mean taken on the volume flow instead of the mass flow (the dropped mean-flow x 1/rho term) -5.7/-7.4/-4.6, chamber +0.4-0.9 dB.
- `PressureProbeHarness` now also prints cylinder 1's port flow as the same monopole. At 67 Hz the solver's port-to-outlet volume-flow ratio is -7.5 / -2.5 / +0.2 dB at 0.39 / 1.16 / 2.32 kW; the network's (render against that port flow) -6.3 at 0.39 kW and -6.5 at 2.32 kW. The network transmits the port's low band at a constant ratio, as the solver does at small amplitude; the solver's ratio rises with amplitude.
- So the missing high-load low band is generated in the solver's pipe by a finite-amplitude effect (candidates: the mass a pulse actually carries out, convection at the mean flow) that a linear zero-mean network fed at the port cannot reproduce. Not measured: which one, and whether a real pipe does the same (the solver's monopole is within ~4 dB of Jones & Brown, so it is the better of the two here).
- Not explained: why a 0.40 m pipe passes only about -6 dB of its port's 67 Hz volume flow at small amplitude in both models (compact pipe, kL 0.3); the rigid-port test put about 2.5 dB of it on the port's orifice model.
- Physics and default sound untouched: the four switches were temporary and reverted, the exporter rebuilt bit-identical to the baseline render.

## 2026-11-17 — K01 and K03: where the measured sound gaps are born

- K01, TS125 at 4,000 rpm, 0.10.0 (`OfflineAudioExporter --exhaust-tap`, `PressureProbeHarness`, 25 mm): the render against Jones & Brown at 63/125/200 Hz reads -9.0/-12.3/-10.5 (short pipe), -4.2/-8.3/-13.6 (chamber); the network at 0.10 m is 7.0/5.4 dB under the solver (8.2/7.2 on 2026-11-16).
- Load is the factor: against the solver's outlet monopole the network radiates -1.8 dB at 67-200 Hz at 0.39 kW, -7.3 at 1.16 kW, -6.7 at 2.32 kW (short pipe). A finite-amplitude effect the linear network does not carry; which one is not found.
- Refuted, one factor each: the port resistance counting the acoustic velocity twice (raw flow plus the network's own; off: <= 0.6 dB); the port's flow-weighted rho*c against the duct's (234 against 244, 0.4 dB); the port model itself (rigid, fed the solver's exact flow: radiated -4.2/-6.6/-9.4 dB at 67/133/200 Hz against -6.7/-8.2/-5.1).
- The exit's temperature modulation of its volume flux (`PressureProbeHarness` now also prints the monopole at the outlet's mean density): 1.4-1.5 dB of the short pipe's 67-200 Hz, +-3 dB on the chamber.
- The port-face pressure is no proxy for the sound: the solver keeps ~152 dB at 67 Hz at 0.39, 1.16 and 2.32 kW while its monopole moves 15 dB. Its near-exit pressure is the outlets' default Cd 0.72 (Cd 1.0: 153.0 -> 134.5 dB at 67 Hz, the network's 133.6), worth 0.6 dB of the radiated low band; the network has no such opening.
- K03, ACME at 0.10.0, 500-1,000 Hz: (a) render -12.3 dB against the book, the solver 130 mm from the valve already -9.7 (its lifts and Cd are named estimates); (c) -7.9 (pipe -3.9); (b) below 250 Hz -4.6 (pipe +3.5). The gaps are born on the gas side, not in the audio network.
- Physics and default sound untouched: diagnostics were temporary and reverted, only the harness gained a column (its old table identical).

## 2026-11-17 — audit lots 7-8 and V08: interface, 3-D routing, licences, documentation

- Lot 7 checked on real JUCE components (`EngineLab.AppLayout`, new; `EngineLab.AudioWorkshop`): the top bar at 1,280/1,440/1,920 px has no two buttons overlapping (10 shown at 1,920); the VTEC row adds 24 px and moves the buttons below it; every tool window's enabled buttons take the focus; the tuner's anti-lag page and maps stay above UNDO at 30 px under the minimum height. Snapshots looked at; the running app not toured by hand.
- 3-D (`EngineLabSceneExport`, 18 engines; clash, self, engine, tight bend, stretched): 4, 4, 0, 46, 6 -> 4, 4, 0, 21, 6. One change each: the plenum's face as far out as one arc of three runner diameters allows (a 2-diameter arc left the CP2's runners at 0.63 and stretched them 8 % until the chord was capped at 0.97 of the runner): 46 -> 25, every runner bend gone; a merge at its routed inputs' mean target: 25 -> 21, Hayabusa self-clash 21.4 -> 4.5 mm, CP4 37.0 -> 14.2.
- Refuted: ending the relaxation on the bend pass (10 alternations) moves nothing (46/25 unchanged): the tight exhaust bends are where the authored length cannot fit the placed ends, not a solver order.
- Left: the 2JZ's middle primaries spend 430 mm over 230 (4 clashes, 5 bends), each 4-2-1's later secondary 256 mm over about 130 between Y pieces 100 mm apart, the LS3's long primaries (2 self-clashes) and its X's 140 mm pipes (3.4x, now shown in the inspector). Moving the parts themselves is a layout change not attempted.
- Physics and default sound untouched: drawing, UI, docs and packaging only.

## 2026-11-16 — audit lot 6: sound, each change measured on the catalogue

- Method: the 18 catalogue showcase masters rendered by the offline exporter before/after each fix alone, octave bands 63 Hz-16 kHz on 2 s windows (a band counts above 1e-5 of the window's power).
- A2-02 (a paused turbo held its whistle): running, every input is multiplied by exactly 1 (by construction; not rendered against an earlier build). A2-04 (the jet noise emitted past its own Mach 0.95 cap, +25.9 dB at Mach 2): all 18 masters bit-identical.
- PG-01 (8 boundary knots spanned 210 us of a 625 us delay at a 30 us flush; now 96, a static_assert holds it): median 0.000 dB on all 18, largest in one high-speed window (RD350 +1.33 dB at 16 kHz, CP4 -0.75, others under 0.5), Radial bit-identical.
- A2-03 (the rigid end {1,-1,-1} kept a closing valve's offset forever; now {1,0,0}): median 0.000 dB, largest in the same window (CP3 +1.79 dB at 16 kHz, others under 0.6). That window moves on both: a sensitive point, not examined.
- A2-05 (a tapered intake runner gained A_out/A_in): a compact 30-60 mm cone read 16.0 dB over its equal-volume cylinder at 150 Hz, 0.0 after. Catalogue: 17 bit-identical, EA288 median 0.04 dB, largest -1.79 dB at 63 Hz, level +0.01 dB.
- A2-08 (the valve flow's high band published 625 us ahead of the network's low band, around one crossover): clear, 3-9 dB in single bands (RD350 -13.8 at 16 kHz), median 0.11-0.99 dB, overall level within +-0.5 dB (CP3 -0.81). The owner heard the pairs (`listening-test/2026-11-16/`) and kept it on 2026-11-17 (60c4ad5).
- Rebuilt and rerun without the fix, failing on their own message: A2-02, A2-04, A2-03, A2-05. A2-08 has no new test; PG-01's is the static_assert.
- Benches against the lot 0 baseline: IntakeDuctBench identical; DynoSweep K20/RD350 torque, power and held_rpm_stddev identical to the digit, the reported egt_c and exh_kpa move (PG-01: K20A -0.003 C; RD350 egt up to +2.0 C, exh_kpa peak -1.7 % at the top, where its history was short). Full build green; ctest 111/113 at -j 4, AudioRender and LoadedAccelerationCatalogDfcoResume timed out and pass alone.
- With A2-08, AudioRender failed alone: the 13B radiated 130.3 dB at 1 m over the 130 dB guard (129.8 before; the harness's held point rises 0.1-1 dB on most engines, RD350 -2.6). The owner moved the guard to 132 dB. Not measured: A2-08 against a real recording.

## 2026-11-16 — audit lot 5: physics, each change measured

- Fixed: PH-01 (back-driven, the wheel gives the clutch torque over the gearbox efficiency: the crank received 56.5 kW for 195 kW at the wheel), PH-04 (drag at p/(R T), 1.196 kg/m3 by default, not 1.225), PH-06 (a live atmosphere reaches the clutch), PG-02 (wet nitrous fuel counted), PG-04 (the reordered-duct test runs one chunk per runner), PG-05 (a taper remeshes by frustum volume), PG-06 (the overboost cut holds the overrun map's fuel), PG-08 (script distance in metres), DR-07/08 (YAML repairs like JSON; JSON whole numbers refuse fractions and wraps), EXHAUST-02 (conversion keeps every route: 1,727 mm stayed 1,727, was 1,547 with the old tailpipe).
- Drive harness, one factor at a time: PH-04 alone, K20A 0-100 7.01 -> 7.03 s, 2JZ 6.30 -> 6.15 s (its shift sequence diverges from 6.67 s on a tiny perturbation: pre-existing sensitivity, not examined), top speeds within 0.4 km/h. PH-01 alone: pulls identical, K20A downshift peak 7,753 -> 7,541 rpm, top 107.3 km/h unchanged.
- Benches bit-identical to the lot 0 baseline (IntakeDuctBench checksums, DynoSweep K20/RD350, K20A render sha256): the default sound and the dyno are untouched.
- Rebuilt and rerun without the fix, failing on its own message: PG-05, PG-06, EXHAUST-02; PG-02 by arithmetic (without the kit fuel wet reads 6.89 g/s against 12.76 dry). The other new tests were not rerun without their fix. PG-05's first test passed without the fix: nested meshes (0.360/0.045) hide the weight; it now remeshes 0.360 -> 0.100.
- Full build green; ctest 111/113 at -j 4, AudioRender and LoadedAccelerationCatalogDfcoResume timed out and pass alone.
- Not done: EXHAUST-02 fixes route lengths only, the straight body as a pipe has no 82 Hz voice mode; PG-05's wall temperature keeps the length weight.

## 2026-11-16 — audit lot 4: the app against the running engine

- Fixed on `fix/audit-2026-11-16`: UA-01/APP-03 (an Audio workshop render or loop pack builds its simulator from the running engine and publishes its ECU snapshot before it; it ran the catalogue engine's tables), APP-04 (the workshop's physics fields follow `setEngine`), PH-03 (`SimpleEcuModel::reset` clears the eight anti-lag latches), EXHAUST-01 (removing a path pins each remaining path's turbo before the erase), APP-02/05/06 (cost advisory read before the apply, Escape writes the running vehicle value back, Build flushes a pending redesign).
- Fails without the fix, rebuilt and rerun: PH-03 "a reset clears the timeout", EXHAUST-01 "each remaining path keeps the turbine it drove", APP-04 "the physics fields follow the engine". UA-01, APP-02, APP-05, APP-06: source proof only (the export manifest carries no ECU figure; the three app paths need a live window).
- Not done: the loop pack's rpm points still come from the authored limits, not from the running calibration's rev limit.

## 2026-11-16 — audit lot 3: the instruments say what they measure

- Fixed: UA-08 (AudioAbHarness passed a dangling sample buffer, now runs every engine, `--filter`), TL2-01 (cyclic variability sampled once per phase wrap and kept zero-work cycles: K20A COV 0.29 -> 0.28 %), TL2-02 (5 unnamed CSV columns), TL2-03/RT-06/RT-07 (an empty reference match, an unwritten scene and a raw control byte fail), TL2-04 (the no-X control bypasses the crossovers only), A2-06 (a tap on a tapered part spread over its sections by length: 2.166 -> 0.000 in the new test), T2-01/TEST-01/TEST-02 (three oracles that could pass what they refuse), V01-V04/RT-01/RT-02 (listening reports count each answer once, unanswered pairs and excluded windows are reported, the binomial is 2^n; pop JSON refuses NaN).
- New ctest entries: `ToolArguments.DynoReferenceNoMatch` and `SceneIndexBlocked` (WILL_FAIL on the right message). The listening fixes were checked by a scratch probe (5 cases fail before, pass after), not in ctest.
- TEST-01 measured: "the last sample under the last 2 s mean" failed the RD350 at its raised 2,080 rpm target (2,278 -> 2,452 at 12 s, rising), but 18 s more show a slow swing, not a hang (min 1,705, settled 2,057; at 1,300: 1,363). The exception now requires the engine back within [0.85, 1.15] x target and over 0.78 x 30 s after the blip; physics unchanged.
- Not examined: AudioAbHarness prints RT60 "UNMEASURABLE" on the K20A.

## 2026-11-16 — audit lot 2: user data is no longer lost

- Fixed: DR-01/02/06/10 (one file per saved-engine name; device names, over-long names and names read back as ECU files refused at save), RT2-01/DR-09 (a log keeps one time base; two logs in one second get two files), UA-05/UA-06/A2-01 (exports write to `.partial` and replace all their files or none; overwrite off keeps an existing tap), APP-01 (an exhaust designer opened before Save As keeps the new name), DR-05 (UTF-8 paths in script includes and the ECU watcher).
- New tests fail without the fix: cancel leaves no `.partial`, a folder named `scenario.json` fails before the master is touched, a held file restores the old ones (Windows), the accented include. APP-01: source proof only.

## 2026-11-16 — audit lots 0-1: a clean base, crashes and the build

- Lot 0: the pending local edits committed on their own (add9560, 02737bd), the register committed (fdf7681), the priority in CLAUDE.md (172e72c); branch `fix/audit-2026-11-16`.
- Lot 1 fixed: PLAT-01 (GCC: `reject()` named one field of three), DR-03 (expression depth is a diagnostic), PG-07 (YAML alias loop is a read error), PH-02 (knock-limit curve validated, no NaN spark), DR-04/A2-07 (live-edit fields guarded between threads), APP-12 (last-ratio click after a resize), RT-05/RT-08 (bad `--exhaust-tap` id, run shorter than a sample).
- DR-04 and A2-07: no race detector, source proof only.

## 2026-11-16 — systematic audit: file coverage and bounded witnesses

- Register: [audit.md](audit.md), 90 scoped findings (52 added); [coverage](audit-coverage.md) records 553/553 tracked files and 174,336 text lines. Proofs, sources and component images are in [audit-evidence](audit-evidence/continuation.md); existing local edits retained.
- Windows Release build passed; initial CTest 106/108, both timed-out entries passed alone (all 108 have passing executions). Linux GCC 13.3 standard build blocked on PLAT-01; four independent freshly built tests passed.
- Executed: current physics/parser/persistence/audio/UI-component witnesses and 18 fresh 3-D route exports; rated points 24/24 catalogue, 20/22 generated designs. Short runtime+audio+gas-view attempt: 17 valid capacity points, Merlin accelerated invalid; paced control factor 0.991 with zero audio-contract losses.
- Limits: desktop capture failed; no live-device, blind-listening, new recording or long thermal campaign. No product correction, default-sound change, commit or publication; detailed uncertainty and refutations remain in the register.

## 2026-11-16 — TS125 (Jones & Brown): the gas is right, the audio network's port source is 7-9 dB low

- Case: NASA TM-84061 (1981, public), Suzuki TS125, `tests/reference-data/jones-brown-ts125/`: 0.40 m pipe, 1.30 m pipe, tuned chamber (Fig. 6), 4,000 rpm; ports, areas and pc(0) published. Estimated and named: rod (port widths follow), trapped 6.7:1, port Cd 0.72, chamber's belly ends, carburettor. Load: throttle setting the model's pc(0) (0.25 / 0.70 / 0.27). `PressureProbeHarness` now prints cylinder 1's pressure.
- In-pipe (25 mm, overlaid on Figs 7, 9, 10, 12): short pipe and chamber follow the measurement in shape and timing (pulse within ~2 kPa); the long pipe's pulse is right at 0.84/1.12 m but ~0.3 ms wide, +8 kPa at 0.10 m (2.5 diameters, the authors' 3-D region), with no shock at 1.12 m; troughs everywhere 30-60 % shallow.
- Radiated, 5 m, bands with a firing harmonic, +6 dB as the authors: the finite-volume outlet's monopole is -3.9 / -3.9 dB (63-200 Hz) and +2.9 / -4.2 (250-630) against the measurement (short pipe / chamber): as close as the authors' own 1-D (-4.4 / -2.5, +4.3 / -0.3). The render: -11.7 / -10.6 and -0.7 / -10.7; 1.25-3.15 kHz -0.2 / -2.8.
- The deficit is the network's source, not its radiation: its own pressure at 0.10 m (`--exhaust-tap 101:1.0`) is under the FV's by 8.2 / 7.2 dB at 63-200 Hz and 2.7 / 8.9 at 250-630, as much as the render under the FV monopole. Above 1.6 kHz it reads +5 dB, not interpretable: the FV side is phase-averaged over 66 cycles, the tap is not (averaging only lowers the FV, so the low-band deficit stands).
- Not tested: why the port source is low (one factor at a time: the port's conductance as the network sees it, the source's mass flow, the two-stroke's transfer flow). Nothing in the physics or the default sound changed.

## 2026-11-16 — the outlet's (1-M)/(1+M) is the no-Kutta limit, which the measurements refute

- Read: Davies, Bento Coelho & Bhattacharya, JSV 72 (1980), 103 points in a 38 mm pipe, M < 0.3; Peters, Hirschberg, Reijnen & Wijnands, JFM 256 (1993); Allam & Abom, JSV 292 (2006). With a mean outflow the pressure |R| follows Munt WITH a Kutta condition: |R| -> 1 as ka -> 0, (1 + M d)(1 - (ka)^2/2) with d 0-0.90, over 1 near Sr = ka/M ~ pi. (1-M)/(1+M) is Rienstra's/Cargill's no-Kutta limit; the energy loss lives in R_E = |R|^2 (1-M)^2/(1+M)^2, not in the pressure. End correction: Levine-Schwinger at high Sr, 0.19 a at low Sr (phase only).
- `AcousticExhaustNetwork` multiplies the reflected wave by (1-M)/(1+M) at the instantaneous outlet flow (c87d31d, "Munt"; added because operating resonances were near-lossless, Hayabusa clipped).
- BSA, `OfflineAudioExporter --outlet-convective-loss off` (new diagnostic, default bit-identical), 8 points, mean band change: 63 Hz +1.4, 125 +1.6, 250 +1.4, 500 +3.0, 1k +3.0, 2k +3.8, 4k +4.6, 8k +2.1 dB; overall +1.1 to +2.4. Gap left: 250-500 Hz -7.5 / -8.7, 1-2 kHz -5.3 / -5.6, 4 kHz -1.8 dB.
- So the factor is a third to a half of the radiated deficit, more above 1 kHz (the pulse leaves at high M). Not changed: it is a sound change, and what replaces the resonance damping it supplies (Peters: turbulent wall damping rises with flow, Ronneberger & Ahrens) is not measured.
- Catalogue showcase, factor off (`--outlet-convective-loss off`, `essai-sortie/`): master rms +0.2 to +0.7 dB (Hayabusa, EJ25, LS3, Big Twin, RD350, K20A), bands within +1.5 dB, no limiter, clamp or gain-control sample, comb prominence (95th percentile of 1/24 over 1/3 octave, 40 Hz-2 kHz) unchanged within 0.5 dB: the ringing that motivated it does not return, the valve orifice (ValvePortTermination) damps it. Turbulent wall damping (Howe, Allam & Abom) is no substitute here: the BSA's acoustic layer is under 10 wall units above ~50 Hz, where it is Kirchhoff's.
- `ExhaustTransfer` fails with it off ("straight did not dissipate its tail"): its fixture passed 60 g/s through a RIGID, lossless port. Given the open valve that flow needs (CdA 4.5 cm2, physical boundary), it passes either way. The owner, given `essai-sortie/` to hear, chose it: the factor is off by default (`--outlet-convective-loss on` restores it).
- The edge loss stands: 4/(3 pi) gives P* = 0.36 for Disselhorst & van Wijngaarden's 2 c_d/(3 pi) = 0.42 (c_d = 2, unflanged), confirmed by Peters at Sr_ac << 1 (P* read as the power over 1/2 rho u^3 pi a^2; the scan garbles it).

## 2026-11-16 — BSA A50: where the radiated deficit is not, and why the case stops here

- Ruled out (system 1, one factor each): decay along the pipe (the pulse's crest holds 1.59-1.60 from 0.3 to 1.6 m); the outlet's nonlinear edge loss (r = 0.21 |u|/c against 2: under 0.5 dB, and the finite volume without it is as quiet); the coupling cadence (`PressureProbeHarness --coupling-every-substep`, 8.4 -> 25 kHz) and a 0.5 deg crank step (bands within 1 dB).
- The measured in-pipe trace (Fig 4/7 digitised, the solid line by continuity) against the model's at 305 mm: 63-250 Hz within 2 dB; 500 Hz -6 / -1, 1 kHz -11 / -11, 2 kHz -15 / -22 dB (5,860 / 2,910 rpm). The model's pulse is the measured one smoothed and 35-50 deg late. A pixel's quantisation moves these bands under 0.5 dB.
- What moves that pulse, each an unsourced input of this case: 325 deg seat-to-seat (the published events at a 0.38 mm checking lift) -16 deg; a flat low-lift exhaust Cd (0.60 at 0.5 mm) -14 deg, +2-5 dB at 1-2 kHz; a parabolic lift (an extreme bound, faster than a cam) 500 Hz-2 kHz to -2 / -5 / -7 dB in the pipe and -3 to -9 dB of the radiated 1-4 kHz gap, 125-500 Hz radiated unchanged (-6 to -10).
- The 25 mm mesh is not converged at 1 kHz in the pipe (50 -> 25 mm: +4-5 dB); the render's production mesh is within 2 dB of it, so it does not set the heard sound.
- Not decidable here: linear plane-wave transfer from ONE in-pipe point to the far field is ill-conditioned above 125 Hz (10-20 dB swings for c 520-650 m/s); at 63-125 Hz the measurement, the model's pipe and the network's radiation agree within 2-4 dB. Without the BSA's lift curve and valve Cd, a simulator fault cannot be told from a wrong input: the case stops. Next reference without that unknown: a two-stroke's ports (Jones & Brown, NASA TM-84061, TS125: timings and areas published).

## 2026-11-16 — BSA A50 open pipes against Blair & Spechko: the pipe is right, the radiated sound 4-9 dB quiet

- Case: SAE 720155 (1972), BSA A50 500 cc 360 deg twin, `tests/reference-data/blair-spechko-bsa-a50/`: system 1 (cylinder 1, 66 in straight pipe), system 2 (two 15 in branches in a Y, 51 in tail), 34.9 mm bore, open end flush with the lab wall, meter 6 ft out, 4 in off axis, 22 in above the ground. Estimated and named in the files: port (60 mm), valves, lifts and the 1-cos lift law, rod, intake, load (full throttle). Model 24.6 kW at 5,860 rpm (A50 listed ~21 kW).
- In-pipe, 305 mm from the seat, system 1 (`PressureProbeHarness`, 25 mm): peak-to-trough swing 0.83 / 0.69 / 0.82 / 0.61 for the measured 0.77 / 0.71 / 0.76 / 0.58 (5,860 to 2,910 rpm); peaks 1.45-1.61 for 1.32-1.44, mean 3-8 % over ambient; the pulse 30-50 deg late at every speed (angle, not time: the lift law, unpublished, is the first suspect). System 2's shape differs: the own pulse 1.7 for ~1.2 measured, the other cylinder's ~1.25 for ~1.4.
- Radiated (`OfflineAudioExporter --exhaust-cell-mm 25 --convolution 0`, exhaust stem, figures read +-1 dB): free field 98-107 dB for 115-123 measured. With the wall as a baffle (x2) and the ground's image (source 0.44 m from Fig 1, hard ground) the model is 3.9-8.5 dB under overall at the 8 points; 125 Hz-4 kHz bands 6-12 dB under on average, 63 Hz 4 dB, 8 kHz +2. Source height 0.30-0.60 m moves the band means by under 3 dB. Production mesh: overall within 2 dB of 25 mm.
- The finite-volume outlet as a monopole (no audio network) reads 107.3 dB free field at 6,000 rpm against the network's 105.7: both stages are low, the loss is between a right in-pipe pressure and the air. Blair's own 1-D calculation was 6 dB under system 1, within 2.5 dB on system 2; ours sits ~4 dB under his.
- Leads, not tested (one factor each): the outlet's nonlinear edge loss at these exit velocities (Blair: up to 34 % of c; the ACME's silenced outlets matched within 1 dB); the wave's decay along 1.4 m of pipe; the lift law (timing and front steepness, mostly above 1 kHz). Nothing in the physics or the default sound changed.

## 2026-11-16 — the two tests the film tau broke: an aliased torque and a starved W16

- `AntiLag`: the test averaged `state.torqueNm` read once a frame; at 0 % kept it swings +-300 N.m a sample (cut firings) and its mean was +3.7 (new tau) or -5.0 N.m (old) while the speed held within 60 rpm. The last cycle's brake torque reads -1.7 (new) / +1.2 (old); 50 % kept -22.4 for a -23.4 target (the sample said -31.9). The test now averages that. Feeding the controller the cycle torque too gave -3.1 / -3.8 N.m at 0 % kept: not kept.
- `Vtec`'s W16 torture start floods with either tau, VTEC or not: at 37 kPa the trapped air is twice the delivered (the misfires' unburnt charge comes back, its fuel with it), the chamber holds 2.4x the metered fuel, AFR 6.5-9, the trim on its floor. The old tau survived at 276 rpm and idled at 550 for 750. Its bypass was 45 mm2, 5.6 a litre (K20 12, LS3 9.7): at the LS3's ratio, 78 mm2, both taus clear the flood by ~2 s and idle at 700-730 rpm, AFR 13.4-13.7.
- Refuted: fuelling a four-stroke for min(trapped, delivered) air (the W16's chamber still 12-15 mg for 5-7 metered).
- Found, left as designed: the trim loop's max(0.45 s, 8 tau) went 0.45 -> 2.1 s with the sourced tau (`CoreTests` asks it to follow the film). At a fixed 0.45 s the W16's trim fell as before, but the I5 resume went 34.5 -> 35.1 % rich, over its 0.35 envelope.
- Lead: Curtis's tau (1,800 rpm, part load) applies at every load. At WOT 5,750 rpm the I5 holds ~350 mg of film a port, and its charges still take ~21 mg each through the cut: the first resumed one gets 49.5 mg for 32 asked. A tau that falls with airflow (Aquino's trend) is the physical answer, a sound change.

## 2026-11-16 — port film tau from Curtis et al. adopted on `exp/port-film-tau`: resume fixed, two tests fail

- Applied (4aa40c3): the three port styles' tau x6.5 (0.26 / 0.17 / 0.49 s) and the serializers' port default 0.040 -> 0.26; the 13B and the two-strokes keep their authored film.
- The I5's rich resume: its first charges took 51-53 mg for a 28-34 mg request while a 60 mm footprint held 35 mg against a 10 mg target (the film kept evaporating through the cut). The resume prime is now signed, a wet footprint comes off the pulse: `--dfco-tip-in` rich peaks I5 36.1 -> 34.5 % (inside 0.35), EJ25 17.0 -> 15.5, CP3 15.5 -> 13.6; the catalogue DFCO test passes.
- Refuted: no prime at all (I5 35.2 %, CP4 38.5 % lean); counting the surplus over the charge's swept runner (I5 35.4 %); crediting the film over one cycle period (I5 36.9 %, 6.2 % misfires).
- Suite at `-j 4`: 104/108; `LoadedAccelerationCatalogDfcoResume` and `AudioRender` timed out and pass alone. Two fail alone and pass with the old tau and the signed prime:
- `Vtec`, the W16 torture engine's start: chaotic already with the old tau (flare to 1,500 rpm, idle ~550 for 750, trim 0.635); with the new tau the trim pins at its 0.559 floor, AFR 11.1 for 13.8, stall at 2.5 s. An over-fuelled start the long film exposes, not one it creates.
- `AntiLag`, 2JZ armed at 0 % kept, full aggressiveness: torque +3.66 N.m against a limit of 1.18 (2 % of the 58.9 N.m drag off): the film feeds charges through the anti-lag's cut.
- Not done: either fix; a listening A/B (both builds delivered to the owner, `EngineLab-essai-film-*`); a port-wall temperature law.

## 2026-11-15 — exhaust port heat: the pipe correlation is half of Caton-Heywood, and the mesh cannot hold a port

- Caton & Heywood (IJHMT 24, 1981), CFR single, 1,000 rpm, IMEP 414 kPa: gas ~1,027 K in the cylinder, ~810-823 K mass-averaged at the port exit 114 mm from the valve (Table 4); turbulent pipe correlations, even with developing flow and roughness, underestimate that loss by more than 2x (fit coefficient 2.2); jet-driven `Nu = 0.35 Re_j^0.6` fits.
- Here every exhaust cell, port included, uses fully developed Gnielinski (no entrance term). Hand estimate at Caton's base case with the mean flow: ~1/5 of the measured 870 W; pulsation brings it nearer Caton's 1/2.
- Not measured in the simulator, for structural reasons: the production four-stroke mesh is 360 mm a cell (a 114 mm port is a third of one), and the port wall is the primary's steel (K20A WOT 1,800 rpm: peak wall 159 C after 30 s, drifting +3.4 C/s), not a water-cooled head.
- Lead, not a fix: a port element with a coolant-held wall and Caton's jet correlation would cool the gas the primaries carry (EGT, speed of sound, turbine energy): a default-sound change, for the owner.

## 2026-11-15 — port fuel film: tau is 7-9x shorter than Curtis et al. measure; experiment on `exp/port-film-tau`

- Curtis et al. (SAE 961186), 1.6 L PFI I4, 1,800 rpm, MAP 50 -> 80 kPa in 1 s, metered AFR held: tip-in lean peak x1.13 at a 299 K port skin, x1.05 at 349 K, back in ~1 s (x1.25 with valve deposits). Aquino (SAE 810494, central injection) gives X 0.3-1.0 and tau 0.1 s hot.
- The model (`parts/injections.yaml`, unsourced since 92a01f2): X 0.22, tau 0.040 s divided by (T_runner-240)/120. K20A WOT 1,800 rpm: runner 19 C, so tau_eff 0.09 s, film 12.7 mg a cylinder. On Curtis's ramp, uncompensated: x1.009. X 0.22 fits the 349 K point with tau_eff ~0.8 s.
- Experiment (one factor: the three styles' tau x6.5, tau_eff ~0.6 s): `LoadedAccelerationHarness --dfco-tip-in` lean resume peaks fall (LS3 26.8 -> 1.2 %, flat-6 16.8 -> 0.4, EJ25 23.8 -> 3.7, K20A 20.7 -> 5.8); rich peaks rise (I5 15.2 -> 36.1 %, over the 0.35 envelope; 2JZ 14.8 -> 19.1, 4.8 % misfire peak). `IdleStabilityRegression` passes (674 s); `ShiftStyle` and both `AudioShiftTransient` pass; DCT 1->2 sync I5 4,341 -> 4,436 rpm, 2JZ unchanged.
- The ECU compensates with the physics' own X and tau, so steady and tip-in fuelling do not move; what moves is every cut (DFCO, shift, limiter): a sound change. The rich I5 resume is the resume logic tuned to the old tau (4 tau settling, fourth-root trim), not the film.
- Not measured: the full suite, sound A/B, a port-wall temperature law (Curtis: the skin temperature sets tau; the model uses the runner's gas).

## 2026-11-15 — the ACME's radiated excess was the audio network's cones gaining power, not missing damping

- Tools: `--exhaust-tap` (the network's own pressure in a render) and `AcousticTransferProbe` (the network alone, impulse at the port, tap-to-microphone transfer). Against a plane-wave transfer matrix (Munjal; 40-section cone, Levine-Schwinger end, ambient rho0) the ACME (b) network's transfer from the transducer to 0.5 m read +9.0 dB at 25-200 Hz, +11-13 dB at 350-750: a constant at frequencies where the downstream system is a plain inertance, so a gain, not a Q.
- Cause: each section of a taper scattered with its inlet area at one end and its outlet area at the other while its line carries pressure unchanged, so a forward wave gained power by A_out/A_in (x6 across the 27-66 mm cone) and a returning one lost it. Fix (`sound/taper-passive`): each section is the cylinder of its frustum's volume (staircase); straight ducts are untouched. The network then matches the transfer matrix within 0.05 dB below 500 Hz, its peaks at 315 / 785 Hz on the matrix's 315 / 790.
- ACME at 0.5 m, overall: (a) +5.6 -> -0.1, (b) +9.3 -> -1.3, (c) +6.1 -> -0.5 dB against the book. Bands still off: (a) 500-1000 Hz -9 dB, (c) -12 dB (the scan's page curve may hold some of it), (b) below 250 Hz -5 dB.
- Catalogue: only the Merlin (12 tapered ducts) and the RD350 (6) change; K20A bit-identical (showcase render, master). Merlin exhaust -6 dB throughout, least above 1 kHz; RD350 -5 to -6 dB at idle and low speed (63 Hz octave -15), +1 to +2 dB at 9,600 rpm. Same number of lines and junctions: real time not measured, nothing to cost. The owner judges by ear: both builds delivered.
- Not kept: an interior tap reads the raw lines while the junction sees them wall-filtered; near an open end at low frequency that read was 9 dB off. A tap at a duct's end is exact (`5820773`). The ACME matrix comparison used an interior tap (60 mm in, away from such a cancellation); the test cone's was checked at its ends, and the overall levels use no tap.

## 2026-11-15 — ACME diesel single against Winterbone & Pearson: the pipe is right, the radiated sound 6-9 dB loud

- Case: the ACME-ADN 43W (426 cc, CR 19) with the three silencers of Winterbone & Pearson (1999) 6.6.2, `tests/reference-data/winterbone-acme/` (book: engine, valve events, every pipe, rated 6.5 kW, the 0.5 m / 45 deg microphone; estimated and named in the file: lifts, intake, injection, load). Model 7.0-7.2 kW at the book's speeds. Book spectra read off Figs 6.12-6.14 (+-2 dB; the scan's page curve may lower Fig 6.13 above 800 Hz by up to 8 dB).
- In-pipe, 130 mm from the valve (`PressureProbeHarness`, 25 mm mesh): (b) pulse 1.28 bar at 181 deg for the measured ~1.31 at ~170, trough 0.84 for ~0.83, second peak 1.10 for ~1.14, ~10-15 deg late; the measured ringing after EVC (+-0.05 bar to 720 deg) dies by 380 deg in the model. Harmonics within +1.6 to +3.6 dB to 760 Hz. (a) within +-2 dB below 240 Hz, 7-9 dB low above. (c) +6-8 dB below 230 Hz: the resonator branch is acoustic-only, the solver has no route into it. Production mesh (one cell per 200 mm pipe): (b) peaks 1.48 bar at 205 deg, low harmonics +13 dB.
- Radiated at 0.5 m, audio network (`OfflineAudioExporter --exhaust-cell-mm 25 --convolution 0`, exhaust stem, pascals from the 140 dB full scale): overall +5.6 (a), +9.3 (b), +6.1 (c) dB over the measurement; below 500 Hz +5 to +10 dB in every case. Production mesh (b) +7.5. The excess sits on the network's own peaks (+10-25 dB) while its troughs match: under-damped resonances, not a gain. The jet is negligible here (11 dB).
- The same outlets' finite-volume flow as a monopole (no audio network) reads 2-17 dB UNDER the measurement: the truth lies between the solver and the audio network. Not separated: the semi-anechoic floor (0 to +6 dB on the measurement, mic height unknown), the load of the test (not stated; the in-pipe peak agrees), the lift profile.
- Lead, not fixed (a sound change): the audio exhaust network's damping (lossless junctions, wall loss) against the measured ringing; it needs an in-pipe probe of the audio network. Nothing in the physics or the default sound changed.

## 2026-11-15 — turbos at high speed: the fitted turbine, not the exhaust valve

- `DynoCurveHarness`, three turbos, full load: the I5 loses 32 N.m from 4,000 to 5,600 rpm at flat gross IMEP (25.5-25.8 bar), all of it pumping (-0.67 -> -2.22 bar); mean port back pressure only 0.93-1.15 x boost, but the cylinder's exhaust-stroke mean is 1.4 bar over it at 5,600. EJ25 falls 12 % from 4,000 to 6,000 (maker 6 %), the 2JZ 4 % (maker 4.5 %): the two generic heads (`turbo_street`, derived valves) fall too steeply, the benched 2JZ does not. BSFC 270-335 g/kWh at lambda 0.82-0.88: not over-efficient.
- Exhaust port plateau 0.51 -> 0.65 (`DynoSweepHarness --exhaust-port-plateau`): at most +0.8 % (I5 6,000 rpm), EJ25 +0.2 %. The valve is not the cause.
- Turbine area 700 mm2 (the default) for the fitted 450 / 500 / 600: I5 +5.5 to +8.8 % from 4,400 rpm (pumping -0.3, gross +1.2-1.5 bar), EJ25 +4-6 %, 2JZ +1.5-2 %; but the I5 holds 145 kPa at 2,000 rpm for 248 (shaft 0.54 of design). The areas were fitted (not measured) to the makers' low-speed torque, and that fit costs the top end.
- Lead, not proven: the turbine is one isentropic orifice (`restrictionOrificeFlux`), choked from a pressure ratio of ~1.9. A radial turbine (nozzle and rotor in series) chokes near 3 and passes much less at low ratios for the same choked flow, so a real one spools early and still swallows rated flow. Needs a turbine map law (Watson and Janota 1982; Payri et al., Energy Convers. Manag. 55, 2012) and a refit of every turbo: nothing changed.

## 2026-11-15 — turbos at rated power: the spark map retarded boost twice

- Makers' points at HEAD: 2JZ -10.9 / -9.8 %, EJ25 -9.2 / -13.7 %, I5 -6.4 / -12.8 %. One factor at a time (`DynoCurveHarness`, `KnockLimitCalibration`, sweeps with `--octane` and `--advance-offset`): the 2JZ burned at CA50 19-23 deg ATDC with no knock; +4 deg gave +2-3 % with none, knock from +8.
- Cause: the generated ignition map took 5 deg per bar above load 1, an unsourced rule older than the end-gas model and its control. Removed (9732f60): 2JZ +3.3 / +3.5 % at 4,000 / 5,600 (advance 9.6 -> 14.0, 10.8 -> 15.2, EGT -17 C, knock 0), Merlin +1.1 / +2.6 %, Hayabusa and CP4 within 0.2 %, atmospheric engines identical. EJ25 is held by knock control (4-5 deg retard, CA50 12-13), the I5 by its `knock_limit_curve`.
- I5 curve re-measured on today's physics: 2.5-7.4 deg more advance, sweep +0.5 to +4.2 %, knock 0. Not kept here (`exp/i5-knock-limit`): `AudioRender`'s dyno cannot hold a 24 bar engine (integral 1.2/s, 4 s), so the I5 ends the render at 4,638 rpm for its 3,905 target (4,148 before) and crosses the 130 dB gate. Faster or scheduled absorber gains move every other engine's render: refuted as the fix.
- Tests: the 2JZ runaway fixture is 3.59 bar (3.84 before) and now asserts past the bounds the line must hold; anti-lag at 0 and 50 % kept both end at the wastegate's shaft speed (131,163 / 131,448), so their order is asserted within 1 %, the 90 % run below both.
- Open: high-rpm exhaust-stroke pumping rises on all three (I5 -1.93 -> -3.27 bar), with back-pressure only 1.0-1.15 x boost. Full-load sound of the 2JZ and Merlin was not compared before/after.

## 2026-11-15 — flame: Poulos-Heywood felt as S_L^(2/3) holds full load, loses the idles (not kept)

- Hires, Tabaczynski and Novak (SAE 780232, eqs. 19, 30): an eddy burns in lambda/S_L, so the burn rate goes as (u' S_L)^(2/3). Built: laminar part x Poulos-Heywood, turbulent part x its 2/3 power, coefficient 1.12 -> 1.29, five anchored engines re-anchored at their measured residual (`residual_spark` x 3.766): flat-6 0.50, Big Twin 0.55, radial 1.15, RD350 3.00, EJ25 1.68 (at 6,000 rpm, 9.4 %; anchored at 4,000 its power read -15.2 %). Local branch `exp/hires-dilution` (c610727).
- Full load: CatalogReference -1.9 / +1.6 % against the freeze, all PASS; turbos -1.8 % at rated power (back-pressure residual). Off the list, Merlin/radial/13B/CP2 full/lab twin -0.1 / +0.7 %, RD350 -0.9 / -1.5 %. CombustionPhasing CA10/50/90 within 2 deg of HEAD.
- Idle (`IdleStabilityRegression`, alone): with the load term 22 failures (flat-6 427 rpm for 780). Without it (Tabaczynski: u' follows the piston; Hires: part load is slow through its residual) 13: flat-6 509 rpm at 30.5 % residual (`--idle-firing`), S_L x 0.20 there; blip minimum 2JZ 631 -> 547, Hayabusa 1,242 -> 940, CP4 1,348 -> 1,009; RD350 idles 1,431 for 1,300. HEAD passes.
- The catalogue's idles were calibrated on the unsourced law (0.78 x products-only fraction, x0.96 at idle, with the load term x0.4). Keeping the sourced law means recalibrating several idles, so every idle sound moves: an owner's decision. Nothing changed.
- Winterbone and Pearson (Theory, 6.1, 6.3) for the exhaust's joints: the area step is Benson's model, already built and set aside on 2026-11-04 (aafd3e3); the constant-pressure junction is their accepted default, and the solver's 2-into-1 reads K 0.14-0.16. Nothing changed.

## 2026-11-15 — anti-lag: one torque sample decided the first 150 ms of a lift

- After the flame fix, `ctest -j 4` 107/108: `EngineLab.AntiLag` (alone too), 0 % kept 4,998 -> 5,027 rpm. Traced (`--trace 0 0 100`) with and without the fix: the PI seeded its filtered torque on the lift frame's `state.torqueNm`, +940 N.m (a firing) before, -7 after. On +940 the air stayed shut 150 ms, the manifold fell 190 -> 115 kPa and the engine lost 500 rpm; the test passed on that.
- Now seeded on the target (air open, most firings cut, as the code's comment says). 2 s after the lift: 0 % kept 4,938 rpm, 50 % 3,830, 90 % 3,154; shaft kept 0.987. Test passes; the rest of the suite was not rerun (the branch only runs with anti-lag armed and active).

## 2026-11-14 — flame: the front was diluted by its own products; Poulos-Heywood measured, not kept

- `FlamePhysicsModel::advance` recomputed the speed each step from the cylinder's mean burned fraction, which climbs with the flame's own products (products-only ~0.27 by the end). The dilution now reads the unburned charge at ignition (`FlameEvent`). CatalogReference: +0.5 to +2.9 % (flat-6 the largest), TDI identical; test fails without it.
- Poulos and Heywood SAE 830334 (S_L x (1 - 4.062 f + 4.706 f^2), on Heywood's residual = products-only x 3.766 for gasoline) as a multiplier on the whole flame speed: -0.1 to -8.7 %, worst on the turbos (2JZ power -10.9 -> -18.7 % against its maker, past the 15 % tolerance). Not kept: it is a law on S_L, and this model has no burn-up time (lambda/S_L) for it to act through. Applied before the freeze it gave -45 to -75 % (the products counted as residual).
- The load term (0.28 + 0.72 load) stays. Tabaczynski SAE 770647 has u' following the piston, not the load, so it is a stand-in for part-load dilution; removing it is not measurable on makers' points (full load) and nothing here is a part-load reference. Its replacement is the full entrainment/burn-up model.

## 2026-11-14 — exhaust noise: jet at ambient rho0/c0 without the x100; muffler flow noise

- Tanna (JSV 50, 1977) and Viswanathan (JFM 516, 2004): a hot jet radiates into the ambient, W = K rho0 A U^8 / c0^5. The code used the hot rho and c, (Tj/T0)^4 too low (+9 dB at 500 K, +19 at 900), and an authored x100 made it up. Now ambient, K 1e-4, no x100.
- Green and Smith (1988) via Onorati (Winterbone and Pearson 1999, 6.12): each silencer element radiates W = eta (rho u^3/2)(pi D^2/4) M^1.5 from its tailpipe, eta from Figs 6.43/6.45 (perforate porosity held to the measured 4.2-27 %), pink 44 Hz-11.3 kHz (`MufflerFlowNoise`). Checked against eq. 6.36 within 0.1 dB.
- AudioRenderHarness catalogue (rms / brightness): I5 0.0410/0.092 -> 0.0463/0.155, 2JZ 0.0311/0.076 -> 0.0321/0.105, Big Twin 0.0179/0.031 -> 0.0188/0.125, CP2 0.0179/0.054 -> 0.0186/0.092; open stacks' jets drop (flat-6 6.6 -> 1.5 Pa). PASS, max similarity 0.530. Not listened to.
- Unknown: how much a packed lining absorbs this noise (Green and Smith tested dry elements).

## 2026-11-14 — turbo tone, lean knock, two-stroke scavenging against their sources

- Turbo: Raitor and Neise (JSV 314, 2008): compressor sound grows as U^5-6 against aero power U^3, so the tone's efficiency now scales with (tip-speed ratio)^2.5. 2JZ transient fiPa 0.927 -> 0.934 Pa, rms unchanged. The absolute level (1e-6) stays unsourced; designed turbos have no blade count, so no whine.
- Knock: Gauthier, Davidson and Hanson (Combust. Flame 139, 2004) print no correlation; a fit of their Table 4 gives the delay x phi^-0.64 below phi 1 (now in `EndGasKnockModel`). Catalogue makers' points bit-identical (none runs lean). Their EGR effect is not added.
- Scavenging: Sher (PECS 16, 1990) and Sweeney et al. (SAE 850178) have SE a function of scavenge ratio and porting, the ranking constant with speed. The model's front is the delivered volume over Cd A L, so it is that already; only its header said otherwise (fixed). RD350: trapped-charge SE 0.79-0.83 over 3,000-9,000 rpm at DR 0.73-0.96, flat in speed. Sweeney's DT250 cylinder 1 reads 0.70 at SR 0.9 on swept volume, a different reference volume; the loop length (1.8 bore) is still unverified.

## 2026-11-14 — the lean misfire draw: a knee at lambda 1.60, full in 0.13

- Owner's papers. Quader SAE 741055 (CFR, propane/isooctane): the limit is 0.5-0.8 % motored cycles; CR 6 -> 10 moves it lambda 1.22 -> 1.45; at the limit the burn takes 72-80 deg CA whatever moved it; 1,500 -> 600 rpm only 1.45 -> 1.54. Shiomoto SAE 780235 (CFR, natural gas, WOT, 900 rpm): COV of IMEP flat to a knee at 1.65, then linear, no brake power at 1.79 (0.13 further). Quader SAE 760760: at the limit, ignition and partial burn limits meet.
- So the 1.40-over-0.35 draw (41 % at 1.6) contradicts Kolodziej's chamber, which still ran at 1.6. Now flat to 1.60, 72 % at 1.73. Not done (a second factor): the onset's CR and charge-temperature dependence (Quader: ~0.06 lambda per unit of CR on 1970s chambers).
- RC8 (`--saved-ecu --step 1000`): lambda 0.905 504 ch, 1.22 367, 1.40 300, 1.60 240, all at 3.5 bar. At 0.905 it burns ~30 g/s, over the 26.4 g/s of 95 kg/h; 610 hp on 26.4 g/s needs ~212 g/kWh, the model gives 270-290. So the efficiency, not misfire, is now the gap. The 2,000 rpm point of the lean runs is the harness's boosted free-rev start (MAP 580-615 kPa), not a result.
- Against the 1.40 rule: catalogue dyno 74 of 111 rows moved, 1 over 0.5 % (K20 7,000 -0.72 %), 12 over 0.1 %; drive pulls identical; renders: 21 identical, Hayabusa, RD350 and idle-start within 0.02 dB RMS, octaves 0.2 dB.
- `ctest -j 4` 107/108: `EngineLab.AntiLag`'s 850 C limit asserted the blocker on the lift's last frame. Traced under both rules: the 50 C band cycles it (on 1.1 s, off 1.5, on 1.6, off 1.9-2.0); the old rule ended off by phase. Now asserts a working anti-lag let go by the heat (fails with the let-go path removed); passes.

## 2026-11-14 — the lean misfire draw starts at lambda 1.40 (sourced), not 1.12

- Source (open access): Kolodziej et al., SAE 2017-01-0671 (OSTI 1501899), port-injected single cylinder, CR 12.1, 1,500 rpm, 5.6 bar IMEPn, tumble 0.6/1.5: at lambda 1.4 COV of IMEP 2.1-2.6 % for every fuel (so under ~0.1 % misfires); at 1.6 the slowest fuel at low tumble no longer ran. The onset moves 1.12 -> 1.40; the slope (0.72 per 0.35 lambda) stays unsourced.
- Owner's RC8 (`--saved-ecu --step 1000`): lambda 0.905 ~504 ch (unchanged within noise); 1.22 367 ch max (was 269); 1.40 297 ch at 6,000 (was 83), the 2,000 rpm point stalls. BSFC 291 g/kWh at 6,000, 536 at 9,000 (real ~210); knock 0.8-0.9 at 8-9k even lean (Douaud-Eyzat has no lambda term). Those two are the gaps left.
- Catalogue dyno (`--step 1000`): 94 of 111 rows moved, torque mostly within +-0.5 %, no sign (2JZ 3,000 -0.44 %, I5 2,000 +0.46 %): lean warm-up cycles now fire, so the warm start differs. Drive pulls: 2JZ, I5, EJ25, Flat-6 differ; K20 identical.
- Sound (`AudioRenderHarness`, bit-deterministic run to run): 21 of 24 renders differ from ~1.1 s on; catalogue RMS within +-0.11 dB, octave bands 63-8k within +-0.5 dB, worst 0.5 s segment 0.9 dB (Merlin, RD350). Not catalogue: EL-20 I4 +1.2..+2.7 dB at 2-8 kHz. Not listened to.
- `ctest -j 4` 108/108 (EJ25 tip-in `StandingStartSettledIdle`, `Core` misfire test included).

## 2026-11-14 — a lean DTM engine: no boost runaway, a stalled engine destroyed standing still, the lean misfire draw

- Owner's RC8 at the published specs, AFR 18 in the boosted cells: MAP read 4.2-6.4 bar. Traced (temporary): the dyno's absorber stalled the misfiring engine (35 % at AFR 18.3-19.7) from 10,300 rpm in 0.15 s; the turbo, still at 1.2x its design speed, held 6.5-7.7 bar against a stopped engine. Not a wastegate fault.
- Then damage rose 0.02 -> 1 in 3 s at 0 rpm: the over-pressure term read the last completed cycle's peak (508 bar), which nothing replaces once the crank stops. Now counted only at 220 rpm and above (where it fires). `EngineLab.PeakPressure`: a K20 stalled at full throttle on a 40 bar limit kept 0.143 at rest (the test fails before). Catalogue K20, 2JZ, I5 sweeps bit-identical.
- Petrol AFR limit 18 -> 30 (lambda 2.04); saved tables widened on load. A hand-edited file still validates against its own stored limit before the widening.
- Then RC8 at lambda 1.22: 269 ch max (506 at 0.905); at lambda 1.40: 83 ch, nothing at 8,700. The cause is the lean misfire draw (`EngineSimulator.cpp`, from the first commit, unsourced): 0 at lambda 1.12, 0.72 x (lambda - 1.12) / 0.35, so 21 % at 1.22, 58 % at 1.40, the 0.92 cap at 1.57. Production homogeneous lean-burn engines ran near 1.4-1.5 (not sourced here); Quader SAE 741055/760760 and Shiomoto SAE 780235 are paywalled. Not changed: the EJ25's tip-in recovery rests on it (journal entry "AFR ~19.7, misfire chance 45 %").

## 2026-11-14 — knock under high boost: Douaud-Eyzat is not what stops the owner's 610 hp DTM engine

- Owner's saved "Audi RC8" (2.0 I4 turbo, CR 12.5, 2.5 bar abs, knock control off, no intercooler): knock 0.8-0.9 at every speed, 444 ch; `DynoSweepHarness --saved-engine --saved-ecu` (new: the file's own ECU tables). Control on and intercooler 0.7: ~500 ch. At the published specs (CR 15, 3.5 bar, RON 102, control on) it still knocks with the 12 deg authority spent: 506 ch.
- Onset traced (temporary, removed): spark ~4 deg ATDC, autoignition 15-45 deg ATDC at 115-275 bar and 775-1,030 K, 20-60 % of the charge unburnt. Turbulence x1.5: 588 ch, onset earlier and higher, still knocking.
- Delay as the model uses it (D-E x2, RON 102) against boosted-engine correlations (Cho et al., Energies 2019, Table 1; all within 15 % of D-E x1 at 40 bar/800 K): at 118-250 bar it is 1.4-2.7x Hoepke 2012's, 2.5-2.8x McKenzie-Cheng 2016's, 5-7x Chen 2014's. The model is already more lenient than any of them; no change made.
- Not settled: the real engine's lambda (fuel flow 95 kg/h suggests ~1.4, unverified), burn rate and IVC. The lean test is the entry above.

## 2026-11-14 — anti-lag audit: cut locked on cylinders, rich mixture, exhaust limit read in the wrong place, surge on letting go

- `EngineLabAntiLagTests` (2JZ, I5; lift at 5,000 rpm after 3 s of full boost). Cut: the pattern over the engine's firings locked whole cylinders (90 %: 2JZ lit only 1, 3, 2; I5 only 1). Now each cylinder cuts its own cycles, golden-ratio staggered: every cylinder lit 0.28-0.38 of its cycles (`--cut`).
- Mixture: the oxygen at intake close counted a cut cycle's retained charge as air (720 mg trapped for 560 delivered): AFR 10.4 for 13.2. Fuelled on the delivered air: 13.5 (`--mixture`). Refuted: holding the trim at 1 instead (AFR 12.2).
- Exhaust limit: it read the cylinders' mean (420-570 C), never let go. Now a turbine-inlet probe (0.5 s): 1,019 C after a full-boost pull, so 1,000 C held anti-lag off on every lift; default 1,050 C (Garrett G-Series housing and wheel rating). At 0-50 % kept the 2JZ reaches it ~1 s into a lift.
- Letting go there (or at any exit) with the pedal shut, the plate it held closed over 0.3 s and the boosted manifold fired normal charges: +370 N.m, the engine +530-854 rpm. The overrun fuel cut now starts at once: 0 rpm (the new assert fails at +854 before).
- Refuted: opening less air over the last 50 C (50 % kept: -29.8 N.m for -18.5 asked; a plain exit -20.4 for -19.6). The controller asserts now run with no limit; 90 % kept reaches 1,340 C there.
- Not checked: the sound, the screen, other engines, a measured turbine-inlet temperature under anti-lag (the simulated 1,019 C at full boost may be high).

## 2026-11-14 — the active valve's branch has its own tailpipe; opening it does not lower the K20A's back pressure

- Owner: each branch its own outlet. `EngineLab.ExhaustValve`, K20A, mean port pressure at 4,000 rpm full throttle (absorber held). Before (bypass merged after the silencer): shut 109.1, open 104.2 kPa. Now: stock 99.63, shut 99.62, open 100.96 (6,000 rpm: 99.44 stock, 99.52 shut, 100.84 open).
- So the old 4.9 kPa came from the merge, not the silencer: the K20A's silencer restricts 0.25 (~0.2 kPa mean), and the split loses more than that. The bypass's tailpipe first took the default outlet's 300 mm; now a twin of the branch's own (70 mm bore, 0 mm).
- The test now asserts shut = stock within 0.05 kPa and open moves it by > 0.5. Not checked: the sound open against shut, a real silencer's restriction (no reference).

## 2026-11-14 — 3-D: real-scale chamber, journals, V stagger, collectors that face their primaries, two-stroke chambers apart

- `EngineLabSceneExport` route counts over the catalogue (clash, self, engine, tight bend, stretched): before 11, 4, 0, 51, 7; after 4, 4, 0, 46, 6. The head on its real clearance (stroke / (CR - 1), was 1.5 mm): 2JZ +2 clashes +1 bend, its 6-into-1 moved; a flat-6's runners 8 % long until the plenum's reach counts the S its runners make (0.81 L^2 - (1.1 offset)^2).
- A collector with 3+ primaries and ports beyond its mouth turns its mouth across when every primary reaches it (lead + entry + 1.2 x distance <= length); a turbo one feeds the turbine straight. I5: 2, 4, 1 -> 0; TDI 1 clash 1 bend -> 0. The 2JZ's end primaries (430 mm) need 479: it keeps its place.
- Chambers of separate paths spaced by the widest part of their straight run (not the header cone): designed V4 two-stroke (54 x 54, 90 deg) 14 clashes -> 1-3, none past the ports (the check fails at 12 without it); RD350 6 -> 0; no other catalogue duct moved.
- Designed V8 shared pins: banks 0.23 bore apart (was a throw); V6 separate pins 0.49. Not looked at on screen; the camera microphone hears the drawn outlets, so the I5 (~110 mm) and the RD350 (50-90 mm) tailpipes move what it hears a little.

## 2026-11-14 — gearboxes: an automated manual cuts fuel and spark before its clutch opens; the automatic changes down on demand

- Automated manual, owner report "the engine keeps accelerating while it shifts". `TruckDriveTests`, K20A and 2JZ given an automatic AMT, flat out 20 s. Before (throttle cut alone, clutch opened on the timer, controller starting a third of the shift early): K20A clutch open at 8,215-8,303 rpm, then +220-310 rpm free, the limiter hit for 17-25 ms on every shift.
- After: fuel and spark cut at the start with the clutch shut, the clutch opens once the cycle torque is gone (at most 0.15 s), the cut held while it is open, the throttle back with the slip as before; the controller changes up at the point itself. K20A open at 8,125-8,175, at most +33 rpm free, no limiter; 2JZ +3 rpm; the designed truck keeps its gates (open at 1,797-1,846 for a 2,200 limit, no flare). New asserts fail before.
- Automatic: a downshift line at 0.72 x the pedal's upshift point (production 3-2 lines sit near 0.7 x the 2-3, not fitted to one car), raised by the brake to half the full-throttle upshift; lugging stays the floor. Half pedal in sixth at 1,600 rpm now takes fourth (it held fifth); braking in fourth at 1,600 takes third or lower. A light pedal at 2,000 rpm holds sixth. Not checked on screen.
- Gear count typed, no cap (the validator capped 12, the menu offered 16): a 20-gear box validates and reaches its 19th flat out in 30 s.

## 2026-11-14 — real time since 0.8.1: the engine runtime has not slowed (nothing changed)

- Owner report: real time "strongly degraded" on four- and two-strokes since recent changes. `RealtimeBudgetHarness --free-run --warmup 2 --seconds 4`, each version built alone on 14.44 (worktrees, harness target only), interleaved, order alternated, the first pair discarded, best kept.
- 0.9.1 (0921d78) -> HEAD (94312ea), 5,000 rpm, catalogue: K20A 1.601 -> 1.581, 2JZ 1.620 -> 1.591, RD350 1.830 -> 1.833, I5 1.482 -> 1.490.
- Same at 1,000 rpm with `--with-audio --gas-view` (the app's audio and 3-D gas view): K20A 2.863 -> 2.792, 2JZ 3.094 -> 3.163, RD350 3.034 -> 2.927.
- 0.8.1 (c0b4639, its own catalogue) -> HEAD: K20A 1.543 -> 1.516, 2JZ 1.554 -> 1.513, RD350 1.772 -> 1.769, I5 1.471 -> 1.478. Every pair within 2-3 %, the harness's noise.
- So the simulation thread, the audio renderer and the gas view cost what they did. Not measured: the application's own threads (UI, OpenGL), the optional fittings (exhaust valve, nitrous, anti-lag, pass-by microphone) and designed engines. The application shows no capacity figure from a command line, so its cost needs the window.

## 2026-11-14 — anti-lag holds boost

- Owner report: nothing like a real one. 2JZ lifted 2 s from full boost at 5,000 rpm, 50 % kept, before: manifold 20-110 kPa hunting (37 at the end), shaft 64 %, 1.2 % of the fuel burnt before the turbine. Where its fuel sat (fuel-weighted, before the turbine): 65 % too rich (phi 1.97 > 1.80), 33 % cold (761 K), 1 % burning. A cold rig: walls 334 K 4.5 s after the start (764 K after 40 s at full load, the EGT 894 C), so the hot run is the one to judge by.
- One factor, the rich limit widened with temperature (Zabetakis, Bureau of Mines Bulletin 627: x(1 + 7.21e-4 (T - 298 K)); anti-lag armed only, the closed backfire keeps 1.80), hot: 13 -> 49 kW burnt in the network, EGT 894 -> 995 C, shaft 87,000 -> 93,400 rpm.
- One factor, the controller: it shut the air at once on any driving torque and hunted (limit cycle ~0.6 s). Now a PI that cuts up to 90 % of the firings before it closes the air: manifold 151 kPa over the last second, shaft 91 % (disarmed 16 kPa, 53 %), 21 % of the fuel burnt before the turbine; cold or hot alike. Maximum cut 75 % kept only 70 % (it had to shut the air), 100 % gives the same as 90 %. EJ25 80 %, I5 94 % of their loaded speed.
- `EngineLab.AntiLag` checks boost, 80 % shaft and a tenth of the fuel before the turbine; it fails without either change (shaft 65 %; manifold 56 kPa).
- Measured, not fixed: the fuelling is 13-35 % richer than its lambda (the trapped-oxygen reference counts a cut charge's retained oxygen as new air; the port metering adds ~15 %). Fuelling the delivered air instead moved the chamber AFR 9.8 -> 10.4 but not the targets (shaft 90 % without it), so it was left out. EGT telemetry is the cylinder-out mean: with 90 % cut it reads ~420 C cold, so `antilag.egt_limit_c` under-reads the manifold. Not tested: the sound of the bangs, a car on a road, the window on screen.

## 2026-11-14 — pass-by never reached the audio

- Owner report: a run sounded from the camera, no distance, no Doppler. Cause: `EngineRuntime` filled `EngineState::passBy*` after `publishAudioFrame`, so the audio always read phase 0 and the microphone never switched on (the UI, reading the later snapshot, did turn the camera's microphones off). Now filled at the frame's creation. `EngineLab.PassByRun` drives the real runtime thread (phase 1 at -300 m published, 0 once stopped; it failed without the fix) and a renderer (its car at -300 m). Not tested: the run heard in the app.

## 2026-11-13 — pass-by run and propagation

- Owner plan step 4: `PassByDriver` (runtime) drives a real K20 car rig in `EngineLab.PassByRun`: standing start from 150 m, 113.2 km/h at the microphone after 8.24 s, 8,480 rpm peak, third gear, finished after 17.8 s; launch control holds the staging at 4,057 rpm (limit 4,000); 50 km/h held in second within 0.63 km/h, 57.2 km/h at the microphone on the 10 m full-throttle program.
- Propagation checked against the exact formulas, not the simulator: ISO 9613-1 (20 C, 70 %) 2.80/4.98/9.02/22.9/76.6 dB/km at 0.5-8 kHz, heard within 0.3 dB from 10 m to 1 km; Delany-Bazley + spherical wave Q (Faddeeva against scipy) within 0.1 dB at band centres for asphalt, gravel and grass at 7.5-500 m.
- Corrected: the previous trackside test's ISO figures (9.7 dB/km at 2 kHz, 32.8 at 4 kHz) were the 10 C row of the table, not 20 C.
- Limits: the comb's notches stay where a hard ground puts them (the image is a real reflection, its magnitude at the first notch), the porous part is third-octave levels; no turbulence, refraction, wind or directivity. Not tested: the window on screen, a WAV from the app, a run heard.

## 2026-11-13 — anti-lag feedback

- Owner plan step 3. Measured first, where the fuel burns (new bookkeeping, `EngineState::exhaustFuelInMgPerSecond` and siblings), 2JZ lifted 2 s from full boost at 5,000 rpm unloaded, 50 % kept: injected 5,999 mg/s, 3,364 into the exhaust unburnt (56 %), 176 burnt there (5 %), 74 of it before the turbine, 3,114 out of the tailpipe.
- Refuted for anti-lag: 40 ms exhaust pockets burn 2.6x more but mostly after the turbine; the shaft does not move. The turbo is held by the air and the late in-cylinder burn, so the air is the lever: a lever sweep gave +3 % shaft at the old 20 % air, +22 % at 40 % (the new default).
- The old fixed opening made the engine climb (3,500 -> 5,390 rpm). Now a torque feedback on a drag model (friction + 0.65 bar shut-throttle PMEP): torque -23.3 for a -24.3 N.m target at 50 % kept, -37.3 for -41.9 at 90 %, +0.29 N.m at 0 % (holds); shaft 83,801 vs 68,572 rpm disarmed (1.22x), 93,861 at 0 % kept; peak 5,420 rpm armed vs 6,469 off (the lift's own overshoot, which DFCO does not stop).
- Launch mode, 4,000 rpm on the line for 3 s: shaft 115,616 vs 73,545 rpm, manifold 180 vs 120 kPa, 3,841 rpm. Exits tested: time, EGT, max rpm, neutral. Not tested: a car in gear on a road, the real window on screen.

## 2026-11-13 — tuner group pages

- Owner plan step 2: a scalar sharing its prefix with another scalar goes on one page (`EcuTunerComponent::pagesOf`); 2JZ: Anti-lag (6, switch first), Limits (3), each a single selector entry. Tested in the Audio workshop GUI test: no selector item for a grouped key, six rows, a typed row published. Not tested on screen.

## 2026-11-13 — Equipment window

- Owner plan 2026-11-13 step 1. Nitrous was not broken: its chain is right, but it needed four unseen conditions (armed, `=` held by default, 95 % throttle, 3,000 rpm), and Drive, unscrolled, could cut its switch off. Now: no push button on a new kit, `EngineState::nitrousBlockers` per condition, an Equipment window with a live status per part, a scrolling Drive panel.
- Tested: `EngineLab.Nitrous` (blocker bits; a K20 at 5 % throttle unloaded runs over the 2,000 rpm the other checks use, so this one sets 5,000) and the Audio workshop GUI test (fit, refill, three status texts, remove, a bypass valve fitted on the 2JZ, the designer callback). Not tested: the real window on screen.

## 2026-11-12 — physical anti-lag

- Owner plan step 10: ECU keys `antilag.*` (off), throttle held open, late spark, own lambda, a firing-order spark cut with fuel kept; armed runs the exhaust reaction model, working is an afterfire window. No new chemistry: the existing in-network oxidation burns it.
- `EngineLab.AntiLag`, 2JZ lifted 1 s from full boost at 5,000 rpm (unloaded): shaft 129,322 vs 96,303 rpm disarmed, manifold 101.6 vs 17.1 kPa, 11.1 kW burnt in the network, 35 % of sparks cut. Off: bit-identical to tables without the keys.
- One factor at a time, armed: manifold burn off (reaction efficiency 0) 128,804 at 5,000 (-0.4 %, wastegate-limited) and 119,110 vs 122,850 at 3,500 rpm lifted 2 s (-3 %); a 0.5 ms reaction instead of 10 ms 124,225 (18.9 kW). So most of the held speed is the open throttle's flow and the late, hot in-cylinder burn; the manifold burn adds a few percent. Air 10 % at 3,500 does not hold the turbo (66,603 vs 67,012).
- Unloaded, armed, the engine climbs (3,500 -> 5,390 rpm in 2 s at 20 % air): net torque stays positive. Not tested in a car in gear; no UI run seen; not in the full ctest yet.

## 2026-11-12 — a nitrous kit

- Owner plan: a kit hidden until fitted, unlimited if wanted, no limit on a figure; off on every engine. One plenum nozzle; nitrous as 0.5 O2 + N2 per mole with its enthalpy less Watson's latent heat; 82 kJ/mol released at the burn by the kit's oxygen share; jet 2.27 kg/min per 100 hp at 900 psi (energy balance at 30 % brake efficiency; install sheets 1.8-2.7), as the root of the drop; bottle at nitrous's vapour pressure, cooling without its heater.
- `EngineLab.Nitrous` (dyno hold, 3 s spraying): K20 wet at 6,000 rpm 124.0 -> 181.7 kW (+77.3 hp for a 100 hp shot), AFR 13.27 -> 12.55, peak 81.6 -> 91.3 bar; LS3 dry at 4,500 272.3 -> 328.7 kW (+75.6 hp), AFR 13.26 -> 12.66; flow 2.287 kg/min at 62.96 bar both (rated 2.27 at 62.05). Knock 0 on both.
- So the model gives about 77 % of a kit's rating at its rated flow, retard (4 deg here) included. Not separated: the retard, the gas volume the nitrous takes from the air, the marginal efficiency. A dry kit at lambda 2.0 ran 16.3:1 against 11.9 at 0.8 with the trim held, but no knock on the LS3 at 4,500 rpm: the "lean kit knocks" case is not shown.
- Without a kit: K20, 2JZ, 13B, RD350, TDI `DriveScenarioHarness --builtin pull` bit-identical to before (10,801 rows); a fitted kit disarmed is the engine without one over 720 frames (the test). UI: `EngineLab.AudioWorkshop` fits, edits, refills and removes a kit in the Fuel window; not seen in the running app.

## 2026-11-12 — boxes inside their window, only when they show whole

- Owner report after the in-window pass: some windows "display very badly, or not at all". Seen in the app: the engine picker's list over the 3-D view showed a strip a few pixels wide (the rest under the OpenGL surface, a native child window on Windows that hides anything its window draws over it); the Fuel window's fuel list was cut to three entries by the small window. `placeInWindow` also shrank a box larger than its window (`constrainedWithin`).
- Now menus are desktop windows again (no `getParentComponentForMenuOptions` override: a menu's size is not known there); `placeInWindow` moves a box in only when it fits whole and covers no view marked `ui::markNativeView` (the 3-D view, while attached), otherwise it stays a desktop window centred over its window.
- `EngineLab.AudioWorkshop`: a menu's parent is null; a box over a marked view and a box larger than its window stay desktop windows, unshrunk; unmarked, the box goes in again. Not measured: every dialog in the running app one by one (picker and Fuel list seen before, not after, the fix in this entry).

## 2026-11-12 — a trackside pass-by microphone

- Owner plan: the car heard from beside its lane as it drives past (ISO 362: 7.5 m, 1.2 m up), on the cruise control; Doppler, ground reflection, air absorption, 6 dB per doubling; off by default.
- `PassByMicrophone`: the master split into the exhaust's share (at the tailpipe, the wheelbase behind) and the rest (at the engine), two points 0.5 m up moving at the vehicle's speed over -150..+150 m, two microphones 0.18 m apart, a direct and a ground-image path each at its retarded time (exact for a constant speed), 1/r, two one-pole low-passes at 58 kHz / sqrt(r). The camera microphone's glide (2 % Doppler, 40 m) could not carry a pass-by.
- `EngineLab.PassByMicrophone`: 500 Hz at 30 m/s reads 547.901 / 459.813 Hz, exactly the retarded-time values; 10 to 20 m 6.02 dB; the ground notch 24.02 dB down (24.02 expected); air over 90 m 0.86 dB at 2 kHz, 2.93 at 4 kHz (ISO 9613-1: 0.87, 2.95; a first try with one pole at 46 kHz / sqrt(r) read 0.69 / 2.41, and 8 kHz still takes 7.7 of 10.5 dB). Switched on at a tone's crest without waiting for the delay line, it stepped 0.176 against the tone's 0.026 (now 0.026). 3 m behind at 30 m/s, the exhaust's tone crosses its own pitch at 2.12196 s, the engine's at 2.02196 s (2 + 7.53 m / c); with the tailpipe at the engine both read 2.02196.
- Default sound: `AudioRenderHarness --catalogue-filter` on 2JZ, K20A, LS3, 13B, RD350, WAVs byte-identical before the valve (0055570) and after this.
- Not checked: listened to in the running app, against a real pass-by recording; the tyres, wind and the car's directivity are absent.

## 2026-11-12 — an active exhaust valve

- Owner plan: a Valve part and a one-click silencer bypass with a valve; a face between two cells, not a tube; Drive's Shut / Open / Auto (rpm and throttle thresholds); ~0.3 s of travel; open = the same exhaust without it, no extra cost, no click.
- Gas network: below full opening the face uses the throttle plate's orifice code (refactored into one lambda) at the open share; at 1 the plain face. Audio: the face's admittance scaled by the opening, which glides per sample.
- `EngineLab.ExhaustValve` (K20A, bypassed silencer): open bit-identical over 720 frames; shut 109.1 kPa back-pressure at 4,000 rpm WOT against 104.2 open. Click metric: the change of the second difference from one 50 Hz period to the next (a curvature maximum mixed the two states' timbres: 1.1x apart, useless): settled 0.00016, valve moving 0.00076, snapped in a frame 0.0027, stepped in one sample 0.0070 Pa (fails).
- Bit-identity of the refactor: `DriveScenarioHarness --builtin pull` (45 s, 10,800 frames) before/after, CSVs identical on 2JZ, K20A, 13B, RD350, TDI and a K20A with individual throttles (the orifice path).
- Not checked: torque or sound shut against open on a real valved car, the Drive switch and designer menu in the running app (no GUI test), a shut valve's leak, the plate's loss when open.

## 2026-11-11 — a loop pack for games (BeamNG: loops only)

- Owner plan: seamless loops a game's sample engine sound can use; no live link to BeamNG.
- `exportLoopPack`: the idle, then every step to 0.95 x min(redline, limiter); on load full throttle on the dyno's absorber, off load shut throttle on a one-way motor (the idle's motor only a floor at 0.9 x idle); a whole number of cycles (720/360/1,080 deg), the end cross-faded into the start, an engine (combustion, intake, turbo, mechanical) and an exhaust (dry + IR) mono layer, one gain for the pack, a `smpl` loop chunk, `loop-pack.json` with each loop's measured speed. The HQ export now shares its render chain (`offline::RenderChain`): K20 48 kHz stems bit-identical before/after.
- `EngineLab.LoopPackExport` (K20A, 1,000 rpm step, 0.5 s): every point held within 3 %; without the cross-fade the idle seam steps 25 x the largest inside (fails).
- Default packs (500 rpm, 2 s): points on and off load: 2JZ 13 in 127 s, LS3 13 in 178 s, 13B 16 in 120 s, RD350 16 in 152 s, every one settled. First run: the 13B never started (a shut-throttle start released at the cut-out speed coasted down) and the RD350 stalled at its free idle; now the audio harness's start (1.1 s of starter at 20 % throttle) and the floor. The RD350's overrun runs over its target where the engine idles above it (2,000 held 2,046: a motor cannot brake); the file gives the measured speed.
- Not checked: in BeamNG (no game here), the Ogg copy's seam (lossy), the workshop button in the running app; BeamNG's `sfxBlend2D` file is not written (format undocumented).

## 2026-11-11 — menus and dialogs inside their window

- Owner request: everything "filmable" with a window capture; no live OBS test, no README section.
- Was: every menu (combo box lists included), alert box and hand-built dialog was a desktop window of its own, so a window capture missed it; tooltips showed only in the main window (JUCE's `TooltipWindow` parented to one window skips components of another peer).
- Now `LookAndFeel::getParentComponentForMenuOptions` puts a menu in its target's window (a right-click menu in the window under the mouse); `ui::showMessage` / `ui::showOkCancel` build the box at once (JUCE 8's `showAsync` builds it on the next message) inside the host's window; `ui::placeInWindow` moves Save as, the JSON editor and key bindings in; each tool window has its own tooltip window. A host in no window on screen keeps a desktop box (one centred on a component of no size would be modal and unseen).
- `EngineLab.AudioWorkshop`: a combo box's menu parent, an alert, an OK/Cancel box and a hand-built dialog are children of the window, none a desktop window; a host in no window gets a desktop box; the ECU, Fuel and Exhaust designer windows have a tooltip window.
- Not checked: a real capture (owner: none), a menu taller than a small window (JUCE scrolls it), the file pickers (the system's, still separate windows).

## 2026-11-11 — one engine file with its ECU maps, drag and drop

- Owner plan: the engine and its ECU maps in one file, old saves still loading, a file dropped on the window opening it, asking first before losing edits.
- Was: a saved engine was `<name>.json` + `<name>.ecu.json`; *Export engine* in YAML wrote the engine alone (the maps lost) and, the new test found, without `audio_voicing` (every catalogue engine's only YAML-vs-JSON difference, 18 of 18; now written); the tuner's LOAD published an old `.ecu.json` without the settings added since (VTEC, knock limit), which a saved engine's read always completed.
- Now `ecu_calibration` in the engine file (JSON: the tuner's tree; YAML: the same tree as a map, numbers as JSON writes them). The engine decoders ignore it, so the engine half is unchanged.
- `EngineLab.SavedEngine` `checkOneFile` (CP2, tables retarded 3 deg): JSON, YAML and YML round trips with nothing beside the file, config and tables read back equal; tables inside win over a stale sidecar; a 0.9.1 two-file save loads, and its next save folds the tables in; an old YAML export loads without tables; damaged tables inside JSON or YAML fail the read.
- Not exercised by a test: the drop itself and the "Replace without saving?" dialog (app only; the rule is: the edits of a menu engine left for another are kept as before, so only a running unlisted engine, the same engine's file, a script or maps over edited maps ask).

## 2026-11-11 — VTEC from EngineLab, made robust

- Owner request: VTEC (that name), fitted, tuned and switched from EngineLab, no file to edit, no sound or curve measured, "make sure it works whatever happens". Tables: `vtec.enabled/engage_rpm/hysteresis_rpm/min_throttle_percent`, only with VTEC cams; the tuner's switch, FIT VTEC CAMS and the valve inspector fit, edit and remove them live.
- `EngineLab.Vtec` (no curve): K20A, LS3, a V8 with a cam per bank, a high cam smaller than the low, 2JZ, EJ25, radial, TDI, 13B, torture W16, ~17-33 s simulated each: switched at idle, at the limiter, in a shift cut, on overrun, in launch control, cams removed on the high cam and refitted, engagement under idle and past the limiter, hysteresis 25,000 rpm, 100 % throttle: every frame finite, no stall, high cam only where fitted.
- Found by it: (1) a 100 % minimum never engaged: the plate follows the pedal exponentially (`smooth`, tau 0.1 s) and never reads 1.0; the ECU's minimum is capped at 99.9 %. (2) Cams fitted live engaged in their first frame on a cycle measured before the fit; they now wait for a cycle completed after it (`awaitCycleAfter`).
- `EngineLab.ValveProfileTransition`: the ECU's switch, a moved engagement, the hysteresis band, the throttle minimum, a live removal and refit, every transition on a base circle (24 up, 20 down). Without the change the ECU switch is ignored and the live fit refused.
- The event generator, the physics' cam metrics and the 3-D view now follow the cam each cylinder actually runs (was: the instantaneous rpm and throttle against the cam's switch). `DriveScenarioHarness --builtin pull` on K20A (to 8,389 rpm, so through its switch), 2JZ, LS3, TDI, 13B: CSV and report byte-identical to before; `AudioRenderHarness --runtime-only` K20A and 2JZ: WAV byte-identical. The default tables change nothing.
- Not measured: the sound or torque of any VTEC setting (owner: not wanted); the tuner's timer refresh after an external publish (exercised in the app only).

## 2026-11-11 — the exhaust designer's path removal and cylinder sources

- Owner report: removing one path of a V8's dual 4-into-1 "wired the cylinders anyhow, with useless collectors"; with a cylinder's default pipe deleted nothing could take its place. Cause of the first: `removePath` called the per-cylinder move, which gave each cylinder a default primary and spliced a new zero-length merge after the destination's FIRST primary: five merges in a chain on one pipe, the removed collector and its pipes dropped.
- `EngineLab.ExhaustPathTopologyEditor`, designer-like V8 dual (4 x 760 x 38 mm into a collector, mid 1,500 mm, silencer, tail per bank), run on the old code: rebuild "left 5 merges, not one 8-into-1"; a moved cylinder "did not make the 4-into-1 a 5-into-1". Both pass now.
- Y mode: both collectors, legs of clamp(0.2 x pipe on, 150, 400) = 300 mm into a Y, the mid pipe 1,500 -> 1,200 mm; every cylinder's route length to the silencer unchanged to 1e-9 mm (`ExhaustGraph::acousticsForCylinder`). Two scalar paths: Y gives a graph with 3 merges, rebuild stays scalar 8-into-1. No common junction (four separate tails): the nearest-neighbour fallback, said in the status line.
- `EngineLab.AudioWorkshop`: delete cylinder 1's pipe, add a resonator, connect it to the collector and from the cylinder (From's cylinder entry): applies valid; undo to the start gives the original back, redo the edit. A 763.27 mm tail selected then left keeps its length (the old re-read of the shown 763.3 fails the test).
- Not measured: the sound or torque of a Y against an 8-into-1 (the join only builds the geometry); the canvas drag itself (mouse) is not exercised by a test.

## 2026-11-11 — the boost that ran away on a lowered stoichiometric ratio

- Owner report: lowering the stoichiometric AFR in Fuel on a turbo engine sometimes ran the boost to 8-12 bar. Owner's 2JZ file (fuel AFR 8.0, heating value 60 MJ/kg: 32 MJ per kg of oxygen, real fuels ~13 by Thornton's rule), `DynoSweepHarness --saved-engine`: MAP 553/957/1,018 kPa at 4,000/5,000/6,000 rpm, 2,390 N.m. Two causes: the Fuel edit scaled the oxygen and the injectors with the ratio but kept the heating value; nothing bounds a turbo's shaft speed (the map's head grows as N^2).
- Fix 1: the heating value follows the ratio (constant energy per kg of oxygen) unless the user set it; the Fuel window shows that energy, marked past 14. Fix 2: a top speed line (`maximum_shaft_speed_rpm`, default 1.3 x design; the catalogue peaks at 1.074, `CatalogBoostHold`): past it efficiency x (N/Nmax)^-8, damage 2 x^2 per s, a burst at 1. Exponent and damage rate are choices, not a fitted map.
- `EngineLab.Turbocharger`, catalogue 2JZ on that fuel at 5,000 rpm, 9 s: no line 3.85 bar, shaft 1.8 x design; line 2.69 bar, 1.36 x, damage 0.02; with a 40 kPa overboost cut 2.38 bar. Owner's file with the defaults: MAP 331/314/292 kPa at 4,000-6,000, shaft 1.34-1.40 x (the wheel slowly dies there), 1,272 N.m peak.
- Refuted as a default: the overboost cut on at 40 kPa. The catalogue 2JZ's dyno spool-up overshoots by more than that (cut held 1.05 s of the sweep; 3,000 rpm torque +3 %, peak cylinder pressure +5 bar after it). It ships off (0); 40 kPa is the suggested value.
- Catalogue unchanged: `DynoSweepHarness --step 1000 --boost-hold-margin 0.05` CSV byte-identical to before the change (2JZ, EJ25, I5, TDI). `DriveScenarioHarness pull` and `downshift-clutch` on EJ25, TDI, Merlin: no overboost or overspeed second (2JZ and I5 still stall on the launch, as before).
- Not measured: a real compressor map past its last speed line, a real overboost cut's margin, the sound of an overspeeding wheel.

## 2026-11-09 — what the intake style and the carburettor change on a four

- Owner question: does airbox -> trumpets change anything but the sound? Code: the physics reads only `airbox_volume_l`, and only to keep fuel pushed back past the throttle (`throttleFlowKeepingReversedFuel`); the throttle draws from ambient whatever the style. `pod_filter`, `bellmouth_diameter_mm` and the snorkel reach the sound (`AcousticIntakeNetwork`) and the 3-D view only: no filter loss, no box resonance, no bellmouth entry loss.
- `DynoSweepHarness --step 1000`, CP4 airbox 9 L vs 0 (trumpets): every row within 0.4 % torque. Designed 998 cc crossplane four (`sport_motorcycle`): port injection airbox vs stacks within 0.4 %.
- Same four on carburettors: -2 to -7 % torque against injection (delivered VE -1.5 to -2 %, lambda 0.82-0.85). Airbox vs stacks moves it: stacks leaner (lambda 0.85-0.99 vs 0.82-0.85, the box returns pushed-back fuel) and +0.4 to +1.7 % torque.
- Layout: a CP4 (catalogue or designed) has a shared 1.4 L plenum behind its four bores, not one runner per throttle; four carburettors are four alike, meter a quarter of the total air each and pour into that plenum. A real bike's carburettors each feed one cylinder. `individual_throttles` exists (CP2 not switched: -5 to -10 %), but its carburettor still meters into the shared volume.
- Not measured: a real airbox's or filter's loss, the sound of each style.

## 2026-11-09 — the automated manual's upshift; a truck's shift point

- Owner report: an AMT upshift locks the clutch with the throttle open and hits the limiter. `EngineLab.TruckDrive` (designed 12.8 L truck six, AMT, automatic, 40 s from rest): before, flat out it changed up at 1,600 rpm (0.73 x limit), the clutch open with the throttle at 1 - `shift_torque_cut_fraction` flared the engine ~+400 rpm, 0.05-0.275 s on the limiter per shift.
- An AMT now cuts the torque fully over the first 20 % of the shift, gives it back only once the clutch has pulled the engine to the new gear, and starts the shift ahead by 0.35 x shift time x rpm rate. A designed truck changes up flat out at min(1.05 x peak power, 0.90 x redline) = 1,850 rpm.
- After, pedal 1.0: clutch opens at 1,723-1,820 rpm, no limiter, lands at 1,433-1,593, 77 km/h at 40 s. Pedal 0.5: opens at 1,488-1,598 (the light-foot rule), lands 1,195-1,404. A 10-30 rpm rise remains while the clutch is open (test bound 2 % of limit).
- The engine brake no longer acts in neutral (arbiter: forward or reverse gear only); its 18.4 kW/L in gear is unchanged. `EngineLab.EngineModel3D`: the drawn exhaust valve opens 2.0 mm more on braking cylinders, 0 on the others.
- Not measured: a real AMT's timings (0.8 s still unsourced), the Vehicle window, the brake menu and the gear-count choice by hand in the app.

## 2026-11-09 — a truck's engine brake; the refit and the automated manual

- Compression release on the exhaust valve (2 mm, cos2 over 80 deg peaking at firing TDC), fuel cut, three stages (2/4/6 of six), only on a designed `truck` four-stroke. `EngineLab.EngineBrake`, 12.78 L six (131 x 158, turbo) motored at 2,100 rpm by a PI on the shaft: drag 183 N.m off, 1,253 on, 235 kW = 18.4 kW/L; a standard Jacobs brake gives 416 kW on a 13 L at 2,100 (~32 kW/L). 0.57 x, inside the test's 0.5-1.5.
- One factor each (stage 3, kW/L): peak at -10/-20/-30 deg 17.0/12.1/7.2; duration 60/120 deg 17.9/18.2. Earlier opening or a longer event does not close the gap; lift, boost while motoring and the turbine's back-pressure are not measured.
- Fuel at 1,400 rpm, pedal 0.01: 0.188 g/s off, 0 on.
- The fuel/intake refit (`withFuelSystem`, `withIntakeStyle`) moved the designer's sizing into shared functions: `DesignBench` on 11 specs (port, DI turbo, carburettor, trumpets, pod, V8 super, diesel, aircraft, 2T carb, 2T DI, rotary) against the old parts: values and YAML byte-identical.
- Designed 12.8 L truck six, `RealtimeBudgetHarness --free-run --with-audio --relative-rpm 0.9`: 1.77/1.66 (two runs, no control engine), no audio drop; `--designer-probe` 1.90.
- Not measured: the brake's sound, the automated manual's 0.8 s shift (unsourced), the truck parts (TraXon ratios; the rest estimated), the app by hand.

## 2026-11-09 — a single's turbo: drawn, on the network, its gate doubled

- Owner report: a turbo on a single is not drawn and cannot be set. `collectorTurbineFaces` and the 3-D layout both needed a junction with >= 2 inputs: the single fell back to the lumped outlet turbine. Now a path with no junction puts the face out of the one pipe its ports open into; the view bolts the turbo to that pipe's end.
- Designed 0.5 L road single (`DesignBench`, 1.56 target), `DynoSweepHarness`: lumped 46.1/49.0/51.1/50.4/48.4/42.9 N.m at 2,000-7,000 rpm, MAP 158 flat; on the face 52.2-59.4 N.m, MAP 158 -> 224 kPa at 7,000.
- `TurboDownstreamAuthorityHarness --spool` 5,000/7,000: boost 2.03/2.21 with the gate fully open (wg 1.000): the gate is too small, not the control. Gate x2 (336 mm2): 1.560 at wg 0.71/0.77, 54.5/44.0 N.m; x4: the same at 0.36/0.39.
- A designed twin at 1.5x holds 1.56 at wg 0.77/0.95; catalogue turbos at 6,000 rpm 0.69-0.95. So `sizedTurbocharger` gives 3.0x when one cylinder feeds a turbine (also on a count change). `EngineLab.TurboFit`: the single reads 1.561 at 7,000 rpm; 2.2 without (fails).
- Not measured: a real turbo single's gate size, a saved single's 1.5x gate (it now overboosts: enlarge it in the turbo inspector), the Big Twin with a fitted turbo, the app by hand.

## 2026-11-09 — a slide carburettor's throat is its slide

- Owner report: the designed V4-2S stalls at the 1/10/20 % throttle buttons, lean, clip 1. `PhysicsPerfHarness --saved-engine --freerev`: lambda 1.7 (1 %), 4-6.8 (10 %), 2.1-2.3 (20 %), stalled within 4 s; the designed 250 single too (5-6.8 at 10 %). The catalogue RD350 is injected: no catalogue engine had a two-stroke carburettor at part throttle.
- One factor each, at 10 %: the designer's 29.6 mm bore instead of the owner's 38 still stalls (not the bore); the jet's lift at 0 gives 5x the fuel, lambda 2.2, still stalls. Cause: the main circuit read the whole venturi's depression (46 Pa at 10 %, lift 36 Pa); the slide's gap, the real throat, was never used.
- Fix: the throat is min(venturi, the bore's effective open area); the needle's annulus follows the slide's open area over the venturi's, x(1 + 0.08 (3 - clip)). Full throttle is untouched (the venturi stays the throat at 0.72 > 0.64); a fixed venturi too.
- After: V4-2S free-revs at 1 % (2,550 rpm, lambda 0.48, its own rich pilot; it was rich at idle before too), 10/20/50 % to the limiter at lambda 0.65-0.74 (clip 1); the single 0.92-0.94. `EngineLab.TwoStroke`'s rig: AFR 13.8/13.3/13.1/13.1 at 10/20/40/60 % against 13.05 wide open.
- Not measured: a loaded part-throttle cruise, a real carburettor's mixture curve, the four-stroke fixed venturi's part throttle, the app by hand.

## 2026-11-08 — an alcohol's metering: injectors resized, the trim's bounds in lambda

- Injectors resized by the stoichiometric ratio (x2.27 on methanol): EJ25 lambda 0.86/0.86/0.84 at 2,000/4,000/6,000 rpm (petrol 0.87/0.86/0.84), RD350 0.89-0.93 (was 0.50-1.53); no more flat fuel flow. Jets take the same ratio times the root of the density ratio (no catalogue carburettor to measure it on).
- I5 still 0.72/0.71/0.64. `DynoCurveHarness`: its trim stayed at 1.00 (petrol learns 0.90-0.92). Molar mass at 100 g/mol changes nothing (0.71), so the fuel vapour's volume is not it.
- Cause: the learner only took observations at AFR 4-40 and clamped the target to 5-30, petrol numbers; AFR 4 is lambda 0.62 on methanol, so the rich cycles were dropped and the trim held on the lean ones. In lambda now (x stoichiometric / 14.7; exactly 1 on every catalogue fuel).
- After: I5 0.837/0.837/0.805, trim 0.93/0.91/0.89, torque 449/506/458 N.m, cycle CV 0.2 % (6 % before); LS3 0.90/0.90/0.89, flat-6 0.90/0.90/0.89. `EngineLab.LiveSettings` (methanol I5 at 2,000 rpm) reads 0.733 without, 0.837 with.
- Not measured: E85, idle and transients on alcohol, a carburetted engine, the app by hand.

## 2026-11-08 — fuels on the catalogue; a new octane is taken live

- `DynoSweepHarness --step 2000`, catalogue copied with `uses: fuel: methanol_m100` and the injection parts' latent heat at 1,103 kJ/kg: 12 of 17 spark engines hold lambda 0.89-0.90 at WOT, as on petrol (the ECU's lambda metering is right).
- Injectors saturate on methanol (2.3x the fuel mass): I5 at 6,000 rpm lambda 1.18 (fuel flow flat at 38.9 g/s from 4,000), EJ25 1.14 (31.1 g/s). Real, but nothing but the "Injector duty" readout says so.
- Rich at 2,000 rpm, not explained: I5 0.66 (petrol 0.84; under the 0.68 rich limit, misfires), LS3 0.745 (0.90), Flat-6 0.80 (0.90). LS3 is the latent heat (0.90 again at 350 kJ/kg); I5 and Flat-6 stay rich at 350. RD350's carburettor meters by jet: lambda 0.50-1.53, torque 4.5 N.m against 25.
- Knock-limit re-measure at 130 RON (`KnockLimitCalibration`): 31 s (2JZ), 43 s (I5); it ends. No path leaving the engine paused for good was found in the code; the app run could not reproduce (the Fuel window opened off-screen on this PC).
- Kept, on the owner's word: no re-measure. The octane is a live setting (the knock model reads it every step), keeps the fuel's name and touches no spark map or knock limit. `EngineLab.LiveSettings` fails without it.
- Not measured: E85 across the catalogue, idle and transients on alcohol, the app by hand.

## 2026-11-06 — the DSG fart: a dual clutch's injection cut

- Source (no recording found, Freesound included): NefMoto forum, "Launch control and DSG farts" (Bosch ME7 tuners). The gearbox asks for ~24 % of the torque during an upshift (misol); the ECU retards to its shift floor (KFZWMNGS, ~-12 deg), then suppresses injection (evz_austot) where that is not enough. Retard alone gives no fart. Whether 24 % is the torque kept or removed is not certain: read as kept (only then does a cut follow).
- Before: our dual clutch only retarded (20 deg, the -10 deg floor), no misfire. Added `dual_clutch_upshift_cylinder_cut` (default 0.76, released with the retard), an error-diffusion sequence in firing order, decided per cylinder at its injection start.
- `ShiftTransientHarness --filter I5 --style dual_clutch --trace`, 1->2 at 6,111 rpm: a cut cylinder gets 20-26 mg of port film for ~100 mg and misfires; ~3 firings in 4 drop over ~120 ms; the clutch's torque 790 -> 500-620 N.m; sync 4,331 rpm against 4,491. The shift's level is ~3 dB lower (50 ms RMS). The owner heard the A/B (`listening-test/2026-11-06/dsg/`) and said to keep going.
- `EngineLab.ShiftStyle`, 2JZ at 85 % of redline: 7 misfired cycles on 6 cylinders, push 343 ms against 407 with the retard alone; fails with the cut zeroed. Not measured: a direct-injection engine (no film), the app, the full ctest.

## 2026-11-05 — 0.8.0's CI: IdleStabilityRegression fails on Linux, the flat-6's early blip

- CI (Linux GCC 13, CI and Release jobs): "Aircooled-like 3.6 Flat-6: dips toward stall after a WOT blip 6 s after the start (588 rpm)", gate 608 (0.78 x 780). Reproduced in an Ubuntu 24.04 container; Windows reads 635 on the same start. Both Windows jobs passed.
- Not a Linux defect: `--early-scan Aircooled 12` on Windows reads 635 589 640 688-698, so GCC lands on the bad start that Windows reaches one step later (known since the resume change above).
- `--trace --early --extra-steps 7`: the dip comes 4 s after the lift-off, not at the resume. After it, port vapour runs the charge rich (phi 1.25-1.7) for ~3 s. The 2 s post-resume learning hold ends inside that, so the trim falls from 0.68 to 0.61. Then the idle valve opens as the speed sags (air 547 -> 673 mg), the fuel lags, phi drops to 0.90, misfire hits 16 % and the speed 666 rpm.
- Refuted: the hold at 3 s. The flat-6's 12 starts read 715-722, but the LS3 falls to 495-569 (gate 562), the Big Twin to 366-674 (593) and the 13B to 439-710 (624). The other engines are unchanged.
- Kept, on the owner's choice: the flat-6 is a named exception of the early-blip gate (`knownEarlyBlipDipAllow`), held to 0.70 x idle (546) instead of 0.78. Open: fuel lags air while the idle valve opens after the resume.

## 2026-11-05 — the cruise control hunted on most engines (owner report)

- `DriveScenarioHarness --builtin cruise` (set at 100 km/h during a 60 % pull) and a gentle set after lifting to 15 %, 7 engines. Old controller, throttle swing once settled (>15 s): K20A 0-20 %, LS3 0-22 %, Big Twin 1-27 %, and after a gentle set CP2 0-19 %, Hayabusa 3-18 %, LS3 0-22 %, RD350 0-18 % (+-0.9-1.5 km/h, period ~2.5 s).
- Cause: a fixed 0.5/s throttle correction whenever the speed was 0.3 km/h off and the raw frame-to-frame acceleration pointed away; the combustion-to-combustion speed ripple crosses that all the time. Without it the PI alone holds every engine (swing <= 0.12 %).
- Kept: that correction only from the set until the vehicle stops gaining (filtered acceleration, 0.3 s), ended by a pedal overtake; the integral holds while the speed returns faster than 0.1 m/s2. Kp 0.15 refuted: the Hayabusa hunts at small openings.
- Cost: a set during a hard pull now peaks 2.9-3.6 km/h over (K20A, LS3, Big Twin) before settling in ~10 s; `--automatic 1` (why the correction was added, 2026-10-15) K20A, LS3, CP2, Big Twin 1.4-3.6 km/h, swing <= 0.12 %. New ctest `CruiseControlHold` (K20A, swing < 2 %) fails on the old controller (20 %).
- The toy car of `CruiseControlTests` does not hunt with the old controller, even with an 80 Hz ripple, a 0.25 s torque lag and +-15 % cycle-to-cycle torque: only the real engine shows it. Not checked in the app by hand.
- Seen in passing, not investigated: the 2JZ never moves off in either drive scenario (top speed 1 km/h), before and after.

## 2026-11-05 — 0.8.0's sound against 0.7.8, each catalogue engine at one steady point

- `AudioRenderHarness --catalogue-filter <engine>` on 0.8.0 and on 0.7.8 (+10 commits, catalogue identical): its governed dyno at 72 % throttle, 4 s, default voicing.
- RMS within 1 dB on 13 of 18 (Big Twin -0.5, Aircooled -0.9, CP3 -0.9, 13B +0.6, K20A +0.7). LS3 +3.6 dB at the same 3,615 rpm (the measured head), EA288 +2.3 dB (the smoke limit's fuel), Audi I5 -2.1 dB at another point (the governor now holds 4,090 rpm where 0.7.8 ran away to 5,842), Merlin +0.4 dB but its strongest resonance moves 415 -> 3,379 Hz.
- K20A crest 2.64 -> 3.50, brightness +33 %; 2JZ low band 83 -> 66 %; EA288 and EJ25 strongest resonance moves below 400 Hz. No clipping, limiter or dropout on either.
- `AudioAbHarness` aborts (0xC0000409) on its first engine on both versions: not a 0.8.0 regression, not investigated.
- Not judged: by ear, or against a recording.

## 2026-11-05 — 0.8.0 closing: an earlier fuel resume, the ECU in lambda, two catalogue refits under the thermally perfect gas

- Idle: the post-blip dip is lean misfires at the fuel-cut resume on an empty port film. A resume led by the deceleration (rpm + 0.45 s of its rate, at most 1.55 x the idle) restores the WOT-blip gates. The early blip's minimum is chaotic in its start: `IdleStability --early-scan`, 12 starts 7 steps apart, Aircooled base 664-700, now 589-698 (1 of 12 under its 608 gate, the canonical start 635); Merlin base 639-702, now 637-702.
- ECU map in petrol AFR (lambda x 14.7), scaled by the fuel's stoichiometry: E85 on the K20A holds lambda 0.90, fuel x 1.49, torque within 2 %, EGT +10 C. Fuel presets (`parts/fuels.yaml`, Heywood D.4) carry octane and latent heat; an octane edit re-measures the knock limit.
- Big Twin flame ratio 0.42 -> 0.58: -8.6 / -25.5 % -> +6.9 / -5.7 %. EA288 smoke limit 47 -> 52 mg at 4,000 (44 at 4,500; 110 kW at 235 g/kWh is 54 mg): lambda 1.29 89 kW -> 96.6 kW (-12.2 %).
- Reference gate 24/24 (EJ25 power -14.9 %, marginal). 13B 153 kW at 8,500 is a named exception (-16.8 %; port areas and VDI refuted). Marine six gate at 0.85 of MAN's 24.9 bar (21.5 measured). Knock tests run the over-advanced 2JZ on 91 RON.
- Not measured: the sound of the refits, real time, the early-blip tail's cause.

## 2026-11-04 — The designed CBR's last 20 %: no single factor, all bounds stacked leave -12 % (nothing changed)

- Same CBR, `DynoSweepHarness --step 500` (reference mode ignores `--crank-degrees`, `--coupling-us`, `--exhaust-cell-mm`, `--settle`, `--advance-offset`: bit-identical). Base 126.3 kW at 14,500, pmep 1.51, exhaust stroke 1.22 bar.
- Resolution: the coupling sits at its 125 us cap (10.9 deg at 14,500); converged by 35 us: +2.5 % power, pumping -0.21 bar. Crank 1 deg: -2.4 %. Both: 127.1 kW (+0.6 %). 0.5 deg wrote no output. `--frame-hz 480`, 25 mm cells, a 6 s settle: within 1.4 %. Not an artefact.
- Combustion (`PhysicsPerfHarness --trace 14500`): CA50 21.1 deg ATDC, 10-90 % 34.6 deg. The designer's knock limit (27.7 deg) does not bind there (removed: +0.4 %). Map +6 / +12 deg: CA50 16.2 / 13.2, power +2.9 / +4.6 %.
- Cams: valves 32.4 / 27.5 mm against Honda's 32.5 / 28.5; no SC82 lift or timing found; the designer's L/D 0.30 / 0.33 equals the SC59's published 8.9 / 8.4 mm on 29 / 24 mm. Unsourced bounds: its own disabled high profile (12.5 / 11.8 mm, 282 / 276 deg) +6.4 %, exhaust +20 deg +2.0 %, intake +20 deg +1.3 % (torque -1.5 %).
- Stacked (high cams, +6 deg without the knock limit, crank 1 deg, coupling 25 us): 141.2 kW at 14,500 (-11.8 %), 107.8 N.m at 10,000 (-4.6 %), delivered VE 1.10 at 12,500, no knock.
- Measured reference: Cycle World, US-spec SP on a Dynojet 250i, 165.4 hp (123.4 kW) at the wheel at 12,000, 74.6 lb-ft at 10,580 (Honda claims 186 hp US, 214 hp EU). No measured EU curve found.

## 2026-11-04 — The exhaust valve's flow is not the designed CBR's missing power (nothing changed)

- Designed CBR1000RR-R (`EngineLab.DesignedReference` set, 39cc47e, `DynoSweepHarness --reference-file`): exhaust valve 27.5 mm derived, curtain Cd 0.62, 9.14 mm lift (L/D 0.33), so the 0.51 plateau caps its high lift.
- Plateau alone (`--exhaust-port-plateau`): 0.51 / 0.65 / 1.0 give 96.9 / 97.6 / 97.5 N.m at 12,500 (Honda 113) and 127.7 / 129.4 / 130.1 kW at 14,500 (Honda 160): -20.2 -> -18.7 % at twice the plateau.
- Bound, Cd 0.90 and plateau 1.5 (about three times a real port's area at full lift): 98.9 N.m, 132.0 kW, -17.5 %. The control SC59 moves alike (-12.3 -> -11.2 % at plateau 1.0).
- Sources agree with 0.51 for a four-valve head: the 2JZ's five benches read 0.50 (journal 2026-11-03); only the two-valve LS3 reads 0.65.
- The area-step boundary is set aside on local branch `exp/area-step`, with its measurements in that branch's journal.
- Not measured: where the 1.22 bar of exhaust-stroke pumping at 14,500 comes from, if not the valve.

## 2026-11-04 — The designed CBR's high-rpm breathing, one factor each; an area step between two ducts over-dissipates (nothing changed)

- Designed CBR1000RR-R, `DynoSweepHarness --step 500`, torque at 12,500 / 14,500 against the design: plenum 1.3 -> 5.2 L +2.1 / +1.8 %; airbox 3 -> 10 L bit-identical; runner 38 -> 44 mm -3.6 / -0.2; runner 131 -> 170 / 95 mm +0.3 / -4.2, -3.4 / +1.1; primaries 345 -> 250 / 450 / 600 mm +0.3 / +0.2, +1.3 / +2.7, +1.5 / +2.3; primaries 40 mm -0.3 / -0.2; Honda's 32.5 / 28.5 mm valves (designer 32.4 / 27.5) +0.8 / +0.1; exhaust plateau 0.65 / 1.0 +0.6 / +1.2, +0.6 / +0.7 (the valve is worth ~0.2 bar of pumping). Merge diameters are not read (bit-identical).
- At 14,500 the intake stroke costs 0.29 bar, the exhaust stroke 1.22: the cylinder sits at 2-3 bar through the stroke over a primary at 1.0-1.5 bar (152 kPa at 260 deg). No hardware factor moves it by more than 0.2 bar. The 20 % gap is not in the designer's choices, and no measured superbike airflow or pumping exists to judge the model's level.
- Anomaly: enlarging the collector, tailpipe and outlet x2 costs 13 % (primary cycle mean 96 -> 133 kPa). Steady-flow bench on `ExhaustGasNetwork` (scratch test, a held reservoir through 1 m of 50 mm then 1 m of 35/50/70 mm, 20 mm cells): a 50 -> 70 mm expansion at 117 m/s loses 8.5 kPa of stagnation pressure, the whole upstream head, where Borda-Carnot gives 2.0; a 50 -> 35 mm contraction loses K = 1.46 of the downstream head where a sudden contraction is 0.25-0.30; a uniform pipe 0.24 kPa. A duct-to-duct interface takes a constant-area Riemann flux on the smaller face.
- The throttle's stagnation-fed orifice on those faces (prototype, not kept): the contraction becomes lossless, the expansion inconsistent (more than the upstream head at 106 kPa); the x2 collector -13 -> -1.7 %, the designed CBR +0.1 %. A 2-into-1 merge with axial momentum (the engine's setting) is fine: K = 0.14-0.16 of the trunk head (a Y-piece 0.1-0.4). As a plenum at rest it meters by rho c u (11-15 kPa at 22-34 m/s); the engine does not use that mode.
- Open: a sourced area-step boundary (Benson / Winterbone-Pearson: isentropic contraction, Borda-Carnot expansion) for every engine and the default sound. Not the Fireblade's gap.

## 2026-11-04 — Friction: the rpm^2 and above-4,000 terms removed; designed engines 6.9 -> 3.4 %, control 2/6 -> 0/6 out

- One factor: the lumped polynomial's 3.5e-8 rpm^2 and 1.5e-4 (rpm - 4,000)+ terms (the latter added 2026-08-27 for "underestimated high-rpm losses", under constant gamma). Without them the simulator's fmep follows Sandoval's Patton-Nitschke-Heywood within 0.1-0.3 bar (K20A 7,000/8,000: 1.91/2.14 vs 1.87/2.08; CBR 12,500/14,500: 2.28/2.62 vs 2.39/2.67); with them it ran 0.27-1.12 bar over. At 4,000-6,000 the two already agreed (K20A 1.29 vs 1.30, CBR 1.47 vs 1.54), untuned.
- Designed set: tuning median |error| 6.9 -> 3.4 %, 4/16 -> 2/16 out (CBR1000RR-R -20.2 power, -14.3 torque, was -29.5 / -20.2); control 11.5 -> 10.3 %, 2/6 -> 0/6 out. Cycle World shape RMS CP2 7.1 -> 6.3, CP3 7.7 -> 6.4 (peak 7,000 as measured), CP4 12.6 -> 11.7, M8 7.1 -> 6.8 %. LS3 / LS7 torque +10.8 / +11.7 (were +9.9 / +10.6).
- Catalogue: 3 -> 2 points out (Big Twin -25.5, EA288 -19.0; EJ25 -14.9 back in); motorcycles -4.4 to +2.3 %; Aircooled +8.2 power. 13B 145.6 -> 153.1 kW (gate 156.4). Owner's Fireblade 124 -> 133 kW at 13,000, torque peak 110.9 N.m at 10,000. BSFC 1-4 g/kWh lower. Diesels and two-strokes unchanged.
- Guards: four-stroke idles on target, 100 % fired; RD350 as before. ctest 91/97: `IdleStabilityRegression` now fails, Merlin and Aircooled dipping to 589 / 592 rpm after a WOT blip (gate 624 / 608) on a 0.045 bar change at the Merlin's 3,200 rpm limit: the idle catch's sensitivity, not investigated. `ShiftStyle` passes again. Not measured: the sound, real time.
- `EngineDesign`'s single read -0.08 N.m at 9,616 rpm: the state's torque once a 240 Hz frame samples an 80 Hz single at fixed phases (7.7 bar before by luck). The absorber's mean gives 10.1 bar, as `DynoSweepHarness` (1.97 N.m at 10,000).

## 2026-11-04 — The designed sport engines' gap at their power points, term by term (nothing changed)

- Branch state (x2 knock), `DynoSweepHarness --step 500` on the designed set; bmep = delivered VE x (gross imep / delivered VE) - pmep - fmep at each maker's point (interpolated). The warm-started sweep carries history: the CBR's 14,500 rpm point moves 1.2 % with a knock-limit change at 1,950 rpm.
- Combustion is not it: gross imep / delivered VE 14.0-14.7 bar and gross indicated efficiency on the fuel 0.365-0.385 (lambda 0.88-0.90) on every engine, hits and misses alike.
- Power points that miss (CBR1000RR-R -29.5 %, Panigale -19, SC59 -19, CP3 -16) deliver 0.98-1.06 where those that hit (CP4 -5, Hayabusa -5) deliver 1.09; pmep 1.3-1.5 bar (exhaust stroke 1.0-1.2 of it) against 1.0-1.1. A 25 mm exhaust mesh moves them -1 to -3 %.
- CBR at 14,500, one factor each: no muffler +0.4 %, collector and outlet x1.3 +4.4 %, exhaust plateau 0.65 +3.9 %.
- Friction at equal piston speed: CBR 14,500 (23.4 m/s) 3.74 bar, K20A 8,000 (22.9) 2.50. Sandoval 2.67 / 2.08, Blair 3.46 / 3.40. The two sources disagree on the level but both charge the CBR 0.06-0.59 bar more than the K20A where the simulator charges 1.24: its rpm polynomial grows with rpm, not piston speed. Following either source's CBR/K20A step: +0.65-1.18 bar, +7-13 % CBR power.
- Left after that: 1.7-2.9 bar on the CBR, a delivered VE of 1.14-1.22 at 14,500 if pumping were right. No measured superbike airflow was found (web searches: none), so that term cannot be judged.

## 2026-11-03 — Knock under the thermally perfect gas: no Douaud-Eyzat prefactor fits both NA and boosted engines

- `KnockControl` and `LiveTuning` fail on the branch: the 2JZ map +8 deg peaks at knock 0.029 and 0 (need > 0.1). The 2026-10-23 doubling (35.4 ms) was set under constant gamma by "a production map sits 0-3 deg from its limit"; redone here the same way (`DynoSweepHarness --step 500`, retard = map at RON 130 minus commanded, at the map and `--advance-offset 5`/`10`).
- x1 (17.68): retard behind the map K20 7.8 deg, LS3 4.3, 2JZ 11.4, EJ25 12 (stop), I5 6.1 -- as under the old gas. x1.25: NA 2 deg, 2JZ 8, EJ25 12. x1.5: K20 0 / 2.9 at +5, LS3 1.0 / 1.5, I5 1.0; 2JZ 7.4 below 3,000, EJ25 9.9. x2: K20 and LS3 clean even 10 deg over their maps (under the old gas +5 knocked); 2JZ 7.3 below 3,000, EJ25 4.2.
- x1.5 meets the criterion on the NA engines and passes both tests (on: peak 0.12, mean 0.096; off: 0.41), but the makers' points move 2JZ torque -12.3 -> -16.1 %, EJ25 power -15.5 -> -19.5 % (designed set unchanged: its knock limit is measured at build). Not kept: it trades one error for another. x2 kept; the two tests stay failing until the owner decides.
- The NA/boosted split is Douaud-Eyzat over-predicting knock as intake pressure rises (Energy & Fuels, doi 10.1021/acs.energyfuels.4c04775, a snippet). A pressure exponent without a source stays refuted.

## 2026-11-03 — The LS3 and the 2JZ on measured heads; the gates left on the branch

- Real heads replace authored curves (Cd 0.36-0.42 at 3 mm where benches read 0.70-0.81). LS3: GM's cam card (254/260 deg, 14.0/13.3 mm), its head's benches (Lingenfelter, EngineLabs, Edelbrock), exhaust plateau 0.65 (new `exhaust_port_head_area_fraction` on a camshaft; 0 keeps 0.51). 2JZ: Toyota's 233 deg 8.25 mm cams, 33.5/29.0 mm valves, the median of five benches (Supramania thread), plateaus 0.56/0.50 as the defaults.
- Makers' points: LS3 -5.7/-24.2 -> -0.0/+0.2 %; 2JZ -14.8/-10.4 -> -12.3/-11.9 %. Every other engine and the designed set unchanged (points and sweep maxima to 0.1 %). `CatalogReference` 3 of 24 out: EJ25 power -15.5 (no head data found), Big Twin -26.5 (0.42 anchor; without it delivered VE 0.99 at 2,500 where H-D implies ~0.86: cam and intake authored, no M8 bench found), EA288 -19.4 (lambda 1.27, 47 mg/stroke at 4,000 where 110 kW at ~245 g/kWh needs ~56: boost and fuel limit authored).
- `EngineDesign`'s 25 cc single was a transient in the window (opened at 2 s, at 9,600 rpm only at 6.2 s; the last 2 s of 8 read 9,255-9,637): 12 s, 9,598-9,638 rpm, 7.67 bar. The test then reaches the marine six: 21.5 bar rated (gate 22-30; 24.0 under constant gamma), BSFC 197 g/kWh at lambda 1.19 against ~180 for a real one: the diesel reads 3-8 % inefficient under the gas, open.
- Rotary: 145.6 kW at 8,500 (Mazda 184, gate 156.4); the gas alone, tumble does not apply. Not investigated.
- `ShiftStyle` fails with the 2JZ's head (alone too): a dual-clutch upshift's 20 deg retard shortens the push 435.5 -> 426.8 ms, at the test's 2 % edge. ctest 91/97: that, CatalogReference, Rotary, KnockControl, LiveTuning, EngineDesign (marine six).

## 2026-11-03 — High-speed friction: the two sources bracket the simulator; not changed

- Sources: Sandoval's revision of Patton-Nitschke-Heywood (MIT thesis 2002, App. A-2, = SAE 2003-01-0725; motored 5.4 L V8 and 3.0 L V6, 90 C) and Blair (1999, p. 536, 1.0 bar + 0.105 bar per m/s).
- Sandoval's terms on a CBR1000RR-R (81 x 48.5, 5 mains 33 x 18 mm, rods 34 x 17, DOHC flat followers, the paper's DOHC constants estimated): 1.92 bar at 9,000 rpm, 2.39 at 12,500, 2.53 at 13,500 (piston 0.79, valvetrain 0.57, crank 0.47, auxiliaries 0.44). Blair: 2.53, 3.12, 3.29. The simulator on the owner's design (imep - bmep): 2.18, 3.13, 3.43. K20A at 7,000: Sandoval 1.87, Blair 3.1, simulator 2.2.
- The two disagree by 0.8-1.2 bar at 20 m/s and the simulator sits within 4 % of Blair at the power point: no source asks for less. Friction is not the Fireblade's missing power; its pumping (pmep 1.2-1.4 bar at 12,500-13,500) and air are what is left.

## 2026-11-03 — A tumbling head's turbulence in rpm x bore: designed engines 11 -> 7 %, control 19 -> 12 %

- Branch `physics/designed-engines` (not merged): the thermally perfect gas (b55ce40), then the flame's turbulence x bore/stroke on a multi-valve four-stroke spark engine (a tumble turns at a ratio of the crank speed across the bore; a two-valve head keeps u' in piston speed). Each measured alone on the whole set (`EngineLab.DesignedReference`, catalogue points, `--step 500` sweeps).
- Gas alone: every engine -12 to -17 % (RD350 -19, EA288 -8/-12); BSFC minimum K20 206 -> 236, LS3 221 -> 255 g/kWh, EGT +40-80 C; designed tuning median 11.1 -> 10.4 %, control 19.2 -> 23.8 %; catalogue 0 -> 6 points out of 15 % (power points).
- Exhaust plateau 0.51 -> 0.65 on top (`--exhaust-port-plateau`, now also in reference mode): four-valve engines 0 to +2 %, the two-valve LS3 +8 % power. One bench (an LS3/L92 head) is the only source: not kept.
- Tumble on the gas: CA50 41 -> 18 deg ATDC on the designed CBR1000RR-R, 46 -> 15 on the Panigale, all designed engines 6-21; gross IMEP / delivered VE 14.0-14.7 bar on every one (was 11-14.5). Designed tuning median 6.9 %, 4/16 out; control 11.5 %, 2/6 out. CP4 torque peak 7,000 -> 9,000 rpm (Cycle World 9,250). Square and two-valve engines unchanged by construction.
- Anchors, each removed alone: CP2 0.80 -> none -3/-8 %, CP3 0.80 -> 0/-5, CP4 1.25 -> -5/-5: removed (and the two CP2 variants'). EJ25 and I5 1.50 -> -16/-22, -18/-23: kept. Big Twin 0.42 -> +21/+11 (kept, -9/-27). Aircooled: its 964 has two valves (the catalogue gives four); with two, 0.55 -> -11/-24, none -> +20/+11: kept as authored. Their common pattern: low-speed torque high, high-speed power low.
- Branch catalogue: 4 of 24 points out (LS3 power -24, EJ25 -16, Big Twin -27, EA288 -19: the diesel has no spark flame, so it is the gas): `EngineLab.CatalogReference` fails, the branch is not mergeable as it is. Owner's Fireblade: 114 -> 124 kW, torque peak 7,500 -> 9,000.
- Friction (step 4) not touched: the Sandoval-Heywood thesis was unreachable (HTTP 429), no other readable source gives a high-speed fmep. At ~20 m/s the rpm polynomial charges the Fireblade 3.0-3.8 bar, the K20A 2.1.
- Guards: four-stroke idles on target, 100 % fired; RD350 1,533 rpm sd 216, 18.6 % fired (was 1,471, 138, 24.2 %). Real time -5 to -9 % capacity, lowest I5 1.45, EJ25 1.63, 13B 1.64. Sound `shape` 0.4-3.4 dB (K20A worst), level within 1 dB: a default-sound change for the owner's ear. ctest 92/97: CatalogReference, Rotary (184 kW at 8,500), KnockControl and LiveTuning (the 2JZ no longer reaches its knock limit) and EngineDesign's 25 cc single, which swings 9,255-9,637 on the test's soft absorber while `DynoSweepHarness` holds it (sd 1.9 rpm, -13 % torque like the others).

## 2026-11-03 — Engines designed from their data sheets: the error follows bore/stroke (r = -0.89)

- New gate `EngineLab.DesignedReference` (report only): 11 engines the designer builds from a data sheet alone (`designed-engines.spec`: bore, stroke, CR, layout, use, rated-power speed / 0.9 as redline; knock limit measured as the window does), against 22 makers' points; 8 tuning, 3 control (LS7, Panigale 1299, SC59) never used to decide. Sources: `designed-manufacturer-sources.md`.
- Baseline (main physics): tuning median |error| 11.1 %, signed +8.4 %, stdev 18.6 %, 6/16 outside 15 %; control 19.2 %, 3/6 outside. Fireblade -28 / -38 % (81.8 N.m at 12,500, 99.4 kW at 14,500), Panigale -24 / -34 %; LS3 +28 / +27 %, LS7 +30 / +11 %, M8 +36 / +15 %, K20A +13 / +9 %. Every hold PASS.
- Error against bore/stroke (0.91-1.91): correlation -0.89. CA50 6-14 deg ATDC on square and long-stroke engines, 25-29 on the SC59, 32-35 CP4, 41-42 Fireblade, 45-47 Panigale (10-90 % 53-61 deg).
- Gross IMEP / delivered VE 15.6-16.5 bar wherever CA50 is under 20 deg (the constant gamma's over-efficiency: the 2-valve V8s, the M8, the K20A land 13-36 % high), 12.6-13.4 on the two slowest burners.
- fmep at ~20 m/s piston speed: K20A 2.06, CP2 2.49, Hayabusa 2.59, Fireblade 3.05 bar (the rpm polynomial charges a short stroke for its rpm). Cycle World shape RMS (each curve over its own peak): CP2 6.2, CP3 7.1, CP4 13.0 (peak 7,000 vs 9,250), M8 5.7 %.
- Not covered: crank offsets, VTEC, 4-2-1 exhausts (the designer has none). Nothing in the physics changed.

## 2026-11-02 — A designed Fireblade: the flame burns in bore/stroke, the losses peak the torque at 9,000

- Owner's designed CBR1000RR-R (81 x 48.5, CR 12.1, saved JSON; `DynoSweepHarness --saved-engine`): 103.8 N.m at 7,500, 114 kW at 12,500 (Honda: 113 N.m at 12,500, 160 kW at 14,500; inlet/exhaust valves 32.5/28.5, CR 13.0, 52 mm bodies, 4-2-1). Delivered VE 1.15 at 11,500: not short of air.
- Trace: CA50 34 deg ATDC at 7,500, 42 at 13,500 (spark 28 BTDC, the build's knock limit). The flame front's speed follows the mean piston speed and crosses half the bore, so burn angle goes as bore/stroke: 1.67 here. The CP4's 1.25 turbulence (its comment: 60 deg burns) is this, patched per engine; a designed four-stroke gets 1.0.
- One factor: turbulence 1.67 (= bore/stroke): 126 N.m at 9,000, 148 kW at 13,000, gross IMEP/VE flat at 16.1-16.5 bar. Then CR 13 +2.6 % power, lift 11/10 mm +2.6 %, advance +5 deg +2 %, exhaust plateau 0.65 +0.6 %; runner 100-220 mm, primaries 600 mm, 52 mm bodies, durations +18 deg: the torque peak never leaves 9,000-9,500.
- Between 9,000 and 14,500: fmep 2.19 -> 3.74 bar (the bearing polynomial is in rpm, with an rpm^2 term fitted on car engines under ~8,000), pmep 0.42 -> 1.46 (exhaust stroke 1.17), VE 1.12 -> 1.07. Honda's 14,500 / 12,500 torque ratio is 0.93; the model's 0.85.
- Catalogue makers' points with turbulence x bore/stroke (`exp/flame-bore-scale`, `EXP_FLAME_BS=1`): square engines unchanged; Hayabusa +6/+8 %, CP4 +9/+12 %, CP3 +7/+11 %, CP2 +4/+6 %, Aircooled out (+25/+27 %: its 0.55 anchor). The constant-gamma over-efficiency (gross IMEP/VE 16+) still hides what each anchor fixed. Nothing merged.

## 2026-11-02 — With the LS3's measured head and cam, the thermally perfect gas meets GM within 1 %

- References: GM 321 kW at 5,900, 575 N.m at 4,600; GM cam (Summit/LSXMag) 14.0/13.3 mm, 254/260 deg at 0.006", 117/117 deg; L92/LS3 rectangle-port flow bench (Lingenfelter, EngineLabs, Edelbrock; may be an L92 head) converted at 28" H2O (mm2 = cfm x 4.378); forum WOT MAF logs 280-338 g/s near 6,000 (anecdotal, snippets only).
- Catalogue LS3 (one factor each, main gas): GM lift +7.3 % torque at 6,000; GM centrelines -4 to -6 %; exhaust plateau 0.51 -> 0.65 (the bench's) +0.3 % at 2,000, +11.7 % at 6,000, exhaust-stroke mep 1.38 -> 0.99 bar: the shape of the common high-rpm deficit.
- Bench Cd curves + GM cam + plateau 0.65 (`DynoSweepHarness --exhaust-port-plateau`), main gas / gas branch: 4,500 rpm 662 / 569 N.m, 5,500 373 / 317 kW, 6,000 381 / 320 kW; BSFC on the branch 262-294 g/kWh, airflow 349 g/s at 5,900. Branch: -1 % torque, -0.3 % power, ratio 5,900/4,600 0.91 (GM 0.90). Main gas: +15-18 %.
- Read: the constant gamma's over-efficiency was hidden by the catalogue's under-flowing exhaust port (0.51) and low-lift Cd, not by airflow. Only the LS3 has bench data; nothing changed on main (any change moves every engine's power and sound).

## 2026-11-02 — The small engine's idle is the mesh within 0.3 m of the outlet; the cure moves the sound

- One factor (branch `exp/outlet-mesh`): only the ducts within a reach of each outlet are refined, never below the network's own CFL length (the time step is unchanged by construction). The 44 mm tailpipe stub alone: no effect. Reach 0.3 m: idle sport 125 2,074 -> 1,325 (target 1,300), sport 250 1,808 -> 1,322, sport 600 1,420 -> 1,292, road 125 1,369 -> 1,347, Hayabusa 1,314 -> 1,260, CP4 1,379 -> 1,323, CP3 1,334 -> 1,306; K20, LS3, CP2, Merlin, 13B, 2JZ, Big Twin within 1 %. A floor of 50 mm leaves the sport 125 at 1,508, 100 mm at 1,406: it is the cell size at the outlet end.
- WOT, whole catalogue `--step 500`: the same as a 150 mm mesh everywhere (CP4 torque +3.5 -> -0.3 %, CP3 power -4.8 -> -8.3 %), BSFC within 1 g/kWh, one point outside 15 % before and after. Off (`EXP_REACH_M=0`) is byte-identical to main.
- Real time (alternated, 4 kept, minimum): Hayabusa 1.071 -> 1.023, CP4 1.107 -> 1.027, 13B 1.112 -> 1.097, 2JZ 1.212 -> 1.203, Big Twin 2.30 -> 1.66 (cells 14 -> 26).
- Sound (`GeometrySensitivityHarness --output-stage-ab --wav-out`, then `--wav-reference`; a repeat render is 0.00 dB): shape Hayabusa 3.8 dB at 3,000 (-11 dB at 800 Hz), 0.9 at 8,000; CP4 3.6 at 3,000; Aircooled 2.6; K20 0.6 / 1.9 at 3,000 / 7,000; 2JZ 1.9; Big Twin 1.4; CP2, 13B 0.9; LS3 0.3. A default-sound change: not merged.
- An outlet plume (composition only) was not built: the inert outlet left the sport 125 at 1,791, and it would mask a numerical diffusion with two unsourced constants. `EngineLabAudioAbHarness` aborts (0xC0000409) at its first engine on main.
- 13B's VDI: at 8,500 rpm a switched runner is one fixed length, and 200-800 mm never passed 193 N.m (journal 2026-11-01): at most +1.6 % of the 9 % gap. Not built.

## 2026-11-01 — The idle's exhaust air is the outlet's oxygen; a finer mesh costs real time

- Diagnostic (built, run, reverted): the exhaust outlet's ambient set inert, production mesh, `PhysicsPerfHarness --trace 1 --idle --settle 8`. Idle (inert / 50 mm): Hayabusa 1,223 / 1,256, CP4 1,296 / 1,304, CP3 1,307 / 1,309, Aircooled 760 / 741, Merlin 787 / 795. The outlet's oxygen is the whole catalogue mesh effect. The sport 125 keeps a second coarse-mesh effect (inert 1,791, 50 mm 1,318).
- Idle at 150 / 100 mm is converged within 1-2 % (sport 125 1,373 / 1,359, Hayabusa 1,261, CP4 1,326 / 1,324). The Aircooled at 50 mm (741, for 780) suggests its bypass was set on the artefact.
- Four-strokes at 150 mm, whole catalogue `DynoSweepHarness --step 500`: makers' points move 1-4 % (CP4 torque +3.5 -> 0.0 %, CP3 power -4.8 -> -8.7 %), the count outside 15 % stays 1, BSFC unchanged.
- Real time (`RealtimeBudgetHarness --free-run --with-audio --relative-rpm 0.95`, alternated, 4 kept rounds, minimum), production -> 150 mm: LS3 1.287 -> 1.039, 13B 1.116 -> 0.996, Hayabusa 1.141 -> 0.967, CP4 1.122 -> 0.983, K20 1.231 -> 1.037, 2JZ 1.127 -> 0.981, Radial 2.48 -> 2.10, Merlin 1.53 -> 1.72. A global finer mesh is refused (real time). Still open: an outlet that holds its own plume, or a finer cell on the tailpipe end only. Sound not measured.
- B4, CP2 at 8,750 rpm (trace, exhaust stroke): cylinder 2.485 bar mean against 1.747 at the runner's port end (6,500: 1.843 / 1.48). The excess pumping is about half valve and half runner wave. The Full System's 42 mm primaries still pump 0.82 bar (torque ratio 0.85 against 0.837). Derived valves 32 / 27.2 mm against Web Cam's standard 31.5 / 26.5 (a vendor, not Yamaha). No stock lift or timing found. Not changed.

## 2026-11-01 — A small engine's high idle is the exhaust mesh; the high-rpm deficit is not numerical

- The sport 125's extra air comes in through its exhaust. `PhysicsPerfHarness --trace 1 --idle --settle 8`: delivered through the intake 3.9 mg a cycle (2,074 rpm x 3.9 mg = the 0.33 mm2 closed-throttle leak's ~0.057 g/s), trapped 21.3. Oxygen from the outlet reaches the valve through the production 360 mm cells (its 347 mm primary is one cell). `--exhaust-cell-mm`: 200 -> 1,802 rpm, 50 -> 1,328 (16.7 mg delivered), 25 -> 1,325, for 1,300. Road 125 1,369 -> 1,343.
- Catalogue at 50 mm: CP2 1,407/1,406, K20 953/954, LS3 718/718 (converged); Hayabusa 1,314 -> 1,256 (idle 1,250; delivered 21.5 -> 35.0 mg). Small cylinders with sport overlap. Not fixed: the cure is the production mesh, which moves every engine's sound and real-time budget.
- High-rpm deficit, resolution (`DynoSweepHarness`): CP2 25 mm cells within 1-3 %, `--crank-degrees 1.0` -1.5 to -2.5 % at every speed, `--coupling-us 40` within 0.8 %; 13B the same within 1 %. The shape does not move: it is the model's physics.
- `DynoSweepHarness --crank-degrees` below ~1.6 deg aborted (0xC0000409) on any engine revving past ~9,000 rpm: the finer step asked more than the solver's 60 kHz ceiling and the refused config threw. The ceiling now follows the step (capped at validation's 100 kHz); without the flag the sweep is byte-identical.
- With the gas (`exp/tpg-rebased`), delivered VE at makers' torque points is a real engine's: K20 1.00, CP2 0.99, LS3 0.97, Hayabusa 1.06, CP4 1.10; at power points it falls (LS3 0.81) while BSFC rises 9-22 % at equal lambda. Still no public WOT airflow, pmep or motored friction to split it (searched: LS3/K20Z3 MAF logs, Patton-Heywood pumping terms, motorcycle motored fmep).

## 2026-11-01 — The 13B's ports are Mazda's published ones; they are not its -8 %

- Mazda Technical Review 21 (2003) "New Rotary Engine RENESIS Mounted on RX-8", Table 1, columns 13B-REW / high power / standard: intake areas 10.11 / 7.81 / 6.64 cm2 (primary / secondary / auxiliary, high power); timings primary 3 ATDC-65 ABDC, secondary 45-36, auxiliary 38-50 (the service manual's 80 ABDC for the auxiliary disagrees); S-DAIS: SSV 3,750, VFAD 5,500, APV 6,000, VDI 7,250 rpm (Fig. 14).
- One factor, the three ports as summed trapezoids at the catalogue's Cd 0.75, primary + secondary below 6,000 and all three above (switched profile): 8,500 rpm 190.2 -> 190.9 N.m (+0.4 %), 5,500 233.0 -> 235.4, 2,000 +2.9 %. Auxiliary closing at 80: 194.5 at 8,500 (+2.3 %). Not kept: the gap is not port area.
- Single factors at 8,500 / 5,500 (Mazda 207 / 216 N.m, ratio 0.957; catalogue 0.816): runner 50 -> 60 mm 204 / 242 (0.844), exhaust "valves" 30 -> 36 mm +2.6 %, runner length 200-800 mm none above 193 at 8,500, muffler restriction and `friction_coefficient` < 0.5 %. The runner, exhaust port and exhaust are estimated; Mazda's VDI (a shorter effective runner above 7,250) is not modelled. Not changed.

## 2026-11-01 — The flame-speed ratios under 1 are torque anchors; the high-rpm deficit is every engine's

- WOT burn phasing (`PhysicsPerfHarness --trace`, CA50 from the burned fraction): K20 7-12 deg ATDC, LS3 15, Radial 5; CP2 20-26, CP3 25-33, CP4 22-27, Hayabusa 20-23, Big Twin 35-42, Aircooled 43-48 (CA10-90 43-58 deg). A non-knocking NA engine runs CA50 ~8-10 (Heywood). The Big Twin's 0.42, the Aircooled's 0.55 and the CP2/CP3 0.80 were fitted to makers' torque (their comments, commits 97b49a3, 2465157, d8e0ec9).
- One factor, those ratios at 1.0, `DynoSweepHarness --step 250`, current gas: Big Twin CA50 7.4, torque +13.6 -> +38.8 %, Aircooled +11 -> +45 %, CP2 +4 -> +10 %, CP3 +4 -> +11 %; BSFC down 10-55 g/kWh. Shape against Cycle World improves (CP2 7.5 -> 6.2 %, CP3 6.8 -> 5.1, Big Twin 7.1 -> 4.5 % RMS).
- `exp/thermally-perfect-gas` rebased on 0.7.8 (local `exp/tpg-rebased`), whole catalogue at `--step 500`, makers' points outside 15 %: main 1, gas 7, gas + ratios 1.0 still 7. K20 BSFC 206 -> 236, LS3 221 -> 255. With the gas, engines already at MBT (K20, LS3, Hayabusa, CP4) lose 7-15 % torque and 12-25 % power; the Big Twin and Aircooled with ratio 1.0 end +21 to +30 %. Each anchor hid a different, engine's own error.
- CP2 8,750 / 6,500 rpm torque 0.810 (Cycle World 0.876): spark +12 deg 0.796 at 9,000 / 6,000 (0.770 at 0), ratio 1.0 0.836, gas 0.781. Not the burn. Breakdown 6,500 -> 8,750: gross IMEP per VE -4.5 %, VE -3 %, pmep 0.62 -> 1.25 bar (exhaust stroke 0.48 -> 0.98), fmep 1.88 -> 2.55 (Blair 2.56 -> 3.10). At makers' power points every NA engine pumps 0.9-1.6 bar, 0.6-1.4 of it on the exhaust stroke against 12-42 kPa of mean back-pressure; LS3 VE 0.83 at 6,000.
- Nothing changed. What would decide it: a measured WOT pmep, exhaust-port pressure or airflow on any catalogue engine. Valve areas are Heywood's (exhaust plateau 0.50-0.55 of head area); not shown wrong.

## 2026-11-01 — Small sport idle and the 13B's port areas: leads, not fixes

- Designed (DesignBench, `--idle-firing 20 --settle 8`): sport 125 single 2,016 rpm for 1,300, sport 250 twin 1,752, sport 600 four 1,411, road 125 1,353 for 1,350. At 2,016 the governor's bypass is shut (error -55 %), manifold 31 kPa (road: 21 at 1,353); the sport cams' overlap pumps less. Trace: oxygen trapped at the spark 21.4 mg against 4.7 mg delivered through the intake that cycle (road 19.6 against 12.3); whether that is overlap backflow bookkeeping or a real oxygen source is not settled.
- 13B ports: Mazda Technical Review 2003 (no. 2) and a secondary table give intake areas, primary / secondary / auxiliary, 10.11 / 7.81 / 6.64 cm2 (high power), 9.29 / 8.99 (standard), 13B-REW 6.09 / 9.29; the column mapping is unread in the original PDF. Not applied.

## 2026-11-01 — A designed diesel's fuel limit follows its peak power, not its redline

- The designer stretched the common-rail part's full-load limit (the EA288's, 54 mg at 2,500-3,000 rpm, 30 at 5,000, rated at 4,000) by redline / 5,000. A marine six given its 750 rpm as a redline was fuelled as a car near its limit: 4.6 g a stroke at 450-525 rpm, 2.6 at 750; `DynoSweepHarness --settle 10` 38.7 kN.m at 600, 35.0 at 650. A MAN 32/40 (same bore and stroke) is rated ~500 kW a cylinder at 720-750 rpm, ~4 g a stroke at ~180 g/kWh.
- Its redline is also its limiter (fuel cut from ~0.91 x): a real one is rated below its governor's limit. With redline 825, peak power 750 (both designer fields), held at 750: 20.0 bar BMEP before, 24.0 bar / 36.9 kN.m (2.92 MW, 487 kW a cylinder) with the limit's speeds x peak power / 4,000.
- The default peak power (0.8 x redline) keeps redline / 5,000 to the bit: `DesignBench`, seven designs (three diesels) byte-identical. `EngineLab.EngineDesign` holds the rated six at 750 rpm above 22 bar (fails before: 19.98).
- Not measured: the EGT and smoke at the rated point; a real medium-speed engine's fuel against speed (only its rated point).

## 2026-10-31 — Owner reports: launch control in first, a rotary's exhaust designer

- Launch control still did not arm in 0.7.7: the ECU required `gear >= 1`, but the driveline counts first as 0 (-1 neutral, the dashboard shows gear + 1). Both tests had the same off-by-one (`LaunchControlTests` called 0 neutral; `ActiveLimits` passed 1 as first). With first as 0 both fail before the fix (CP2, launch 4,000 rpm: peak 10,422 rpm, no launch bit) and pass after (4,172 rpm, bit set).
- Clicking *Exhaust* on a rotary aborted the app (0xC0000409): the canvas skips a rotor's port passage when placing nodes, then `nodeBounds_.at()` on it threw out of `paint()`. `EngineLab.AudioWorkshop` (the GUI test) now also builds and paints the exhaust designer on the 13B: aborts before, passes after.
- Not checked in the running application: both by tests only.

## 2026-10-31 — Test and release time

- Full ctest, VS tree, c178077: serial 95/95 in 3,171 s (53 min; 32 min for 91 tests on 2026-10-23, 43-44 min since). `IdleStabilityRegression` 628 s, then `LiveCylinderResize`, `IntakeTuning`, `LiveTuning` ~185-195 s each. One engine was added since 10-23 (the 13B); the rest of the growth is not measured.
- Same tree at `-j 4`, nothing else running: 95/95 in 17 min 54 s (one run). `IdleStabilityRegression` 838 s under that load sets the floor; the three wall-clock dyno tests stay `RUN_SERIAL` and passed, `CoreTests` too. `.claude/CLAUDE.md` now gives `-j 4`. Not shown: that no load-induced failure ever appears (one run).
- CI on c178077: Windows build 1,291 s + test 1,351 s, Linux build 404 s + test 1,909 s (`--parallel 2`). The v0.7.7 release then rebuilt and retested the same commit for another hour. `release.yml` now skips its tests when a CI run passed on that SHA (the API query returns 1 for c178077, 0 for the failed 6b80ce0); it has not run on a tag yet.
- Not done: splitting `IdleStabilityRegression` (the floor at more jobs) and Ninja for the Windows CI build (MSBuild compiles the JUCE project's units in series).

## 2026-10-30 — A designed rotary: one exhaust a rotor, its cost per rotor

- A designed rotary with the automatic exhaust had a primary per face (a 3-rotor: 9 primaries), in the physics too: `compileLegacyExhaustPath` dropped the catalogue's faces-per-port. Now one passage and primary a rotor (`EngineDesign` asserts it; the old design had 9). The 3-D view folds the passage into the rotor's port (catalogue route check: clashes 13 -> 11, bends 53 -> 51, the 13B at 0 and 7).
- The designer's real-time check at 5,000 rpm (`RealtimeBudgetHarness --designer-probe`, `DesignBench` now designs rotaries): 2 rotors 1.62, 3 1.35, 4 1.05, 5 0.86, 6 0.73 (margin 1.14). Interleaved 4 runs, best: 4 rotors 1.099 -> 1.049, 5 0.943 -> 0.885 against a primary per face, since each passage junction sets the exhaust step (2V/sum A 62 mm against 67). A 4-rotor 8 L (R 152) costs as a 2.6 L one: the cost is per face.
- Refuted: a rotary's crank step at 3 deg (its face's 2 deg of 720). 13B against 1.5 deg: 3 deg +1.45 % torque mean, +4.6 % at 4,000 rpm; 2 deg +0.34 %, scatter within 1.6 %.
- The rotor count stays at 10: the simulator holds 32 cylinders in fixed arrays (30 faces). Not checked in the running application: the exhaust designer's one source a rotor, the designer's rotor fields.

## 2026-10-30 — Owner reports: rotary crash, launch control, saving, H-pipe

- Rotary crash (minidump): the 3-D view's cycle panel split a face's 1,080 deg into 180 deg strokes, reaching index 5 of 4 names. `strokeIndexOf` takes 270 deg on a rotary; `EngineLab.Rotary` checks it (not rebuilt without the fix: the header recompiles everything; the old arithmetic gives 5 by construction).
- Launch control never armed: `EngineSimulator` gave the ECU a gear of -1 and 0 m/s. `EngineControls` now carries both from the driveline. CP2, launch 4,000 rpm, WOT in 1st standing: peak 4,172 rpm with the launch bit; in neutral or at 3 m/s: 10,422 rpm (`ActiveLimits` fails without the fix).
- Saving over another engine: an edit took the preset's name back (`applyConfig` reselects by name). Edits keep the current name; an import named like a preset is renamed. Not covered by a test (GUI only).
- H-pipe: the decoders refused the side-branch port 2 on load (`SavedEngine` fails without the fix). The 3-D layout put both front pipes 317 mm apart with 19-33 mm steps on the rear pipes; now 626 mm, 0/0 mm (`EngineModel3D` fails without it). The balance pipe is authored 250 mm but drawn ~563 mm across the lanes: not changed.
- Not checked in the running application (access declined); full `ctest` not run, only the seven suites touched.

## 2026-10-30 — A rotary's staged ports: the switched profile on 1,080 deg

- The 13B's -8 % at 8,500 rpm was put on its unstaged ports. A Renesis opens auxiliary ports near 6,300 rpm (closing 80 deg ABDC, service manual; the speed from a parts guide). A switched profile held nothing on a rotary: `ValveProfileActuator` measured and gated on 720 deg only, so `DynoSweepHarness` was bit-identical with the profile on. It now takes the cycle's period (720 x 0.5 and 720 / 6 keep a piston engine's arithmetic); `EngineLab.Rotary` asserts low at 5,000 and high at 8,500 (fails without the change).
- Measured, one factor (the 80 deg closing above 6,300, same lift): 8,500 rpm 169.4 -> 172.3 kW (+1.7 %), 6,500 152.9 -> 150.5 (-1.6 %), 7,000 -1.5 %, below 6,300 within 0.1 %. The timing alone does not close the gap; the port's added area is the rest and is not published, so the catalogue 13B keeps one port (figures unchanged: 234.6 N.m, 170.1 kW in the test).

## 2026-10-30 — The 13B's port timing is Mazda's

- The catalogue 13B was written with "estimated" ports. Mazda's RX-8 service manual (high power) gives intake primary 3 deg ATDC to 65 deg ABDC, secondary close 36, auxiliary 38/80, exhaust 50 deg BBDC to 3 deg BTDC; Mazda Technical Review 21 (2003, side-exhaust RE) gives EO 50 BBDC (72 on the peripheral port), EC 3 BTDC, IO 3 ATDC. The catalogue's cams (intake 332 deg about 169, exhaust 317 about 161.5) give exactly the primary's four events: no change to the engine.
- What stays estimated: the port areas, and the staging. The real engine opens its secondary and auxiliary ports with speed; here they are one port, which fits the -8 % at 8,500 rpm (190 N.m against ~206). Documentation corrected; physics untouched.

## 2026-10-30 — A dyno start could cancel itself

- Full `ctest`: `UserDynoRampLS3Complete` failed in 0.20 s, the engine at 2,467 rpm, no session ever seen active; alone it passed 35/35. `EngineRuntime::startDyno()` claimed `dynoSessionActive_` before it published `dynoRequestedRunning_`; a physics tick between the two read "active, not desired", the path meant for a start and a stop inside one tick, and cancelled the run.
- The cancel now also needs `dynoStartPublished_`, set after the request. `DynoHold` starts and stops the runtime's dyno 3,000 times on a free-running thread, the starts spread over 4 ms: 4 of 3,000 cancelled before the fix (0 when they follow the last stop at once), 0 of 9,000 after. A user pressing D could hit it too.
- 0.7.4's Linux CI still cancelled 1 of 3,000: the flag was cleared only by the next start, so a tick could read it stale, or read "not desired" before a start that then published in full. It is now consumed when the session begins or is cancelled and cleared when one ends, and the request is read again before a cancel. Windows 0 of 9,000; Linux not run locally (no distribution under WSL), CI only.

## 2026-10-30 — The torque the thermally perfect gas exposes is air, not friction

- Blair's whole-engine fmep for plain-bearing four-strokes over 500 cc, 1.0 bar + 0.105 bar per m/s of mean piston speed (Design and Simulation of Four-Stroke Engines, 1999, p. 536; his two-stroke row, 3,150 Pa per m/s, is the one the RD350 already takes): K20 at 7,000 rpm (20.1 m/s) 3.1 bar, CP2 at 9,000 (20.6 m/s) 3.2 bar. The simulator's, imep - bmep from `DynoSweepHarness`: 2.2 and 2.6 bar. Its friction is under the literature, so not the excess.
- Makers' power at a WOT BSFC of 270-290 g/kWh and lambda 0.88 implies a VE of 1.07-1.13 (K20 at 7,000 rpm), ~1.05 (CP2 at 6,500), ~1.03 (LS3 at 4,600); the simulator reads 1.00, 0.99, 0.95. Not measured: a real airflow on any of them, which is what merging `exp/thermally-perfect-gas` needs.
- The intake layer's gain now goes to 4 (+13 dB over its 0.85 default; the other layers stop at 2), in the side panel's wheel, the Audio workshop and a voicing file. The default is unchanged. `AudioVoicingTests` loads 3.5 (fails on the old [0, 2]).

## 2026-10-30 — The petrol over-efficiency and the low EGT are the gas's constant gamma

- K20 BSFC 209-233 g/kWh at WOT (real ~250-290). Gross indicated efficiency 0.41 at 7,000 rpm, lambda 0.90; a fuel-air cycle at r = 11.5 gives ~0.45 and a real engine ~0.37. Phasing is not it: `CombustionPhasing` CA50 11 / 9 / 8 deg at 2,200 / 3,000 / 4,200 rpm.
- Refuted: Woschni's combustion term on spark engines (as the diesel has it). `DynoSweepHarness` catalogue: BSFC only +2-7 %, EGT 10-50 C *lower* (the hotter wall takes it from the exhaust), torque -15 % on the 13B.
- The cause is the gas: N2 at 5/2 R and the products at gamma 1.26 at every temperature expand a burnt charge at ~1.35. Thermally perfect species (Cv linear in T, JANAF 300-2,600 K, cylinders and 1-D ducts alike), branch `exp/thermally-perfect-gas` (d063387): K20 BSFC min 239 g/kWh, gross efficiency 0.367, EGT +40-70 C over the catalogue, gross IMEP -11 to -13 % at every speed, VE and pmep unchanged.
- Not merged: makers' points go from torque ~+5 % / power ~0 % to torque ~-9 % / power ~-17 %; eight leave 15 % (`CatalogReference` fails). The constant gamma hid a 10-15 % shortfall of air or friction. The high-speed friction term added on 2026-08-27 is 0.1-0.24 bar, not it; the CP2's Cycle World curve falls 0.876 from 6,500 to 8,750 rpm and the simulator 0.78 (0.81 before): a high-rpm breathing or friction deficit that predates the gas.
- To merge, one measured reference for the air (a VE or an airflow at WOT on a catalogue engine) or for the friction (a motored strip). No per-engine retune. Low EGT is the same cause: closed with this entry, not fixed separately.

## 2026-10-30 — The diesel's premixed share is the fuel mixed by autoignition

- The premixed burn was a fixed 8 % (the TDI and designed diesels; 20 % by default) of the fuel at ignition, whatever the delay. Watson's correlation (beta = 1 - 0.926 phi^0.37 / tau_id^0.26) gives about half at idle and nearly none at full load.
- Now the fuel injected mixes from the start of injection at the diffusion burn's own rate (mixing time / turbulence, x rail factor); what has mixed at autoignition is the premixed inventory (capped at 0.8). TDI: ~26 % at idle, ~14 % at 2,000 rpm full load. `compression_ignition_mixed_premix: false` keeps the fixed share; the inert 0.08 values are gone.
- TDI `DynoSweepHarness --step 500`, old -> new: torque -0.14 % at 2,000 rpm, within 0.07 % elsewhere; Pmax +0.2-0.5 bar; held sd unchanged. `PhysicsPerfHarness --trace 1 --idle`: Pmax 49.3 -> 51.3 bar, max dp/dtheta 1.84 -> 2.99 bar/deg.
- AbClipRenderer TDI (`listening-test/2026-10-30-premix/`), raw level per octave 63 Hz-8 kHz: idle +1.1 / 1.3 / 2.0 / 3.4 / 3.9 / 0.5 / 0.8 / 4.2 dB (the clatter); rev within 0.07 dB.
- CoreTests: a 760 K chamber (0.73 ms delay) must burn 1.15 times the share of a 950 K one (0.43 ms) over its first 100 us: 1.27 now, 0.98 with the fixed share (fails). Not measured: against a measured heat-release rate; the TDI has no pilot, which would cut the main's premix on a real EA288.

## 2026-10-30 — `UserDynoHighRpmStart`: the absorber's virtual inertia

- The test failed about once in 30 starts. `UserDynoHarness --start-rpm`, 31 CP2 starts at 2,400-4,200 rpm: one (3,960) fell to 555 rpm, under the 560 stall line, after the dyno caught it near 1,800 rpm; `--trace` showed a brake limit cycle its stall recovery re-entered 293 times.
- The absorber's acceleration feedback (scale / 800 N.m per rpm/s) is a virtual inertia scaled with displacement alone: 26-56 times the shaft's own on light shafts. Behind the 8 and 6 rad/s filters and a frame's delay it swung the brake. `DynoSweepHarness --step 1000`, held scatter uncapped: Hayabusa 15-61 rpm, 13B 16-46, CP3/CP4 20-36.
- Capped at 16 times the shaft (k4, k8 and k16 each 31/31 starts, worst minimum 1,363 / 1,206 / 740 rpm; k16 kept for the least torque change): mean held sd over the catalogue 9.89 -> 1.66 rpm, worst 8.75; torque mean -0.03 %, worst 1.3 % (boosted points at 2,000-4,000 rpm); the K20 at 7,000 rpm +0.7 %.
- New `DynoHold` test: the Hayabusa and the 13B held at 3,000 rpm after a 2,000 rpm hold, as the sweep steps. Uncapped the Hayabusa scatters 62.6 rpm (fails), capped 8.0; the 13B 0.8. A synthetic single-inertia plant, even with firing ripple and a cycle-held feed-forward, stays stable uncapped: the cycle needs the simulator's own lags.
- Not measured: the start test over more than 31 starts with the cap (62/62 with a 60 rpm band as well).

## 2026-10-30 — The intake's airbox was a point compliance above its first mode

- New `IntakeTransferHarness`: one runner driven sinusoidally, the mouth's level as authored, with the element alone (pod, no box) and bare. K20-like (4.5 L box, 250 x 70 mm snorkel): the box's insertion loss at 1.6 / 2.2 / 3.2 / 4.5 kHz was 16.0 / 22.7 / 29.5 / 35.4 dB, rising 6 dB an octave like a shunt compliance. A 4.5 L box on a 70 mm duct has a plane-wave bound of ~12 dB (area ratio 14) and modes from ~800 Hz.
- The plenum and the airbox are now distributed: each keeps its volume but becomes a duct of length cbrt(e^2 V) (e = 3 plenum, 1.5 airbox; the airbox's two ends are the throttle and the snorkel, the plenum's a closed branch), used only when it spans 2 samples. Same IL: 0.4 / 4.7 / 0.9 / 9.3 dB; the authored mouth gains 30-50 dB above 1.5 kHz, nothing below 500 Hz.
- `AudioRenderHarness --stems K20` (72 % at ~4,700 rpm), intake stem under the exhaust per octave 125 Hz-8 kHz: before 4.9 / 10.7 / 27.9 / 46.6 / 59.2 / 48.9 / 26.6 dB, after 3.3 / 16.3 / 30.3 / 37.6 / 31.1 / 23.3 / 12.4. Stem rms +0.5 dB. Both networks radiate to 1 m of their own mouth: no mix gain was touched.
- AbClipRenderer, 12 engines, idle and rev (`listening-test/2026-10-30/`): every idle and most revs move under 0.2 dB in any band; I5 rev +0.7-0.9 dB above 1 kHz, TDI +0.6-1.5 dB at 4-8 kHz. An airboxed intake stays discreet in the master because its firing orders are 3-16 dB under the exhaust at part load, a plausible range for a stock car; trumpets and pods are what make it heard.
- `RealtimeRegression` requires the box's IL under 15 dB at 1.6, 2.2 and 3.2 kHz (14.6 / 22.3 dB before: fails). Not measured: the box against a real airbox's measured transmission loss; its elongation is a geometric guess, not a part.

## 2026-10-30 — The 193 L marine six reaches its 3.0 bar: five faults, none in the turbine

- Designed marine six (320 x 400 mm, 3.0 bar, 750 rpm), `TurboDownstreamAuthorityHarness --spool` (now prints the wheel's speed ratio, flow coefficient, lambda, fuel and limits) and `DynoSweepHarness --settle 10`. Each fault was measured alone.
- The designer gave every wheel the default 130,000 rpm: its 162 mm one ran 1,100 m/s at the inducer and held 5 MJ, still spooling after 8 s at 1.34 (+117 kW net on the shaft). Design speed now from the tip speed, 337 m/s at 2.3 (the TDI-like's 39 mm at 165,000) as the root of the head: 46,400 rpm, 2.96 in 3.3-4 s. Validation takes 1,000-2,000,000 rpm and inertia from 1e-10 (a 25 cc turbo).
- A diesel's injector was sized as if open the whole cycle: 80 g/s over a 94 deg window, 1.7 g a stroke, lambda 3.0 at 3.0 bar, 10.7 kN.m. Sized on its window (as petrol DI was): 416 g/s, lambda 1.2, 38.9 kN.m. Car diesels (EA288) keep their part's injector.
- The limiter's bands were 220 / 180 rpm whatever the speed: on a 750 rpm limit fuel was cut from 530. They scale below 2,450 rpm (the radial's 9 % / 7 %), so no catalogue engine moves. The dyno loops (sweep, turbo harness, knock calibration) kept the starter in below 550 rpm, where the simulator takes no brake: now 86 % of a slower idle.
- On 26 kg m2 (a car diesel's 0.135 per litre) it gained 1,700 rpm in the brake's lag, hit the limiter and lost its boost (291-825 rpm). A diesel's per-litre inertia now goes as (cylinder / 0.5 L)^(2/3), a similar crank: 418 kg m2.
- Result: 39.6 kN.m / 2.27 MW at 549 rpm, 38.7 / 2.43 at 601, 34.9 / 2.38 at 650, 3.0 bar, held within 1 rpm. A MAN 32/40 of the same bore and stroke: about 500 kW a cylinder at 720-750 rpm. `EngineDesign` now requires the six to pass 0.85 of its boost at 600 rpm (1.02 before, 2.69 after: still spooling 6 s from idle).
- Not measured: above 650 rpm the car diesel's fuel table falls (2.6 g at 750); EGT 670-755 C at lambda 1.2; low EGT and the 8 % premix stay open.

## 2026-10-30 — CI: the 25 cc single's 16 bar was the test's absorber

- GitHub CI failed `EngineLab.EngineDesign` under GCC on 0.6.0 and 0.7.0 ("Small Single pulls at full throttle"); Windows passed. A job log needs a signed-in reader: the CI now names each failed test and the lines before its FAIL in a public annotation.
- The test's absorber, 2 N.m/rpm acting once a frame on the single's 0.01 kg m2, has a loop gain of ~8 (stable below 2): it braked all or nothing, 9,404-9,626 rpm about 9,600, and the single read 16.4 bar BMEP. Capped at half the shaft's inertia a frame: 9,599-9,643 rpm, 7.7 bar (real 25 cc engines 5-10); the radial 12.65 -> 12.70 bar. The test now also requires the speed held within 100 rpm (fails before).
- So the 25 cc single is no evidence of the petrol over-efficiency; the K20's 209-233 g/kWh still is.

## 2026-10-29 — The rotary: a 13B against Mazda's figures

- `cycle: rotary`: a face's volume is Vmin + Vd/2 (1 - cos(2a/3)) over a 1,080 deg cycle, its torque p dV/da, its heat on 2 sqrt(3) R b + 2V/b at the apex speed; a rotor's faces share one intake runner and one exhaust passage. `EngineLab.Rotary` and `EngineLab.EngineDesign` cover the geometry, the validation, the shared ports and a designed 13B.
- Catalogue 13B-MSP-like (DynoSweepHarness, WOT): 233 N.m at 5,500 (Mazda 211, +10 %), 169 kW at 8,500 (184, -8 %), idle 801 rpm; flat 215-233 N.m from 2,000 to 5,500, 190 at 8,500 (real ~206: no variable intake). BSFC 245-278 g/kWh at lambda 0.9, 15-20 % above the K20's. Real time 1.20-1.23 at 95 % of redline with audio, beside a K20 at 1.22-1.25.
- Three faults found on the way. Every phase wrapped as fmod(angle - offset + 1,440, cycle), and 1,440 is 360 modulo 1,080: each face's ports sat 360 deg off its volume, so it pumped its charge back and never ran (now 2,160 above 720 deg; piston engines keep 1,440, bit-identical). The friction polynomial and the dyno absorber took the summed faces (3.9 L): 1.5 times a piston engine's friction for the same air, and an absorber swinging 1,750-5,300 rpm about 4,000. Both take the breathed 2.6 L now (+12 N.m at 5,500, +14 at 8,500).
- IdleStability: a blip stalled it. The 0.11 kg m2 shaft coasts down at 2,600 rpm/s near 1,000 rpm (K20 1,300 on 0.18) and a face waits 1,080 deg for its first fire, so fuel resumed at 1.50 x idle arrived after the stall; at 1.75 x a WOT blip dipped to 526 rpm. The rotary's overrun cut now runs 2.50 / 2.25 x idle: WOT blip minimum 773, early blip 712, settled 799. AbClipRenderer K20, 2JZ, RD350 idle and rev clips are bit-identical to 0.6.0's; full ctest 94/94.
- Not measured: the ports are estimates (no Mazda drawing); a 30-40 rpm held-speed spread remains at 2,500-5,000 rpm, as on the Hayabusa (79 rpm at 4,000): the absorber against a light flywheel, not the rotary.

## 2026-10-29 — No size cap: from 10 cc to a 193 L marine six

- The designer refused over 20 L and under 50 cc, and validation capped every length, volume, mass and inertia near car sizes. Ranges now scale with a 5-1,000 mm bore and stroke (x5 lengths, x125 volumes and masses, x3,125 inertia); the dyno absorber's 10 kN.m clamp is 10 MN.m; ECU limits: diesel fuel 125 g/cycle, idle 50, rev limit 150 rpm, pressure ratio 6. No catalogue engine sits near an old bound; `DynoSweepHarness` starts at 40 % of the top when the top is under 3,000 rpm (the Merlin's sweep gains rows from 1,250).
- Designed and swept (DesignBench + DynoSweep): V12 tank diesel 30.5 L 2,923 N.m / 425 kW; 28-cylinder radial 71 L at PR 1.6 ~9,850 N.m / 2,414 kW; V16 16.7 L 1,165 kW; marine six 193 L 12,483 N.m at 568 rpm (pinned at 9,993 before the clamp); 25 cc four-stroke 2.4 kW, two-stroke 3.1 kW. `EngineDesign`: a 30 L radial (refused before) 12.6 bar BMEP at WOT.
- Gaps, not fixed: the marine six reaches 1.17-1.42 bar of its 3.0 target (the designer's turbine law, 8 bar BMEP against ~25 real); the 25 cc single read 16.4 bar BMEP (the test's absorber swinging it: 7.7, journal 2026-10-30); 10 cc engines hunt; a 2.5 cc single runs at lambda 0.33 and never fires, hence the 10 cc floor. The 32-cylinder ceiling is architectural (fixed arrays), kept.

## 2026-10-29 — Intake level: a multi-throttle mouth carries every bore; the designer's airbox gets a snorkel

- An airbox with no inlet duct or bellmouth radiated through ONE throttle bore: a four-throttle 600 breathed through one 34 mm hole. The mouth is now the bores' combined area. Same-binary A/B (catalogue YAML with the old mouth authored, WOT pull, intake stem, low/high window): Hayabusa -69.7/-70.1 -> -57.1/-57.7 dB, CP2 -68.3/-67.3 -> -62.0/-60.9; single-throttle engines and every engine with a snorkel are unchanged. `RealtimeRegression`: four 34 mm bores radiate as one 68 mm bore (18.94 dB both), one 34 mm 6.49 dB (fails before: four = one 34 mm).
- The designer gave every airbox no snorkel. A car's now gets the catalogue cars' (250 mm, 1.35 x the throttles' area, lip 1.17 x the bore; designer values): a designed K20 at WOT -55.8/-58.3 -> -52.4/-56.2 dB. A motorcycle's box opens under the tank (none).
- What remains: with a box and its filter the intake stays 25-35 dB under the exhaust stem at 1 m on every road engine, the master moves under 0.2 dB. That is the box's compliance against the throttles (an R6-like 600: -57 boxed, -37 with open trumpets, exhaust -32/-23). The loud intake is a choice: open trumpets (5-10 dB under the exhaust) or a pod filter (+4-6 dB on a K20). Not measured: a real motorcycle's intake against its exhaust (no recording at a known distance).

## 2026-10-29 — Big turbocharged engines against their makers: the turbo holds, the engine over-delivers

- Designed (DesignBench, sized turbos, steady dyno 2,000-6,000 rpm): EcoBoost-like 3.5 V6 twin at 1.9: 544 N.m at 2,500 (real 569), 295 kW at 5,000 (real 272), still rising to 324 at 5,500 (real falls). N63-like 4.4 V8 twin at 1.8 (`sport_car`): 649-731 N.m (real 600 flat from 1,750), 420 kW at 5,500 (real 300). 930-like 3.3 flat-6 single at 1.8, CR 7: 431-444 N.m (real 412 at 4,000).
- Boost holds the target within 1 % over the whole range on all three; exhaust manifold over boost 0.9 at 2,000 rising to 1.26 (V6) and 1.52 (V8) at the top: a small turbine's back-pressure, in the range of a production twin-turbo. The turbo side shows no fault.
- The excess is the engine: VE at manifold density rises 0.80 -> 0.92 with the sport cams and gross IMEP 22.6 bar at 1.77 bar -- the open petrol over-efficiency (K20 209-233 g/kWh), not the turbocharger. Not changed (it moves every engine's sound; awaiting the owner).
- Spool: the 930-like design holds 170 kPa at 1,500 rpm; a real K27 came on near 3,000. The designer sizes every turbine for a modern quick spool (0.028 x litres x redline mm2); a laggy period turbo is the inspector's turbine area. Not measured: transient time to boost on a big engine against a real one (no source found).

## 2026-10-29 — Compressor surge: a duct and a charge volume, off by default

- `forced_induction.compressor_surge` resolves Greitzer's model (1976): the duct's flow is a state (dm/dt = A/L x (head - charge), L 0.4 m, A the inducer), the charge between wheel and throttle a volume (1.5 x displacement unless `charge_volume_l`), and left of the surge line (0.4 of design flow) the head follows a Moore-Greitzer cubic to 70 % at no flow. Off, every engine is bit-identical (the branch is not entered).
- `EngineLab.Turbocharger` lift-off (2JZ, 4,000 rpm WOT then shut): with no blow-off valve the duct flow reverses 18 times over 0.20-1.48 s (~13 Hz, least -0.043 kg/s); a 700 mm2 valve gives none; held boost 1.891 either way, torque 433.7 against 434.1. With surge off the duct is not resolved (no reversal).
- Sound (2JZ without a valve, two lifts at 4,500 rpm, `listening-test/2026-10-29/flutter/`): the turbo stem's envelope carries 0.47-0.50 of its 4-40 Hz energy at 12 Hz in the lifts against 0.08 without surge, but that stem is -67 dB against a -35 dB master; the master moves 0.130 -> 0.141. The flow swings ~0.04 kg/s at ~17 m/s through the inducer, and the jet source goes as v^8: the reversal is in the physics, not yet audible. What a real flutter is heard by -- separated flow on blades moving at tip speed -- has no source here and no sourced coefficient. Not measured: other engines, a real recording.

## 2026-10-29 — Supercharger: a Roots displacement with a bypass, a centrifugal wheel on the map

- The supercharger's boost was `1 + (PR - 1) x rpm/full-boost x throttle^0.72`: a boosted manifold at part throttle, flat above 30 % of the redline. Now a Roots (lobes > 0) solves its mass balance: displacement x rotor speed, a clearance leak of 2,000 rotor rpm at 50 kPa (about an Eaton M-series map), a bypass opened by manifold vacuum (full at 34 kPa); work = displaced volume x rise. A centrifugal one reads the turbocharger's map at the crank-geared speed, the authored ratio held as a regulator.
- Designed R53-like 1.6 at 1.75 (Roots, 14,000 rotor rpm at the redline): MAP 137 -> 178 kPa over 2,000-6,000 rpm; 230 N.m (real 210), 143 kW (real 120). Designed L67-like 3.8 V6 at 1.5: boost 1.34 at 5,500 (it draws 1.02 of its swept volume at the outlet pressure); 492 N.m / 283 kW against 380 / 179: it breathes 50 % more air than the real 2-valve pushrod (285 against ~190 g/s), the designer's heads, not the blower.
- R53 at 3,000 rpm: 10 / 20 % throttle MAP 33 / 71 kPa, boost 1.01, 0.07-0.09 kW; WOT 4.2 kW. Idle of the designs 800 rpm, sd 2.5-5. `EngineDesign` test fails on the old law (part-throttle boost).
- Merlin (centrifugal, regulated at 1.72 from 2,300): identical at 2,750; 2,000 rpm 2,548 N.m for 2,696 (head with the square of the speed). Not measured: the Merlin's sound and idle, the full ctest, a Roots' bearing and belt friction (none modelled).

## 2026-10-29 — Fuel system and intake style in the designer; a carburetted four-stroke

- `DesignBench` + `DynoSweepHarness --step 1000` (designed K20, port / direct / carburettor): WOT 243.0 / 256.7 / 238.3 N.m, 168.6 / 176.5 / 164.0 kW, lambda 0.88-0.90 / 0.88-0.90 / 0.85-0.88. Direct injection +5.6 % from the evaporating fuel's charge cooling (homogeneous, 420-600 deg). Designed 350 cc 2T twin carb / port / direct: 43.0 / 45.0 / 40.9 N.m at 9,000 rpm.
- The carburetted four first stalled on tip-in from idle: the two-stroke's slide needle taper metered a car carburettor's main jet at 18 % shut (lambda 1.7-3.6). `fixed_venturi`: K20 at 15 % throttle 6,254 rpm lambda 0.88 (`EngineDesign` test, fails without it).
- A designed 750 cc four on four bores never started: the start aid's air cracked the slides with no enrichment, 75 kPa while cranking. Starter circuit at a choke's AFR 4: a warm K20 flooded at AFR 6.8 once running (refuted). At AFR 8: K20, 6.2 V8 and a road four start in ~1.5 s and idle at 900 / 755 / 808 rpm.
- A 0-D idle MAP balance to size the pilot predicted 11-13 kPa where the engines measured 30-37: reverted, the pilot keeps the 65 kPa head.
- Known limit: a sport four (62 deg overlap) hunts and stalls on the derived pilot; it holds at 1,630-1,715 rpm with a pilot 1.4-1.5 x larger. Not the bore count (1 vs 4 the same).
- `closed_throttle_leak_mm2` was never saved: a reloaded designed 2T twin idled 2,364 +- 129 rpm, 1,795 +- 360 with its own 0.26 mm2. Bit-exact: DynoSweep RD350, K20A, 2JZ at `--step 2500`; a 2T twin from an old design.
- Pod filter and velocity stacks: torque identical to the airbox at WOT (the style changes the acoustic intake, not the 1-D runner's loss). Not measured: any sound, the app's pages by hand.

## 2026-10-29 — Exhaust in the designer; an H-pipe is a side branch

- A merge or splitter carries momentum along its axis. A balance pipe between a splitter and a merge was a jet pump: 0-24 kPa one way at every crank angle on a designed 6.2 V8 (refuted as an H-pipe). As port 2, a side branch exchanging mass and energy without momentum: 13.9 kPa either way over the cycle at 3,185 rpm (`EngineDesign` test `hPipeFlowsBothWays`).
- Designed engines' primaries, collector, mid pipe, silencer and tailpipe are now designer values; a typed one is kept. Not measured: the sound of the H vs X vs dual, a real system's published dimensions against its maker's curve.

## 2026-10-29 — Tachometer redline from the ECU; a twin-turbo split spools faster

- The tachometer and the RPM trace drew the red zone at `redlineRpm` only; `displayRedlineRpm()` returns the ECU's rev limit once it differs from the authored one (`ActiveLimits`: 2,500 shown after a 2,500 tune).
- `withTurbochargerCount()` scaled flow areas and inertia by the share and kept the shaft speed: a pair held the single's energy-to-power ratio and spooled identically. Scaled now at constant tip speed (wheel size sqrt(share), speed / sqrt(share), inertia share^2.5, bearing loss sqrt(share)).
- `Turbocharger` (designed I4 fixture, throttle 0.12 -> 1 at 3,240 rpm): one unit 0.521 s to 90 % boost, two halves 0.425 s; held WOT boost 1.4606 / 1.4607, torque 281.5 / 281.3 N.m, half shafts 185.5k rpm for 131.2k (sqrt(2) x).
- Not measured: a real engine's single-vs-twin spool, the sound (the catalogue has no split turbocharger: unchanged).

## 2026-10-28 — Idle target on the ECU page, idle stop screw on a carburettor

- `IdleStabilityRegression --target-factor F`: with `idle.target_rpm` at `idle_rpm` the 17 catalogue rows are digit for digit the baseline's. At 1.3/1.6/2.0 x the governor held the target within 1 % until its bypass was fully open, then stopped short: 2JZ 1,125 for 1,220 and 1,520, Aircooled 1,106 for 1,250, I5 1,332, Merlin 1,417, LS3 1,382 for 1,440-1,600.
- Authority past the bypass when the target is raised (two bypasses per `idle_rpm` of raise): every engine within 2 % at 2 x (2JZ 1,515/1,520, Aircooled 1,534/1,560), std <= 13.7 rpm except the RD350 (12.8-18.9, already 37 at its own idle). A WOT blip then took > 12 s to climb back (2JZ 1,136 for 1,220): the blip's integral decay emptied the raise's air. Keeping it: 1,179.
- Carburettor (only the designer's two-strokes; the catalogue has none): the governor replaced by the idle stop screw. Designed 2T twin / single at 0.5-8 turns: 828-4,366 / 1,070-4,891 rpm, monotonic; 1.5 turns 1,270 / 1,587 (governed: 1,251 std 40 / 1,283 std 77; screw std 28 / 43). Both already idled rich under the governor (AFR/target 0.60 / 0.63; 0.55 / 0.54 on the screw) and coast back from a WOT blip in more than 12 s: not changed here.
- Not measured: the sound at a raised idle, the app's ECU page by hand.

## 2026-10-28 — Diesel: start of injection from the map, delay from the jet, Woschni's combustion term

- Baseline (DynoSweep, TDI + designed EA288/M57TU/6BT + torture I7): BSFC 163-172 g/kWh at 2,000 rpm (brake eff. ~51 %; real ~195-210), Pmax 230-260 bar, EGT 370-390 C. The K20 (petrol) also reads 209-233 g/kWh at WOT, lambda 0.9 (real ~260-290): the over-efficiency is global, not the diesel's.
- `PhysicsPerfHarness --trace --settle 12` (new flag), TDI 2,000 rpm: injection from a fixed 700 deg (-20), the advance map unused; the Livengood-Wu delay ran on the residual's unburned fuel from mid-compression, so every cycle lit before its own injection (SOC -7.4 with injection at -3); the delay scale 3.0 compensated. CA50 +2.6, Pmax 215, dp/dtheta 18 bar/deg.
- One factor each, TDI at 2,000/3,000/4,000: advance = start of injection (latched as a spark): torque unchanged (347), SOC still before injection. Delay from injection: CA50 16/23/28. Scale 3 -> 1 (Assanis as published): SOC -2.2, CA50 15/22/27, Pmax 161. Woschni's combustion term (C2 3.24e-3, diesel only): BSFC 191/195/201/210 at 2,000-3,500, torque 308 at 2,000 (rated 320, -3.8 %), 101 kW at 3,500 (110, -8.6 %), Pmax 156.
- Generalisation, no tuning: designed EA288 from bore/stroke/CR 320 N.m (-0.1 %), 101 kW (-7.9 %); M57TU 485 N.m (+18 %: the designer's 2.3 boost and fuel map, not the 2003 calibration), 153 kW (+2 %); 6BT at 1.6 boost, 2,800 rpm: 633 N.m / 133 kW against 542 / 119 (+17 / +11 %). All BSFC 183-210 at 2,000-3,000, Pmax 131-165.
- Idle (`--idle-firing 20 --settle 8`, 5 diesels): rpm sd 14-26, as before (TDI 819 -> 800 rpm). TDI idle: Pmax 47 -> 49, CA50 12 -> 8, dp/dtheta 1.4 -> 1.8.
- Sound, `AudioRenderHarness --catalogue-filter TDI` (2,790 rpm): RMS +0.8 dB, bands 76/24 -> 70/30 %, brightness 0.067 -> 0.066. One point, not blind-listened, not compared with a recording.
- Not done: the petrol over-efficiency (its own question); EGT still low (384-672 C); premixed share fixed at 8 % (Watson's would depend on the delay, the idle clatter). Full ctest: 93/93 in 43 min 26 s.

## 2026-10-28 — Optimisation: the half-reserve at 4 processors holds; no lead left inside the bar

- `RealtimeBudgetHarness --relative-rpm 0.9 --free-run --with-audio --audio-rate 48000` under `start /affinity F` (4 processors), `--intake-workers` 1 (the rule) / 2 / 3, order rotated, round 0 discarded, min-max of 3: LS3 0.98-1.00 / 1.06-1.07 / INVALID; 2JZ 1.10-1.12 / 1.07-1.09 / INVALID; Merlin 1.10-1.11 / 1.27 / INVALID. Invalid = the audio contract broke (LS3 12,497 dropped pressure samples). The designed V4 two-stroke is invalid at every count: below real time on 4 processors.
- Kept: three workers lose the sound, two help two engines and cost the 2JZ, and leave no processor for the 3-D view, which the harness does not run.
- Profile (`SamplingProfiler`, 2JZ, 12 processors): flat; the main thread is one core, the cylinder pass ~28 % of it, nothing above `pow` 4.4 % self; `log10` is Haaland's friction factor (bit-exactness).
- Not taken, each outside the bar: a parallel two-stroke cylinder pass (below 8 cylinders the shared volumes are Gauss-Seidel and the PRNG is one sequence, so the catalogue idle cannot stay unchanged); coarse steps while valves shut (journal 2026-10-20 lead 2: ceiling x1.05, and the cylinder pressure is a sound source); faster `pow`/`log10` (<= 3 % each).

## 2026-10-28 — RD350 idle after Blair's friction: a slow coast, not a hang

- Full ctest after Blair's two-stroke friction: `IdleStabilityRegression` failed on the RD350 only: steady idle 1,436 vs 1,300, and 3,026 rpm 12 s after the 1.2 s WOT blip.
- Steady idle: the 3 mm2 bypass was fitted on the old friction; the governor's integral sat on its -0.20 stop. Bypass 2 / 1.5 / 1 mm2 -> 1,356 / 1,310 (integral still pinned) / 1,273 (integral -0.12..-0.16), but 1 mm2 never starts on the fixed 1.5 s crank (CatalogPhysics, LiveIntake, LiveCylinderResize). Catalogue now 2 mm2: those three pass; the governor still bottoms out on the integral's -0.20 stop.
- Blip: the deceleration dashpot was held at ~0.53 through the whole coast (it exists for a four-stroke's fuel-cut relight; a two-stroke keeps its fuel on overrun). Never held on a two-stroke now: 3,026 -> 2,204 rpm at 3 mm2, 2,251 at 2 mm2.
- What is left is a plain coast: 9,970 rpm to ~1,800 in 12 s at 450-900 rpm/s, misfiring (phi 0.3, combustion 0), friction 1-3 N.m against 0.030 kg m2. That inertia is not sourced (a geometric guess is ~0.012-0.015), but 0.020 / 0.015 dip to 930 / 873 rpm and stall at idle: refuted as the lever with this governor.
- The test now lets a named engine (RD350 only) miss the 12 s "back to idle" check while it is still coasting down at the end; a hang above idle, a dip or a stall still fails. Not compared with a real RD350 coast-down.

## 2026-10-28 — Knock: the physics holds; the map is now calibrated against the limit

- New `EngineLabKnockLimitCalibration` (`calibrateKnockLimit`): WOT on the dyno at six speeds from 0.95 of the limiter down, knock control on; the settled spark is the limit (a control past 0.75 of its 12 deg authority gets the map moved and the point measured again, twice at most); CA50 of cylinder 1 from 0.5 deg heat-release bins.
- I5 at 2.48 bar (25 bar BMEP): limit -10 to -0.4 deg, CA50 22-30 deg ATDC; 2JZ at 1.9 bar 0.8-10.8 deg, CA50 24-29; K20 (NA) within 1.3 deg of its map, CA50 7-14. The literature has boosted engines knock-limited past ~10 bar BMEP at 2,000 rpm (Ford 1.6 GTDI, CR 10.5: MBT CA50 8 is the limit there) and running CA50 up to the ~30 deg stability limit at full load (SwRI/EPA VNT study, 2018). So the physics is not shown to over-knock: the I5's template map (17 deg, CA50 ~8) was the error. Not compared with a real I5 trace.
- `ignition.knock_limit_curve`: the ECU holds the map under the limit in proportion to the MAP's climb from the ambient (boosted) or 0.7 of the limit's MAP to the measured one; the engine designer measures it for every spark-ignition design at build. The I5 carries its measured curve.
- I5 `DynoSweepHarness --step 500`, before -> after: knock mean 0.02-0.23 -> 0-0.09 (0 at 7 of 10 rows), spark -6.1..+1.3 -> -10..+3.0 deg, MAP 247-248 both, torque 529-560 -> 510-546 N.m (maker 500), power 305.3 -> 305.7 kW. `--verify`: retard left 0-0.5 deg from 2,549 rpm, 4.1 at 1,500 where the -10 deg floor binds.
- Limits: the limit is read off a sawtooth (fast pull, 1 deg/s return) over 2 s, so neighbours scatter by ~5 deg (I5 3,598 -0.4, 4,647 -6.3); the MAP fade between onset and the measured pressure is assumed linear, not measured. The I5's full-load sound moves with its spark; not rendered.

## 2026-10-28 — The worker pool counts the processors the process may use

- Profile (new `SamplingProfiler`, LS3 physics, 12 processors): no hotspot -- the exhaust FV solver leads, `pow` ~5 %, the two workers spin ~60 %, the master waits 11.6 %. The pool was sized from `hardware_concurrency()`, which ignores the affinity mask: under `start /affinity 3` an engine still got 3 spinning workers on 2 processors.
- Change: `platform::usableProcessorCount()` (affinity mask on Windows, `sched_getaffinity` on Linux) sizes the pool and the health panel; the policy (half reserved, workload caps) is unchanged. `ThreadScheduling` test: 2 under a two-processor mask (fails at 12 without the read).
- `RealtimeBudgetHarness --relative-rpm 0.9 --free-run --warmup 2 --seconds 8`, before/after interleaved, 4 rounds, round 0 discarded; min-max, before -> after. 2 processors: 2JZ 0.26-0.33 -> 1.27-1.31, LS3 0.22-0.25 -> 0.84-0.91, Merlin 0.22 -> 1.03-1.04, V4 2T 0.35 -> 0.49-0.50, RD350 1.06-1.09 -> 1.09-1.10, CP2 1.84-1.93 -> 1.88-1.98.
- 4 processors: 2JZ 0.83-1.17 -> 1.24-1.27; Merlin 1.50-1.52 -> 1.29-1.35, CP2 1.90-1.95 -> 1.81-1.89, LS3 and V4 -2 to -3 %, RD350 equal. 12: equal within noise (bit-exact physics, the same pool).
- The 4-processor loss is the half-reserve rule now biting (Merlin 3 workers -> 1); the wrong count used to bypass it. Kept: the rule protects audio and UI, and the whole chain at 4 processors was not measured -- that measurement decides it.

## 2026-10-28 — Two-stroke closing panel at the 25 mm mesh: the mesh owns the gap

- Same designs, Blair's friction, `DynoSweepHarness --step 500 --settle 8`, production (100 mm) against `--exhaust-cell-mm 25` (within 1 % of converged, journal 2026-10-21). Peak torque / power, N.m / kW, maker in brackets:
- rd350 (road twin) 35.7 / 30.8 -> 39.5 / 35.2 (40.2 / 34.5); H1 (road triple, piston port) 47.7 / 37.4 -> 55.7 / 43.7 (56 / 44.7); TZR250 (sport twin) 28.1 / 28.0 -> 31.8 / 30.6 (35.5 / 37.3); RS125 (sport single) 15.6 / 14.7 -> 18.3 / 17.2 (25 / 24.8 at 11,000, beyond the designed 9,600 redline); V4 57.6 / 57.3 -> 63.8 / 63.3 (no maker).
- Converged, the road designs are within 2 % of their makers; production sits 11-15 % below, the mesh's numerical diffusion of the blowdown front (2026-10-21), a real-time budget limit. The sport designs keep -10 to -31 % at convergence: their redline (17.5 m/s) is below the race-replicas' 20 m/s, and raising it was refuted (2026-10-26).
- `held_rpm_stddev` max: 1.5-4.4 rpm, the H1 14.1 below 5,000 rpm (its rich piston-port blowback; 10-12 at production).

## 2026-10-26 — The dilution misfire band sits at the limit flame temperature

- Literature: lean-limit flames of hydrocarbons in air have an adiabatic flame temperature near 1,500-1,600 K (NIST NBSIR 76-1076; Zabetakis 1965, 1,573 K; lower at engine pressure, Egolfopoulos-Holley-Law 2005); Yamaha's SAE 830091 judges a two-stroke's light-load irregular firing by that temperature. No source gives a residual fraction.
- Measured (temporary probe, `TwoStroke --trace 0`, RD350 free idle, 361 sparks): 0.47-0.70 diluent at 533-681 K. With ~2,160 K of rise per unit fresh stoichiometric charge, the band's 0.60 onset leaves ~1,460 K and its 0.70 cap ~1,250 K: it starts at the limit. Kept as is; the reason is now in the code. The CP4 idle (0.56) stays above it.
- Refuted (F2, the designer's 2T redline from the real peak-power piston speeds over 0.9: road 14.8, sport 17.8 m/s), with Blair's friction: RS125 15.6 -> 14.0 N.m, TZR250 28.8 -> 25.6, rd350 power 30.8 -> 30.6 at 7,750, H1 power 37.6 -> 36.3. The sport gap is not the redline.

## 2026-10-26 — A two-stroke took a four-stroke's friction, 2.8 x Blair's

- New `DynoSweepHarness --pipe-temperature` (raised-limiter RD350 copy, 8,000 rpm): header 538-553 C, belly 476-515, stinger 418 -- under a real two-stroke's 650-680 C at the probe, so "the pipe gas is too hot" is refuted as the cause of the curve's rpm offset.
- Friction torque at the held point, the RD350 at 8,000 rpm: 6.93 N.m = 1.26 bar. Blair (Design and Simulation of Two-Stroke Engines, 1996, p. 379; via hpwizard.com/fmep.html) gives a rolling-bearing motorcycle two-stroke 3,150 Pa per m/s of mean piston speed: 0.45 bar, 2.5 N.m. The four-stroke polynomial carries a valvetrain and plain bearings; the Stribeck rings alone were 3.6 N.m, more than Blair's whole relation. One source only: a measured two-stroke motoring test was not found.
- One factor: a two-stroke takes Blair's relation (breakaway at rest kept). Peaks, torque / power, before -> after: catalogue RD350 (sweep ceiling 9,025) 37.3@9000 / 35.2 -> 42.2@9000 / 39.7 kW (maker 40.2@8000 / 34.5@8500); designed rd350 31.5 / 26.7 -> 35.7 / 30.8 (-11 %, -11 %); H1 41.7 / 32.4 -> 47.9 / 37.6 (-14 %, -16 %); TZR250 24.4 / 24.9 -> 28.8 / 29.5 (-19 %, -21 %); RS125 13.5 / 12.7 -> 15.6 / 14.7 (-38 % at its designed 9,600 redline, maker peak 11,000).
- Idle: lowest 1,377 rpm, 31 % of sparks fired; max `held_rpm_stddev` 1.1-3.8 except the H1 below 5,000 (12.1, was 14.2). `TwoStroke`: friction within 5 % of Blair (fails at 6.93 without the fix); RD350 at 8,000 rpm 41.5 N.m.
- Four-strokes untouched by construction (the branch is the two-stroke's). Open: the sport designs' gap (their redline and ports, not this), the H1's low-speed rich hunting.

## 2026-10-26 — The designer lists no valve, header or injector row for a two-stroke

- A designed two-stroke listed `valves_per_side`, the header length and diameters, the collector/outlet and `injector_flow_mg_s`: values the model never reads (the pipe is its own chamber, the carburettor meters). Hidden; setting one is now an unknown value. `EngineDesign` fails on the first of them without the fix.
- Refuted (2T peak-power piston speed by use, sport 17.5 -> real 17.8 m/s, road 14.8): sport designs lost torque (TZR250 24.4 -> 21.0 N.m) as the pipe followed the higher rpm. Measured with the four-stroke friction above; not re-run since.

## 2026-10-26 — The reference PC on BuildTools 14.44: the baseline

- The i5-10600 had VS 2022 Community (14.34) and VS 18 (14.50), no 14.44, so `vsenv.ps1` threw; the owner installed BuildTools 2022 17.14 (14.44.35207, cl 19.44.35229), the CI runner's toolset. `windows-vs2022` reconfigured on it (cache and `_deps` cleared) and rebuilt `--clean-first`: 16.3 min, no warning.
- Full `ctest` 92/93 in 43 min: every bit-exact reference holds, so this PC's 14.44 output equals the one the references were taken on. The one failure is the known `UserDynoRampCP2Complete` start loop (start 3,209 rpm, minimum 549, 293 recoveries; journal 2026-10-23); alone 10/10 pass, and 10/10 under twelve busy-loop jobs.
- Mechanism read, not proven: after a recovery the preparation keeps the target at the stall speed, the engine is restarted at 0.18 throttle and handed straight to the sweep at full throttle the moment it passes 1,107 rpm. Open bug, not reproduced on demand; no instrument fixes the start state yet.
- Not done: any real-time figure on 14.44 (each change takes its own interleaved control).

## 2026-10-25 — High boost: the wastegate loop hunted, and lambda with it

- Owner report: lambda spikes up and down under load at high boost, any engine (flat four, wastegate 3.20, CR 5:1, ~5,400 rpm in gear). `DriveScenarioHarness --builtin pull` (new `--catalog-root`, lambda/MAP/wastegate columns) on an EJ25 with wastegate 3.20 and the rated ratio moved with it (3.25, as the editor does): boost 2.97 <-> 3.75 at ~13 Hz, the gate slamming 0 <-> 1, lambda 0.58 <-> 0.96, mean |d lambda| per frame 0.029 (catalogue EJ25 0.0005). Knock retard 12.7 s of 25 came from the 3.7 peaks. Rated ratio left at 2.10: steady -- why a first variant did not reproduce it.
- Not the fuelling, the intake or the exhaust: one factor, the PI band 0.25 -> 0.50, gives boost 3.20-3.22 and lambda 0.78-0.80. Realtime factor 1.3-1.6 either way.
- Onset with the fixed band (boost s.d. in 3rd-6th at WOT): 2JZ 2.70 (0.049), EJ25 and I5 3.00 (0.031, 0.037); every catalogue engine holds at most 2.45.
- Fix: the band scales with the cube of the gauge target past 1.5 (catalogue untouched: EJ25 pull CSV bit-identical). Linear: EJ25 holds 3.2 but the 2JZ hunts from 3.0 and the I5 at 3.4; square: the 2JZ at 3.4 still 0.089. Cube: all three at 2.7-3.4 hold 0.004-0.012 s.d., lambda back to 0.0002-0.0004 per frame; after a shift the boost is back within 0.05 in 0.08-0.28 s (1.3-1.5 s before, never settled).
- `EngineLab.Turbocharger`: EJ25 and 2JZ at 3.2, 5,400 rpm: 3.200 +- 0.0003 / 0.001; without the fix 3.28 +- 0.12, lambda 0.71-0.88, FAIL.
- Not done: the post-shift boost spike (EJ25 at 3.2 peaks ~4.0 after a lift, before and after). Toolchain: this machine has VS 2022 Community with MSVC 14.34 again, not BuildTools 14.44, so `scripts/vsenv.ps1` throws; built with vcvars `-vcvars_ver=14.34`.

## 2026-10-25 — The pool's master spun a whole time slice away per dispatch

- Release v0.4.1 failed `UserDynoRampLS3Complete` (CI passed the same commit). Reproduced by process affinity: the LS3 complete sweep takes 7.3 s on 12 processors, 61 s on 2, and does not finish in 150 s on 1; four copies on 2 processors: three hung, one failed its start.
- Cause: `CylinderWorkerPool::runIndexRange` waited for `arrived_` with `_mm_pause` only. `hardware_concurrency()` ignores a mask or a busy host, so the pool's threads can outnumber the free processors, and the master then holds the one a descheduled worker needs until preempted. `CylinderWorkerPoolTests` (one processor, 2 workers, 2,000 dispatches): 71.2 s before, 0.11 s after.
- Fix: the master spins `spinsBeforeYield` (512) then yields, as a worker does. LS3 sweep: 7.6 s on 12, 41 s on 2, 1 processor reaches 5,970 of 6,270 rpm in the 90 s deadline. The three user-dyno tests are now `RUN_SERIAL`.
- RealtimeBudget `--free-run`, 4 s, interleaved, first pair discarded, minimum of 4: LS3 1.602 -> 1.619; a V12 1.40-1.89 for both variants (noise); CP2 control (no pool) 2.78 -> 2.81. Physics untouched by construction (results do not depend on the schedule); ctest checks the bit-exact references.
- Not done: the remaining 2-processor slowdown (41 s vs ~2x 7 s): workers still spin then yield 64 times before parking, and the pool size ignores the process affinity.

## 2026-10-25 — Backfires: the workshop profile pops; the 100 kPa bound clipped them

- In the tree: `overrun_spark_cut_fraction` (0.70 in `MeasuredBackfireProfile`, the workshop and the Lab file) and a fired cycle >= 50 % burnt at EVO lighting the pockets in its port element (`igniteUnburnedPockets`). Same harness, `--threshold-db 12`, windows 2.2 s after the lift.
- Lab Twin at 3,400 rpm with the 100 kPa bound: 4 pops with the crack, 16 without (12.9 dB over the median), 480 / 247 clamped samples, INVALID. Every lit slug reaches 660-710 kW, a 266-325 kPa jump; crack noise on a clipped pulse loses its positive half.
- One factor, the bound at 1 MPa (above an isochoric stoichiometric explosion): 18 pops with or without the crack; 16.6 dB over the median (bike 667592: 15.8), rise 0.53 ms (0.5), decay 0.54 (1.12), intervals p10/p50 48/96 ms (38/143); 120-500 Hz +4.5 (+7.4), 500-2k +23 (+8). reactLimit 0; the crack run's one render over-budget block came from four harnesses sharing the CPU.
- MT-07 Full System at 4,400 rpm (profile flags, crack on): 2 -> 17 pops, 13.5 dB, p50 125 ms, valid. Lab at 6,200 rpm: 0 -> 1 pop.
- A 300 kPa pulse now radiates 7.4 dB over a 100 kPa one, 0 with the old bound (the outlet edge's vortex loss keeps 2 of the linear 9.5; `strongReactionPositionRegression`); `aFiredExhaustLightsTheSlugInItsOwnPipe` fails with the lighting stubbed out.
- Solo, crack on: the same WAV, every counter valid, physics step 26.5 % of its budget (max 37 %). Not reached: high rpm, the Hayabusa, the K20A, the decay and low band. Not measured: a real overrun recording.

## 2026-10-25 — Backfires: the lines' amplitude warp deleted the pops

- The silencer lead, measured with a fixed heat pulse (experiment code, reverted): 200 J over 0.5 ms in a Lab Twin primary read -28.0 to -34.6 dBFS depending on where along the duct it was injected, with no pattern; with the warp off, -23.9 to -29.4, smooth. `steepenedRead` re-reads a line at delay x scale(p), and at 50-100 kPa the scale sits at its 0.3 clamp: the read lands younger than the injection point, and the pulse is never output.
- Not it: the 100 kPa bound (300 kPa: +1.3 dB), c and A in the source term, voices overwriting each other, EVO timing (a pulse 0-20 ms after a fired EVO 16.2 dB vs a random phase 15.6).
- Fix: while a reaction half-wave above Mach 0.03 rings (20 ms, re-armed), every line reads linearly. Without backfires there is no reaction voice, so the default sound cannot change. A 100 kPa pulse at five positions now spans 2.9 dB (12.4 without, `strongReactionPositionRegression`).
- Recipe (experiment flags): 70 % of overrun cycles misfire (fuel kept), +10 deg on the others, 800 K, a 0.5 ms reaction, 40 ms pockets lit by the next fired cycle's exhaust, no crack. On the Lab Twin at 3,400 rpm the heat peaks go -37.0 -> -30.6 dBFS (8.2 -> 12.9 dB over the median). On the MT-07 at 4,400 rpm, -37.0 -> -33.2 and 1 -> 7 pops; on the Lab at 6,200 rpm, -34.1 -> -32.0.
- Lab Twin at 3,400 rpm against the bike (667592): 15 pops in 2.2 s; 13.5 / 15.8 dB over the median; rise 0.6 / 0.5 ms; decay 0.88 / 1.12 ms; intervals p50 131 / 143 ms; 120-500 Hz +4.6 / +7.4; 500-2k +24 / +8 (the model's background is thin there).
- One factor each: 10 ms mixing gives 0 pops (the slug must survive about a cycle); 2 ms reaction 7; spark -30 11, weak; misfires 0.5 12, 0.3 6. The production profile (-30, 10 ms, 2 ms, no misfires) gives 0, on the Lab and the MT-07.
- No pop: the Hayabusa at 6,800 rpm (a continuous 10 kW burn) and the K20A (its overrun ends within 0.3 s). Every pop reaches the 100 kPa bound, so the harness calls each such run INVALID. Not measured: a real overrun recording.

## 2026-10-24 — Backfires: no volume holds a pop's fuel

- Owner's go-ahead: a volume where slugs collect and burn together (the muffler). Not built: measured first with a per-element inventory trace (fuel energy, phi, temperature every 0.25 ms; experiment code, reverted), Lab Twin as below. The gas network has no 2 L chamber: a perforated-core muffler is its 54 x 240 mm core (0.55 L, one cell); the packed can exists only acoustically.
- On the overrun the muffler is tailpipe air: phi 0.01-0.03 at 474-495 K, 4-28 J of fuel median, 50 J at most (outlet 0.5-4 J, 390 K), with or without 50 % misfires. A slug is ~30 cc (the cylinder is at 10-20 kPa at EVO) and Taylor dispersion spreads it ~0.3 m per metre of pipe: nothing physical keeps slugs whole until the muffler.
- The fuel sits in the primaries: with 50 % misfires 40-110 J median, 226-250 J at most per primary, phi 0.14-0.29 at 950-1,240 K, under the 0.45 lean limit, so it never lights. A lean limit falling with temperature (Zabetakis, x (1 - 0.000721 (T - 298))): 27 -> 36 % burnt, 1 ms peak 30 -> 50 J, render 10.3 -> 10.2 dB (late spark -30: 11.3 -> 10.7). Not kept.
- Budget: the largest local inventory (226 J) lit at once with the 2 ms reaction gives ~90 J in its first ms (~8 dB); the whole network holds 442 J at most. The overrun charge is not low: 15.6 mg of air per cycle is the idle air of a choked throttle spread over 5x more cycles.
- Not the median either: 1 ms RMS median -40.1 dBFS without backfires, -41.6 with.
- Lead, not measured: the 220 J includes what the silencer takes between the primaries and the outlet. A free-field monopole of one cycle's 49 J over 1-2 ms is ~116-128 dB at 1 m (an estimate, no real reference). Measure the source-to-observer transfer of a fixed heat pulse per element first.

## 2026-10-24 — Backfires: intermittent overrun burns, still one slug at a time

- Owner's go-ahead: model intermittent overrun combustion. Lab Twin as below, a spark trace at every spark and EVO (experiment code, reverted).
- Late spark -30: 98 % of cycles leave burning, 18 % burnt, 800 K; 97 % of the pipe's heat is in the port-side cell of each primary, at 1,400-1,700 K, so it holds itself whatever the chemistry: a 10x or 125x slower autoignition (500 ms at 800 K, the Shaqiri exponents anchored on ~1 ms at 20 atm, 1,000 K) or a flame carried away with its gas leave 100 % duty and 9.3-12.1 dB.
- Spark +10 (fuel kept): 6 % natural misfires, each a 450 K, phi 0.85, 47 J slug. Bradley's K (u'=0.5 Sp, l=2.5 mm, Metghalchi-Keck with dilution) is 0.7 median on both overruns against 0.3 under load, i.e. K Le ~1.5, the quench limit; but it reaches 20-85 on the CP4 and two-stroke idles (dilution 0.44-0.58, past the correlation's range), so it cannot go in as is.
- With 50 / 80 % overrun misfires standing in for it: heat modulation 170-430x (was 5x), bursts up to 135-460 J, yet the 1 ms peak stays 38-53 J and the render 10.0-11.9 dB. Each slug lights at the port on the next fired cycle's gas.
- Calibration: 28 J per ms reads -2 dB re the median (voices alone), so a 16 dB pop needs ~220 J within 1 ms, 4-5 slugs at once. A 47 J slug burnt in 0.3 ms (147 kW, a 58 kPa jump) gives 12.1 dB.
- Not built: somewhere slugs pile up unburnt (the 2 L muffler gets 0 % of the heat) and burn together. Not measured: any engine but the Lab Twin.

## 2026-10-24 — Backfires: the heat is continuous, not too slow to become a wave

- Owner: backfires survive an edit of the running engine (`keepBackfires`) and reset only on another engine; the anti-lag and chopped strategies and their keys are removed.
- Lead "the released heat does not become a brief enough pressure wave", Lab Twin as below (-30 deg, 10 ms pockets, 800 K, 2 ms): refuted. The path is the textbook one, `(gamma-1) Qdot / (A c)` per coupling advance (<= 125 us); the voices alone peak 1.9 dB over the render's median. The source is a 3.7 kW mean, 5.7 kW peak afterburn at 100 % duty (240 Hz bins, modulation 5x): the ~114 mg/s that burns would be ~400 J per 1 ms pop every ~80 ms if it accumulated, and it never does.
- One factor each, peak 11.3 dB at baseline: pockets at the unburnt zone's temperature 10.8; pockets born lit while the cylinder's flame burns at EVO 9.3 (both 9.3); ignition 950 / 1100 K 10.4 / 11.5, with lit pockets 9.4 / 9.0. Duty stays 100 % in all: every late-spark cycle's charge burns on its own, so nothing builds up. None kept.
- What a pop seems to need, not built: an overrun whose cylinder burns intermittently (stock-ECU closed-throttle partial burns), so unburnt charge collects over several cycles, then a fast burn of that collected volume. Not measured: any engine but the Lab Twin.

## 2026-10-24 — Backfires: a late spark and unburnt pockets, still short of a pop

- Owner: backfires only from the Audio workshop, off by default. `disableBackfires` clears them when an engine is switched, reloaded, saved, read back or compared; engine 16 and `physical-audio-lab.els` no longer switch them on. The workshop installs `late_spark_overrun`; the 2 Hz slugs and the anti-lag are no longer offered.
- Lab Twin, `AfterfireHarness --liftoff-rpm 6000 --audio`, overrun 38.4-40.9 s, 1 ms peak over the +/-1 s median (real pops 16-22 dB). Late spark alone, -20/-30/-40 deg: 7/25/35 % of the exhaust fuel burns, as a continuous afterburn; peak 8.5 dB, 0 pops. The model misfires 0 of 240 late sparks; COV 0.20 and a 622 degC wall (60 s warm-up) change nothing.
- Why: a ~0.25 m cell averages the cylinder's unburnt phi ~1.2 with the air the tailpipe draws in to 0.3-0.45, under the 0.45 lean limit. A 0.10 limit burns 67-71 %, a 50 mm mesh 92-97 %; both are continuous, 0 pops.
- Unburnt pockets (own composition and temperature, 10 ms mixing): 58-78 % burns, source peaks 55-73 kW, peak 11.3-11.5 dB, twice as often over 6 dB, 0 pops. The loaded part is bit-identical; the step costs 35 % mean against 34 %.
- One factor each, no gain: skipped sparks 0.1-0.5, flame contact between cells at 10/30 m/s, pocket-to-pocket ignition, 40 ms mixing (10.3-11.8 dB). A 0.3 ms reaction: +1 dB (12.3). Without the reaction voices: 11.6 dB, so they add nothing to the peaks, and the pockets' gain comes through the FV gas.
- Kept: late spark -30 deg and 10 ms pockets as the workshop profile. Removed: the skip and flame-contact knobs. Not measured: any engine but the Lab Twin (the CP2 included), the render against a recording by ear.

## 2026-10-24 — A backfire target from three real recordings

- Owner's go-ahead for the backfire work. Three CC0 Freesound recordings (`references/real-engine-audio/backfire-manifest.json`): a motorbike drive-by (Yoyodaman234, 12 pops), a large motorbike (mudflea2, 3), a car's anti-lag (modusmogulus, 34). New `scripts/pop_metrics.py` measures any file, real or rendered, the same way.
- A pop is a 1 ms RMS peak 15-18 dB over the +/-1 s median: an engine's own firing pulses stand 12-16 dB over it, so a lower threshold counts the firing (239 "pops" at 18-47 ms intervals on the drive-by).
- Energy share by band is the wrong metric: the real pops, like the engines, hold >95 % of their energy below 2 kHz (2-8 kHz 0.07-0.4 % of the files). So the 2026-09-23 "0.2-0.5 % between 4 and 8 kHz" was not by itself a sign of a missing crack. What differs is each band's rise over its own background.
- Medians, motorbikes / anti-lag: over the engine +15.8-17.1 / +21.7 dB; rise (10-90 %) 0.5-0.9 / 0.3 ms; decay to 10 % 1.0-1.1 / 0.4 ms; band rise 20-120 Hz +3-5 / +10, 120-500 +7-8 / +12, 500-2k +6-8 / +15, 2k-8k +3.5-5 / +3, 8k-16k +1-4 / 0 dB. The drive-by pops come in bursts 38-143 ms apart (p10-p50), the anti-lag 25-151 ms; none at a fixed 500 ms.
- Not known: rpm, distance, microphone gain; the previews are lossy transcodes. None is a CP2 or an overrun pop on a stock ECU.

## 2026-10-24 — Two-stroke cost: its pipes as networks of their own

- `RealtimeBudgetHarness --free-run` read every designed two-stroke "hold not stable": it cranked at the dyno's full throttle and they never caught (a binary without the idle limit did the same). It now cranks shut. Then (6-core desktop, free run, interleaved, min of three after a discarded run; control: a designed four-stroke twin, 3.05-3.07 throughout): single 2.7-3.1, twin 1.53, triple 1.30, V4 0.97 (slow motion), LS3 1.70.
- Profile (ninja-prof tree, `/Z7`): 78 % of the twin is `ExhaustGasNetwork::advance`; on the V4 the workers spin 73 % of their time, as the main thread runs the serial coupling between per-duct dispatches, one duct per atomic claim (a chamber cone is 2-3 cells).
- Bit-identical steps (`DynoSweepHarness` CSVs equal to HEAD's: twin, triple, RD350, LS3): one contiguous run of ducts per thread, triple 1.33 -> 1.41, V4 1.00 -> 1.06, LS3 1.70 -> 1.75 (two runs per thread gained nothing); a worker for a two-stroke twin, 1.53 -> 1.84 (a four-stroke twin lost 4 % with one, and keeps none).
- `PartitionedExhaustNetwork`: a two-stroke's unconnected pipes are networks of their own, each with its own CFL step, one per claim. Whole vs partitioned: twin 1.82-1.84 / 2.05-2.09, triple 1.37-1.40 / 1.62-1.67, V4 1.02-1.05 / 1.13-1.14, with three workers 1.24-1.28 (V4 sweep identical with two or three). Torque against `--exhaust-whole`: within 0.15 %, but -0.66 % on the triple at 2,500 rpm. LS3 identical to HEAD; four-strokes are never partitioned.
- `AudioRenderHarness`: 22 of 23 files byte-identical (CP2 included); the RD350 differs, level -0.02 dB, octave bands 22 Hz-22 kHz within 0.21 dB. Full `ctest` 92/92 (44 min).
- Near the limiter (`--relative-rpm 0.9`, audio 48 kHz and gas view): RD350 (the catalogue's only two-stroke) 1.30, twin 1.41-1.44, triple 1.09-1.12, V4 0.74-0.76 (0.82-0.84 without audio). The V4 left serially (`--intake-workers 0`): exhaust 65 %, its runners 7 %, the inline cylinder pass ~20 %. That pass is what the workers wait on, and making it concurrent changes `decoupleSharedVolumes`, a physics change; not done. Not measured: joined pipes (one part, so as before), any other machine.

## 2026-10-24 — Two-stroke idle: a dilution misfire limit, so it four-strokes

- Owner: a real two-stroke idles firing every 3-5 revolutions; the model fired every one. New instrument `PhysicsPerfHarness --idle-firing 20 --settle 8` (sparks lit, longest misfire run, Heywood diluent `1 - (O2/0.2095 + fuel)/total` at the spark). Before: two-strokes trap 0.72-0.87 diluent at idle and the twin, triple and RD350 light 100 % of sparks (the single and the V4 already skip 20-30 % on the AFR terms). Four-stroke idles: 0.21-0.35, Hayabusa and Flat-6 0.49, CP4 0.56.
- Nothing stopped them: the flame model only slows a diluted charge, and the misfire draw had AFR and cranking terms but no dilution term. Added: a smoothstep from 0.60 to 0.70 diluent, on top of the 0.92 cap.
- One factor, same binary, six designed two-strokes plus the catalogue. Onset/full 0.40/0.70: two-strokes 22-29 %, but CP4 0.78, Hayabusa and Flat-6 0.89 misfire. 0.60/0.85: 41-52 %. 0.60/0.75: 32-43 %. 0.60/0.70 (kept): 28-37 % (about one firing in three revolutions), idle 1,240-1,336 rpm, sd 37-92, lowest dip 806-1,152. 0.58/0.68: 26-35 %. Above a 0.58 onset every four-stroke row is identical to the digit.
- The onset is set against the model's most diluted four-stroke idle (CP4), not a literature limit. Homogeneous-charge limits are usually given lower (about 0.3-0.4, from memory of the textbooks; no page was checked), so the model's four-stroke idles are probably over-diluted; that was not looked into.
- `EngineLab.TwoStroke`: the RD350 idle lights 0.34 of its sparks and the CP2 every one; without the limit it lights 0.98 and the test fails. `AudioRenderHarness`: every file byte-identical, CP2 and the RD350 point included.
- Not measured: the idle sound against a recording, or a real engine's firing pattern (the owner's 3-5 revolutions is the only reference).

## 2026-10-24 — Two-stroke: cylinder-port intake, drawing, power valve, jets

- Intake as a choice: crankcase reed (default, solver path unchanged) or a cylinder port in series with the carburettor (zero while the skirt covers it), with or without a reed. `EngineLab.TwoStroke`, catalogue twin: delivery ratio at 8,000 rpm 0.88 reed / 0.50 a 110 deg port; 3,000 rpm, 190 deg port 0.88 with a reed / 0.69 without (blow-back). A port engine does not catch on a shut throttle at cranking (the window passes about half the idle air): the test cranks at 0.12. Idle sizing for it is not done (the idle pass is deferred).
- Drawing: exhaust from its window (the test fails on the old head stub), transfers in the flanks, round crankcase, power valve blade. Catalogue route check 11 / 4 / 0 / 44 / 7 (clashes 9 -> 11: the RD350's two chambers share a lane, tight bends 46 -> 44). The exhaust headers still loop: the shared exhaust router runs the trunk along the crank.
- Jets: a Mikuni 500 is a 173 hole at Cd 0.80, so the owner's 500 on a 38 mm carburettor is the Keihin 170-178 of a real 250 mono. The conversion is the model's own (its jet Cd); no maker's cross-reference table was checked against it. A new bore scales the main by the bore's square when the venturi follows the bore (`EngineLab.LiveIntake` fails without it).
- Not checked on screen (screen access declined): the power valve and port editors, the jets in holes. Not measured: the sound of either intake, a real port engine's curve.

## 2026-10-24 — Owner reports: V gearbox, two-stroke intake drawing, editors

- Gearbox: `EngineLab.EngineModel3D` now measures, across the crank, the gap from the drawn case to each barrel (top of the crank's sweep to the deck, a bore wide). Without the new turn the catalogue Big Twin-like V2 already fails at -16.6 mm (the test stops at the first failure, so the designed Vs were not read without it). With it (5 deg steps, downwards first, kept where already clear): Big Twin 22.0 mm; designed V2 90 deg 14.7, V2 45 deg 15.6, V4 65 deg 9.6, two-stroke V4 90 deg 9.5, I4 27.0; catalogue inlines and the RD350 25-36 mm (the turn leaves a case its own estimate finds clear where it was).
- Two-stroke intake drawn as built: transfer duct per cylinder (authored length, within 3 %), reed block, 25 mm manifold, carburettor, boot, one airbox of the authored volume. Catalogue route check 9 / 4 / 0 / 46 / 7 (tight bends 48 -> 46); the transfer duct is left out of the engine-solid check (it is cast in the barrel).
- The shared airbox moves every crankcase's intake mouth to its top; that placement only reaches the sound once the camera microphone moves. Not listened to.
- Editors (port timing and widths, compression ratio on every head, clutch capacity live): no automated test of the inspector, and not checked on screen. Clicking the carburettors: not checked on screen either.
- Left aside (they need measurements first): the two-stroke's cost, its idle firing every revolution.

## 2026-10-23 — Performance: a 4K window costs 1.3 cores and does not take the 2JZ below real time

- Hypothesis for the 14th-gen i9 report: a gaming PC's 1440p/4K screen. The app (VS tree, 6c90081+), 2JZ running free at 20 % throttle (~6,800 rpm), 30 s settle, then six alternating 30 s phases, window forced to 3840x2159 or 1600x900 (DPI-aware MoveWindow), engine started from its own buttons.
- Process CPU: 4.31-4.32 cores at 3840x2159 against 2.84-3.16 at 1600x900, every phase.
- Real-time factor 0.997-1.001 in every phase. Overruns per 30 s: big 4,946 / 4,701 / 4,660, small 4,560 / 3,385 / 3,646 (about +23 % at 4K). An overrun is any step finishing past its deadline, however slightly; the loop catches up, which is why the factor holds while over half the 240 steps/s count one.
- Ruled out on this machine (8 cores / 16 threads): the window's size taking the physics below real time. Not measured: the frame-rate cap (`frameRateCap`, 0 = unlimited) at 4K, a real 4K monitor (the window here is mostly off screen), a hybrid processor.

## 2026-10-23 — `UserDynoHighRpmStart` fails under CPU load, before and after the hybrid change

- Full ctest (VS tree, 39c1185): 90/91, the one failure the CP2 "crossed the running threshold during preparation" (minimum 508 rpm, recover 294). Alone: 18/18 pass, start 3,241-4,083 rpm (it is wall-clock paced, so not deterministic).
- With 16 busy-loop jobs on the 16 logical CPUs: 3/10 fail, the same signature (minimum 536-554, recover 293-294).
- Same load, Ninja builds of e1b2260 (before `ThreadScheduling`) and 9b882b1+, interleaved, 12 rounds each: base 1/12 fail, head 2/12, every failure min 549-553 / recover 293-294. Not separable at this count: the sensitivity predates the change.
- Cause: not the scheduling. The dyno runs in simulated time; only the moment the harness presses D is wall-clock (1 ms polling against a free-running runtime), so load picks the start state. From some states the sweep drops below `max(350, 0.55 x idle)` and the recovery re-prepares and drops again: 293 recoveries, no point, until the 90 s deadline (13 s against ~1 s for a pass). A user pressing D at that moment would hit the same loop. Open, not fixed (outside the mandate).
- After 6c90081: full ctest 91/91 in 32 min.
- Diagnostics rows checked on screen (Windows, 125 % scaling): 48.0 / 48.0 kHz, "any of 16, no throttling"; the callback load printed full precision (`juce::String(x, 0)`), now one decimal.

## 2026-10-23 — Performance: the audio device's rate

- The audio work scales with the device rate, and WASAPI shared mode offers only the mixer's rate (96/192 kHz on many headsets and DACs). `RealtimeBudgetHarness --with-audio`, 2JZ at 5,000 rpm, free-run, interleaved: audio load 21 % at 48 kHz, 41 % at 96, 90 % at 192 with ~180k dropped samples per run (INVALID).
- Fix: synthesise at the lowest whole fraction of the device rate >= 48 kHz and upsample (`IntegerUpsampler`, Kaiser polyphase, 48 taps/phase; image -106 to -129 dB, passband +0.0001 dB). 44.1/48 kHz devices take the old path unchanged.
- Equal 5.33 ms blocks (192 kHz/1024 against 48 kHz/256), 7 rounds: upsampled 192 kHz 22.2-22.8 % mean audio, all valid, factor 1.96-2.02; 48 kHz 21.2-22.0 %, 1.96-2.04; native 192 kHz 93.7-96.2 %, every run INVALID (175-183k dropped). The 48 kHz voicing's level at 192 kHz: -0.008 dB.
- Ruled out here: core count (the pool caps at 2-3 workers), the GUI (paced at 60 fps by default), the release build (same preset), the timer (paced 2JZ holds 1.000 with 1.4 ms max lateness on a 4.17 ms step).
- Not measured: the friend's device rate; whether the 192 kHz case alone puts a 14th-gen i9 below real time (the physics factor itself barely moves with audio: it is the sound that breaks up).

## 2026-10-23 — Performance on a hybrid processor (a 14th-gen i9 below real time)

- Report: the 0.3.1 zip falls below real time on a 2JZ on an i9-14xxx, while the Ryzen 7 8840U reference holds it. The zip is built with the same preset and Release config as the reference tree; the cylinder pool is 2-3 workers whatever the core count, so many cores do not dilute it.
- Mechanism (not measured, no hybrid machine here): the pool's barrier waits for its slowest worker, and Thread Director steers a `pause`-spinning thread to an efficiency core; Windows 11 also puts an app it judges in the background under EcoQoS.
- `ThreadScheduling.hpp`: process and threads opt out of power throttling; the physics thread and the workers are held to the fastest CPU-set class when there is more than one (nothing restricted on a uniform CPU; unit-tested on recorded topologies).
- `RealtimeBudgetHarness --free-run`, 2JZ at 5,000 rpm, interleaved, round 0 discarded, rounds 1-7: base (the 2026-10-22 knock tree with Woschni's term, not the one merged) min 2.154 / median 2.190; with the change 2.160 / 2.186 (neutral); with `--power-throttled` 1.287 / 1.296: EcoQoS alone costs 41 %.
- Not measured: the fix on a hybrid processor; whether the i9 was under EcoQoS (window hidden or unfocused) or on E-cores.

## 2026-10-23 — Editing on the engine: checked on screen (Linux, Xvfb)

- Compression ratio on a 2JZ piston, 8.7 -> 9.5 by the stepper: taken live (the engine shows modified, the field reads it back). `LiveCylinderResize`: K20A +1.5 held at 60 % redline settles like one built so, with more torque.
- Aircooled flat six, *Joined* on its exhaust ports: one path, six primaries into one collector, one tailpipe; it idles at 744 rpm. The ports are one part for all cylinders (no cylinder to name a path), so the first path is offered the next.
- The designer window (built 2026-10-19), first time on screen: it works. Fixed: the names' column was headed "Value" and the values' none; the name stayed "Inline Seven" for any engine. Not fixed: a two-stroke lists "Valves per side" and "Injector flow", which it does not use.
- Designed two-stroke twin (64 x 54): its real-time check failed ("did not hold 5000 rpm; mean 673"): cranked at full throttle, a carburettor's pilot is dead and its venturi draws nothing, so it never catches. The probe now cranks shut until it runs (<= 5 s simulated): 1.90 x real time here (test fails without, 1,397 rpm mean).
- The same twin catches only after ~3.1 s of cranking at closed throttle (lambda 6.8 -> 1.4 first), against ~1 s for an injected engine. A real cold two-stroke is started on its choke, which the model has not: not changed, recorded.
- Carburettor jetting live: main #288 -> #431 at ~5,800 rpm full throttle, lambda 0.80 -> 0.53. Its injectors were still drawn (and offered) on a carburetted engine; both removed.

## 2026-10-23 — Performance: what this Linux box can and cannot say

- Refuted: whole-project link-time optimisation (`CMAKE_INTERPROCEDURAL_OPTIMIZATION`, GCC 13): bit-identical CSVs; CP2 sweep 6.65 -> 6.42 s best of 3, LS3+K20+Hayabusa 40.8 -> 39.1 s, within the run-to-run spread (39.1-42.1 for both).
- Test duration is simulation CPU: 3,485 s of tests packed into 1,742-1,803 s at `-j 2`, the ideal. The ten slowest (IdleStabilityRegression 382 s, LiveCylinderResize 274, IntakeTuning 258...) are half of it; splitting them cannot help at two-wide.
- Designed 6 L V12 (`PhysicsPerfHarness`, one run): 2,256 / 4,580 / 7,129 us per 240 Hz frame at 990 / 4,345 / 7,110 rpm (budget 4,167). perf: 24 % self time in `CylinderWorkerPool` workers plus 6.5 % in `attachNetworkParallelFor` (spin, then yield, then park, by design); FV duct + Riemann + primitive recovery ~14 %; `pow` 3 %.
- Not changed: the pool's spin/park balance and the duct numerics. Both move the real-time factor, which is valid only on the reference Windows machine, interleaved (`.claude/CLAUDE.md`); Linux scheduling differs by construction.

## 2026-10-23 — Build: JUCE compiled once

- JUCE's modules are interface libraries carrying their sources, and `EngineLabAudio` linked four of them PUBLIC: every executable that linked audio compiled JUCE again (6 units each, 15 for the app); 130 of the tree's 390 compile units were JUCE.
- `EngineLabJuce` (top-level `CMakeLists.txt`) links every module PRIVATE and re-exports their include directories (as SYSTEM) and definitions; all targets link it.
- Linux, 4 cores, clean configure + build at `-j 4`, `linux-gcc-release` flags: 14 min 46 s wall / 53 min 40 s CPU (390 units) -> 6 min 08 s / 20 min 50 s (255 units). Full ctest green on the new tree.
- Profile of a CP2 dyno sweep for the next step: `pow` 9 % (open ends, `GasCell::dynamicPressureKpa`, valve fluxes), the FV duct (cache, Riemann flux, primitive recovery) ~20 %. Not changed: each costs bit-exactness.
- CI, Build step: Linux 17 min 47 s -> 4 min 33 s; Windows 25 min 21 s -> 32 min 05 s: MSBuild compiles one project's units in series and CI runs two nodes, so the one JUCE project sits on the critical path. `/MP2` on that project failed the build with C1060 (out of heap) on two harnesses beside the app's LTCG link: reverted. Not measured: a local many-core Windows build, where JUCE no longer compiles ~20 times.

## 2026-10-23 — Two-stroke: a power valve

- Added: `two_stroke.power_valve_*` (the exhaust's opening with the valve shut, the speeds it lifts between, 0.25 s servo lag); the port's roof and so its area follow the valve. The designer fits one to sport designs: 12 deg later shut, lifting from 65 to 90 % of peak power speed.
- Designed t2_twin_500 (EPO 82), DynoSweep step 250 / settle 8, valve shut at 90 / 94 / 98 deg (5,500-7,500 rpm): +18-29 % / +22-39 % / +24-47 % over 3,000-5,750 rpm, within 1 % from 7,250 up; 2,000 rpm -4 / -7 / -9 %. The designer's (94, 5,031-6,966): 34-42 N.m from 2,000 to 5,000 rpm where the valveless port gave 29.5-37, top end unchanged, held within 1.5 rpm.
- Found on the way: the JSON reader dropped `scavenge_loop_length_ratio`, so a saved two-stroke lost an authored loop length and came back at the default 1.8. Fixed and tested.
- Not measured: a real YPVS engine's curve against the model's (no data here); the sound; the RD350LC keeps no valve, as the LC had none.

## 2026-10-23 — Two-stroke: the 3,500/7,000/7,500 rpm holding band is the 240 Hz frame's alias

- Designed t2_twin_500 (sport, 0.5 L), DynoSweep step 250, settle 8, with a new `--frame-hz`. `held_rpm_stddev` at 240 Hz: 3,500 2.3, 7,000 6.6, 7,500 2.6, elsewhere 0.2-1.1; at 300 Hz the three are gone (0.2-0.4); at 200 Hz the band moves to 5,750-6,250 (2.7-3.1), where the twin fires at 200 Hz. A twin two-stroke fires at 233 Hz at 7,000 rpm, 117 at 3,500, 250 at 7,500.
- Mechanism: `EngineState::rpm` is the speed at the frame's end, with the firing ripple in it (+-50 rpm here). Sampled once a frame it beats at 6-7 Hz, which the absorber's 8 rad/s filter passes in part: the brake swung 40-58 N.m with the alias. Spark, AFR and trim were steady, so the engine itself held.
- Fix: the simulator publishes `frameAveragedRpm` (crank travel over the frame) and the absorber holds that. 240 Hz after: 3,500 0.2, 7,000 0.3, 7,500 0.2; torque within 1 %. Left: 1.4-1.8 rpm at 5,750-6,000, present at 200/240/300 Hz alike, so the engine's own.
- Not measured: the application's continuous-ramp dyno, which reads the same controller; Windows.

## 2026-10-23 — Two-stroke idle: the governor's gains halved; designed carburetted engines idle

- RD350 (injected) free idle, std over 16-40 s: the idle gate failed on drift 66 rpm (baseline 64.4, gate 65): a 5 s limit cycle, trim 0.68-1.16, air per cycle 34-49 mg. No end-gas event in it (the old model had 4).
- Lambda trim gain x0 / x0.5 / x1 / x2: std 165 / 125 / 66 / 16: the trim damps the hunt, it does not make it. The cycle-correct trim gain (360 deg, half the speed) made it worse (std 69, drift 78): not kept.
- Governor P,I x0.5: std 13.6 (trim on), 15.8 (trim frozen); D x2 helps only with the trim (16.7 vs 152). Kept for two-strokes: idle gate std 13.4, drift 0.8; WOT-blip recovery settles at 1,489 rpm (was 1,336).
- Designed carburetted 2T (sport, 54-64 x 54 mm): the 1-, 2- and 3-cylinder designs do not idle; the 4-cylinder idles 1,131 rpm, std 31. The twin's pilot meters ~AFR 7 against the air its bypass can pass (it is sized for an idle delivery ratio of 0.35); `airFlowGramsPerSecond` reads trapped mass x cycle rate, ~4 g/s of a misfiring charge, not throttle flow.
- Sizing the pilot from the idle path's air at the governor's neutral 0.42 alone: the twin cranks at AFR 30-100 on the 0.88 post-start air and never fires. With the pilot also following the idle path's opening (progression holes), the bypass per carburettor at 18 mm2 per litre of its cylinder (a four had 6.25 each) and the pilot factor refitted 0.14 -> 0.026 (RD350 #35): designed 1/2/3/4-cylinder engines idle 1,310/1,303/1,303/1,302 rpm, std 73/26/20/18, pilots #25/35/35/35. The rig's RD350 idles at delivery ratio 0.041.

## 2026-10-23 — Knock: Douaud-Eyzat's prefactor doubled; Woschni's combustion term backed out

- Linux, `linux-gcc-release`. The 2026-10-22 knock work failed 8 ctest gates its baseline (91c04d3) passes. Ablation by switches, one ingredient each.
- Woschni's combustion term plus the 4V/B liner stalled the RD350's standing start (min 552 -> 260 rpm), the lugged I4 of CombustionPhasing and moved CameraMicrophone's click metric; either one off fixed them. Backed out with the TDI refit it forced (280 mm2, 0.028 law): still the TDI's 171 g/kWh, an open lead.
- I5 at 2,000 rpm, 2.48 bar, map 8.7 deg, control off: CA50 ~8 ATDC, end gas 955-965 K at 96-100 bar, 13-33 % unburned at onset, tau 0.37 ms. Seal 377 K at 2.28 bar, manifold 64 degC: plausible inputs.
- Retard held behind the map (8 engines, 2-9.5 krpm): x1 delay K20 7-12 deg, LS3 5-9, 2JZ 5-12, EJ25 10-12, I5 saturated; x2: NA 0-2, 2JZ 0-4.6, EJ25 0-5.4, I5 8-13 at light knock; x3 all ~0. Same with Woschni off. Kept x2 (35.4 ms): a production map sits 0-3 deg from its limit.
- x2, control off: map clean; +5 deg light (K20 0.28 at 3,500); +10 deg K20 0.23-0.39, 2JZ 0.80 at 5,000 (all frames heavy).
- KnockControl/LiveTuning now advance the 2JZ map 8 deg to reach a limit. CatalogPhysics' absorber stopped at 25 bar BMEP, below the I5's ~26: now 35 bar, gains x25/35.
- Sources reachable here are search snippets only: Chen et al. 2014 (D-E ignores EGR and lambda), an Energy & Fuels study, doi 10.1021/acs.energyfuels.4c04775 (D-E over-predicts knock as intake pressure rises). Not measured: the sound; Windows.

## 2026-10-22 — Knock: the end gas, a stepped control, Woschni's combustion term

- End gas as its own zone from the seal, isentropic with real cp(T); Douaud-Eyzat delay; Livengood-Wu from the spark; intensity = the constant-volume pressure the unburned share adds, over 30 bar. ECU knock control now steps (20 x excess/s of a 12 deg authority, ~1.3 deg per heavy event, back at 1 deg/s).
- 2JZ at full load, control off: knock 0.83 mean, damage 0.0065; on: 0.08 mean at 4.7 deg, no damage. Catalogue WOT: NA engines at most 0.10, 2JZ <= 0.08, EJ25 0.40 at 5,000 rpm.
- It took three more changes: the flame's load term capped at 1 (boost burned a charge up to 36 % faster); intercoolers 0.7 on 2JZ/EJ25/I5; Woschni's combustion term and the 4V/B liner (TDI BSFC 171/181/199 -> 212/203/215 g/kWh at 2/3/4,000 rpm; petrol WOT 227-310). TDI throat 280 -> 220 mm2: 285 N.m at 2,000 rpm.
- Maker gate (before the TDI refit): all pass but the TDI at 2,000 rpm; 2JZ +9.6 %, EJ25 +12.8 %, I5 +7.0 % torque.
- **Open: the model over-knocks under boost.** Implied knock-limited spark vs calibration practice: ~6 deg early NA, ~11 at 1.9 bar, ~17 at 2.45. The I5 knocks 0.78-0.90 at every rpm with the authority saturated, 0.56 at 2,000 rpm at the -10 deg floor; at 2.3/2.2/2.1 bar still heavy (2.1: 0.47-0.83); direct injection (end gas -15 K) and CR 10 neither cure it.
- Refuted: Kalghatgi's octane index (the zone is 150-200 K colder than his K fit, boost gains 1-3 octane); an ECU boost cut on knock (I5 155 kPa / 363 N.m).
- Leads: the intensity scale (constant-volume rise vs MAPO, a load-scaled threshold); Douaud-Eyzat used at 90-100 bar onsets, beyond its fit; the DI preset going lean above 5,000 rpm (lambda 1.07-1.18); the RD350's 437-1,582 g/kWh.
- Not measured: the sound before/after; CatalogReference and CatalogBoostHold after the TDI refit; the full ctest.

## 2026-10-22 — Two-stroke: a carburettor, and the bore it sits in

- Added: a slide carburettor per intake path (`CarburettorModel`), two circuits on their own depressions -- the main on the venturi's 1/2 rho V^2, the pilot on the bowl-to-crankcase drop -- with jets in their stamped numbers (cc/min under 1 m of head). Its fuel enters the crankcase with the air; the injector is commanded nothing on a carburetted path. The designer fits one to every two-stroke and sizes the jets from the engine: an RD350-sized design gets #287 main / #41 pilot against the bike's 260-290 / 30-40, fitted to neither.
- **A bore bug, found in passing.** A two-stroke's carburettor was sized from the whole engine's displacement and fitted to each cylinder, so `t2_single_125` (16.6 mm) and `t2_four_500` (33.2 mm) were four times apart in area for identical 125 cc cylinders. Now sized per cylinder, with the factor doubled (0.16 -> 0.32) so the RD350-calibrated twin stays at 26.186 mm: every 125 cc cylinder gets 23.45 mm, every 250 cc one 29.60 mm, and both twins are bit-identical by construction.
- Three-way sweep, one factor between each pair (A committed, B bore fix, C B plus carburettor), seven designed two-strokes, 250 rpm steps, 8 s settle. Arm A reproduces the previous entry's roughness to the digit, and the four-stroke control is bit-identical across all three.
- Bore fix, peak torque: the singles gain (125 cc +29 %, 250 cc +18 %) and the multis lose what the oversized bores gave them (triple -6 %, four -9 %, V4 -8 %). Roughness moves both ways (125 cc 1.76 -> 1.40, four 0.97 -> 1.60).
- Carburettor: lambda 0.88-0.94 -> 0.74-0.84, falling steadily with rpm (twin 0.837 at 2,000 -> 0.768 at 9,000). That is the plain jet richening with flow, i.e. the deliberately absent air corrector, now measured. Peak torque -4 to -6 % and roughness +0.13 to +0.35 points on all seven. The 3,500/7,000 rpm holding band is where it was in all three arms (t2_twin_500 at 7,000: 5.7 / 5.7 / 5.8 rpm), so neither factor touches it.
- **Three refutations of that roughness, all mine.** (1) The pilot: shut to #1 it moves lambda 0.768 -> 0.784, 2 % of the fuel. (2) The rich mixture: the main jet x0.90 brings lambda to 0.89-0.94, the injector's own, and the roughness stays (twin 1.91 -> 1.94, triple 2.16 -> 2.38) with 2.5-4 % of torque still missing. (3) Mixture noise: lambda is *smoother* with the carburettor on six of seven (0.11-0.16 % against 0.13-0.17 %), an order of magnitude below torque's.
- So at equal lambda it is putting the fuel in the crankcase rather than the transfer duct that costs 2.5-4 % of torque and ~0.3 points of roughness. Unverified candidate: fuel vapour changes how the crankcase pumps (the triple's delivered-VE roughness rises 1.85 -> 2.34 with it). The larger part, the 1.4-2.1 points the injector arm already had against a four-stroke's 0.32, is not the fuel system.
- A gauge bug of mine fixed: `fuel_g_s` counted the injector only and read 0.000 with a carburettor fitted. Rerun on the fixed binary it is the only column that moves (now 1.4-4.0 g/s on the twin against the injector's 1.6-3.9).
- Not measured: the sound; a real carburetted two-stroke's curve or AFR trace; the catalogue RD350 on a carburettor (it keeps its injector so the reference engine does not move); reed and power valves.

## 2026-10-21 — Two-stroke: integrating the scavenging front, and what the numerics do not own

- The fix for the hunting the one-shot sample caused: the front's progress is integrated every sub-step, `frontProgress += jetVelocity x dt / loopLength`, instead of a transit time predicted from the jet velocity at the instant the transfers crack open. Three-way sweep (model off / one-shot / integral), eight designed engines plus the catalogue RD350, 250 rpm steps, 8 s settle.
- **The hunting is gone.** Mean `held_rpm_stddev` over 4,500-6,250 rpm, one-shot against integral: RD350 5.06 -> 0.48 (model off 0.43), t2_twin_347 4.27 -> 0.49, t2_triple_750 3.31 -> 0.40, t2_v4_1000 3.17 -> 0.33, t2_four_500 1.67 -> 0.26, t2_single_125 3.27 -> 0.72. Worst single point 10.05 -> 2.50 rpm. The integral sits on the model-off floor everywhere.
- **And the curve is smoother than with the model off**, which neither earlier variant managed. Roughness off / one-shot / integral: RD350 5.74 / 6.34 / **1.44**, t2_v4_1000 2.23 / 4.97 / **1.92**, t2_single_250 2.62 / 4.01 / **1.95**, t2_twin_500 2.71 / 3.77 / **1.91**, t2_four_500 1.13 / 2.52 / **0.97**. It beats the shipped model on all eight two-strokes and model-off on seven of eight (t2_single_125 1.76 against 1.72 is a tie).
- Torque: the designed engines gain 2-14 % and keep it (t2_twin_500 +7 %, t2_v4_1000 +9-14 %, t2_single_250 +8 %). The catalogue RD350 is the exception and **loses 12 % of mean torque** (29.68 -> 26.77 N.m): trapped VE falls below 8,000 rpm and rises above it, so the hole at 5,750 rpm disappears and the curve becomes a monotone rise. That is a deliberate behaviour and sound change on a catalogue engine, peakier in the direction a tuned two-stroke should be, but it is not validated against a real RD350's curve.
- Two controls, both held: a ratio-0 two-stroke run is **bit-identical** to the shipped ratio-0 run, and the four-stroke from the same derivation is **bit-identical across all three variants** (roughness 0.32, peak 78.9 N.m @ 4,251). So the rewrite reaches only the scavenging window.
- **The 3,500 / 7,000 / 7,500 rpm holding failures are the plant, not the numerics.** Five runs of t2_twin_500 with the model off, one factor each: `held_rpm_stddev` at 7,000 rpm reads 5.62 (settle 8), 6.16 (settle 16), 5.93 (step 125), 5.81 (crank 1 deg), 5.57 (coupling 60 us). Halving the step also finds 5.29 rpm at 7,376, so it is a band. The brake swing there is not the speed error: 5.6 rpm x the 0.166 N.m/rpm P gain is 0.9 N.m against 14.7 N.m measured, so the engine's own cycle-averaged torque swings about 15 % at a steady hold and the absorber only follows it.
- Two convergence costs the same probe exposed, for the performance pass: **the 2 deg crank step is 10.5 % off at 2,000 rpm** (35.70 -> 31.94 N.m at 1 deg, 6.6 % at 2,250, under 1.5 % from 4,000 up), and **the 125 us exhaust flush clock costs 2.5-4.7 % of torque around the power peak** (6,000 rpm 40.40 -> 42.28 at 60 us). Neither is a bug; both are what the real-time budget buys.
- **Refuted: the 3,500/7,000 rpm band is not the exhaust pipe's.** Same engine at 0.87x, 1.00x and 1.15x of the designer's 947.5 mm tuned length, 125 rpm steps. The torque peak moves as it should (7,375 -> 7,000 -> 6,000 rpm), so the length took effect, but the scatter stays at 6,997/7,000/7,000, 7,375/7,375/7,373 and 3,500/3,502/3,499 rpm. It is locked to crank speed, with 3,500 and 7,000 exactly 2:1, and survives pipe length, settle, step, crank step and flush clock. Untested candidates: the intake side (runner, crankcase, throttle plenum -- the one part held fixed in every probe), and the constant-power accessory term faded in over exactly 3,500-4,500 rpm at `EngineSimulator.cpp:5000`, whose torque falls as 1/omega and is therefore negative damping.
- Not measured: the RD350's changed curve against a real one; the sound; the intake-side probe for that band; a carburettor; MBT calibration.

## 2026-10-21 — Two-stroke: the mean is smooth while the engine is not, and the scavenging model is half the chaos

- Every "is the curve chaotic?" judgement so far read `torque_nm`, the mean over the sample window. `brake_nm_min`/`brake_nm_max` and `held_rpm_stddev` are accumulated only after the settle, so they say whether the settled engine **held**. Brake-torque spread is the wrong one of the two: a twin's within-cycle crank ripple inflates it (the four-stroke control reads 26 % spread at 3,500 rpm with 4.1 rpm of filtered-speed scatter, which is a healthy engine). `held_rpm_stddev` already has the ripple filtered out by the absorber's own 8 rad/s filter, so it is the holding metric.
- **Refuted, mine:** "3,500 and 7,000 rpm are bad on every engine, four-strokes included, so they are a fixed-rpm artefact of the harness." Measured on the filtered speed, the four-strokes are clean at both (0.88-1.14 rpm at 7,000, against 5.5-8.4 for the two-strokes) and 3,250-3,500 is the scavenging model, not the plant. Only the 7,000 rpm point survives as plant: RD350 reads 8.08 rpm with the model off and 8.39 with it on, same torque and same VE, while its neighbour at 7,250 is the cleanest point of the sweep (`rpm_stddev` 2.5 against 44). Not the absorber (no rpm-locked structure in `DynoAbsorberController`) and not an ignition node (the designed map is flat 20 deg from 1,720 to 9,030).
- One factor over the eight designed engines, `scavenge_loop_length_ratio` 1.8 against 0, same binary, 250 rpm steps, 8 s settle. The four-stroke control is **identical to the digit** (roughness 0.32 %, spread 7.3 %, peak 78.9 N.m @ 4,251 both), so the knob reaches two-strokes only.
- The model **doubles** mean-curve roughness on every two-stroke: 2.52-4.97 % against 1.13-2.71 % with it off (+1.06 to +2.73 points). A four-stroke from the same derivation is 0.32 %, so the model owns about half of the designed two-stroke's roughness and the geometry owns the other half.
- Its whole effect is one band. Outside 4,500-6,250 rpm torque and VE are unchanged to three decimals (±0.5 %); inside it torque rises 12-27 % and `held_rpm_stddev` goes from 0.2-0.9 rpm to 3-9.6. That band is the pipe's antiresonance (t2_triple_750 VE 0.453 -> 0.399 -> 0.568 with the model off), and the model fills it: 0.399 -> 0.505 at 4,750 rpm, 46.3 -> 59.0 N.m, scatter 0.44 -> 9.55 rpm.
- Which says what the instability **is**, not just that it exists: only in the trough does the front stop short of the exhaust port, so `frontProgress` sits on the steep middle of the ramp where a small change of crankcase-to-cylinder pressure swings trapping hard, and the cycle-to-cycle loop through the exhaust pipe closes there. Elsewhere the ramp is saturated and insensitive. So the shipped one-shot sample is a sufficient cause but may not be the only one, and the integral-front rewrite has to be measured against the holding columns, not the mean.
- Not measured: whether integrating removes the hunting or only halves it; the ramp width as a second factor; the 7,000 rpm point's mechanism; anything on sound.

## 2026-10-21 — Two-stroke: the product's own dyno is not where the chaos is

- The complaint is about the product's dyno, not the sweep, so `EngineLabDynoRuntimeCurveHarness --mode ramp` was run on the shipped build (25 mm clamp restored, idle host) for the catalogue RD350 and a CP2 four-stroke control. RD350: 145 points, 1,800-9,000 rpm. CP2: 155 points, 1,800-9,500.
- **Refuted, mine:** "a ramp measures while accelerating and `DynoQualityGate` accepts 150 rpm of speed error and 3x the ramp rate, so the two-stroke's accepted points scatter." **Every point of both runs is valid and `quality_reasons` is 0 on all 300.** The gate rejects nothing, so it is not filtering a scatter into existence and not letting one through by a loose tolerance either.
- The two-stroke *is* measurably noisier in the product's own instrument, but by a margin nobody would call chaotic: second-difference roughness **0.71 % against the four-stroke's 0.09 %**, per-point torque variance **3.28 against 0.105 N·m²** (31x), max step 1.65 against 0.54 N·m. Window rpm spread and accepted cycles per point are the same for both (129/119 rpm, 11.8/12.3 cycles), so the controller is holding the two-stroke as well as the four-stroke.
- So neither instrument reproduces the complaint on the **catalogue** engine: sweep 1.58 %, ramp 0.71 %. What the owner's words actually say is "whatever 2T engines **I design**" — the designer's derivation, not the hand-authored RD350, and no two-stroke measurement this session had touched it.
- `EngineLabDesignBench` was written for exactly that: it runs `designCatalogueEngine` over a spec file and writes the results as a catalogue the sweep can measure, so a designed engine is now a first-class measurement subject. Eight designs (125-1,000 cc, 1-4 cylinders, inline and V, plus a four-stroke control from the same derivation) came out with nothing clamped — tuned lengths 840-1,055 mm inside the [500, 1800] range, redlines 8,600-10,800 from the 17.5 m/s piston-speed rule.
- Not measured yet: the sweeps of those eight, running. The ramp also stops at its accepted ceiling (9,025 rpm here), so its 36.52 N·m peak at 8,900 is a transient reading below the sweep's 41.25 at 9,751 and the two numbers are not comparable.

## 2026-10-21 — Two-stroke: the mesh converges at 12 mm, and production is 18 % below it

- Peak torque against exhaust cell length (probe-r18, step 250 / settle 8): **23.20@6,252 / 34.32@9,251 / 39.10@9,751 / 41.25@9,751 / 41.67@9,751 / 41.52@9,751** at 200 / 100 / 50 / 25 / 12 / 6 mm. It **converges at about 12 mm** — 12 against 6 mm differ by 1.47 % of mean torque and −0.36 % on the peak. Production for a two-stroke is 100 mm (`productionExhaustCellLengthM`, confirmed bit-identical to an explicit 100 mm run), so **production sits 17.6 % below the model's own converged answer with its peak 500 rpm low**. 25 mm is within 1 % of converged.
- Torque rising monotonically with refinement is numerical diffusion smearing the blowdown front, which weakens the reflected plugging wave. **Roughness moves the other way** — 2.55 / 3.41 / 6.19 / 6.34 / 7.08 / 7.59 % from 200 mm to 6 mm — so a coarse mesh *smooths* the curve. Mesh aliasing is therefore **not** the "chaotic curves" complaint; production gives the smoothest curve of the set.
- **Trap, and it cost a measurement of mine:** `--exhaust-cell-mm` saturates. `buildPhysicalExhaustNetwork` clamps the target to [25, 600] mm, so a 12 mm request became 25 mm and the two runs came out **bit-identical on all 42 rows**. The clamp was lifted to 4 mm locally for the study above and **restored before anything else was measured**; nothing of it is committed. 4 mm is unreachable anyway — the per-duct cap saturates silently at 75 cells against a limit of 64.
- Separating the two defects this leaves: at convergence the **magnitude is right** (41.5 N·m against the maker's 40.2, +3 %) but the **peak is 1,750 rpm high** (9,751 against 8,000). So geometry/wave timing owns the position and the mesh owns the level. The implied wave speed at the measured peak is `12 x 0.940 x 9,751 / 196` = 561 m/s where the gas there supports 510 — the model's return is about 10 % early, which is the next single factor for position.
- The level defect is **a real-time budget problem, not a physics one**: the code comment on `productionExhaustCellLengthM` records that 100 mm is the finest mesh that ran in real time on the reference machine and that 75 and 50 mm did not (journal 2026-10-15). Two-stroke torque accuracy is therefore gated by solver speed, which makes the performance pass the unlock for two-stroke accuracy rather than a separate errand.
- Not measured: the owner's actual instrument. The sweep is 1.58 % jitter at this step and settle, so the "chaotic curves" complaint lives in `DynoMode::continuousRamp`; `EngineLabDynoRuntimeCurveHarness --mode ramp` on the two-stroke against a four-stroke control is next, on an idle host with the shipped clamp restored.


## 2026-10-21 — Two-stroke: the exhaust chamber owns the curve's shape

- **Both torque humps are the pipe's**, measured by scaling the tuned section alone (stinger, muffler and outlet held, so back-pressure does not move), 42 rows each: at x1.088 the pair 7,245 / 9,751 becomes **6,750 / 9,001** — 9,001 against 8,964 predicted by 1/L, inside one 250 rpm step — and at x1.300 the two merge into one peak, 54.99 @ 7,001, collapsing violently after it (15.39 by 8,251). So the **8,252 trough between them, exactly where the real engine peaks, is the chamber's own wave structure.** Magnitude at the stock 940 mm is right (41.25 against the maker's 40.2) and the longer pipes are overpowered (+33 % at x1.300): lengthening is not the fix.
- **Refuted, mine:** "the designer's `a = 500 m/s` (`EngineDesign.cpp:706`) is too slow for the solver's pipe, so every designed two-stroke peaks high." The 469 °C behind that came from the wrong operating point. Measured egt across 7,000-9,000 is 345-365 °C ⇒ c = 486-493 m/s, so the authored 940 mm tunes to **8,436-8,570 rpm** — exactly the 8,500 the engine file intends. Blair's figure and the designer's rule are both right.
- **Refuted, mine, within the hour:** "there is one resonance, and the 9,751 hump is trapping overtaking falling delivery, not a pipe feature." The length probes move it as 1/L. The error was reading the delivery hump off `max(delivered_ve)`, which selects the lugged 2,000 rpm through-flow (1.43) rather than the mid-range resonance. Trapping *does* rise monotonically 0.448 → 0.843 and that is still unphysical at the top, but it is not what places the peak.
- A real expansion chamber gives **one broad power band**. Two sharp humps with a trough between, both scaling with length, is the diffuser's rarefaction and the baffle's compression arriving as separate sharp events instead of blending. The quasi-1D cone itself is genuine (`DuctGeometry::faceAreaM2` lerps the radius per face, so a taper is a varying-area duct, not a point step).
- Next single factor, running: the **mesh**, already suspect at 34.00 / 36.26 / 38.18 N·m for 100 / 50 / 25 mm with 25 mm called not converged. 50 and 12 mm on the identical catalogue, step 250 / settle 8. If the humps merge and the trough fills as the mesh refines, the structure is discretisation; if they sharpen, it is the model's physics.
- Not measured: whether the real engine's single band is reproducible at any mesh, and any listening on these geometries.

## 2026-10-21 — Two-stroke: a scavenging model that fills one hole and cannot touch the other

- The cylinder was perfect mixing *by construction* (two orifices onto one well-mixed cell), so trapping had no engine-speed term. Replaced by a loop-scavenging law (`TwoStrokeScavenging.hpp`): a per-window **state** whose displacement phase lasts until the fresh front crosses the cylinder, raced against the port window — the front needs `scavenge_loop_length_ratio` x bore over the transfer jet's velocity, the window lasts `duration / (6 x rpm)`, and the breakdown then establishes over one further transit time. Two measured times, no fitted constant.
- The bias goes on the **composition the exhaust port offers the 1-D network**, not on the port areas. The network reports back exactly the species masses it took and the cylinder is debited the same ones, so species, mass and energy conserve for any composition presented. The energy density is passed through untouched: pressure and temperature drive the flow, and this model says what the gas leaving *is*, not how much leaves.
- **One-binary A/B** (`scavenge_loop_length_ratio` 0 vs 1.8, same build, 42 rows, step 250 / settle 8 / 25 mm): mean **+2.22 %**, max **+26.2 % at 5,752**, concentrated in 5,001-5,752. It fills the antiresonance measured there: **23.05 → 29.09**. Below 3,251 and above 6,998 the curve moves less than 1 % (at 2,000 rpm, −0.34 %). Peak torque is **unchanged: 41.23 → 41.25, both at 9,751** — so it does not address the owner's complaint, and the entry above says what does.
- Band-limited for a reason, not by a tuning: the displacing share is `transit/window` = 0.10 at 2,000 rpm (so mixing covers 80 % of the window and there is almost no bias — which is why the low end is untouched) and 0.48 at 9,751, where trapping is *already* 0.83 and the `min(shortfall, residual)` cap binds. You cannot displace with gas the cylinder no longer holds. The effect lands where both a long displacement phase and spare residual exist.
- Controls, all on this build: four-stroke **provably untouched** (EJ25/CP2/LS3 torque and egt identical to 0.0000, audio render bit-identical on every four-stroke — structural, since a four-stroke never opens a window and its boundary returns `networkStateForGasCell` on the helper's first line); a free idle is **neutral** (1,312.4 rpm mean with the loop against 1,305.5 perfectly mixed, spread 38.3 against 39.2, target 1,300 — the 752 and 1,134 rpm idles reported earlier today were the refuted window-width variant); `ctest` 89/89 green. The only sound that moved is the RD350's own (resonance 17.3 dB@1312 Hz → 24.9 dB@335 Hz, rms 0.0079→0.0108), unlistened.
- **Refuted, mine:** "a delivery ratio above one is an internal contradiction." It is not. The crankcase's clearance volume is 2.86 swept volumes and is partly emptied and refilled every cycle, so its ceiling is ~3.9, not ~1.0. A wide-open two-stroke at 2,000 rpm really does blow air straight through — that is why it is filthy there — so `delivered_ve` 1.44 *with* trapping 0.45 was the sound pair all along.
- **Refuted, mine:** ramping the breakdown over the **remaining window**. It over-trapped the low end (48.8 N·m at 2,000 rpm, trapped ve 1.088 with the pipe at only 114 kPa, so no plugging to justify it). At 2,000 rpm that window is 10.7 ms and 90 % of it was given a gentle ramp where a through-flowing cylinder is fully mixed or worse. The transit-time width measured above is the one kept.
- A bug of mine, caught before it reached a measurement: `transfer_port_open_deg` is the angle the piston uncovers the port, not the duration (`2 x (180 - angle)`). A 5 % short window; now `portOpenDurationDegrees`, asserted with the ordering it fixes (exhaust 82° opens first and runs 196°, transfers 116° run 128°). A *larger* opening angle is a *shorter* window.
- Not measured: a descending sweep against the wall-heating confound, and whether the exhaust chemistry refuted earlier today behaves differently on top of this.

## 2026-10-21 — Two-stroke: the pipe never burns, and un-gating it is not the fix

- The RD350's chaotic curve was measured before it was touched: at step 250 / settle 8 the harness curve is **1.58 % jitter**, not chaos (the 5.04 % at step 500 was the coarse grid). The owner's complaint therefore lives in `DynoMode::continuousRamp`, a different instrument, not in the sweep. Settling was real but minor: settle 2→8 cut mean |held_rpm_drift| 3.1→0.3 rpm and moved the curve 1-4 % with its shape untouched.
- Swept past the production ceiling (probe catalogue, redline 13000, 25 mm mesh), the curve is **two lobes, not a ramp**: a flat 25-29 N·m shelf below 5500 with no resonance at all, an antiresonance at 5752 (23.1), lobe A to 36.5 @ 7250, a dip at 8252 — *where the real engine peaks* — lobe B to 41.2 @ 9751, then a cliff to ~9.7 by 11,000. Magnitude is about right (maker: 40.2 @ 8000); position is ~1750 rpm high and the shape has a dip on the real peak.
- Mesh: the expansion chamber does work and the production 100 mm mesh blunts it. Peak torque 34.00 (100 mm) / 36.26 (50) / 38.18 (25) at 9000 — **11 % lost at production mesh, and 25 mm is still not converged**. The `delivered_ve` step at 5750→6000 sharpens monotonically (+0.029/+0.053/+0.089).
- Scavenging is **perfect mixing by construction, with no rpm term**: both ports are orifices onto one well-mixed cell (`EngineSimulator.cpp:3349-3363`), so trapping is a function of delivery ratio and nothing else (0.448→0.807 as `delivered_ve` falls 1.441→0.825). `grep -rn scaveng src/` finds comments only. A real loop-scavenged engine loses charge two ways, both worsening with speed; the model has neither.
- At matched 100 mm mesh the two-stroke pipe runs **300-330 K colder** than a four-stroke's (egt 177/319/469 vs 508/680/778 °C at 2000/5000/9000), where a real two-stroke runs *hotter*. Cause found: exhaust oxidation was gated on the afterfire strategy, so an engine on the default `cleanDfco` never burned anything in its pipe, discarding 36-49 kW of chemical power (four-stroke control: 0.2-0.6 kW). `egt_c` is mesh-independent on a four-stroke (±6 K) but moves 105 K on the two-stroke.
- **Un-gating it is refuted, on three counts.** Peak torque 41.23 @ 9751 → **36.45 @ 7248**; egt at 9000 went *down* (364→357), not up. Four-stroke controls moved (EJ25 −1.54 N·m @ 2500). Four-stroke *sound* moved materially (EL-09 I2 resonance 6281→609 Hz, Aircooled peak 0.4795→0.3620), which `CLAUDE.md` forbids outright. Reverted, never committed.
- Why it failed is an **ordering result**: torque collapses while trapping *rises* (0.81→0.92), the signature of trapped burned product rather than fresh mixture — `ve/delivered_ve` counts trapped mass, not trapped *combustible* mass. Burning the short-circuit at the port mouth lets the plugging pulse stuff oxygen-free gas back in. The slug is 25-55 % of the fuel, which is itself the scavenging defect. So scavenging comes first; the chemistry is re-tested on top of it.
- Control worth keeping: `EngineLabAudioRenderHarness` is **deterministic run-to-run on one binary** (two runs byte-identical on every engine). That had never been checked here, and it is what makes a sound A/B trustworthy.
- Refuted along the way: a warming pipe wall as the cause of the climbing top end (settle 2 vs 8 = 87 s vs 261 s of thermal integration moved it the *wrong* way); "pmep=0 on a two-stroke is a bug" (deliberate — the crankcase pumps, `:3384`). Not measured: the sound of a two-stroke, any descending sweep, and the 10,250 cliff — which **disappears** under the reverted change, so it is composition-sensitive.

## 2026-10-21 — Linux CI: the GUI wrapper trusted `DISPLAY`

- The port's first CI run failed where every local run passed: `EngineLab.AudioWorkshop` in **0.49 s**, the same `BadAtom` the wrapper exists to prevent, with the other 88 of 89 green and no timeout. The cause is in the wrapper, not the test: it reused an already-set `DISPLAY`, and the hosted Linux runner exports one with **no window manager** behind it. WSLg does run one, which is exactly why the local runs all passed — the entry below says both branches were exercised, and they were, but neither was this case.
- It now asks the display instead of trusting the variable: `_NET_SUPPORTED` on the root window, absent on a bare `Xvfb` and present once a manager claims the screen. Measured on Ubuntu 24.04, four conditions, a bare `Xvfb :77` standing in for the runner — `DISPLAY` set to it passes (0.25 s, own server started), no `DISPLAY` passes, a real managed desktop passes and is reused with no nested server (0.08 s), and the binary run straight at the bare server still **fails**, which is what makes the first a fix and not a tautology.
- The probe has to read xprop's **output**: it exits 0 for a property that does not exist and prints `no such atom on any window`. Testing the status, as the first version did, made the check answer yes on a bare server — and is also why the wait for matchbox never waited. Not a timing bug; a shell one.
- Both CI test steps now pass `--output-on-failure`. Without it a job log names the failing test and says nothing else, and a job log is the only record a CI-only failure leaves.
- Confirmed on the pushed commit: **both CI jobs green**, Windows (MSVC, Release) and Linux (GCC, Release), run 39538121420. A fresh clone of the pre-fix commit in WSL also clears `EngineLab.AudioWorkshop` with `DISPLAY` unset, so the xvfb branch is doing the work and not an artefact of this tree.
- One failure in that fresh-clone suite was **self-inflicted and is not a Linux defect**: `EngineLab.Core` failed at 85.68 s while a dyno sweep saturated the Windows host (WSL shares its CPUs), and passes alone twice at 40.4 / 40.1 s. CI's own 4-core runner passed it on the same commit. It does expose a real fragility, though — `tests/CoreTests.cpp` drives a live `EngineRuntime` against wall-clock `steady_clock` deadlines (15 s, 40 s, 10 s) that nothing scales by machine load, so `ctest --parallel 2` on few cores is passing on margin.
- Not measured: whether the hosted runner's `DISPLAY` points at a live server or a dead one (the fix does not care — absent `_NET_SUPPORTED` either way); and the full fresh-clone suite on an idle host, so "89/89 on Linux" is still a claim about this tree.

## 2026-10-21 — Linux: the port, measured

- Scope: `linux-gcc-release` (GCC 13.3, Ubuntu 24.04 under WSL2, 8 CPUs) configures, builds with `-Werror` and runs the suite; `linux-clang-release` (Clang 18.1.3) does the same; CI builds and tests both platforms. Windows stays the reference and `docs/platforms.md` says what differs. Not done: no Linux archive, and the GUI has never been looked at on a real Linux screen.
- Warnings: the first build gave 522, of which ~400 were JUCE's own module units inheriting our flag set (they arrive as interface sources, so they compile *into* our targets), not our code. EngineLab's own 125 came from 5 root causes: omitted aggregate tails on types without member initialisers, shadowed locals, `size_t`->`double`, a `/*` inside a block comment, one unused variable. JUCE's units are quieted per source; its *headers* needed `INTERFACE_SYSTEM_INCLUDE_DIRECTORIES`, because no per-source property reaches a header and one `juce_UMPUtils.h` line broke 14 of our translation units.
- Three things the compiler cannot see. `EngineRuntime` (~7.4 MB) on the stack: Linux has no link-time stack size (the kernel ignores `PT_GNU_STACK`'s), so 4 test fixtures moved to `make_unique`, which is the house rule anyway. The physics thread's priority: POSIX grants `SCHED_RR` only to a privileged process, so the attempt is made and its failure ignored, and an unprivileged Linux run can report a lower real-time factor for the same engine. File names: `std::filesystem::path` reads a narrow string through the active code page on Windows and a wide one through the locale on Linux, so `pathOf`/`fileOf` use wide on Windows, UTF-8 on Linux.
- `-ffp-contract=off` for GCC and Clang: both default to `fast` and fuse `a * b + c`, MSVC under `/fp:precise` does not, and whether a given expression gets fused is a code-generation decision. Predictability was chosen over the FMA because the tests assert tight tolerances. Cross-platform bit-exactness is unattainable regardless (glibc vs MSVC `libm`, `long double` 16 bytes vs 8), so `EngineLabIntakeDuctBench`'s checksum stays a within-platform instrument.
- Two GCC-only diagnostics, neither a bug. `-Winterference-size` fires 34 times on `CylinderWorkerPool.hpp`: suppressed at the declaration, since EngineLab is one binary per build and nothing crosses an ABI, while the per-architecture value is what the padding wants. `-Warray-bounds` on `ExhaustGraph::process` is `std::sort`'s long-range branch (insertion-sort threshold 16) on a 4-element array: the sort length is now clamped against `size()`, which costs nothing at run time. MSVC reports neither.
- Clang is not redundant with GCC: its first run found **26** things GCC accepted (plus 12 in yaml-cpp's headers). 22 were `-Wsign-conversion`, which Clang's `-Wconversion` pulls in and GCC's does not in C++ -- all an `int` counter or rpm bin subscripting a `std::array`/`std::vector`, now `std::size_t` converted once *after* the guard that rejects a negative, since the index is cast from a `double`. 1 was a real conformance error (a captureless lambda reaching a local `constexpr std::string_view`, which comparing against odr-uses; GCC and MSVC both accept it). 3 were dead declarations, including a `SidePanel` member the constructor stored and no method read. yaml-cpp's headers needed JUCE's SYSTEM treatment, so that is now one `enginelab_vendor_headers_are_system` over all three dependencies.
- `EngineLab.AudioWorkshop` died in 0.4 s with `BadAtom` on `X_ChangeProperty`, atom 0: JUCE 8 reads the `_NET_WM_*` atoms with `only_if_exists` (`Atoms::getIfExists`) and, with no window manager ever having interned them, changes a property with atom `None`. Depth 24 and `+extension RANDR GLX` changed nothing; it passes unchanged with a window manager running. `scripts/run-gui-test.sh` is now what `ctest` invokes: it starts Xvfb and matchbox and waits for `_NET_SUPPORTED`, or uses an existing `DISPLAY`. Both branches were run on purpose, because WSL sets `DISPLAY=:0` (WSLg) and a plain `ctest` here therefore exercises only the desktop one.
- ctest: **89/89 on both compilers**, 937 s under GCC and 933 s under Clang (`--parallel 2`), against the ~15 min CLAUDE.md records for Windows. The first full run was not like that: 87 min, with four tests timed out (IntakeTuning, AudioRender, LoadedAccelerationCatalogDfcoResume, StandingStartSettledIdle). None is stuck -- a clean run takes 134/92/109/82 s for those four, inside their *original* limits, and the slowest test in the suite is IdleStabilityRegression at 220 s. In between, AudioRender alone measured 369 s. Same binaries, same flags: wall times here are not reproducible between runs, so no Linux/Windows ratio is claimed, and the 4x scaling of all 31 limits (off Windows only, one place) is slack for a CI runner with fewer cores, not a measured factor. Windows keeps "nothing printed after `Start N:` means stuck" exact.
- Not measured: the GUI or the audio device on a real Linux desktop; the real-time factor on Linux against Windows (scheduling differs by construction, so the comparison would not mean anything); aarch64; macOS.

## 2026-10-20 — Cylinders in parallel on the resident workers (lead 1)

- Audit of `processCylinder` from 8 cylinders up (shared volumes already frozen): it writes only its cylinder's arrays, scratch and runner duct, except 4 engine-wide events (spark count, misfire count + last misfire AFR/time, "solver resolution limited"). These now go through the scratch and are applied in cylinder order after the pass. Two-strokes stay inline (reed fill per intake path); a joint manifold must give each cylinder its own runner duct (checked each step).
- Dispatch: the existing intake pool, one more barrier per sub-step. `EngineSimulatorOptions::parallelCylinderPass` / harness `--inline-cylinders` keep it inline for A/B.
- Bit-identity: `EngineLab.JointIntakeManifold` now also runs the Merlin and compares net torque, spark and misfire counts besides speed and pressures, every frame, 0 vs 3 workers: identical on LS3 and Merlin.
- A/B in the same binary, `--relative-rpm 0.95 --free-run --seconds 15`, 4 alternating runs, warm-up ignored, best: designed V12 0.711 -> 0.877 (x1.23), LS3 1.171 -> 1.368 (x1.17), Merlin 1.400 -> 1.755 (x1.25), 2JZ control (6 cyl, untouched) 1.453 / 1.454. Spread within a variant <= 0.04. Machine: no build/test running; instantaneous load 2-90 % (the harness itself).
- Then, one factor: the end-of-sub-step per-cylinder publish (state + kinematics, writes only its index) on the workers too, A/B against `--serial-publish`, same protocol: V12 0.878 -> 0.933 (x1.06), LS3 1.369 -> 1.427, Merlin 1.770 -> 1.855, 2JZ 1.455 / 1.450. Both together: x1.31 / x1.22 / x1.33 against the inline pass, near the x1.37/1.30/1.39 estimate. The designed V12 stays below 1.0 (0.93).
- Not measured: with audio or the 3-D view; on a machine with fewer cores than this i5-10600 (6 cores, 12 threads; the pool needs at least 4 hardware threads).

## 2026-10-20 — Where a big engine's physics thread goes (profile only, nothing changed)

- How: rdtsc counters (temporary patch, not committed; they cost 1-3 % against the plain binary) + an unelevated stack sampler on Release with symbols; `EngineLabRealtimeBudgetHarness --relative-rpm 0.95 --free-run`, this i5-10600, idle machine, 4 alternating runs each. Factor quoted is the plain binary's best; times are the best instrumented run.
- Designed V12 sport 6.0 L at 7,505 rpm: 0.72. Needs 24,000 sub-steps per sim s (1.88 deg each), reaches 16,900 per wall s, 59.0 us each: cylinders (`processCylinder`) 31 % (1.54 us per cylinder), exhaust network 31 %, intake runners 14 %, serial rest 24 %, incl. per-cylinder loops (end-of-step kinematics 5 %, valve-plane publish 3 %). LS3 6,270 rpm: 1.18, 42.4 us, 29/34/12/24 %. Merlin 2,900: 1.39, 77.9 us, 34/27/21/18 %, 2.19 us per cylinder: its 107 us sub-step exceeds the 100 us blow-by sub-rate, so blow-by runs every sub-step (10 % of the thread; V12 design and LS3 4 %).
- Pool: 72,000-102,000 barriers per wall s (V12 design 1.3 intake + 3 exhaust per sub-step), 2.1-5.2 us each; the master waits 0.2-0.8 us after its own share, 2.6-5.7 % of wall. Workers 20-24 % busy and never park: already resident across sub-steps. These dispatches run at 3.1x on 4 threads (2.7x on 3); empty-dispatch floor 0.30-0.51 us (pool bench).
- Lead 1, cylinders (and their per-cylinder loops) in parallel on these workers, at that 3.1x: V12 design x1.37 (0.72 -> ~0.99; x1.43 if ideal), LS3 x1.30 (-> ~1.5), Merlin x1.39 (-> ~1.9). In Aug 2026 a cylinder cost ~0.6 us; now 1.5-2.2. Not verified: that `processCylinder` writes only cylinder-private state.
- Lead 2, coarse steps while valves shut and nothing burns: 25-29 % of cylinder calls, and such a call costs as much as an open one (V12 1.49 vs 1.52 us). Ceiling x1.07-1.10 at 4x coarser, x1.10-1.13 at most; x1.05 after lead 1.
- Not measured: either lead built; with audio or the 3-D view. Tables and tools: side-session notes `physics-profile-2026-10-20.md`.

## 2026-10-19 — Catalogue Vs: the LS3 and the Merlin share no pin either

- Catalogue V8 and V12 cylinders are generated: TDC from the firing order, odd ids on the -half bank. A row shares a pin only if its two TDCs differ by the bank angle (mod 360). Checked by hand from the files, not changed.
- LS3 (1-8-7-2-6-5-4-3): rows differ by 270, so pins pair 1-8, 3-6, 4-5, 2-7 across rows. With odd ids on the +45 bank every row shares (pins 315/225/45/135, the cross-plane): the GM order assumes the other rotation sense. That fix moves no TDC, but swaps the cylinders' stereo pan.
- Merlin (1-8-5-10-3-7-6-11-2-9-4-12): no bank side shares a pin; the real order 1A 6B 4A 3B 2A 5B 6A 1B 3A 4B 5A 2B with A odd, B even is 1-12-7-6-3-10-11-2-5-8-9-4, which shares all six. That fix changes the firing sequence over its 12 stubs.
- Both are sound changes to catalogue engines: left for the owner. Big Twin (explicit pins): shared, right.

## 2026-10-19 — V cranks: one pin per row

- Owner report: a designed V gives each piston its own crank pin. Measured (SceneExport, throws drawn): V2 90/45 2, V4 4, V6 60/90 6, V8 4 (by luck), V10 72 7, V12 60 5. The even-firing search placed pins freely.
- Fix: a V's or W's row shares a pin (`rowPinCrank()`, every pin set on a 360/rows grid, evenest then best balanced). After: V2 1 (270-450, 315-405), V4 2 (90-180-270-180), V8 4, V10 5, V12 6, all even. 60/90 deg V6 and W16: shared cannot fire evenly, so split pins (60, 30, 5 deg), as the real even-firing V6s; `crank_pins: shared` gives the odd-fire V6 (90-150).
- 3-D view: neighbouring rows with pins alike were merged into one throw (the V12's 6th); now only within a row. Catalogue: EJ25 3 -> 4 throws (right), LS3 7 -> 8, Merlin 11 -> 12: their own data pairs no cylinders on a pin (next entry).
- 8 V designs: idle on target (V4 1,392 for 1,300), designer probe passes except the 6 L V12 at 0.99. Back to back with the old binary, 3 runs each: V12 1.005-1.030 old, 0.993-1.013 new, I6 control 1.74-1.81 both: borderline before, not caused.
- Not measured: the sound of the V-twins now firing 270-450 (designed engines only; the catalogue's are unchanged).

## 2026-10-19 — Small engines: refused, then idling high

- Owner report: a 200 cc single cannot be designed. 31 designs (singles 50-250 cc x 5 uses, small twins/four, 2T, diesel): 29 refused, all with the generic validator line. The validator now names the value: final drive 8.0-20.2 over the limit of 8 (a motorcycle's ratio includes the primary: ~10 on a 125), inertia 0.002-0.009 under 0.01; under 0.1 L also plenum, piston mass (< 50 g), throttle (< 15 mm), and 50 cc failed a 0.05 L check by round-off.
- Fix: final drive limit 15; the designer holds every such value at the simulator's limit and says so in its rule. 31/31 design.
- Idle, then: 50 cc 2,042 rpm for 1,350. One factor, the per-bore closed-throttle leak 0.6 -> 0.1 mm2: 1,329 (cruiser 1,196 -> 800, sport car 1,385 -> 901). Rule: 0.6 mm2 x bore / 60 mm below 60 mm. 15 rebuilt designs: idle unchanged (CP2 1,350 -> 1,349, RD350 1,316 -> 1,311). 26/31 small designs within 30 % of target.
- Not fixed: sport motorcycles <= 125 cc idle ~2,000 for 1,300. One factor each on the 125: leak 0.05 1,859, bypass 0.5 2,009, inertia x3 2,029, bore/stroke 1.15 1,761, road cams 1,361: the sport cams' overlap on a small cylinder. No rule from size is backed by data (the CP4 design, 250 cc a cylinder, idles on target). Diesel single 0.3 L 1,106 for 800; 50 cc two-stroke 3 Nm (BMEP ~4 bar).
- Full load: 125 road single 14 Nm, 11.4 kW at 9,000 (BMEP 14 bar); 50 cc 5 Nm; 250 twin 27 Nm.

## 2026-10-19 — The designer's real-time check failed engines that run fine

- Owner report: some designs fail "the 5,000 rpm test" yet run well. New `EngineLabRealtimeBudgetHarness --designer-probe` runs the designer's own check. Before: 3/3 singles (450-650 cc) and the Merlin and the radial (catalogue) "did not hold" in 30 s; 14 other designs and 15 catalogue engines passed.
- Singles: held on the mean (5,000 rpm), but one polled sample swings 4,711-5,436 rpm (trace at 2 deg: +3.7 / -5.7 % on the 500 cc); the check wanted every sample within 3 % for 0.5 s. A test-binary single passed by poll timing, so the regression test is a synthetic +-5 % ripple (fails on the old rule).
- Merlin, radial: the dyno cannot pull a full-load engine up to 95 % of the limiter; they settle 5 % short (2,900 / 3,040, 2,151 / 2,280 rpm).
- Rule now: mean speed (1/3 s filter, as the harness) within 3 % for 0.5 s, or settled (< 0.5 % in 1 s) within 15 %, measured where it settled. After: 17/17 designs and 17/17 catalogue engines measured in 1.9-4.4 s; factors as before within run-to-run noise.
- Not measured: the check from the app with the 3-D view and audio running.

## 2026-10-19 — Builder phase 6: W engines in 3-D, and a W with no angle

- A W designed with no bank angle had every bank at 0 deg: four cylinders stacked per row. The phase 4 W16 figures were that engine. Rule now: banks spread over 120 deg (at most 90 between neighbours; 3 banks 60 deg, 4 banks 40 deg); two banks at one angle are refused. Corrected W16: physics-only 0.533 (stacked 0.537, so cost is per cylinder, not geometry), still INVALID with audio; idle 901 / 900 rpm.
- 3-D view: banks > 2 were drawn as a radial. Now bank by bank, banks next in angle interleaved half a pitch. Measured with SceneExport (`--catalog-root`, new) and RouteCheck, one change at a time on the W16: stacked banks 213 duct clashes / 236 through the engine; angles fixed 58 / 70; plus the W drawing 15 / 8. Deepest liner overlap 96 -> 57 -> 30 mm (V12 design: 29). Catalogue and 15 rebuilt designs: totals identical before/after (9/4/0/48/7, 16/7/6/40/13).
- Not measured: the view in the app (screen access declined; front/side projections of the exported meshes only), a W's exhaust stubs from the inner banks (they point at the outer head).

## 2026-10-19 — Builder phase 4: spark advance, real-time check, idle

- Advance: DynoSweep `--advance-offset` -6/-3/0/+3/+6/+9 deg on the 15 rebuilt designs, `--step 1000`. Most still gain at +9 (2JZ, EJ25, CP3/4, Hayabusa, I5, flat six: +2 to +9 %); K20A, Harley, RD350 peak at -3..+3; the TDI ignores it. No MBT auto-calibration: designs already exceed the maker's power (2JZ 312 vs 206 kW, flat six 289 vs 200) and nothing here limits advance by knock, so "best torque" would walk away from the datasheets.
- Real time, 7 harder designs (free-run, audio + gas view): I7 1.51, radial 9 1.60, I10 1.16, V8 diesel 0.99, V12 sport 0.95, two-stroke four 0.93, quad-turbo W16 INVALID (physics 0.54). V12 physics only 1.00: exhaust mesh 600 mm +3 %, intake mesh 0; it is per-cylinder work, rising with rpm.
- The whole chain ran at 0.88-0.97 of the physics-only factor (19 designs). The designer now runs a design for ~3 s (`measureRealtimeCapacity`, same speed as the harness: 5,000 rpm, at most 95 % of the limiter) with the live engine paused, and asks before building under 1.14 physics-only. The I7 probe read 1.598 against the harness's 1.599.
- Idle, 22 designs, PhysicsPerfHarness `--freerev 0 --seconds 25`, last 8 s: 21 within 7 % of target, no misfire. Two-stroke four 2,070 rpm for 1,300, misfiring: one factor at a time, bypass 0 2,203; idle target 1,600 2,475; one throttle body 1,433, no misfire. Rule: a two-stroke gets one throttle (the catalogue RD350's carburettor-to-crankcase convention). RD350 design idle 1,393 -> 1,304 (sd 42 -> 16), WOT -2 to -5 % (34.4 kW at 9,000, maker 35).
- Not measured: the designer window on screen (access declined), the probe inside the app against the harness, catalogue engines' advance sensitivity, transients.

## 2026-10-19 — Builder phases 1-3: the catalogue rebuilt from datasheets alone

- `designEngine()` (catalog): cycle, fuel, use, layout, cylinders, bore x stroke (or litres), induction -> a whole engine; each value derived by a rule fitted to the catalogue, or set by key (its rule kept). A file may hold `design:` instead of `engine:`, so every harness runs designed engines.
- Rebuild: the 15 distinct catalogue engines as datasheet specs only (size, layout, use, boost, firing order or crank offsets). Dyno `--step 1000`, peak torque design / catalogue 0.88-1.18 (median 1.04): K20A 244/236, LS3 718/645, EJ25 372/424, CP4 104/116, Harley 212/188, flat six 406/344 N.m.
- Power first ran high where the derived redline was (sport car 23.5 m/s: 2JZ 8,200 rpm vs 7,200, 349 vs 276 kW). Refit: sport car 22.0 m/s, boosted petrol 1.5 lower. Then 2JZ 312, EJ25 267, I5 297, flat six 289 kW (catalogue 276/235/283/203). Not refitted further: 15 engines are the whole fitting set.
- Two-stroke on the four-stroke 4-2-1 part: RD350 design 13.5 kW at 9,000 rpm. With a generated expansion chamber per cylinder (tuned length 500 x exhaust duration / 12 n, Blair; RD350LC proportions): 36.1 kW (catalogue 34.2, Yamaha 35).
- Crank: V/flat/W banks, W bank angles as given (W16 +-37.5/+-52.5); a radial's TDCs follow its single throw (an even-count radial cannot fire evenly). With no order given, the best balanced one is searched.
- Correction to 2026-10-18: the W16 had no banks, so it loaded as one bank at 0 deg (a 16 in line); its idle and real-time figures are not a W's.
- Real time (free-run, audio + gas view, one run each): 13 designs 1.26 (LS3) to 2.88 (CP2); catalogue 1.20-2.83. Merlin and radial designs INVALID (leveler, limiter, clamp): outlet jet 1,640 / 920 Pa vs 1.5 Pa. Not the voicing (catalogue Merlin's: same); the stack lip, 108 mm from "1.1 x collector" vs the part's 140. Lip 2.7 x stack, radial on `radial_collector`: valid, 1.29 / 1.91, jet 0.3 / 0.7 Pa.
- Not measured: sound of any design against its catalogue twin, idle of all 15, transients.

## 2026-10-18 — Builder phase 0: eight engines written with no base

- Question: what breaks when an engine is described from nothing? Eight files in `tools/torture-engines/engines/` (I7 petrol, single, flat twin, V10 72 deg, V16, I7 diesel = TDI x 7/4, W16 as four `bank_offset_deg` banks, two-stroke triple = RD350 x 3/2). Catalogue root = that folder plus `parts/` and `voicing/default.yaml` copied beside `engines/`.
- All eight load, validate and hold their idle 20 s (PhysicsPerfHarness `--freerev 0`): mean at target within 1 % except W16 711 vs 750 (672-735). The triple misfires at idle (0.55 at start) on the four-stroke 4-2-1 part.
- Dyno (`--step 1000`), peak N.m and BMEP: I7 329 (14.7 bar), single 72 (13.8), flat twin 142 (14.2), V10 518 at 3,000 (13.5), V16 869 (13.7), I7 diesel 611 (22.3). Generic parts give upper-edge NA BMEP (typical 11-13.5); the V10's peak at 3,000 rpm on a 9,000 rpm engine shows parts not matched to it.
- Real time (free-run, audio + gas view, one run each, not back-to-back): I7 1.29, single 4.03, flat twin 2.50, I7 diesel 1.22, triple 1.59, V10 0.96 (below the hard limit), V16 and W16 invalid (40,000 dropped pressure samples); V16 without audio 0.65 (exhaust substeps 28 kHz).
- So the format already takes any piston layout up to 32 cylinders; what a from-zero builder lacks is matched parts (cams, pipes, plenum for the target rpm) and a real-time cost known before the engine is delivered.
- New `CrankBalance` (foundation): free forces and couples, firing intervals, ranked even-firing inline orders. EngineLab.EngineBuilder checks the textbook I3/I4/I5/I6 and cross-plane V8 (primary couple sqrt 10) values. Best I7 orders: 1-3-5-7-6-4-2 and its mirror (couples 0.27 / 0.30 m r w^2 a); the torture I7's 1-4-7-3-6-2-5 was not among the top four.
- Not measured: sound of any of them, the 3-D view (W16 would be drawn as a radial: banks > 2), V/W axial positions (assumed one pitch per row).

## 2026-10-17 — The Merlin's runtime spike was a late frame stamped in the past

- `EngineLab.AudioRender` and `AudioRuntimeDiscontinuity` (Merlin, live runtime) failed CI on 6a1d505. Locally 2 of 40 runs fail alone, 15 of 50 with two runs in parallel (preLimiter up to 8.9, observer up to 3 kPa).
- Per-block trace (harness instrumentation, not committed): every spike follows 20-37 ms in which the renderer's rpm does not move, i.e. one physics frame preempted while computing. Its samples were stamped from the frame's start, so all of them arrived behind the renderer's 20 ms look-ahead; the renderer stepped through them in one audio sample, and the exhaust boundary's jump radiated as a one-block, full-scale click. Not the rev limiter (one spike at 1,696 rpm), not the jet nor reactions (0).
- Fix: a frame published more than 10 ms after its start is stamped from 10 ms before publication (`MonotonicPublicationTimeline`); the renderer then interpolates across the gap. A frame in time keeps its stamps, and offline renders do not use the runtime.
- Same stress, 50 runs: 0 failures, preLimiter max 0.42 (median 0.35, as alone). Same overrun band (400-699): 12 of 34 failed before, 0 of 12 after. dropped pressure samples 0 both.
- Not measured: a long run on a machine below real time, and the audibility of the held boundary during the gap (a short freeze instead of a click).

## 2026-10-16 — Two-stroke exhaust coupled every substep from BDC to transfer close

- Where 100 mm lost (RD350, 8,000 rpm, single-point dyno, one factor each): first the cylinder/exhaust coupling, not the cells. Production couples every 117 us (3 substeps, exchange applied as a lump): 27.6 N.m; every substep 31.3; 25 mm coupled at 40 us 35.9. 78 us gains nothing over 117 (not explained).
- Fine coupling inside one crank window only: blowdown 28.0, 115-180 deg (first half of scavenging) 26.8, whole scavenging 115-245 30.8, BDC to transfer close (180-245) 31.1. There the cylinder pressure is a few-kPa balance between two open ports, and it sets the trapped charge. Finer transfer (intake) coupling: 26.0-27.4, not a lever.
- Kept: a two-stroke couples every substep while a cylinder is between 180 deg and 360 - transfer open. Dyno sweep (N.m, coarse -> window, every substep): 6,000 19.2 -> 22.3 (21.3), 7,000 24.6 -> 28.3 (27.9), 8,000 26.0 -> 28.9 (29.2), 9,000 29.5 -> 33.6 (34.5); 3,000-5,000 within 1.4 %.
- Real time (free-run, audio + gas view, 9,025 rpm, 4 alternated rounds): window 1.057-1.068 (36.0 N.m, 34.0 kW), coarse 1.164-1.177 (31.7, 30.0), LS3 control 1.107-1.123. Whole scavenging window 0.968-0.985 and every substep (cpl 40 us, dropped samples) are not real time.
- EngineLab.TwoStroke: production within 5 % of every-substep at 8,000 rpm (33.0 vs 33.6; fails before: 29.2). Gates: idle 1,300 std 14.7, WOT blip min 1,133; launch at 4/25 s min 704/574. Four-stroke dyno and IntakeDuctBench bit-identical. ctest 89/89.
- Render `--catalogue-filter RD350`: RMS 0.0077 -> 0.0079, bands 0.4/77.8/21.8 -> 1.0/72.6/26.5 %, brightness 0.48 -> 0.50, crest 6.7 -> 9.3, max 6,902 -> 7,232 rpm.
- Left: ~35-36 N.m converged vs 37-40.2 (maker). Not measured: any recording, scavenging efficiency against literature, friction.

## 2026-10-16 — RD350 combustion: maker's timing, crankcase no longer read as load

- Burn phasing from traces (CA10/50/90, `burn.py` on PhysicsPerfHarness `--trace 8000`): with the maker's fixed 20 deg BTDC (CDI, 2.0 mm, workshop manual as quoted by owners) and the default flame, CA50 sat at 28.5 deg ATDC, far past MBT (8-10); the catalogue's 13 deg gave 29.0.
- Cause 1: the two-stroke "MAP" is its crankcase (75-87 kPa at idle, ~107 at WOT), read as load: the flame saw an idle at 0.77 load and the ECU took 2 deg off at WOT for "boost". Load is now the delivery ratio, in the simulator and the ECU (EngineLab.TwoStroke, fails before: 17.65 vs 19.8 deg, idle load 0.77).
- Cause 2, a calibration, not a measurement: `chamber_turbulence_intensity_ratio` 2.0 (squish head) puts CA50 at 9.2 deg ATDC with 20 deg (CA10/90 -4.0/17.6, peak 51.5 bar; 1.0: 28.5, 1.75: 12.1). 1.75 with the MAP load failed the idle gate alone.
- Single geometry factors, earlier (12.3 N.m state, 8,000 rpm): crankcase compression 1.50, exhaust port 50 mm wide, transfers 115 mm, throttle 36 mm, runner 50 mm gave 10.3-13.7; none kept. The port timing matches two forum port maps that agree (exhaust 193-209 deg, transfers 125-130 deg duration); it was not swept. Port widths were not checked.
- RD350 dyno 100 mm (N.m, before -> after): 3,000 21.1->23.1, 5,000 19.1->21.9, 8,000 21.9->26.0, 9,000 22.6->29.5 (27.8 kW). 25 mm: 8,000 30.1->34.1, 9,000 26.8->37.2 (35.1 kW; maker 34.5 kW at 8,500, 37-40.2 N.m at 8,000).
- Gates: idle 1,300 std 14.7 drift -0.8, WOT blip min 1,122 settled 1,257, early blip 1,128; launch at 4/25 s min 704/574. Four-stroke dyno and IntakeDuctBench bit-identical.
- Render `--catalogue-filter RD350` (both entries of the day): RMS 0.0086 -> 0.0077 (-1.0 dB), bands 1.9/68.0/30.2 -> 0.4/77.8/21.8 %, brightness 0.51 -> 0.48, max 6,241 -> 6,902 rpm. Not measured: any recording, the real burn duration, 12.5 mm with this setup.

## 2026-10-16 — Two-stroke exhaust reconstructed across interfaces; where 100 mm loses

- The chambers are short cones: at 100 mm most are 2-3 cells, and duct end cells were first order, so a whole cone was. Reconstructing across every open duct-to-duct interface (on for two-strokes only), RD350 at 8,000 rpm: 100 mm 12.1->21.9 N.m, 50 mm 17.9->27.1, 25 mm 22.3->30.1; 18 mm 30.9, 12.5 mm 31.3 (converged near 31-32 with the timing of the day). New EngineLab.GasDynamics case: a 400 mm pipe authored as two 200 mm components carries a pulse as one pipe.
- What 100 mm still loses against 12.5 mm (one factor at a time): the time step ~2.2 N.m, the port cells ~1.8, the rest ~5.6. The first cell behind a port holds ~126 cm3, about the cylinder's volume, so the blowdown lingers in a plenum.
- Not kept (8,000 rpm, 100/25 mm): third-order kappa = 1/3 faces 21.6/29.8; one-sided slopes at open ends 22.5/30.4; the characteristic valve 22.7/28.2 (gains at 100, loses at 25: mesh-dependent). They stay as diagnostics.
- Real time (free-run, audio + gas view, 9,025 rpm, 4 alternated rounds after a warm-up): RD350 reconstructed 1.149-1.170, first-order ends 1.287-1.302, LS3 control 1.081-1.114. The reconstruction un-fuses RK2's second stage on two-strokes.
- Not measured: a solver fast enough for 25 mm in real time (multirate per duct is the lead), any recording.

## 2026-10-16 — Two-stroke fuelled from its reed fill; two-strokes now at 100 mm cells

- Lean launch (RD350, 100 mm, launch after a 25 s idle, traced every 12.5 ms): the pulse (sprayed 250-355°) was sized from the air across the transfers latched at TDC, i.e. for the event before last, and that transfer air itself lags the crankcase fill by one event (mg per event from idle: fill 81, 328, 287; transfers 18, 127, 192). Five lean misfires before the clutch bit.
- A, latch the transfer air at transfer close: min 389/592 rpm (launch at 25/4 s), but stalls a 12 s launch and at 90 mm; at 360 mm the early WOT blip falls to 614 (gate 1,014). Not kept.
- B, kept: the reference is the reed inflow into the crankcase since the last transfer close, latched at that close. 100 mm: launches at 4-30 s all survive (min 430-653, stall 220); 90/110/125 mm pass; 80 mm stalls at 25 s on top of its known idle hunt. At 360 mm B also fails the early blip (626): it only stands with the finer mesh, rich early idle (below).
- Two-stroke production mesh is now 100 mm (`EngineSimulator::productionExhaustCellLengthM`), in EngineRuntime, the app's fine view (never coarser) and the designer's cost. IdleStability RD350: mean 1,322, std 28.8, drift -42.7, WOT blip min 1,251, settled 1,433 (gate 1,495; 1,258 before); early blip 1,372. Standing start at 4/25 s: min 629/486.
- RD350 dyno (N.m, before -> after): 2,000 15.3->20.5, 3,000 15.3->22.4, 5,000 13.9->15.7, 8,000 9.8->12.3, 9,000 8.2->9.7 (maker 37-40). Four-stroke dyno sweep and IntakeDuctBench checksums bit-identical. Render `--catalogue-filter RD350`: RMS 0.0056 -> 0.0086 (+3.7 dB), bands 1.6/87.0/11.4 -> 1.9/68.0/30.2 %, brightness 0.38 -> 0.51.
- Left: B coasts lean after a WOT blip (AFR 18-25, misfire 0.6-0.9; reed fill ~3 mg vs 4-7 mg of oxygen-based delivery, not explained), hence the settle near its gate. While cranking the trim winds up to 2.2 and acts as a choke (early idle rich). Not measured: the real-time factor with B (no added cost expected; 1.22-1.26 is the 2026-10-15 figure), any recording.

## 2026-10-16 — Aircooled soft limiting at 7,030 rpm: duct steepening into an open pipe

- RealtimeBudgetHarness `--with-audio --relative-rpm 0.95`: the Aircooled is INVALID on soft limiting with or without `--gas-view` (3 runs without it: 12-22 samples). Its pre-limiter peak is 1.54-1.80 against 0.09-0.43 on the 16 other engines, and its exhaust observer reads 590-712 Pa against 26-140. AudioRenderHarness does not reproduce it: its catalogue point never passes 6,103 rpm (pre-limiter 0.45). GeometrySensitivityHarness held at 7,030 rpm does: pre-limiter 2.20, 1,237 soft-limited samples.
- Signature: positive spikes 2-5 samples wide (99 % positive), spaced by one bank's firing interval and not aligned to blocks. Onset is near 5,500 rpm: 16 of 206 cycles over 0.82 at 6,200 rpm, 122 of 234 at 7,030.
- One factor each at 7,030 rpm (offline, with diagnostic switches that are not committed). Exhaust reactions: 0 events. Reaction crack off: unchanged. Valve-flow high band off: 2.04. NonlinearDuctAcoustics off: pre-limiter 0.26, observer 883 -> 62 Pa, RMS -4.8 dB, no soft limiting. A guard against reading backwards in the warp: 1.83 only.
- Cause: at these in-duct amplitudes the steepening warp sits on its ±30 % clamp, so each long duct turns the blowdown front into a jump of up to ~0.23 x its transit time (~13 samples on a 720 mm primary). The flat-six is the only road exhaust without a silencer, so its open outlet radiates that step as an impulse. Steepening stays: it carries every engine's 1.5-4 kHz content (2026-07-21).
- Silencer as one factor (scratch catalogue, `flat6_equal_length` + 130 x 380 mm chamber). Packed (20,000 Pa s/m2, 30 mm, 0.30): pre-limiter 0.29, no soft limiting, RMS 0.112 -> 0.051 (LS3 0.060). Realtime, 2 runs: softLimit=0 in both (one run INVALID on 42 late events, a timing failure, not a level one). Dry chamber alone: 1.42. Torque -0.4 to -2.1 % at 3,000-7,000 rpm (every row UNSETTLED_TIMEOUT).
- Not changed: the flat-six keeps no chamber, as decided on 2026-07-21 ("near-open pipe in reality"). Yet the preset's own comment says the silencer sits behind the engine, and a stock 964 has a rear silencer (not checked against a drawing). This is the owner's call. Not measured: whether the spike height depends on the sample rate (exporter at 48 vs 96 kHz was inconclusive), or any recording.

## 2026-10-15 — Two-stroke exhaust stays at 360 mm: 50 mm is not real time, 100 mm stalls the launch

- Profile (RD350, 9,025 rpm, 50 mm): the exhaust FV network is most of the physics thread; interfaces were solved serially. Each interface's Riemann solve now runs in its upstream duct's pool share: +4.5 % on a pooled run (min of 4 alternated, 1.262 -> 1.319), bit-identical (four-stroke dyno sweep, IntakeDuctBench, RD350 standing starts unchanged).
- MUSCL-Hancock (diagnostic `--exhaust-hancock`, one stage per substep): cheaper, but amplified a sealed duct up to 479x above Courant 0.3 (centred wall pressure on closed faces; a reflected Riemann pressure fixes it, test fails without it). That wall on partly open faces cost 43 % torque: not kept. At 75 mm it made 8.3 N.m at 4,000 rpm (RK2 17.8): not production. CFL 0.9: refuted.
- Real time (free-run, audio + gas view, 9,025 rpm; LS3 1.09 the same hour): RK2 50 mm 0.94-1.05 even with 2-3 pool workers (one invalid run); 75 mm + 2 workers 1.37; 100 mm without pool 1.22-1.26. A pool on the twin gave paced spikes of 25-34 ms and late audio events, even at 360 mm: not kept.
- RD350 torque, 360 -> 100 mm (N.m): 3,000 15.2->22.3, 5,000 13.8->15.5, 8,000 9.6->11.9, 9,000 9.5->10.4 (maker 37-40.2 at 8,000; 25 mm 22.7, not converged). Steady WOT torque at 1,500 rpm also rises (15.9 -> 20.1).
- Blockers, so production stays 360 mm: at 75 and 50 mm the idle hunts (std 90-138 rpm; 1-2 mm2 pilot bypass did not settle it, not explained). At 100 mm idle is fine but the launch from a settled idle stalls: the tip-in goes lean (AFR 47-50) before the clutch bites. At 360 mm the same lean tip-in (AFR 36-39) already dips it to 370 rpm (stall 220); 150 mm survives at 228.
- Not measured: a real RD350 recording; the two-stroke tip-in fuelling itself (the next lever for a finer mesh); the pool's paced spikes on other engines.

## 2026-10-15 — Every catalogue engine through the drive harness

- `EngineLabDriveScenarioHarness --builtin pull|downshift-clutch|cruise` on all 17 engines. Cruise holds 100 km/h within 0.06-0.96 km/h mean, 2.1 max; no false "injectors saturated" left. Merlin and Radial sit on a test stand (no road vehicle): they do not move, as intended.
- Bug: the Audi I5-like stalls on the `cruise` launch (60 % throttle, clutch let out linearly over 0.9 s), and the stalled car then rolled BACKWARDS at a steady 0.33 km/h, brake off, flat road. The stopped crank's friction (-6.7 Nm) went through the locked clutch as a drive torque (-71 Nm at the wheel) while the crank was held at zero. A crank at rest now passes no resistive torque.
- Second bug under it: rolling resistance switched off below 1 cm/s, so a car crossing that line crept on at that speed for ever (0.036 km/h here). It now fades with the speed below 1 cm/s while the car slows; a car pulling away keeps none there, as before. Fading it on launches too moved the 2JZ dual-clutch push by 2 % (EngineLab.ShiftStyle, push 375 -> 369 ms without retard) and failed its retard check: not kept. Both bugs in EngineLab.VehicleDynamics, failing before; dyno bit-identical.
- Not a bug, not changed: the stall itself. The I5's 900 Nm clutch asks 200 Nm at 0.2 s of a 0.9 s linear release, more than the engine makes at 700 rpm and 60 %; it also stalls from a settled idle (launch at 8 s). The scenario has no clutch modulation; a real driver's launch was not measured. The RD350 never reaches 100 km/h in `cruise` (known torque gap).

## 2026-10-15 — "Injectors saturated" was read mid-window

- The `injectors_saturated` limit read the injector's open time over the window elapsed SO FAR: a frame ending while the injector was still open read 100 %. Now judged on the last completed cycle. EngineLab.ActiveLimits: CP2 held at 6,000 rpm at full load, own injectors: no (was yes); 2 g/s injectors: yes.
- Correction to "Drive-scenario harness: first runs on the CP2" below: the "99 % of their window for 9.3 s" was this artefact. CP2 `pull` now: 0 s saturated, 0-100 km/h 3.97 s (5.86 s before the stage-E motorcycle inertias), top speed 202 km/h. A real MT-07 is quoted near 4 s; not measured here. Physics untouched (flag only).

## 2026-10-15 — Two-stroke fuelling: delivered air, no overrun cut

- The RD350 was fuelled for its trapped oxygen-equivalent air (~60 mg, mostly retained charge) while ~9 mg crossed the transfers: idle AFR 3.7, trim on its 0.55 floor, 50 % misfires, stalled in the standing start. Fuelled on last cycle's delivered air: idle AFR 13.5, trim 1.01. Four-stroke dyno bit-identical.
- IdleStability: idle 1,320 rpm (target 1,300, bypass 3 mm2; 6 mm2 gave 1,421) but 1,747 rpm 12 s after a WOT blip. Trace (`--trace --wot`): the overrun fuel cut cycled between 1.50 and 1.65 x idle for 4 s, each resume firing a clean scavenged charge (+5 N.m). No overrun cut on two-strokes: 1,413-1,430 rpm, passes.
- Fuelled overrun then taught the trim the film drain (0.64 at a tip-in, AFR 25, 141 misfire events in 2 s). Holding learning only during overrun just delayed the crash to the 0.55 floor; holding it through overrun and 2 s after: 4 events, lean peak 62 %. The DFCO-resume test reports two-strokes as n/a.
- Not compared with a real carburettor's transient; the remaining tip-in lean is the one-cycle lag of a delivered-air reference.

## 2026-10-15 — Two-stroke engines; the expansion chamber needs a finer mesh

- Piston ports, crankcase pumping (path plenum = crankcase volume, reed throttle), 360-degree cylinder phase in a 720-degree crank domain. Four-stroke catalogue dyno bit-identical. Catalogue: RD350LC-like twin (maker 37-40.2 N.m at 8,000 rpm).
- The maker's 6.2:1 is a trapped ratio; geometric 11.2:1 is used (single cylinder: 40 -> 54 J per cycle).
- Brake torque at 8,000 rpm against exhaust cell length: 360 mm 8.5 N.m, 100 mm 12.3, 75 mm 15.3, 50 mm 19.1, 25 mm 23.4 (stinger 22 mm). Single cylinder, trapped fresh charge 73 -> 136 mg from 360 to 25 mm: the chamber's suction and plugging waves need cells of 50 mm or less.
- Real-time capacity (free run, no audio) at 9,500 rpm: 100 mm 1.41, 75 mm 1.29, 50 mm 0.76, 25 mm 0.29; paced with audio, 100 mm already overruns. So the catalogue keeps the 360 mm production mesh: 10.4 N.m at 8,000 rpm with a 26 mm stinger (0.65 x header), a quarter of the maker's. Not compensated by combustion or friction.
- Second gap: combustion is late (CA50 ~30 deg ATDC at 8,000 rpm); not addressed. Outlet size and silencer restriction are inert. Ports, chambers and crankcase ratio are estimatedFamily; not compared with a recording.

## 2026-10-15 — Several turbochargers, a compressor map, an intercooler

- N turbochargers (1-4), each exhaust path's turbine face on its own shaft, the compressors solved together on one charge. EngineLab.Turbocharger: an I4 on two half-size units = one double (boost, torque within 0.2 %); a V8 with 2 + 6 cylinders per turbine: 113 vs 174 krpm, 22 % of the air through the small one, both at the common boost.
- Compressor head now from a scaled speed-line map (Moraal-Kolmanovsky, design point = wastegate ratio at the engine's flow at 0.7 x redline). Dyno (catalogue): above 2,000 rpm unchanged (wastegate holds the ratio); at 2,000 rpm EJ25 +2.5 %, I5 -1.8 %, 2JZ +0.8 %, TDI -0.5 %.
- REFUTED, not kept: an efficiency island (peak at the design point, -0.24 (phi-1)^2 - 0.25 (N-1)^2) costs at 2,000 rpm 2JZ -8.6 %, EJ25 -10.6 %, I5 -19.3 % (397 -> 320 N.m, real 480), TDI -15.9 % (347 -> 291, real 320); phi only (similarity): -7 to -16 %. Peak power unchanged. The low end is spool-limited and was already short (I5); the constant efficiency compensates a weak low-speed turbine. A turbine efficiency against U/C was not tried: its peak is the fitted value, so it can only remove more.
- Intercooler (`intercooler_effectiveness`, default 0): with 0.7 the petrol turbos make 19-29 % more torque, ABOVE their makers' figures (2JZ 445 -> 524 at 4,000 rpm, real 427; EJ25 411 -> 506, real 393; I5 473 -> 594, real 500); the TDI is fuel-limited (+3 %). IMEP per unit of trapped charge is 14.5-15.2 bar on these vs 16.4 on the K20: the missing intercooler hides a ~20 % optimism at boost (lead, unverified: knock intensity saturates, so no knock-limited retard). The catalogue keeps none authored.

## 2026-10-15 — Peak firing pressure and its limit; diesel rail pressure

- Peak pressure is now tracked per cylinder at every sub-step and published per cycle (the dyno's `peak_cyl_bar` sampled once per frame). DynoSweepHarness, whole catalogue, maximum over each 1,000 rpm row at full load: K20 116.8 bar, LS3 84.6, CP2 73.6-80.3, Hayabusa 77.1, CP4 87.9; 2JZ 107.1, EJ25 138.3, Audi I5 175.2 (3,000 rpm), TDI 231.5 (2,000 rpm).
- Pmax/IMEP at those rows: 5.1-7.3 on petrol engines, 9.9 on the TDI. Real production limits are about 120 (NA), 140 (boosted) and 200 bar (diesel): the I5 and the TDI fire above them, so their full-load phasing is probably earlier than a real calibration. Not addressed; both carry a limit 10 % over their stock peak (195, 255 bar).
- Damage above the limit grows as the square of the excess (0.05/s at 100 % over). EngineLab.PeakPressure: K20 held at full load (106.5 bar mean, 0 damage); with a limit at 70 % of that, 0.069 damage in 8 s. Stock dyno torque bit-identical.
- Diesel mixing time x sqrt(rated / rail pressure) (Chmela-Orthaber jet velocity). TDI held at full load, injector capacity held: 198.4 bar at 2,000 bar rail, 177.0 at 1,000. Stock rail = rated pressure, so bit-identical at stock. Not compared with a measured pressure trace or a noise recording.

## 2026-10-15 — The default collector was a 2 L chamber

- Owner complaint: a short collector sounds muffled on every engine. GeometrySensitivityHarness, collector volume -> swept only: CP2 +10 to +19 dB over 0.5-5 kHz, TDI +8 to +12 dB at 1.2-3 kHz. Cause: `collectorVolumeLitres` defaulted to 2.0 L, lumped as a compliance at the branch (a pre-chamber the geometry does not have), and the catalogue floored it at 0.05 L.
- Now 0 = no body: the collector holds what its trunk sweeps (legacy graph, editable network, catalogue builder). An authored body (CP3 1.7 L, CP4 2.0 L) is kept and scales with the collector on resize.
- First attempt collapsed the CFL (2JZ 64.8 -> 9.3 mm): the catalogue's 0.05 L floor, not the swept stiffness. Final: CFL identical on all 10 engines measured (CP2 44.4, 2JZ 64.8, Hayabusa 44.4 ...).
- Sound vs before (default render, 2 s skip): shape CP2 7.2, Hayabusa 12.3 (+5.8 dB level), TDI 6.9, I5 6.7, K20 4.1, 2JZ 3.8, EJ25 3.6; tilt brighter (CP2 -2.80 -> -1.25, Hayabusa -0.06 -> +3.43 dB/oct). LS3, Harley, CP4: bit-identical.
- Dyno (whole catalogue, 1,000 rpm steps): peak power -1.9 to +2.4 %, torque rows within -4.9/+3.0 %.
- Not listened to; not compared with a recording. The real stock MT-07 and Hayabusa have an under-engine box that is not authored here (could be, as on CP3/CP4).

## 2026-10-15 — Knock control as a calibration; knock intensity saturates

- The ECU's knock retard (`knockLevel x 12` deg) is now the calibration `knock.retard_deg_per_intensity` (default 12, 0 = off). EngineLab.KnockControl, 2JZ held at 0.6 x redline, full load, last 6 of 12 s: on: knock 0.35, advance 6.3 deg, 455.6 N.m, damage 0; off: knock 0.43, advance 10.5 deg, 465.4 N.m, damage 3e-6.
- Same rig with the spark trimmed +5/+10/+20 deg: knock 0.42/0.47/0.47 (on), 0.47/0.47/0.47 (off); torque still +2 to +5 %; damage at most 4.4e-4 after 12 s (0.5 "damaged" would take hours). The intensity (`severity x sqrt(unburned)` at auto-ignition, mean-chamber conditions) saturates just above the 0.45 "severe" threshold whatever the advance.
- So knock consequences were NOT strengthened: a damage rate or a heat-transfer penalty tuned on this flat scale would be calibrated on a non-physical signal (onset changes are refuted, see the rules). An over-advanced map is not punished as a real engine would; next lead, unverified: the intensity's dependence on advance, not its onset.
- Not compared with a real knock trace; a real ECU retards in steps per event and recovers slowly, not modelled.

## 2026-10-15 — CVT, car and scooter

- A variator inside the clutch model: ratio interpolated over the 1 ms steps, the stick constraint follows its rate and takes slip out over 20 ms. Fixed-ratio gearboxes bit-for-bit unchanged (start = end ratio, added terms zero).
- Toy engine (EngineLab.Cvt, 200 Nm, 1,300 kg): the scheduled speed is held within 0.0 %, no step over 0.0 rpm/frame; 30 % pedal 2,510 rpm (centrifugal 2,717), flat out 6,120; launches and braked stops never under 0.85 x idle; the scooter's centrifugal clutch idles free, the car's creeps.
- K20 switched to CVT (its 1st-6th range), DriveScenarioHarness `--builtin pull`: held 7,396 rpm from 6 s to top speed, slip 0-1 rpm; 0-100 km/h 5.80 s (its manual 6.19 s), 235.5 km/h. `--builtin cruise`: 100 km/h held, mean error 0.59 km/h.
- Not compared with a real CVT's engine-speed trace; the 1.5 s ratio rate, the pedal schedule and both parts' ranges are typical values, not a unit's. No scooter engine in the catalogue yet.

## 2026-10-15 — Motorcycle rotating inertias were a car's

- The three motorcycle gearboxes inherited the car defaults (wheels 3.6, differential 0.16, input 0.08 kg m^2): 234 kg of equivalent mass in first on a 260 kg bike. Now wheels 1.2 (cruiser 1.6), chain 0.02 (0.03), clutch basket 0.004 (0.008) referred through the primary: 23 kg (28).
- DriveScenarioHarness `--builtin pull`, 0-100 km/h before -> after: CP2 5.86 -> 3.91 s (published 3.85 s, motostatz), CP3 4.17 -> 2.75, CP4 3.53 -> 2.38, Hayabusa 2.90 -> 1.95, Big Twin 4.52 -> 3.92. Top speeds unchanged (+/-0.6 km/h).
- CP3, CP4 and Hayabusa are now quicker than published (about 3.0-3.5 s): a real one is wheelie- and grip-limited and the model has neither by default. Next gap, not addressed.
- Car gearbox input inertias (0.07-0.12 kg m^2) look high too; not changed, not measured.

## 2026-10-15 — Dual-clutch upshift spark retard (timeboxed)

- Retard of up to 20 deg while the oncoming clutch pulls the engine down, released with the slip (DriveScenarioHarness `--dct-retard`, 2JZ dual clutch, flat-out pull, 0 vs 20 deg). The advance reaches the ECU's -10 deg floor on every loaded upshift (control: 4-7 deg).
- Sync time: 237.5 -> 225, 216.7 -> 208.3, 216.7 -> 204.2, 237.5 -> 200, 308 -> 238 ms (gears 1-2 to 5-6). Peak wheel torque unchanged (6,471, 4,634, 3,592, 2,742, 2,137 vs 2,151 Nm): the clutch sits at its 760 Nm capacity through the pull-down either way, so the retard only shortens the push (-4 % impulse at 85 % of redline, EngineLab.ShiftStyle).
- EGT peak +1 to +3 degC: the retard window (0.2 s) is shorter than the EGT lag.
- Kept (no catalogue engine uses a dual clutch, default sound unchanged). Not listened to: whether the late burn gives the "DSG fart" is the owner's ear. No production retard calibration found to compare.

## 2026-10-15 — Cruise control and the automatic shift schedule, driven

- `DriveScenarioHarness --builtin cruise --automatic 1` (60 % pedal, set at 100 km/h, brake at 40 s). First version: the 2JZ ran to 116 km/h, because the integral started at the 60 % accelerating throttle and bled at 0.03/s per m/s. Added: past the set speed and still gaining, the throttle falls at 0.5/s (and the mirror case). Toy-car test: peak 111.1 -> 103.0 km/h.
- After, the gearbox shifting itself (the scenario's scripted rpm upshifts are now skipped under `--automatic`): peak 106.7 (2JZ), 107.9 (CP2), 101.6 (TDI), 108.6 km/h (LS3); then mean |error| 0.67 / 0.05 / 0.22 / 0.87, max 1.42 / 0.70 / 0.40 / 2.05 km/h. Gains are choices, not fits to a real controller.
- Upshifts at 60 % pedal, one gear at a time: 2JZ 4,601-4,768 rpm, CP2 5,994-6,032, TDI 3,263-3,427, LS3 4,068-4,507; under cruise the LS3 lifts up to sixth at 2,308. Dual-clutch 2JZ test: flat out 6,581-6,769 rpm (limit 7,000), 25 % pedal 2,660; braked from sixth to a stop, back in first, lowest 629 rpm.
- Reference: MT-07 0-100 km/h 3.85 s (MotoStatz), 0-60 mph 3.80 s (MCN 2014); EngineLab CP2 5.86-6.35 s. Not changed yet (plan E5).

## 2026-10-15 — Standing starts after the driver's clutch took over the shift

- `EngineLab.StandingStartSettledIdle` failed after B1: the I5 stalled at 25 s. Cause, one factor: a gear selected with the clutch held now engages at once, so the scripted 0.9 s pedal ramp loaded the engine from t = 0 (before, the timed selection held it out for 0.18 s). I5, 8 launch times: 2 stalls, lowest 241-294 rpm; ramp held at 0 for the first 0.18 s: 0 stalls, 383-462 rpm.
- Fix in the scripted driver, not the driveline: the pedal stays down for the gearbox's shift duration, then ramps over 0.9 s. EJ25, Aircooled, I5, Big Twin over 8 launch times each: 32/32 launch, lowest 595 rpm (Big Twin). The whole catalogue launches at 4 and 25 s, LS3 included: the three declared stalls are removed.
- Not measured: a human's real clutch timing; the launch is gentler than before, so these tests no longer cover a clutch dumped from the first frame.

## 2026-10-15 — Drive-scenario harness: first runs on the CP2

- New `EngineLabDriveScenarioHarness`, through the product's coupling (`advanceVehicle`). The shift, loaded-acceleration and afterfire harnesses now use it too: before, they skipped the cooling air, and two of them skipped the quickshifter cut and the blip. Their ctest gates still pass.
- CP2 `pull` (launch, upshift at 9,000 rpm): measured engine/road ratio within +0.13 to +0.37 % of the authored ratio in every gear (clutch slip, tyre). Manual gearbox: same within 0.4 % (gear 3 -0.05 %). **"The quickshifter changes the gear spacing" does not reproduce on the catalogue CP2.** Still open: an engine or setting the owner used.
- Same run: 0-100 km/h 5.86 s from first motion (manual 5.85), top speed 204 km/h. Injectors open for 99 % or more of their window for 9.3 s of the 45 s. Knock retard of 0.5° or more for 3.6 s. Nothing compared with a real MT-07 yet.
- CP2 `downshift-clutch` with `--blipper 1`: the blipper opened the throttle for 93 frames (0.39 s) with the clutch pulled. Bug confirmed, to be fixed in B1.
- Not measured: any other engine; whether the 5.86 s is a driveline-inertia problem (plan E).

## 2026-10-14 — Blind listening of the valve noise and the IR, and the fine-mesh question

- Owner, blind, one trial per pair, CP2 Full System clips (`--valve-noise`, `--impulse-response`). Valve turbulence noise: no preference at idle; on the rev the control was preferred ("deeper, less muffled"). It stays off.
- Stairwell IR at the default convolution 0.45: no difference heard at idle or on the rev, as its 22 dB margin under the dry sound predicts. Free field stays the default. Not tested: a fully wet chain.
- Earlier blind listening, recorded here: the owner preferred the rev without the output stage (`--output-stage`). Not adopted.
- A private mesh ablation of the other simulator (owner's captures, kept out of the repo) found its default mesh not converged in the 1-2 kHz band, and no sign that a finer mesh is what the owner hears. The 4 cm lockstep prototype is not pursued.
- Same analysis on EngineLab CP2 at 3,148 rpm, steady part only (a render starts with a ~5,500 rpm transient 15 dB louder: skip the first 4 s): energy above 2 kHz -50 dB of total, tilt -9.8 dB/oct, crest 10.8 dB, cycle-synchronous share 93.7 %.
- Merlin spike: `EngineLab.AudioRender` (runtime wiring) failed 4 times in ~17 runs on this branch: Merlin at 3,106 instead of 3,040 rpm, observer up to 4,092 Pa. On `main` (c423400) its 2nd run failed the same way (3,090 rpm, preLimiter 1.53). Pre-existing; cause found 2026-10-17.
- Not measured: anything against a real recording, which remains the arbiter.

## 2026-10-13 — Valve turbulence noise, and the first IR clips

- The other simulator's turbulent valve-area modulation (4 RBJ low-pass sections, f_c = clamp(0.35 v/d, 100, 3,500) Hz, depth 0.3, collapse on fast opening) re-expressed as `ValveTurbulenceNoise`: a Norton mass-flow source beside each exhaust valve's high-band source, own noise per valve. Its tests reproduce the analysis's measured deviations (1.0 / 3.0 / 5.7 %) and fail with 2 sections or a 10x smaller collapse. Off by default; `--valve-noise-ab`.
- Seven points: level -0.03 to +0.04 dB; shape 1.05-3.47 dB from valleys filled between harmonics (worst band +4.0 to +9.4 dB, anywhere from 25 Hz to 2 kHz); crest +0.2 to +1.2 dB; cycle-to-cycle COV up (LS3 1.2 -> 5.0 %, CP2 Full System 4,000 rpm 0.8 -> 1.8 %); periodicity -0.07 at most (LS3); tilt within 0.9 dB/oct.
- Blind clips, CP2 Full System (`AbClipRenderer --valve-noise`): the noise is 21-22 dB under the clip (correlation 0.996). Offline renders are deterministic (two controls bit-identical), so that is the noise alone.
- IR: no catalogue engine authors one, so the application plays in free field. The owner's stairwell IR (provenance unknown, not in the repo) on every path at the default convolution 0.45 is 22 dB under the dry sound; its 0.6 s cut is 60 dB from the 3 s file. Clips: `--impulse-response`.
- Not measured: realtime cost with the noise on (per-sample trigonometry per valve), intake valves, any listening result.

## 2026-10-13 — Ambient far-field density by default, monitor full scale 140 dB

- Owner-approved sound change: the outlets now radiate with the live ambient air density (p / R T from the runtime's ambient state); `setOutletFarFieldDensity(0)` restores the duct medium. Catalogue at 88 % of redline: +2.5 to +11.7 dB, the CP2 least (coolest gas).
- At the old 134 dB full scale the CP3 (~210 Pa peak) and the Merlin drove the safety limiter. Full scale moved to 140 dB (282.8 Pa peak): every catalogue engine stays under the 0.82 knee except the Aircooled, whose spikes (crest ~24 dB) were there before (29 soft-limited samples and 1 clamp at 7,166 rpm, against 377 / 32 before the change). The CP2 keeps roughly its old on-screen level.
- `EngineLab.AudioRuntimeDiscontinuity` (Merlin, 80 ms stall) failed in 2 of ~26 runs: the engine took another trajectory (3,116 instead of 3,040 rpm) and the observer peaked at 454 Pa (preLimiter 1.63; 117 Pa and 0.35 otherwise). Physics does not read the audio, and the duct density is at most 4.9 dB under ambient there (measured, Merlin 3,000 rpm), so the old calibration would have put that peak at ~1.85: a pre-existing intermittent spike, not caused by this change; cause found 2026-10-17.
- Not measured: absolute SPL against a calibrated recording (a stationary-noise homologation figure is the cheapest check).

## 2026-10-13 — Pressure-release outlet versus the Levine-Schwinger load

- The other simulator terminates its pipes with an imposed pressure and no radiation load (R = -1 at every frequency). New switch `setOutletPressureRelease`, off by default (renders byte-identical); `GeometrySensitivityHarness --pressure-release-ab`, same seven points.
- Level: -0.04 to +0.42 dB. Shape 0.47-3.45 dB. Worst band: +7 to +10 dB at 5-10 kHz on CP2 Full System, K20 and LS3; +1.5 to +2.5 dB at 1.25-2 kHz on CP2, Hayabusa and 2JZ. The tailpipe keeps the resonances that the load would radiate away. Crest -0.1 to +0.9 dB, tilt up to +0.9 dB/oct, periodicity unchanged except the 2JZ (0.77 -> 0.72).
- Verdict: it moves the sound away from the other simulator's character (crest rises), and only above the plane-mode cutoff, where a 1-D pipe means nothing physical. Kept off; only a real recording could argue otherwise.

## 2026-10-13 — Outlet far field: duct density versus ambient air

- The outlet monopole is p = rho dQ/dt / (4 pi r) with rho = the path's duct medium (hot gas). Outside the mouth the field is in ambient air and Q is continuous across the interface, so the textbook rho is the ambient one. New switch `setOutletFarFieldDensity`, off by default (renders byte-identical); `GeometrySensitivityHarness --radiation-density-ab 1.2`.
- Same seven points as the output-stage entry, same render otherwise. Exhaust level: CP2 Full System +4.0 dB at 4,000 rpm and +4.5 at 7,000; CP2 +4.4; K20 +8.2; 2JZ +9.4; LS3 +9.9; Hayabusa +10.0. That implies a duct density of 0.4-0.75 kg/m3, i.e. a mean path medium of ~490 K on the CP2 and 740-930 K on the others. Leveler never engaged.
- Shape 0.9-4.1 dB, but not from the physics of the main band: on the CP2 at 6,000 rpm, 50 Hz-1.6 kHz moves as one block (+-1 dB), and above 2 kHz it rises 1.5-4.4 dB less. That is the outlet jet noise (own jet density, not switched) taking a smaller share. Crest, periodicity and tilt are unchanged within 0.6 dB, 0.01 and 0.35 dB/oct.
- At equal loudness, then, this is mostly a balance change against the jet noise, plus a level that grows with gas temperature. It does not explain the other simulator's character. Not changed by default: it is a sound change and needs the owner's go-ahead. The absolute SPL is still unchecked against any calibrated recording.

## 2026-10-13 — How much character an output stage alone gives

- Spec from a static analysis of another simulator, whose sound the owner prefers: after its room convolution it ends in a level-normalising gain (5 Hz envelope, 4x attack, 1 s hold, gain <= 10) into a tanh, on by default. Its August 2026 measurement gave crest 7.4 dB, periodicity 0.92, tilt -4.6 dB/oct (archive). Re-expressed as `AutoGainSoftClipper` (off the default path).
- Step 0, today's EngineLab at steady wide-open throttle (`GeometrySensitivityHarness`): periodicity 0.77-0.98, crest 7.8-14.5 dB, tilt -4.9 to +2.3 dB/oct. The August EngineLab figures (crest 18-25, periodicity 0.38-0.50) are stale.
- Step 1, `--output-stage-ab`, same render with the stage at +40 dB drive (at 0 dB the gain sits on the x10 cap, so the stage is just a gain; shape 0.09-1.72 dB). Crest raw -> staged: CP2 Full System 4,000 rpm 11.2 -> 6.2, 7,000 rpm 14.5 -> 7.0; CP2 6,000 11.3 -> 6.3; K20 6,000 9.5 -> 6.1; LS3 4,500 11.3 -> 6.3; Hayabusa 7,000 7.8 -> 5.4; 2JZ 4,500 11.1 -> 6.4. Band shape moves 1.3-3.4 dB; periodicity and tilt are almost unchanged.
- So the other simulator's low crest factor can come from its output stage alone, not from its gas dynamics. Blind clips: `EngineLabAbClipRenderer --output-stage "Full System"`.
- Not measured: any listening result, either simulator against a real recording, transients (idle, rev) beyond the clips, or the other steps of that spec (room response, outlet radiation, fine mesh).

## 2026-10-13 — A turbo fitted to any engine

- `sizedTurbocharger()`: laws fitted to the four catalogue turbos (turbine 0.028 mm² per L per redline rpm, within 10 %; inducer within 15 %). Boost by compression: 0.5 bar from 10.5:1, 0.7 from 9.5, 0.9 below.
- `EngineLabDynoSweepHarness --add-turbo`, 1,000 rpm steps, every engine without forced induction: peak power +38 to +85 % (CP2 54 -> 80 kW, K20A 166 -> 229, LS3 315 -> 440, Aircooled 198 -> 368 at 0.7 bar), lambda 0.84-0.90, boost at target except the Big Twin (1.79 for 1.66: no collector, so the older outlet turbine, whose work is overstated).
- `EngineLabThermalHarness --add-turbo`, CP2, 3 passes: 61.5 -> 92.1 kW, knock mean 0.30 (heavy 0 %), no damage; the ECU retards from 30.5 to 24 deg.
- `EngineLabRealtimeBudgetHarness --free-run --relative-rpm 0.8`, alternated: a fitted turbo costs 0-5 %; lowest LS3 1.24 (1.27 without).
- `EngineLab.TurboFit`: CP2 at 7,000 rpm, torque x1.41 for a charge density x1.28, lambda 0.88, peak knock 0.41.
- Not measured: spool against a real kit, any real turbo conversion's curve. The LS3 and Big Twin turbines are not drawn; the Aircooled's second bank turbine is not drawn.

## 2026-10-13 — Shift styles: quickshifter, blipper, dual clutch

- `EngineLab.ShiftStyle`: real engine, ECU and driveline coupled as the runtime couples them; 1 -> 2 at WOT, 70 % of redline. Gap = time the wheel torque stays below half the new gear's.
- CP2 manual (lift + clutch, 0.18 s): gap 54 ms, synchronised at 204 ms. Quickshifter (65 ms ignition cut, clutch in): cut 62.5 ms (240 Hz frames), spark really off, gap 21 ms, synchronised at 67 ms, 0.3 % off the gear's speed.
- 2JZ manual: gap 62 ms, sync 379 ms. Dual clutch: no gap (wheel torque never below the new gear's), sync 200 ms; no torque reduction during the inertia phase, so the wheel gets a push.
- CP2 3 -> 2 on a shut throttle: blipped, engaged at 0.988 of the gear's speed, slip 35 rpm; through the clutch, 0.756 and 1,517 rpm. Disabling the styles fails the test.
- Not measured: any real quickshift or dual-clutch shift trace; the 15 ms dog change is a guess. Wet cut pops depend on the CP2 afterfire (nothing burns at 800 K).

## 2026-10-13 — Stalls after a blip: three ECU causes

- `EngineLabPhysicsPerfHarness --freerev 1 --release S --settle S` (new `--settle`, fuel and air columns). 2JZ, warm, WOT blip then release: down to 516-548 rpm (760 target). After the fuel-cut resume the charge reference ran 20-30 % above the trapped air for ~1.5 s (AFR 10-12); lambda learning took the idle trim 0.81 -> 0.57 in 2 s, then the refilled manifold ran AFR 17.4, 30 % misfires. Learning now holds 2 s after a resume.
- That exposed a hung idle: the dashpot was held above 1.3 x idle, so a fuelled EJ25 sat at 1,200 rpm on its air for good (CP4 1,814 and TDI 1,161-1,288 already did in the base). Held now only while coasting down (losing > 5 % of idle per second).
- Blipped 6 s after the start the fuel cut was inhibited (after-start phase): the 2JZ coasted from 6,800 rpm fuelled at lambda 0.27, 90 % misfires; LS3, Merlin, Radial stalled. Opening the throttle past 0.2 now lifts that inhibit, as for afterfire engines; ending the whole start phase also stopped its lambda learning and moved the default renders (EL-20 dyno 3,820 -> 4,843 rpm). Renders now unchanged except the Big Twin rev return (771 -> 776 rpm).
- Catalogue, WOT 0.5 / 1.2 s after 6 or 30 s of idle: base 6 stalls, worst warm 0.67 x idle; all three: no stall, lowest 0.83 x idle (Aircooled), idle back. Each change alone left a stall (Radial, LS3). `EngineLab.IdleStabilityRegression` gained these blips; base fails on 12 engines.
- Not reproduced in the application itself, nor with a gear engaged.

## 2026-10-13 — Knock model checked: not physical, not changed

- Trace of every auto-ignition, one dyno pass: 2JZ 2,029, K20A 1,877, CP2 875 events, at 50-95 % burned. The integral reads the mean chamber temperature (1,850-3,070 K, clamped to 1,500) where the end gas is the unburned charge, isentropic from the flame start: 830-1,200 K. The delay fit is 2-5 x slower than Douaud-Eyzat (18 vs 8.2 ms at 850 K, 20 bar, RON 95); the two errors offset.
- Isentropic end gas alone: no knock on any engine (peak power -0.7 to +1.1 %), none even at RON 80. Plus Douaud-Eyzat: CP2 clean at 98, light knock from 95 (realistic); 2JZ and K20A knock 0.33-0.44 whatever the octane, still 0.2-0.36 with an integral knock control at its 12 deg stop: their end gas (1,000-1,200 K) is hotter than measured engines at knock onset (~850-950 K). The charge temperature is the next suspect, unverified.
- Kept as it was: light knock on every engine at WOT (mean 0.12-0.37), no damage since the earlier fix, held by a proportional retard (`knockLevel * 12`).

## 2026-10-13 — Air-cooled oil thermostat; why turbo engines overheated

- Big Twin ran at 34-47 degC on the dyno: its fins were always fully open, so its temperature scaled with load. Air-cooled engines now get a tenth of their fin cooling always and the rest through an oil thermostat (85 -> 100 degC). Realistic, cell fan, 5 passes: Big Twin 42 -> 83 degC, 74 after 60 s of idle, 89.6 on a ride; Aircooled 48 -> 90, ride 87. `EngineLab.LiveTuning`: Big Twin cruise 87.5, flat out at 30 m/s 97.3 degC.
- The owner's overheating (turbo engines, hot by pass 5, big loss at 8-10) reproduced with the former free model from 3 min of warm-up: 2JZ +8 degC per pass, 32.7 -> 100.3 degC at pass 10 (EJ25 90.7, I5 99.8): heading for the 108 degC derate and 115 degC damage. New model, same run: 2JZ, EJ25, I5 level off at 92.9-93.5 degC (oil 105-110).
- Power still drifts -1.2 to -1.9 % over 10 passes. Probe at 80 % of each ramp: boost, AFR, advance and knock constant; exhaust wall 154 -> 608 degC (2JZ), 143 -> 538 (CP2), still climbing; VE -0.9 %, torque -1.2 %. Heat soak of the pipes, physical. Harness renders all start with cold pipes.
- Not compared with any recorded air-cooled temperature or dyno-session power trace.

## 2026-10-13 — Realistic temperatures (EngineThermalModel)

- The former free model stalled cold: a car-sized 180 kJ/K on every engine and radiator air through a closed thermostat (CP2 36.8 degC after 5 passes). Now: capacities from displacement, a thermostat (82-94 degC), air of the vehicle's speed (12 m/s of cell fan on the dyno), a fan on at 100 / off at 95 degC, all friction heat into the oil, heat shares 24 % / 5 % (Heywood, coolant 17-26 %). Sizes are plausible, not measured.
- `EngineLabThermalHarness --realistic`. CP2 in still air, idle: 42 / 59 / 73 / 85 degC at 5 / 10 / 15 / 20 min (simulated idle ~2.8 kW released). With the cell fan, 5 passes from cold: CP2 81 then 94 degC (oil 113), K20A 62 -> 94, LS3 49 -> 91; 60 s of idle after: ~80; a 60 s ride at 25 m/s, half redline, quarter throttle: 86-87 degC. Peak power within -1.8 % (CP2 pass 2, run-to-run spread; no damage).
- Air-cooled Big Twin with the cell fan: only 34 -> 47 degC over the passes, 29 degC after 60 s of idle: probably too cool; its fins are sized like a radiator. Not changed.
- Not compared with any recorded warm-up or temperature trace. Default (regulated) behaviour and sound unchanged.

## 2026-10-13 — Warm standing starts: three engines with no margin

- `EngineLab.StandingStartSettledIdle` (launch at 25 s, 1st gear, WOT, clutch over 0.9 s) failed once engines ran regulated at 90 degC: the EJ25 stalled. New `--unregulated-thermal` flag in `EngineLabLoadedAccelerationHarness` for the one-factor comparison.
- EJ25, 41 launch times from 6 to 34 s: 9 stalls warm, 0 free (cold, ~25-30 degC). Catalogue, 8 launch times each: warm EJ25 0/8, Audi I5 1/8, Big Twin 2/8; free 0 everywhere. All three already sagged to 240-440 rpm cold.
- Trace (EJ25, 25 s): the first cycle after the tip-in gets 67 % of its metered fuel (the late part of the extended pulse stays in the port), AFR ~18 cold and ~19.7 warm; at 19.7 the misfire chance is 45 %, two misfires in a row and the clutch drags it under 220 rpm. Min AFR after: ~10 cold, ~11.2 warm, consistent with the lost warm-up enrichment (x1.09-1.12). Not proven to be the only difference.
- Declared as a known stall (EJ25), not compensated. Stalls are the next step, with the owner's scenarios; an asynchronous tip-in pulse is refuted cold and would need new evidence warm.

## 2026-10-13 — Light knock no longer wears the engine

- `EngineLabThermalHarness` now prints knock per pass. At WOT every engine knocks lightly through the whole pass, held there by the ECU's proportional retard (`knockLevel * 12` deg): mean CP2 0.14, 2JZ 0.27, LS3 0.37; above the 0.45 "severe" threshold 0 % of the pass (LS3 0.2 %).
- Damage counted that light knock linearly: +0.003 to +0.005 per pass, a permanent 0.82 x damage efficiency loss. Now only knock above 0.45 counts, scaled so full knock keeps its rate. 2 passes: damage 0.006 -> 0 (CP2), 0.011 -> 0 (LS3). `EngineLab.LiveTuning`: 2JZ at full load 8 s, knock mean 0.34, damage 0 (0.0029 without the fix).
- Sound: within the first pass the old damage reached 0.003, at most -0.02 dB by efficiency (computed, not rendered). The ECU's knock control itself is unchanged: a real one retards in steps and holds, it does not sit at constant light knock. Not measured against a real knock trace.

## 2026-10-13 — Engine temperature over a dyno session; regulated by default

- New `EngineLabThermalHarness`: idle, 5 app-like dyno passes (entry to ceiling, 500 rpm/s), 20 s of idle between, 120 s of idle after. Deterministic.
- Before, every engine started at 22 degC (car-sized thermal mass, 180 kJ/degC, on all but Merlin and Radial). After 5 passes: CP2 36.8, K20A 54.2, 2JZ 65.2, LS3 77.7 degC (highest of 16); 120 s of idle then cools 0 to 2.9 degC. The owner's "excessive after 5 passes" is NOT reproduced from a cold start; harness renders were all of a cold engine.
- Power over 5 passes: -0.0 to -1.2 % (Lab twin -4.3 %), cold and warm alike. It follows `damage`, +0.003 to +0.006 per pass from end-gas knock at WOT (`knockLevel * throttle * 0.0012`), which lowers efficiency by 0.82 x damage for good. Fixed the same day (light knock no longer counts).
- Now `thermal.regulated` (default): coolant 90, oil 100 degC from the start. Sound, cold -> warm: CP2 at 6,000 rpm +0.32 dB, shape 0.57 dB; AudioRenderHarness catalogue within +0.24 / -0.62 dB (EJ25), brightness within 0.009. Not compared with a recording.

## 2026-10-13 — Wastegate holds a gauge boost

- The boost controller held `wastegate_pressure_ratio` as a ratio to ambient: up high it lost as much manifold pressure as an unblown engine. It now holds the sea-level gauge boost, like a spring against the atmosphere. Bit-identical at 101.325 kPa (the added term is exactly zero).
- `EngineLab.LiveTuning`, 2JZ held at 60 % of redline, pressure only: gauge boost 90.19 kPa at sea level, 70.76 -> 90.19 kPa at 79.5 kPa; brake torque at 79.5 kPa 358.5 -> 382.8 Nm (sea level 457.4). The new check fails without the fix.
- 2,000 m and 35 degC: 2JZ 455 -> 339 Nm before, 455 -> 362 Nm now (-20 %). Not compared with a measured altitude curve; turbo overspeed up high is not limited.

## 2026-10-13 — Do the cams change the sound?

- Owner report: editing valve lift/duration changes the engine but not the sound. `EngineLabGeometrySensitivityHarness --cam-duration-delta D --cam-lift-scale S --wav-out`, then `--wav-reference`, CP2 held at 6,000 rpm, 0.85 throttle, every cam (low and high profile).
- Cams -40 deg and lift x0.7 (CP2 torque -22 % in LiveTuning): level -0.74 dB, shape 4.07 dB, worst band -11.8 dB at 315 Hz. Cams +40 deg, lift x1.2: -0.69 dB, shape 2.38 dB, worst -9.1 dB at 200 Hz.
- Same run, exhaust variants for scale: no muffler body 2.70, long primaries 4.08, independent pipes 12.0 dB of shape. The cams do reach the sound, as much as a modest exhaust change; the level barely follows the torque.
- Not measured: idle (a long-duration cam's lope), light load, any real recording of a cam change. The harness's default `CP2` filter had become ambiguous (two CP2 engines); it is now `Yamaha CP2`.

## 2026-10-12 — Live flywheel, camshafts and air

- `EngineLab.LiveTuning`, deterministic, built / swapped / untouched engines. Flywheel x2 taken at idle: free rev to 75 % of redline CP2 0.938 / 0.925 / 0.525 s, 2JZ 1.404 / 1.421 / 0.842 s.
- Cams 40 deg shorter, 30 % less lift, taken at 6 s at 60 % of redline: CP2 55.16 / 55.14 (55.13 over 2 s) / 70.84 Nm, K20A 142.2 / 142.1 / 222.6 Nm. Each fails without its copy into the running configuration.
- Air of 2,000 m (79.5 kPa) and 35 degC: CP2 51.6 / 51.5 / 70.8 Nm (-27 %), 2JZ 338.7 / 339.3 / 454.7 Nm (-25 %). The turbo's boost target is a pressure ratio to ambient, so it does not hold manifold pressure up high as a gauge-referenced wastegate (about -11 % MAP) or an absolute-MAP controller would. Not changed; not compared with a measured altitude curve.
- Gearbox: K20A driveline, first gear, engine held at 2,000 rpm, final drive x1.3 at 1 s: 3.093 / 3.085 / 3.997 m/s.
- Not done: the pipes' outer walls keep the built ambient until a restart; the 3-D edits were not driven by hand.

## 2026-10-12 — Turbo mid pipes, behind the turbine

- `turbo_downpipe` (2JZ, I5, TDI) and the EJ25's `compact_sport` get the K20A's 2.2 m mid pipe: routes ~1.2 -> ~3.4 m. Same binary, catalogue copies with and without, deterministic harnesses.
- Spool t90 (`TurboDownstreamAuthorityHarness --spool`), 3,000 rpm: 2JZ 2.263 -> 2.321, EJ25 2.358 -> 2.392, I5 1.979 -> 1.887, TDI 0.979 -> 0.979 s; 2,000 rpm within 2 %. `DynoSweepHarness`: within 1 % from 3,000 rpm up (top end -0.6 to -1 %, back pressure +4 to +7 kPa), EJ25 -2.4 % and I5 +8.5 % at 2,000. CatalogReference: every gap within 0.5 point (2JZ power +11.8 -> +11.4 %, I5 -6.4 -> -6.7 %). CatalogBoostHold passes (swing <= 6.7 %).
- Realtime free-run, alternated, minimum: default point 2JZ 1.67 -> 1.79, EJ25 2.08 -> 1.83, I5 1.91 -> 1.86, TDI 2.24 -> 2.03, K20A control 1.72 -> 1.79; 95 % of redline with audio 2JZ 1.49 -> 1.35, EJ25 1.64 -> 1.60, I5 1.56 -> 1.44, TDI 2.11 -> 1.88. `--runtime-blip`: lowest 0.992, worst lateness 1.8 ms (without: 0.994, 8.6 ms).
- Sound, `AudioRenderHarness` catalogue point: RMS 2JZ +5.8 dB (brightness 0.138 -> 0.086), I5 +3.1, EJ25 -2.1 (0.096 -> 0.132), TDI -4.0 dB (0.080 -> 0.127); K20A control identical. One held point each: not a level over the range, and not compared with any recording.
- `TurboDownstreamAuthority` (tailpipe sweep 45-95 mm, 2JZ): behind the mid pipe 76 -> 95 mm reads +0.5 kPa (tolerance 0.5 -> 1.0), and the raised-target stress holds 3.42 even at 45 mm (gate 0.003), so its authority is now the gate (0.003 -> 0.27) when boost cannot rise. A turbo-back sweep (mid pipe at the tip's bore) was rejected: a 95 mm pipe between 64 mm sections raises back pressure, the K20A control's too (101.0 -> 107.4 kPa).

## 2026-10-12 — Mechanical layer off by default

- Owner's listening: the layer adds nothing and an unpleasant sound; always switched off. Every voicing `mechanical_gain` (0.66-1.18; CP2s already 0) and the code defaults (0.70) -> 0; the fader stays. The starter leaves the mechanical bus for a fixed 0.70 (`EngineLab.RealtimeRegression`: starter RMS 0.0484 at fader 0 and 2; before, 0 at fader 0).
- `AudioRenderHarness` catalogue point, old binary + old voicing vs new: RMS -5.7 dB I5, -5.3 2JZ, -2.8 Hayabusa, -1.2 LS3, -0.9 K20A, -0.8 Merlin, -0.4 EJ25, -0.3 Radial and APL, -0.2 CP4, 0 to +0.1 Big Twin, Aircooled, CP3, TDI, CP2s. Brightness falls on every engine that changes (2JZ 0.177 -> 0.138, K20A 0.180 -> 0.081): at these points the layer was mostly upper band, not low. The starter is now audible while cranking where the voicing had 0 (CP2 peak 0.095 -> 0.115 in the first 1.3 s).
- The layer was compensating: the synthetic EL-R5 radial goes from 48 % to 0.9 % of its energy above 250 Hz without it (catalogue Radial 5 % either way). The synthetic fixtures keep 0.70 so the harness still checks the renderer with every layer.
- Not compared with any recording. Not measured: what the owner hears as "low" (the harness shows the layer bright at these points).

## 2026-10-12 — Live connecting-rod length

- `resizeConnectingRods` moves the deck with the rod, so the clearance volume and the compression ratio stay; the live resize now carries the rod (the kinematics already read it live). `LiveCylinderResize`, rod + 0.3 stroke, 60 % of redline, brake torque over the last 3 s: CP2 115 -> 135.6 mm, built 71.50, at once 71.80, over 2 s 71.75, untouched 70.74 N.m; K20A 139 -> 164.8 mm, built 223.96, at once 223.93, ramp 223.92, untouched 222.73. Without the simulator carrying the rod: 70.74 (fails). The longer rod gains ~0.5-1 % at that point; not compared with any measurement.
- Not done: the rod keeps its mass (a real longer rod is heavier); the structural radiator keeps the built rod length until a restart. The 3-D edit was not driven by hand.

## 2026-10-12 — TDI boost controller limit cycle at full load

- Owner's report: the TDI "misfires" at WOT from 2,500 rpm, the dyno curve full of quick dips. `DynoSweepHarness`: held brake torque swing 13 % at 2,500, 32 % at 3,000 rpm (base before the turbine move: 3-7 %); other turbos within 9 %. No misfire: `PhysicsPerfHarness --trace 3000 --watch` (new turbo columns) shows a 4 Hz cycle, gate 0 -> 0.45, back pressure 148 -> 239 kPa, turbine 2 -> 16 kW, cycle torque 322 -> 352 N.m.
- Cause: the proportional gate (fully open 0.08 above its ratio) against a turbine that now loses its inlet pressure as soon as the gate opens: loop gain ~30 on a 4e-5 kg.m2 shaft. A gate lag of 0.1 / 0.3 s made it worse (swing 302-358 / 292-356 N.m); band 0.25 alone settled it (339-346) but droops.
- Fix: PI, band 0.25, integral 0.5 s, anti-windup. Swing <= 6 % on all four turbos (TDI 4 %); boost exactly at the gate ratio (2JZ 1.890, EJ25 2.050, I5 2.450, TDI 2.250); spool t90 within 1 %; TurboDownstreamAuthority boost 1.890 at every outlet. Sound vs the previous build: RMS -4 to +1 %. CatalogBoostHold now fails a 15 % swing (P gate: 30.5 %).

## 2026-10-12 — Turbine on the collector face, in the gas network

- The turbine is a restriction face on the collector's outgoing face (orifice from the collector's stagnation state; turbine share of the flow gives up `eta cp T0 (1 - (p_out/p0)^k)`, removed from the downpipe's energy; no jet on the receiving side). `EngineLab.RestrictionFace`: choked junction face -0.2 % vs isentropic, work 37.7 kJ/kg under its 37.9 ceiling, energy closed to 3e-12, cooling 33.9 K vs w/cp 37.5 K, half share 0.50 of the work. With the jet kept on the receiving side: work over the ceiling, half share 0.66.
- At the old areas (700 mm2) the spool at 3,000 rpm (`TurboDownstreamAuthorityHarness --spool`, t90) went 1.09 -> 3.60 s (2JZ), 1.69 -> 5.29 (EJ25), 1.98 -> 5.55 (I5): the old outlet model drove the shaft from the peak exhaust pressure, and the areas had been fitted to it. Re-fitted to the rated curves (`DynoSweepHarness`), not measured: 2JZ 600, EJ25 500, I5 450, TDI 320 -> 280. t90 then 2.25 / 2.34 / 1.98 / 0.98 s (TDI 0.89 before); CatalogReference and CatalogBoostHold pass.
- Authority harness: outlet monotone tolerance 0.05 -> 0.5 kPa (pulse-resolved outlet), boost hold within the gate's 0.08 proportional band, shaft balance within 2 % of turbine power (was 0.26 kW at the 45 mm stress point).
- Realtime free-run, 4 alternated rounds, minimum: 2JZ 1.61 -> 1.60, EJ25 1.92 -> 1.91, I5 1.77 -> 1.83, TDI 2.18 -> 2.25, K20A control 1.82 -> 1.80; at 95 % of redline 1.59-2.34 -> 1.59-2.27. `--runtime-blip` with audio: lowest 0.992, worst lateness 4.7 ms (TDI lift-off).
- Sound (`AudioRenderHarness` catalogue point, rpm floats with torque so it is not held): RMS 2JZ -1.6 %, EJ25 -27 %, I5 +16 %, TDI +42 %; low-band share 2JZ 14 -> 45 %, EJ25 43 -> 84 %. The turbine move alone (old areas) gave -0.5 / -16 / +33 / +50 %. Not compared with any recording.
- Not done: turbo mid pipes (the downpipe is now cold side); several paths each with a turbine (supported, no catalogue engine uses it).

## 2026-10-12 — Individual throttles as a restriction face in the runner

- New 1-D primitive: a plate on a duct-to-duct face (isentropic orifice fed by the approaching cell's stagnation state; jet re-expanding against the loaded face; the supplying side keeps its own momentum). `EngineLab.RestrictionFace`: choked flow -0.2 % vs isentropic (-1.4 % with the throat momentum on the supplying side), full bore +0.003 % vs no plate, shut 0, mass to 1e-14.
- CP2 with `individual_throttles: true` only (plate 66 mm from the valve, same bores and Cd 0.72, plenum fed through the bores fully open). `DynoSweepHarness`: VE -2 to -8 % above 3,500 rpm; torque -10 to -19 % with the ECU reading the cell behind the plate (62-70 kPa at WOT), -5 to -10 % reading the mean of the valve-side duct (83-87 kPa), kept. The peak stays at 3,500-4,000 rpm: no help for the shape gap.
- Idle (`PhysicsPerfHarness --idle`, 20 s): 1,399 rpm (1,383-1,419) vs 1,408 (1,389-1,439). Free-run at 5,000 rpm: 2.66 vs 3.18 (more cells). Catalogue WAVs byte-identical (no engine uses it).
- Not done: the CP2 is not switched; the audio intake network and the 3-D view still draw one plenum throttle; the ECU still reads a pressure, not the throttle angle.

## 2026-10-12 — Mechanical layer over the exhaust above 1 kHz, catalogue-wide

- Owner's listening: the CP2 sounds better with the mechanical slider at 0. `GeometrySensitivityHarness` (WOT held, runtime default mechanical gain 0.70, voicing not applied), mechanical stem minus exhaust stem per third octave:
- CP2 3,500 rpm: over the exhaust from 1 kHz up, by 20-44 dB at 1.25-5 kHz (12 bands of 28); 7,000 rpm: up to 10 dB at 2-5 kHz (4 bands). CP4 5,000: 9-18 dB from 1.6 kHz (14 bands). 2JZ 3,500: 24-47 dB from 1 kHz (22 bands).
- Reference (literature, not a recording): on a 125 cc motocross bike at full load the silencer is predominant from 500 Hz to 3 kHz, the cylinder a substantial contribution at 1-2 kHz (Astrup, IOA). A constant gain cannot match both CP2 speeds: the excess falls 30 dB from 3,500 to 7,000 rpm, so the layer's speed scaling is suspect, not only its level.
- Changed: CP2 and CP2 full-system voicing `mechanical_gain` 0.82 / 0.78 -> 0 (linear gain: the mix loses exactly the mechanical stem). `AudioRenderHarness` CP2 catalogue point (5,430 rpm): RMS 0.0150 -> 0.0146 (-0.23 dB), physics byte-identical. Not changed: the layer itself, the other engines.

## 2026-10-12 — CP4 below real time at the limiter and on lift-off: overlap drain

- Owner's report. `PhysicsPerfHarness --freerev 1 --release 4` (new step_ms, intake accepted/rejected columns): limiter 3.87 ms per 4.17 ms frame, lift-off 4.23 ms; 102k / 94k rejected intake substeps in 3.3 s / 1 s.
- Cause: during overlap the intake network subtracted the exhaust outflow handed over from the previous window (hot burned gas, ~6-10e4 W) from a chamber refilling with cold charge: energy to 0 K, every attempt rejected. Now the outflow leaves at its mass rate relative to the content, with the chamber's own composition and enthalpy, and caps the step. `EngineLab.IntakeMovingBoundary` fails without it (549 rejections, 5.6e-10 K).
- Second, separate: ring blow-by applied every 100 us instead of every sub-step (12 % of a CP4 limiter step); idle and cruise sub-steps are longer, bit-identical WAVs on 7 engines.
- Runtime with audio, `AudioRenderHarness --runtime-blip` (WOT 2-5.5 s, shut to 9 s), 3 alternated runs: lowest realtime factor on lift-off 0.73-0.80 -> 0.995, worst lateness 18 ms -> 1.8 ms. Whole catalogue after: >= 0.992 in both phases, worst 5.6 ms (2JZ).
- Effect: torque <= 1.1 % (CP4 6,750 rpm), peak 124.0 -> 123.2 kW; WAV level within 3 %, bands within 4 points. The two changes were not separated on the curves.
- Still counted: ~320 of 840 CP4 WOT frames late by under one frame (sub-frame jitter, absorbed).

## 2026-10-12 — Bike WOT torque shapes against Cycle World dyno traces

- `DynoSweepHarness` (250 rpm) against `tests/reference-data/measured-curves/` (rear-wheel), each curve divided by its own peak. Peak rpm, sim vs real: CP3 7,250 vs 7,000; CP4 9,000 vs 9,250; Big Twin 3,500 vs 3,000; CP2 4,000 vs 6,250. Shape RMS: CP2 7.5 %, CP3 6.6 %, CP4 12.7 %, Big Twin 7.1 %.
- Common to the three Yamahas: too much torque below the peak relative to it (CP2 +10 % at 2-3k, CP3 +11 % at 5k, CP4 +15 to +22 % at 3-6k, where the real CP4 has a flat 5-6k hole). Big Twin: -15 % at 5,000.
- CP2: VE is nearly flat (0.915 at 2,000, 0.988 at 7,000); gross IMEP per unit VE flat within 2 % from 4,000 to 8,000; FMEP 0.74 -> 2.63 bar and PMEP up to 1.2 bar at 9,000. The torque falls from 4,000 because friction and pumping grow while VE barely rises. Crank peak 74 Nm vs 67-68 Nm rated.
- One factor, CP2 intake runner 120 -> 240 / 360 mm: peak moves to 5,500 (VE 1.08 / 1.14 at 6,500 / 5,500) but 8-9k collapses (-11 / -29 % vs the trace); shape RMS 8.1 / 15.4 %. The CP2 full-system exhaust (a twin's 42 mm primaries) changes nothing (6.9 %).
- Not found: a single cause. Not measured: real CP2 VE, ignition and lambda at WOT; no catalogue value changed.

## 2026-10-12 — Individual throttle bodies as a small cell per cylinder: refuted

- Tried on the CP2 (real hardware: one 38 mm body per cylinder) with configuration only: two intake paths, each one throttle into a 0.05 L cell (the volume behind the plate), then the 120 mm runner. `DynoSweepHarness`, WOT, 500 rpm steps.
- Torque vs today's shared 1 L plenum: -3 % at 2,000 rpm, -15 % at 4,000, -30 % at 6,500 (48 vs 70 Nm), -54 % at 9,500; VE 0.98 -> 0.74 at 6,000.
- One factor, today's topology with the shared plenum at 0.1 L: -7 % at 4,000, -16 % at 6,000, -29 % at 9,000. The loss is the orifice dumping a pulsating jet into a small well-mixed cell (peak velocity ~3x the mean, loss as v^2). A real open plate sits in a continuous bore and recovers that pressure.
- So an ITB needs the plate inside the 1-D runner (a restriction face between two ducts, choked at idle), with the runner mouth on the airbox. Not built: it moves the MAP signal, the idle bypass and the ECU load the plenum carries today.

## 2026-10-12 — CP2 exhaust lengths: header and silencer do interact

- Owner's report: the sound is only right when header AND silencer are both very long. `GeometrySensitivityHarness --factorial primary|midpipe` (x2 each), CP2 held at 3,500 and 7,000 rpm, third octaves, interaction LL-LS-SL+SS.
- Null (same plan at x1.001): interaction RMS 0.7 dB (3,500) and 1.1 dB (7,000). Primary x silencer: 5.2 / 5.6 dB on the mix, 6.0 / 6.9 dB on the exhaust bus; long-both +13 to +18 dB at 250 Hz where neither alone does it. Midpipe x silencer: 2.1 / 4.3 dB. So the model is non-additive, mostly below 1 kHz; the header length matters more than the midpipe. Caveat: the brake holds each cell within ±130 rpm, the null within ±10.
- At 3,500 rpm the mechanical layer is 20-44 dB above the exhaust from 1 kHz up (12 of 28 bands): the mix does not move there whatever the geometry (pipe x2 changes the exhaust bus by +8 dB at 1.6 kHz, the mix by 0.0). At 7,000 rpm only 4 bands are masked.
- Removing the silencer changes the unweighted RMS by +0.07 dB (3,500) and +0.29 dB (7,000); the exhaust bus rises up to +9 dB at 1.6 kHz. Not compared with a measured insertion loss (none in hand, and the RMS is dominated by < 200 Hz).
- Not measured: whether a real CP2's mechanical noise sits that high over an aftermarket can; it decides between "mechanical too loud" and "exhaust too dull above 1 kHz".

## 2026-10-11 — Gas networks on the worker pool, bit-identical

- Each duct's share of an RK stage (update, cache, wall heat, interior residual, its ports' and outlets' face fluxes) runs on the existing worker pool; coupling stays serial in a fixed order. Euler stage and second-stage pass fused (3 barriers per step). WAVs of all 16 catalogue engines byte-identical to the serial build; `EngineLab.GasDynamics` reverses the dispatch order (a misplaced plenum sum fails it with 6 runners, not with 3).
- Free-run, 0.95 x limiter, alternated, 2-3 runs each: Merlin 1.15 (0 workers) -> 1.47; LS3 1.01 -> 1.12. Fusion alone +2-3 %. Duct interiors only (no boundaries) gave Merlin +5-8 %, LS3 nothing.
- With audio, whole catalogue, same hour vs main: worst LS3 1.07 (main 0.95); Merlin 1.40 (1.35). Twins (no pool) 1.98-2.06 vs 2.10-2.22, not investigated. LS3 with audio + 3-D view: 1.05-1.06 (main 0.94-0.96 or invalid, dropped pressure).
- Runtime scenario (`--runtime-filter`, limiter at 50 % throttle), overruns of 1,440: Merlin 115-117 (main 59-112), LS3 267-306 (main 530).
- Not tried: residual of the next step fused into the candidate pass (one barrier fewer except on each call's last step).

## 2026-10-11 — Merlin and Radial clicks: the valve-flow band toggled

- Corrects the 2026-10-09 entry "Merlin runtime gate still red, not from the intake": the cause was in the audio. The complementary valve-flow band is fitted to the published mechanical rate; single short crank sub-steps spiked it to 12-20 kHz for a few ms. On the Merlin the floor (~9.8 kHz) leaves the band empty, so it switched on ~30 times in 8 s with stale state: clicks up to 3x full scale.
- Fix: follow the slowest recent rate (down at once, up over 0.25 s) and unprime a closed band. Offline Merlin peak 3.15 -> 0.45, crest 32 -> 5.0; runtime gate passes (pre-limiter 0.42-0.46). Catalogue RMS unchanged (Radial -1.1 %), Radial window crest 8.91 -> 1.81.
- Refuted: re-tuning the reconstruction as a state-variable filter instead of DF1 sections (-65 dB difference, clicks unchanged).

## 2026-10-09 — Exhaust junction step: the duct cells' convention

- A junction's explicit bound was C V / sum(A (|u|+c)); a duct cell's is C dx / (|u|+c) = 2 C V / sum(A (|u|+c)). The LS3's derived X crossover (2 A d, four 80 mm ports) took half its pipes' step and bound the whole exhaust (~42 us vs ~84 us).
- LS3, one factor (junction bound x0.5 / x1 / x2): torque at 3,000 / 4,500 / 6,000 rpm within 0.15 %; catalogue sound octave bands within 0.2 dB, spectral cosine 0.9987.
- Realtime, LS3 free-run at 0.9 of the limiter (5,940 rpm), alternated: 0.915 / 0.905 -> 1.031 / 1.043. At the limiter (6,270) it was 0.886 before; not remeasured.
- Closed X fixture (`EngineLab.ExhaustJunctionStep`): passive at the new bound and at twice it.

## 2026-10-09 — Intake valve: characteristic boundary; forward coupling 330 us

- Root cause of the intake bias: the quasi-steady valve nozzle fed by the first cell's average made the trapped charge depend on the internal Courant number (single runner + moving piston, Courant 0.8 vs 0.08: -6.5 % at 1,300 mm2, -11 % at 2,000 mm2). Ruled out before: MUSCL limiter, finite plenum, wall heat, valve linearisation, forward coupling alone.
- Characteristic boundary (face on the interior wave curve, mass flux = valve nozzle): 0.07-0.09 % at the same points. Joint manifold then accurate at Courant 0.8; the coupling interval sets the cost.
- Forward coupling with the exhaust overlap drain, K20 vs exchange every substep: 150 us -0.49 % worst, 250 -0.79, 330 -1.26, 400 -1.48 %. Default 330 us.
- Front-loaded delivery (6,500: -2.28 % unchanged) and trajectory-resolved delivery (-0.78 vs -0.79 %): no effect, removed.
- Warm-started secant: 4.3 residual evaluations per solve (was 8.4). Live intake swap now copies these warm starts (bit-identity test caught it).
- Forward intervals counted their substeps at their opening size; over 2,500 <-> 6,500 rpm ramps the network's clock drifted beyond one interval from the chambers'. Each interval now runs to the chambers' expected time from the network's own clock.
- Realtime, free-run, 5,000 rpm (Merlin 3,040): LS3 1.08, Merlin 1.15 (were 0.78 / 0.80). At --relative-rpm 0.9 every catalogue engine > 1.1 except LS3 0.918 at 5,940 rpm: its exhaust step is bound by the 4-port crossover junction (derived ~0.8 L, ~42 us vs ducts ~84 us).
- Sound, AudioRenderHarness catalogue point, `--intake-legacy` (nozzle, every substep) vs new: RMS within ±4 % on 12 of 16; 2JZ -15 %, EJ25 -11 %, Hayabusa +19 % (brightness 0.176 -> 0.143). Merlin pre-limiter 1.51 -> 0.66: its catalogue gate (0.82) now passes. Not judged by ear; full 50-rpm curves not rerun.

## 2026-10-09 — Exhaust coupling cap; LS3 realtime and Merlin clicks still open

- The exhaust flushed on the sub-step nearest its 125 us cap: up to half a sub-step past it, and with crank-angle sub-steps the stride flipped 1 <-> 2 per frame (Merlin: 82 us sub-steps, 164 us windows). Now the last sub-step within the cap; default I4 at a 160 us cap: 941 frames over -> 0.
- AudioRenderHarness, catalogue: most engines < 5 %; CP3 rms +16 %, CP4 in-duct Pa -19 %, flat-six +10 %, EL-09 Pa +12 %, LS3 -4 %. Not judged by ear.
- Realtime, free-run, min of 2 back-to-back: all ±1.5 % except K20A 1.21 -> 1.12 (its 62-83 us sub-steps now couple every sub-step).
- LS3 0.78 vs main 1.13-1.14, Merlin 0.80 vs 1.45: structural. The joint intake network advances every runner on both half-steps (main advanced closed runners once per sub-step). Profiling found ~1 % recoverable without changing results; main's intake workers gained ~1 % too.
- Merlin over the limiter (catalogue pre-limiter 1.49-1.51, gate 0.82): sparse ~5 kHz clicks clipped in the exhaust-dry stem (1.34-1.82 s), same RMS as main; late steady state is quieter (master RMS 0.030 vs 0.044). Ruled out: coupling cadence (fix leaves 1.51), exhaust reactions, firing voices, port state, low-pressure EVOs.
- Reverting only the inflow law: 0.79; only the joint network (per-runner): 0.76; neither: 1.66. An interaction, not one cause. main's own build also fails the non-deterministic runtime Merlin gate.

## 2026-10-08 — Curve spikes: intake numerics, crank step, VTEC switching

- Intake runners on MUSCL/Forward Euler amplified a closed perturbation 823-962x; SSP-RK2 holds the gain at 1. The inflow boundary had a singular small-signal admittance, and the finite plenum was not advanced in the RK stages: both fixed, each with a passivity fixture.
- A 400 us delayed cylinder/plenum exchange moved trapped mass +4.6 % and work -7 % (isolated); exchange now on both half-steps, one joint network per path.
- The crank step was sized from the initial speed and could overrun its angle; it now follows the travelled angle, and a fault rejects the whole 720-degree dyno cycle.
- K20 VTEC switched on instantaneous rpm, valves open, 106 times/s/cylinder: torque CV 3.48 % at 5,800 rpm. Requested per shaft cycle and switched on a common base circle: 0.14 %.
- Adjacent 50-rpm torque steps: K20 8.8-11.4 % -> 1.9-3.5 %, CP2 2.6-5.8 % -> 1.8-2.1 %. Against rated points (100-rpm sweep): 2JZ 4,000 rpm 369 -> 416 Nm (427), Hayabusa max 178 -> 153 Nm (138).
- Refutes the 2026-10-07 "not numerical": that oracle changed mesh and integrator together, on a stale binary.
- Not fixed: Merlin audio over the limiter (pre-limiter 2.7x full scale), LS3 realtime 0.75-0.87. 931 of 942 sweep points are thermally unsettled. Threaded/reuse prototypes in `out/evidence` were never built.

## 2026-10-07 — Hayabusa and 2JZ curve swings come from the intake runner waves

- A rated peak torque is its curve's maximum. Sweep maxima over it: Hayabusa +29 % (178 Nm at 7,500, VE 1.26
  where 138 Nm needs ~1.03), EJ25 +22 %, Big Twin +16 %, the rest ≤ +13 %.
- Hayabusa, one factor each: intake oracle mesh (30 mm, RK2) keeps VE 1.17-1.24 at 7,500-10,000, so not
  numerical; plenum momentum fully dissipated: inert; 8 L plenum: MAP 107.8 -> 103.4 kPa, peak 178 -> 164 Nm,
  but it stands in for throttles the model can only put upstream of it. CR 11.0 (the 1999 engine's; 12.5 is
  2008's): -2 % at 7,000 but VE at 9,500 1.14 -> 1.22. Not applied. Its WOT misfire sits on the VE jump at 7,000.
- 2JZ dip (369 Nm at 4,000 for 427): boost held at 192 kPa, charge over plenum density 0.62-0.81. Well-mixed
  junctions and 650 mm primaries: inert; runners 330 -> 450 mm move the peak 5,500 -> 4,750. Runner waves swing
  ±20 % where real curves move 5-8 %. Next: their damping, against a measured full curve.

## 2026-10-07 — Catalogue exhausts at their real length

- Routes were 0.9-1.3 m (LS3 2.07). `midpipe_length_mm` gives the K20A 3.5 m, LS3 3.0 (realtime: 3.73 m cost
  8 % and one INVALID run, median 1.06 -> 1.02 at 3.0), flat-six 1.57, bikes 1.22-1.49. CatalogReference moves ≤ 4.4 %.
- Turbos refuted: the turbine is the outlet restriction, so the mid pipe sat on its hot side. 2.6 m slowed
  the spool (90 % of the step at 3,000 rpm) 1.30 -> 1.72 s (2JZ), 2.47 -> 3.53 s (I5), EJ25 and TDI alike;
  the 2JZ no longer reached its shift point. 2JZ, EJ25, I5 and TDI keep their old length.
- AudioRenderHarness: level -1.2 dB (LS3) to +2.5 dB (flat-six); the share below 250 Hz falls (CP2 64 -> 47 %,
  Full System 64 -> 41 %, Lab 53 -> 23 %). Not judged by ear yet.
- Open: the CP3 and CP4 misfire once on the DFCO resume (first charge, CP3 AFR 9.05); the CP2's live remesh
  lands 37 % short of a fine-built engine, already before this change.

## 2026-10-06 — 2JZ boost ran past its wastegate

- DynoSweepHarness: at 520 mm2 (the default gate) the 2JZ's gate is fully
  open from 5,500 rpm and the pressure ratio keeps rising: MAP 202 kPa at
  5,000, 246 at 6,000, 297 at 6,500. EJ25, I5 and TDI hold theirs.
- Turbine inlet at the mean back pressure instead of the port peak: 252 kPa
  at 6,500, not a fix; not kept. Gate 900 mm2 (a 34 mm port): 190-194 kPa
  from 3,000 to 6,500; 1,300 mm2 gives the same curve.
- CatalogReference: power 275.2 -> 259.2 kW (+15.2 -> +8.4 %), torque 371.3 ->
  373.2 N.m at 4,000 (-12.6 %). Audio harness (holds ~3,700 rpm): RMS and peak
  equal, crest 6.33 -> 6.84. New test CatalogBoostHold (fails at 520 mm2: 2.47).

## 2026-10-06 — DFCO resume: the EJ25's peak is lean, not rich

- LoadedAccelerationHarness now splits the resume error: rich 16-30 %, lean
  5-35 %. The EJ25's 35.1 % (which loosened the envelope to 0.40) is its first
  post-cut cycle, lean: first four charges 219 mg metered, 120 mg in the
  chambers (162 needed); the dry runner and film kept the rest.
- The rich side is the resume trim: it starts at the fourth root of the
  learned high-load cell (EJ25 0.92 against 0.73 settled), ~3 cycles to fall.
- One factor each, catalogue max: no prime 51 % lean; start sqrt 41 %; full
  cell 58 % lean; unity 30 % but Hayabusa/CP3 misfire; 150 mm footprint 34 %
  but 2JZ 23 misfires; both 40 % (EJ25) and 26 misfires. Kept: rich 0.35, lean 0.40.

## 2026-10-06 — Injectors drawn, Ctrl+S, quit warning, no manual load

- `EngineLab.EngineModel3D`: one injector per cylinder on the 16 catalogue
  engines (port and direct), named with its cylinder by a click, port in the
  runner spraying at the valves, direct in the roof spraying down.
  Mutations caught: 6 of 6.
- `EngineLab.SourceEncoding` fails on the `⋯` menu text corrupted in 8af95bd
  (UTF-8 read as Latin-1) and passes on the 258 repaired files.
- Not exercised on screen: the inspector, the side panel's *Show in 3-D*,
  Ctrl+S against the starter, the quit dialog (no screen here).

## 2026-10-06 — Sound sources at their drawn places

- With the camera microphone on, the exhaust and intake still radiated from
  the origin (their authored, schematic place). Now each outlet sounds from
  its drawn tip and each intake path from its drawn mouth, the turbo from its
  compressor. `EngineLab.EngineModel3D`: every compiled outlet of the 16
  catalogue engines and a scalar copy finds its drawn tip and axis.
- `EngineLab.CameraMicrophone`: CP2 openings 1 m before the microphones
  +11.9 dB exhaust, +11.9 dB intake; 2JZ turbo halfway +6.00 dB (1/r 6.00);
  switched off, bit for bit again at 7.11 s. Mutations caught: 13 of 13.
  Not listened to in the application.

## 2026-10-06 — Camera microphone

- `EngineLab.CameraMicrophone`: twice as far, -6.02 dB for a tone, the CP2
  block (-6.02), exhaust (-6.02), intake (-5.99), 2JZ turbo (-6.02); pitch
  979.98-1000 Hz during a 1 kHz glide; largest sample step while moving 0.0049
  against 0.0128 before; a live exhaust/intake swap heard at -6.00/-6.00 dB.
- Switched off, the CP2 stayed 35 dB off its default sound: the float glide
  stalls 0.3 sample short (step < half an ulp). A linear tail lands it: bit
  for bit again 1.25 s after switching off. Mutations caught: 9 of 10, the
  survivor equivalent. Off by default; not listened to or exercised on screen.

## 2026-10-06 — Inspector edits for intake, injectors and boost

- `resizeIntakePart`: read and written where the engine keeps them (own
  runner or the path's), mirrored on a single path (without it, normalising
  puts the old runner back), refused out of range; the runtime takes them.
  Mutations caught: no mirror, own runner ignored.
- The turbine flow area is read at every step (outlet restriction) and by
  the turbo sound per sample: a live edit is not stale. Not exercised on
  screen: the app starts; no click in its window from here.

## 2026-10-06 — Intake sizes while running

- `EngineLab.LiveIntake`, 60 % of redline, change at 6 s (runners +120 mm,
  plenum x1.6, throttle +6 mm): torque built/swapped/untouched CP2
  78.4/78.6/60.3, K20A 223.6/223.6/229.1, LS3 685.6/685.7/628.7 Nm.
- The stiff dyno moves the speed to its new equilibrium within a few frames
  (LS3: 28 rpm): a first "no step" bound (1.5 x the engine's own) failed on
  that legitimate shift; the bound now adds it.
- Mutations caught: runners without their state, plenum not resized, resize
  not keeping its state, scope blind to a path's own size (needed a two-path
  CP2: no catalogue engine has two), audio swap not begun, no warm-up.

## 2026-10-06 — Injectors and turbo while running

- `EngineLab.LiveSettings`, held at 60 % of redline, change at 6 s, mean of
  the last 4 s. 2JZ wastegate 1.89 -> 1.42: boost ratio 1.94 -> 1.68 (built)
  and 1.69 (swapped). Its brake torque moved 1 % only: not limited by boost.
- CP2 injectors: x0.45 and 4-8 g/s change nothing (its own are 20 g/s);
  2 g/s each gives 60 -> 46 Nm, swapped 45.8.
- Mutations caught: no turbo swap, no injection swap, audio update not taken,
  scope blind to the turbo, runtime without its check, layer taking another
  compressor. The app starts; the JSON editor path not exercised on screen.

## 2026-10-06 — Saving an engine as it is

- `EngineLab.SavedEngine`: the 16 catalogue engines, edited (bore -1 mm,
  runners +40 mm), saved and read back run bit-identical over 2.5 s
  (cranking to 70 % throttle); tables retarded 6° likewise.
- The JSON did not name the voicing: a copy lost it (K20, voiced monitor:
  rms 0.0341 instead of 0.0363; the physical reference monitor ignores the
  voicing). Family and key are now in the JSON; the 16 render the same master
  rms and peak once saved.
- Mutations caught: runner length not decoded, tables not read, voicing not
  restored, revision in the "edited" test, rename not applied.
- Not checked: the menu, dialogs and picker dot on screen (no screen here);
  the app starts and closes with the change.

## 2026-10-06 — EJ25: one exhaust path into its one turbo

- Two paths (one per bank) left cylinders 2/4 bypassing the drawn turbo; the
  solver's single turbine already took the whole flow. Now one path (4-1).
- Dyno sweep, WOT, before/after: 2,000 rpm 359/313 N.m (boost 185/151 kPa);
  2,500-5,000 rpm -2 to +3 %; 5,500-6,000 rpm 453-462/402-404 N.m, boost
  236-257/211 kPa (the overshoot past the 2.05 wastegate is gone).
- CatalogReference: 4,000 rpm -6.4/-7.1 %, 6,000 rpm power +10.6/+7.0 %.
- AudioRenderHarness: rms 0.0341/0.0265 (-2.2 dB), bands 39/60 -> 63/37 %,
  main resonance 350 Hz -> 3,986 Hz, mono (LRcorr 1.0). Not listened to.
- DFCO resume (declared rich regression): peak AFR error 31.6 -> 35.1 %,
  misfires 3 -> 1; the test envelope went from 0.35 to 0.40.

## 2026-10-06 — A stopped engine's intake rang by itself

- From a uniform ambient start, ignition off, every engine's runners reached
  ±14 to ±111 kPa in a second (CP2 ±14, LS3 ±54, Radial ±111). Two causes,
  each measured alone: an open valve at zero pressure difference (the
  quasi-steady law has unbounded gain), and, valves shut, the explicit
  plenum coupling (growth ~3.7x per 400 us flush; ±30-70 kPa at 400 us,
  ±5-45 at 100 us, ±0.05-0.25 at 20 us). Mesh 30 mm and RK2: no better.
- Fix: |rpm| < 20 without starter seals the valves and settles the runners
  at plenum pressure. AudioRenderHarness deterministic renders bit-identical.
- Not measured: whether the same coupling adds noise to a running intake.

## 2026-10-05 — Merlin supercharger drawn; cost of the gas view

- `EngineLab.EngineModel3D`: drawn on the Merlin only, eye fed by the airbox,
  charge pipe on the throttle, clear of the engine, impeller at ratio x crank.
  Route counts unchanged. Mutation caught: impeller frozen.
- Budget harness `--gas-view` (field + probe asked at 60 Hz), free-run, 60 %
  redline, best of 4 alternated, off/on: CP2 3.28/3.24, LS3 1.31/1.30, K20A
  1.92/1.92. Within the ±4 % noise: no measurable simulation-thread cost.
- Not measured: GPU and message thread; not seen in the app (the scene
  viewer does not draw in a hidden pane).

## 2026-10-05 — Fine exhaust mesh on demand

- The view's *Fine* setting remeshes the running exhaust from 360 to 180 mm.
  Held at 60 % redline, remeshed at 6 s: LS3 625.94 Nm, against 625.80 for an
  engine started at 180 mm and 629.19 at 360 mm; CP2 60.16/60.33/60.29 (the
  mesh barely moves its torque, so it only proves nothing breaks). Cells:
  CP2 6 -> 11, LS3 26 -> 44. No stall.
- Mutation caught: the live build ignoring the requested cell length.
- Not tested: the menu itself, and the cost in the app (see 2026-10-05 wave
  resolution entry: 13-20 % less headroom).

## 2026-10-05 — Live bore and stroke changes

- CP2/K20A/LS3 at 60 % redline, +3 mm bore and stroke at 5 s: settled brake
  torque within 0.3 % of an engine built that way (CP2 67.80 at once, 67.77
  over 2 s, 67.89 built); resized back, within 0.06 % of untouched.
- At once, one cycle leaves the variability band (CP2 58.9 Nm, AFR 14.8
  against 13.3): its fuel was metered for the old cylinder. Then ~69 Nm,
  drifting to 68 over seconds as the walls warm. Over a ramp: no cycle out.
- 16 engines, 2 mm at 3 s of idle: none stalls (2JZ dips to 625 rpm, idle 760).
- Mutations caught: no TDC wait, no ramp, no kinematics rebuild (74.4 Nm).
- Not tested: the runtime's telemetry, inertia and dyno re-sizing.

## 2026-10-05 — Live exhaust changes

- Gas: an identical exhaust adopted continues bit-identically; 360 to 45 mm
  conserves mass, energy and wall energy per duct. Physics, CP2/K20A/LS3 held
  at 60 % redline, +500 mm and x0.70 diameter swapped at 6 s: settled brake
  torque within 0.2 % of an engine built with it (CP2 56.64/56.64 Nm, 60.26
  untouched). No speed step either way: a fresh network refills in ms. What
  the state transfer keeps is the wall (CP2 332 K at 6 s, < 3 % change).
- Audio: identical swap -75 dB during the crossfade, -114 dB after. 60 ms of
  warm-up left -33 dB, 150 ms -74 dB. Outlet jet noise is seeded: disabled.
- Mutations caught: no wall copy, nearest-cell remap, no adoption, no fade.

## 2026-10-05 — Resizing the exhaust from the 3-D view

- `EngineLab.EngineModel3D`, 16 engines and a scalar-geometry copy of the
  K20A: the resized component is drawn 80 mm longer (a pipe also 4 mm
  wider), every other component unchanged, the configuration valid.
- Found by the test: on a single scalar path the edit did not reach the
  drawing (normalisation copies `exhaust` over the path); fixed by mirroring.
- Mutation: without the silencer guard, the test fails (a silencer narrowed
  to its outlet is accepted).
- Not done: no live preview before Apply; the intake is not editable.

## 2026-10-05 — Wave resolution of the exhaust mesh

- First primary, cell at 1/4 of its length, full load held at 60 % of
  redline, probe at every sub-step averaged over 12 × 1/8 s, against 45 mm:
  360 mm (production) shows 29-61 % less peak-to-peak (CP2 89/127 kPa, LS3
  37/85, K20A 36/94, Hayabusa 51/96), RMS shape error 27-76 %. 180 mm: within
  5 % on CP2, LS3, Hayabusa; the K20A needs 90 mm (cells sampled up to 1/8 of
  the length off the reference point).
- Cost, budget harness free-run, best of 4 alternated, 360/180/90 mm: CP2
  3.28/2.85/2.39, LS3 1.31/1.05/0.73, K20A 1.92/1.67/1.32. Nothing changed.

## 2026-10-05 — Oscilloscope in the part inspector

- `EngineLab.EngineModel3D` (first catalogue engine): a probed cycle fills
  all 360 bins; on every element the probe reads the captured cell exactly;
  rpm and crank angle bit-identical to an unprobed simulator.
- Mutation: runner cells not reversed to gas-flow order fails (element 8).
- Not measured: its cost on the budget harness. It only runs while a duct
  is inspected: one cell read per sub-step.

## 2026-10-05 — Intake waves in the 3-D view

- Premise checked first: is the intake wave too weak for the exhaust's
  scale? Peak departure from each cell's mean over 1 s, 16 engines, idle and
  full load held at 60 % of redline: intake/exhaust 0.57-4.8. Refuted: one
  shared scale, no separate intake scale.
- Runners and plenums now take the wave colours. Mutation: the old
  exhaust-only filter fails `EngineLab.EngineModel3D`.
- Not done: the plenum is lumped (one colour); the airbox, throttle bores and
  inlet duct have no solver cells and stay plain.

## 2026-10-05 — Turbocharger in the 3-D view

- Drawn on the 4 catalogue turbos (2JZ, EJ25, I5, TDI), after the collector
  where all of a path's primaries meet. Route check unchanged (7, 4, 0, 48,
  7); the turbo's solids clear the engine's on all four.
- Mutations: the trunk not resuming at the turbine outlet, a wheel that does
  not turn: both fail `EngineLab.EngineModel3D`.
- Not done: the solver's turbine is a restriction at the outlets, so the gas
  field shows the downpipe at turbine inlet pressure. No charge piping, no
  supercharger (Merlin).

## 2026-10-05 — Pipe routing in the 3-D view

- Route check (`checkRoutes`), 16 catalogue engines. Old layout: 107 clashes,
  51 self-clashes, 0 through the engine, 259 bends < 1 D, 6 stretched. Router
  and placement: 7, 4, 0, 48, 7. Gated at these counts.
- A first checker gave 161 clashes: inner segments bulged past a flat end by
  their radius (a 65 mm collector reached 50 mm out of its mouth). Fixed.
- Stiffness (pull to straight) tried at 0.1-0.5: more bends (97-244 vs 87):
  with the length held it acts as tension. Removed.
- Not done: the 2JZ six-into-one stays a dense knot; +1 stretched pipe there.
  Layout cost: export of 16 engines 1.3 → 4.1 s.

## 2026-10-04 — Gas field on the 3-D view

- `EngineLab.EngineModel3D`, 16 engines: every drawn exhaust component,
  runner and plenum bound to its solver element; capture within one sub-step
  of the asked angle (fails without the guard), simulation bit-identical;
  waves over a 200 kPa mean show (fails against ambient: scale 204 kPa).
- Against ambient the 2JZ exhaust was one orange (the turbine is the 1-D
  network's restricted outlet): colours show the departure from a mean.
- Budget harness as below, alternated: with 1.896-1.923 (7 runs), without
  1.919-1.956 (4). At most ~2 %, the ranges overlap.
- Not observed: the wall glow (798 K not reached in a 15 s run), the
  afterfire flame.

## 2026-10-04 — Exhaust and intake laid out from the configuration

- `EngineLab.EngineModel3D`, 16 catalogue engines: every exhaust component is
  drawn once; no pipe is drawn shorter than authored; runners within 3 % of
  their length; plenum ≥ and airbox = authored volume (mesh volume).
- 6 of 72 exhaust pipes are drawn > 3 % longer than authored: the LS3 X
  (140 mm pipes crossing ~400 mm between banks, ×2.9-3.1), 2JZ cylinder 6
  primary (+16 %), I5 cylinder 5 primary (+6 %). Gated at 6.
- Budget harness as in the entry below, same hour, 4 runs each: with the
  ducts 1.93-1.95, without 1.91-1.93. No measurable cost.
- Not measured: whether the invented routing matches any real engine.

## 2026-10-04 — Cost of the 3-D engine view

- `EngineLabRealtimeBudgetHarness --filter 2JZ --free-run --rpm 4000`, 10 s,
  run while the app drove its own 2JZ at the rev limiter; i5-10600, GTX 1660
  Super, 60 fps cap. Alternated, 2 to 4 runs each: app closed 2.08-2.10, 2-D
  1.98-1.99, 3-D without blur 1.94-1.95, 3-D blur every 6° (≤ 24 sub-frames)
  1.89, every 12° (≤ 12) 1.93-1.95. Kept 12°.
- Frame submission costs 0.07-0.2 ms on the OpenGL thread; the rest is the
  driver. Overruns at the limiter exist in 2-D too.
- Not measured: integrated GPUs, other drivers, frame-time jitter.

## 2026-09-23 — Injection and idle

- Port-injection pulse recomputed every sub-step: ratchet (CP2: AFR 10.3, trim
  pinned at 0.55). Pulse sized once per cycle: 15/15 at φ 1.02-1.04 at idle.
- Fuel pushed back past the throttle was destroyed (CP2 start: 592/1,192 mg);
  kept in the airbox and drawn back in: 25 s start 14/14 except Aircooled.
- **Declared, accepted**: rich DFCO recovery ~0.2 s, peak 16-32 % (HEAD 9-17 %),
  3 EJ25 misfires; LS3 stalls at the 4 s start (fuel stored in the plenum).
- CP2 idle sound: +5.3 dB, darker (−17 dB at 1-2 kHz). Realism unknown.
- Not measured: remaining trim biases (predicted air +17 % CP2, efficiency 0.77).

## 2026-09-23 — Fixes after the afterfire audit

- Hill-start stall: ECU reserve ×2.12 kept ~14 s after start on top of the
  X-tau; limited to the starter. At 4 s: 8 → 13/14 road engines; at 25 s:
  13/14 unchanged. Declared stalls: 2JZ ≤ 8 s (lean, crushed by the clutch),
  Aircooled at 25 s. Accepted by the owner: 2JZ 5,600 rpm +14.81 →
  +15.11 % (16 % tolerance), gear change launched after 20 s of idle.
- Crack layer (noise > 4 kHz driven by the reaction), ratio 1.0 uncalibrated,
  clamped between 0.8 and 2.5: +3.9 dB in 4-8 kHz during the 2JZ pops.
- **CP2 (standard and Full System): the discrete profile burns nothing** (0 % of
  200 mg, wall 390-424 °C); at 650 K instead of 800 K: 18 %. Not fixed.

## 2026-09-23 — Afterfire audit

- **Regression from `d70e8b8`**: both CP2s and the LS3 stall at launch
  (1st gear, full throttle, 0.9 s clutch) in `EngineLabAfterfireHarness`; at
  `75f64fa` the same lab Twin launches and reaches 4,284 rpm. No test caught
  it. `--trace` now prints the trajectory when arming fails.
- Audio front of a backfire: 0.2-0.8 ms (median Twin 0.46, 2JZ 0.61),
  duration 2-4 ms. Energy: centroid 450-790 Hz, 0.2-0.5 % between 4 and 8 kHz,
  0 above (LR8 cutoff at 0.47 × coupling rate). ON/OFF peak: -3 to +10 dB.
- Continuous fuel at 18 %: 0.0 % burned (equivalence 0.18 < 0.45). Same mass in
  packets: 89 % burned (2JZ). Only engine 16 authors the afterfire.

## 2026-09-22 — Project reorganisation

- Blind listening by the owner against real engines: **no engine is
  recognisable beyond its cylinder count**. The rhythm (firing order) is right;
  the timbre resembles no specific engine.
- The afterfire does not sound like a backfire, despite a dozen commits.
- The `references/real-engine-audio/` corpus cannot measure the gap: 10 of 10
  recordings have an unknown engine speed and 7 are proxies.
  There has never been a measurable sound target.
- New direction: see `VISION.md`.

## 2026-09-22 — Commit of the 27 August audit work

Work in progress (34 files: AFR, dyno, intake smoothing, DFCO recovery)
committed after a warning-free Release build and 44/44 green tests. Two points
to know:

- DFCO recovery goes from 1.25× to **1.50× idle**, which an earlier note
  advised against (1.50× alone still stalled without the fuel-film fix). Both
  fixes coexist. Revisit only if an idle or recovery problem comes back.
- A common mechanical loss term above 4,000 rpm was added to pull the top end
  back into line: it is a compensation, not a model.
- 27 August audit: LS3 at 1.151× real time in free-run, Merlin at 88 % of an
  audio block at P99, on the reference machine, without the UI open.
