# Physical afterfire in the exhaust

EngineLab's afterfire is neither a sample nor added noise. Unburned fuel and
oxygen leave the cylinder into the quasi-1D network; a local reaction then
releases energy in the cell or junction where the conditions are met. The
pressure rise travels through the same acoustic DAG, the same collectors,
mufflers and outlets as the normal blowdown.

**Status (closed 2026-10-25, `docs/journal.md`):** the workshop's profile pops. On
the overrun the ECU cuts 70 % of the sparks (fuel kept), and the next fired
cycle's exhaust lights the slug a cut cycle left in its primary. On the Lab
Twin at 3,400 rpm: 18 pops in 2.2 s, 16.6 dB over the median against the
real bike's 15.8, a 0.5 ms rise (0.5), 96 ms between pops (143); on the
MT-07 at 4,400 rpm, 17 pops at 13.5 dB. Both runs keep the audio contract.
It took two fixes in the acoustic path (below): the lines' amplitude warp
deleted 4-9 dB of every pop by where it burned, and the old 100 kPa source
bound flattened the 320 kPa jump of a lit slug. Not reached: the Lab at
6,200 rpm (1 pop), the Hayabusa (a continuous burn), the K20A (too short an
overrun), a pop's 1.1 ms decay (0.5-0.6) and its 120-500 Hz weight (+4.5 dB
against +7.4). These are known limits, not work in progress: reopening them
needs a measured lead: a real overrun recording at a known engine speed.

## Backfires are a listening switch, not an engine property

Backfires (overrun afterfire and the wet rev limiter) are turned on only from
the Audio workshop, for the engine running, and are off whenever an engine is
loaded. `disableBackfires()` (`EngineTypes.hpp`) clears the strategy, the
`enabled` flag and `ignition.limiter_keeps_fuel`. It is applied:

- when the application switches engine (catalogue, saved, designed or built);
- when an engine is saved or read back (`SavedEngines.cpp`);
- in the "modified" comparison (`EngineBaseline`), so the switch is never an
  edit.

An edit of the running engine keeps them: `keepBackfires()` gives every edit
(the 3-D view's bore or stroke, a designer, the JSON editor, an A/B switch, a
script reload) the running engine's switch and calibration, because those hold
copies made before the workshop's last change. Only another engine resets them.

The calibration under the switch (temperatures, times, spark angle and cut,
pocket mixing) is part of the engine and is saved. Engine files can still carry the
activation keys and a script `ignition.limiter_keeps_fuel` (the serializers
read them, and the `EngineLabAfterfireHarness` measures them), but the
application drops them.

## ECU strategies

- `clean_dfco`: clean fuel cut, no fuel retained (the default);
- `late_spark_overrun`: what the Audio workshop installs, a "pops and bangs"
  map. On a shut throttle the ECU keeps the normal charge and fires it at
  `overrun_spark_advance_deg` (negative is after top dead centre, past the
  map's -10 deg floor), and cuts the spark of a share
  `overrun_spark_cut_fraction` of the cycles, each drawn on its own, fuel
  kept. A late spark's flame is still burning when the exhaust valve opens; a
  cut cycle's whole charge leaves unburnt and waits in the primary for the
  next fired cycle's exhaust. The cut is drawn apart from the misfire draw and
  only while the overrun map runs, so no other engine's misfire sequence
  changes.

The retained-fuel strategies (`continuous_anti_lag`, `discrete_afterfire`, with
`overrun_fuel_fraction` and the `overrun_pulse_*` chopper) were removed on
2026-10-24: the discrete rhythm was the chopper's 2 Hz, not the physics', and
the retained charge, mixed into 0.25 m cells, never burned on the lab Twin. A
file that still names them reads as `clean_dfco`, and the old keys are ignored.

## Unburned pockets

A production four-stroke cell is 0.25-0.30 m long. Mixed into it, a cylinder's
unburnt charge (equivalence ratio about 1.2) and the air the tailpipe draws in
average to 0.3-0.45, below the 0.45 lean limit: nothing burns, cell by cell.
`pocket_mixing_time_s` (zero: off) keeps that charge, at exhaust valve opening,
as one pocket per cylinder (`ExhaustGasNetwork::emitUnburnedPocket`, at most 32
per network) with its own composition and temperature:

- it is carried at the local gas velocity, from duct to duct and through
  junctions, and leaves at the outlet;
- its temperature relaxes to the host cell's over the mixing time, and after
  three of them it has mixed into the cells;
- it lights from its own temperature (the same Livengood-Wu integral as a
  cell), from a burning host cell, or when its cylinder's next cycle fires
  (half burnt or more at exhaust valve opening): that exhaust leaves at
  2,000-2,200 K and lights every pocket waiting in the cylinder's port element
  (`igniteUnburnedPockets`). It is checked against the flammability window on
  its own equivalence ratio;
- it burns at the reaction time constant, out of the fuel and oxygen its host
  cell actually holds, so it adds no mass; the released heat is a source like
  any other.

Pockets are emitted only while an overrun afterfire or a wet limiter is
active, so a loaded engine is bit-identical with or without them.

## Physical conditions

A site burns only if all of the following hold:

1. fuel and oxygen coexist locally;
2. the local equivalence ratio is inside the flammability window;
3. the gas or the wall exceeds the ignition temperature;
4. this mixture stays active for the induction delay;
5. an established flame is not below the quench temperature.

Each cell and each junction has its own persistent induction and combustion
state. The reaction consumes the species conservatively and adds
`fuel_mass × LHV` to the energy. It publishes a bounded event holding the exact
node, the axial position, the energy, the duration, the density, the speed of
sound and the local area.

`induction_time_s` is the reference delay at the threshold, at the reference
pressure and at `phi=1`. Schema 8 integrates `dt/tau(T,p,phi)` with an
Arrhenius law whose coefficients are all exposed; schemas 1 to 7 migrate with
zero exponents and get exactly their flat duration back. The wall/gas origin of
the flame is stored at ignition; it is not reinterpreted after the reaction
itself has heated the gas.

The chemistry keeps its state as soon as a reaction strategy is authored,
including under load. That oxidises hydrocarbon traces as they travel instead
of accumulating sixty seconds of fuel and igniting that old inventory on
lift-off. This maintenance oxidation publishes neither afterfire telemetry nor
an acoustic source: both stay reserved for an active overrun afterfire or wet
rev limiter, and the loaded check just before lift-off measures zero acoustic
events.

## The acoustic source

The compact acoustic source is derived from the released heat. The total
pressure jump is:

```text
Delta p = (gamma - 1) × Qdot / (A × c)
```

The network then splits it between its two travelling characteristics; each
outgoing wave therefore receives `(gamma - 1) × Qdot / (2 × A × c)`. The signal
at the solver rate is reconstructed by the same LR8 anti-imaging filter as the
physical boundaries. A two-pole 25 Hz DC blocker only removes the quasi-steady
heat already carried by the mean flow.

The source is injected at the node and axial position of the reaction. There
is no "pop" oscillator, no sample, no imposed audio periodicity and no global
source placed at the outlet. A last-resort 1 MPa bound protects the linear
network; every sample that would reach it is counted, shown and invalidates
the validation harnesses. It sits above the ~0.8 MPa rise of an isochoric
stoichiometric explosion, so no physical burn reaches it. The old 100 kPa
bound clipped every lit slug (up to ~700 kW, a 320 kPa jump), cost a pop
3 dB and made the generic crack below eat into it: crack noise riding a
clipped pulse loses its positive half. Each voice keeps the power
`energy / duration` for the exact duration of the reaction step.

The reconstruction keeps nothing above ~3.8 kHz: the 1-D network does not
compute that band. `ReactionCrackSynthesiser` adds it to every reaction voice
(white noise high-passed at the crossover, a -6 dB/octave slope, an envelope
locked to the voice's jump: 0.1 ms attack, 0.5 ms release, at `defaultCrackRatio`
1.0 × that jump, uncalibrated). `EngineLabAfterfireHarness --no-reaction-crack`
renders the same trajectory without it.

The acoustic lines steepen a wave by its own amplitude (`steepenedRead`, a
first-order simple-wave relation for the kilopascal blowdown waves). A
burning slug's pulse reaches 0.4-1x the ambient pressure, where that warp sits
at its clamp and reads the line at an age younger than where the pulse was
injected: 4-9 dB of a pop vanished, by where it burned, and the earlier
reading that the voices "add nothing to the peaks" came from that (journal
2026-10-25). While a reaction half-wave above Mach 0.03
(`reactionLinearMachThreshold`) rings in the network, every line reads
linearly for `reactionLinearHoldSeconds` (20 ms, re-armed by each such
source). Without backfires there is no reaction voice, so the default sound
is unchanged.

## Using it in the Audio workshop

The `Afterfire  (pops and bangs on overrun)` switch in the `Real-time mix`
group turns backfires on or off and applies at once, without `Apply live`. It
stays in sync with the box in the physics group, and returns to the live state
if it is refused (dyno run in progress). The wet limiter has its own box in the
physics group. Both are off whenever an engine is loaded.

The physics group exposes the ignition temperature, the reaction time, the
efficiency, the overrun spark angle, the pocket mixing time and the overrun
spark cut. On an engine that never authored an afterfire calibration (900 K,
10 ms, no pockets), turning backfires on installs the measured profile
(`MeasuredBackfireProfile`): 800 K, 0.5 ms, +10 deg, 40 ms pockets, a 70 %
spark cut, and the schema 8 induction correlation in place of a flat timer.
An authored calibration is kept. `Audible demo` installs the same profile with
the wet limiter and a 6 % cycle variation.

`Apply live` sends the calibration to the simulation thread through a mailbox.
It keeps engine speed, phase, gas inventories and wall temperatures, and is
refused during a dyno pull.

For a direct test:

1. select `Audio Physics Lab 689 Twin`;
2. turn `Afterfire` on (or `Audible demo`);
3. hold the engine above 3,000 rpm with more than 20 % throttle;
4. release completely.

The telemetry shows the strategy, the ECU blockers, the kW, the mg/s, the
number of reacting volumes and the lost events. Zero power is still a possible
physical result: cold line, mixture outside the window, strategy not armed.

`EngineLabAfterfireHarness --backfires` measures what the switches do, on the
engine's own calibration. `--late-spark DEG`, `--pocket-mix-ms MS` and
`--spark-cut SHARE` change one factor, and a value outside the engine's limits
is refused by name. `scripts/pop_metrics.py` counts pops in the render the
same way as in a recording (`--threshold-db 12` for the figures above).

The 2026-08 write-ups of the schema 8 induction and of the discrete-slug level
correction are in the docs archive (git tag `archive/docs-2026-09`):
`afterfire-induction-implementation-2026-08-22.md` and
`audio-level-afterfire-correction-2026-08-23.md`.
