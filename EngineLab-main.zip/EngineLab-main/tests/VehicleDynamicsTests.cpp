#include <enginelab/catalog/EngineCatalog.hpp>
#include <enginelab/diagnostics/EngineDiagnostics.hpp>
#include <enginelab/foundation/ForcedInductionFlow.hpp>
#include <enginelab/foundation/EngineTypes.hpp>
#include <enginelab/runtime/DrivelineModel.hpp>
#include <enginelab/serialization/JsonEngineSerializer.hpp>
#include <enginelab/serialization/YamlEngineSerializer.hpp>

#include <algorithm>
#include <cmath>
#include <cstdlib>
#include <iostream>
#include <numbers>
#include <string_view>
#include <utility>

namespace {
void require(bool condition, std::string_view message) {
    if (!condition) {
        std::cerr << "FAIL: " << message << '\n';
        std::exit(1);
    }
}

enginelab::EngineConfig launchConfig(enginelab::DrivenAxleLayout layout) {
    auto config = enginelab::makeDefaultInlineFour();
    config.vehicle.massKg = 1'200.0;
    config.vehicle.dragCoefficient = 0.30;
    config.vehicle.frontalAreaM2 = 2.0;
    config.vehicle.tireRadiusM = 0.30;
    config.vehicle.rollingResistanceCoefficient = 0.0;
    config.vehicle.tireFrictionCoefficient = 1.0;
    // This suite exists to exercise the friction circle and the longitudinal
    // load transfer that rides on it, so it opts in explicitly: the shipped
    // default is off (see VehicleConfig::tyreGripLimitEnabled).
    config.vehicle.tyreGripLimitEnabled = true;
    config.vehicle.drivenAxleLayout = layout;
    config.vehicle.drivenAxleWeightFraction = 0.50;
    config.vehicle.wheelbaseM = 2.50;
    config.vehicle.centerOfGravityHeightM = 0.52;
    config.transmission.gearRatios = { 3.20 };
    config.transmission.finalDriveRatio = 4.0;
    config.transmission.maxClutchTorqueNm = 2'000.0;
    config.transmission.shiftDurationSeconds = 0.01;
    config.transmission.drivelineEfficiency = 0.95;
    return config;
}

enginelab::DrivelineOutput launch(enginelab::DrivenAxleLayout layout,
                                  bool reverse = false) {
    const auto config = launchConfig(layout);
    enginelab::DrivelineModel model(config);
    model.requestGear(reverse ? -2 : 0);

    enginelab::EngineState engine;
    engine.rpm = 5'000.0;
    engine.angularVelocityRadPerSecond =
        engine.rpm * 2.0 * std::numbers::pi / 60.0;
    engine.torqueNm = 800.0;
    engine.throttle = 1.0;

    enginelab::DrivelineOutput output;
    for (int step = 0; step < 600; ++step)
        output = model.advance(0.001, engine, 0.0, 1.0, 0.0);
    return output;
}

const enginelab::EngineConfig& findEngine(
    const enginelab::EngineCatalogLoadResult& catalog,
    std::string_view nameFragment) {
    const auto found = std::find_if(catalog.entries.begin(),
        catalog.entries.end(), [&](const auto& entry) {
            return entry.config.name.find(nameFragment)
                != std::string::npos;
        });
    require(found != catalog.entries.end(),
        "expected engine must exist in the catalogue");
    return found->config;
}
} // namespace

int main() {
    constexpr double gravityMps2 = 9.80665;
    constexpr double massKg = 1'200.0;
    constexpr double staticDrivenNormalN = 0.5 * massKg * gravityMps2;

    const auto front = launch(enginelab::DrivenAxleLayout::front);
    const auto rear = launch(enginelab::DrivenAxleLayout::rear);
    const auto all = launch(enginelab::DrivenAxleLayout::all);
    const auto rearReverse =
        launch(enginelab::DrivenAxleLayout::rear, true);

    std::cout << "layout,direction,accel_mps2,normal_n,tire_n,speed_mps,limited\n";
    const auto print = [](std::string_view layout,
                          std::string_view direction,
                          const enginelab::DrivelineOutput& value) {
        std::cout << layout << ',' << direction << ','
                  << value.longitudinalAccelerationMps2 << ','
                  << value.drivenAxleNormalForceN << ','
                  << value.tireForceN << ',' << value.vehicleSpeedMps
                  << ',' << (value.tractionLimited ? "yes" : "no")
                  << '\n';
    };
    print("front", "forward", front);
    print("rear", "forward", rear);
    print("all", "forward", all);
    print("rear", "reverse", rearReverse);

    require(front.tractionLimited && rear.tractionLimited
            && all.tractionLimited && rearReverse.tractionLimited,
        "the witnesses must actually exercise the tyre friction limit");
    require(front.longitudinalAccelerationMps2 > 0.0
            && rear.longitudinalAccelerationMps2 > 0.0
            && rearReverse.longitudinalAccelerationMps2 < 0.0,
        "the launch directions must produce signed longitudinal acceleration");
    require(front.drivenAxleNormalForceN < staticDrivenNormalN,
        "forward acceleration must unload a front driven axle");
    require(rear.drivenAxleNormalForceN > staticDrivenNormalN,
        "forward acceleration must load a rear driven axle");
    require(rearReverse.drivenAxleNormalForceN < staticDrivenNormalN,
        "reverse acceleration must unload a rear driven axle");
    require(rear.tireForceN > front.tireForceN * 1.25
            && rear.vehicleSpeedMps > front.vehicleSpeedMps * 1.20,
        "load transfer must materially separate otherwise identical FWD and RWD launches");
    require(std::abs(all.drivenAxleNormalForceN
                     - massKg * gravityMps2) < 1.0,
        "all-wheel drive must retain the sum of front and rear normal loads");

    auto roundTripConfig = launchConfig(
        enginelab::DrivenAxleLayout::front);
    roundTripConfig.vehicle.wheelbaseM = 2.73;
    roundTripConfig.vehicle.centerOfGravityHeightM = 0.49;
    const enginelab::JsonEngineSerializer json;
    const enginelab::YamlEngineSerializer yaml;
    const auto jsonResult = json.decode(json.encode(roundTripConfig));
    const auto yamlResult = yaml.decode(yaml.encode(roundTripConfig));
    require(jsonResult && yamlResult
            && jsonResult.config->vehicle.drivenAxleLayout
                == enginelab::DrivenAxleLayout::front
            && yamlResult.config->vehicle.drivenAxleLayout
                == enginelab::DrivenAxleLayout::front
            && std::abs(jsonResult.config->vehicle.wheelbaseM - 2.73)
                < 1.0e-9
            && std::abs(yamlResult.config->vehicle
                .centerOfGravityHeightM - 0.49) < 1.0e-9,
        "schema 5 JSON/YAML must preserve vehicle load-transfer geometry");

    auto invalid = roundTripConfig;
    invalid.vehicle.centerOfGravityHeightM =
        invalid.vehicle.wheelbaseM;
    require(enginelab::validateEngineConfig(invalid).has_value(),
        "validation must reject a centre of gravity at or beyond the wheelbase");

    const auto catalog =
        enginelab::loadEngineCatalog(ENGINELAB_CATALOG_ROOT);
    // The exact count matters and is not redundant with `errors.empty()`: a file
    // the loader SKIPS rather than rejects produces no error, so only the count
    // catches an engine silently vanishing from the catalogue. Bump it when a
    // catalogue entry is deliberately added -- 18 covers the 16 base engines (the 13B rotary since 0.7.0),
    // the CP2 full-system variant and the explicit audio-physics lab variant.
    require(catalog.errors.empty() && catalog.entries.size() == 18,
        "the full schema-5 catalogue and vehicle parts must load");
    require(findEngine(catalog, "K20A").vehicle.drivenAxleLayout
                == enginelab::DrivenAxleLayout::front
            && findEngine(catalog, "Audi I5").vehicle.drivenAxleLayout
                == enginelab::DrivenAxleLayout::all
            && findEngine(catalog, "Aircooled").vehicle.drivenAxleLayout
                == enginelab::DrivenAxleLayout::rear
            && findEngine(catalog, "VW EA288").vehicle.drivenAxleLayout
                == enginelab::DrivenAxleLayout::front,
        "catalogue engines must select their authored driveline layout");

    {
        auto diagnosticConfig = enginelab::makeDefaultV8();
        enginelab::EngineState diagnosticState;
        diagnosticState.load = 0.8;
        diagnosticState.rpm = 3'000.0;
        diagnosticState.cylinderStateCount = 8;
        for (std::size_t cylinder = 0; cylinder < 8; ++cylinder)
            diagnosticState.cylinderStates[cylinder].injectorCapacityRatio = 0.50;
        diagnosticState.cylinderStates[7].injectorCapacityRatio = 0.05;
        const auto diagnostics = enginelab::EngineDiagnostics {}.evaluate(
            diagnosticConfig, diagnosticState);
        const auto saturated = std::any_of(diagnostics.begin(), diagnostics.end(),
            [](const auto& item) { return item.code == "injection.capacity"; });
        require(saturated,
            "one saturated injector must not be hidden by the cylinder average");
    }

    {
        auto dieselConfig = enginelab::makeDefaultInlineFour();
        dieselConfig.fuel = enginelab::FuelType::diesel;
        enginelab::EngineState state;
        state.load = 0.9;
        state.rpm = 2'500.0;
        state.targetAirFuelRatio = 17.0;
        state.airFuelRatio = 22.0;
        state.lambda = 1.50;
        state.airFuelRatioValid = true;
        const auto normal = enginelab::EngineDiagnostics {}.evaluate(
            dieselConfig, state);
        require(std::none_of(normal.begin(), normal.end(), [](const auto& item) {
                return item.code == "combustion.lean"
                    || item.code == "combustion.diesel_smoke_limit";
            }),
            "a normally lean diesel must not inherit the gasoline lean fault");
        state.airFuelRatio = 16.0;
        state.lambda = 16.0
            / dieselConfig.fuelProperties.stoichiometricAirFuelRatio;
        const auto smoky = enginelab::EngineDiagnostics {}.evaluate(
            dieselConfig, state);
        require(std::any_of(smoky.begin(), smoky.end(), [](const auto& item) {
                return item.code == "combustion.diesel_smoke_limit";
            }),
            "a diesel richer than its smoke floor must be diagnosed explicitly");
    }

    {
        enginelab::ForcedInductionConfig turbo;
        turbo.turbineFlowAreaMm2 = 700.0;
        turbo.wastegateFlowAreaMm2 = 500.0;
        const auto shutGate = enginelab::partitionTurboExhaustFlow(
            turbo, 1.2, 0.0);
        require(std::abs(shutGate.turbineKgPerSecond - 1.2) < 1.0e-12
                && std::abs(shutGate.wastegateKgPerSecond) < 1.0e-12,
            "a shut wastegate must route all exhaust through the turbine");
        const auto openGate = enginelab::partitionTurboExhaustFlow(
            turbo, 1.2, 0.6);
        require(std::abs(openGate.turbineKgPerSecond - 0.84) < 1.0e-12
                && std::abs(openGate.wastegateKgPerSecond - 0.36) < 1.0e-12
                && std::abs(openGate.turbineKgPerSecond
                    + openGate.wastegateKgPerSecond - 1.2) < 1.0e-12,
            "wastegate flow split must conserve the measured exhaust mass");
    }

    {
        const auto reportsBackPressure = [](const enginelab::EngineConfig& config,
                                            enginelab::EngineState state) {
            const auto diagnostics = enginelab::EngineDiagnostics {}.evaluate(
                config, state);
            return std::any_of(diagnostics.begin(), diagnostics.end(),
                [](const auto& item) {
                    return item.code == "exhaust.back_pressure";
                });
        };
        auto naturallyAspirated = enginelab::makeDefaultV8();
        enginelab::EngineState state;
        state.load = 0.8;
        state.rpm = 3'000.0;
        state.exhaustPressureKpa = naturallyAspirated.ambientPressureKpa
            + 180.0; // instantaneous blowdown peak: diagnostic must ignore it
        state.exhaustBackPressureKpa = naturallyAspirated.ambientPressureKpa
            + 39.0;
        require(!reportsBackPressure(naturallyAspirated, state),
            "a blowdown peak must not masquerade as excessive mean back pressure");
        state.exhaustBackPressureKpa = naturallyAspirated.ambientPressureKpa
            + 41.0;
        require(reportsBackPressure(naturallyAspirated, state),
            "an NA mean back-pressure excess above 40 kPa must be diagnosed");

        auto turbocharged = naturallyAspirated;
        turbocharged.forcedInduction.enabled = true;
        turbocharged.forcedInduction.type =
            enginelab::ForcedInductionType::turbocharger;
        turbocharged.forcedInduction.fullBoostRpm = 3'500.0;
        state.rpm = 4'000.0;
        state.boostPressureRatio = 2.0;
        state.manifoldPressureKpa = 190.0;
        state.exhaustBackPressureKpa = 265.0;
        require(!reportsBackPressure(turbocharged, state),
            "a healthy post-spool turbo drive-pressure ratio must not be diagnosed");
        state.exhaustBackPressureKpa = 385.0;
        require(reportsBackPressure(turbocharged, state),
            "a post-spool turbo drive-pressure ratio above 2:1 must be diagnosed");
        state.rpm = 2'500.0;
        require(!reportsBackPressure(turbocharged, state),
            "a pre-spool pressure transient must not latch the turbo diagnostic");
    }

    // A stalled engine left in gear with the clutch out: its friction holds
    // the crank, it does not drive the car. Its resistive torque used to be
    // passed through the locked clutch as a drive torque, and the car rolled
    // backwards at a steady 0.3 km/h (Audi I5-like, stalled on a launch).
    {
        auto config = launchConfig(enginelab::DrivenAxleLayout::front);
        config.vehicle.tyreGripLimitEnabled = false;
        config.vehicle.rollingResistanceCoefficient = 0.012;
        enginelab::DrivelineModel model(config);
        model.requestGear(0);
        enginelab::EngineState stalled;
        stalled.simulationTimeSeconds = 5.0;
        stalled.torqueNm = -6.7;
        stalled.cycleAveragedTorqueNm = -6.7;
        enginelab::DrivelineOutput output;
        auto fastest = 0.0;
        for (int step = 0; step < 2'400; ++step) {
            output = model.advance(1.0 / 240.0, stalled, 0.0, 1.0, 0.0);
            fastest = std::max(fastest, std::abs(output.vehicleSpeedMps));
        }
        std::cout << "stalled in gear: fastest " << fastest * 3.6 << " km/h\n";
        require(fastest < 1.0e-3, "a stalled engine in gear must not drive the car");
    }
    // A car coasting in neutral comes to rest: rolling resistance
    // used to vanish below 1 cm/s, so it crept on at whatever speed it had
    // left there, for ever.
    {
        auto config = launchConfig(enginelab::DrivenAxleLayout::front);
        config.vehicle.tyreGripLimitEnabled = false;
        config.vehicle.rollingResistanceCoefficient = 0.012;
        enginelab::DrivelineModel model(config);
        model.requestGear(0);
        enginelab::EngineState pulling;
        pulling.simulationTimeSeconds = 5.0;
        pulling.rpm = 1'500.0;
        pulling.angularVelocityRadPerSecond = pulling.rpm * 2.0 * std::numbers::pi / 60.0;
        pulling.torqueNm = 60.0;
        pulling.cycleAveragedTorqueNm = 60.0;
        enginelab::DrivelineOutput output;
        for (int step = 0; step < 60; ++step) output = model.advance(1.0 / 240.0, pulling, 0.0, 1.0, 0.0);
        require(output.vehicleSpeedMps > 0.05, "the coasting witness must first move the car");
        model.requestGear(-1);
        // About 13.6 km/h, losing 0.12 m/s^2 to rolling: at rest after 33 s.
        for (int step = 0; step < 240 * 60; ++step) output = model.advance(1.0 / 240.0, pulling, 0.0, 0.0, 0.0);
        std::cout << "coasted 60 s: " << output.vehicleSpeedMps * 3.6 << " km/h\n";
        require(std::abs(output.vehicleSpeedMps) < 1.0e-4, "a coasting car must come to rest");
    }

    // Engine braking through a slipping clutch: the wheels drive the engine,
    // so the gearbox's loss comes out of the wheel's power. The wheel gave
    // the clutch's torque times the ratio times the efficiency, so the crank
    // received more power than the wheel lost (audit PH-01).
    {
        auto config = launchConfig(enginelab::DrivenAxleLayout::front);
        config.vehicle.tyreGripLimitEnabled = false;
        const auto ratio = config.transmission.gearRatios.front() * config.transmission.finalDriveRatio;
        const auto efficiency = config.transmission.drivelineEfficiency;
        enginelab::DrivelineModel model(config);
        model.requestGear(0);
        enginelab::EngineState engine;
        engine.simulationTimeSeconds = 5.0;
        engine.rpm = 3'000.0;
        engine.angularVelocityRadPerSecond = engine.rpm * 2.0 * std::numbers::pi / 60.0;
        engine.torqueNm = 200.0;
        engine.cycleAveragedTorqueNm = 200.0;
        enginelab::DrivelineOutput output;
        for (int step = 0; step < 240 * 4; ++step) output = model.advance(1.0 / 240.0, engine, 0.0, 1.0, 0.0);
        // The engine drops to 900 rpm with the clutch half let in: it slips
        // with the wheels turning the crank faster than the engine runs.
        engine.rpm = 900.0;
        engine.angularVelocityRadPerSecond = engine.rpm * 2.0 * std::numbers::pi / 60.0;
        engine.torqueNm = 0.0;
        engine.cycleAveragedTorqueNm = 0.0;
        for (int step = 0; step < 3; ++step) output = model.advance(1.0 / 240.0, engine, 0.0, 0.3, 0.0);
        const auto wheelOmega = output.vehicleSpeedMps / config.vehicle.tireRadiusM;
        const auto crankPowerW = output.engineCouplingTorqueNm * engine.angularVelocityRadPerSecond;
        const auto wheelPowerW = -output.wheelTorqueNm * wheelOmega;
        std::cout << "engine braking through a slipping clutch: slip " << output.clutchSlipRpm << " rpm, wheel "
                  << output.wheelTorqueNm << " N.m / clutch " << output.clutchTorqueNm << " N.m = "
                  << output.wheelTorqueNm / output.clutchTorqueNm << " (ratio / efficiency " << ratio / efficiency
                  << "); crank receives " << crankPowerW << " W, wheel gives " << wheelPowerW << " W\n";
        require(output.clutchStickFraction == 0.0 && output.clutchSlipRpm < -100.0 && output.clutchTorqueNm < 0.0,
            "the witness slips with the wheels driving the engine");
        require(std::abs(output.wheelTorqueNm / output.clutchTorqueNm - ratio / efficiency) < 1.0e-6 * ratio,
            "back-driven, the wheel gives the clutch's torque times the ratio over the efficiency");
        require(crankPowerW <= wheelPowerW, "the crank receives no more power than the wheel gives");
    }
    // The drag is the air's: at 50 and 120 kPa, both at 20 degC, a car
    // coasting in neutral with no rolling resistance slows 2.4 times as fast
    // in the denser air. The density was 1.225 whatever the atmosphere, so
    // the two coasted identically (audit PH-04).
    {
        const auto coastLoss = [](double pressureKpa) {
            auto config = launchConfig(enginelab::DrivenAxleLayout::front);
            config.vehicle.tyreGripLimitEnabled = false;
            config.ambientPressureKpa = pressureKpa;
            config.ambientTemperatureC = 20.0;
            enginelab::DrivelineModel model(config);
            model.requestGear(0);
            enginelab::EngineState pulling;
            pulling.simulationTimeSeconds = 5.0;
            pulling.rpm = 3'000.0;
            pulling.angularVelocityRadPerSecond = pulling.rpm * 2.0 * std::numbers::pi / 60.0;
            pulling.torqueNm = 200.0;
            pulling.cycleAveragedTorqueNm = 200.0;
            enginelab::DrivelineOutput output;
            for (int step = 0; step < 240 * 4; ++step) output = model.advance(1.0 / 240.0, pulling, 0.0, 1.0, 0.0);
            model.requestGear(-1);
            for (int step = 0; step < 24; ++step) output = model.advance(1.0 / 240.0, pulling, 0.0, 0.0, 0.0);
            const auto before = output.vehicleSpeedMps;
            for (int step = 0; step < 240; ++step) output = model.advance(1.0 / 240.0, pulling, 0.0, 0.0, 0.0);
            return std::pair { before, before - output.vehicleSpeedMps };
        };
        const auto [thinSpeed, thinLoss] = coastLoss(50.0);
        const auto [denseSpeed, denseLoss] = coastLoss(120.0);
        const auto ratio = denseLoss / thinLoss * (thinSpeed * thinSpeed) / (denseSpeed * denseSpeed);
        std::cout << "coasting 1 s from " << thinSpeed * 3.6 << " / " << denseSpeed * 3.6 << " km/h: lost "
                  << thinLoss << " / " << denseLoss << " m/s at 50 / 120 kPa (ratio " << ratio << ")\n";
        require(thinSpeed > 5.0 && thinLoss > 0.0, "the drag witness must first move the car");
        require(std::abs(ratio - 2.4) < 0.1, "the drag follows the air's density (120 / 50 = 2.4)");
    }
    // A live edit of the air reaches the clutch: it cooled toward the air the
    // driveline was built with (audit PH-06). In neutral it does no work,
    // so it sits at the ambient it cools toward.
    {
        auto config = launchConfig(enginelab::DrivenAxleLayout::front);
        config.ambientTemperatureC = 20.0;
        enginelab::DrivelineModel model(config);
        model.requestGear(-1);
        enginelab::EngineState idling;
        idling.simulationTimeSeconds = 5.0;
        idling.rpm = 900.0;
        idling.angularVelocityRadPerSecond = idling.rpm * 2.0 * std::numbers::pi / 60.0;
        auto output = model.advance(1.0 / 240.0, idling, 0.0, 0.0, 0.0);
        require(std::abs(output.clutchTemperatureC - 20.0) < 1.0e-9, "the clutch starts at the air's 20 degC");
        model.setAtmosphere(config.ambientPressureKpa, 40.0);
        output = model.advance(1.0 / 240.0, idling, 0.0, 0.0, 0.0);
        require(std::abs(output.clutchTemperatureC - 40.0) < 1.0e-9, "the clutch follows the air edited to 40 degC");
    }

    std::cout << "PASS: load transfer, persistence, catalogue layouts, injector and back-pressure diagnostics\n";
    return 0;
}
