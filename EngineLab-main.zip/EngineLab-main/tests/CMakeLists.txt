add_executable(EngineLabCoreTests CoreTests.cpp)
target_link_libraries(EngineLabCoreTests PRIVATE
    EngineLab::Foundation EngineLab::Events EngineLab::Physics EngineLab::Ecu
    EngineLab::Exhaust EngineLab::Simulation EngineLab::Serialization EngineLab::Catalog EngineLab::Runtime)
target_link_libraries(EngineLabCoreTests PRIVATE EngineLab::Audio)
target_compile_definitions(EngineLabCoreTests PRIVATE ENGINELAB_CATALOG_ROOT="${CMAKE_SOURCE_DIR}")
enginelab_set_warnings(EngineLabCoreTests)
add_test(NAME EngineLab.Core COMMAND EngineLabCoreTests)

add_executable(EngineLabAudioVoicingTests AudioVoicingTests.cpp)
target_link_libraries(EngineLabAudioVoicingTests PRIVATE
    EngineLab::Foundation EngineLab::Catalog)
target_compile_definitions(EngineLabAudioVoicingTests PRIVATE
    ENGINELAB_CATALOG_ROOT="${CMAKE_SOURCE_DIR}")
enginelab_set_warnings(EngineLabAudioVoicingTests)
add_test(NAME EngineLab.AudioVoicing COMMAND EngineLabAudioVoicingTests)

add_executable(EngineLabPorousLinerLossTests PorousLinerLossTests.cpp)
target_link_libraries(EngineLabPorousLinerLossTests PRIVATE EngineLab::Audio)
enginelab_set_warnings(EngineLabPorousLinerLossTests)
add_test(NAME EngineLab.PorousLinerLoss COMMAND EngineLabPorousLinerLossTests)

add_executable(EngineLabAutoGainSoftClipperTests AutoGainSoftClipperTests.cpp)
target_link_libraries(EngineLabAutoGainSoftClipperTests PRIVATE EngineLab::Audio)
enginelab_set_warnings(EngineLabAutoGainSoftClipperTests)
add_test(NAME EngineLab.AutoGainSoftClipper COMMAND EngineLabAutoGainSoftClipperTests)

add_executable(EngineLabValveTurbulenceNoiseTests ValveTurbulenceNoiseTests.cpp)
target_link_libraries(EngineLabValveTurbulenceNoiseTests PRIVATE EngineLab::Audio)
enginelab_set_warnings(EngineLabValveTurbulenceNoiseTests)
add_test(NAME EngineLab.ValveTurbulenceNoise COMMAND EngineLabValveTurbulenceNoiseTests)

add_executable(EngineLabCombustionCycleVariationTests
    CombustionCycleVariationTests.cpp)
target_link_libraries(EngineLabCombustionCycleVariationTests PRIVATE
    EngineLab::Physics)
enginelab_set_warnings(EngineLabCombustionCycleVariationTests)
add_test(NAME EngineLab.CombustionCycleVariation
    COMMAND EngineLabCombustionCycleVariationTests)

add_executable(EngineLabVehicleDynamicsTests VehicleDynamicsTests.cpp)
target_link_libraries(EngineLabVehicleDynamicsTests PRIVATE
    EngineLab::Foundation EngineLab::Runtime EngineLab::Diagnostics EngineLab::Serialization
    EngineLab::Catalog)
target_compile_definitions(EngineLabVehicleDynamicsTests PRIVATE
    ENGINELAB_CATALOG_ROOT="${CMAKE_SOURCE_DIR}")
enginelab_set_warnings(EngineLabVehicleDynamicsTests)
add_test(NAME EngineLab.VehicleDynamics COMMAND EngineLabVehicleDynamicsTests)

add_executable(EngineLabDynoEstimatorTests DynoEstimatorTests.cpp)
target_link_libraries(EngineLabDynoEstimatorTests PRIVATE EngineLab::Runtime)
enginelab_set_warnings(EngineLabDynoEstimatorTests)
add_test(NAME EngineLab.DynoEstimator COMMAND EngineLabDynoEstimatorTests)

add_executable(EngineLabDynoQualityGateTests DynoQualityGateTests.cpp)
target_link_libraries(EngineLabDynoQualityGateTests PRIVATE EngineLab::Runtime)
enginelab_set_warnings(EngineLabDynoQualityGateTests)
add_test(NAME EngineLab.DynoQualityGate COMMAND EngineLabDynoQualityGateTests)

add_executable(EngineLabDynoRunArchiveTests DynoRunArchiveTests.cpp)
target_link_libraries(EngineLabDynoRunArchiveTests PRIVATE EngineLab::Runtime)
enginelab_set_warnings(EngineLabDynoRunArchiveTests)
add_test(NAME EngineLab.DynoRunArchive COMMAND EngineLabDynoRunArchiveTests)

add_executable(EngineLabAudioUpsamplingTests AudioUpsamplingTests.cpp)
target_link_libraries(EngineLabAudioUpsamplingTests PRIVATE EngineLab::Audio)
enginelab_set_warnings(EngineLabAudioUpsamplingTests)
add_test(NAME EngineLab.AudioUpsampling COMMAND EngineLabAudioUpsamplingTests)

add_executable(EngineLabThreadSchedulingTests ThreadSchedulingTests.cpp)
target_link_libraries(EngineLabThreadSchedulingTests PRIVATE EngineLab::Foundation)
enginelab_set_warnings(EngineLabThreadSchedulingTests)
add_test(NAME EngineLab.ThreadScheduling COMMAND EngineLabThreadSchedulingTests)

add_executable(EngineLabCylinderWorkerPoolTests CylinderWorkerPoolTests.cpp)
target_link_libraries(EngineLabCylinderWorkerPoolTests PRIVATE EngineLab::Simulation)
enginelab_set_warnings(EngineLabCylinderWorkerPoolTests)
add_test(NAME EngineLab.CylinderWorkerPool COMMAND EngineLabCylinderWorkerPoolTests)

add_executable(EngineLabStructuralNvhTests StructuralNvhTests.cpp)
target_link_libraries(EngineLabStructuralNvhTests PRIVATE
    EngineLab::Audio EngineLab::Serialization EngineLab::Catalog)
enginelab_set_warnings(EngineLabStructuralNvhTests)
add_test(NAME EngineLab.StructuralNvh COMMAND EngineLabStructuralNvhTests)

add_executable(EngineLabPhysicsRegressionTests PhysicsRegressionTests.cpp)
target_link_libraries(EngineLabPhysicsRegressionTests PRIVATE EngineLab::Foundation EngineLab::Physics)
enginelab_set_warnings(EngineLabPhysicsRegressionTests)
add_test(NAME EngineLab.PhysicsRegression COMMAND EngineLabPhysicsRegressionTests)

add_executable(EngineLabCombustionPhasingTests CombustionPhasingTests.cpp)
target_link_libraries(EngineLabCombustionPhasingTests PRIVATE
    EngineLab::Foundation EngineLab::Events EngineLab::Physics EngineLab::Ecu
    EngineLab::Exhaust EngineLab::Simulation)
enginelab_set_warnings(EngineLabCombustionPhasingTests)
add_test(NAME EngineLab.CombustionPhasing COMMAND EngineLabCombustionPhasingTests)

add_executable(EngineLabIntakeTuningTests IntakeTuningTests.cpp)
target_link_libraries(EngineLabIntakeTuningTests PRIVATE
    EngineLab::Foundation EngineLab::Events EngineLab::Physics EngineLab::Ecu
    EngineLab::Exhaust EngineLab::Simulation)
enginelab_set_warnings(EngineLabIntakeTuningTests)
# --enforce-tuning keeps the four literature criteria hard. --compare-oracle
# additionally constrains the production intake mesh to 15% point-by-point
# against the 30 mm target/12-cell cap/RK2/every-substep numerical reference,
# temporally qualified at Courant 0.1, on the same
# joint-manifold or explicitly selected historical intake topology.
# These are independent guards: real-engine curve shape and numerical drift.
add_test(NAME EngineLab.IntakeTuning COMMAND EngineLabIntakeTuningTests
    --enforce-tuning --compare-oracle)
set_tests_properties(EngineLab.IntakeTuning PROPERTIES TIMEOUT 600)

add_executable(EngineLabIntakeAcousticConvergenceTests
    IntakeAcousticConvergenceTests.cpp)
target_link_libraries(EngineLabIntakeAcousticConvergenceTests PRIVATE
    EngineLab::GasDynamics EngineLab::Simulation)
enginelab_set_warnings(EngineLabIntakeAcousticConvergenceTests)
add_test(NAME EngineLab.IntakeAcousticConvergence
    COMMAND EngineLabIntakeAcousticConvergenceTests)
set_tests_properties(EngineLab.IntakeAcousticConvergence PROPERTIES TIMEOUT 60)

add_executable(EngineLabIntakeRunnerCourantTests IntakeRunnerCourantTests.cpp)
target_link_libraries(EngineLabIntakeRunnerCourantTests PRIVATE EngineLab::GasDynamics)
enginelab_set_warnings(EngineLabIntakeRunnerCourantTests)
add_test(NAME EngineLab.IntakeRunnerCourant COMMAND EngineLabIntakeRunnerCourantTests)

add_executable(EngineLabExhaustJunctionStepTests ExhaustJunctionStepTests.cpp)
target_link_libraries(EngineLabExhaustJunctionStepTests PRIVATE EngineLab::GasDynamics)
enginelab_set_warnings(EngineLabExhaustJunctionStepTests)
add_test(NAME EngineLab.ExhaustJunctionStep COMMAND EngineLabExhaustJunctionStepTests)

add_executable(EngineLabIntakePlenumPassivityTests IntakePlenumPassivityTests.cpp)
target_link_libraries(EngineLabIntakePlenumPassivityTests PRIVATE EngineLab::GasDynamics)
enginelab_set_warnings(EngineLabIntakePlenumPassivityTests)
add_test(NAME EngineLab.IntakePlenumPassivity COMMAND EngineLabIntakePlenumPassivityTests)
set_tests_properties(EngineLab.IntakePlenumPassivity PROPERTIES TIMEOUT 60)
add_test(NAME EngineLab.IntakeBoundaryAdmittance
    COMMAND EngineLabIntakePlenumPassivityTests --boundary-admittance)
add_test(NAME EngineLab.IntakeOutletPredictionEquilibrium
    COMMAND EngineLabIntakePlenumPassivityTests --outlet-prediction-equilibrium)
set_tests_properties(EngineLab.IntakeBoundaryAdmittance
    EngineLab.IntakeOutletPredictionEquilibrium PROPERTIES TIMEOUT 60)

add_executable(EngineLabIntakeCouplingContinuityTests IntakeCouplingContinuityTests.cpp)
target_link_libraries(EngineLabIntakeCouplingContinuityTests PRIVATE
    EngineLab::Foundation EngineLab::Events EngineLab::Physics EngineLab::Ecu
    EngineLab::Exhaust EngineLab::Simulation)
enginelab_set_warnings(EngineLabIntakeCouplingContinuityTests)
add_test(NAME EngineLab.IntakeCouplingContinuity COMMAND EngineLabIntakeCouplingContinuityTests)
set_tests_properties(EngineLab.IntakeCouplingContinuity PROPERTIES TIMEOUT 60)

add_executable(EngineLabIntakeSplitReservoirContinuityTests
    IntakeSplitReservoirContinuityTests.cpp)
target_link_libraries(EngineLabIntakeSplitReservoirContinuityTests PRIVATE
    EngineLab::Foundation EngineLab::Events EngineLab::Physics EngineLab::Ecu
    EngineLab::Exhaust EngineLab::Simulation EngineLab::Catalog EngineLab::Runtime)
target_compile_definitions(EngineLabIntakeSplitReservoirContinuityTests PRIVATE
    ENGINELAB_CATALOG_ROOT="${CMAKE_SOURCE_DIR}")
enginelab_set_warnings(EngineLabIntakeSplitReservoirContinuityTests)
add_test(NAME EngineLab.IntakeSplitReservoirContinuity
    COMMAND EngineLabIntakeSplitReservoirContinuityTests)
set_tests_properties(EngineLab.IntakeSplitReservoirContinuity PROPERTIES TIMEOUT 60)

add_executable(EngineLabIntakeMovingBoundaryTests IntakeMovingBoundaryTests.cpp)
target_link_libraries(EngineLabIntakeMovingBoundaryTests PRIVATE EngineLab::GasDynamics)
enginelab_set_warnings(EngineLabIntakeMovingBoundaryTests)
add_test(NAME EngineLab.IntakeMovingBoundary COMMAND EngineLabIntakeMovingBoundaryTests)
set_tests_properties(EngineLab.IntakeMovingBoundary PROPERTIES TIMEOUT 60)

add_executable(EngineLabPartitionedExhaustNetworkTests PartitionedExhaustNetworkTests.cpp)
target_link_libraries(EngineLabPartitionedExhaustNetworkTests PRIVATE EngineLab::GasDynamics)
enginelab_set_warnings(EngineLabPartitionedExhaustNetworkTests)
add_test(NAME EngineLab.PartitionedExhaustNetwork COMMAND EngineLabPartitionedExhaustNetworkTests)
set_tests_properties(EngineLab.PartitionedExhaustNetwork PROPERTIES TIMEOUT 60)

add_executable(EngineLabRestrictionFaceTests RestrictionFaceTests.cpp)
target_link_libraries(EngineLabRestrictionFaceTests PRIVATE EngineLab::GasDynamics)
enginelab_set_warnings(EngineLabRestrictionFaceTests)
add_test(NAME EngineLab.RestrictionFace COMMAND EngineLabRestrictionFaceTests)
set_tests_properties(EngineLab.RestrictionFace PROPERTIES TIMEOUT 60)

add_executable(EngineLabJointIntakeManifoldTests JointIntakeManifoldTests.cpp)
target_link_libraries(EngineLabJointIntakeManifoldTests PRIVATE
    EngineLab::Foundation EngineLab::Events EngineLab::Physics EngineLab::Ecu
    EngineLab::Exhaust EngineLab::Simulation EngineLab::Catalog EngineLab::Runtime)
target_compile_definitions(EngineLabJointIntakeManifoldTests PRIVATE
    ENGINELAB_CATALOG_ROOT="${CMAKE_SOURCE_DIR}")
enginelab_set_warnings(EngineLabJointIntakeManifoldTests)
add_test(NAME EngineLab.JointIntakeManifold COMMAND EngineLabJointIntakeManifoldTests)
set_tests_properties(EngineLab.JointIntakeManifold PROPERTIES TIMEOUT 120)

add_executable(EngineLabAngularStepResolutionTests AngularStepResolutionTests.cpp)
target_link_libraries(EngineLabAngularStepResolutionTests PRIVATE
    EngineLab::Foundation EngineLab::Events EngineLab::Physics EngineLab::Ecu
    EngineLab::Exhaust EngineLab::Simulation EngineLab::Catalog EngineLab::Runtime)
target_compile_definitions(EngineLabAngularStepResolutionTests PRIVATE
    ENGINELAB_CATALOG_ROOT="${CMAKE_SOURCE_DIR}")
enginelab_set_warnings(EngineLabAngularStepResolutionTests)
add_test(NAME EngineLab.AngularStepResolution COMMAND EngineLabAngularStepResolutionTests)
set_tests_properties(EngineLab.AngularStepResolution PROPERTIES TIMEOUT 240)

add_executable(EngineLabBrakeCycleNumericalQualityTests
    BrakeCycleNumericalQualityTests.cpp)
target_link_libraries(EngineLabBrakeCycleNumericalQualityTests PRIVATE
    EngineLab::Foundation EngineLab::Events EngineLab::Physics EngineLab::Ecu
    EngineLab::Exhaust EngineLab::Simulation)
enginelab_set_warnings(EngineLabBrakeCycleNumericalQualityTests)
add_test(NAME EngineLab.BrakeCycleNumericalQuality
    COMMAND EngineLabBrakeCycleNumericalQualityTests)
set_tests_properties(EngineLab.BrakeCycleNumericalQuality PROPERTIES TIMEOUT 60)

add_executable(EngineLabGasExchangeTests GasExchangeTests.cpp)
target_link_libraries(EngineLabGasExchangeTests PRIVATE
    EngineLab::Foundation EngineLab::Events EngineLab::Physics EngineLab::Ecu
    EngineLab::Exhaust EngineLab::Simulation)
enginelab_set_warnings(EngineLabGasExchangeTests)
# Registered WITHOUT --enforce-gas-exchange on purpose. The two literature
# pumping ceilings are frozen from Heywood ch. 13 and the simulator measures
# roughly three times the high-rpm one today, so they are reported and not
# gated; the always-on checks (sign, growth, net == gross + pmep, absorber
# holding, WOT MAP) do gate. Promotion is adding the flag here -- never
# relaxing a ceiling in the test. Same staging as EngineLab.IntakeTuning.
add_test(NAME EngineLab.GasExchange COMMAND EngineLabGasExchangeTests)
set_tests_properties(EngineLab.GasExchange PROPERTIES TIMEOUT 600)

add_executable(EngineLabOverrunThermalRegressionTests OverrunThermalRegressionTests.cpp)
target_link_libraries(EngineLabOverrunThermalRegressionTests PRIVATE
    EngineLab::Foundation EngineLab::Events EngineLab::Physics EngineLab::Ecu
    EngineLab::Exhaust EngineLab::Simulation EngineLab::Catalog EngineLab::Runtime)
target_compile_definitions(EngineLabOverrunThermalRegressionTests PRIVATE
    ENGINELAB_CATALOG_ROOT="${CMAKE_SOURCE_DIR}")
enginelab_set_warnings(EngineLabOverrunThermalRegressionTests)
add_test(NAME EngineLab.OverrunThermalRegression
    COMMAND EngineLabOverrunThermalRegressionTests)

add_executable(EngineLabPartLoadFuellingRegressionTests PartLoadFuellingRegressionTests.cpp)
target_link_libraries(EngineLabPartLoadFuellingRegressionTests PRIVATE
    EngineLab::Foundation EngineLab::Events EngineLab::Physics EngineLab::Ecu
    EngineLab::Exhaust EngineLab::Simulation EngineLab::Catalog EngineLab::Runtime)
target_compile_definitions(EngineLabPartLoadFuellingRegressionTests PRIVATE
    ENGINELAB_CATALOG_ROOT="${CMAKE_SOURCE_DIR}")
enginelab_set_warnings(EngineLabPartLoadFuellingRegressionTests)
add_test(NAME EngineLab.PartLoadFuelling
    COMMAND EngineLabPartLoadFuellingRegressionTests)
set_tests_properties(EngineLab.PartLoadFuelling PROPERTIES TIMEOUT 600)

add_executable(EngineLabIdleStabilityRegressionTests IdleStabilityRegressionTests.cpp)
target_link_libraries(EngineLabIdleStabilityRegressionTests PRIVATE
    EngineLab::Foundation EngineLab::Events EngineLab::Physics EngineLab::Ecu
    EngineLab::Exhaust EngineLab::Simulation EngineLab::Catalog EngineLab::Runtime)
target_compile_definitions(EngineLabIdleStabilityRegressionTests PRIVATE
    ENGINELAB_CATALOG_ROOT="${CMAKE_SOURCE_DIR}")
enginelab_set_warnings(EngineLabIdleStabilityRegressionTests)
add_test(NAME EngineLab.IdleStabilityRegression
    COMMAND EngineLabIdleStabilityRegressionTests)

add_executable(EngineLabShiftStyleTests ShiftStyleTests.cpp)
target_link_libraries(EngineLabShiftStyleTests PRIVATE
    EngineLab::Foundation EngineLab::Events EngineLab::Physics EngineLab::Ecu
    EngineLab::Exhaust EngineLab::Simulation EngineLab::Catalog EngineLab::Runtime
    EngineLab::Serialization)
target_compile_definitions(EngineLabShiftStyleTests PRIVATE
    ENGINELAB_CATALOG_ROOT="${CMAKE_SOURCE_DIR}")
enginelab_set_warnings(EngineLabShiftStyleTests)
add_test(NAME EngineLab.ShiftStyle COMMAND EngineLabShiftStyleTests)

add_executable(EngineLabDriverCommandTests DriverCommandTests.cpp)
target_link_libraries(EngineLabDriverCommandTests PRIVATE
    EngineLab::Foundation EngineLab::Catalog EngineLab::Runtime)
target_compile_definitions(EngineLabDriverCommandTests PRIVATE
    ENGINELAB_CATALOG_ROOT="${CMAKE_SOURCE_DIR}")
enginelab_set_warnings(EngineLabDriverCommandTests)
add_test(NAME EngineLab.DriverCommand COMMAND EngineLabDriverCommandTests)

add_executable(EngineLabActiveLimitsTests ActiveLimitsTests.cpp)
target_link_libraries(EngineLabActiveLimitsTests PRIVATE
    EngineLab::Foundation EngineLab::Calibration EngineLab::Events EngineLab::Physics EngineLab::Ecu
    EngineLab::Exhaust EngineLab::Simulation EngineLab::Catalog EngineLab::Runtime)
target_compile_definitions(EngineLabActiveLimitsTests PRIVATE
    ENGINELAB_CATALOG_ROOT="${CMAKE_SOURCE_DIR}")
if(MSVC)
    target_link_options(EngineLabActiveLimitsTests PRIVATE /STACK:8388608)
endif()
enginelab_set_warnings(EngineLabActiveLimitsTests)
add_test(NAME EngineLab.ActiveLimits COMMAND EngineLabActiveLimitsTests)

add_executable(EngineLabTurboFitTests TurboFitTests.cpp)
target_link_libraries(EngineLabTurboFitTests PRIVATE
    EngineLab::Foundation EngineLab::Events EngineLab::Physics EngineLab::Ecu
    EngineLab::Exhaust EngineLab::Simulation EngineLab::Catalog EngineLab::Runtime)
target_compile_definitions(EngineLabTurboFitTests PRIVATE
    ENGINELAB_CATALOG_ROOT="${CMAKE_SOURCE_DIR}")
enginelab_set_warnings(EngineLabTurboFitTests)
add_test(NAME EngineLab.TurboFit COMMAND EngineLabTurboFitTests)

add_executable(EngineLabEngineBrakeTests EngineBrakeTests.cpp)
target_link_libraries(EngineLabEngineBrakeTests PRIVATE
    EngineLab::Foundation EngineLab::Events EngineLab::Physics EngineLab::Ecu
    EngineLab::Exhaust EngineLab::Simulation EngineLab::Catalog EngineLab::Runtime)
target_compile_definitions(EngineLabEngineBrakeTests PRIVATE
    ENGINELAB_CATALOG_ROOT="${CMAKE_SOURCE_DIR}")
enginelab_set_warnings(EngineLabEngineBrakeTests)
add_test(NAME EngineLab.EngineBrake COMMAND EngineLabEngineBrakeTests)

add_executable(EngineLabTruckDriveTests TruckDriveTests.cpp)
target_link_libraries(EngineLabTruckDriveTests PRIVATE
    EngineLab::Foundation EngineLab::Events EngineLab::Physics EngineLab::Ecu
    EngineLab::Exhaust EngineLab::Simulation EngineLab::Catalog EngineLab::Runtime)
target_compile_definitions(EngineLabTruckDriveTests PRIVATE
    ENGINELAB_CATALOG_ROOT="${CMAKE_SOURCE_DIR}")
enginelab_set_warnings(EngineLabTruckDriveTests)
add_test(NAME EngineLab.TruckDrive COMMAND EngineLabTruckDriveTests)

add_executable(EngineLabDynoHoldTests DynoHoldTests.cpp)
target_link_libraries(EngineLabDynoHoldTests PRIVATE
    EngineLab::Foundation EngineLab::Events EngineLab::Physics EngineLab::Ecu
    EngineLab::Exhaust EngineLab::Simulation EngineLab::Catalog EngineLab::Runtime)
target_compile_definitions(EngineLabDynoHoldTests PRIVATE
    ENGINELAB_CATALOG_ROOT="${CMAKE_SOURCE_DIR}")
enginelab_set_warnings(EngineLabDynoHoldTests)
add_test(NAME EngineLab.DynoHold COMMAND EngineLabDynoHoldTests)
set_tests_properties(EngineLab.DynoHold PROPERTIES TIMEOUT 300)

add_executable(EngineLabEcuCalibrationIntegrationTests EcuCalibrationIntegrationTests.cpp)
target_link_libraries(EngineLabEcuCalibrationIntegrationTests PRIVATE
    EngineLab::Foundation EngineLab::Calibration EngineLab::Ecu)
enginelab_set_warnings(EngineLabEcuCalibrationIntegrationTests)
add_test(NAME EngineLab.EcuCalibration COMMAND EngineLabEcuCalibrationIntegrationTests)

add_executable(EngineLabSavedEngineTests SavedEngineTests.cpp)
target_link_libraries(EngineLabSavedEngineTests PRIVATE
    EngineLab::Foundation EngineLab::Calibration EngineLab::Events EngineLab::Physics EngineLab::Ecu
    EngineLab::Exhaust EngineLab::Simulation EngineLab::Serialization EngineLab::Catalog EngineLab::Runtime
    EngineLab::Audio)
target_compile_definitions(EngineLabSavedEngineTests PRIVATE ENGINELAB_CATALOG_ROOT="${CMAKE_SOURCE_DIR}")
enginelab_set_warnings(EngineLabSavedEngineTests)
add_test(NAME EngineLab.SavedEngine COMMAND EngineLabSavedEngineTests)
set_tests_properties(EngineLab.SavedEngine PROPERTIES TIMEOUT 600)
if(MSVC)
    target_link_options(EngineLabSavedEngineTests PRIVATE /STACK:8388608)
endif()

add_executable(EngineLabRealtimeRegressionTests
    RealtimeRegressionTests.cpp
    ExhaustTransferTests.cpp
    LiveChangeTests.cpp
    LiveSettingsTests.cpp
    LiveIntakeTests.cpp
    LiveTuningTests.cpp
    CameraMicrophoneTests.cpp)
target_link_libraries(EngineLabRealtimeRegressionTests PRIVATE EngineLab::Audio EngineLab::Catalog)
target_compile_definitions(EngineLabRealtimeRegressionTests PRIVATE
    ENGINELAB_CATALOG_ROOT="${CMAKE_SOURCE_DIR}")
enginelab_set_warnings(EngineLabRealtimeRegressionTests)
add_test(NAME EngineLab.RealtimeRegression COMMAND EngineLabRealtimeRegressionTests)
if(MSVC)
    target_link_options(EngineLabRealtimeRegressionTests PRIVATE /STACK:8388608)
endif()

# Fixed-source transfer oracle for the complete authored exhaust DAG. It is
# intentionally separate from the engine/audio render harnesses: no catalogue,
# running simulator, voicing, random source or external recording can obscure
# whether geometry itself changes the passive acoustic transfer. Reuse the
# realtime-regression binary so JUCE's module sources compile only once.
add_test(NAME EngineLab.ExhaustTransfer
    COMMAND EngineLabRealtimeRegressionTests --exhaust-transfer-only)
set_tests_properties(EngineLab.ExhaustTransfer PROPERTIES TIMEOUT 30)

# Live exhaust changes: the running simulator and renderer take a resized
# exhaust without a restart. Same binary, for the same reason.
add_test(NAME EngineLab.LiveChange
    COMMAND EngineLabRealtimeRegressionTests --live-change-only)
# Live bore and stroke changes, on the same simulator path.
add_test(NAME EngineLab.LiveCylinderResize
    COMMAND EngineLabRealtimeRegressionTests --live-resize-only)
# Live injector and forced-induction settings, simulator and turbo sound.
add_test(NAME EngineLab.LiveSettings
    COMMAND EngineLabRealtimeRegressionTests --live-settings-only)
# Live intake sizes (runners, plenums, throttles), simulator and intake sound.
add_test(NAME EngineLab.LiveIntake
    COMMAND EngineLabRealtimeRegressionTests --live-intake-only)
# Live tuning (flywheel, cams, ambient, gearbox) on a running simulator.
add_test(NAME EngineLab.LiveTuning
    COMMAND EngineLabRealtimeRegressionTests --live-tuning-only)
# The camera microphone: a listener that moves, glides and comes back.
add_test(NAME EngineLab.CameraMicrophone
    COMMAND EngineLabRealtimeRegressionTests --camera-microphone-only)

add_executable(EngineLabOfflineAudioExportTests OfflineAudioExportTests.cpp)
target_link_libraries(EngineLabOfflineAudioExportTests PRIVATE
    EngineLab::Audio EngineLab::Catalog nlohmann_json::nlohmann_json)
target_compile_definitions(EngineLabOfflineAudioExportTests PRIVATE
    ENGINELAB_CATALOG_ROOT="${CMAKE_SOURCE_DIR}")
enginelab_set_warnings(EngineLabOfflineAudioExportTests)
add_test(NAME EngineLab.OfflineAudioExport
    COMMAND EngineLabOfflineAudioExportTests)
set_tests_properties(EngineLab.OfflineAudioExport PROPERTIES TIMEOUT 180)
if(MSVC)
    target_link_options(EngineLabOfflineAudioExportTests PRIVATE /STACK:8388608)
endif()

add_executable(EngineLabLoopPackExportTests LoopPackExportTests.cpp)
target_link_libraries(EngineLabLoopPackExportTests PRIVATE
    EngineLab::Audio EngineLab::Catalog nlohmann_json::nlohmann_json)
target_compile_definitions(EngineLabLoopPackExportTests PRIVATE
    ENGINELAB_CATALOG_ROOT="${CMAKE_SOURCE_DIR}")
enginelab_set_warnings(EngineLabLoopPackExportTests)
add_test(NAME EngineLab.LoopPackExport
    COMMAND EngineLabLoopPackExportTests)
set_tests_properties(EngineLab.LoopPackExport PROPERTIES TIMEOUT 300)
if(MSVC)
    target_link_options(EngineLabLoopPackExportTests PRIVATE /STACK:8388608)
endif()

add_executable(EngineLabExhaustValveTests ExhaustValveTests.cpp)
target_link_libraries(EngineLabExhaustValveTests PRIVATE
    EngineLab::Audio EngineLab::Catalog EngineLab::Serialization
    EngineLab::Simulation EngineLab::Ecu EngineLab::Events EngineLab::Physics
    EngineLab::Exhaust EngineLab::GasDynamics)
target_compile_definitions(EngineLabExhaustValveTests PRIVATE
    ENGINELAB_CATALOG_ROOT="${CMAKE_SOURCE_DIR}")
enginelab_set_warnings(EngineLabExhaustValveTests)
add_test(NAME EngineLab.ExhaustValve
    COMMAND EngineLabExhaustValveTests)
set_tests_properties(EngineLab.ExhaustValve PROPERTIES TIMEOUT 300)
if(MSVC)
    target_link_options(EngineLabExhaustValveTests PRIVATE /STACK:8388608)
endif()

add_executable(EngineLabOutletLowBandTests OutletLowBandTests.cpp)
target_link_libraries(EngineLabOutletLowBandTests PRIVATE
    EngineLab::Audio EngineLab::Catalog EngineLab::Exhaust EngineLab::GasDynamics)
target_compile_definitions(EngineLabOutletLowBandTests PRIVATE
    ENGINELAB_CATALOG_ROOT="${CMAKE_SOURCE_DIR}")
enginelab_set_warnings(EngineLabOutletLowBandTests)
add_test(NAME EngineLab.OutletLowBand
    COMMAND EngineLabOutletLowBandTests)
set_tests_properties(EngineLab.OutletLowBand PROPERTIES TIMEOUT 300)

add_executable(EngineLabAntiLagTests AntiLagTests.cpp)
target_link_libraries(EngineLabAntiLagTests PRIVATE
    EngineLab::Catalog EngineLab::Calibration EngineLab::Simulation EngineLab::Ecu
    EngineLab::Events EngineLab::Physics EngineLab::Exhaust)
target_compile_definitions(EngineLabAntiLagTests PRIVATE
    ENGINELAB_CATALOG_ROOT="${CMAKE_SOURCE_DIR}")
enginelab_set_warnings(EngineLabAntiLagTests)
add_test(NAME EngineLab.AntiLag COMMAND EngineLabAntiLagTests)
set_tests_properties(EngineLab.AntiLag PROPERTIES TIMEOUT 900)
if(MSVC)
    target_link_options(EngineLabAntiLagTests PRIVATE /STACK:8388608)
endif()

add_executable(EngineLabNitrousTests NitrousTests.cpp)
target_link_libraries(EngineLabNitrousTests PRIVATE
    EngineLab::Catalog EngineLab::Serialization EngineLab::Simulation EngineLab::Ecu
    EngineLab::Events EngineLab::Physics EngineLab::Exhaust)
target_compile_definitions(EngineLabNitrousTests PRIVATE
    ENGINELAB_CATALOG_ROOT="${CMAKE_SOURCE_DIR}")
enginelab_set_warnings(EngineLabNitrousTests)
add_test(NAME EngineLab.Nitrous COMMAND EngineLabNitrousTests)
set_tests_properties(EngineLab.Nitrous PROPERTIES TIMEOUT 900)
if(MSVC)
    target_link_options(EngineLabNitrousTests PRIVATE /STACK:8388608)
endif()

add_executable(EngineLabPassByMicrophoneTests PassByMicrophoneTests.cpp)
target_link_libraries(EngineLabPassByMicrophoneTests PRIVATE EngineLab::Audio)
enginelab_set_warnings(EngineLabPassByMicrophoneTests)
add_test(NAME EngineLab.PassByMicrophone
    COMMAND EngineLabPassByMicrophoneTests)
set_tests_properties(EngineLab.PassByMicrophone PROPERTIES TIMEOUT 120)

add_executable(EngineLabAudioWorkshopTests
    AudioWorkshopTests.cpp
    "${CMAKE_SOURCE_DIR}/src/app/src/AudioWorkshopWindow.cpp"
    "${CMAKE_SOURCE_DIR}/src/app/src/EcuTunerWindow.cpp"
    "${CMAKE_SOURCE_DIR}/src/app/src/ExhaustDesignerWindow.cpp"
    "${CMAKE_SOURCE_DIR}/src/app/src/FuelEditing.cpp"
    "${CMAKE_SOURCE_DIR}/src/app/src/FuelWindow.cpp"
    "${CMAKE_SOURCE_DIR}/src/app/src/EquipmentWindow.cpp"
    "${CMAKE_SOURCE_DIR}/src/app/src/PassByWindow.cpp"
    "${CMAKE_SOURCE_DIR}/src/app/src/Theme.cpp"
    "${CMAKE_SOURCE_DIR}/src/app/src/Widgets.cpp")
target_include_directories(EngineLabAudioWorkshopTests PRIVATE
    "${CMAKE_SOURCE_DIR}/src/app/include")
target_link_libraries(EngineLabAudioWorkshopTests PRIVATE
    EngineLab::Audio EngineLab::Catalog
    EngineLabJuce EngineLabFonts
    juce::juce_recommended_config_flags)
target_compile_definitions(EngineLabAudioWorkshopTests PRIVATE
    ENGINELAB_CATALOG_ROOT="${CMAKE_SOURCE_DIR}"
    JUCE_WEB_BROWSER=0
    JUCE_USE_CURL=0)
enginelab_set_warnings(EngineLabAudioWorkshopTests)
# The only test that constructs real JUCE components, so the only one that
# needs a display. Wrapping the command here, rather than wrapping `ctest` in
# CI, means a contributor's bare `ctest` works on Linux too.
set(enginelab_audio_workshop_command EngineLabAudioWorkshopTests)
if(UNIX AND NOT APPLE)
    # The wrapper finds Xvfb and a window manager itself and reports what is
    # missing. A bare Xvfb is not enough: JUCE dies with `BadAtom` when no
    # window manager has interned the `_NET_WM_*` atoms, which is why this
    # goes through a script rather than straight to `xvfb-run`.
    set(enginelab_audio_workshop_command
        "${CMAKE_SOURCE_DIR}/scripts/run-gui-test.sh"
        "$<TARGET_FILE:EngineLabAudioWorkshopTests>")
    find_program(ENGINELAB_XVFB_RUN xvfb-run)
    find_program(ENGINELAB_WINDOW_MANAGER matchbox-window-manager)
    if(NOT ENGINELAB_XVFB_RUN OR NOT ENGINELAB_WINDOW_MANAGER)
        message(STATUS
            "EngineLab: xvfb-run or matchbox-window-manager not found, so "
            "EngineLab.AudioWorkshop will need a desktop with a window manager")
    endif()
endif()
add_test(NAME EngineLab.AudioWorkshop
    COMMAND ${enginelab_audio_workshop_command})
set_tests_properties(EngineLab.AudioWorkshop PROPERTIES TIMEOUT 120)
if(MSVC)
    target_link_options(EngineLabAudioWorkshopTests PRIVATE /STACK:8388608)
endif()

# The main window's components (audit lot 7): no window is shown, but the
# components are real JUCE ones, so Linux runs it through the display wrapper.
add_executable(EngineLabAppLayoutTests
    AppLayoutTests.cpp
    "${CMAKE_SOURCE_DIR}/src/app/src/ActionMap.cpp"
    "${CMAKE_SOURCE_DIR}/src/app/src/DashboardModel.cpp"
    "${CMAKE_SOURCE_DIR}/src/app/src/DynoPanel.cpp"
    "${CMAKE_SOURCE_DIR}/src/app/src/ReadoutStrip.cpp"
    "${CMAKE_SOURCE_DIR}/src/app/src/SidePanel.cpp"
    "${CMAKE_SOURCE_DIR}/src/app/src/Theme.cpp"
    "${CMAKE_SOURCE_DIR}/src/app/src/TopBar.cpp"
    "${CMAKE_SOURCE_DIR}/src/app/src/TopMenus.cpp"
    "${CMAKE_SOURCE_DIR}/src/app/src/UnitFormat.cpp"
    "${CMAKE_SOURCE_DIR}/src/app/src/Widgets.cpp")
target_include_directories(EngineLabAppLayoutTests PRIVATE
    "${CMAKE_SOURCE_DIR}/src/app/include")
target_link_libraries(EngineLabAppLayoutTests PRIVATE
    EngineLab::Audio EngineLab::Catalog EngineLab::Diagnostics EngineLab::Render
    EngineLabJuce EngineLabFonts
    juce::juce_recommended_config_flags)
target_compile_definitions(EngineLabAppLayoutTests PRIVATE
    ENGINELAB_CATALOG_ROOT="${CMAKE_SOURCE_DIR}"
    JUCE_WEB_BROWSER=0
    JUCE_USE_CURL=0)
enginelab_set_warnings(EngineLabAppLayoutTests)
set(enginelab_app_layout_command EngineLabAppLayoutTests)
if(UNIX AND NOT APPLE)
    set(enginelab_app_layout_command
        "${CMAKE_SOURCE_DIR}/scripts/run-gui-test.sh"
        "$<TARGET_FILE:EngineLabAppLayoutTests>")
endif()
add_test(NAME EngineLab.AppLayout COMMAND ${enginelab_app_layout_command})
set_tests_properties(EngineLab.AppLayout PROPERTIES TIMEOUT 120)
if(MSVC)
    target_link_options(EngineLabAppLayoutTests PRIVATE /STACK:8388608)
endif()

if(TARGET EngineLabComparisonHarness)
    add_test(NAME EngineLab.CatalogPhysics COMMAND EngineLabComparisonHarness
        --output "${CMAKE_BINARY_DIR}/catalog-physics-test"
        --catalog-root "${CMAKE_SOURCE_DIR}")
endif()
if(TARGET EngineLabDynoSweepHarness)
    # The header and each data row are generated from fixed-size arrays whose
    # sizes are tied by a static assertion. This fast invocation also catches a
    # stale executable or argument/parser regression before a multi-minute sweep.
    add_test(NAME EngineLab.TurboDownstreamAuthority
        COMMAND EngineLabTurboDownstreamAuthorityHarness --enforce
                --catalog-root "${CMAKE_SOURCE_DIR}")
    set_tests_properties(EngineLab.TurboDownstreamAuthority
        PROPERTIES TIMEOUT 900)
    add_test(NAME EngineLab.DynoSchema COMMAND EngineLabDynoSweepHarness --schema-only)
    # Manufacturer-anchored rated points. Unlike CatalogPhysics, this is an
    # absolute torque/power gate: every point must be held within 2% rpm and
    # land within the committed 15% real-engine envelope.
    add_test(NAME EngineLab.CatalogReference
        COMMAND EngineLabDynoSweepHarness
            --catalog-root "${CMAKE_SOURCE_DIR}"
            --reference-file
                "${CMAKE_SOURCE_DIR}/tests/reference-data/catalog-manufacturer-points.csv")
    set_tests_properties(EngineLab.DynoSchema PROPERTIES
        PASS_REGULAR_EXPRESSION
            "exhaust_stroke_mep_bar,intake_stroke_mep_bar")
    set_tests_properties(EngineLab.CatalogReference PROPERTIES TIMEOUT 600)
    # Every catalogue turbo holds its boost at wide-open throttle across the
    # range. The 2JZ's 520 mm2 default gate was fully open from 5,500 rpm and
    # let the pressure ratio reach 2.47 at 6,000 rpm (journal 2026-10-06).
    add_test(NAME EngineLab.CatalogBoostHold
        COMMAND EngineLabDynoSweepHarness
            --catalog-root "${CMAKE_SOURCE_DIR}"
            --step 1000 --boost-hold-margin 0.05)
    set_tests_properties(EngineLab.CatalogBoostHold PROPERTIES TIMEOUT 600)
    # Engines the designer builds from their makers' data sheets alone, with
    # none of the catalogue's per-engine values, against the makers' rated
    # points. A report until the physics reaches the 15% envelope.
    if(TARGET EngineLabDesignBench)
        add_test(NAME EngineLab.DesignedEnginesBuild
            COMMAND EngineLabDesignBench --quiet --knock-limit
                --catalog-root "${CMAKE_SOURCE_DIR}"
                --spec "${CMAKE_SOURCE_DIR}/tests/reference-data/designed-engines.spec"
                --output "${CMAKE_BINARY_DIR}/designed-engines")
        set_tests_properties(EngineLab.DesignedEnginesBuild PROPERTIES
            TIMEOUT 900 FIXTURES_SETUP DesignedEngines)
        add_test(NAME EngineLab.DesignedReference
            COMMAND EngineLabDynoSweepHarness --report-only
                --catalog-root "${CMAKE_BINARY_DIR}/designed-engines"
                --reference-file
                    "${CMAKE_SOURCE_DIR}/tests/reference-data/designed-manufacturer-points.csv")
        set_tests_properties(EngineLab.DesignedReference PROPERTIES
            TIMEOUT 900 FIXTURES_REQUIRED DesignedEngines)
    endif()
endif()

# The tools refuse a bad argument with their message instead of ending
# without one (audit 2026-11-16): the message is what passes, so a crash fails.
if(TARGET EngineLabOfflineAudioExporter)
    add_test(NAME EngineLab.ToolArguments.ExporterTap
        COMMAND EngineLabOfflineAudioExporter --engine K20A
            --output "${CMAKE_BINARY_DIR}/tool-arguments/exporter-tap" --exhaust-tap bad:0.5)
    set_tests_properties(EngineLab.ToolArguments.ExporterTap PROPERTIES
        PASS_REGULAR_EXPRESSION "Exhaust tap is <component id>")
endif()
if(TARGET EngineLabAcousticTransferProbe)
    add_test(NAME EngineLab.ToolArguments.TransferProbeSeconds
        COMMAND EngineLabAcousticTransferProbe --filter K20A --component 100
            --seconds 0.000001 --max-hz 10)
    set_tests_properties(EngineLab.ToolArguments.TransferProbeSeconds PROPERTIES
        PASS_REGULAR_EXPRESSION "usage: EngineLabAcousticTransferProbe")
endif()
if(TARGET EngineLabDynoSweepHarness)
    # A reference check whose filter selects nothing fails (audit TL2-03).
    add_test(NAME EngineLab.ToolArguments.DynoReferenceNoMatch
        COMMAND EngineLabDynoSweepHarness --catalog-root "${CMAKE_SOURCE_DIR}"
            --reference-file "${CMAKE_SOURCE_DIR}/tests/reference-data/catalog-manufacturer-points.csv"
            --filter no-engine-matches-this)
    set_tests_properties(EngineLab.ToolArguments.DynoReferenceNoMatch PROPERTIES
        WILL_FAIL TRUE)
endif()
if(TARGET EngineLabSceneExport)
    # An index that cannot be written (a folder in its place) fails the
    # export (audit RT-06).
    add_test(NAME EngineLab.ToolArguments.SceneIndexBlockedSetup
        COMMAND "${CMAKE_COMMAND}" -E make_directory
            "${CMAKE_BINARY_DIR}/tool-arguments/scene-blocked/index.json")
    set_tests_properties(EngineLab.ToolArguments.SceneIndexBlockedSetup PROPERTIES
        FIXTURES_SETUP SceneIndexBlocked)
    add_test(NAME EngineLab.ToolArguments.SceneIndexBlocked
        COMMAND EngineLabSceneExport --out "${CMAKE_BINARY_DIR}/tool-arguments/scene-blocked"
            --filter no-engine-matches-this)
    set_tests_properties(EngineLab.ToolArguments.SceneIndexBlocked PROPERTIES
        FIXTURES_REQUIRED SceneIndexBlocked WILL_FAIL TRUE)
endif()
if(TARGET EngineLabAudioRenderHarness)
    add_test(NAME EngineLab.AudioRender COMMAND EngineLabAudioRenderHarness)
    add_test(NAME EngineLab.AudioRuntimeDiscontinuity
        COMMAND EngineLabAudioRenderHarness
            --runtime-filter "Merlin"
            --runtime-stall-ms 80)
    add_test(NAME EngineLab.AudioTransients
        COMMAND EngineLabAudioRenderHarness
            --transient-only
            --output "${CMAKE_BINARY_DIR}/audio-transient-test")
    if(ENGINELAB_ENABLE_SANITIZERS)
        set_tests_properties(
            EngineLab.AudioRender
            EngineLab.AudioRuntimeDiscontinuity
            PROPERTIES TIMEOUT 600)
        set_tests_properties(EngineLab.AudioTransients PROPERTIES TIMEOUT 600)
    else()
        set_tests_properties(
            EngineLab.AudioRender
            EngineLab.AudioRuntimeDiscontinuity
            PROPERTIES TIMEOUT 180)
        set_tests_properties(EngineLab.AudioTransients PROPERTIES TIMEOUT 180)
    endif()
endif()
if(TARGET EngineLabShiftTransientHarness)
    add_test(NAME EngineLab.AudioShiftTransientNA
        COMMAND EngineLabShiftTransientHarness
            --filter "K20"
            --audio-output "${CMAKE_BINARY_DIR}/audio-shift-transient-na-test")
    add_test(NAME EngineLab.AudioShiftTransientBoosted
        COMMAND EngineLabShiftTransientHarness
            --filter "2JZ"
            --audio-output "${CMAKE_BINARY_DIR}/audio-shift-transient-boosted-test")
    set_tests_properties(
        EngineLab.AudioShiftTransientNA
        EngineLab.AudioShiftTransientBoosted
        PROPERTIES TIMEOUT 180)
endif()
if(TARGET EngineLabLoadedAccelerationHarness)
    add_test(NAME EngineLab.LoadedAccelerationCP2
        COMMAND EngineLabLoadedAccelerationHarness
            --filter "Yamaha CP2"
            --gear 2)
    add_test(NAME EngineLab.LoadedAccelerationAudi
        COMMAND EngineLabLoadedAccelerationHarness
            --filter "Audi I5"
            --gear 3)
    # Declared regression, accepted by the owner (docs/journal.md 2026-09-23).
    # Once-per-cycle port metering removed the ratchet that over-fuelled every
    # idle; the same ratchet had been refilling the runner after a fuel cut.
    # The resume runs rich for ~0.2 s (the resume trim starts at the fourth
    # root of the learned high-load cell, ~0.92 against ~0.73 settled): peak
    # rich error 16-30 %, held at 0.35. The lean side is the first post-cut
    # cycle, starved while the dry runner refills (EJ25: 219 mg metered, 120 mg
    # in the chambers over its first four charges): 5-35 %, held at 0.40 since
    # the EJ25's exhausts merged into one turbo (2026-10-06, 31.6 -> 35.1 %).
    # Both still reject the old AFR 20-30 lean excursion (+55 % and more).
    # Since their link pipes (2026-10-07) the CP3 and the CP4 misfire once on
    # the resume, each on one cylinder's first charge (CP3 rich, AFR 9.05 with
    # a 4.8 mg film; CP4 lean, 17.4): the resume is still open, see CLAUDE.md.
    add_test(NAME EngineLab.LoadedAccelerationCatalogDfcoResume
        COMMAND EngineLabLoadedAccelerationHarness
            --dfco-tip-in --resume-afr-envelope 0.35 --resume-lean-afr-envelope 0.40
            --known-resume-misfire EJ25 --known-resume-misfire CP3
            --known-resume-misfire CP4)
    # Standing start from idle, 1st gear, WOT, clutch over 0.9 s, 4 s after
    # the start (inside the ECU post-start window) and 25 s after it. d70e8b8
    # stalled six road engines at 4 s (x2.12 start reserve stacked on X-tau)
    # and no other test launched this quickly. The Merlin and the radial sit
    # on `vehicle: test_stand` and also stalled before d70e8b8: a road launch
    # is not a meaningful test for them. Any stall fails. The scripted driver
    # holds the clutch down while the lever moves, then feeds it in: with it,
    # the stalls once declared here (LS3 at 4 s, EJ25 and Aircooled at 25 s)
    # launch, and the four most fragile (EJ25, Aircooled, I5, Big Twin) keep
    # at least 595 rpm over eight launch times (journal 2026-10-15).
    add_test(NAME EngineLab.StandingStartCatalogue
        COMMAND EngineLabLoadedAccelerationHarness
            --standing-start --gear 1 --launch-at 4
            --skip Merlin --skip Radial)
    add_test(NAME EngineLab.StandingStartSettledIdle
        COMMAND EngineLabLoadedAccelerationHarness
            --standing-start --gear 1 --launch-at 25
            --skip Merlin --skip Radial)
    set_tests_properties(
        EngineLab.LoadedAccelerationCP2
        EngineLab.LoadedAccelerationAudi
        PROPERTIES TIMEOUT 120)
    set_tests_properties(
        EngineLab.LoadedAccelerationCatalogDfcoResume
        EngineLab.StandingStartCatalogue
        EngineLab.StandingStartSettledIdle
        PROPERTIES TIMEOUT 240)
endif()
if(TARGET EngineLabUserDynoHarness)
    # A free-running engine against a 90 s wall-clock deadline: run alone, so a
    # parallel ctest on a shared runner cannot take its processors.
    add_test(NAME EngineLab.UserDynoHighRpmStart
        COMMAND EngineLabUserDynoHarness
            --filter "Yamaha CP2")
    add_test(NAME EngineLab.UserDynoRampCP2Complete
        COMMAND EngineLabUserDynoHarness
            --filter "11_yamaha_cp2_mt07_like" --complete)
    add_test(NAME EngineLab.UserDynoRampLS3Complete
        COMMAND EngineLabUserDynoHarness
            --filter "03_gm_ls3_like" --complete)
    set_tests_properties(EngineLab.UserDynoHighRpmStart
        EngineLab.UserDynoRampCP2Complete
        EngineLab.UserDynoRampLS3Complete
        PROPERTIES TIMEOUT 120 RUN_SERIAL TRUE)
endif()
if(TARGET EngineLabDieselControlHarness)
    add_test(NAME EngineLab.DieselControl
        COMMAND EngineLabDieselControlHarness)
    set_tests_properties(EngineLab.DieselControl PROPERTIES TIMEOUT 180)
endif()
if(MSVC)
    target_link_options(EngineLabCoreTests PRIVATE /STACK:8388608)
endif()
if(MSVC AND ENGINELAB_ENABLE_SANITIZERS)
    get_filename_component(ENGINELAB_MSVC_RUNTIME_DIR "${CMAKE_CXX_COMPILER}" DIRECTORY)
    set_tests_properties(EngineLab.Core PROPERTIES
        ENVIRONMENT_MODIFICATION "PATH=path_list_prepend:${ENGINELAB_MSVC_RUNTIME_DIR}")
endif()

add_executable(EngineLabEngineModel3DTests EngineModel3DTests.cpp)
target_link_libraries(EngineLabEngineModel3DTests PRIVATE EngineLab::Render EngineLab::Catalog EngineLab::Exhaust
    EngineLab::Ecu EngineLab::Events EngineLab::Physics EngineLab::Simulation)
target_compile_definitions(EngineLabEngineModel3DTests PRIVATE ENGINELAB_CATALOG_ROOT="${CMAKE_SOURCE_DIR}")
enginelab_set_warnings(EngineLabEngineModel3DTests)
add_test(NAME EngineLab.EngineModel3D COMMAND EngineLabEngineModel3DTests)

# UTF-8 text decoded as Windows-1252 and saved again ("â€¦" for an ellipsis)
# has reached the menus twice; no source file may hold it.
add_test(NAME EngineLab.SourceEncoding
    COMMAND ${CMAKE_COMMAND} -DROOT=${CMAKE_SOURCE_DIR} -P ${CMAKE_CURRENT_SOURCE_DIR}/SourceEncoding.cmake)


add_executable(EngineLabValveProfileTransitionTests
    ValveProfileTransitionTests.cpp ValveProfileActuatorContracts.cpp)
target_link_libraries(EngineLabValveProfileTransitionTests PRIVATE
    EngineLab::Foundation EngineLab::Calibration EngineLab::Events EngineLab::Physics EngineLab::Ecu
    EngineLab::Exhaust EngineLab::Simulation EngineLab::Catalog EngineLab::Runtime)
target_compile_definitions(EngineLabValveProfileTransitionTests PRIVATE
    ENGINELAB_CATALOG_ROOT="${CMAKE_SOURCE_DIR}")
enginelab_set_warnings(EngineLabValveProfileTransitionTests)
add_test(NAME EngineLab.ValveProfileTransition COMMAND EngineLabValveProfileTransitionTests)
set_tests_properties(EngineLab.ValveProfileTransition PROPERTIES TIMEOUT 120)

add_executable(EngineLabUnitsTests UnitsTests.cpp)
target_link_libraries(EngineLabUnitsTests PRIVATE EngineLab::Foundation)
enginelab_set_warnings(EngineLabUnitsTests)
add_test(NAME EngineLab.Units COMMAND EngineLabUnitsTests)

add_executable(EngineLabCruiseControlTests CruiseControlTests.cpp)
target_link_libraries(EngineLabCruiseControlTests PRIVATE EngineLab::Runtime)
enginelab_set_warnings(EngineLabCruiseControlTests)
add_test(NAME EngineLab.CruiseControl COMMAND EngineLabCruiseControlTests)

add_executable(EngineLabPassByRunTests PassByRunTests.cpp)
target_link_libraries(EngineLabPassByRunTests PRIVATE
    EngineLab::Audio EngineLab::Runtime EngineLab::Catalog EngineLab::Calibration EngineLab::Simulation EngineLab::Ecu
    EngineLab::Events EngineLab::Physics EngineLab::Exhaust)
target_compile_definitions(EngineLabPassByRunTests PRIVATE
    ENGINELAB_CATALOG_ROOT="${CMAKE_SOURCE_DIR}")
enginelab_set_warnings(EngineLabPassByRunTests)
add_test(NAME EngineLab.PassByRun COMMAND EngineLabPassByRunTests)
set_tests_properties(EngineLab.PassByRun PROPERTIES TIMEOUT 900)
if(MSVC)
    target_link_options(EngineLabPassByRunTests PRIVATE /STACK:8388608)
endif()
# The real engine and driveline: the toy car of CruiseControlTests has no
# combustion-to-combustion torque, and the hunting the owner reported
# (2026-11-05: throttle 0-20 % every 2.5 s, a K20A at 100 km/h) only showed
# on it.
if(TARGET EngineLabDriveScenarioHarness)
    add_test(NAME EngineLab.CruiseControlHold
        COMMAND EngineLabDriveScenarioHarness --builtin cruise --engine K20A
            --max-cruise-throttle-swing 0.02)
endif()

add_executable(EngineLabShiftScheduleTests ShiftScheduleTests.cpp)
target_link_libraries(EngineLabShiftScheduleTests PRIVATE
    EngineLab::Foundation EngineLab::Events EngineLab::Physics EngineLab::Ecu
    EngineLab::Exhaust EngineLab::Simulation EngineLab::Catalog EngineLab::Runtime)
target_compile_definitions(EngineLabShiftScheduleTests PRIVATE
    ENGINELAB_CATALOG_ROOT="${CMAKE_SOURCE_DIR}")
enginelab_set_warnings(EngineLabShiftScheduleTests)
add_test(NAME EngineLab.ShiftSchedule COMMAND EngineLabShiftScheduleTests)
set_tests_properties(EngineLab.ShiftSchedule PROPERTIES TIMEOUT 300)

add_executable(EngineLabCvtTests CvtTests.cpp)
target_link_libraries(EngineLabCvtTests PRIVATE EngineLab::Runtime)
enginelab_set_warnings(EngineLabCvtTests)
add_test(NAME EngineLab.Cvt COMMAND EngineLabCvtTests)

add_executable(EngineLabKnockControlTests KnockControlTests.cpp)
target_link_libraries(EngineLabKnockControlTests PRIVATE
    EngineLab::Foundation EngineLab::Calibration EngineLab::Events EngineLab::Physics EngineLab::Ecu
    EngineLab::Exhaust EngineLab::Simulation EngineLab::Catalog EngineLab::Runtime)
target_compile_definitions(EngineLabKnockControlTests PRIVATE
    ENGINELAB_CATALOG_ROOT="${CMAKE_SOURCE_DIR}")
if(MSVC)
    target_link_options(EngineLabKnockControlTests PRIVATE /STACK:8388608)
endif()
enginelab_set_warnings(EngineLabKnockControlTests)
add_test(NAME EngineLab.KnockControl COMMAND EngineLabKnockControlTests)

add_executable(EngineLabPeakPressureTests PeakPressureTests.cpp)
target_link_libraries(EngineLabPeakPressureTests PRIVATE
    EngineLab::Foundation EngineLab::Calibration EngineLab::Events EngineLab::Physics EngineLab::Ecu
    EngineLab::Exhaust EngineLab::Simulation EngineLab::Catalog EngineLab::Diagnostics)
target_compile_definitions(EngineLabPeakPressureTests PRIVATE
    ENGINELAB_CATALOG_ROOT="${CMAKE_SOURCE_DIR}")
if(MSVC)
    target_link_options(EngineLabPeakPressureTests PRIVATE /STACK:8388608)
endif()
enginelab_set_warnings(EngineLabPeakPressureTests)
add_test(NAME EngineLab.PeakPressure COMMAND EngineLabPeakPressureTests)

add_executable(EngineLabTurbochargerTests TurbochargerTests.cpp)
target_link_libraries(EngineLabTurbochargerTests PRIVATE
    EngineLab::Foundation EngineLab::Calibration EngineLab::Events EngineLab::Physics EngineLab::Ecu
    EngineLab::Exhaust EngineLab::Simulation EngineLab::Catalog)
target_compile_definitions(EngineLabTurbochargerTests PRIVATE
    ENGINELAB_CATALOG_ROOT="${CMAKE_SOURCE_DIR}")
if(MSVC)
    target_link_options(EngineLabTurbochargerTests PRIVATE /STACK:8388608)
endif()
enginelab_set_warnings(EngineLabTurbochargerTests)
add_test(NAME EngineLab.Turbocharger COMMAND EngineLabTurbochargerTests)

add_executable(EngineLabLaunchControlTests LaunchControlTests.cpp)
target_link_libraries(EngineLabLaunchControlTests PRIVATE
    EngineLab::Foundation EngineLab::Calibration EngineLab::Ecu)
enginelab_set_warnings(EngineLabLaunchControlTests)
add_test(NAME EngineLab.LaunchControl COMMAND EngineLabLaunchControlTests)

add_executable(EngineLabOverboostCutTests OverboostCutTests.cpp)
target_link_libraries(EngineLabOverboostCutTests PRIVATE
    EngineLab::Foundation EngineLab::Calibration EngineLab::Ecu)
enginelab_set_warnings(EngineLabOverboostCutTests)
add_test(NAME EngineLab.OverboostCut COMMAND EngineLabOverboostCutTests)

add_executable(EngineLabDataLoggerTests DataLoggerTests.cpp)
target_link_libraries(EngineLabDataLoggerTests PRIVATE EngineLab::Foundation EngineLab::Runtime)
enginelab_set_warnings(EngineLabDataLoggerTests)
add_test(NAME EngineLab.DataLogger COMMAND EngineLabDataLoggerTests)

add_executable(EngineLabCalibrationEditingTests CalibrationEditingTests.cpp)
target_link_libraries(EngineLabCalibrationEditingTests PRIVATE EngineLab::Calibration)
enginelab_set_warnings(EngineLabCalibrationEditingTests)
add_test(NAME EngineLab.CalibrationEditing COMMAND EngineLabCalibrationEditingTests)

add_executable(EngineLabTwoStrokeTests TwoStrokeTests.cpp)
target_link_libraries(EngineLabTwoStrokeTests PRIVATE
    EngineLab::Foundation EngineLab::Calibration EngineLab::Events EngineLab::Physics EngineLab::Ecu
    EngineLab::Exhaust EngineLab::Simulation EngineLab::Catalog EngineLab::Serialization)
target_compile_definitions(EngineLabTwoStrokeTests PRIVATE ENGINELAB_CATALOG_ROOT="${CMAKE_SOURCE_DIR}")
if(MSVC)
    target_link_options(EngineLabTwoStrokeTests PRIVATE /STACK:8388608)
endif()
enginelab_set_warnings(EngineLabTwoStrokeTests)
add_test(NAME EngineLab.TwoStroke COMMAND EngineLabTwoStrokeTests)

add_executable(EngineLabCatalogRoundTripTests CatalogRoundTripTests.cpp)
target_link_libraries(EngineLabCatalogRoundTripTests PRIVATE
    EngineLab::Foundation EngineLab::Serialization EngineLab::Catalog)
target_compile_definitions(EngineLabCatalogRoundTripTests PRIVATE ENGINELAB_CATALOG_ROOT="${CMAKE_SOURCE_DIR}")
enginelab_set_warnings(EngineLabCatalogRoundTripTests)
add_test(NAME EngineLab.CatalogRoundTrip COMMAND EngineLabCatalogRoundTripTests)

add_executable(EngineLabEngineDesignTests EngineDesignTests.cpp)
target_link_libraries(EngineLabEngineDesignTests PRIVATE
    EngineLab::Foundation EngineLab::Calibration EngineLab::Events EngineLab::Physics EngineLab::Ecu
    EngineLab::Exhaust EngineLab::GasDynamics EngineLab::Simulation EngineLab::Catalog EngineLab::Runtime)
target_compile_definitions(EngineLabEngineDesignTests PRIVATE ENGINELAB_CATALOG_ROOT="${CMAKE_SOURCE_DIR}")
if(MSVC)
    target_link_options(EngineLabEngineDesignTests PRIVATE /STACK:8388608)
endif()
enginelab_set_warnings(EngineLabEngineDesignTests)
add_test(NAME EngineLab.EngineDesign COMMAND EngineLabEngineDesignTests)

add_executable(EngineLabRotaryTests RotaryTests.cpp)
target_link_libraries(EngineLabRotaryTests PRIVATE
    EngineLab::Foundation EngineLab::Calibration EngineLab::Events EngineLab::Physics EngineLab::Ecu
    EngineLab::Exhaust EngineLab::GasDynamics EngineLab::Simulation EngineLab::Catalog)
target_compile_definitions(EngineLabRotaryTests PRIVATE ENGINELAB_CATALOG_ROOT="${CMAKE_SOURCE_DIR}")
if(MSVC)
    target_link_options(EngineLabRotaryTests PRIVATE /STACK:8388608)
endif()
enginelab_set_warnings(EngineLabRotaryTests)
add_test(NAME EngineLab.Rotary COMMAND EngineLabRotaryTests)

add_executable(EngineLabVtecTests VtecTests.cpp)
target_link_libraries(EngineLabVtecTests PRIVATE
    EngineLab::Foundation EngineLab::Calibration EngineLab::Events EngineLab::Physics EngineLab::Ecu
    EngineLab::Exhaust EngineLab::GasDynamics EngineLab::Simulation EngineLab::Catalog EngineLab::Serialization)
target_compile_definitions(EngineLabVtecTests PRIVATE ENGINELAB_CATALOG_ROOT="${CMAKE_SOURCE_DIR}")
if(MSVC)
    target_link_options(EngineLabVtecTests PRIVATE /STACK:8388608)
endif()
enginelab_set_warnings(EngineLabVtecTests)
add_test(NAME EngineLab.Vtec COMMAND EngineLabVtecTests)
set_tests_properties(EngineLab.Vtec PROPERTIES TIMEOUT 400)

# Every TIMEOUT above is tuned on Windows, the reference platform, where a test
# that stops printing after `Start N:` is stuck rather than slow -- a diagnosis
# the project leans on, and one a generous limit would blunt. Off Windows they
# are headroom instead, for a reason that is not a measured speed ratio: on
# 2026-10-21 a full Linux run timed four of these out, a later run of the same
# binaries passed all 89 in 17 minutes against Windows's ~15, and in between
# AudioRender alone measured 369 s and then 92 s against its 180 s limit. Wall
# times here are simply not reproducible between runs (journal 2026-10-21), so
# the limits carry slack rather than a factor, and a CI runner with half these
# cores gets the same slack. A genuine hang still never terminates, so it is
# still caught. All 31 limits are scaled in one place rather than written twice.
if(NOT WIN32)
    get_property(enginelab_timed_tests DIRECTORY PROPERTY TESTS)
    foreach(enginelab_test IN LISTS enginelab_timed_tests)
        get_test_property(${enginelab_test} TIMEOUT enginelab_timeout)
        if(enginelab_timeout)
            # The property comes back as a float ("600.0"); math() wants an
            # integer, so drop any fractional part before multiplying. The
            # dot is a character class, not an escape: CMake unescapes "\."
            # inside a quoted argument, which would leave the regex matching
            # any character and empty the value.
            string(REGEX REPLACE "[.].*$" "" enginelab_timeout "${enginelab_timeout}")
            math(EXPR enginelab_scaled "${enginelab_timeout} * 4")
            set_tests_properties(${enginelab_test} PROPERTIES TIMEOUT ${enginelab_scaled})
        endif()
    endforeach()
endif()
