#include <enginelab/runtime/DynoQualityGate.hpp>
#include <enginelab/simulation/DynoAbsorberController.hpp>

#include <cmath>
#include <cstdlib>
#include <iostream>
#include <limits>
#include <string_view>

namespace {

void require(bool condition, std::string_view message) {
    if (!condition) {
        std::cerr << "FAIL: " << message << '\n';
        std::exit(EXIT_FAILURE);
    }
}

enginelab::DynoQualityGateInput validInput() {
    enginelab::DynoQualityGateInput input;
    input.mode = enginelab::DynoAcquisitionMode::steppedCalibration;
    input.targetRpm = 3'000.0;
    input.measuredRpm = 3'000.0;
    input.rampRateRpmPerSecond = 500.0;
    input.measuredCycleTorqueNm = 100.0;
    input.prepared = true;
    input.protocolReady = true;
    input.cycleContinuous = true;
    return input;
}

enginelab::EngineState validState() {
    enginelab::EngineState state;
    state.rpm = 3'000.0;
    return state;
}

enginelab::DynoAbsorberOutput validAbsorber() {
    enginelab::DynoAbsorberOutput output;
    output.brakeTorqueNm = 100.0;
    output.filteredRpm = 3'000.0;
    output.filteredAccelerationRpmPerSecond = 0.0;
    output.contacted = true;
    output.contactFraction = 1.0;
    output.unclampedBrakeTorqueNm = 100.0;
    return output;
}

void requireOnly(enginelab::DynoQualityReason actual,
                 enginelab::DynoQualityReason expected,
                 std::string_view message) {
    require(actual == expected, message);
}

} // namespace

int main() {
    using enginelab::DynoAcquisitionMode;
    using enginelab::DynoQualityGate;
    using enginelab::DynoQualityReason;
    using enginelab::hasDynoQualityReason;

    const DynoQualityGate gate;
    auto input = validInput();
    auto state = validState();
    auto absorber = validAbsorber();
    require(gate.evaluate(input, state, absorber).accepted(),
            "a prepared, tracked, continuous sample must pass");

    {
        auto primingInput = validInput();
        primingInput.mode = DynoAcquisitionMode::continuousRamp;
        primingInput.rampRateRpmPerSecond = 500.0;
        // EngineRuntime supplies this phase flag while its target is held at
        // entry. The observation deliberately passes the later ramp limits.
        primingInput.rampPrimed = false;
        primingInput.measuredRpm = 3'100.0;
        auto primingAbsorber = validAbsorber();
        primingAbsorber.filteredRpm = primingInput.measuredRpm;
        primingAbsorber.filteredAccelerationRpmPerSecond = 300.0;
        auto primingGate = gate.evaluate(primingInput, state, primingAbsorber);
        std::cout << "ramp priming accepted=" << primingGate.accepted()
            << " speed_limit=" << primingGate.maximumAllowedSpeedErrorRpm
            << " acceleration_limit=" << primingGate.maximumAllowedAccelerationRpmPerSecond
            << " reasons=" << static_cast<std::uint32_t>(primingGate.reasons) << '\n';
        require(primingGate.reasons == (DynoQualityReason::speedTrackingError
                | DynoQualityReason::accelerationOutOfBounds)
            && primingGate.maximumAllowedSpeedErrorRpm == 60.0
            && primingGate.maximumAllowedAccelerationRpmPerSecond == 120.0
            && primingGate.taintsCycle(),
            "a configured ramp's entry hold must use the unchanged steady gate throughout priming");

        primingInput.rampPrimed = true;
        primingGate = gate.evaluate(primingInput, state, primingAbsorber);
        require(primingGate.accepted()
            && primingGate.maximumAllowedSpeedErrorRpm == 150.0
            && primingGate.maximumAllowedAccelerationRpmPerSecond == 1'500.0,
            "a primed forward pull must retain the unchanged ramp limits");

        primingInput.rampPrimed = false;
        primingInput.measuredRpm = 3'000.0;
        primingAbsorber.filteredRpm = primingInput.measuredRpm;
        primingAbsorber.filteredAccelerationRpmPerSecond = 0.0;
        require(gate.evaluate(primingInput, state, primingAbsorber).accepted(),
            "steady clean priming observations must pass instead of deadlocking the pull");
    }

    {
        constexpr DynoAcquisitionMode modes[] = {
            DynoAcquisitionMode::steppedCalibration,
            DynoAcquisitionMode::continuousRamp,
            DynoAcquisitionMode::hold
        };
        for (const auto mode : modes) {
            auto numericalInput = validInput();
            numericalInput.mode = mode;
            auto numericalState = validState();
            numericalState.solverResolutionLimited = true;
            requireOnly(gate.evaluate(numericalInput, numericalState, absorber).reasons,
                DynoQualityReason::simulationNumericalFault,
                "an unresolved simulation step must explicitly reject every dyno mode");

            numericalState = validState();
            numericalState.intakeCylinderTransferFailures = 1;
            requireOnly(gate.evaluate(numericalInput, numericalState, absorber).reasons,
                DynoQualityReason::simulationNumericalFault,
                "a rejected cylinder inventory transfer must not become a physical dyno point");

            numericalState = validState();
            numericalState.intakePlenumTransferFailures = 1;
            requireOnly(gate.evaluate(numericalInput, numericalState, absorber).reasons,
                DynoQualityReason::simulationNumericalFault,
                "a rejected plenum inventory transfer must not become a physical dyno point");

            numericalState = validState();
            numericalState.intakeNetworkRejectedSubsteps = 1;
            require(gate.evaluate(numericalInput, numericalState, absorber).accepted(),
                "a recovered internal trial rejection alone must not invalidate a completed simulation step");
        }
    }

    input.prepared = false;
    requireOnly(gate.evaluate(input, state, absorber).reasons,
                DynoQualityReason::notPrepared,
                "preparation must have one explicit reason");
    input = validInput();
    input.protocolReady = false;
    requireOnly(gate.evaluate(input, state, absorber).reasons,
                DynoQualityReason::protocolNotReady,
                "protocol readiness must have one explicit reason");
    input = validInput();
    input.recoveryActive = true;
    requireOnly(gate.evaluate(input, state, absorber).reasons,
                DynoQualityReason::recoveryActive,
                "recovery must have one explicit reason");
    input = validInput();
    input.cycleContinuous = false;
    requireOnly(gate.evaluate(input, state, absorber).reasons,
                DynoQualityReason::discontinuousCycle,
                "cycle continuity must have one explicit reason");

    input = validInput();
    input.measuredCycleTorqueNm = 1.4;
    requireOnly(gate.evaluate(input, state, absorber).reasons,
                DynoQualityReason::insufficientEngineTorque,
                "the minimum torque threshold is strict");
    input.measuredCycleTorqueNm = std::nextafter(1.4,
        std::numeric_limits<double>::infinity());
    require(gate.evaluate(input, state, absorber).accepted(),
            "torque just above the strict threshold must pass");

    input = validInput();
    absorber = validAbsorber();
    absorber.contactFraction = std::nextafter(0.95, 0.0);
    require(gate.evaluate(input, state, absorber).accepted(),
            "sub-picometric contact rounding must not chatter the gate");
    absorber.contactFraction = 0.949;
    requireOnly(gate.evaluate(input, state, absorber).reasons,
                DynoQualityReason::noBrakeContact,
                "materially partial contact must be rejected");

    input = validInput();
    input.mode = DynoAcquisitionMode::continuousRamp;
    absorber = validAbsorber();
    absorber.contactFraction = 0.0;
    absorber.contacted = false;
    requireOnly(gate.evaluate(input, state, absorber).reasons,
                DynoQualityReason::noBrakeContact,
                "a brake-dyno ramp without absorber contact must be rejected");

    {
        auto config = enginelab::makeDefaultInlineFour();
        enginelab::DynoAbsorberController controller(config);
        enginelab::EngineState rampState;
        rampState.rpm = 2'000.0;
        rampState.torqueNm = 100.0;
        rampState.cycleAveragedTorqueNm = 100.0;
        controller.reset(rampState.rpm, 100.0);
        auto minimumSettledContact = 1.0;
        auto settledRampBrakeTorqueNm = 0.0;
        constexpr double dt = 0.001;
        for (int step = 0; step < 3'000; ++step) {
            const auto targetRpm = 2'000.0 + 500.0 * step * dt;
            rampState.rpm = targetRpm;
            const auto output = controller.advance(
                dt, targetRpm, rampState);
            if (step > 500) {
                minimumSettledContact = std::min(
                    minimumSettledContact, output.contactFraction);
                settledRampBrakeTorqueNm = output.brakeTorqueNm;
            }
        }
        require(minimumSettledContact > 0.999,
            "an ideal 500 rpm/s follower must retain full absorber contact");

        enginelab::DynoAbsorberController steadyController(config);
        rampState.rpm = 3'500.0;
        steadyController.reset(rampState.rpm, 100.0);
        auto settledSteadyBrakeTorqueNm = 0.0;
        for (int step = 0; step < 2'000; ++step) {
            const auto output = steadyController.advance(
                dt, rampState.rpm, rampState);
            settledSteadyBrakeTorqueNm = output.brakeTorqueNm;
        }
        require(settledRampBrakeTorqueNm < settledSteadyBrakeTorqueNm,
            "a positive target ramp must release inertial torque instead of braking an ideal follower");
    }

    input = validInput();
    absorber = validAbsorber();
    input.measuredRpm = 3'060.0;
    absorber.filteredAccelerationRpmPerSecond = 120.0;
    require(gate.evaluate(input, state, absorber).accepted(),
            "steady limits are inclusive");
    input.measuredRpm = 3'060.01;
    absorber.filteredAccelerationRpmPerSecond = 120.01;
    auto result = gate.evaluate(input, state, absorber);
    require(hasDynoQualityReason(result.reasons,
                DynoQualityReason::speedTrackingError)
            && hasDynoQualityReason(result.reasons,
                DynoQualityReason::accelerationOutOfBounds),
            "speed and acceleration reasons must accumulate");

    input = validInput();
    input.mode = DynoAcquisitionMode::continuousRamp;
    input.rampRateRpmPerSecond = 500.0;
    input.measuredRpm = 3'150.0;
    absorber = validAbsorber();
    absorber.filteredAccelerationRpmPerSecond = 1'500.0;
    result = gate.evaluate(input, state, absorber);
    require(result.accepted()
            && result.maximumAllowedSpeedErrorRpm == 150.0
            && result.maximumAllowedAccelerationRpmPerSecond == 1'500.0,
            "ramp limits must scale with the commanded rate");

    absorber = validAbsorber();
    absorber.saturatedLow = true;
    require(gate.evaluate(input, state, absorber).accepted(),
            "low clamp alone is not an absorber-capacity fault");
    absorber.saturatedHigh = true;
    requireOnly(gate.evaluate(input, state, absorber).reasons,
                DynoQualityReason::absorberCapacityLimited,
                "high clamp must expose absorber capacity exhaustion");

    absorber = validAbsorber();
    state = validState();
    state.ecuHardRevLimiterActive = true;
    requireOnly(gate.evaluate(input, state, absorber).reasons,
                DynoQualityReason::revLimiterActive,
                "any active rev limiter must reject acquisition");

    state = validState();
    input = validInput();
    absorber = validAbsorber();
    input.targetRpm = std::numeric_limits<double>::quiet_NaN();
    input.prepared = false;
    input.cycleContinuous = false;
    result = gate.evaluate(input, state, absorber);
    require(hasDynoQualityReason(result.reasons,
                DynoQualityReason::nonFinite)
            && hasDynoQualityReason(result.reasons,
                DynoQualityReason::notPrepared)
            && hasDynoQualityReason(result.reasons,
                DynoQualityReason::discontinuousCycle),
            "non-finite input must not hide independent protocol reasons");

    std::cout << "PASS: deterministic dyno quality attribution\n";
    return 0;
}
