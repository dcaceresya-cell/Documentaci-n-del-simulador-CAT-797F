// Turbochargers: the compressor map, parallel compressors feeding one charge,
// and several turbochargers sharing an engine's exhaust paths.

#include <enginelab/calibration/EcuCalibration.hpp>
#include <enginelab/catalog/EngineCatalog.hpp>
#include <enginelab/calibration/EcuCalibrationKeys.hpp>
#include <enginelab/ecu/SimpleEcuModel.hpp>
#include <enginelab/events/FourStrokeEventGenerator.hpp>
#include <enginelab/exhaust/ExhaustGraph.hpp>
#include <enginelab/foundation/ForcedInductionFlow.hpp>
#include <enginelab/foundation/TurboSizing.hpp>
#include <enginelab/physics/SimplifiedGasolinePhysics.hpp>
#include <enginelab/simulation/EngineSimulator.hpp>

#include <algorithm>
#include <array>
#include <cmath>
#include <cstdlib>
#include <iostream>
#include <memory>
#include <numbers>
#include <string>
#include <string_view>
#include <utility>
#include <variant>
#include <vector>

namespace {
using namespace enginelab;
constexpr double frameSeconds = 1.0 / 240.0;

void require(bool condition, std::string_view message) {
    if (!condition) {
        std::cerr << "FAIL: " << message << '\n';
        std::exit(EXIT_FAILURE);
    }
}

[[nodiscard]] double radiansPerSecond(double rpm) { return rpm * 2.0 * std::numbers::pi / 60.0; }

/** The map holds its design point and falls along a speed line. */
void mapFollowsItsDesignPoint() {
    ForcedInductionConfig turbo;
    turbo.pressureRatio = 2.0;
    turbo.designShaftSpeedRpm = 120'000.0;
    constexpr double designFlow = 0.2;
    const auto omega = radiansPerSecond(turbo.designShaftSpeedRpm);
    const auto at = [&](double speed, double flow) {
        return compressorOperatingPoint(turbo, designFlow, speed, flow,
            compressorReferenceTemperatureK, compressorReferencePressureKpa);
    };
    const auto design = at(omega, designFlow);
    require(std::abs(design.pressureRatio - 2.0) < 1.0e-9 && std::abs(design.flowCoefficientRatio - 1.0) < 1.0e-12,
        "at its design speed and flow the map gives the design pressure ratio");
    const auto low = at(omega, 0.1);
    const auto high = at(omega, 0.27);
    require(low.pressureRatio > design.pressureRatio && design.pressureRatio > high.pressureRatio,
        "along a speed line the head falls as the flow rises");
    const auto stalled = at(omega, 0.0);
    require(stalled.surge && stalled.pressureRatio > 2.0 && stalled.pressureRatio < 2.4,
        "at no flow the wheel surges, its head a little above the design one");
    const auto choked = at(omega, 0.31);
    require(choked.choke && choked.pressureRatio == 1.0, "past choke the wheel adds no head");
    const auto half = at(0.5 * omega, 0.5 * designFlow);
    const auto quarterHead = 0.25 * (std::pow(2.0, turboIsentropicExponent) - 1.0);
    require(std::abs(std::pow(half.pressureRatio, turboIsentropicExponent) - 1.0 - quarterHead) < 1.0e-9,
        "at half speed and half flow (the same flow coefficient) the head is a quarter");
}

/** Two compressors on one charge: identical ones split the flow and hold the
 *  ratio of one twice the size; a slower one passes less. */
void parallelCompressorsShareTheCharge() {
    ForcedInductionConfig turbo;
    turbo.pressureRatio = 2.0;
    turbo.designShaftSpeedRpm = 120'000.0;
    const auto omega = radiansPerSecond(110'000.0);
    std::array<double, maximumTurbochargers> speeds { omega, omega, 0.0, 0.0 };
    std::array<double, maximumTurbochargers> flows {};
    const auto ratio = parallelCompressorPressureRatio(turbo, 0.2, speeds, 2, 0.35,
        compressorReferenceTemperatureK, compressorReferencePressureKpa, flows);
    const auto single = compressorOperatingPoint(turbo, 0.4, omega, 0.35,
        compressorReferenceTemperatureK, compressorReferencePressureKpa).pressureRatio;
    require(std::abs(ratio - single) < 1.0e-6 && std::abs(flows[0] - 0.175) < 1.0e-9
            && std::abs(flows[1] - 0.175) < 1.0e-9,
        "two identical compressors hold the ratio of one of twice the flow, half the flow each");
    speeds[1] = 0.7 * omega;
    const auto uneven = parallelCompressorPressureRatio(turbo, 0.2, speeds, 2, 0.35,
        compressorReferenceTemperatureK, compressorReferencePressureKpa, flows);
    require(flows[1] < flows[0] && std::abs(flows[0] + flows[1] - 0.35) < 1.0e-9 && uneven < ratio,
        "a slower compressor passes less of the flow, and the charge holds less");
}

struct Rig final {
    explicit Rig(EngineConfig engine)
        : config(std::move(engine)), exhaust(ExhaustGraph::makeForEngine(config)),
          simulator(std::make_unique<EngineSimulator>(config, ecu, physics, events, exhaust)) {}
    EngineConfig config;
    SimpleEcuModel ecu;
    SimplifiedGasolinePhysics physics;
    FourStrokeEventGenerator events;
    ExhaustGraph exhaust;
    std::unique_ptr<EngineSimulator> simulator;
};

struct HeldRun final {
    double boostRatio { 0.0 };
    double boostStdDev { 0.0 };
    double boostMax { 0.0 };
    double shaftRpmMax { 0.0 };
    double wheelDamage { 0.0 };
    bool overboostCut { false };
    double torqueNm { 0.0 };
    double lambdaMin { 1.0e9 };
    double lambdaMax { 0.0 };
    std::array<double, maximumTurbochargers> shaftRpm {};
    std::array<double, maximumTurbochargers> flowShare {};
};

/** The ECU's boost table set flat at `gaugeKpa`. */
void publishBoostTable(SimpleEcuModel& ecu, double gaugeKpa) {
    auto draft = calibration::makeDraft(*ecu.calibrationStore()->snapshot());
    const auto* found = draft.find(calibration::keys::boostTargetGauge);
    require(found != nullptr, "a turbocharged engine's tables carry a boost target");
    auto entry = *found;
    for (auto& value : std::get<calibration::CalibrationCurve1D>(entry).values) value = gaugeKpa;
    draft.set(std::move(entry));
    require(ecu.calibrationStore()->publish(draft).published, "a boost table must publish");
}

/** The ECU's overboost cut at `marginKpa` past the target (0: off). */
void publishOverboostMargin(SimpleEcuModel& ecu, double marginKpa) {
    auto draft = calibration::makeDraft(*ecu.calibrationStore()->snapshot());
    const auto* found = draft.find(calibration::keys::overboostCut);
    require(found != nullptr, "a turbocharged engine's tables carry an overboost cut");
    auto entry = *found;
    std::get<calibration::ScalarCalibration>(entry).value = marginKpa;
    draft.set(std::move(entry));
    require(ecu.calibrationStore()->publish(draft).published, "an overboost margin must publish");
}

/** Cranked, then full throttle against a dyno holding `heldRpm` (0.7 x
 *  redline by default); means over the last 3 s, peaks over the whole run. A
 *  non-negative `boostTableGaugeKpa` replaces the ECU's boost table, a
 *  non-negative `overboostMarginKpa` its overboost cut. */
[[nodiscard]] HeldRun heldFullLoad(const EngineConfig& config, double seconds, double boostTableGaugeKpa = -1.0,
                                   double heldRpm = 0.0, double overboostMarginKpa = -1.0) {
    if (heldRpm <= 0.0) heldRpm = 0.7 * config.redlineRpm;
    auto rig = std::make_unique<Rig>(config);
    if (boostTableGaugeKpa >= 0.0) publishBoostTable(rig->ecu, boostTableGaugeKpa);
    if (overboostMarginKpa >= 0.0) publishOverboostMargin(rig->ecu, overboostMarginKpa);
    const auto frames = static_cast<int>(seconds * 240.0);
    const auto firstMeasured = frames - 3 * 240;
    const auto weight = 1.0 / static_cast<double>(frames - firstMeasured);
    HeldRun run;
    auto rpm = 0.0;
    for (auto frame = 0; frame < frames; ++frame) {
        const auto t = frame * frameSeconds;
        EngineControls controls;
        controls.ignitionEnabled = true;
        controls.starterEngaged = t < 1.5;
        controls.throttle = t < 2.0 ? 0.0 : 1.0;
        if (t >= 2.0) controls.dynamometerTorqueNm = std::max(0.0, 2.0 * (rpm - heldRpm));
        const auto state = rig->simulator->step(frameSeconds, controls).state;
        rpm = state.rpm;
        run.boostMax = std::max(run.boostMax, state.boostPressureRatio);
        for (std::size_t index = 0; index < state.turbochargerCount; ++index) {
            run.shaftRpmMax = std::max(run.shaftRpmMax, state.turbochargers[index].shaftSpeedRpm);
            run.wheelDamage = std::max(run.wheelDamage, state.turbochargers[index].wheelDamage);
        }
        run.overboostCut = run.overboostCut || hasActiveLimit(state.activeLimits, ActiveLimit::overboostCut);
        if (frame < firstMeasured) continue;
        run.boostRatio += state.boostPressureRatio * weight;
        run.boostStdDev += state.boostPressureRatio * state.boostPressureRatio * weight;
        if (state.airFuelRatioValid) {
            run.lambdaMin = std::min(run.lambdaMin, state.lambda);
            run.lambdaMax = std::max(run.lambdaMax, state.lambda);
        }
        run.torqueNm += state.torqueNm * weight;
        auto totalFlow = 0.0;
        for (std::size_t index = 0; index < state.turbochargerCount; ++index)
            totalFlow += state.turbochargers[index].compressorMassFlowKgPerSecond;
        for (std::size_t index = 0; index < state.turbochargerCount; ++index) {
            run.shaftRpm[index] += state.turbochargers[index].shaftSpeedRpm * weight;
            run.flowShare[index] += (totalFlow > 0.0
                ? state.turbochargers[index].compressorMassFlowKgPerSecond / totalFlow : 0.0) * weight;
        }
    }
    run.boostStdDev = std::sqrt(std::max(0.0, run.boostStdDev - run.boostRatio * run.boostRatio));
    return run;
}

/** The engine with its cylinders split over scalar exhaust paths. */
[[nodiscard]] EngineConfig withPaths(EngineConfig config, const std::vector<std::vector<std::uint32_t>>& groups) {
    config.exhaustPaths.clear();
    std::uint32_t id = 1;
    for (const auto& group : groups) {
        ExhaustPathConfig path;
        path.id = id++;
        path.cylinderIds = group;
        path.geometry = config.exhaust;
        config.exhaustPaths.push_back(std::move(path));
    }
    normaliseEngineConfig(config);
    return config;
}

/** A turbocharger split in equal units, each the old one scaled to its
 *  share of the air at the same tip speed: areas as the share, wheels as its
 *  root (so they spin faster by as much), inertia as the fifth power of the
 *  size, journal-bearing loss at the design speed as the root. */
[[nodiscard]] EngineConfig asTwinUnits(EngineConfig config, std::uint32_t count) {
    auto& turbo = config.forcedInduction;
    const auto share = 1.0 / static_cast<double>(count);
    const auto size = std::sqrt(share);
    turbo.compressorDesignMassFlowKgPerSecond = compressorDesignMassFlowKgPerSecond(config) * share;
    turbo.turbineFlowAreaMm2 *= share;
    turbo.wastegateFlowAreaMm2 *= share;
    turbo.compressorInducerDiameterMm *= size;
    turbo.turbineExducerDiameterMm *= size;
    turbo.designShaftSpeedRpm /= size;
    turbo.shaftInertiaKgM2 *= share * share * size;
    turbo.bearingFrictionPowerWatts *= size;
    turbo.turbochargerCount = count;
    return config;
}

/** Seconds from the throttle opening (held at `heldRpm` by the dyno) until
 *  the boost first reaches `fraction` of its gauge value 6 s later. */
[[nodiscard]] double secondsToBoost(const EngineConfig& config, double heldRpm, double fraction) {
    auto rig = std::make_unique<Rig>(config);
    constexpr double openSeconds = 3.0;
    const auto frames = static_cast<int>((openSeconds + 6.0) * 240.0);
    std::vector<double> boost;
    auto rpm = 0.0;
    for (auto frame = 0; frame < frames; ++frame) {
        const auto t = frame * frameSeconds;
        EngineControls controls;
        controls.ignitionEnabled = true;
        controls.starterEngaged = t < 1.5;
        controls.throttle = t < openSeconds ? 0.12 : 1.0;
        if (t >= 1.5) controls.dynamometerTorqueNm = std::max(0.0, 4.0 * (rpm - heldRpm));
        const auto state = rig->simulator->step(frameSeconds, controls).state;
        rpm = state.rpm;
        if (t >= openSeconds) boost.push_back(state.boostPressureRatio);
    }
    require(!boost.empty() && boost.back() > 1.1, "the fixture makes boost (else this proves nothing)");
    const auto target = 1.0 + fraction * (boost.back() - 1.0);
    for (std::size_t index = 0; index < boost.size(); ++index)
        if (boost[index] >= target) return static_cast<double>(index) * frameSeconds;
    return 6.0;
}

/** Changing the count keeps the set's total size: the same units as a
 *  hand split, and back again. */
void countKeepsTheSize() {
    auto single = withPaths(withTurbocharger(makeDefaultInlineFour()), { { 1, 4 }, { 2, 3 } });
    const auto designFlow = compressorDesignMassFlowKgPerSecond(single);
    const auto split = withTurbochargerCount(single, 2);
    const auto byHand = asTwinUnits(single, 2);
    const auto& a = split.forcedInduction;
    const auto& b = byHand.forcedInduction;
    require(a.turbochargerCount == 2U && !validateEngineConfig(split), "two valid units");
    require(std::abs(a.compressorDesignMassFlowKgPerSecond - b.compressorDesignMassFlowKgPerSecond) < 1.0e-12
            && a.turbineFlowAreaMm2 == b.turbineFlowAreaMm2 && a.wastegateFlowAreaMm2 == b.wastegateFlowAreaMm2
            && a.shaftInertiaKgM2 == b.shaftInertiaKgM2 && a.bearingFrictionPowerWatts == b.bearingFrictionPowerWatts,
        "each unit is half the one");
    require(a.blowOffValveFlowAreaMm2 == single.forcedInduction.blowOffValveFlowAreaMm2,
        "the blow-off valve is on the common charge");
    auto named = split;
    named.exhaustPaths[1].turbocharger = 1;
    const auto back = withTurbochargerCount(named, 1);
    require(back.forcedInduction.turbochargerCount == 1U && back.exhaustPaths[1].turbocharger == -1
            && !validateEngineConfig(back), "a path naming a unit that went goes back to the default");
    require(std::abs(back.forcedInduction.compressorDesignMassFlowKgPerSecond - designFlow) < 1.0e-12 * designFlow
            && std::abs(back.forcedInduction.turbineFlowAreaMm2 - single.forcedInduction.turbineFlowAreaMm2) < 1.0e-9,
        "and one unit is the original again");
    const auto natural = makeDefaultInlineFour();
    require(withTurbochargerCount(natural, 3).forcedInduction.turbochargerCount
            == natural.forcedInduction.turbochargerCount, "an engine without a turbo is left alone");
}

/** Two identical turbochargers, one per pair of cylinders, run as one of
 *  twice the size on both pairs. */
void twoIdenticalAreOneDouble() {
    auto single = withPaths(withTurbocharger(makeDefaultInlineFour()), { { 1, 4 }, { 2, 3 } });
    single.forcedInduction.compressorDesignMassFlowKgPerSecond = compressorDesignMassFlowKgPerSecond(single);
    const auto twin = asTwinUnits(single, 2);
    require(!validateEngineConfig(single) && !validateEngineConfig(twin), "valid fixtures");
    const auto one = heldFullLoad(single, 9.0);
    const auto two = heldFullLoad(twin, 9.0);
    std::cout << "  I4, one turbocharger: boost " << one.boostRatio << ", " << one.torqueNm << " N.m, shaft "
              << one.shaftRpm[0] << " rpm; two halves: boost " << two.boostRatio << ", " << two.torqueNm
              << " N.m, shafts " << two.shaftRpm[0] << " / " << two.shaftRpm[1] << " rpm\n";
    require(one.boostRatio > 1.2, "the fixture makes boost (else this proves nothing)");
    require(std::abs(two.boostRatio - one.boostRatio) < 0.01 * one.boostRatio
            && std::abs(two.torqueNm - one.torqueNm) < 0.01 * one.torqueNm,
        "two identical turbochargers make the boost and torque of one twice the size");
    // Same pressure ratio, same tip speed: a wheel of 1/sqrt(2) the size
    // spins sqrt(2) faster.
    require(std::abs(two.shaftRpm[0] - std::numbers::sqrt2 * one.shaftRpm[0]) < 0.01 * one.shaftRpm[0]
            && std::abs(two.shaftRpm[1] - std::numbers::sqrt2 * one.shaftRpm[0]) < 0.01 * one.shaftRpm[0],
        "each half spins sqrt(2) faster than the double one");

    // Each half holds a quarter of the double's kinetic energy at the design
    // point (inertia x 2^-2.5, speed squared x 2) on half its turbine power:
    // the pair spools faster, which is why engines carry two.
    const auto split = withTurbochargerCount(single, 2);
    const auto heldRpm = 0.45 * single.redlineRpm;
    const auto oneSpool = secondsToBoost(single, heldRpm, 0.9);
    const auto twoSpool = secondsToBoost(split, heldRpm, 0.9);
    std::cout << "  to 90 % boost at " << heldRpm << " rpm: one turbocharger " << oneSpool << " s, two halves "
              << twoSpool << " s\n";
    require(twoSpool < 0.85 * oneSpool, "two half-size turbochargers spool faster than one of twice the size");

    // A charge-air cooler: the same boost, a denser charge.
    auto cooled = single;
    cooled.forcedInduction.intercoolerEffectiveness = 0.7;
    require(!validateEngineConfig(cooled), "valid intercooled fixture");
    const auto intercooled = heldFullLoad(cooled, 9.0);
    std::cout << "  with a 0.7 intercooler: boost " << intercooled.boostRatio << ", " << intercooled.torqueNm
              << " N.m\n";
    require(intercooled.torqueNm > 1.08 * one.torqueNm,
        "an intercooler makes more torque from the same boost");
    require(std::abs(intercooled.boostRatio - one.boostRatio) < 0.05 * one.boostRatio,
        "the wastegate still holds the boost");
}

/** A V8 with two cylinders on one turbocharger and six on the other: the
 *  small one gets a third of the gas, spins slower and passes less air. */
void aSmallBankSpinsSlower() {
    const auto engine = asTwinUnits(withPaths(withTurbocharger(makeDefaultV8()),
        { { 1, 2 }, { 3, 4, 5, 6, 7, 8 } }), 2);
    require(!validateEngineConfig(engine), "valid fixture");
    const auto run = heldFullLoad(engine, 9.0);
    std::cout << "  V8, 2 + 6 cylinders: shafts " << run.shaftRpm[0] << " / " << run.shaftRpm[1]
              << " rpm, flow shares " << run.flowShare[0] << " / " << run.flowShare[1] << ", boost "
              << run.boostRatio << '\n';
    require(run.shaftRpm[0] < 0.8 * run.shaftRpm[1], "the turbocharger on two cylinders spins slower");
    require(run.flowShare[0] < 0.4, "and its compressor passes the smaller share of the air");
}

/** The ECU's boost table is the boost: by default the configuration's
 *  wastegate ratio, and a lower table holds a lower boost. */
void boostTableIsTheTarget() {
    const auto config = withTurbocharger(makeDefaultInlineFour());
    const auto defaults = calibration::makeDefaultEcuCalibration(config);
    const auto* table = defaults.find(calibration::keys::boostTargetGauge);
    require(table != nullptr, "a turbocharged engine's default tables carry a boost target");
    const auto expectedGaugeKpa = (config.forcedInduction.wastegatePressureRatio - 1.0) * 101.325;
    for (const auto value : std::get<calibration::CalibrationCurve1D>(*table).values)
        require(std::abs(value - expectedGaugeKpa) < 1.0e-9, "the default table is the wastegate ratio, flat");
    auto aspirated = makeDefaultInlineFour();
    aspirated.forcedInduction.enabled = false;
    require(calibration::makeDefaultEcuCalibration(aspirated).find(calibration::keys::boostTargetGauge) == nullptr,
        "a naturally aspirated engine has no boost table");

    const auto stock = heldFullLoad(config, 9.0);
    const auto lower = heldFullLoad(config, 9.0, expectedGaugeKpa - 20.0);
    std::cout << "  boost table " << expectedGaugeKpa << " kPa: ratio " << stock.boostRatio << ", "
              << stock.torqueNm << " N.m; " << expectedGaugeKpa - 20.0 << " kPa: ratio " << lower.boostRatio
              << ", " << lower.torqueNm << " N.m\n";
    require(std::abs(stock.boostRatio - (1.0 + expectedGaugeKpa / 101.325)) < 0.02,
        "the default table holds the configured boost");
    require(std::abs(lower.boostRatio - (1.0 + (expectedGaugeKpa - 20.0) / 101.325)) < 0.02,
        "a table 20 kPa lower holds a boost 20 kPa lower");
    require(lower.torqueNm < stock.torqueNm, "and the engine makes less torque");
}

[[nodiscard]] EngineConfig catalogueEngine(std::string_view selector) {
    static const auto catalogue = loadEngineCatalog(ENGINELAB_CATALOG_ROOT);
    const auto selected = selectSingleEngineCatalogEntry(catalogue.entries, selector);
    require(static_cast<bool>(selected), "catalogue engine " + std::string(selector));
    auto config = selected.entry->config;
    normaliseEngineConfig(config);
    return config;
}

/** A wastegate set far past the catalogue's holds its boost: the gate's
 *  authority grows with the boost, and a fixed controller band ran a 13 Hz
 *  limit cycle from ~2.7 (2JZ) or ~3.0 (EJ25), the gate slamming shut and open
 *  and lambda swinging 0.58 <-> 0.96 (EJ25 at 3.2, journal 2026-10-25). The
 *  wastegate is moved as the engine editor moves it, the rated ratio keeping
 *  its distance. */
void highBoostHoldsSteady() {
    for (const auto* name : { "EJ25", "2JZ" }) {
        auto config = catalogueEngine(name);
        auto& turbo = config.forcedInduction;
        const auto margin = turbo.pressureRatio - turbo.wastegatePressureRatio;
        turbo.wastegatePressureRatio = 3.2;
        turbo.pressureRatio = turbo.wastegatePressureRatio + margin;
        const auto run = heldFullLoad(config, 9.0, -1.0, 5'400.0);
        std::cout << "  " << name << " wastegate 3.2 at 5,400 rpm: boost " << run.boostRatio << " +- "
                  << run.boostStdDev << ", lambda " << run.lambdaMin << " .. " << run.lambdaMax << '\n';
        require(std::abs(run.boostRatio - 3.2) < 0.05, std::string(name) + ": the boost reaches its wastegate");
        require(run.boostStdDev < 0.03, std::string(name) + ": and holds it without hunting");
        require(run.lambdaMax - run.lambdaMin < 0.08, std::string(name) + ": so the mixture holds too");
    }
}

struct LiftOff final {
    double heldBoost {};
    double heldTorqueNm {};
    int reversals {};
    double firstReversalSeconds { -1.0 };
    double lastReversalSeconds { -1.0 };
    double leastDuctFlowKgPerSecond {};
};

/** Full throttle held at 4,000 rpm, then the throttle shut for 1.5 s. */
[[nodiscard]] LiftOff liftOff(const EngineConfig& config) {
    auto rig = std::make_unique<Rig>(config);
    constexpr double shutSeconds = 6.0;
    LiftOff run;
    auto rpm = 0.0;
    auto reversed = false;
    auto heldFrames = 0;
    for (auto frame = 0; frame < static_cast<int>((shutSeconds + 1.5) * 240.0); ++frame) {
        const auto t = frame * frameSeconds;
        EngineControls controls;
        controls.ignitionEnabled = true;
        controls.starterEngaged = t < 1.5;
        controls.throttle = t < 2.0 || t >= shutSeconds ? 0.0 : 1.0;
        if (t >= 2.0 && t < shutSeconds) controls.dynamometerTorqueNm = std::max(0.0, 4.0 * (rpm - 4'000.0));
        const auto state = rig->simulator->step(frameSeconds, controls).state;
        rpm = state.rpm;
        if (t >= shutSeconds - 1.0 && t < shutSeconds) {
            run.heldBoost += state.boostPressureRatio;
            run.heldTorqueNm += state.torqueNm;
            ++heldFrames;
        }
        if (t < shutSeconds) continue;
        run.leastDuctFlowKgPerSecond = std::min(run.leastDuctFlowKgPerSecond, state.compressorDuctFlowKgPerSecond);
        const auto now = state.compressorDuctFlowKgPerSecond < 0.0;
        if (now && !reversed) {
            ++run.reversals;
            if (run.firstReversalSeconds < 0.0) run.firstReversalSeconds = t - shutSeconds;
            run.lastReversalSeconds = t - shutSeconds;
        }
        reversed = now;
    }
    run.heldBoost /= std::max(1, heldFrames);
    run.heldTorqueNm /= std::max(1, heldFrames);
    return run;
}

/** Greitzer's surge, off by default: with it, a throttle shut on boost with
 *  no blow-off valve blows the charge back through the wheel in bursts (a
 *  turbocharger's flutter); a blow-off valve vents the charge instead, and
 *  the held boost is the map's either way. */
void liftOffSurgesWithoutBlowOff() {
    auto config = catalogueEngine("2JZ");
    require(!config.forcedInduction.compressorSurge, "surge is off by default");
    config.forcedInduction.blowOffValveFlowAreaMm2 = 0.0;
    const auto quasiSteady = liftOff(config);
    config.forcedInduction.compressorSurge = true;
    const auto bare = liftOff(config);
    config.forcedInduction.blowOffValveFlowAreaMm2 = 700.0;
    const auto vented = liftOff(config);
    std::cout << "  2JZ lift-off at 4,000 rpm: held boost " << quasiSteady.heldBoost << " / " << bare.heldBoost
              << ", torque " << quasiSteady.heldTorqueNm << " / " << bare.heldTorqueNm
              << " N.m; no valve: " << bare.reversals << " reversals over " << bare.firstReversalSeconds
              << " .. " << bare.lastReversalSeconds << " s, least duct flow " << bare.leastDuctFlowKgPerSecond
              << " kg/s; with a valve: " << vented.reversals << " reversals\n";
    require(quasiSteady.reversals == 0, "without the surge model the duct is not resolved");
    require(std::abs(bare.heldBoost - quasiSteady.heldBoost) < 0.03 * quasiSteady.heldBoost,
        "the held boost is the map's with or without the duct resolved");
    require(bare.reversals >= 3, "a shut throttle with no valve surges, the flow reversing in bursts");
    require(vented.reversals == 0, "a blow-off valve vents the charge: no surge");
}

/** Up to its top speed line a compressor's efficiency is the authored one,
 *  exactly; past it it falls fast. */
void topSpeedLineCostsEfficiency() {
    ForcedInductionConfig turbo;
    turbo.designShaftSpeedRpm = 120'000.0;
    require(turboMaximumShaftSpeedRpm(turbo) == 156'000.0, "the line defaults to 1.3 x the design speed");
    const auto line = radiansPerSecond(156'000.0);
    require(compressorOverspeedEfficiencyScale(turbo, 0.0) == 1.0
            && compressorOverspeedEfficiencyScale(turbo, line) == 1.0,
        "up to the line the efficiency is untouched, bit for bit");
    const auto over = compressorOverspeedEfficiencyScale(turbo, 1.09 * line);
    require(over > 0.45 && over < 0.55, "9 % past the line the wheel has about half its efficiency");
    turbo.maximumShaftSpeedRpm = 200'000.0;
    require(turboMaximumShaftSpeedRpm(turbo) == 200'000.0, "an authored line is kept");
    require(compressorOverspeedEfficiencyScale(turbo, line) == 1.0, "and moves the collapse with it");
}

/** A petrol 2JZ given a methanol ratio at 60 MJ/kg -- 32 MJ per kilogram of
 *  oxygen, 2.5 times any real fuel, as an owner's Fuel edit made it -- ran
 *  its turbocharger to 3.5 x its design speed and ten bar at 6,000 rpm
 *  (journal 2026-11-11). Without a top speed line or an overboost cut it
 *  still runs away (3.59 bar, 1.33 x its line, at 5,000 rpm); with the line the shaft is held near it (and the wheel takes
 *  damage); with the ECU's cut set to 40 kPa (it is off by default) the
 *  boost stays by its target. */
void runawayFuelIsHeld() {
    auto config = catalogueEngine("2JZ");
    auto& fuel = config.fuelProperties;
    const auto petrolRatio = fuel.stoichiometricAirFuelRatio;
    fuel.name = "Methanol at a petrol heat";
    fuel.lowerHeatingValueMjPerKg = 60.0;
    fuel.densityKgPerL = 0.792;
    fuel.stoichiometricAirFuelRatio = 8.0;
    fuel.molarMassGramsPerMole = 32.04;
    fuel.oxygenMolesPerFuelMole = 8.0 * 0.232 * fuel.molarMassGramsPerMole / 31.9988;
    fuel.productMolesPerFuelMole = 3.0;
    config.injection.injectorFlowMgPerSecond *= petrolRatio / fuel.stoichiometricAirFuelRatio;
    config.injection.latentHeatKjPerKg = 1'103.0;
    require(!validateEngineConfig(config), "valid fixture");
    const auto topRpm = turboMaximumShaftSpeedRpm(config.forcedInduction);
    const auto targetRatio = config.forcedInduction.wastegatePressureRatio;

    auto unlined = config;
    unlined.forcedInduction.maximumShaftSpeedRpm = 1.0e9;
    const auto free = heldFullLoad(unlined, 9.0, -1.0, 5'000.0, 0.0);
    const auto lined = heldFullLoad(config, 9.0, -1.0, 5'000.0, 0.0);
    const auto guarded = heldFullLoad(config, 9.0, -1.0, 5'000.0, 40.0);
    std::cout << "  2JZ at 32 MJ/kg of oxygen, 5,000 rpm: no line, no cut: boost " << free.boostMax << ", shaft "
              << free.shaftRpmMax << " rpm; line " << topRpm << " rpm: boost " << lined.boostMax << ", shaft "
              << lined.shaftRpmMax << " rpm, wheel damage " << lined.wheelDamage << "; with the overboost cut: boost "
              << guarded.boostMax << ", shaft " << guarded.shaftRpmMax << " rpm, cut "
              << (guarded.overboostCut ? "yes" : "no") << '\n';
    // Runs away = past both bounds the line must hold below (3.84 bar before
    // the spark map stopped retarding boost; its fuller burn leaves the
    // turbine less, 3.59 bar and 1.33 x the line after).
    require(free.boostMax > 3.0 && free.shaftRpmMax > 1.3 * topRpm,
            "without the line or the cut the fixture runs away (else this proves nothing)");
    require(lined.boostMax < 3.0 && lined.shaftRpmMax < 1.3 * topRpm,
        "the top speed line holds the shaft near it and the boost under 3.0");
    require(lined.wheelDamage > 0.0, "and a wheel held past its line is damaged");
    require(guarded.overboostCut && guarded.boostMax < targetRatio + 0.55,
        "the overboost cut holds the boost near its target");
}

} // namespace

int main() {
    mapFollowsItsDesignPoint();
    std::cout << "compressor map: ok\n";
    parallelCompressorsShareTheCharge();
    std::cout << "parallel compressors: ok\n";
    countKeepsTheSize();
    std::cout << "turbocharger count: ok\n";
    twoIdenticalAreOneDouble();
    std::cout << "two identical = one double: ok\n";
    aSmallBankSpinsSlower();
    std::cout << "two plus six cylinders: ok\n";
    boostTableIsTheTarget();
    std::cout << "ECU boost table: ok\n";
    highBoostHoldsSteady();
    std::cout << "high boost holds steady: ok\n";
    liftOffSurgesWithoutBlowOff();
    std::cout << "lift-off surge: ok\n";
    topSpeedLineCostsEfficiency();
    std::cout << "top speed line: ok\n";
    runawayFuelIsHeld();
    std::cout << "runaway fuel held: ok\n";
    return 0;
}
