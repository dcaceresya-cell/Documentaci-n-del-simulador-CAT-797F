cmake_minimum_required(VERSION 3.24)
# C is listed even though EngineLab itself is C++ only. JUCE declares
# `project(JUCE LANGUAGES C CXX)`, but that runs inside the FetchContent
# subdirectory scope, so the C rule variables (CMAKE_C_COMPILE_OBJECT and
# friends) never reach the top level. The Visual Studio generator tolerates
# that -- MSBuild picks the language from the file extension -- which is why the
# windows-vs2022 cache has CMAKE_C_FLAGS but no CMAKE_C_COMPILER at all. Ninja
# resolves the compile rule at generate time and fails outright.
project(EngineLab VERSION 0.14.1 LANGUAGES CXX C)

option(ENGINELAB_BUILD_TESTS "Build EngineLab unit tests" ON)
option(ENGINELAB_BUILD_COMPARISON_HARNESS "Build deterministic comparison and regression harness" ON)
option(ENGINELAB_ENABLE_WARNINGS_AS_ERRORS "Treat compiler warnings as errors" OFF)
option(ENGINELAB_ENABLE_SANITIZERS "Enable Address/UndefinedBehavior sanitizers" OFF)
option(ENGINELAB_ENABLE_CLANG_TIDY "Run clang-tidy while compiling" OFF)
option(ENGINELAB_ENABLE_COMPILER_CACHE "Route compilation through sccache/ccache when one is available" OFF)
set(CMAKE_CXX_STANDARD 20)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_CXX_EXTENSIONS OFF)
set(CMAKE_EXPORT_COMPILE_COMMANDS ON)

# DO NOT SWITCH THIS ON. It is kept only so the finding is reproducible.
#
# A compiler cache looked like the way to make a bisect cheap, and it is not
# usable here. Two independent reasons:
#
# - The Visual Studio generator silently IGNORES
#   CMAKE_CXX_COMPILER_LAUNCHER, so the authoritative tree cannot use it at all.
# - With the Ninja generator it is worse than useless: it breaks header
#   dependency tracking. Ninja learns dependencies by parsing cl.exe's
#   /showIncludes output, and sccache does not pass it through, so every object
#   records `#deps 0` and the tree serves STALE objects after any header edit.
#   Measured on this project: with the launcher, `ninja -t deps` on
#   EngineTypes.cpp.obj reports `#deps 0`; without it, `#deps 1` naming
#   EngineTypes.hpp. SCCACHE_DIRECT=false does not help, and a forced recache
#   (SCCACHE_RECACHE=1) does not either -- it is not a cache-hit artefact.
#
# The cache was measured at 94.5 % hits and 56.5 s for a full rebuild that costs
# ~474 s cold, so the prize was real; it is simply not worth a build tree that
# can silently compile against a header it no longer matches.
if(ENGINELAB_ENABLE_COMPILER_CACHE)
    file(GLOB ENGINELAB_COMPILER_CACHE_HINTS
        "$ENV{LOCALAPPDATA}/Microsoft/WinGet/Packages/Mozilla.sccache*/*")
    find_program(ENGINELAB_COMPILER_CACHE NAMES sccache ccache
        HINTS ${ENGINELAB_COMPILER_CACHE_HINTS})
    if(ENGINELAB_COMPILER_CACHE)
        set(CMAKE_CXX_COMPILER_LAUNCHER "${ENGINELAB_COMPILER_CACHE}")
        if(MSVC)
            # sccache cannot cache a compile that writes into a shared PDB, and
            # silently falls back to an uncached invocation for every such
            # object -- a 0% hit rate that looks like the cache simply not
            # working. /Z7 puts the debug info in the object instead, where the
            # cache can carry it. CMake 3.24 predates
            # CMAKE_MSVC_DEBUG_INFORMATION_FORMAT (CMP0141 landed in 3.25), so
            # the per-configuration flags are rewritten directly. Release
            # carries no debug flag at all here and comes out unchanged.
            foreach(enginelab_config DEBUG RELWITHDEBINFO MINSIZEREL RELEASE)
                string(REPLACE "/ZI" "/Z7"
                    CMAKE_CXX_FLAGS_${enginelab_config} "${CMAKE_CXX_FLAGS_${enginelab_config}}")
                string(REPLACE "/Zi" "/Z7"
                    CMAKE_CXX_FLAGS_${enginelab_config} "${CMAKE_CXX_FLAGS_${enginelab_config}}")
            endforeach()
        endif()
        message(STATUS "EngineLab: compiler cache enabled (${ENGINELAB_COMPILER_CACHE})")
    else()
        message(WARNING
            "ENGINELAB_ENABLE_COMPILER_CACHE is ON but neither sccache nor ccache was found")
    endif()
endif()

# GCC and Clang default to -ffp-contract=fast, which fuses `a * b + c` into a
# single FMA. MSVC under /fp:precise does not contract, and the solver is full
# of exactly that shape, so the default would make a Linux result differ from
# the reference platform's -- and differ again between GCC versions and
# optimisation levels, since whether a given expression gets fused is a
# code-generation decision. The tests assert tight numeric tolerances, so
# predictability is worth more here than the fused multiply-add. See
# docs/platforms.md.
if(NOT MSVC)
    add_compile_options(-ffp-contract=off)
endif()

# Sanitizer instrumentation must be consistent across EngineLab and fetched
# static dependencies (notably yaml-cpp), otherwise MSVC's annotated STL types
# produce LNK2038 mismatches at the final executable.
if(ENGINELAB_ENABLE_SANITIZERS)
    if(MSVC)
        add_compile_options(/fsanitize=address)
        add_link_options(/INCREMENTAL:NO)
    else()
        add_compile_options(-fsanitize=address,undefined -fno-omit-frame-pointer)
        add_link_options(-fsanitize=address,undefined)
    endif()
endif()

if(ENGINELAB_ENABLE_CLANG_TIDY)
    find_program(ENGINELAB_CLANG_TIDY_EXECUTABLE NAMES clang-tidy REQUIRED)
    set(CMAKE_CXX_CLANG_TIDY "${ENGINELAB_CLANG_TIDY_EXECUTABLE}")
endif()

include(FetchContent)
include(cmake/CompilerWarnings.cmake)

# yaml-cpp 0.8.0 still declares compatibility with CMake 3.4. CMake 4.x
# requires consumers to opt into the 3.5 policy floor explicitly.
set(CMAKE_POLICY_VERSION_MINIMUM 3.5 CACHE STRING "Minimum policy version for legacy dependencies")

# Pinned dependencies keep builds reproducible.
FetchContent_Declare(JUCE GIT_REPOSITORY https://github.com/juce-framework/JUCE.git GIT_TAG 8.0.13 GIT_SHALLOW TRUE)
FetchContent_Declare(nlohmann_json GIT_REPOSITORY https://github.com/nlohmann/json.git GIT_TAG v3.12.0 GIT_SHALLOW TRUE)
FetchContent_Declare(yaml_cpp GIT_REPOSITORY https://github.com/jbeder/yaml-cpp.git GIT_TAG 0.8.0 GIT_SHALLOW TRUE)
FetchContent_MakeAvailable(JUCE nlohmann_json yaml_cpp)

# None of the three dependencies' headers build clean under the warning set
# `cmake/CompilerWarnings.cmake` puts on our own targets, and that file explains
# why no source property can reach a header.
if(NOT MSVC)
    set(enginelab_vendor_targets nlohmann_json yaml-cpp)
    if(juce_SOURCE_DIR)
        # A JUCE module's target carries its own directory's name, and the
        # modules are one level deep inside `modules/` by construction.
        file(GLOB enginelab_juce_module_dirs "${juce_SOURCE_DIR}/modules/*")
        foreach(enginelab_juce_module_dir IN LISTS enginelab_juce_module_dirs)
            if(IS_DIRECTORY "${enginelab_juce_module_dir}")
                get_filename_component(enginelab_juce_module
                    "${enginelab_juce_module_dir}" NAME)
                list(APPEND enginelab_vendor_targets ${enginelab_juce_module})
            endif()
        endforeach()
    endif()
    enginelab_vendor_headers_are_system(${enginelab_vendor_targets})
endif()

# JUCE's modules arrive as interface sources, so every target that linked one
# compiled JUCE again: about 130 of the Linux tree's 390 compile units were
# JUCE, six to fifteen per executable. They are compiled once here, linked
# PRIVATE so their sources stay in this library, and their include directories
# and definitions are re-exported (JUCE's own pattern for a shared code
# library). Our targets link this, never a `juce::` module directly.
add_library(EngineLabJuce STATIC)
target_link_libraries(EngineLabJuce
    PRIVATE
        juce::juce_audio_basics juce::juce_audio_devices juce::juce_audio_formats
        juce::juce_audio_utils juce::juce_dsp juce::juce_gui_extra juce::juce_opengl
        juce::juce_cryptography
        juce::juce_recommended_config_flags)
target_compile_definitions(EngineLabJuce
    PUBLIC JUCE_WEB_BROWSER=0 JUCE_USE_CURL=0
    INTERFACE $<TARGET_PROPERTY:EngineLabJuce,COMPILE_DEFINITIONS>)
target_include_directories(EngineLabJuce SYSTEM
    INTERFACE $<TARGET_PROPERTY:EngineLabJuce,INCLUDE_DIRECTORIES>)
set_target_properties(EngineLabJuce PROPERTIES POSITION_INDEPENDENT_CODE TRUE)

add_subdirectory(src/foundation)
add_subdirectory(src/calibration)
add_subdirectory(src/events)
add_subdirectory(src/physics)
add_subdirectory(src/ecu)
add_subdirectory(src/exhaust)
add_subdirectory(src/gas-dynamics)
add_subdirectory(src/simulation)
add_subdirectory(src/diagnostics)
add_subdirectory(src/render)
add_subdirectory(src/serialization)
add_subdirectory(src/scripting)
add_subdirectory(src/catalog)
add_subdirectory(src/runtime)
add_subdirectory(src/audio)
add_subdirectory(src/app)
if(ENGINELAB_BUILD_COMPARISON_HARNESS)
    add_subdirectory(tools)
endif()

if(ENGINELAB_BUILD_TESTS)
    enable_testing()
    add_subdirectory(src/calibration/tests)
    add_subdirectory(src/exhaust/tests)
    add_subdirectory(src/gas-dynamics/tests)
    add_subdirectory(src/render/tests)
    add_subdirectory(src/scripting/tests)
    add_subdirectory(tests)
endif()

# Packaging: `--target package` produces EngineLab-<version>-win64.zip on
# Windows, EngineLab-<version>-Linux.tar.gz on Linux; both are attached to
# every GitHub release. Each holds only what a user needs to
# run the application; the documentation stays online.
install(TARGETS EngineLabApp
    RUNTIME DESTINATION . COMPONENT EngineLab
    BUNDLE DESTINATION . COMPONENT EngineLab)
if(TARGET EngineLabOfflineAudioExporter AND TARGET EngineLabAbClipRenderer)
    install(TARGETS EngineLabOfflineAudioExporter EngineLabAbClipRenderer
        RUNTIME DESTINATION tools COMPONENT EngineLab)
endif()
install(DIRECTORY engines parts assets examples voicing DESTINATION . COMPONENT EngineLab)
install(FILES packaging/README.txt LICENSE.md THIRD_PARTY_NOTICES.md DESTINATION . COMPONENT EngineLab)
install(FILES src/app/resources/fonts/OFL-BarlowSemiCondensed.txt src/app/resources/fonts/OFL-IBMPlexMono.txt
    src/app/resources/fonts/OFL-Inter.txt src/app/resources/fonts/OFL-JetBrainsMono.txt
    DESTINATION licenses COMPONENT EngineLab)
# The statically linked libraries' own notices, taken from the pinned sources
# CMake fetched: MIT asks for the copyright and permission text to travel with
# every copy (audit PKG-01).
install(FILES "${nlohmann_json_SOURCE_DIR}/LICENSE.MIT"
    DESTINATION licenses RENAME nlohmann-json-LICENSE.txt COMPONENT EngineLab)
install(FILES "${yaml_cpp_SOURCE_DIR}/LICENSE"
    DESTINATION licenses RENAME yaml-cpp-LICENSE.txt COMPONENT EngineLab)
install(FILES "${juce_SOURCE_DIR}/LICENSE.md"
    DESTINATION licenses RENAME JUCE-LICENSE.md COMPONENT EngineLab)

# Ship the MSVC runtime next to the executable (app-local deployment), so the
# archive runs on a machine without the Visual C++ Redistributable installed.
# A Linux build has no counterpart: the application links the distribution's
# own ALSA, X11, GL and freetype, which `CONTRIBUTING.md` lists as build and
# run dependencies.
if(MSVC)
    set(CMAKE_INSTALL_SYSTEM_RUNTIME_DESTINATION .)
    set(CMAKE_INSTALL_SYSTEM_RUNTIME_COMPONENT EngineLab)
    set(CMAKE_INSTALL_UCRT_LIBRARIES OFF)
    include(InstallRequiredSystemLibraries)
endif()

set(CPACK_PACKAGE_NAME "EngineLab")
set(CPACK_PACKAGE_VERSION "${PROJECT_VERSION}")
set(CPACK_PACKAGE_VENDOR "EngineLab contributors")
# A tarball on Linux: it keeps the executable bit a zip may drop.
if(UNIX AND NOT APPLE)
    set(CPACK_GENERATOR "TGZ")
else()
    set(CPACK_GENERATOR "ZIP")
endif()
set(CPACK_INSTALL_CMAKE_PROJECTS "${CMAKE_BINARY_DIR};${PROJECT_NAME};EngineLab;/")
include(CPack)
