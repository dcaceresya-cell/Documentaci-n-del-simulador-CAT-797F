"""CAN vehicle dashboard backend."""
