import warnings
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .dbc_specifics import DbcSpecifics


class DbcEnvironmentVariable:
    """A CAN environment variable.

    """

    def __init__(self,
                 name: str,
                 env_type: int,
                 minimum: float,
                 maximum: float,
                 unit: str,
                 initial_value: float,
                 env_id: int,
                 access_type: str,
                 access_nodes: list[str],
                 comment: str | None,
                 data_size: int | None,
                 dbc_specifics: "DbcSpecifics") -> None:
        self._name = name
        self._env_type = env_type
        self._minimum = minimum
        self._maximum = maximum
        self._unit = unit
        self._initial_value = initial_value
        self._env_id = env_id
        self._access_type = access_type
        self._access_nodes = access_nodes
        self._comment = comment
        self._data_size = data_size
        self._dbc = dbc_specifics

    @property
    def name(self) -> str:
        """The environment variable name as a string.

        """

        return self._name

    @name.setter
    def name(self, value: str) -> None:
        self._name = value

    @property
    def env_type(self) -> int:
        """The environment variable type value.

        """

        return self._env_type

    @env_type.setter
    def env_type(self, value: int) -> None:
        self._env_type = value

    @property
    def minimum(self) -> int | float:
        """The minimum value of the environment variable.

        """

        return self._minimum

    @minimum.setter
    def minimum(self, value: float) -> None:
        self._minimum = value

    @property
    def maximum(self) -> int | float:
        """The maximum value of the environment variable.

        """

        return self._maximum

    @maximum.setter
    def maximum(self, value: float) -> None:
        self._maximum = value

    @property
    def unit(self) -> str:
        """ The units in which the environment variable is expressed as a string.

        """

        return self._unit

    @unit.setter
    def unit(self, value: str) -> None:
        self._unit = value

    @property
    def initial_value(self) -> int | float:
        """The initial value of the environment variable.

        """

        return self._initial_value

    @initial_value.setter
    def initial_value(self, value: float) -> None:
        self._initial_value = value

    @property
    def env_id(self) -> int:
        """The id value of the environment variable.

        """

        return self._env_id

    @env_id.setter
    def env_id(self, value: int) -> None:
        self._env_id = value

    @property
    def access_type(self) -> str:
        """The environment variable access type as a string.

        """

        return self._access_type

    @access_type.setter
    def access_type(self, value: str) -> None:
        self._access_type = value

    @property
    def access_node(self) -> str:
        """The first environment variable access node as a string.

        Kept for compatibility; use ``access_nodes`` to get all of them.

        """

        if len(self._access_nodes) > 1:
            warnings.warn(
                f"'{self._name}' has {len(self._access_nodes)} access nodes, "
                "only the first is returned; use 'access_nodes'",
                UserWarning,
                stacklevel=2,
            )

        return self._access_nodes[0]

    @access_node.setter
    def access_node(self, value: str) -> None:
        warnings.warn(
            "'access_node' is deprecated, use 'access_nodes' instead.",
            DeprecationWarning,
            stacklevel=2,
        )
        self._access_nodes = [value]

    @property
    def access_nodes(self) -> list[str]:
        """The environment variable access nodes as a list of strings.

        """

        return self._access_nodes

    @access_nodes.setter
    def access_nodes(self, value: list[str]) -> None:
        self._access_nodes = value

    @property
    def data_size(self) -> int | None:
        """The size of the environment variable data in bytes, or ``None`` if
        the database does not declare the variable as data.

        """

        return self._data_size

    @data_size.setter
    def data_size(self, value: int | None) -> None:
        self._data_size = value

    @property
    def comment(self) -> str | None:
        """The environment variable comment, or ``None`` if unavailable.

        """

        return self._comment

    @comment.setter
    def comment(self, value: str | None) -> None:
        self._comment = value

    @property
    def dbc(self) -> "DbcSpecifics":
        """An object containing dbc specific properties like e.g. attributes.

        """

        return self._dbc

    @dbc.setter
    def dbc(self, value: "DbcSpecifics") -> None:
        self._dbc = value

    def __repr__(self) -> str:
        return "environment_variable('{}', {}, {}, {}, '{}', {}, {}, '{}', '{}', {})".format(
            self._name,
            self._env_type,
            self._minimum,
            self._maximum,
            self._unit,
            self._initial_value,
            self._env_id,
            self._access_type,
            ','.join(self._access_nodes),
            "'" + self._comment + "'" if self._comment is not None else None)
